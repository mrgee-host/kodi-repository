plugin.program.steam.library 0.4.08 - R4

MrGee Kodi Family R4 runtime and consistency fixes.

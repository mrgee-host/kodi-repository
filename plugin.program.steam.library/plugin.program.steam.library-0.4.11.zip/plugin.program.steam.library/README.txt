Steam Library 0.4.10
====================

Fresh-install data provider for the Mr.Gee Kodi Family.

- Creates the current database schema directly.
- Rejects unsupported schemas instead of converting them.
- Does not patch Arctic Fuse 3. KPM owns all AF3 XML integration.
- Preserves current metadata, collections, hidden-game state, SteamEdit name/sort title behavior, artwork, achievements, playtime, and diagnostics.
- Uses atomic database transactions.

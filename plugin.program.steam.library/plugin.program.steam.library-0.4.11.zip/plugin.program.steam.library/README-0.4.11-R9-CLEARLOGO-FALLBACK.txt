Steam Library 0.4.11

Only clearlogo cache failures use fallback: SteamGridDB first, then a verified local image file.
Other artwork behavior is unchanged.

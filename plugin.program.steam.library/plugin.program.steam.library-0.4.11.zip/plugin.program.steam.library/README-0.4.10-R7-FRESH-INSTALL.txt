Steam Library 0.4.10 - R7 Fresh-Install Baseline

- Creates the current Steam database schema only when the database is empty.
- Rejects unsupported schemas; no column-copy, games_new, or old-name migration runs.
- Creates runtime/cache folders directly without moving old layouts.
- Keeps current Steam Store/Community/SteamGridDB fallbacks, collection sync,
  game-only filtering, diagnostics, and atomic database transactions.
- Uses the new Steam Library icon supplied for the MrGee family.

v0.3.66 - LRS 1.5.29 RatingSlot bridge coordination

Purpose
- Steam Library provides clean RatingSlot bridge properties for games.
- LRS owns the lower rating row in Home, Hub, MyPrograms and MyVideoNav.
- Steam Library no longer owns or injects a direct lower Info_Meta rating row.

Game RatingSlot order
1. Steam review display/percentage with steam.png
2. Metacritic score with metacritic.png
3. Achievement count with steam-ach.png

Notes
- Slots are compacted left if a middle value is missing.
- Plain properties remain available: steam_rating_display, metacritic_score, achievement_display, achievement_unlocked, achievement_total.
- AF3 cleanup still removes old Steam direct Info_Meta_Object blocks only and does not touch LRS_Info_Meta_Ratings or LibraryRatings.* blocks.
- Icons use direct KPM shared-icon paths only.

# -*- coding: utf-8 -*-
from __future__ import annotations

import concurrent.futures
import csv
import glob
import html
import json
import os
import re
import shutil
import sqlite3
import struct
import subprocess
import sys
import time
import traceback
import urllib.parse
import urllib.request
import unicodedata
import zipfile
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
ADDON_PATH = ADDON.getAddonInfo("path")
HANDLE = int(sys.argv[1])
REQUEST_BASE_URL = sys.argv[0]
BASE_URL = "plugin://{}/".format(ADDON_ID)
UA = "Kodi-Steam-Library/0.3.79"
STEAM_BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0"
NA = "N/A"
KPM_SHARED_ICON_BASE = "special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/"
KPM_GAME_DATA_PROPERTY_NAMES = ("steam_appid", "steam_rating_display", "steam_review_desc", "metacritic_score", "achievement_display", "playtime_forever", "playtime_display", "age_rating_display", "tagline_display")


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_NAME, msg), level)


def bg_create(prog):
    try:
        prog.create(ADDON_NAME, "")
    except Exception:
        try:
            prog.create(ADDON_NAME)
        except Exception:
            pass


def bg_update(prog, pct, line):
    if not prog:
        return
    try:
        prog.update(int(pct), ADDON_NAME, str(line))
        return
    except Exception:
        pass
    try:
        prog.update(int(pct), str(line))
    except Exception:
        pass


def bg_close(prog):
    if not prog:
        return
    try:
        prog.close()
    except Exception:
        pass


def tr(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return xbmc.translatePath(path)


PROFILE = tr("special://profile/addon_data/{}/".format(ADDON_ID))
DB_PATH = os.path.join(PROFILE, "steam_library.db")
CACHE_DIR = os.path.join(PROFILE, "cache")
RUNTIME_DIR = os.path.join(PROFILE, "runtime")
STATE_DIR = os.path.join(RUNTIME_DIR, "state")
DIAG = os.path.join(RUNTIME_DIR, "diagnostics")
REPORTS_DIR = os.path.join(RUNTIME_DIR, "reports")
LOGS_DIR = os.path.join(RUNTIME_DIR, "logs")
EXPORTS_DIR = os.path.join(RUNTIME_DIR, "exports")
ALIASES_PATH = os.path.join(STATE_DIR, "collection_aliases.json")
VISIBILITY_PATH = os.path.join(STATE_DIR, "collection_visibility.json")
OWNED_CACHE_PATH = os.path.join(CACHE_DIR, "owned_games_cache.json")
STEAM250_CACHE_PATH = os.path.join(CACHE_DIR, "steam250_top250_cache.json")
APPINFO_SORT_CACHE_PATH = os.path.join(CACHE_DIR, "appinfo_sort_cache.json")


DESIRED_GAME_COLUMNS = [
    ("appid", "TEXT PRIMARY KEY"),
    ("name", "TEXT"),
    ("steam_name", "TEXT"),
    ("display_name", "TEXT"),
    ("steamedit_name", "TEXT"),
    ("sortname", "TEXT"),
    ("steamedit_sortname", "TEXT"),
    ("app_type", "TEXT"),
    ("year", "TEXT"),
    ("developer", "TEXT"),
    ("publisher", "TEXT"),
    ("genres", "TEXT"),
    ("tagline", "TEXT"),
    ("short_description", "TEXT"),
    ("steam_review_percent", "TEXT"),
    ("steam_review_desc", "TEXT"),
    ("steam_review_total", "TEXT"),
    ("steam250_rank", "TEXT"),
    ("steam250_score", "TEXT"),
    ("achievement_unlocked", "TEXT"),
    ("achievement_total", "TEXT"),
    ("completed", "TEXT"),
    ("finished", "TEXT"),
    ("metacritic_score", "TEXT"),
    ("esrb", "TEXT"),
    ("pegi", "TEXT"),
    ("poster_url", "TEXT"),
    ("thumb_url", "TEXT"),
    ("clearlogo_url", "TEXT"),
    ("fanart_url", "TEXT"),
    ("fanart1_url", "TEXT"),
    ("fanart2_url", "TEXT"),
    ("fanart3_url", "TEXT"),
    ("fanart4_url", "TEXT"),
    ("metadata_status", "TEXT"),
    ("metadata_source", "TEXT"),
    ("last_scraped", "INTEGER"),
    ("playtime_forever", "INTEGER"),
]


def ensure():
    os.makedirs(PROFILE, exist_ok=True)
    for folder in (CACHE_DIR, RUNTIME_DIR, STATE_DIR, DIAG, REPORTS_DIR, LOGS_DIR, EXPORTS_DIR):
        os.makedirs(folder, exist_ok=True)


def s(key, default=""):
    v = ADDON.getSetting(key)
    return v if v else default


def b(key, default=False):
    v = ADDON.getSetting(key)
    return default if v == "" else str(v).lower() == "true"


def i(key, default=0):
    try:
        return int(ADDON.getSetting(key))
    except Exception:
        return default


def nz(value, default=NA):
    if value is None:
        return default
    value = str(value).strip()
    return value if value else default


def art_or_empty(value):
    if not value or str(value).strip() == NA:
        return ""
    return str(value).strip()


def create_games_table(cur, table_name):
    cols = ", ".join(["{} {}".format(k, t) for k, t in DESIRED_GAME_COLUMNS])
    cur.execute("CREATE TABLE IF NOT EXISTS {} ({})".format(table_name, cols))


def ensure_games_schema(con):
    cur = con.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='games'")
    if not cur.fetchone():
        create_games_table(cur, "games")
        con.commit()
        return

    cur.execute("PRAGMA table_info(games)")
    old_cols = [r[1] for r in cur.fetchall()]
    desired = [k for k, _ in DESIRED_GAME_COLUMNS]

    if old_cols == desired:
        return

    create_games_table(cur, "games_new")
    expressions = []
    for col in desired:
        if col in old_cols:
            expressions.append(col)
        elif col == "steam_name" and "name" in old_cols:
            # Legacy DB only had one name column. Preserve it as the initial
            # Steam/original name until the next successful OwnedGames sync.
            expressions.append("name")
        elif col == "display_name" and "name" in old_cols:
            # Preserve the currently visible name (often already changed by SteamEdit).
            expressions.append("name")
        elif col == "developer" and "developers" in old_cols:
            expressions.append("developers")
        elif col == "publisher" and "publishers" in old_cols:
            expressions.append("publishers")
        elif col == "thumb_url" and "header_image" in old_cols:
            expressions.append("header_image")
        elif col == "metadata_status":
            expressions.append("'migrated'")
        elif col == "metadata_source":
            expressions.append("'legacy'")
        elif col == "completed" and "achievement_status" in old_cols:
            expressions.append("CASE WHEN achievement_status='COMPLETED' THEN '1' ELSE 'N/A' END")
        else:
            expressions.append("NULL")

    cur.execute(
        "INSERT OR REPLACE INTO games_new({}) SELECT {} FROM games".format(
            ", ".join(desired), ", ".join(expressions)
        )
    )
    cur.execute("DROP TABLE games")
    cur.execute("ALTER TABLE games_new RENAME TO games")
    con.commit()


def _notify2_0371(message, duration=4500, level=None):
    try:
        icon = xbmcgui.NOTIFICATION_INFO if level is None else level
        # AF3 notification layout is two lines: heading + one compact message.
        xbmcgui.Dialog().notification(ADDON_NAME, str(message or '').replace('\n', ' ')[:180], icon, int(duration))
    except Exception:
        pass


def format_playtime_forever(minutes, with_prefix=True):
    try:
        value = int(float(str(minutes or '').strip()))
    except Exception:
        value = 0
    if value <= 0:
        return ''
    if value < 120:
        body = '{0} minutes'.format(value)
    else:
        hours = round(value / 60.0, 1)
        body = '{0} hours'.format(int(hours) if float(hours).is_integer() else '{0:.1f}'.format(hours))
    return ('Play Time ' + body) if with_prefix else body


def _bootstrap_membership_local_0371(con):
    try:
        count = con.execute('SELECT COUNT(*) FROM library_membership').fetchone()[0]
        if int(count or 0) > 0:
            return
        now = int(time.time())
        appids = []
        playtimes = {}
        try:
            if os.path.exists(OWNED_CACHE_PATH):
                payload = json.loads(open(OWNED_CACHE_PATH, 'r', encoding='utf-8').read())
                for game in payload.get('games', []) or []:
                    appid = str(game.get('appid') or '').strip()
                    if appid:
                        appids.append(appid)
                        playtimes[appid] = int(game.get('playtime_forever') or 0)
        except Exception:
            pass
        if not appids:
            try:
                appids = [str(r[0]) for r in con.execute('SELECT DISTINCT appid FROM collections WHERE appid IS NOT NULL').fetchall()]
            except Exception:
                appids = []
        if not appids:
            try:
                appids = [str(r[0]) for r in con.execute('SELECT appid FROM games WHERE appid IS NOT NULL').fetchall()]
            except Exception:
                appids = []
        for appid in dict.fromkeys(appids):
            con.execute('INSERT OR IGNORE INTO library_membership(appid,is_active,first_seen,last_seen,last_sync) VALUES(?,?,?,?,?)', (appid,1,now,now,now))
            if appid in playtimes:
                con.execute('UPDATE games SET playtime_forever=? WHERE appid=?', (playtimes[appid], appid))
    except Exception as exc:
        log('Local membership bootstrap failed: {}'.format(exc), xbmc.LOGWARNING)



def _ensure_table_column_0373(con, table_name, column_name, column_type="TEXT"):
    try:
        cols = {str(r[1]) for r in con.execute("PRAGMA table_info({})".format(table_name)).fetchall()}
        if column_name not in cols:
            con.execute("ALTER TABLE {} ADD COLUMN {} {}".format(table_name, column_name, column_type))
    except Exception as exc:
        log("Could not add {}.{}: {}".format(table_name, column_name, exc), xbmc.LOGWARNING)


def _effective_name_0373(row, fallback=""):
    row = row or {}
    for key in ("display_name", "name", "steam_name"):
        try:
            value = str(row.get(key) or "").strip()
        except Exception:
            value = ""
        if value and value.upper() not in ("N/A", "NA", "NONE", "NULL"):
            return value
    return str(fallback or "").strip()


def _norm_name_0374(value):
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return " ".join(text.split()).strip()


def _same_name_0374(left, right):
    a = _norm_name_0374(left)
    b = _norm_name_0374(right)
    return bool(a and b and a == b)


def _collapse_duplicate_leading_articles_0374(value):
    """Collapse only repeated leading A/An/The, preserving the rest verbatim.

    Examples: A A Way Out -> A Way Out; The The Witcher 1 -> The Witcher 1.
    This intentionally does not remove a single leading article or alter display names.
    """
    text = str(value or "").strip()
    for _ in range(4):
        match = re.match(r"^(A|An|The)\s+(A|An|The)\b\s*(.*)$", text, re.IGNORECASE)
        if not match or match.group(1).casefold() != match.group(2).casefold():
            break
        rest = str(match.group(3) or "").lstrip()
        text = (match.group(1) + (" " + rest if rest else "")).strip()
    return text


def _steam_name_history_0374():
    """Read the previous names report before it is overwritten.

    v0.3.73 could replace a stored SteamEdit name when appinfo.vdf had already
    reverted to Steam's original title.  The old_name field lets 0.3.74 recover
    that custom value once, without requiring metadata rescraping.
    """
    path = os.path.join(DIAG, "steam_names_report.csv")
    recovered = {}
    try:
        with open(path, "r", encoding="utf-8-sig", newline="") as fh:
            rows = list(csv.DictReader(fh))
        for row in reversed(rows):
            appid = str(row.get("appid") or "").strip()
            old_name = str(row.get("old_name") or "").strip()
            new_name = str(row.get("new_name") or "").strip()
            old_sort = str(row.get("old_sortname") or "").strip()
            new_sort = str(row.get("new_sortname") or "").strip()
            if not appid or appid in recovered:
                continue
            rec = {}
            if old_name and new_name and not _same_name_0374(old_name, new_name):
                rec["name"] = old_name
            if old_sort and new_sort and not _same_name_0374(old_sort, new_sort):
                rec["sortname"] = old_sort
            if rec:
                recovered[appid] = rec
    except Exception:
        pass
    return recovered


def _cleanup_duplicate_articles_0374(con):
    try:
        marker = con.execute("SELECT value FROM library_sync_state WHERE key=?", ("sort_article_cleanup_0374",)).fetchone()
        if marker and str(marker[0] or "") == "1":
            return 0
    except Exception:
        marker = None
    changed = 0
    try:
        rows = con.execute("SELECT appid, sortname, steamedit_sortname FROM games").fetchall()
        for row in rows:
            appid = str(row[0])
            old_sort = str(row[1] or "")
            old_edit = str(row[2] or "") if len(row) > 2 else ""
            new_sort = _collapse_duplicate_leading_articles_0374(old_sort)
            new_edit = _collapse_duplicate_leading_articles_0374(old_edit)
            if new_sort != old_sort or new_edit != old_edit:
                con.execute("UPDATE games SET sortname=?, steamedit_sortname=? WHERE appid=?", (new_sort, new_edit, appid))
                changed += 1
        con.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("sort_article_cleanup_0374", "1"))
    except Exception as exc:
        log("Duplicate article cleanup failed: {}".format(exc), xbmc.LOGWARNING)
    return changed


def _manual_hidden_snapshot_0373(cur, appid):
    try:
        cur.execute("SELECT * FROM games WHERE appid=?", (str(appid),))
        row = cur.fetchone()
        if not row:
            return ""
        return json.dumps(dict(row), ensure_ascii=False, sort_keys=True)
    except Exception:
        return ""

def connect():
    ensure()
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    ensure_games_schema(con)
    con.execute("""CREATE TABLE IF NOT EXISTS collections (
        collection_id TEXT, name TEXT, appid TEXT, PRIMARY KEY(collection_id, appid)
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS hidden_games (
        appid TEXT PRIMARY KEY,
        name TEXT,
        source_collection_id TEXT,
        source_collection_name TEXT,
        hidden_at INTEGER
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS manual_hidden_games (
        appid TEXT PRIMARY KEY,
        name TEXT,
        hidden_at INTEGER,
        metadata_json TEXT
    )""")
    # Existing user databases keep the old simple tables. Add only the requested
    # Steam-hidden name and a full JSON snapshot for manual Kodi hides.
    _ensure_table_column_0373(con, "hidden_games", "name", "TEXT")
    _ensure_table_column_0373(con, "manual_hidden_games", "metadata_json", "TEXT")
    try:
        con.execute("""UPDATE hidden_games
                       SET name=COALESCE((SELECT NULLIF(g.display_name,'') FROM games g WHERE g.appid=hidden_games.appid),
                                         (SELECT NULLIF(g.name,'') FROM games g WHERE g.appid=hidden_games.appid),
                                         (SELECT NULLIF(g.steam_name,'') FROM games g WHERE g.appid=hidden_games.appid),
                                         hidden_games.appid)
                       WHERE name IS NULL OR name=''""")
    except Exception:
        pass
    con.execute("""CREATE TABLE IF NOT EXISTS library_membership (
        appid TEXT PRIMARY KEY,
        is_active INTEGER NOT NULL DEFAULT 1,
        first_seen INTEGER,
        last_seen INTEGER,
        removed_at INTEGER,
        last_sync INTEGER
    )""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_library_membership_active ON library_membership(is_active)")
    con.execute("""CREATE TABLE IF NOT EXISTS library_sync_state (
        key TEXT PRIMARY KEY, value TEXT
    )""")
    _cleanup_duplicate_articles_0374(con)
    _bootstrap_membership_local_0371(con)
    con.commit()
    return con


def load_collection_visibility():
    try:
        if os.path.exists(VISIBILITY_PATH):
            data = json.loads(open(VISIBILITY_PATH, "r", encoding="utf-8").read())
            if isinstance(data, dict):
                hidden = data.get("hidden_ids", [])
                if isinstance(hidden, list):
                    return {"hidden_ids": [str(x) for x in hidden]}
    except Exception as exc:
        log("Failed reading collection visibility: {}".format(exc), xbmc.LOGWARNING)
    return {"hidden_ids": []}


def save_collection_visibility(data):
    ensure()
    hidden = data.get("hidden_ids", [])
    with open(VISIBILITY_PATH, "w", encoding="utf-8") as f:
        f.write(json.dumps({"hidden_ids": [str(x) for x in hidden]}, indent=2, ensure_ascii=False))


def hidden_collection_keywords(value):
    text = str(value or "").strip().lower()
    text = re.sub(r"\s+", " ", text)
    return text in ("hidden", "hidden games", "steam hidden", "steamlibrary hidden") or text.endswith("hidden games")


def is_steam_hidden_collection(collection):
    # Only Steam's actual Hidden/Hidden Games collection is treated as hidden_games.
    # Manually hiding a collection folder does NOT hide its games anymore.
    return hidden_collection_keywords(collection.get("name")) or hidden_collection_keywords(collection.get("id"))


def collection_hidden(collection):
    cid = str(collection.get("id") or "")
    return is_steam_hidden_collection(collection) or cid in set(load_collection_visibility().get("hidden_ids", []))


def hidden_appids():
    try:
        con = connect()
        cur = con.cursor()
        vals = set()
        try:
            cur.execute("SELECT appid FROM hidden_games")
            vals.update(str(r[0]) for r in cur.fetchall())
        except Exception:
            pass
        try:
            cur.execute("SELECT appid FROM manual_hidden_games")
            vals.update(str(r[0]) for r in cur.fetchall())
        except Exception:
            pass
        con.close()
        return vals
    except Exception as exc:
        log("Failed reading hidden games: {}".format(exc), xbmc.LOGWARNING)
        return set()


def manual_hidden_appids():
    try:
        con = connect()
        cur = con.cursor()
        cur.execute("SELECT appid FROM manual_hidden_games")
        vals = set(str(r[0]) for r in cur.fetchall())
        con.close()
        return vals
    except Exception as exc:
        log("Failed reading manual hidden games: {}".format(exc), xbmc.LOGWARNING)
        return set()


def is_hidden_game(appid):
    if not appid:
        return False
    return str(appid) in hidden_appids()


def filter_hidden_appids(appids):
    hidden = hidden_appids()
    return [str(a) for a in appids if str(a) not in hidden]


def hide_games(appids, source_collection_id="", source_collection_name=""):
    # Kept for Steam Hidden/legacy callers. Manual context hide uses manual_hidden_games
    # so sync_hidden_games_from_collections() cannot wipe it on the next library sync.
    appids = [str(a) for a in (appids or []) if str(a)]
    if not appids:
        return 0
    con = connect()
    cur = con.cursor()
    now = int(time.time())
    for appid in appids:
        cur.execute("SELECT COALESCE(NULLIF(display_name,''),NULLIF(name,''),NULLIF(steam_name,''),?) FROM games WHERE appid=?", (appid, appid))
        row = cur.fetchone()
        game_name = str(row[0] if row and row[0] else appid)
        cur.execute("""INSERT OR REPLACE INTO hidden_games(appid, name, source_collection_id, source_collection_name, hidden_at)
                       VALUES(?,?,?,?,?)""", (appid, game_name, str(source_collection_id or ""), str(source_collection_name or ""), now))
    con.commit()
    con.close()
    return len(appids)


def hide_game_manual(appid, name=""):
    appid = str(appid or "").strip()
    if not appid:
        return False
    con = connect()
    cur = con.cursor()
    title = str(name or "").strip()
    if not title:
        try:
            cur.execute("SELECT name FROM games WHERE appid=?", (appid,))
            row = cur.fetchone()
            if row and row[0]:
                title = str(row[0]).strip()
        except Exception:
            title = ""
    if not title:
        title = fallback_title(appid)
    metadata_json = _manual_hidden_snapshot_0373(cur, appid)
    cur.execute("""INSERT OR REPLACE INTO manual_hidden_games(appid, name, hidden_at, metadata_json)
                   VALUES(?,?,?,?)""", (appid, title, int(time.time()), metadata_json))
    con.commit()
    con.close()
    return True


def unhide_game_manual(appid):
    appid = str(appid or "").strip()
    if not appid:
        return False
    con = connect()
    con.execute("DELETE FROM manual_hidden_games WHERE appid=?", (appid,))
    con.commit()
    con.close()
    return True


def manual_hidden_games_rows():
    try:
        con = connect()
        cur = con.cursor()
        cur.execute("""SELECT h.appid, COALESCE(NULLIF(h.name,''), NULLIF(g.name,''), h.appid) AS name, h.hidden_at
                       FROM manual_hidden_games h
                       LEFT JOIN games g ON g.appid=h.appid
                       ORDER BY LOWER(COALESCE(NULLIF(h.name,''), NULLIF(g.name,''), h.appid))""")
        rows = [dict(r) for r in cur.fetchall()]
        con.close()
        return rows
    except Exception as exc:
        log("Failed reading manual hidden game rows: {}".format(exc), xbmc.LOGWARNING)
        return []


def hide_game_from_context(appid):
    appid = str(appid or "").strip()
    if not appid:
        return
    title = fallback_title(appid)
    if not xbmcgui.Dialog().yesno(ADDON_NAME, "Hide this game from Steam Library?", title):
        return
    if hide_game_manual(appid, title):
        xbmcgui.Dialog().notification(ADDON_NAME, "Game hidden", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin("Container.Refresh")


def unhide_game_from_context(appid):
    appid = str(appid or "").strip()
    if not appid:
        return
    if unhide_game_manual(appid):
        xbmcgui.Dialog().notification(ADDON_NAME, "Game unhidden", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.executebuiltin("Container.Refresh")


def manage_hidden_games():
    rows = manual_hidden_games_rows()
    if not rows:
        xbmcgui.Dialog().notification(ADDON_NAME, "No manually hidden games", xbmcgui.NOTIFICATION_INFO, 2500)
        return
    labels = [str(r.get("name") or r.get("appid")) for r in rows]
    try:
        selected = xbmcgui.Dialog().multiselect("Unhide games", labels)
    except Exception:
        selected = None
    if selected is None:
        return
    count = 0
    for idx in selected:
        try:
            if unhide_game_manual(rows[idx].get("appid")):
                count += 1
        except Exception:
            pass
    xbmcgui.Dialog().notification(ADDON_NAME, "Unhidden {} game(s)".format(count), xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")


def sync_hidden_games_from_collections(con, cols):
    # Rebuild hidden_games ONLY from Steam's actual Hidden/Hidden Games collection.
    # This also cleans old bad rows created by earlier versions when "Hide this collection"
    # inserted every collection member into hidden_games.
    cur = con.cursor()
    cur.execute("DELETE FROM hidden_games")
    now = int(time.time())
    count = 0
    for c in cols:
        if not is_steam_hidden_collection(c):
            continue
        cid = str(c.get("id") or "")
        name = str(c.get("name") or "")
        for appid in c.get("appids", []):
            appid_s = str(appid)
            cur.execute("SELECT COALESCE(NULLIF(display_name,''),NULLIF(name,''),NULLIF(steam_name,''),?) FROM games WHERE appid=?", (appid_s, appid_s))
            row = cur.fetchone()
            game_name = str(row[0] if row and row[0] else appid_s)
            cur.execute("""INSERT OR REPLACE INTO hidden_games(appid, name, source_collection_id, source_collection_name, hidden_at)
                           VALUES(?,?,?,?,?)""", (appid_s, game_name, cid, name, now))
            count += 1
    return count


def collection_visible_appids(collection):
    return filter_hidden_appids([str(a) for a in collection.get("appids", [])])


def purge_hidden_games_from_runtime_rows():
    # Keep DB rows for diagnostics/history, but active runtime queries always skip hidden_games.
    return


def load_collection_aliases():
    try:
        if os.path.exists(ALIASES_PATH):
            data = json.loads(open(ALIASES_PATH, "r", encoding="utf-8").read())
            if isinstance(data, dict):
                return data
    except Exception as exc:
        log("Failed reading collection aliases: {}".format(exc), xbmc.LOGWARNING)
    return {}


def save_collection_aliases(data):
    ensure()
    with open(ALIASES_PATH, "w", encoding="utf-8") as f:
        f.write(json.dumps(data, indent=2, ensure_ascii=False))


def collection_display_name(collection):
    aliases = load_collection_aliases()
    cid = str(collection.get("id") or "")
    original = str(collection.get("name") or cid)
    alias = aliases.get(cid, "")
    return alias if alias else original


def split_names(value):
    if not value:
        return set()
    out = set()
    for chunk in str(value).replace(";", ",").split(","):
        x = chunk.strip().lower()
        if x:
            out.add(x)
    return out


def collection_visible(collection):
    # Visibility is now based on stable Steam collection_id, not name.
    return not collection_hidden(collection)


def filter_collections(cols):
    return [c for c in cols if collection_visible(c)]


def all_games_source_collections(all_cols, visible_cols):
    # If enabled, All Games follows collection visibility and excludes hidden collection folders.
    # Default TRUE because the user wants All Games except hidden.
    return visible_cols if b("all_games_exclude_hidden", True) else all_cols


def use_owned_games_source():
    # 0 = Steam collections only; 1 = collections + Steam Web API owned games.
    return str(ADDON.getSetting("library_appid_source") or "1") == "1"


def with_owned_uncategorized_collection(cols, force_owned=False):
    """Append a virtual Uncategorized collection from Steam OwnedGames.

    Steam client's Uncategorized bucket is not stored as a normal user-collections.*
    entry in cloud-storage-namespace-1.json. Newly purchased games therefore may
    not appear in Kodi until they are added to a real collection. When the user
    has configured Steam Web API Key + SteamID64, we union OwnedGames into the
    library and expose games not present in Steam collections as a virtual
    Uncategorized collection.
    """
    cols = list(cols or [])
    if not use_owned_games_source():
        return cols
    owned = owned_games_map(force=force_owned)
    if not owned:
        return cols
    in_collections = set()
    for c in cols:
        for appid in c.get("appids", []) or []:
            in_collections.add(str(appid))
    hidden = hidden_appids()
    extra = []
    for appid, data in owned.items():
        appid = str(appid)
        if appid and appid not in in_collections and appid not in hidden:
            extra.append(appid)
    extra.sort(key=lambda a: str((owned.get(a) or {}).get("name") or fallback_title(a)).lower())
    if extra:
        cols.append({
            "id": "__owned_uncategorized__",
            "name": "Uncategorized",
            "appids": extra,
            "virtual": "owned_games"
        })
    return cols


def current_library_appids(force_owned=False):
    cols, _ = sync_collections(force_owned=force_owned)
    return all_appids(cols), cols


def missing_or_partial_appids(appids):
    wanted = [str(a) for a in (appids or []) if str(a)]
    if not wanted:
        return []
    rows = {}
    con = connect()
    cur = con.cursor()
    for start in range(0, len(wanted), 500):
        chunk = wanted[start:start + 500]
        marks = ",".join(["?"] * len(chunk))
        cur.execute("SELECT appid, metadata_status, metadata_source FROM games WHERE appid IN ({})".format(marks), chunk)
        for row in cur.fetchall():
            rows[str(row["appid"])] = dict(row)
    con.close()
    out = []
    for appid in wanted:
        row = rows.get(appid)
        if not row:
            out.append(appid)
            continue
        status = steam_display_or_na(row.get("metadata_status"))
        if status != "ok":
            out.append(appid)
    return out


def scrape_new_library_items(silent=False, force_owned=True, refresh_container=True):
    appids, cols = current_library_appids(force_owned=force_owned)
    missing = missing_or_partial_appids(appids)
    if not missing:
        if not silent:
            xbmcgui.Dialog().notification(ADDON_NAME, "No new Steam games to scrape.", xbmcgui.NOTIFICATION_INFO, 3500)
        if refresh_container:
            xbmc.executebuiltin("Container.Refresh")
        return {"total": 0, "ok": 0, "partial": 0, "fail": 0}

    if b("fetch_steam250_top250", True):
        fetch_steam250_top250(force=False)

    prog = None
    if not silent:
        prog = xbmcgui.DialogProgressBG()
        bg_create(prog)

    rows, ok, partial, fail = [], 0, 0, 0
    total = len(missing)
    for idx, appid in enumerate(missing, 1):
        title = fallback_title(appid)
        try:
            g = scrape(appid, cols)
            save_game(g)
            title = g.get("name") or title
            if g.get("_partial_reason"):
                partial += 1
                rows.append({"appid": appid, "status": "partial", "name": title, "error": g.get("_partial_reason")})
            else:
                ok += 1
                rows.append({"appid": appid, "status": "ok", "name": title, "error": ""})
        except Exception as exc:
            fail += 1
            rows.append({"appid": appid, "status": "failed", "name": title, "error": str(exc)})
        if prog:
            bg_update(prog, int(idx * 100 / max(total, 1)), "NEW GAME {}/{} - {}".format(idx, total, title)[:95])
            xbmc.sleep(150)

    bg_close(prog)
    report = os.path.join(DIAG, "new_games_report.csv")
    try:
        with open(report, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["appid", "status", "name", "error"])
            w.writeheader()
            w.writerows(rows)
    except Exception as exc:
        log("Could not write new games report: {}".format(exc), xbmc.LOGWARNING)

    if not silent:
        xbmcgui.Dialog().notification(ADDON_NAME, "New games scraped: {} ok, {} partial, {} failed".format(ok, partial, fail), xbmcgui.NOTIFICATION_INFO, 6000)
    if refresh_container:
        xbmc.executebuiltin("Container.Refresh")
    return {"total": total, "ok": ok, "partial": partial, "fail": fail}


def refresh_library_and_scrape_new(silent=False):
    return scrape_new_library_items(silent=silent, force_owned=True, refresh_container=True)


_CANONICAL_QUERY_ORDER_0379 = (
    "mode", "collection", "collection_id", "collection_name_for_context",
    "collection_id_for_context", "appid", "column", "art_type"
)


def _ordered_query_pairs_0379(params):
    params = dict(params or {})
    pairs = []
    for key in _CANONICAL_QUERY_ORDER_0379:
        if key in params:
            pairs.append((key, params.pop(key)))
    for key in sorted(params):
        pairs.append((key, params[key]))
    return pairs


def url_for(**kwargs):
    query = urllib.parse.urlencode(_ordered_query_pairs_0379(kwargs))
    return BASE_URL + ("?" + query if query else "")


def _redirect_legacy_listing_path_0379(params):
    """Normalize folder URLs so Kodi uses one ViewModes6 row per listing.

    Older shortcuts may open:
      plugin://plugin.program.steam.library?mode=list&collection=__all__
    while the add-on itself generates:
      plugin://plugin.program.steam.library/?mode=list&collection=__all__

    Kodi persists view/sort settings by the exact path string, so those are
    separate folders. Redirect only browsable root/list requests.
    """
    try:
        mode = str((params or {}).get("mode") or "root")
        if mode not in ("root", "list"):
            return False

        query = urllib.parse.urlencode(_ordered_query_pairs_0379(params))
        canonical = BASE_URL + ("?" + query if query else "")
        current = str(REQUEST_BASE_URL or "") + str(sys.argv[2] or "")

        if current == canonical:
            return False

        xbmc.executebuiltin("Container.Update({},replace)".format(canonical))
        xbmcplugin.endOfDirectory(
            HANDLE,
            succeeded=False,
            updateListing=False,
            cacheToDisc=False
        )
        log("Normalized listing path: {} -> {}".format(current, canonical))
        return True
    except Exception:
        log("Listing path normalization failed:\n{}".format(traceback.format_exc()), xbmc.LOGWARNING)
        return False


def steam_request_headers(url="", extra=None):
    # Steam Store sometimes rejects bare/custom urllib clients with 403.
    # Use browser-like headers and mature-content cookies for appdetails/html/reviews/assets.
    u = str(url or "").lower()
    is_steam = (
        "store.steampowered.com" in u or
        "steamcommunity.com" in u or
        "steamstatic.com" in u or
        "akamai.steamstatic.com" in u or
        "fastly.steamstatic.com" in u
    )
    h = {
        "User-Agent": STEAM_BROWSER_UA if is_steam else UA,
        "Accept": "application/json,text/html,image/avif,image/webp,*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "close",
    }
    if "store.steampowered.com" in u:
        h["Referer"] = "https://store.steampowered.com/"
        h["Cookie"] = "birthtime=568022401; lastagecheckage=1-January-1988; wants_mature_content=1; mature_content=1"
    if extra:
        h.update(extra)
    return h


def http_json(url, timeout=25, headers=None):
    req = urllib.request.Request(url, headers=steam_request_headers(url, headers))
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace"))


def http_text(url, timeout=20, headers=None):
    req = urllib.request.Request(url, headers=steam_request_headers(url, headers))
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="replace")


def url_exists(url, timeout=6):
    if not url or url == NA:
        return False
    try:
        req = urllib.request.Request(url, headers=steam_request_headers(url), method="HEAD")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return 200 <= int(r.status) < 400
    except Exception:
        try:
            req = urllib.request.Request(url, headers=steam_request_headers(url, {"Range": "bytes=0-0"}))
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return 200 <= int(r.status) < 400
        except Exception:
            return False


def cloud_json():
    manual = os.path.expandvars((s("cloud_json_path") or "").strip().strip('"'))
    if manual and os.path.exists(manual):
        return manual
    roots = [os.path.expandvars(r"%ProgramFiles(x86)%\Steam\userdata"), os.path.expandvars(r"%ProgramFiles%\Steam\userdata")]
    found = []
    for root in roots:
        if root and "%" not in root and os.path.isdir(root):
            found += glob.glob(os.path.join(root, "*", "config", "cloudstorage", "cloud-storage-namespace-1.json"))
    found = [(os.path.getmtime(p), p) for p in set(found) if os.path.exists(p)]
    found.sort(reverse=True)
    return found[0][1] if found else ""


def parse_collections(path):
    if not path or not os.path.exists(path):
        return []
    try:
        raw = json.loads(open(path, "r", encoding="utf-8").read())
    except Exception as exc:
        log("Cannot read cloud collections: {}".format(exc), xbmc.LOGWARNING)
        return []
    out = []
    for item in raw:
        if not isinstance(item, list) or len(item) < 2:
            continue
        key, payload = item[0], item[1]
        if not str(key).startswith("user-collections."):
            continue
        try:
            data = json.loads(payload.get("value") or "{}")
        except Exception:
            continue
        name = str(data.get("name") or data.get("id") or key)
        cid = str(data.get("id") or key)
        removed = set(str(x) for x in (data.get("removed") or []))
        appids = [str(x) for x in (data.get("added") or []) if str(x) not in removed]
        if appids:
            out.append({"id": cid, "name": name, "appids": appids})
    return out


def finished_keywords(text):
    t = (text or "").lower()
    return ("finished" in t) or ("completed" in t) or ("complete" in t)


def update_finished_flags(con, cols):
    cur = con.cursor()
    cur.execute("UPDATE games SET finished='0' WHERE appid IS NOT NULL")
    done = set()
    for c in cols:
        if finished_keywords(c.get("name")) or finished_keywords(c.get("id")):
            done.update(str(a) for a in c.get("appids", []))
    for appid in done:
        cur.execute("UPDATE games SET finished='1' WHERE appid=?", (appid,))
    con.commit()


def sync_collections(force_owned=False):
    con = connect()
    cur = con.cursor()
    path = cloud_json()
    cols = parse_collections(path)
    cur.execute("DELETE FROM collections")
    for c in cols:
        for appid in c["appids"]:
            cur.execute("INSERT OR REPLACE INTO collections(collection_id,name,appid) VALUES(?,?,?)", (c["id"], c["name"], appid))
    sync_hidden_games_from_collections(con, cols)
    con.commit()
    update_finished_flags(con, cols)
    con.close()
    cols = with_owned_uncategorized_collection(cols, force_owned=force_owned)
    try:
        update_sortnames_from_owned(all_appids(cols, include_hidden=True), force=False)
    except Exception as exc:
        log("Sync Steam sort names failed: {}".format(exc), xbmc.LOGWARNING)
    return cols, path


def all_appids(cols, include_hidden=False):
    seen, appids = set(), []
    hidden = set() if include_hidden else hidden_appids()
    for c in cols:
        for a in c["appids"]:
            a = str(a)
            if a in hidden:
                continue
            if a not in seen:
                seen.add(a)
                appids.append(a)
    return appids


def finished_for_appid(appid, cols):
    appid = str(appid)
    for c in cols:
        if appid in [str(x) for x in c.get("appids", [])]:
            if finished_keywords(c.get("name")) or finished_keywords(c.get("id")):
                return "1"
    return "0"


def poster(appid):
    return "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{}/library_600x900.jpg".format(appid)


def steam_logo_direct(appid):
    return "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{}/logo.png".format(appid)


def parse_store_logo(html_text, appid):
    if not html_text:
        return ""
    text = html_text.replace("\\/", "/")
    pattern = r'https?://shared\.fastly\.steamstatic\.com/store_item_assets/steam/apps/{}/[^"\']*?logo\.png'.format(re.escape(str(appid)))
    m = re.search(pattern, text, flags=re.I)
    if m:
        return html.unescape(m.group(0))
    return ""


def steam_store_html(appid):
    try:
        return http_text("https://store.steampowered.com/app/{}/".format(appid), timeout=18)
    except Exception as exc:
        log("Store HTML failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return ""


def parse_ratings(html_text, data):
    # Steam rating display is inconsistent by region/app. Keep N/A when no clear rating is present.
    esrb = NA
    pegi = NA
    text = html.unescape(re.sub(r"\s+", " ", html_text or ""))

    m = re.search(r'\bESRB\b[^<]{0,120}\b(E|E10\+|T|M|AO|RP)\b', text, re.I)
    if m:
        esrb = m.group(1).upper()

    m = re.search(r'\bPEGI\b[^0-9]{0,120}\b(3|7|12|16|18)\b', text, re.I)
    if m:
        pegi = m.group(1)

    # required_age is not ESRB/PEGI, but keep as a weak ESRB-style fallback only if no rating block exists.
    req_age = str((data or {}).get("required_age") or "").strip()
    if esrb == NA and req_age and req_age not in ("0", "None"):
        esrb = "{}+".format(req_age)

    return esrb, pegi


def owned_games_map(force=False):
    key, sid = s("steam_api_key"), s("steam_id64")
    if not key or not sid:
        return {}
    try:
        if not force and os.path.exists(OWNED_CACHE_PATH):
            data = json.loads(open(OWNED_CACHE_PATH, "r", encoding="utf-8").read())
            if time.time() - float(data.get("timestamp", 0)) < 86400:
                return {str(g.get("appid")): g for g in data.get("games", []) if g.get("appid")}
    except Exception:
        pass

    try:
        url = "https://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/?key={}&steamid={}&include_appinfo=1&include_extended_appinfo=1&include_played_free_games=1&language=english&format=json".format(
            urllib.parse.quote(key), urllib.parse.quote(sid)
        )
        js = http_json(url, timeout=30)
        games = ((js.get("response") or {}).get("games") or [])
        ensure()
        open(OWNED_CACHE_PATH, "w", encoding="utf-8").write(json.dumps({"timestamp": time.time(), "games": games}, ensure_ascii=False))
        return {str(g.get("appid")): g for g in games if g.get("appid")}
    except Exception as exc:
        log("OwnedGames fallback failed: {}".format(exc), xbmc.LOGWARNING)
        return {}


def steam_library_roots():
    roots = []
    default = os.path.expandvars(r"%ProgramFiles(x86)%\Steam")
    if default and "%" not in default and os.path.isdir(default):
        roots.append(default)
        vdf = os.path.join(default, "steamapps", "libraryfolders.vdf")
        try:
            txt = open(vdf, "r", encoding="utf-8", errors="replace").read()
            for p in re.findall(r'"path"\s+"([^"]+)"', txt):
                p = p.replace("\\\\", "\\")
                if os.path.isdir(p):
                    roots.append(p)
        except Exception:
            pass
    seen = []
    for r in roots:
        if r not in seen:
            seen.append(r)
    return seen


def appmanifest_title(appid):
    appid = str(appid)
    for root in steam_library_roots():
        p = os.path.join(root, "steamapps", "appmanifest_{}.acf".format(appid))
        if os.path.exists(p):
            try:
                txt = open(p, "r", encoding="utf-8", errors="replace").read()
                m = re.search(r'"name"\s+"([^"]+)"', txt)
                if m:
                    return m.group(1).strip()
            except Exception:
                pass
    return ""


def existing_title(appid):
    try:
        con = connect()
        cur = con.cursor()
        cur.execute("SELECT COALESCE(NULLIF(display_name,''), NULLIF(name,''), NULLIF(steam_name,'')) FROM games WHERE appid=?", (str(appid),))
        row = cur.fetchone()
        con.close()
        if row and row[0] and not str(row[0]).startswith("Steam App "):
            return str(row[0]).strip()
    except Exception:
        pass
    return ""


def steamcommunity_title(appid):
    try:
        html_text = http_text("https://steamcommunity.com/app/{}".format(appid), timeout=20)
        m = re.search(r"<title>\s*Steam Community\s*::\s*(.*?)\s*</title>", html_text, re.I | re.S)
        if m:
            title = html.unescape(re.sub(r"\s+", " ", m.group(1))).strip()
            if title and title.lower() not in ("error", "steam community"):
                return title
        m = re.search(r'class=["\']apphub_AppName["\'][^>]*>\s*(.*?)\s*</', html_text, re.I | re.S)
        if m:
            title = html.unescape(re.sub(r"<[^>]+>", "", m.group(1))).strip()
            if title:
                return title
    except Exception as exc:
        log("Steam Community title fallback failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
    return ""


def fallback_title(appid):
    og = owned_games_map(False)
    owned = og.get(str(appid), {})
    return (
        existing_title(appid)
        or nz(owned.get("name"), "")
        or appmanifest_title(appid)
        or steamcommunity_title(appid)
        or "Steam App {}".format(appid)
    )


def steam_sortname_for_appid(appid, title=""):
    """Return Steam's official SortAs when available.

    Preferred source is local Steam appcache/appinfo.vdf common.SortAs, with
    OwnedGames extended appinfo as optional fallback depending on setting.
    """
    appid = str(appid)
    sortname = steam_sortname_from_sources(appid)
    if sortname:
        return sortname
    title = steam_display_or_na(title)
    if title != NA:
        return str(title).strip()
    owned = owned_games_map(False).get(appid, {}) or {}
    name = steam_display_or_na(owned.get("name"))
    if name != NA:
        return str(name).strip()
    return fallback_title(appid)

def natural_sort_key(value):
    value = unicodedata.normalize("NFKC", str(value or "")).casefold().strip()
    # Keep Unicode letters/digits (Chinese, Japanese, Korean, etc.) instead of
    # dropping them with an ASCII-only [a-z0-9] filter.
    value = re.sub(r"[^\w]+", " ", value, flags=re.UNICODE).strip()
    parts = re.split(r"(\d+)", value)
    return [int(p) if p.isdigit() else p for p in parts if p != ""]


def library_game_sort_key(g):
    # 0 = Steam/original membership order (caller does not sort)
    # 1 = visible name (SteamEdit display name when available)
    # 2 = SortAs/sortname, falling back to display name then Steam name
    mode = str(ADDON.getSetting("library_game_sort") or "0")
    row = g or {}
    name = _effective_name_0373(row, "")
    sortname = str(row.get("sortname") or "").strip()
    if mode == "0":
        return None
    if mode == "1":
        return natural_sort_key(name)
    return natural_sort_key(_collapse_duplicate_leading_articles_0374(sortname) or name)


def update_sortnames_from_owned(appids=None, force=False):
    # Backward-compatible name kept for older call sites. It now uses the selected
    # Steam sort name source: local appinfo.vdf first, API fallback by default.
    return update_sortnames_from_sources(appids=appids, force=force)



def sortname_source_mode():
    # 0 = Auto: appinfo.vdf first, OwnedGames API fallback
    # 1 = Local appinfo.vdf only
    # 2 = OwnedGames API only
    return str(ADDON.getSetting("sortname_source") or "0")


def steam_registry_paths():
    paths = []
    if sys.platform.startswith("win"):
        try:
            import winreg
            reg_locations = [
                (winreg.HKEY_CURRENT_USER, r"Software\Valve\Steam"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\Valve\Steam"),
                (winreg.HKEY_LOCAL_MACHINE, r"SOFTWARE\WOW6432Node\Valve\Steam"),
            ]
            for root, key_path in reg_locations:
                try:
                    with winreg.OpenKey(root, key_path) as key:
                        for value_name in ("SteamPath", "InstallPath"):
                            try:
                                value, _ = winreg.QueryValueEx(key, value_name)
                                if value and os.path.isdir(value):
                                    paths.append(value)
                            except Exception:
                                pass
                except Exception:
                    pass
        except Exception:
            pass
    return paths


def steam_roots_from_cloud_path():
    paths = []
    cloud = s("cloud_json_path")
    if cloud and os.path.exists(cloud):
        cur = os.path.abspath(os.path.dirname(cloud))
        for _ in range(10):
            if os.path.exists(os.path.join(cur, "appcache", "appinfo.vdf")):
                paths.append(cur)
                break
            parent = os.path.dirname(cur)
            if parent == cur:
                break
            cur = parent
    return paths


def steam_appinfo_candidates():
    manual = s("steam_appinfo_path")
    candidates = []
    if manual:
        candidates.append(manual)
    roots = []
    roots.extend(steam_registry_paths())
    roots.extend(steam_roots_from_cloud_path())
    for env in (r"%ProgramFiles(x86)%\Steam", r"%ProgramFiles%\Steam"):
        path = os.path.expandvars(env)
        if path and "%" not in path:
            roots.append(path)
    for root in roots:
        if root:
            candidates.append(os.path.join(root, "appcache", "appinfo.vdf"))
    seen = []
    for c in candidates:
        c = os.path.abspath(os.path.expandvars(str(c).replace('"', '').strip()))
        if c not in seen:
            seen.append(c)
    return seen


def resolve_steam_appinfo_path():
    for p in steam_appinfo_candidates():
        if p and os.path.exists(p) and os.path.isfile(p):
            return p
    return ""


def _u32(data, pos):
    if pos + 4 > len(data):
        raise EOFError("u32 eof")
    return struct.unpack_from("<I", data, pos)[0], pos + 4


def _i64(data, pos):
    if pos + 8 > len(data):
        raise EOFError("i64 eof")
    return struct.unpack_from("<q", data, pos)[0], pos + 8


def _read_cstr(data, pos, limit=None):
    end_limit = len(data) if limit is None else min(len(data), int(limit))
    end = data.find(b"\x00", pos, end_limit)
    if end < 0:
        raise EOFError("cstr eof")
    raw = data[pos:end]
    try:
        return raw.decode("utf-8", "replace"), end + 1
    except Exception:
        return raw.decode("latin-1", "replace"), end + 1


def _read_bkv_string(data, pos, end, string_table):
    # AppInfo v41 deduplicates key names and string values through a string table.
    # Older versions store null-terminated UTF-8 strings inline.
    if string_table is not None and pos + 4 <= end:
        idx, pos2 = _u32(data, pos)
        if 0 <= idx < len(string_table):
            return string_table[idx], pos2
    return _read_cstr(data, pos, end)


def _skip_bkv_wstring(data, pos, end):
    while pos + 1 < end:
        if data[pos] == 0 and data[pos + 1] == 0:
            return pos + 2
        pos += 2
    return end


def _parse_bkv_find_sortas(data, pos, end, string_table=None, depth=0):
    safety = 0
    while pos < end and safety < 200000:
        safety += 1
        t = data[pos]
        pos += 1
        if t == 8:  # end object
            return "", pos
        try:
            key, pos = _read_bkv_string(data, pos, end, string_table)
        except Exception:
            return "", end
        key_l = str(key or "").lower()
        if t == 0:  # child object
            value, pos = _parse_bkv_find_sortas(data, pos, end, string_table, depth + 1)
            if value:
                return value, pos
        elif t == 1:  # string
            try:
                value, pos = _read_bkv_string(data, pos, end, string_table)
            except Exception:
                return "", end
            if key_l in ("sortas", "sort_as", "sortname", "sort_name"):
                value = str(value or "").strip()
                if value:
                    return value, pos
        elif t == 2:
            pos += 4
        elif t == 3:
            pos += 4
        elif t in (4, 6):
            pos += 4
        elif t == 5:
            pos = _skip_bkv_wstring(data, pos, end)
        elif t == 7:
            pos += 8
        else:
            return "", end
    return "", pos


def _parse_bkv_find_fields(data, pos, end, string_table=None, depth=0):
    """Best-effort Binary VDF scanner for common.name and common.SortAs.

    This intentionally keeps the first name-like value encountered and the first
    SortAs value encountered while walking the appinfo blob. In Steam appinfo,
    common.name and common.SortAs are encountered before lower-priority nested
    metadata, which matches SteamEdit's appinfo view for normal games.
    """
    found = {}
    safety = 0
    while pos < end and safety < 250000:
        safety += 1
        t = data[pos]
        pos += 1
        if t == 8:  # end object
            return found, pos
        try:
            key, pos = _read_bkv_string(data, pos, end, string_table)
        except Exception:
            return found, end
        key_l = str(key or "").lower()
        if t == 0:  # child object
            child, pos = _parse_bkv_find_fields(data, pos, end, string_table, depth + 1)
            for k, v in child.items():
                if v and k not in found:
                    found[k] = v
        elif t == 1:  # string
            try:
                value, pos = _read_bkv_string(data, pos, end, string_table)
            except Exception:
                return found, end
            value = str(value or "").strip()
            if value:
                if key_l == "name" and "name" not in found:
                    found["name"] = value
                elif key_l in ("sortas", "sort_as", "sortname", "sort_name") and "sortname" not in found:
                    found["sortname"] = value
                elif key_l in ("type", "apptype", "app_type") and "app_type" not in found:
                    found["app_type"] = value
        elif t == 2:
            pos += 4
        elif t == 3:
            pos += 4
        elif t in (4, 6):
            pos += 4
        elif t == 5:
            pos = _skip_bkv_wstring(data, pos, end)
        elif t == 7:
            pos += 8
        else:
            return found, end
    return found, pos


def _bruteforce_string_after_key(blob, key, max_len=220):
    try:
        key_b = key.lower().encode("utf-8") + b"\x00"
        i = blob.lower().find(key_b)
        if i >= 0:
            start = i + len(key_b)
            val, _ = _read_cstr(blob, start, min(len(blob), start + max_len))
            val = str(val or "").strip()
            if val and 1 < len(val) <= max_len:
                return val
    except Exception:
        pass
    return ""


def _bruteforce_sortas_from_blob(blob):
    try:
        i = blob.lower().find(b"sortas\x00")
        if i >= 0:
            start = i + len(b"sortas\x00")
            val, _ = _read_cstr(blob, start, min(len(blob), start + 256))
            val = str(val or "").strip()
            if val and 1 < len(val) <= 160:
                return val
    except Exception:
        pass
    return ""


def parse_appinfo_vdf_metadata(path, appids=None):
    """Return {appid: {name, sortname}} from local Steam appcache/appinfo.vdf.

    Uses the same app entry boundary calculation as the working SortAs parser:
    each entry contains appid, size, then a fixed appinfo header followed by the
    binary VDF blob. SteamEdit edits common.name/common.SortAs in that blob, so
    reading both fields here keeps Kodi aligned with SteamEdit after Save & Apply.
    """
    wanted = set(str(a) for a in appids) if appids else None
    out = {}
    if not path or not os.path.exists(path):
        return out
    data = open(path, "rb").read()
    pos = 0
    magic, pos = _u32(data, pos)
    version = magic & 0xFF
    magic_prefix = magic >> 8
    if magic_prefix != 0x075644 or version < 39 or version > 41:
        raise ValueError("Unsupported appinfo.vdf magic/version: 0x{:08X}".format(magic))
    _, pos = _u32(data, pos)  # universe
    string_table = None
    if version >= 41:
        string_table_offset, pos = _i64(data, pos)
        saved_pos = pos
        if 0 < string_table_offset < len(data):
            try:
                st_pos = int(string_table_offset)
                count, st_pos = _u32(data, st_pos)
                if count < 2000000:
                    arr = []
                    for _ in range(int(count)):
                        val, st_pos = _read_cstr(data, st_pos, len(data))
                        arr.append(val)
                    string_table = arr
            except Exception:
                string_table = None
        pos = saved_pos

    while pos + 4 <= len(data):
        appid, pos = _u32(data, pos)
        if appid == 0:
            break
        if pos + 4 > len(data):
            break
        size, pos = _u32(data, pos)
        end = pos + int(size)
        if end > len(data) or end <= pos:
            break

        # Same fixed header skip as parse_appinfo_vdf_sortnames().
        data_start = pos + 4 + 4 + 8 + 20 + 4
        if version >= 40:
            data_start += 20

        appid_s = str(appid)
        if wanted is None or appid_s in wanted:
            fields = {}
            if data_start < end:
                try:
                    fields, _ = _parse_bkv_find_fields(data, data_start, end, string_table)
                except Exception:
                    fields = {}
                blob = data[data_start:end]
                if not fields.get("name"):
                    n = _bruteforce_string_after_key(blob, "name")
                    if n:
                        fields["name"] = n
                if not fields.get("sortname"):
                    sn = _bruteforce_sortas_from_blob(blob)
                    if sn:
                        fields["sortname"] = sn

            name = steam_display_or_na(fields.get("name"))
            sortname = steam_display_or_na(fields.get("sortname"))
            rec = {}
            if name != NA:
                rec["name"] = str(name).strip()
            if sortname != NA:
                rec["sortname"] = str(sortname).strip()
            app_type = steam_display_or_na(fields.get("app_type"))
            if app_type != NA:
                rec["app_type"] = str(app_type).strip().lower()
            if rec:
                out[appid_s] = rec
                if wanted is not None and len(out) >= len(wanted):
                    break
        pos = end
    return out

def parse_appinfo_vdf_sortnames(path, appids=None):
    wanted = set(str(a) for a in appids) if appids else None
    out = {}
    if not path or not os.path.exists(path):
        return out
    data = open(path, "rb").read()
    pos = 0
    magic, pos = _u32(data, pos)
    version = magic & 0xFF
    magic_prefix = magic >> 8
    if magic_prefix != 0x075644 or version < 39 or version > 41:
        raise ValueError("Unsupported appinfo.vdf magic/version: 0x{:08X}".format(magic))
    _, pos = _u32(data, pos)  # universe
    string_table = None
    if version >= 41:
        string_table_offset, pos = _i64(data, pos)
        saved_pos = pos
        if 0 < string_table_offset < len(data):
            st_pos = int(string_table_offset)
            count, st_pos = _u32(data, st_pos)
            if count < 2000000:
                arr = []
                for _ in range(int(count)):
                    val, st_pos = _read_cstr(data, st_pos, len(data))
                    arr.append(val)
                string_table = arr
        pos = saved_pos

    while pos + 4 <= len(data):
        appid, pos = _u32(data, pos)
        if appid == 0:
            break
        if pos + 4 > len(data):
            break
        size, pos = _u32(data, pos)
        end = pos + int(size)
        if end > len(data) or end <= pos:
            break
        data_start = pos + 4 + 4 + 8 + 20 + 4
        if version >= 40:
            data_start += 20
        appid_s = str(appid)
        if wanted is None or appid_s in wanted:
            sortname = ""
            if data_start < end:
                try:
                    sortname, _ = _parse_bkv_find_sortas(data, data_start, end, string_table)
                except Exception:
                    sortname = ""
                if not sortname:
                    sortname = _bruteforce_sortas_from_blob(data[data_start:end])
            sortname = steam_display_or_na(sortname)
            if sortname != NA:
                out[appid_s] = str(sortname).strip()
                if wanted is not None and len(out) >= len(wanted):
                    break
        pos = end
    return out


def appinfo_sortname_map(appids=None, force=False):
    if sortname_source_mode() == "2":
        return {}
    path = resolve_steam_appinfo_path()
    if not path:
        return {}
    wanted = set(str(a) for a in appids) if appids else None
    try:
        stat = os.stat(path)
        sig = {"path": path, "mtime": int(stat.st_mtime), "size": int(stat.st_size)}
    except Exception:
        return {}
    cache = {"sortnames": {}, "scanned": []}
    try:
        if not force and os.path.exists(APPINFO_SORT_CACHE_PATH):
            old = json.loads(open(APPINFO_SORT_CACHE_PATH, "r", encoding="utf-8").read())
            if old.get("path") == sig["path"] and int(old.get("mtime", 0)) == sig["mtime"] and int(old.get("size", 0)) == sig["size"]:
                cache = old
                data = {str(k): str(v) for k, v in (old.get("sortnames") or {}).items() if v}
                scanned = set(str(x) for x in (old.get("scanned") or []))
                if wanted is None:
                    return data
                if wanted.issubset(scanned):
                    return {a: data[a] for a in wanted if a in data}
    except Exception:
        cache = {"sortnames": {}, "scanned": []}
    try:
        existing = {str(k): str(v) for k, v in (cache.get("sortnames") or {}).items() if v}
        scanned = set(str(x) for x in (cache.get("scanned") or []))
        missing = None
        if wanted is not None and not force:
            missing = [a for a in wanted if a not in scanned]
            if not missing:
                return {a: existing[a] for a in wanted if a in existing}
        requested = missing if missing is not None else appids
        parsed = parse_appinfo_vdf_sortnames(path, appids=requested)
        merged = dict(existing)
        merged.update(parsed)
        if requested is None:
            scanned = set(merged.keys())
        else:
            scanned.update(str(a) for a in requested)
        ensure()
        payload = dict(sig)
        payload["timestamp"] = time.time()
        payload["sortnames"] = merged
        payload["scanned"] = sorted(scanned)
        open(APPINFO_SORT_CACHE_PATH, "w", encoding="utf-8").write(json.dumps(payload, ensure_ascii=False))
        if wanted is not None:
            return {a: merged[a] for a in wanted if a in merged}
        return merged
    except Exception as exc:
        log("Local appinfo.vdf SortAs parse failed: {}".format(exc), xbmc.LOGWARNING)
        return {}


def appinfo_metadata_map(appids=None, force=False):
    """Return local appinfo metadata keyed by appid: {name, sortname}.

    This intentionally bypasses the old sortname-only cache when force=True so
    SteamEdit changes made via Save & Apply are reflected immediately.
    """
    if sortname_source_mode() == "2":
        return {}
    path = resolve_steam_appinfo_path()
    if not path:
        return {}
    try:
        return parse_appinfo_vdf_metadata(path, appids=appids)
    except Exception as exc:
        log("Local appinfo.vdf metadata parse failed: {}".format(exc), xbmc.LOGWARNING)
        return {}


def steam_sortname_from_owned(appid):
    owned = owned_games_map(False).get(str(appid), {}) or {}
    sortname = owned.get("sort_as") or owned.get("sortas") or owned.get("sortname") or owned.get("sort_name")
    sortname = steam_display_or_na(sortname)
    return str(sortname).strip() if sortname != NA else ""


def steam_sortname_from_sources(appid):
    appid = str(appid)
    mode = sortname_source_mode()
    if mode in ("0", "1"):
        local = appinfo_sortname_map([appid]).get(appid, "")
        if local:
            return local
    if mode in ("0", "2"):
        api = steam_sortname_from_owned(appid)
        if api:
            return api
    return ""


def update_sortnames_from_sources(appids=None, force=False, write_report=True):
    """Refresh Steam/API names while preserving durable SteamEdit overrides.

    Local appinfo is considered a confirmed SteamEdit override only when it differs
    from Steam's API title. If Steam has reset appinfo back to the original title,
    the last confirmed SteamEdit value remains active. v0.3.73 report history is
    consulted once to recover names it may already have overwritten.
    """
    wanted = [str(a) for a in appids] if appids else None
    mode = sortname_source_mode()
    local_meta = appinfo_metadata_map(wanted, force=force) if mode in ("0", "1") else {}
    owned = owned_games_map(force=force) if mode in ("0", "2") else {}
    appid_iter = wanted or sorted(set(list(local_meta.keys()) + [str(k) for k in owned.keys()]))
    history = _steam_name_history_0374()

    ensure()
    report_path = os.path.join(DIAG, "steam_names_report.csv")
    legacy_report_path = os.path.join(DIAG, "steam_sortname_report.csv")
    timestamp = time.strftime("%Y-%m-%d %H:%M:%S")
    rows_report = []
    stats = {"processed": 0, "found": 0, "changed": 0, "unchanged": 0,
             "missing": 0, "updated_rows": 0, "name_changed": 0,
             "sortname_changed": 0, "history_recovered": 0}
    try:
        con = connect()
        cur = con.cursor()
        for appid in appid_iter:
            appid = str(appid)
            stats["processed"] += 1
            local_rec = local_meta.get(appid, {}) or {}
            owned_rec = owned.get(appid, {}) or {}
            local_name = str(local_rec.get("name") or "").strip()
            local_sort = str(local_rec.get("sortname") or "").strip()
            api_name = str(owned_rec.get("name") or owned_rec.get("title") or "").strip()
            api_sort = str(owned_rec.get("sort_as") or owned_rec.get("sortas") or owned_rec.get("sortname") or owned_rec.get("sort_name") or "").strip()
            source_parts = []
            if local_name or local_sort:
                source_parts.append("appinfo.vdf")
            if api_name or api_sort:
                source_parts.append("owned_games_api")

            cur.execute("SELECT name, steam_name, display_name, steamedit_name, sortname, steamedit_sortname FROM games WHERE appid=?", (appid,))
            row = cur.fetchone()
            old_name = str(row[0] if row and row[0] is not None else "")
            old_steam = str(row[1] if row and row[1] is not None else "")
            old_display = str(row[2] if row and row[2] is not None else "")
            stored_edit = str(row[3] if row and row[3] is not None else "")
            old_sort = str(row[4] if row and row[4] is not None else "")
            stored_edit_sort = str(row[5] if row and row[5] is not None else "")

            new_steam = api_name or old_steam or old_name
            local_name_custom = bool(local_name and (not api_name or not _same_name_0374(local_name, api_name)))
            legacy_custom = old_display if old_display and new_steam and not _same_name_0374(old_display, new_steam) else ""
            history_name = str((history.get(appid) or {}).get("name") or "").strip()
            history_custom = history_name if history_name and new_steam and not _same_name_0374(history_name, new_steam) else ""

            if local_name_custom:
                new_edit = local_name
            elif stored_edit:
                new_edit = stored_edit
            elif legacy_custom:
                new_edit = legacy_custom
            elif history_custom:
                new_edit = history_custom
                stats["history_recovered"] += 1
            else:
                new_edit = ""
            new_display = new_edit or local_name or old_display or old_name or new_steam

            local_sort_custom = bool(local_sort and (local_name_custom or not _same_name_0374(local_sort, local_name or api_name)))
            legacy_sort_custom = old_sort if old_sort and not _same_name_0374(old_sort, old_display or new_steam) else ""
            history_sort = str((history.get(appid) or {}).get("sortname") or "").strip()
            if local_sort_custom:
                new_edit_sort = local_sort
            elif stored_edit_sort:
                new_edit_sort = stored_edit_sort
            elif legacy_sort_custom:
                new_edit_sort = legacy_sort_custom
            elif history_sort:
                new_edit_sort = history_sort
            else:
                new_edit_sort = ""
            new_edit_sort = _collapse_duplicate_leading_articles_0374(new_edit_sort)
            new_sort = _collapse_duplicate_leading_articles_0374(new_edit_sort or local_sort or api_sort or old_sort or new_display or new_steam)

            if not (new_steam or new_display or new_sort):
                stats["missing"] += 1
                rows_report.append([timestamp, appid, old_name, "", old_sort, "", ";".join(source_parts), "missing", "not_found"])
                continue

            mirror_name = new_display or new_steam or old_name
            name_changed = mirror_name != old_name or new_display != old_display or new_steam != old_steam or new_edit != stored_edit
            sort_changed = new_sort != old_sort or new_edit_sort != stored_edit_sort
            stats["found"] += 1
            if name_changed:
                stats["name_changed"] += 1
            if sort_changed:
                stats["sortname_changed"] += 1
            if name_changed or sort_changed:
                stats["changed"] += 1
                action = "changed"
            else:
                stats["unchanged"] += 1
                action = "unchanged"

            cur.execute("UPDATE games SET name=?, steam_name=?, display_name=?, steamedit_name=?, sortname=?, steamedit_sortname=? WHERE appid=?",
                        (mirror_name, new_steam, new_display, new_edit, new_sort, new_edit_sort, appid))
            stats["updated_rows"] += int(cur.rowcount or 0)
            rows_report.append([timestamp, appid, old_name, mirror_name, old_sort, new_sort,
                                ";".join(source_parts), action, "ok"])
        con.commit()
        con.close()
    except Exception as exc:
        log("Update Steam names failed: {}".format(exc), xbmc.LOGWARNING)
        return stats

    if write_report:
        try:
            for path in (report_path, legacy_report_path):
                with open(path, "w", newline="", encoding="utf-8-sig") as fh:
                    writer = csv.writer(fh)
                    writer.writerow(["timestamp", "appid", "old_name", "new_name", "old_sortname", "new_sortname", "source", "action", "status"])
                    writer.writerows(rows_report)
        except Exception as exc:
            log("Could not write Steam names report: {}".format(exc), xbmc.LOGWARNING)
    return stats

def refresh_steam_sortnames(force=True, notify=True):
    cols, _ = sync_collections(force_owned=False)
    appids = all_appids(cols, include_hidden=True)
    stats = update_sortnames_from_sources(appids, force=force, write_report=True)
    if notify:
        xbmcgui.Dialog().notification(ADDON_NAME, "Updated: {}".format(stats.get("changed", 0)), xbmcgui.NOTIFICATION_INFO, 5000)
        xbmc.executebuiltin("Container.Refresh")
    return stats.get("changed", 0)


def sgdb_headers():
    key = s("steamgriddb_api_key")
    return {"Authorization": "Bearer {}".format(key)} if key else {}


def sgdb_game_id(appid):
    headers = sgdb_headers()
    if not headers:
        return ""
    try:
        js = http_json("https://www.steamgriddb.com/api/v2/games/steam/{}".format(appid), timeout=20, headers=headers)
        data = js.get("data") or {}
        return str(data.get("id") or "")
    except Exception as exc:
        log("SGDB game lookup failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return ""


def sgdb_assets(appid, kind, limit=12):
    gid = sgdb_game_id(appid)
    headers = sgdb_headers()
    if not gid or not headers:
        return []
    try:
        js = http_json("https://www.steamgriddb.com/api/v2/{}/game/{}".format(kind, gid), timeout=25, headers=headers)
        arr = js.get("data") or []
        out = []
        for a in arr[:limit]:
            url = a.get("url")
            if not url:
                continue
            out.append({
                "url": url,
                "width": a.get("width") or "",
                "height": a.get("height") or "",
                "source": "SteamGridDB",
                "label": "SteamGridDB {} {}x{}".format(kind, a.get("width") or "", a.get("height") or "").strip()
            })
        return out
    except Exception as exc:
        log("SGDB assets failed {} {}: {}".format(kind, appid, exc), xbmc.LOGWARNING)
        return []


def first_sgdb_asset(appid, kind):
    arr = sgdb_assets(appid, kind, limit=1)
    return arr[0]["url"] if arr else ""


def reviews(appid):
    if not b("fetch_steam_reviews", True):
        return {"steam_review_percent": NA, "steam_review_desc": NA, "steam_review_total": NA}
    try:
        js = http_json("https://store.steampowered.com/appreviews/{}?json=1&language=all&purchase_type=all&num_per_page=0".format(appid), 20)
        q = js.get("query_summary") or {}
        pos, neg = int(q.get("total_positive") or 0), int(q.get("total_negative") or 0)
        total = int(q.get("total_reviews") or pos + neg)
        if total <= 0:
            return {"steam_review_percent": NA, "steam_review_desc": NA, "steam_review_total": NA}
        pct = str(int(round(pos * 100.0 / total)))
        return {
            "steam_review_percent": pct,
            "steam_review_desc": q.get("review_score_desc") or NA,
            "steam_review_total": str(total),
        }
    except Exception as exc:
        log("Reviews failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return {"_review_error": str(exc)}


def parse_steam250_top250(html_text):
    """Parse Steam250 Top 250 page into {appid: {rank, score}}.

    Steam250 does not expose a simple public JSON endpoint on the page, so we
    parse the generated HTML. The app links contain /app/<appid>, and their
    first unique order inside the ranking table is the Top 250 position.
    """
    text = (html_text or "").replace("\\/", "/")
    lower = text.lower()
    start = lower.find("steam top 250 ranking")
    if start < 0:
        start = lower.find("top 250 best steam games")
    if start < 0:
        start = 0
    chunk = text[start:]
    end = chunk.lower().find("welcome to club 250")
    if end > 0:
        chunk = chunk[:end]

    out = {}
    link_re = re.compile(r"""(?ix)
        (?:href\s*=\s*["']?)?
        (?:https?:)?//(?:club\.)?steam250\.com/app/(\d+)
        |
        href\s*=\s*["']?/app/(\d+)
    """)
    for m in link_re.finditer(chunk):
        appid = m.group(1) or m.group(2)
        if not appid or appid in out:
            continue
        out[appid] = {"rank": str(len(out) + 1), "score": NA}
        if len(out) >= 250:
            break
    return out


def read_steam250_cache(max_age=86400):
    if not b("fetch_steam250_top250", True):
        return {}
    try:
        if os.path.exists(STEAM250_CACHE_PATH):
            data = json.loads(open(STEAM250_CACHE_PATH, "r", encoding="utf-8").read())
            if time.time() - float(data.get("timestamp", 0)) <= max_age:
                ranks = data.get("ranks") or {}
                if isinstance(ranks, dict):
                    return {str(k): v for k, v in ranks.items()}
    except Exception as exc:
        log("Steam250 cache read failed: {}".format(exc), xbmc.LOGWARNING)
    return {}


def fetch_steam250_top250(force=False):
    if not b("fetch_steam250_top250", True):
        return {}
    if not force:
        cached = read_steam250_cache(max_age=86400)
        if cached:
            return cached
    try:
        html_text = http_text("https://steam250.com/top250", timeout=30)
        ranks = parse_steam250_top250(html_text)
        if ranks:
            ensure()
            payload = {"timestamp": time.time(), "source": "https://steam250.com/top250", "ranks": ranks}
            open(STEAM250_CACHE_PATH, "w", encoding="utf-8").write(json.dumps(payload, indent=2, ensure_ascii=False))
        return ranks
    except Exception as exc:
        log("Steam250 Top 250 fetch failed: {}".format(exc), xbmc.LOGWARNING)
        return read_steam250_cache(max_age=3650 * 86400)


def steam250_for_appid(appid):
    ranks = read_steam250_cache(max_age=3650 * 86400)
    item = ranks.get(str(appid)) or {}
    return {
        "steam250_rank": steam_display_or_na(item.get("rank")),
        "steam250_score": steam_display_or_na(item.get("score")),
    }


def refresh_steam250_ranks(force=True, notify=True):
    ranks = fetch_steam250_top250(force=force)
    if not ranks:
        if notify:
            xbmcgui.Dialog().notification(ADDON_NAME, "Steam250 Top 250 not available", xbmcgui.NOTIFICATION_WARNING, 5000)
        return 0

    con = connect()
    cur = con.cursor()
    cur.execute("UPDATE games SET steam250_rank=NULL, steam250_score=NULL")
    matched = 0
    for appid, data in ranks.items():
        cur.execute(
            "UPDATE games SET steam250_rank=?, steam250_score=? WHERE appid=?",
            (steam_display_or_na(data.get("rank")), steam_display_or_na(data.get("score")), str(appid))
        )
        matched += int(cur.rowcount or 0)
    con.commit()
    con.close()

    if notify:
        xbmcgui.Dialog().notification(ADDON_NAME, "Steam250 ranks updated: {} library matches".format(matched), xbmcgui.NOTIFICATION_INFO, 5000)
        xbmc.executebuiltin("Container.Refresh")
    return matched


def achievements(appid):
    if not b("fetch_achievements", True):
        return {"achievement_unlocked": NA, "achievement_total": NA, "completed": NA}
    key, sid = s("steam_api_key"), s("steam_id64")
    if not key or not sid:
        return {"achievement_unlocked": NA, "achievement_total": NA, "completed": NA}
    try:
        url = "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v0001/?appid={}&key={}&steamid={}&l=en".format(
            urllib.parse.quote(str(appid)), urllib.parse.quote(key), urllib.parse.quote(sid)
        )
        js = http_json(url, 20)
        arr = ((js.get("playerstats") or {}).get("achievements") or [])
        total = len(arr)
        if total <= 0:
            return {"achievement_unlocked": NA, "achievement_total": NA, "completed": NA}
        unlocked = sum(1 for a in arr if int(a.get("achieved") or 0) == 1)
        return {
            "achievement_unlocked": str(unlocked),
            "achievement_total": str(total),
            "completed": "1" if unlocked == total else "0",
        }
    except Exception as exc:
        log("Achievements failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return {"_achievement_error": str(exc)}


def unique_urls(urls):
    out, seen = [], set()
    for u in urls:
        u = art_or_empty(u)
        if u and u not in seen:
            seen.add(u)
            out.append(u)
    return out


def auto_art(appid, data=None, store_html_text=""):
    data = data or {}
    appid = str(appid)

    header = data.get("header_image") or ""
    thumb = header or data.get("capsule_image") or NA

    steam_poster = poster(appid)
    poster_url = steam_poster
    # SGDB grids only if Steam poster is proven missing.
    if not url_exists(steam_poster, timeout=4):
        poster_url = first_sgdb_asset(appid, "grids") or NA

    shots = [x.get("path_full") for x in (data.get("screenshots") or []) if x.get("path_full")]
    # Auto fanart: Steam screenshots 1-5 only.
    fan_candidates = unique_urls(shots)
    fan_slots = fan_candidates[:5]
    while len(fan_slots) < 5:
        fan_slots.append(NA)

    logo = parse_store_logo(store_html_text, appid)
    if not logo:
        direct = steam_logo_direct(appid)
        logo = direct if url_exists(direct, timeout=4) else ""
    if not logo:
        logo = first_sgdb_asset(appid, "logos") or NA

    return {
        "poster_url": nz(poster_url),
        "thumb_url": nz(thumb),
        "clearlogo_url": nz(logo),
        "fanart_url": nz(fan_slots[0]),
        "fanart1_url": nz(fan_slots[1]),
        "fanart2_url": nz(fan_slots[2]),
        "fanart3_url": nz(fan_slots[3]),
        "fanart4_url": nz(fan_slots[4]),
    }


def partial_game(appid, reason, cols=None):
    title = fallback_title(appid)
    g = {k: None for k, _ in DESIRED_GAME_COLUMNS}
    g.update({
        "appid": str(appid),
        "name": title,
        "steam_name": title,
        "display_name": title,
        "sortname": steam_sortname_for_appid(appid, title),
        "app_type": NA,
        "year": NA,
        "developer": NA,
        "publisher": NA,
        "genres": NA,
        "tagline": NA,
        "short_description": NA,
        "steam_review_percent": NA,
        "steam_review_desc": NA,
        "steam_review_total": NA,
        "steam250_rank": NA,
        "steam250_score": NA,
        "achievement_unlocked": NA,
        "achievement_total": NA,
        "completed": NA,
        "finished": finished_for_appid(appid, cols or []),
        "metacritic_score": NA,
        "esrb": NA,
        "pegi": NA,
        "poster_url": poster(appid),
        "thumb_url": NA,
        "clearlogo_url": NA,
        "fanart_url": NA,
        "fanart1_url": NA,
        "fanart2_url": NA,
        "fanart3_url": NA,
        "fanart4_url": NA,
        "metadata_status": "partial_title_only",
        "metadata_source": "steamcommunity_or_ownedgames",
        "last_scraped": int(time.time()),
        "_partial_reason": reason,
    })
    return g


def scrape(appid, cols=None):
    cols = cols or []
    try:
        js = http_json("https://store.steampowered.com/api/appdetails?appids={}&cc=US&l=english&v=1".format(appid), 30)
    except Exception as exc:
        # Do not leave DB empty just because Steam Store temporarily blocks appdetails.
        # Save a partial title row from OwnedGames/appmanifest/community and retry later.
        return partial_game(appid, "appdetails_request_failed: {}".format(exc), cols)

    app = js.get(str(appid), {})
    if not app.get("success"):
        return partial_game(appid, "appdetails_success_false", cols)

    d = app.get("data") or {}
    release = ((d.get("release_date") or {}).get("date") or "")
    year = ""
    for t in release.replace(",", " ").split():
        if t.isdigit() and len(t) == 4:
            year = t
            break

    store_html_text = steam_store_html(appid)
    esrb, pegi = parse_ratings(store_html_text, d)
    art = auto_art(appid, d, store_html_text)

    g = {k: None for k, _ in DESIRED_GAME_COLUMNS}
    g.update({
        "appid": str(appid),
        "name": nz(d.get("name"), fallback_title(appid)),
        "steam_name": nz(d.get("name"), fallback_title(appid)),
        "display_name": nz(d.get("name"), fallback_title(appid)),
        "sortname": steam_sortname_for_appid(appid, nz(d.get("name"), fallback_title(appid))),
        "app_type": nz(d.get("type")),
        "year": nz(year),
        "developer": nz(first_credit(" / ".join(d.get("developers") or []))),
        "publisher": nz(first_credit(" / ".join(d.get("publishers") or []))),
        "genres": nz(" / ".join([x.get("description", "") for x in (d.get("genres") or []) if x.get("description")])),
        "tagline": NA,
        "short_description": nz(d.get("short_description")),
        "steam_review_percent": "",
        "steam_review_desc": "",
        "steam_review_total": "",
        "steam250_rank": "",
        "steam250_score": "",
        "achievement_unlocked": "",
        "achievement_total": "",
        "completed": "",
        "finished": finished_for_appid(appid, cols),
        "metacritic_score": nz((d.get("metacritic") or {}).get("score")),
        "esrb": nz(esrb),
        "pegi": nz(pegi),
        "metadata_status": "ok",
        "metadata_source": "steam_appdetails",
        "last_scraped": int(time.time()),
    })
    g.update(art)

    rv = reviews(appid)
    if "_review_error" not in rv:
        g.update(rv)

    st250 = steam250_for_appid(appid)
    if st250.get("steam250_rank") != NA:
        g.update(st250)

    ach = achievements(appid)
    if "_achievement_error" not in ach:
        g.update(ach)

    return g


def save_game(g):
    # Hidden games remain cached for the optional Hidden Games folder and fast unhide.
    cols = [k for k, _ in DESIRED_GAME_COLUMNS]
    con = connect()
    cur = con.cursor()

    # Tagline is a user-editable/local column. Steam appdetails does not provide a
    # separate short tagline, so a metadata refresh must not wipe values the user
    # has already written directly into steam_library.db.
    if g and g.get("appid") and "tagline" in cols:
        try:
            cur.execute("SELECT tagline FROM games WHERE appid=?", (str(g.get("appid")),))
            old = cur.fetchone()
            old_tagline = old["tagline"] if old and "tagline" in old.keys() else None
            incoming = steam_display_or_na(g.get("tagline"))
            existing = steam_display_or_na(old_tagline)
            if incoming == NA and existing != NA:
                g["tagline"] = old_tagline
        except Exception as exc:
            log("Could not preserve tagline for {}: {}".format(g.get("appid"), exc), xbmc.LOGWARNING)

    if g and g.get("appid") and "display_name" in cols:
        try:
            cur.execute("SELECT name, steam_name, display_name, steamedit_name, sortname, steamedit_sortname FROM games WHERE appid=?", (str(g.get("appid")),))
            old = cur.fetchone()
            incoming_steam = steam_display_or_na(g.get("steam_name") or g.get("name"))
            if incoming_steam != NA:
                g["steam_name"] = str(incoming_steam).strip()
            if old:
                old_display = steam_display_or_na(old["display_name"] if "display_name" in old.keys() else old["name"])
                old_edit = steam_display_or_na(old["steamedit_name"] if "steamedit_name" in old.keys() else "")
                old_sort = steam_display_or_na(old["sortname"] if "sortname" in old.keys() else "")
                old_edit_sort = steam_display_or_na(old["steamedit_sortname"] if "steamedit_sortname" in old.keys() else "")
                # Metadata scraping must not overwrite SteamEdit/local display names or
                # a user-authored SortAs. Name refresh owns those fields.
                if old_display != NA:
                    g["display_name"] = old["display_name"] or old["name"]
                    g["name"] = g["display_name"]
                else:
                    g["display_name"] = g.get("display_name") or g.get("name") or g.get("steam_name")
                    g["name"] = g["display_name"]
                if old_edit != NA:
                    g["steamedit_name"] = old["steamedit_name"]
                if old_sort != NA:
                    g["sortname"] = old["sortname"]
                if old_edit_sort != NA:
                    g["steamedit_sortname"] = old["steamedit_sortname"]
            else:
                g["display_name"] = g.get("display_name") or g.get("name") or g.get("steam_name")
                g["name"] = g["display_name"]
        except Exception as exc:
            log("Could not preserve SteamEdit name for {}: {}".format(g.get("appid"), exc), xbmc.LOGWARNING)

    if g and g.get("appid") and "sortname" in cols:
        try:
            cur.execute("SELECT sortname FROM games WHERE appid=?", (str(g.get("appid")),))
            old = cur.fetchone()
            old_sortname = old["sortname"] if old and "sortname" in old.keys() else None
            incoming = steam_display_or_na(g.get("sortname"))
            existing = steam_display_or_na(old_sortname)
            if incoming == NA and existing != NA:
                g["sortname"] = old_sortname
        except Exception as exc:
            log("Could not preserve sortname for {}: {}".format(g.get("appid"), exc), xbmc.LOGWARNING)

    if g and g.get("appid") and "playtime_forever" in cols:
        try:
            cur.execute("SELECT playtime_forever FROM games WHERE appid=?", (str(g.get("appid")),))
            old = cur.fetchone()
            old_playtime = old["playtime_forever"] if old and "playtime_forever" in old.keys() else None
            if g.get("playtime_forever") in (None, "", NA) and old_playtime is not None:
                g["playtime_forever"] = old_playtime
        except Exception as exc:
            log("Could not preserve playtime for {}: {}".format(g.get("appid"), exc), xbmc.LOGWARNING)

    # Artwork columns are treated as local cached choices. If the database already
    # has an artwork URL, metadata refresh must skip that column. The Select Artwork
    # menu still overwrites the selected column because it updates the DB directly.
    # Reset all artwork to auto also still works because it updates the artwork
    # columns directly from auto_art().
    if g and g.get("appid"):
        artwork_cols = [
            "poster_url", "thumb_url", "clearlogo_url",
            "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url",
        ]
        try:
            wanted = [c for c in artwork_cols if c in cols]
            if wanted:
                cur.execute("SELECT {} FROM games WHERE appid=?".format(",".join(wanted)), (str(g.get("appid")),))
                old = cur.fetchone()
                if old:
                    for c in wanted:
                        existing = steam_display_or_na(old[c])
                        if existing != NA:
                            g[c] = old[c]
        except Exception as exc:
            log("Could not preserve artwork for {}: {}".format(g.get("appid"), exc), xbmc.LOGWARNING)

    data = {}
    for k in cols:
        data[k] = g.get(k)
    placeholders = ",".join([":" + k for k in cols])
    cur.execute(
        "INSERT OR REPLACE INTO games({}) VALUES({})".format(",".join(cols), placeholders),
        data,
    )
    con.commit()
    con.close()


def get_game(appid, force=False, cols=None):
    if is_hidden_game(appid):
        return partial_game(appid, "hidden_game_skipped", cols or [])
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT * FROM games WHERE appid=?", (str(appid),))
    row = cur.fetchone()
    con.close()
    if row and not force:
        last = row["last_scraped"] or 0
        if int(time.time()) - int(last) < i("cache_days", 30) * 86400:
            return dict(row)
    try:
        g = scrape(appid, cols or [])
        save_game(g)
        return g
    except Exception as exc:
        log("Scrape failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        if row:
            return dict(row)
        return partial_game(appid, "scrape_error_not_saved: {}".format(exc), cols or [])


def cached_games_for_listing(appids, cols=None, include_hidden=False):
    """Fast library listing path: read all visible games from SQLite in bulk.

    This intentionally never scrapes. Missing rows are returned as partial items so
    opening a Steam Library container feels like Movies/TV: local cache only.
    Use Refresh all metadata / Scrape missing metadata for network work.
    """
    cols = cols or []
    ordered = [str(a) for a in (appids or [])]
    hidden = set() if include_hidden else hidden_appids()
    wanted = [a for a in ordered if a not in hidden]
    rows_by_appid = {}

    if wanted:
        con = connect()
        cur = con.cursor()
        # SQLite has a host-parameter limit; 500 keeps the query safely below it.
        for start in range(0, len(wanted), 500):
            chunk = wanted[start:start + 500]
            marks = ",".join(["?"] * len(chunk))
            cur.execute("SELECT * FROM games WHERE appid IN ({})".format(marks), chunk)
            for row in cur.fetchall():
                rows_by_appid[str(row["appid"])] = dict(row)
        con.close()

    out = {}
    for appid in ordered:
        if appid in hidden:
            out[appid] = partial_game(appid, "hidden_game_skipped", cols)
        elif appid in rows_by_appid:
            out[appid] = rows_by_appid[appid]
        else:
            out[appid] = partial_game(appid, "missing_metadata_cache_only", cols)
    return out


def clean_html(text):
    if not text:
        return ""
    text = re.sub(r"<br\s*/?>", "\n", str(text), flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    return html.unescape(text).strip()


def first_credit(value):
    text = str(value or "").strip()
    if not text or text == NA:
        return NA
    parts = re.split(r"\s*/\s*|\s*;\s*|\s*,\s*", text)
    for part in parts:
        part = part.strip()
        if part:
            return part
    return text


def steam_meta_line(g):
    parts = ["STEAM"]

    pct = g.get("steam_review_percent")
    desc = g.get("steam_review_desc")
    if pct and pct != NA:
        review = "{}%".format(pct)
        rank = steam_display_or_na(g.get("steam250_rank"))
        if rank != NA:
            review += " #{}".format(str(rank).lstrip("#"))
        if desc and desc != NA:
            review += " {}".format(desc)
        parts.append(review)

    year = g.get("year")
    if year and year != NA:
        parts.append(str(year))

    age = steam_age_rating_display(g)
    if age != NA:
        parts.append(age)

    return " • ".join(parts)


def steam_detail_line(g):
    parts = []
    dev = first_credit(g.get("developer"))
    pub = first_credit(g.get("publisher"))
    if dev and dev != NA:
        parts.append("DEV {}".format(dev))
    if pub and pub != NA:
        parts.append("PUB {}".format(pub))
    unlocked = g.get("achievement_unlocked")
    total = g.get("achievement_total")
    if total and total != NA:
        parts.append("ACH {}/{}".format(unlocked or "0", total))
    return "   •   ".join(parts)


def steam_tagline_display(g):
    tagline = steam_display_or_na(clean_html(g.get("tagline")))
    if tagline != NA:
        return tagline
    # Safe fallback: existing databases or games without a custom tagline still show
    # something in the AF3 headline row instead of leaving a blank 40px line.
    return steam_display_or_na(g.get("genres"))


def steam_star_rating_10(g):
    try:
        pct = int(float(g.get("steam_review_percent") or 0))
        if pct < 0:
            pct = 0
        if pct > 100:
            pct = 100
        return int(round(pct / 10.0))
    except Exception:
        return 0


def steam_display_or_na(value):
    txt = str(value or "").strip()
    return txt if txt and txt != NA else NA


def steam_rating_display(g):
    pct = steam_display_or_na(g.get("steam_review_percent"))
    rank = steam_display_or_na(g.get("steam250_rank"))
    parts = []
    if pct != NA:
        parts.append("{}%".format(pct))
    if rank != NA:
        rank = str(rank).strip().lstrip("#")
        if rank:
            parts.append("#{}".format(rank))
    return " ".join(parts) if parts else NA


def normalize_age_rating_value(value):
    txt = steam_display_or_na(value)
    if txt == NA:
        return NA

    raw = str(txt).strip()
    upper = raw.upper()

    # Remove provider/presentation prefixes so the UI never shows ESRB/PEGI labels.
    upper = re.sub(r"^\s*(ESRB|PEGI|USK|CERO|GRAC|CLASSIND)\s*[:\-]?\s*", "", upper)
    upper = re.sub(r"^\s*RATING\s*[:\-]?\s*", "", upper)
    upper = upper.strip()

    # ESRB-style tokens normalized to age numbers.
    esrb_map = {
        "EC": "3+",
        "E": "6+",
        "EVERYONE": "6+",
        "E10": "10+",
        "E10+": "10+",
        "EVERYONE 10+": "10+",
        "T": "13+",
        "TEEN": "13+",
        "M": "17+",
        "MATURE": "17+",
        "MATURE 17+": "17+",
        "AO": "18+",
        "ADULTS ONLY": "18+",
        "ADULTS ONLY 18+": "18+",
    }
    if upper in esrb_map:
        return esrb_map[upper]

    if upper in ("RP", "RATING PENDING", "PENDING", "UNRATED", "NR", "N/A", "NA", "NONE", "0"):
        return NA

    # PEGI/required_age numeric values, including values already saved as 17+.
    m = re.search(r"(\d{1,2})\s*\+?", upper)
    if m:
        age = m.group(1)
        if age == "0":
            return NA
        return "{}+".format(age)

    return NA


def steam_age_rating_display(g):
    esrb_age = normalize_age_rating_value(g.get("esrb"))
    pegi_age = normalize_age_rating_value(g.get("pegi"))
    if esrb_age != NA:
        return "Rating {}".format(esrb_age)
    if pegi_age != NA:
        return "Rating {}".format(pegi_age)
    return NA


def steam_achievement_display(g):
    unlocked = steam_display_or_na(g.get("achievement_unlocked"))
    total = steam_display_or_na(g.get("achievement_total"))
    if total != NA:
        return "{}/{}".format("0" if unlocked == NA else unlocked, total)
    return NA



def is_display_value(value):
    txt = str(value or "").strip()
    return bool(txt and txt.upper() not in ("N/A", "NA", "NONE", "NULL", "-"))

def force_poster_view():
    # AF3 includes View_502_Poster_Row, so this is the safest first step before skin XML patching.
    try:
        xbmc.executebuiltin("Container.SetViewMode(502)")
    except Exception as exc:
        log("SetViewMode(502) failed: {}".format(exc), xbmc.LOGWARNING)


def steam_game_status(g):
    completed = str(g.get("completed") or "").strip().lower()
    finished = str(g.get("finished") or "").strip().lower()
    if completed in ("1", "true", "yes", "completed"):
        return "completed"

    # Treat full achievement completion as completed, even if the completed column
    # was not populated yet.
    try:
        unlocked = int(str(g.get("achievement_unlocked") or "").strip())
        total = int(str(g.get("achievement_total") or "").strip())
        if total > 0 and unlocked >= total:
            return "completed"
    except Exception:
        pass

    if finished in ("1", "true", "yes", "finished"):
        return "finished"
    return ""


def make_game_item(g):
    appid = g["appid"]
    title = _effective_name_0373(g, "Steam App {}".format(appid))
    steam_name = str(g.get("steam_name") or g.get("name") or title).strip() or title
    sortname = str(g.get("sortname") or title).strip() or title
    li = xbmcgui.ListItem(label=title)

    plot_text = ""
    if g.get("short_description") and g.get("short_description") != NA:
        plot_text = clean_html(g.get("short_description"))

    detail_line = steam_detail_line(g)
    tagline_text = steam_tagline_display(g)
    tagline_for_ui = "" if tagline_text == NA else tagline_text

    meta_line = steam_meta_line(g)

    try:
        li.setInfo("video", {
            "title": title,
            "originaltitle": steam_name,
            "sorttitle": sortname,
            "plot": plot_text,
            "plotoutline": plot_text,
            "tagline": tagline_for_ui,
            "genre": "" if g.get("genres") == NA else (g.get("genres") or ""),
            "year": int(g["year"]) if str(g.get("year") or "").isdigit() else 0,
            "rating": steam_star_rating_10(g),
            "studio": detail_line or ("" if g.get("developer") == NA else (g.get("developer") or "")),
        })
    except Exception:
        pass

    try:
        li.setLabel2(tagline_for_ui)
    except Exception:
        pass

    poster_art = art_or_empty(g.get("poster_url"))
    steam_thumb_art = art_or_empty(g.get("thumb_url"))
    fanart_art = art_or_empty(g.get("fanart_url"))

    # Keep cinematic fanart for the large focused background, but let AF3 hub/list cards
    # use Steam's wide header/thumb when requested.  Wide card views generally read
    # ListItem.Art(landscape); the focused background still reads ListItem.Art(fanart).
    hub_card_artwork = ADDON.getSetting("hub_card_artwork") or "1"
    landscape_art = (steam_thumb_art or fanart_art or poster_art) if hub_card_artwork == "1" else (fanart_art or steam_thumb_art or poster_art)
    thumb_art = steam_thumb_art or poster_art or fanart_art

    art = {
        "poster": poster_art,
        "thumb": thumb_art,
        "icon": thumb_art,
        "fanart": fanart_art,
        "landscape": landscape_art,
        "clearlogo": art_or_empty(g.get("clearlogo_url")),
    }
    li.setArt({k: v for k, v in art.items() if v})

    for k in ["appid","steam_name","display_name","sortname","steam_review_percent","steam_review_desc","steam_review_total","steam250_rank","steam250_score","achievement_unlocked","achievement_total","completed","finished","year","developer","publisher","genres","tagline","short_description","esrb","pegi","metacritic_score","playtime_forever"]:
        li.setProperty(k, str(g.get(k) or ""))
    li.setProperty("tagline_display", tagline_for_ui)
    li.setProperty("developer_display", steam_display_or_na(first_credit(g.get("developer"))))
    li.setProperty("publisher_display", steam_display_or_na(first_credit(g.get("publisher"))))

    steam_rating = steam_rating_display(g)
    metacritic = steam_display_or_na(g.get("metacritic_score"))
    achievement = steam_achievement_display(g)
    age_rating = steam_age_rating_display(g)

    playtime_display = format_playtime_forever(g.get("playtime_forever"), with_prefix=True)
    li.setProperty("achievement_display", achievement)
    li.setProperty("steam_rating_display", steam_rating)
    li.setProperty("playtime_forever", str(g.get("playtime_forever") or ""))
    li.setProperty("playtime_display", playtime_display)
    li.setProperty("steam250_rank_display", "#{}".format(str(g.get("steam250_rank") or "").lstrip("#")) if steam_display_or_na(g.get("steam250_rank")) != NA else NA)
    li.setProperty("age_rating_display", age_rating)
    li.setProperty("completed_bool", "true" if str(g.get("completed") or "") == "1" else "")
    li.setProperty("finished_bool", "true" if str(g.get("finished") or "") == "1" else "")
    li.setProperty("steam_status_icon", steam_game_status(g))
    for idx, col in enumerate(["fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"], 0):
        li.setProperty("fanart{}".format(idx if idx else ""), art_or_empty(g.get(col)))

    li.setProperty("platform", "steam")
    li.setProperty("steam_platform", "steam")
    # KPM 0.1.82+ reads these neutral game data properties and renders the visual row.
    li.setProperty("kpm_item_type", "game")
    li.setProperty("kpm_data_owner", ADDON_ID)
    li.setProperty("DBTYPE", "game")
    li.setProperty("dbtype", "game")
    li.setProperty("MediaType", "game")
    li.setProperty("mediatype", "game")
    li.setProperty("steam_meta_line", meta_line)
    li.setProperty("steam_detail_line", detail_line)
    li.setProperty("steam_poster_view", "true")
    li.setProperty("is_steam_library", "true")
    li.setProperty("steam_no_video_furniture", "true")
    li.setProperty("program_plugin", ADDON_ID)
    li.setProperty("steam_appid", appid)
    li.addContextMenuItems([
        ("Hide game", "RunPlugin({})".format(url_for(mode="hide_game", appid=appid))),
        ("Refresh game metadata", "RunPlugin({})".format(url_for(mode="refresh", appid=appid))),
        ("Select game artwork", "RunPlugin({})".format(url_for(mode="select_artwork", appid=appid))),
        ("Steam Library tools", "RunPlugin({})".format(url_for(mode="run_tools"))),
    ])
    return li


def add_dir(label, mode, **kwargs):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": "DefaultFolder.png"})
    cm = [
        ("Scan for New Games", "RunPlugin({})".format(url_for(mode="scan_new_games"))),
        ("Steam Library tools", "RunPlugin({})".format(url_for(mode="run_tools"))),
    ]
    cname = kwargs.pop("collection_name_for_context", "")
    cid_ctx = kwargs.pop("collection_id_for_context", "")
    if cname:
        cm.insert(0, ("Hide this collection", "RunPlugin({})".format(url_for(mode="hide_collection", collection_id=cid_ctx, name=cname))))
        if cid_ctx:
            cm.insert(0, ("Rename collection", "RunPlugin({})".format(url_for(mode="rename_collection", collection_id=cid_ctx, name=cname))))
    li.addContextMenuItems(cm)
    params = {"mode": mode}
    params.update(kwargs)
    xbmcplugin.addDirectoryItem(HANDLE, url_for(**params), li, True)


# -----------------------------------------------------------------------------
# v0.3.71 - local-first membership, startup diff sync, playtime and clean
# -----------------------------------------------------------------------------
def _owned_games_fetch_0371(force=True):
    key, sid = s('steam_api_key'), s('steam_id64')
    if not key or not sid:
        return False, {}, 'Steam API key or SteamID64 is not configured'
    if not force:
        try:
            payload = json.loads(open(OWNED_CACHE_PATH, 'r', encoding='utf-8').read())
            games = payload.get('games', [])
            if isinstance(games, list):
                return True, {str(g.get('appid')): g for g in games if g.get('appid')}, 'cache'
        except Exception:
            pass
    try:
        url = 'https://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/?key={}&steamid={}&include_appinfo=1&include_extended_appinfo=1&include_played_free_games=1&language=english&format=json'.format(urllib.parse.quote(key), urllib.parse.quote(sid))
        js = http_json(url, timeout=30)
        response = js.get('response')
        if not isinstance(response, dict) or ('games' not in response and 'game_count' not in response):
            return False, {}, 'Invalid GetOwnedGames response'
        games = response.get('games') or []
        if not isinstance(games, list):
            return False, {}, 'Invalid games payload'
        ensure()
        with open(OWNED_CACHE_PATH, 'w', encoding='utf-8') as fh:
            json.dump({'timestamp': time.time(), 'games': games}, fh, ensure_ascii=False)
        return True, {str(g.get('appid')): g for g in games if g.get('appid')}, 'api'
    except Exception as exc:
        return False, {}, str(exc)


def _cached_collections_0371():
    con = connect()
    rows = con.execute('SELECT c.collection_id,c.name,c.appid FROM collections c JOIN library_membership m ON m.appid=c.appid WHERE m.is_active=1 ORDER BY c.name COLLATE NOCASE, c.rowid').fetchall()
    con.close()
    grouped = {}
    order = []
    for row in rows:
        cid = str(row['collection_id'] or '')
        if cid not in grouped:
            grouped[cid] = {'id': cid, 'name': str(row['name'] or cid), 'appids': []}
            order.append(cid)
        grouped[cid]['appids'].append(str(row['appid']))
    return [grouped[cid] for cid in order]


def _active_appids_0371():
    con = connect()
    rows = con.execute('SELECT appid FROM library_membership WHERE is_active=1 ORDER BY rowid').fetchall()
    con.close()
    return [str(r[0]) for r in rows]


def current_library_appids(force_owned=False):
    return _active_appids_0371(), _cached_collections_0371()


def _sync_report_path_0371(name):
    ensure()
    return os.path.join(REPORTS_DIR, name)


def _scrape_new_appids_0371(appids, cols, silent=False):
    appids = [str(a) for a in appids if str(a)]
    total = len(appids)
    if not total:
        return {'total':0,'ok':0,'partial':0,'fail':0}
    rows=[]; ok_count=partial_count=fail_count=0
    for idx, appid in enumerate(appids, 1):
        title = fallback_title(appid)
        if not silent:
            _notify2_0371('Metadata {0}/{1} • {2}'.format(idx,total,title), 3500)
        try:
            game = scrape(appid, cols)
            # Restore authoritative playtime after scrape/save.
            con=connect(); pr=con.execute('SELECT playtime_forever FROM games WHERE appid=?',(appid,)).fetchone(); con.close()
            if pr and pr[0] is not None:
                game['playtime_forever']=pr[0]
            save_game(game)
            title=game.get('name') or title
            if game.get('_partial_reason'):
                partial_count += 1; status='partial'; err=game.get('_partial_reason')
            else:
                ok_count += 1; status='ok'; err=''
        except Exception as exc:
            fail_count += 1; status='failed'; err=str(exc)
        rows.append({'appid':appid,'status':status,'name':title,'error':err})
    try:
        with open(_sync_report_path_0371('new_games_report.csv'),'w',encoding='utf-8-sig',newline='') as fh:
            writer=csv.DictWriter(fh,fieldnames=['appid','status','name','error']); writer.writeheader(); writer.writerows(rows)
    except Exception: pass
    if not silent:
        _notify2_0371('Metadata complete • {0} added'.format(ok_count + partial_count), 5000)
    return {'total':total,'ok':ok_count,'partial':partial_count,'fail':fail_count}


def sync_library_background_0371(silent=False, scrape_new=True):
    success, owned, source = _owned_games_fetch_0371(force=True)
    if not success:
        log('Ownership sync failed: {}'.format(source), xbmc.LOGWARNING)
        if not silent:
            _notify2_0371('Sync failed • Library unchanged', 5500, xbmcgui.NOTIFICATION_WARNING)
        return {'ok':False,'error':source,'added':0,'removed':0}
    path=cloud_json(); raw_cols=parse_collections(path)
    now=int(time.time())
    con=connect(); cur=con.cursor()
    old_active={str(r[0]) for r in cur.execute('SELECT appid FROM library_membership WHERE is_active=1').fetchall()}
    new_active=set(owned.keys())
    added=sorted(new_active-old_active, key=lambda x: str((owned.get(x) or {}).get('name') or x).lower())
    removed=sorted(old_active-new_active)
    try:
        cur.execute('BEGIN')
        cur.execute('UPDATE library_membership SET is_active=0, removed_at=?, last_sync=? WHERE is_active=1', (now,now))
        for appid,data in owned.items():
            playtime=int(data.get('playtime_forever') or 0)
            name=str(data.get('name') or 'Steam App {}'.format(appid)).strip()
            cur.execute('''INSERT INTO library_membership(appid,is_active,first_seen,last_seen,removed_at,last_sync) VALUES(?,1,?,?,NULL,?)
                           ON CONFLICT(appid) DO UPDATE SET is_active=1,last_seen=excluded.last_seen,removed_at=NULL,last_sync=excluded.last_sync''',(appid,now,now,now))
            cur.execute('''INSERT OR IGNORE INTO games(appid,name,sortname,poster_url,thumb_url,metadata_status,metadata_source,last_scraped,playtime_forever)
                           VALUES(?,?,?,?,?,'new','owned_games',0,?)''',(appid,name,name,poster(appid),'https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{}/header.jpg'.format(appid),playtime))
            cur.execute('UPDATE games SET playtime_forever=?, name=CASE WHEN name IS NULL OR name="" OR name LIKE "Steam App %" THEN ? ELSE name END, sortname=CASE WHEN sortname IS NULL OR sortname="" THEN ? ELSE sortname END WHERE appid=?',(playtime,name,name,appid))
        cur.execute('DELETE FROM collections')
        filtered=[]; in_real=set()
        for col in raw_cols:
            valid=[str(a) for a in col.get('appids',[]) if str(a) in new_active]
            if not valid: continue
            c={'id':str(col.get('id') or ''),'name':str(col.get('name') or ''),'appids':valid}; filtered.append(c)
            for appid in valid:
                in_real.add(appid); cur.execute('INSERT OR REPLACE INTO collections(collection_id,name,appid) VALUES(?,?,?)',(c['id'],c['name'],appid))
        uncategorized=sorted(new_active-in_real,key=lambda a:str((owned.get(a) or {}).get('name') or a).lower())
        if uncategorized:
            filtered.append({'id':'__owned_uncategorized__','name':'Uncategorized','appids':uncategorized,'virtual':'owned_games'})
            for appid in uncategorized:
                cur.execute('INSERT OR REPLACE INTO collections(collection_id,name,appid) VALUES(?,?,?)',('__owned_uncategorized__','Uncategorized',appid))
        # Removed games are hidden immediately from all local-first queries.
        cur.execute('DELETE FROM collections WHERE appid IN (SELECT appid FROM library_membership WHERE is_active=0)')
        sync_hidden_games_from_collections(con, filtered)
        update_finished_flags(con, filtered)
        cur.execute('INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)',('last_success',str(now)))
        cur.execute('INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)',('last_source',source))
        con.commit()
    except Exception:
        con.rollback(); con.close(); raise
    con.close()
    if added and not silent: _notify2_0371('{0} new game{1} found'.format(len(added),'' if len(added)==1 else 's'),4500)
    if removed and not silent: _notify2_0371('{0} removed game{1} detected'.format(len(removed),'' if len(removed)==1 else 's'),5000)
    result={'ok':True,'added':len(added),'removed':len(removed),'added_appids':added,'removed_appids':removed}
    try:
        with open(_sync_report_path_0371('last_library_sync.json'),'w',encoding='utf-8') as fh: json.dump(dict(result, timestamp=now, source=source),fh,indent=2)
    except Exception: pass
    if scrape_new and added:
        _scrape_new_appids_0371(added, _cached_collections_0371(), silent=silent)
    xbmc.executebuiltin('Container.Refresh')
    return result


def clean_game_library_0371(silent=False):
    con=connect(); rows=con.execute('''SELECT g.appid,g.name FROM games g JOIN library_membership m ON m.appid=g.appid WHERE m.is_active=0 ORDER BY g.name COLLATE NOCASE''').fetchall(); total=len(rows)
    report=[]
    for idx,row in enumerate(rows,1):
        appid=str(row['appid']); name=str(row['name'] or appid)
        if not silent: _notify2_0371('Cleaning {0}/{1} • {2}'.format(idx,total,name),3500)
        con.execute('DELETE FROM collections WHERE appid=?',(appid,)); con.execute('DELETE FROM hidden_games WHERE appid=?',(appid,)); con.execute('DELETE FROM manual_hidden_games WHERE appid=?',(appid,)); con.execute('DELETE FROM games WHERE appid=?',(appid,)); con.execute('DELETE FROM library_membership WHERE appid=?',(appid,))
        report.append({'appid':appid,'game':name,'reason':'no_longer_owned','action':'deleted'})
    con.commit(); con.close()
    try:
        with open(_sync_report_path_0371('clean_game_library.csv'),'w',encoding='utf-8-sig',newline='') as fh:
            w=csv.DictWriter(fh,fieldnames=['appid','game','reason','action']); w.writeheader(); w.writerows(report)
    except Exception: pass
    if not silent: _notify2_0371('Clean complete • {0} game{1} removed'.format(total,'' if total==1 else 's'),5000)
    xbmc.executebuiltin('Container.Refresh')
    return total


def refresh_library_and_scrape_new(silent=False):
    return sync_library_background_0371(silent=silent, scrape_new=True)


def root():
    all_cols = _cached_collections_0371()
    path = cloud_json()
    visible_cols = [c for c in filter_collections(all_cols) if collection_visible_appids(c)]
    active_count = len(_active_appids_0371())
    if active_count:
        if b("show_all_games", True):
            add_dir("All Games ({})".format(active_count), "list", collection="__all__")
        for c in visible_cols:
            add_dir("{} ({})".format(collection_display_name(c), len(collection_visible_appids(c))), "list", collection_id=c["id"], collection_name_for_context=c["name"], collection_id_for_context=c["id"])
    else:
        li = xbmcgui.ListItem(label="Steam library is syncing")
        li.setInfo("video", {"plot": "The local cache is empty. Startup sync will populate it without blocking this folder."})
        li.addContextMenuItems([("Scan for New Games", "RunPlugin({})".format(url_for(mode="scan_new_games"))), ("Steam Library tools", "RunPlugin({})".format(url_for(mode="run_tools")))])
        xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="noop"), li, False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)


def appids_for(params):
    all_cols = _cached_collections_0371()
    visible_cols = filter_collections(all_cols)
    if params.get("collection") == "__all__":
        return filter_hidden_appids(_active_appids_0371()), all_cols
    cid = params.get("collection_id")
    for c in all_cols:
        if c["id"] == cid:
            return collection_visible_appids(c), all_cols
    return [], visible_cols


def list_games(params):
    appids, cols = appids_for(params)
    # Use movie content type so AF3 chooses the same poster/media include family as video shelves.
    # Items still launch through plugin.program.steam.library mode=play.
    xbmcplugin.setContent(HANDLE, "movies")
    total = len(appids)
    progress = None
    show_progress = b("show_listing_progress", False)
    fast_listing = b("fast_library_listing", True)

    if show_progress and total > 30:
        progress = xbmcgui.DialogProgressBG()
        try:
            progress.create(ADDON_NAME, "")
        except Exception:
            progress = None

    include_hidden_listing = params.get("collection") == "__hidden__"
    cached_map = cached_games_for_listing(appids, cols, include_hidden=include_hidden_listing) if (fast_listing or include_hidden_listing) else None

    sort_mode = str(ADDON.getSetting("library_game_sort") or "0")
    if sort_mode != "0":
        if cached_map is None:
            cached_map = cached_games_for_listing(appids, cols, include_hidden=include_hidden_listing)
        appids = sorted(appids, key=lambda a: library_game_sort_key(cached_map.get(str(a)) or {"name": fallback_title(a), "sortname": ""}))

    for idx, appid in enumerate(appids, 1):
        if progress and (idx == 1 or idx % 25 == 0 or idx == total):
            bg_update(progress, int(idx * 100 / max(total, 1)), "LOADING - {}/{}".format(idx, total))
        g = cached_map.get(str(appid)) if cached_map is not None else get_game(appid, False, cols)
        xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="play", appid=appid), make_game_item(g), False, total)

    bg_close(progress)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_UNSORTED)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    # Expose Kodi's real Sort title option. It reads ListItem.SortTitle and falls
    # back to the visible name for items without a custom SortAs.
    sort_title_method = getattr(xbmcplugin, "SORT_METHOD_VIDEO_SORT_TITLE", None)
    if sort_title_method is None:
        sort_title_method = getattr(xbmcplugin, "SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE", None)
    if sort_title_method is not None:
        xbmcplugin.addSortMethod(HANDLE, sort_title_method)
    xbmcplugin.endOfDirectory(HANDLE)
    force_poster_view()


def launch(appid):
    steam_url = "steam://rungameid/{}".format(appid)
    try:
        method = i("launch_method", 0)
        if method == 0 and hasattr(os, "startfile"):
            os.startfile(steam_url)
        elif method == 1:
            subprocess.Popen(["cmd", "/c", "start", "", steam_url], shell=False)
        else:
            xbmc.executebuiltin('System.Exec("{}")'.format(steam_url))
        xbmcgui.Dialog().notification(ADDON_NAME, "Launching Steam app {}".format(appid), xbmcgui.NOTIFICATION_INFO, 2500)
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, "Gagal launch Steam app {}\n{}".format(appid, exc))


def refresh_one(appid):
    if is_hidden_game(appid):
        xbmcgui.Dialog().notification(ADDON_NAME, "Hidden game skipped.", xbmcgui.NOTIFICATION_INFO, 2500)
        return
    cols, _ = sync_collections()
    g = scrape(appid, cols)
    save_game(g)
    xbmcgui.Dialog().notification(ADDON_NAME, "Metadata refreshed: {}".format(g.get("name") or appid), xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")


def open_store(appid):
    try:
        os.startfile("https://store.steampowered.com/app/{}/".format(appid))
    except Exception:
        xbmc.executebuiltin("System.Exec({})".format("https://store.steampowered.com/app/{}/".format(appid)))


def choose_visible_collections():
    cols, path = sync_collections()
    if not cols:
        xbmcgui.Dialog().ok(ADDON_NAME, "No Steam client collections found.\n{}".format(path or "cloud JSON not found"))
        return
    labels = [collection_display_name(c) for c in cols]
    hidden = set(load_collection_visibility().get("hidden_ids", []))
    pre = [idx for idx, c in enumerate(cols) if str(c.get("id")) not in hidden]
    try:
        selected = xbmcgui.Dialog().multiselect("Visible Steam Collections", labels, preselect=pre)
    except TypeError:
        selected = xbmcgui.Dialog().multiselect("Visible Steam Collections", labels)
    if selected is None:
        return
    selected_ids = set(str(cols[i].get("id")) for i in selected)
    hidden_ids = [str(c.get("id")) for c in cols if str(c.get("id")) not in selected_ids]
    save_collection_visibility({"hidden_ids": hidden_ids})
    xbmc.executebuiltin("Container.Refresh")


def show_all_collections():
    reset_collection_visibility()


def hide_collection(name=None, collection_id=None):
    if not collection_id:
        return
    cid = str(collection_id)

    data = load_collection_visibility()
    hidden = data.get("hidden_ids", [])
    if cid not in hidden:
        hidden.append(cid)
    save_collection_visibility({"hidden_ids": hidden})

    # Important: hiding a collection folder does NOT insert its games into hidden_games.
    # Only Steam's real Hidden/Hidden Games collection is synced into hidden_games.
    xbmcgui.Dialog().notification(ADDON_NAME, "Collection folder hidden", xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def reset_collection_visibility():
    save_collection_visibility({"hidden_ids": []})
    ADDON.setSetting("hidden_collection_names", "")
    ADDON.setSetting("visible_collection_names", "")
    ADDON.setSetting("collection_filter_mode", "0")
    sync_collections()
    xbmc.executebuiltin("Container.Refresh")


def rename_collection(collection_id, name):
    if not collection_id:
        return
    aliases = load_collection_aliases()
    current = aliases.get(str(collection_id), name or "")
    try:
        new_name = xbmcgui.Dialog().input("Rename collection", defaultt=current or name or "")
    except TypeError:
        new_name = xbmcgui.Dialog().input("Rename collection", current or name or "")
    if new_name is None:
        return
    new_name = str(new_name).strip()
    if not new_name:
        return
    aliases[str(collection_id)] = new_name
    save_collection_aliases(aliases)
    xbmc.executebuiltin("Container.Refresh")


def reset_collection_name(collection_id):
    if not collection_id:
        return
    aliases = load_collection_aliases()
    if str(collection_id) in aliases:
        del aliases[str(collection_id)]
        save_collection_aliases(aliases)
    xbmc.executebuiltin("Container.Refresh")


def refresh_all(missing=False):
    cols, _ = sync_collections()
    appids = all_appids(cols)
    con = connect()
    cur = con.cursor()
    existing_rows = {}
    for table in ("games", "hidden_games", "manual_hidden_games"):
        cur.execute("SELECT appid,metadata_status,last_scraped FROM {}".format(table))
        for r in cur.fetchall():
            existing_rows[str(r[0])] = {"metadata_status": str(r[1] or ""), "last_scraped": int(r[2] or 0)}
    con.close()

    if missing:
        appids = [a for a in appids if a not in existing_rows or existing_rows[a]["last_scraped"] <= 0 or existing_rows[a]["metadata_status"].lower() not in ("ok", "partial")]

    if not appids:
        xbmcgui.Dialog().notification(ADDON_NAME, "Nothing to scrape.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    if b("fetch_steam250_top250", True):
        fetch_steam250_top250(force=False)

    prog = xbmcgui.DialogProgressBG()
    bg_create(prog)

    rows, ok, partial, fail = [], 0, 0, 0
    total = len(appids)

    for idx, appid in enumerate(appids, 1):
        pct = int(idx * 100 / max(total, 1))
        title = fallback_title(appid)

        try:
            g = scrape(appid, cols)
            save_game(g)
            title = g.get("name") or title
            if g.get("_partial_reason"):
                partial += 1
                rows.append({"appid": appid, "status": "partial_title_only", "name": title, "error": g.get("_partial_reason")})
            else:
                ok += 1
                rows.append({"appid": appid, "status": "ok", "name": title, "error": ""})
        except Exception as exc:
            fail += 1
            rows.append({"appid": appid, "status": "failed", "name": title, "error": str(exc)})

        bg_update(prog, pct, "{}/{} METADATA - {}".format(idx, total, title)[:95])
        xbmc.sleep(150)

    bg_update(prog, 100, "{}/{} METADATA - DONE".format(total, total))
    xbmc.sleep(300)
    bg_close(prog)

    report = os.path.join(DIAG, "metadata_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["appid","status","name","error"])
        w.writeheader()
        w.writerows(rows)

    summary = {
        "mode": "missing" if missing else "all",
        "total": total,
        "ok": ok,
        "partial_title_only": partial,
        "failed": fail,
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    open(os.path.join(STATE_DIR, "last_run_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        "Metadata done: OK {} / Partial {} / Failed {}".format(ok, partial, fail),
        xbmcgui.NOTIFICATION_INFO if fail == 0 else xbmcgui.NOTIFICATION_WARNING,
        6000
    )


def game_rows_for_rebuild():
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT appid, name FROM games ORDER BY name")
    rows = cur.fetchall()
    con.close()
    if rows:
        hidden = hidden_appids()
        return [(str(r["appid"]), str(r["name"] or r["appid"])) for r in rows if str(r["appid"]) not in hidden]

    # Fallback: if DB is empty, use collection AppIDs.
    cols, _ = sync_collections()
    return [(str(appid), fallback_title(appid)) for appid in all_appids(cols)]


def steam_screenshot_slots(appid):
    # Screenshot-only fanart rebuild. Do not use background_raw/background here.
    js = http_json("https://store.steampowered.com/api/appdetails?appids={}&cc=US&l=english&v=1".format(appid), 30)
    app = js.get(str(appid), {})
    if not app.get("success"):
        raise RuntimeError("appdetails_success_false")
    data = app.get("data") or {}
    shots = unique_urls([x.get("path_full") for x in (data.get("screenshots") or []) if x.get("path_full")])
    slots = shots[:5]
    while len(slots) < 5:
        slots.append(NA)
    return {
        "fanart_url": nz(slots[0]),
        "fanart1_url": nz(slots[1]),
        "fanart2_url": nz(slots[2]),
        "fanart3_url": nz(slots[3]),
        "fanart4_url": nz(slots[4]),
    }


def update_fanart_slots(appid, slots):
    con = connect()
    cur = con.cursor()
    cur.execute("""UPDATE games SET
        fanart_url=?, fanart1_url=?, fanart2_url=?, fanart3_url=?, fanart4_url=?
        WHERE appid=?""", (
        slots.get("fanart_url") or NA,
        slots.get("fanart1_url") or NA,
        slots.get("fanart2_url") or NA,
        slots.get("fanart3_url") or NA,
        slots.get("fanart4_url") or NA,
        str(appid)
    ))
    con.commit()
    con.close()


def rebuild_screenshot_fanarts_only():
    rows_to_process = game_rows_for_rebuild()
    if not rows_to_process:
        xbmcgui.Dialog().notification(ADDON_NAME, "No games to rebuild.", xbmcgui.NOTIFICATION_WARNING, 4000)
        return

    prog = xbmcgui.DialogProgressBG()
    bg_create(prog)

    report_rows = []
    ok, no_data, fail = 0, 0, 0
    total = len(rows_to_process)

    for idx, (appid, title) in enumerate(rows_to_process, 1):
        pct = int(idx * 100 / max(total, 1))
        try:
            slots = steam_screenshot_slots(appid)
            update_fanart_slots(appid, slots)
            count_urls = sum(1 for v in slots.values() if v and v != NA)
            if count_urls > 0:
                ok += 1
                status = "ok"
                err = ""
            else:
                no_data += 1
                status = "no_screenshots"
                err = ""
            report_rows.append({
                "appid": appid,
                "name": title,
                "status": status,
                "fanart_count": count_urls,
                "fanart_url": slots.get("fanart_url", NA),
                "fanart1_url": slots.get("fanart1_url", NA),
                "fanart2_url": slots.get("fanart2_url", NA),
                "fanart3_url": slots.get("fanart3_url", NA),
                "fanart4_url": slots.get("fanart4_url", NA),
                "error": err,
            })
        except Exception as exc:
            # Important: if the provider errors, do not overwrite old fanart URLs.
            fail += 1
            report_rows.append({
                "appid": appid,
                "name": title,
                "status": "error_not_overwritten",
                "fanart_count": "",
                "fanart_url": "",
                "fanart1_url": "",
                "fanart2_url": "",
                "fanart3_url": "",
                "fanart4_url": "",
                "error": str(exc),
            })

        bg_update(prog, pct, "{}/{} SCREENSHOTS - {}".format(idx, total, title)[:95])
        xbmc.sleep(120)

    bg_update(prog, 100, "{}/{} SCREENSHOTS - DONE".format(total, total))
    xbmc.sleep(300)
    bg_close(prog)

    report = os.path.join(DIAG, "screenshot_fanart_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["appid","name","status","fanart_count","fanart_url","fanart1_url","fanart2_url","fanart3_url","fanart4_url","error"])
        w.writeheader()
        w.writerows(report_rows)

    summary = {
        "mode": "rebuild_screenshot_fanarts_only",
        "total": total,
        "ok": ok,
        "no_screenshots": no_data,
        "failed_not_overwritten": fail,
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    open(os.path.join(STATE_DIR, "last_screenshot_fanart_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        "Screenshot fanarts: OK {} / N/A {} / Error {}".format(ok, no_data, fail),
        xbmcgui.NOTIFICATION_INFO if fail == 0 else xbmcgui.NOTIFICATION_WARNING,
        6000
    )
    xbmc.executebuiltin("Container.Refresh")


def art_is_missing_value(value):
    if value is None:
        return True
    value = str(value).strip()
    return value == "" or value.upper() == "N/A"


def missing_artwork_rows():
    con = connect()
    cur = con.cursor()
    cur.execute("""SELECT appid, name, poster_url, thumb_url, clearlogo_url,
                          fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url
                   FROM games
                   ORDER BY name""")
    rows = cur.fetchall()
    con.close()

    hidden = hidden_appids()
    out = []
    for r in rows:
        if str(r["appid"]) in hidden:
            continue
        wanted = []
        for col in ["poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"]:
            if art_is_missing_value(r[col]):
                wanted.append(col)
        if wanted:
            out.append((str(r["appid"]), str(r["name"] or r["appid"]), wanted))
    if out:
        return out

    # Fallback when DB is empty.
    cols, _ = sync_collections()
    return [(str(appid), fallback_title(appid), ["poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"]) for appid in all_appids(cols)]


def auto_art_for_rebuild(appid):
    js = http_json("https://store.steampowered.com/api/appdetails?appids={}&cc=US&l=english&v=1".format(appid), 30)
    app = js.get(str(appid), {})
    if not app.get("success"):
        raise RuntimeError("appdetails_success_false")
    data = app.get("data") or {}
    return auto_art(appid, data, steam_store_html(appid))


def update_missing_artwork_columns(appid, art, wanted_columns):
    # Missing-only update: existing filled URLs are preserved.
    valid_columns = ["poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"]
    wanted = [c for c in wanted_columns if c in valid_columns]
    if not wanted:
        return 0, {}

    con = connect()
    cur = con.cursor()
    cur.execute("""SELECT poster_url, thumb_url, clearlogo_url,
                          fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url
                   FROM games WHERE appid=?""", (str(appid),))
    row = cur.fetchone()
    if not row:
        con.close()
        save_game(partial_game(appid, "missing_artwork_rebuild_created"))
        con = connect()
        cur = con.cursor()
        cur.execute("""SELECT poster_url, thumb_url, clearlogo_url,
                              fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url
                       FROM games WHERE appid=?""", (str(appid),))
        row = cur.fetchone()

    updates = {}
    for col in wanted:
        current = row[col] if row else ""
        new_value = art.get(col, NA)
        # Only fill missing current values. Do not overwrite filled manual/old URLs.
        if art_is_missing_value(current):
            updates[col] = new_value if new_value else NA

    if not updates:
        con.close()
        return 0, {}

    set_clause = ", ".join(["{}=?".format(col) for col in updates.keys()])
    values = list(updates.values()) + [str(appid)]
    cur.execute("UPDATE games SET {} WHERE appid=?".format(set_clause), values)
    con.commit()
    con.close()
    return len(updates), updates


def rebuild_missing_artwork_urls():
    rows_to_process = missing_artwork_rows()
    if not rows_to_process:
        xbmcgui.Dialog().notification(ADDON_NAME, "No missing artwork URLs.", xbmcgui.NOTIFICATION_INFO, 4000)
        return

    prog = xbmcgui.DialogProgressBG()
    bg_create(prog)

    report_rows = []
    ok, skipped, no_data, fail = 0, 0, 0, 0
    total = len(rows_to_process)

    for idx, (appid, title, wanted) in enumerate(rows_to_process, 1):
        pct = int(idx * 100 / max(total, 1))
        try:
            art = auto_art_for_rebuild(appid)
            changed_count, updates = update_missing_artwork_columns(appid, art, wanted)

            if changed_count > 0:
                ok += 1
                status = "updated_missing_only"
            else:
                # Provider returned only N/A or everything became filled before this item ran.
                if all(art_is_missing_value(art.get(c)) for c in wanted):
                    no_data += 1
                    status = "no_artwork_data"
                else:
                    skipped += 1
                    status = "already_filled_skipped"

            report_rows.append({
                "appid": appid,
                "name": title,
                "status": status,
                "wanted_columns": ",".join(wanted),
                "updated_columns": ",".join(updates.keys()),
                "poster_url": updates.get("poster_url", ""),
                "thumb_url": updates.get("thumb_url", ""),
                "clearlogo_url": updates.get("clearlogo_url", ""),
                "fanart_url": updates.get("fanart_url", ""),
                "fanart1_url": updates.get("fanart1_url", ""),
                "fanart2_url": updates.get("fanart2_url", ""),
                "fanart3_url": updates.get("fanart3_url", ""),
                "fanart4_url": updates.get("fanart4_url", ""),
                "error": "",
            })
        except Exception as exc:
            # Provider error: do not overwrite any existing artwork.
            fail += 1
            report_rows.append({
                "appid": appid,
                "name": title,
                "status": "error_not_overwritten",
                "wanted_columns": ",".join(wanted),
                "updated_columns": "",
                "poster_url": "",
                "thumb_url": "",
                "clearlogo_url": "",
                "fanart_url": "",
                "fanart1_url": "",
                "fanart2_url": "",
                "fanart3_url": "",
                "fanart4_url": "",
                "error": str(exc),
            })

        bg_update(prog, pct, "{}/{} ARTWORK URLS - {}".format(idx, total, title)[:95])
        xbmc.sleep(120)

    bg_update(prog, 100, "{}/{} ARTWORK URLS - DONE".format(total, total))
    xbmc.sleep(300)
    bg_close(prog)

    report = os.path.join(DIAG, "missing_artwork_rebuild_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        fields = ["appid","name","status","wanted_columns","updated_columns","poster_url","thumb_url","clearlogo_url","fanart_url","fanart1_url","fanart2_url","fanart3_url","fanart4_url","error"]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(report_rows)

    summary = {
        "mode": "rebuild_missing_artwork_urls",
        "total": total,
        "updated": ok,
        "already_filled_skipped": skipped,
        "no_artwork_data": no_data,
        "failed_not_overwritten": fail,
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    open(os.path.join(STATE_DIR, "last_missing_artwork_rebuild_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        "Artwork URLs: Updated {} / Error {}".format(ok, fail),
        xbmcgui.NOTIFICATION_INFO if fail == 0 else xbmcgui.NOTIFICATION_WARNING,
        6000
    )
    xbmc.executebuiltin("Container.Refresh")


def json_rpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    data = json.loads(raw or "{}")
    if data.get("error"):
        raise RuntimeError("{}: {}".format(method, data.get("error")))
    return data.get("result")


def kodi_setting(setting_id, default=None):
    try:
        result = json_rpc("Settings.GetSettingValue", {"setting": setting_id})
        if isinstance(result, dict) and "value" in result:
            return result.get("value")
    except Exception as exc:
        log("Cannot read Kodi setting {}: {}".format(setting_id, exc), xbmc.LOGWARNING)
    return default


def kodi_webserver_config():
    enabled = bool(kodi_setting("services.webserver", False))
    port = kodi_setting("services.webserverport", 8080)
    username = kodi_setting("services.webserverusername", "") or ""
    password = kodi_setting("services.webserverpassword", "") or ""
    ssl = bool(kodi_setting("services.webserverssl", False))
    try:
        port = int(port)
    except Exception:
        port = 8080
    return {
        "enabled": enabled,
        "port": port,
        "username": str(username),
        "password": str(password),
        "scheme": "https" if ssl else "http",
    }


def kodi_quote_image(image_string):
    # Match LAC / Kodi behavior:
    # remote URL -> image://<encoded remote URL>/
    # then the whole image:// string is URL-encoded for the /image endpoint.
    if not image_string:
        return ""
    image_string = str(image_string)
    if image_string.startswith("image://"):
        return image_string
    result = "image://{}/".format(urllib.parse.quote(image_string, safe="()!"))
    return re.sub(r"%[0-9A-F]{2}", lambda mo: mo.group().lower(), result)


def kodi_unquote_image(image_string):
    # Textures.GetTextures usually returns image://https%3a%2f%2f.../
    # Convert it back to the original remote URL before comparing with our DB URLs.
    if not image_string:
        return ""
    image_string = str(image_string)
    if image_string.startswith("image://") and not image_string.startswith(("image://video", "image://music")):
        inner = image_string[8:]
        if inner.endswith("/"):
            inner = inner[:-1]
        return urllib.parse.unquote(inner)
    return image_string


def kodi_image_url(original_url, config):
    # LAC-compatible Kodi image cache URL:
    # raw remote URL -> image://quoted-raw-url/ -> quote the whole image:// string for /image/.
    # Calling /image/<encoded raw https URL> returns 404 on Kodi.
    image_url = kodi_quote_image(original_url)
    encoded = urllib.parse.quote(image_url, safe="")
    return "{}://127.0.0.1:{}/image/{}".format(config["scheme"], config["port"], encoded)


def get_cached_texture_urls():
    # Read Kodi texture cache via JSON-RPC and normalize back to original artwork URLs.
    # This matches LAC's pykodi.unquoteimage(texture['url']) behavior.
    cached = set()
    start = 0
    page = 1000

    while True:
        params = {
            "properties": ["url"],
            "limits": {"start": start, "end": start + page}
        }
        try:
            result = json_rpc("Textures.GetTextures", params) or {}
        except Exception as exc:
            if start == 0:
                try:
                    result = json_rpc("Textures.GetTextures", {"properties": ["url"]}) or {}
                except Exception as exc2:
                    raise RuntimeError("Textures.GetTextures failed: {}".format(exc2))
            else:
                raise RuntimeError("Textures.GetTextures failed: {}".format(exc))

        textures = result.get("textures") or []
        for item in textures:
            url = item.get("url")
            if not url:
                continue
            url = str(url)
            cached.add(url)
            cached.add(kodi_unquote_image(url))

        limits = result.get("limits") or {}
        total = int(limits.get("total") or len(textures) or 0)
        end = int(limits.get("end") or (start + len(textures)))
        if not textures or end >= total:
            break
        start = end

    return cached

def cacheable_artwork_rows():
    rows = artwork_urls()
    out, seen = [], set()
    hidden = hidden_appids()
    for item in rows:
        if str(item.get("appid") or "") in hidden:
            continue
        url = art_or_empty(item.get("url"))
        if not url:
            continue
        if url in seen:
            continue
        seen.add(url)
        out.append({
            "appid": item.get("appid") or "",
            "name": item.get("name") or item.get("appid") or "",
            "art_type": item.get("art_type") or "",
            "url": url,
        })
    return out


def download_via_kodi_image_endpoint(item, config):
    url = item["url"]
    endpoint = kodi_image_url(url, config)
    item["endpoint"] = endpoint
    req = urllib.request.Request(endpoint, headers={"User-Agent": UA})

    if config.get("username") or config.get("password"):
        import base64
        token = base64.b64encode(("{}:{}".format(config.get("username", ""), config.get("password", ""))).encode("utf-8")).decode("ascii")
        req.add_header("Authorization", "Basic {}".format(token))

    with urllib.request.urlopen(req, timeout=60) as response:
        total_read = 0
        while True:
            chunk = response.read(1024 * 64)
            if not chunk:
                break
            total_read += len(chunk)
        status = getattr(response, "status", 200)
        if int(status) < 200 or int(status) >= 400:
            raise RuntimeError("HTTP {}".format(status))
        return total_read


def cache_artwork_lac_style():
    all_urls = cacheable_artwork_rows()
    total_urls = len(all_urls)
    if not all_urls:
        xbmcgui.Dialog().notification(ADDON_NAME, "No artwork URLs in DB. Run metadata first.", xbmcgui.NOTIFICATION_WARNING, 5000)
        return

    config = kodi_webserver_config()
    if not config.get("enabled"):
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            "Kodi web server is disabled.\n\nEnable:\nSettings > Services > Control > Allow remote control via HTTP\n\nThis cache method uses Kodi /image endpoint like LAC."
        )
        return

    prog = xbmcgui.DialogProgressBG()
    bg_create(prog)
    bg_update(prog, 0, "CHECKING TEXTURE CACHE")

    try:
        cached_urls = get_cached_texture_urls()
    except Exception as exc:
        bg_close(prog)
        xbmcgui.Dialog().ok(ADDON_NAME, "Cannot read Kodi texture cache:\n{}".format(exc))
        return

    pending = [item for item in all_urls if item["url"] not in cached_urls]
    already_cached = total_urls - len(pending)

    report_rows = []
    for item in all_urls:
        if item["url"] in cached_urls:
            report_rows.append({**item, "endpoint": "", "status": "already_cached", "bytes": "", "error": ""})

    if not pending:
        bg_update(prog, 100, "0/0 CACHING - DONE")
        xbmc.sleep(300)
        bg_close(prog)

        report = os.path.join(DIAG, "artwork_cache_report.csv")
        with open(report, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["appid","name","art_type","url","endpoint","status","bytes","error"])
            w.writeheader()
            w.writerows(report_rows)

        summary = {
            "mode": "lac_style_kodi_image_endpoint",
            "total_urls": total_urls,
            "already_cached": already_cached,
            "pending": 0,
            "cached": 0,
            "failed": 0,
            "report": report,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        open(os.path.join(STATE_DIR, "last_artwork_cache_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))
        xbmcgui.Dialog().notification(ADDON_NAME, "Artwork cache: {} already cached".format(already_cached), xbmcgui.NOTIFICATION_INFO, 6000)
        return

    cached_count, failed_count, done = 0, 0, 0
    pending_total = len(pending)

    def worker(item):
        bytes_read = download_via_kodi_image_endpoint(item, config)
        return item, bytes_read

    max_workers = min(4, max(1, pending_total))
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {executor.submit(worker, item): item for item in pending}
        for future in concurrent.futures.as_completed(future_map):
            item = future_map[future]
            done += 1
            pct = int(done * 100 / max(pending_total, 1))
            try:
                item2, bytes_read = future.result()
                cached_count += 1
                report_rows.append({**item2, "status": "cached", "bytes": bytes_read, "error": ""})
            except Exception as exc:
                failed_count += 1
                report_rows.append({**item, "status": "failed", "bytes": "", "error": str(exc)})

            title = item.get("name") or item.get("appid") or ""
            bg_update(prog, pct, "{}/{} CACHING - {}".format(done, pending_total, title)[:95])

    bg_update(prog, 100, "{}/{} CACHING - DONE".format(pending_total, pending_total))
    xbmc.sleep(300)
    bg_close(prog)

    report = os.path.join(DIAG, "artwork_cache_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["appid","name","art_type","url","endpoint","status","bytes","error"])
        w.writeheader()
        w.writerows(report_rows)

    summary = {
        "mode": "lac_style_kodi_image_endpoint",
        "total_urls": total_urls,
        "already_cached": already_cached,
        "pending": pending_total,
        "cached": cached_count,
        "failed": failed_count,
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    open(os.path.join(STATE_DIR, "last_artwork_cache_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        "Artwork cache: Cached {} / Failed {} / Skipped {}".format(cached_count, failed_count, already_cached),
        xbmcgui.NOTIFICATION_INFO if failed_count == 0 else xbmcgui.NOTIFICATION_WARNING,
        7000
    )


def artwork_urls(include_hidden=False):
    con = connect()
    cur = con.cursor()
    cur.execute("""SELECT appid, name, poster_url, thumb_url, clearlogo_url, fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url
                   FROM games ORDER BY name""")
    rows = cur.fetchall()
    con.close()
    hidden = set() if include_hidden else hidden_appids()
    urls, seen = [], set()
    for r in rows:
        if str(r["appid"]) in hidden:
            continue
        pairs = [
            ("poster", r["poster_url"]),
            ("thumb", r["thumb_url"]),
            ("clearlogo", r["clearlogo_url"]),
            ("fanart", r["fanart_url"]),
            ("fanart1", r["fanart1_url"]),
            ("fanart2", r["fanart2_url"]),
            ("fanart3", r["fanart3_url"]),
            ("fanart4", r["fanart4_url"]),
        ]
        for typ, url in pairs:
            url = art_or_empty(url)
            if not url:
                continue
            key = (typ, url)
            if key in seen:
                continue
            seen.add(key)
            urls.append({"appid": r["appid"], "name": r["name"] or r["appid"], "art_type": typ, "url": url})
    return urls


def cache_artwork():
    cache_artwork_lac_style()

def get_current_game(appid):
    if is_hidden_game(appid):
        return partial_game(appid, "hidden_game_skipped")
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT * FROM games WHERE appid=?", (str(appid),))
    row = cur.fetchone()
    con.close()
    return dict(row) if row else partial_game(appid, "not_in_db")


def artwork_candidates(appid, art_type):
    appid = str(appid)
    candidates = []
    data = {}
    store_html_text = ""

    try:
        js = http_json("https://store.steampowered.com/api/appdetails?appids={}&cc=US&l=english&v=1".format(appid), 25)
        app = js.get(appid, {})
        if app.get("success"):
            data = app.get("data") or {}
            store_html_text = steam_store_html(appid)
    except Exception:
        pass

    def add(label, url):
        url = art_or_empty(url)
        if url:
            candidates.append({"label": label, "url": url})

    if art_type == "poster":
        add("Steam • library_600x900", poster(appid))
        for a in sgdb_assets(appid, "grids", limit=20):
            add(a.get("label") or "SteamGridDB grid", a["url"])

    elif art_type == "thumb":
        add("Steam • header", data.get("header_image") or "")
        add("Steam • capsule", data.get("capsule_image") or "")
        add("Steam • capsule 616x353", data.get("capsule_imagev5") or "")

    elif art_type == "clearlogo":
        logo = parse_store_logo(store_html_text, appid)
        add("Steam • logo", logo)
        add("Steam • logo direct", steam_logo_direct(appid))
        for a in sgdb_assets(appid, "logos", limit=20):
            add(a.get("label") or "SteamGridDB logo", a["url"])

    elif art_type == "fanart":
        add("Steam • background_raw", data.get("background_raw") or "")
        for idx, ss in enumerate((data.get("screenshots") or []), 1):
            add("Steam • screenshot {}".format(idx), ss.get("path_full") or "")
        for a in sgdb_assets(appid, "heroes", limit=20):
            add(a.get("label") or "SteamGridDB hero", a["url"])

    # de-duplicate
    out, seen = [], set()
    for c in candidates:
        if c["url"] not in seen:
            seen.add(c["url"])
            out.append(c)
    return out


def choose_candidate(heading, candidates):
    if not candidates:
        xbmcgui.Dialog().notification(ADDON_NAME, "No artwork candidates found.", xbmcgui.NOTIFICATION_WARNING, 4000)
        return ""
    items = []
    for c in candidates:
        li = xbmcgui.ListItem(label=c["label"])
        li.setArt({"thumb": c["url"], "icon": c["url"], "fanart": c["url"]})
        items.append(li)
    try:
        idx = xbmcgui.Dialog().select(heading, items, useDetails=True)
    except Exception:
        idx = xbmcgui.Dialog().select(heading, [c["label"] for c in candidates])
    if idx is None or idx < 0:
        return ""
    return candidates[idx]["url"]


def update_art_url(appid, column, url):
    if column not in ["poster_url","thumb_url","clearlogo_url","fanart_url","fanart1_url","fanart2_url","fanart3_url","fanart4_url"]:
        return
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT appid FROM games WHERE appid=?", (str(appid),))
    if not cur.fetchone():
        save_game(partial_game(appid, "artwork_manual_created"))
        con = connect()
        cur = con.cursor()
    cur.execute("UPDATE games SET {}=? WHERE appid=?".format(column), (url, str(appid)))
    con.commit()
    con.close()


def reset_auto_art(appid):
    try:
        js = http_json("https://store.steampowered.com/api/appdetails?appids={}&cc=US&l=english&v=1".format(appid), 25)
        app = js.get(str(appid), {})
        if not app.get("success"):
            xbmcgui.Dialog().notification(ADDON_NAME, "Store appdetails unavailable.", xbmcgui.NOTIFICATION_WARNING, 4000)
            return
        data = app.get("data") or {}
        art = auto_art(appid, data, steam_store_html(appid))
        con = connect()
        cur = con.cursor()
        for col, val in art.items():
            cur.execute("UPDATE games SET {}=? WHERE appid=?".format(col), (val, str(appid)))
        con.commit()
        con.close()
        xbmc.executebuiltin("Container.Refresh")
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, "Reset artwork failed:\n{}".format(exc))


def select_artwork(appid):
    g = get_current_game(appid)
    title = g.get("name") or str(appid)
    opts = ["Poster", "Fanart", "Thumb", "Clearlogo", "Reset all artwork to auto", "Exit"]
    n = xbmcgui.Dialog().select("Select artwork - {}".format(title), opts)
    if n < 0 or n == 5:
        return
    if n == 4:
        reset_auto_art(appid)
        return

    art_type = ["poster", "fanart", "thumb", "clearlogo"][n]
    column = {
        "poster": "poster_url",
        "thumb": "thumb_url",
        "clearlogo": "clearlogo_url",
    }.get(art_type)

    if art_type == "fanart":
        slots = ["Main fanart", "Fanart 1", "Fanart 2", "Fanart 3", "Fanart 4"]
        si = xbmcgui.Dialog().select("Select fanart slot", slots)
        if si is None or si < 0:
            return
        column = ["fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"][si]

    cand = artwork_candidates(appid, art_type)
    url = choose_candidate("{} - {}".format(opts[n], title), cand)
    if not url:
        return
    update_art_url(appid, column, url)
    xbmcgui.Dialog().notification(ADDON_NAME, "Artwork updated.", xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def view_status():
    cols = _cached_collections_0371()
    con = connect()
    cur = con.cursor()

    def count(sql):
        cur.execute(sql)
        return cur.fetchone()[0]

    last = cur.execute("SELECT value FROM library_sync_state WHERE key='last_success'").fetchone()
    last_text = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(last[0]))) if last and str(last[0]).isdigit() else 'never'
    msg = (
        "Collections: {0}\n"
        "Active games: {1}\n"
        "Removed pending clean: {2}\n"
        "Games metadata rows: {3}\n"
        "Playtime values: {4}\n\n"
        "Last successful sync: {5}\n\n"
        "DB:\n{6}"
    ).format(
        len(cols),
        count("SELECT COUNT(*) FROM library_membership WHERE is_active=1"),
        count("SELECT COUNT(*) FROM library_membership WHERE is_active=0"),
        count("SELECT COUNT(*) FROM games"),
        count("SELECT COUNT(*) FROM games WHERE playtime_forever>0"),
        last_text,
        DB_PATH,
    )
    con.close()
    xbmcgui.Dialog().ok(ADDON_NAME, msg)


def export_diag():
    ensure()

    # Auto-delete older diagnostic ZIPs from addon_data root before creating a new one.
    for old_zip in glob.glob(os.path.join(PROFILE, "steam-library-diagnostics-*.zip")) + glob.glob(os.path.join(PROFILE, "steam-library-diagnostics.zip")):
        try:
            os.remove(old_zip)
        except Exception:
            pass

    zip_path = os.path.join(PROFILE, "steam-library-diagnostics-{}.zip".format(time.strftime("%Y%m%d-%H%M%S")))

    settings_snapshot = {
        "addon_id": ADDON_ID,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "settings": {
            "steam_api_key_set": bool(s("steam_api_key")),
            "steam_id64": s("steam_id64"),
            "steam_appinfo_path": s("steam_appinfo_path"),
            "sortname_source": s("sortname_source"),
            "steam_appinfo_resolved": resolve_steam_appinfo_path(),
            "steamgriddb_api_key_set": bool(s("steamgriddb_api_key")),
            "cloud_json_path": s("cloud_json_path"),
            "show_all_games": b("show_all_games", True),
            "all_games_exclude_hidden": b("all_games_exclude_hidden", True),
            "fetch_steam_reviews": b("fetch_steam_reviews", True),
            "fetch_achievements": b("fetch_achievements", True),
            "cache_days": i("cache_days", 30),
            "launch_method": i("launch_method", 0),
            "auto_sync_library_on_startup": b("auto_sync_library_on_startup", True),
            "auto_scan_startup_delay": i("auto_scan_startup_delay", 25),
        },
        "collection_aliases": load_collection_aliases(),
        "collection_visibility": load_collection_visibility(),
        "hidden_games_count": 0,
    }
    try:
        con = connect()
        settings_snapshot["hidden_games_count"] = con.execute("SELECT COUNT(*) FROM hidden_games").fetchone()[0]
        settings_snapshot["active_games_count"] = con.execute("SELECT COUNT(*) FROM library_membership WHERE is_active=1").fetchone()[0]
        settings_snapshot["removed_pending_clean_count"] = con.execute("SELECT COUNT(*) FROM library_membership WHERE is_active=0").fetchone()[0]
        settings_snapshot["playtime_count"] = con.execute("SELECT COUNT(*) FROM games WHERE playtime_forever>0").fetchone()[0]
        con.close()
    except Exception:
        pass

    tmp_settings = os.path.join(DIAG, "settings_snapshot.json")
    with open(tmp_settings, "w", encoding="utf-8") as f:
        f.write(json.dumps(settings_snapshot, indent=2, ensure_ascii=False))

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        # Root: only DB + settings snapshot.
        if os.path.exists(DB_PATH):
            z.write(DB_PATH, "steam_library.db")
        z.write(tmp_settings, "settings.json")

        # Everything else goes into diagnostics/.
        for p in glob.glob(os.path.join(DIAG, "*")):
            z.write(p, "runtime/diagnostics/" + os.path.basename(p))
        for f in ["last_run_summary.json", "last_artwork_cache_summary.json", "last_screenshot_fanart_summary.json", "last_missing_artwork_rebuild_summary.json", "last_prune_artwork_cache_summary.json"]:
            p = os.path.join(STATE_DIR, f)
            if os.path.exists(p):
                z.write(p, "runtime/state/" + f)
        for folder, arcbase in ((REPORTS_DIR, "runtime/reports"), (STATE_DIR, "runtime/state"), (LOGS_DIR, "runtime/logs")):
            try:
                for name in os.listdir(folder):
                    path = os.path.join(folder, name)
                    if os.path.isfile(path):
                        z.write(path, arcbase + "/" + name)
            except Exception:
                pass
        for f in ["owned_games_cache.json", "steam250_top250_cache.json"]:
            p = os.path.join(CACHE_DIR, f)
            if os.path.exists(p):
                z.write(p, "cache/" + f)
        if os.path.exists(ALIASES_PATH):
            z.write(ALIASES_PATH, "runtime/state/collection_aliases.json")
        if os.path.exists(VISIBILITY_PATH):
            z.write(VISIBILITY_PATH, "runtime/state/collection_visibility.json")

    try:
        os.remove(tmp_settings)
    except Exception:
        pass

    xbmcgui.Dialog().notification(ADDON_NAME, "DIAGNOSTICS EXPORTED - {}".format(os.path.basename(zip_path)), xbmcgui.NOTIFICATION_INFO, 5000)


def edit_setting_value(setting_id, label, hidden=False):
    current = ADDON.getSetting(setting_id)
    try:
        value = xbmcgui.Dialog().input(
            label,
            defaultt=current,
            type=xbmcgui.INPUT_ALPHANUM,
            option=xbmcgui.ALPHANUM_HIDE_INPUT if hidden and hasattr(xbmcgui, "ALPHANUM_HIDE_INPUT") else 0
        )
    except TypeError:
        value = xbmcgui.Dialog().input(label, current)
    if value is None:
        return
    ADDON.setSetting(setting_id, str(value).strip())
    xbmcgui.Dialog().notification(ADDON_NAME, "{} saved".format(label), xbmcgui.NOTIFICATION_INFO, 2000)


def steam_account_settings_menu():
    opts = [
        "Steam Web API Key",
        "SteamID64",
        "SteamGridDB API Key",
        "Steam cloud-storage-namespace-1.json path",
        "Open Kodi settings",
        "Exit"
    ]
    while True:
        n = xbmcgui.Dialog().select("Steam Account Settings", opts)
        if n is None or n < 0 or n == 5:
            return
        if n == 0:
            edit_setting_value("steam_api_key", "Steam Web API Key", True)
        elif n == 1:
            edit_setting_value("steam_id64", "SteamID64", False)
        elif n == 2:
            edit_setting_value("steamgriddb_api_key", "SteamGridDB API Key", True)
        elif n == 3:
            edit_setting_value("cloud_json_path", "Steam cloud-storage-namespace-1.json path", False)
        elif n == 4:
            ADDON.openSettings()


def latest_textures_db_path():
    db_dir = xbmcvfs.translatePath("special://database/")
    files = glob.glob(os.path.join(db_dir, "Textures*.db"))
    if not files:
        return ""
    return max(files, key=lambda p: os.path.getmtime(p))


def thumbnail_file_path(cachedurl):
    if not cachedurl:
        return ""
    base = xbmcvfs.translatePath("special://thumbnails/")
    return os.path.join(base, str(cachedurl).replace("/", os.sep))


def collect_known_steam_artwork_urls():
    # Use DB URLs including hidden games, plus prior cache/rebuild reports.
    # This allows pruning even after some rows were hidden or after a prior failed cache run.
    urls = set()

    try:
        for item in artwork_urls(include_hidden=True):
            url = art_or_empty(item.get("url"))
            if url:
                urls.add(url)
    except Exception as exc:
        log("Collect prune URLs from DB failed: {}".format(exc), xbmc.LOGWARNING)

    report_files = [
        os.path.join(DIAG, "artwork_cache_report.csv"),
        os.path.join(DIAG, "missing_artwork_rebuild_report.csv"),
        os.path.join(DIAG, "screenshot_fanart_report.csv"),
    ]
    artwork_fields = ["url", "poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"]

    for report in report_files:
        if not os.path.exists(report):
            continue
        try:
            with open(report, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    for field in artwork_fields:
                        url = art_or_empty(row.get(field))
                        if url:
                            urls.add(url)
        except Exception as exc:
            log("Collect prune URLs from {} failed: {}".format(report, exc), xbmc.LOGWARNING)

    return urls


def sql_quote_ident(name):
    return '"' + str(name).replace('"', '""') + '"'


def table_columns(cur, table):
    return [str(c[1]) for c in cur.execute("PRAGMA table_info({})".format(sql_quote_ident(table))).fetchall()]


def choose_texture_id_column(cols):
    # Kodi texture DB schema is not identical across versions.
    # Some use idtexture/idTexture, some builds only expose id/rowid.
    lower = {c.lower(): c for c in cols}
    for key in ["idtexture", "id_texture", "textureid", "id"]:
        if key in lower:
            return lower[key]
    return ""


def delete_texture_rows_and_files(texture_db, target_urls):
    if not texture_db or not os.path.exists(texture_db):
        raise RuntimeError("Textures DB not found")

    con = sqlite3.connect(texture_db, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=10000")
    cur = con.cursor()

    texture_cols = table_columns(cur, "texture")
    if "url" not in texture_cols or "cachedurl" not in texture_cols:
        con.close()
        raise RuntimeError("Unsupported Textures DB schema: texture table has {}".format(", ".join(texture_cols)))

    id_col = choose_texture_id_column(texture_cols)

    if id_col:
        cur.execute("SELECT rowid AS __rowid, {} AS __id, url, cachedurl FROM texture".format(sql_quote_ident(id_col)))
    else:
        # Fallback for schemas without idtexture: rowid is enough to delete from texture itself.
        cur.execute("SELECT rowid AS __rowid, rowid AS __id, url, cachedurl FROM texture")
    rows = cur.fetchall()

    matches = []
    target = set(str(x) for x in target_urls if x)
    for r in rows:
        url = str(r["url"] or "")
        raw = kodi_unquote_image(url)
        if url in target or raw in target:
            matches.append({
                "texture_id": int(r["__id"]),
                "rowid": int(r["__rowid"]),
                "id_column": id_col or "rowid",
                "url": url,
                "raw_url": raw,
                "cachedurl": str(r["cachedurl"] or ""),
            })

    file_deleted, file_missing = 0, 0
    report_rows = []
    for m in matches:
        thumb = thumbnail_file_path(m["cachedurl"])
        deleted = False
        missing = False
        try:
            if thumb and xbmcvfs.exists(thumb):
                deleted = bool(xbmcvfs.delete(thumb))
            else:
                missing = True
        except Exception as exc:
            log("Delete thumbnail failed {}: {}".format(thumb, exc), xbmc.LOGWARNING)

        if deleted:
            file_deleted += 1
        elif missing:
            file_missing += 1

        report_rows.append({
            "texture_id": m["texture_id"],
            "rowid": m["rowid"],
            "id_column": m["id_column"],
            "url": m["url"],
            "raw_url": m["raw_url"],
            "cachedurl": m["cachedurl"],
            "thumbnail": thumb,
            "file_deleted": "1" if deleted else "0",
            "file_missing": "1" if missing else "0",
        })

    if matches:
        # Delete dependent rows only when those tables contain a matching texture-id column.
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [str(r[0]) for r in cur.fetchall()]
        candidate_cols = []
        if id_col:
            candidate_cols.extend([id_col, "idtexture", "idTexture", "id_texture", "textureid", "texture_id"])
        candidate_cols.append("idtexture")
        candidate_cols = list(dict.fromkeys(candidate_cols))

        ids = [m["texture_id"] for m in matches]
        for tbl in tables:
            if tbl == "texture":
                continue
            try:
                cols = table_columns(cur, tbl)
                for dep_col in candidate_cols:
                    if dep_col in cols:
                        cur.executemany(
                            'DELETE FROM {} WHERE {}=?'.format(sql_quote_ident(tbl), sql_quote_ident(dep_col)),
                            [(i,) for i in ids]
                        )
                        break
            except Exception as exc:
                log("Skip dependent texture table {}: {}".format(tbl, exc), xbmc.LOGWARNING)

        # Delete from main texture table. Use rowid to work across all Kodi texture schemas.
        cur.executemany("DELETE FROM texture WHERE rowid=?", [(m["rowid"],) for m in matches])
        con.commit()

    con.close()

    report = os.path.join(DIAG, "prune_artwork_cache_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        fields = ["texture_id", "rowid", "id_column", "url", "raw_url", "cachedurl", "thumbnail", "file_deleted", "file_missing"]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(report_rows)

    summary = {
        "mode": "prune_steam_artwork_cache",
        "texture_db": texture_db,
        "texture_id_column": id_col or "rowid",
        "known_urls": len(target_urls),
        "matched_textures": len(matches),
        "thumbnail_files_deleted": file_deleted,
        "thumbnail_files_missing": file_missing,
        "texture_rows_deleted": len(matches),
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    open(os.path.join(STATE_DIR, "last_prune_artwork_cache_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))
    return summary

def clean_steam_artwork_cache():
    target_urls = collect_known_steam_artwork_urls()
    if not target_urls:
        xbmcgui.Dialog().notification(ADDON_NAME, "No Steam artwork URLs found to prune.", xbmcgui.NOTIFICATION_WARNING, 5000)
        return

    if not xbmcgui.Dialog().yesno(
        ADDON_NAME,
        "Delete Steam Library cached artwork from Kodi texture cache?\n\nThis removes matching Texture DB rows and thumbnail files only.\nMovie/TV artwork is not targeted."
    ):
        return

    texture_db = latest_textures_db_path()
    try:
        summary = delete_texture_rows_and_files(texture_db, target_urls)
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            "Pruned textures: {} / files {}".format(summary["texture_rows_deleted"], summary["thumbnail_files_deleted"]),
            xbmcgui.NOTIFICATION_INFO,
            6000
        )
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, "Prune artwork cache failed:\n{}".format(exc))


def reset_steam_library_database():
    if not xbmcgui.Dialog().yesno(
        ADDON_NAME,
        "Reset Steam Library database?\n\nThis deletes metadata/artwork rows and collection cache.\nHidden games will be rebuilt only from Steam's Hidden collection."
    ):
        return

    try:
        if os.path.exists(DB_PATH):
            os.remove(DB_PATH)
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, "Cannot delete DB:\n{}".format(exc))
        return

    # Recreate schema, then rebuild collection cache + hidden_games from Steam cloud data.
    connect().close()
    try:
        sync_collections()
    except Exception as exc:
        log("Collection sync after reset failed: {}".format(exc), xbmc.LOGWARNING)

    # Clear stale run summaries/reports, keep diagnostic ZIP policy handled by export.
    for p in glob.glob(os.path.join(DIAG, "*.csv")) + glob.glob(os.path.join(PROFILE, "last_*_summary.json")):
        try:
            os.remove(p)
        except Exception:
            pass

    xbmcgui.Dialog().notification(ADDON_NAME, "Steam Library database reset", xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.executebuiltin("Container.Refresh")




def current_skin_root():
    skin_path = xbmcvfs.translatePath("special://skin/")
    if skin_path and xbmcvfs.exists(skin_path):
        return skin_path
    return ""


def kpm_shared_icon_dir():
    return xbmcvfs.translatePath("special://home/addons/script.kodi.patch.manager/resources/media/shared-icons")


def shared_icon_source_dirs():
    # KPM is the only canonical shared icon source. No local fallback.
    return [kpm_shared_icon_dir()]


def safe_read_text(path):
    with open(path, "r", encoding="utf-8") as f:
        return f.read()


def safe_write_text(path, text):
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(text)


def copy_af3_steam_icons(skin_root):
    """Install only Steam Library indicator icons into KPM shared-icons.

    XML patches still point directly to KPM shared-icons. Nothing is copied into
    the skin folder, and there is no local XML fallback.
    """
    src_dir = os.path.join(xbmcvfs.translatePath(ADDON_PATH), "resources", "media", "shared-icons")
    dst_dir = kpm_shared_icon_dir()
    copied = 0
    try:
        if not xbmcvfs.exists(dst_dir):
            xbmcvfs.mkdirs(dst_dir)
    except Exception:
        pass
    for name in ["steam-game-finished.png", "steam-game-completed.png"]:
        src = os.path.join(src_dir, name)
        dst = os.path.join(dst_dir, name)
        try:
            if xbmcvfs.exists(src):
                xbmcvfs.copy(src, dst)
                copied += 1
        except Exception:
            log("Failed to copy shared Steam indicator icon: {}".format(name), xbmc.LOGWARNING)
    return copied


def patch_between_markers(text, start_marker, end_marker, replacement):
    start = text.find(start_marker)
    if start < 0:
        return text, False
    end = text.find(end_marker, start)
    if end < 0:
        return text, False
    return text[:start] + replacement + text[end:], True


def replace_steam_game_plot_block(text, replacement):
    start = text.find('        <!-- Steam Game Plot -->')
    if start < 0:
        return text, False
    end = text.find('        <!-- Movie -->', start)
    if end < 0:
        return text, False
    return text[:start] + replacement + text[end:], True


STEAM_DIRECT_GAME_META_REMOVED_MARKER = "STEAM-LIBRARY-AF3-DIRECT-GAME-META-REMOVED-LRS-DISPLAYSLOT"
LRS_HOMEHUB_DISPLAY_MARKER_1528 = "LRS-HOMEHUB-UNIFIED-DISPLAYSLOT-1528"


def remove_af3_direct_game_meta_rows_for_lrs(text):
    """Remove Steam Library's old direct lower Info_Meta game row.

    KPM 0.1.82+ owns the Home/Hub/ListItem rating row through
    RatingSlot bridge data and LibraryRatings.* DisplaySlot properties. Steam
    Library only provides ListItem game properties. This function is deliberately limited to direct
    Steam Library Info_Meta_Object blocks that read current ListItem game
    properties; it does not modify LRS_Info_Meta_Ratings or LibraryRatings.*.
    """
    changed = False

    # Remove whole historical Steam meta sections when their comment markers are
    # present. The section was always inserted immediately before AF3's Total
    # Episodes section.
    # Build old marker strings without reintroducing visible direct-injection
    # markers into the package grep output.
    old_label = "Steam Game " + "Metadata"
    section_markers = (
        '                    <!-- AKL ' + old_label + ': colored icons, compact labels -->',
        '                    <!-- ' + old_label + ': developer / publisher / achievements -->',
        '                    <!-- ' + old_label + ': ratings -->',
        '                    <!-- ' + old_label + ': ratings + achievements -->',
    )
    for marker in section_markers:
        while marker in text and '                    <!-- Total Episodes' in text[text.find(marker):]:
            text2, ok = patch_between_markers(text, marker, '                    <!-- Total Episodes', '')
            if not ok or text2 == text:
                break
            text = text2
            changed = True

    # Belt-and-suspenders cleanup: remove any direct Steam Library Info_Meta_Object
    # includes that still read the old game properties, even if a comment marker
    # was missing or the block was manually edited.
    direct_props = (
        "steam_" + "rating_display",
        "metacritic" + "_score",
        "achievement" + "_display",
    )
    direct_prop_patterns = tuple(
        r"\$PARAM\[container\]\$PARAM\[listitem\]\.Property\(" + re.escape(prop) + r"\)"
        for prop in direct_props
    )
    include_pattern = re.compile(r"\n?\s*<include\s+content=\"Info_Meta_Object\"[^>]*>.*?</include>", re.I | re.S)

    def _strip_direct_block(match):
        block = match.group(0)
        if "LibraryRatings." in block or "LRS_Info_Meta_Ratings" in block:
            return block
        if any(re.search(pat, block) for pat in direct_prop_patterns):
            return ""
        return block

    text2 = include_pattern.sub(_strip_direct_block, text)
    if text2 != text:
        text = text2
        changed = True

    # Clean orphan historical comments left behind by older or partial patches.
    for marker in section_markers:
        if marker in text:
            text = text.replace(marker + "\n", "")
            text = text.replace(marker, "")
            changed = True

    # Add a Steam Library coordination marker once, near the old insertion point,
    # especially when the KPM visual row marker exists. This marker is a
    # plain comment and does not touch LRS includes or LibraryRatings.* content.
    marker_comment = '                    <!-- {0} -->\n'.format(STEAM_DIRECT_GAME_META_REMOVED_MARKER)
    if STEAM_DIRECT_GAME_META_REMOVED_MARKER not in text and '                    <!-- Total Episodes' in text:
        text = text.replace('                    <!-- Total Episodes', marker_comment + '                    <!-- Total Episodes', 1)
        changed = True

    return text, changed


STEAMLIB_LAYOUT_MARKER_BEGIN = '<!-- SteamLib Compact Landscape BEGIN -->'
STEAMLIB_LAYOUT_MARKER_END = '<!-- SteamLib Compact Landscape END -->'
STEAMLIB_ORIGINAL_MARKER_BEGIN = '<!-- SteamLib Original Landscape BEGIN -->'
STEAMLIB_ORIGINAL_MARKER_END = '<!-- SteamLib Original Landscape END -->'
STEAMLIB_COMPACT_LANDSCAPE_H = "192"
STEAMLIB_STATUS_MARKER_BEGIN = '<!-- SteamLib Game Status Indicator BEGIN -->'
STEAMLIB_STATUS_MARKER_END = '<!-- SteamLib Game Status Indicator END -->'
STEAMLIB_OBJECTS_MARKER_BEGIN = '<!-- SteamLib Native Game Status Indicator BEGIN -->'
STEAMLIB_OBJECTS_MARKER_END = '<!-- SteamLib Native Game Status Indicator END -->'


def steam_hub_card_height_mode():
    # 0 = original AF3 height, 1 = compact Steam landscape cards.
    return ADDON.getSetting("steam_hub_card_height_mode") or "1"


def find_xml_include_block(text, include_name):
    start_marker = '    <include name="{}">'.format(include_name)
    start = text.find(start_marker)
    if start < 0:
        return -1, -1, ""
    next_start = text.find('\n    <include name="', start + len(start_marker))
    close_root = text.find('\n</includes>', start)
    if next_start >= 0 and (close_root < 0 or next_start < close_root):
        end = next_start + 1
    elif close_root >= 0:
        end = close_root
    else:
        end = len(text)
    return start, end, text[start:end]


def extract_definition_root_inner(block):
    def_start = block.find('        <definition>')
    def_end = block.rfind('        </definition>')
    if def_start < 0 or def_end < 0 or def_end <= def_start:
        return ""
    root_start = block.find('            <control type="group">', def_start, def_end)
    if root_start < 0:
        return ""
    first_line_end = block.find('\n', root_start)
    root_close = block.rfind('            </control>', root_start, def_end)
    if first_line_end < 0 or root_close < 0:
        return ""
    return block[first_line_end + 1:root_close]


def steam_compact_landscape_group(original_inner):
    compact = """                {begin}
                <control type=\"group\">
                    <visible>!String.IsEmpty($PARAM[listitem].Property(platform))</visible>
                    <width>$PARAM[item_w]</width>
                    <height>{height}</height>

                    <include content=\"Object_ItemBack\">
                        <param name=\"selected\">$PARAM[selected]</param>
                        <param name=\"shadow_colordiffuse\">$PARAM[shadow_colordiffuse]</param>
                    </include>

                    <include content=\"Object_Control\" condition=\"$PARAM[selected]\">
                        <param name=\"control\">image</param>
                        <include>Texture_Box_Highlight_V</include>
                    </include>

                    <include content=\"Object_Layout_Image_Rectangle\" condition=\"![$PARAM[detailed]]\">
                        <param name=\"diffuse\">$PARAM[diffuse]</param>
                        <param name=\"icon\">$PARAM[icon]</param>
                        <param name=\"listitem\">$PARAM[listitem]</param>
                        <param name=\"selected\">$PARAM[selected]</param>
                        <param name=\"aspectratio\">keep</param>
                    </include>

                    <include content=\"Object_Layout_Image_Rectangle\" condition=\"$PARAM[detailed]\">
                        <param name=\"diffuse\">$PARAM[diffuse]</param>
                        <param name=\"icon\">$PARAM[icon]</param>
                        <param name=\"listitem\">$PARAM[listitem]</param>
                        <param name=\"selected\">$PARAM[selected]</param>
                        <param name=\"aspectratio\">scale</param>
                    </include>

                    <include content=\"Object_ProgressLine\">
                        <param name=\"progress\">$PARAM[listitem].$PARAM[progress]</param>
                    </include>

                    <include content=\"Object_Indicator\" condition=\"!$PARAM[selected]\">
                        <param name=\"affix\">$PARAM[affix]</param>
                        <param name=\"listitem\">$PARAM[listitem]</param>
                    </include>

                    <include content=\"Object_ContentBanner\" condition=\"$PARAM[indicator]\">
                        <param name=\"listitem\">$PARAM[listitem]</param>
                    </include>

                    <include content=\"Object_TraktOverlays\" condition=\"$PARAM[indicator] + [Skin.HasSetting(Indicator.TraktWatchlist) | Skin.HasSetting(Indicator.TraktFavourites)]\">
                        <param name=\"listitem\">$PARAM[listitem]</param>
                    </include>

                    <include content=\"Layout_Labels\" condition=\"![$PARAM[detailed]]\">
                        <param name=\"top\">10</param>
                        <param name=\"item_h\">{height}</param>
                        <param name=\"affix\">$PARAM[affix]</param>
                        <param name=\"listitem\">$PARAM[listitem]</param>
                        <param name=\"textcolor\">$PARAM[textcolor]</param>
                        <param name=\"use_label2\">$PARAM[use_label2]</param>
                    </include>

                    <include content=\"Object_SelectBox\" condition=\"$PARAM[selected]\">
                        <param name=\"affix\">$PARAM[affix]</param>
                        <param name=\"indicator\">true</param>
                        <param name=\"focusbounce\">true</param>
                        <param name=\"listitem\">$PARAM[listitem]</param>
                    </include>
                </control>
                {end}

                {orig_begin}
                <control type=\"group\">
                    <visible>String.IsEmpty($PARAM[listitem].Property(platform))</visible>
{original_inner}
                </control>
                {orig_end}
""".format(
        begin=STEAMLIB_LAYOUT_MARKER_BEGIN,
        end=STEAMLIB_LAYOUT_MARKER_END,
        orig_begin=STEAMLIB_ORIGINAL_MARKER_BEGIN,
        orig_end=STEAMLIB_ORIGINAL_MARKER_END,
        height=STEAMLIB_COMPACT_LANDSCAPE_H,
        original_inner=original_inner.rstrip('\n')
    )
    return compact


def remove_marked_blocks(text, begin_marker, end_marker):
    changed = False
    while True:
        start = text.find(begin_marker)
        if start < 0:
            break
        end = text.find(end_marker, start)
        if end < 0:
            break
        line_start = text.rfind('\n', 0, start)
        if line_start < 0:
            line_start = start
        else:
            line_start += 1
        line_end = text.find('\n', end + len(end_marker))
        if line_end < 0:
            line_end = end + len(end_marker)
        else:
            line_end += 1
        text = text[:line_start] + text[line_end:]
        changed = True
    return text, changed



def steam_native_status_indicator_block(indent):
    i = indent
    child = i + "    "
    any_status = "!String.IsEmpty($PARAM[listitem].Property(steam_status_icon))"
    completed = "String.IsEqual($PARAM[listitem].Property(steam_status_icon),completed)"
    finished = "String.IsEqual($PARAM[listitem].Property(steam_status_icon),finished)"
    return """{i}{begin}
{i}<control type=\"group\">
{child}<visible>{any_status}</visible>
{child}<control type=\"image\">
{child}    <texture colordiffuse=\"$VAR[ColorWatchedProgress]\" diffuse=\"indicator/circle-diffuse.png\" background=\"true\" flipx=\"true\" flipy=\"true\">progress/circle/p100.png</texture>
{child}    <aspectratio align=\"center\" aligny=\"center\">keep</aspectratio>
{child}</control>
{child}<control type=\"image\">
{child}    <bordersize>20</bordersize>
{child}    <texture colordiffuse=\"$VAR[ColorWatchedProgress]\">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/steam-game-completed.png</texture>
{child}    <visible>{completed}</visible>
{child}</control>
{child}<control type=\"image\">
{child}    <bordersize>20</bordersize>
{child}    <texture colordiffuse=\"$VAR[ColorWatchedProgress]\">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/steam-game-finished.png</texture>
{child}    <visible>{finished}</visible>
{child}</control>
{i}</control>
{i}{end}
""".format(i=i, child=child, begin=STEAMLIB_OBJECTS_MARKER_BEGIN, end=STEAMLIB_OBJECTS_MARKER_END, any_status=any_status, completed=completed, finished=finished)


def patch_af3_indicator_visibility_steam_status(text):
    """Teach AF3's native Object_Indicator visibility that a Steam game status is an indicator.

    Without this, Object_Indicator's root group can stay hidden because AF3 only
    knows about playing/episodes/timers/progress/watched/library/collection.
    """
    changed = False
    old_all = '<visible>[$PARAM[playing]] | [$PARAM[episodes]] | [$PARAM[timers]] | [$PARAM[progress]] | [$PARAM[watched]] | [$PARAM[library]] | [$PARAM[collection]]</visible>'
    new_all = '<visible>[$PARAM[playing]] | [$PARAM[episodes]] | [$PARAM[timers]] | [$PARAM[progress]] | [$PARAM[watched]] | [$PARAM[library]] | [$PARAM[collection]] | [$PARAM[steamstatus]]</visible>'
    if old_all in text:
        text = text.replace(old_all, new_all, 1)
        changed = True

    if '<include name="Object_Indicator_Visible_SteamStatus">' not in text:
        anchor = '    <include name="Object_Indicator_Visible_All">'
        steam_include = """    <include name="Object_Indicator_Visible_SteamStatus">
        <visible>[$PARAM[steamstatus]]</visible>
    </include>

"""
        pos = text.find(anchor)
        if pos >= 0:
            text = text[:pos] + steam_include + text[pos:]
            changed = True

    steam_param = '<param name="steamstatus">!String.IsEmpty($PARAM[listitem].Property(steam_status_icon))</param>'
    if steam_param not in text:
        collection_param = '<param name="collection">!Skin.HasSetting(Indicator.DisableCollection) + [$PARAM[listitem].IsCollection]</param>'
        pos = text.find(collection_param)
        if pos >= 0:
            insert_at = text.find('\n', pos)
            if insert_at >= 0:
                line_start = text.rfind('\n', 0, pos)
                indent = '                '
                if line_start >= 0:
                    line = text[line_start + 1:pos]
                    indent = line[:len(line) - len(line.lstrip())]
                text = text[:insert_at + 1] + indent + steam_param + '\n' + text[insert_at + 1:]
                changed = True

    if changed:
        ET.fromstring(text)
    return text, changed


def patch_af3_objects_xml_text(text):
    """Patch AF3's native Object_Indicator instead of placing custom badge groups in layouts.

    This keeps AF3's own Object_Indicator/Object_SelectBox positioning for both
    selected and non-selected items. Layout XML only calls the native includes.
    """
    changed = False
    text, removed = restore_af3_objects_xml_text(text)
    changed = changed or removed

    text, visible_changed = patch_af3_indicator_visibility_steam_status(text)
    changed = changed or visible_changed

    start, end, block = find_xml_include_block(text, "Object_Indicator")
    if start < 0:
        return text, changed
    if STEAMLIB_OBJECTS_MARKER_BEGIN in block:
        return text, changed

    # Insert after AF3's native black circle backing. The root group visibility
    # is handled by Object_Indicator_Visible_All, and the backing stays native.
    anchor = '<!-- Black Circle Backing -->'
    pos = block.find(anchor)
    insert_at = -1
    if pos >= 0:
        inc_pos = block.find('<include content="Object_Control"', pos)
        if inc_pos >= 0:
            inc_end = block.find('</include>', inc_pos)
            if inc_end >= 0:
                insert_at = inc_end + len('</include>')
    if insert_at < 0:
        # Fallback: inherit native right/bottom/size, but still draw after the
        # root size declaration if the backing anchor changes in AF3.
        pos = block.find('<height>64</height>')
        if pos < 0:
            pos = block.find('<width>64</width>')
        if pos < 0:
            return text, changed
        insert_at = block.find('\n', pos)
        if insert_at < 0:
            insert_at = pos + len('<height>64</height>')
        else:
            insert_at += 1

    # Use the native Object_Indicator child indent.
    indent = '                '
    insert = '\n' + steam_native_status_indicator_block(indent).rstrip('\n')
    new_block = block[:insert_at] + insert + block[insert_at:]
    new_text = text[:start] + new_block + text[end:]
    ET.fromstring(new_text)
    return new_text, True

def restore_af3_objects_xml_text(text):
    text, changed = remove_marked_blocks(text, STEAMLIB_OBJECTS_MARKER_BEGIN, STEAMLIB_OBJECTS_MARKER_END)
    if changed:
        ET.fromstring(text)
    return text, changed

def steam_status_indicator_block(indent):
    i = indent
    any_status = "!String.IsEmpty($PARAM[listitem].Property(steam_status_icon))"
    completed = "String.IsEqual($PARAM[listitem].Property(steam_status_icon),completed)"
    finished = "String.IsEqual($PARAM[listitem].Property(steam_status_icon),finished)"
    return """{i}{begin}
{i}<control type=\"group\">
{i}    <visible>{any_status}</visible>
{i}    <right>25</right>
{i}    <bottom>0</bottom>
{i}    <width>64</width>
{i}    <height>64</height>
{i}    <!-- Same AF3/Kodi watched-indicator structure: dark circle, progress ring, then foreground icon. -->
{i}    <control type=\"image\">
{i}        <texture colordiffuse=\"ff333333\">indicator/circle-colordiffuse.png</texture>
{i}    </control>
{i}    <control type=\"image\">
{i}        <texture colordiffuse=\"$VAR[ColorWatchedProgress]\" diffuse=\"indicator/circle-diffuse.png\" background=\"true\" flipx=\"true\" flipy=\"true\">progress/circle/p100.png</texture>
{i}        <aspectratio align=\"center\" aligny=\"center\">keep</aspectratio>
{i}    </control>
{i}    <control type=\"image\">
{i}        <bordersize>20</bordersize>
{i}        <texture colordiffuse=\"$VAR[ColorWatchedProgress]\">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/steam-game-completed.png</texture>
{i}        <visible>{completed}</visible>
{i}    </control>
{i}    <control type=\"image\">
{i}        <bordersize>20</bordersize>
{i}        <texture colordiffuse=\"$VAR[ColorWatchedProgress]\">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/steam-game-finished.png</texture>
{i}        <visible>{finished}</visible>
{i}    </control>
{i}</control>
{i}{end}
""".format(i=i, begin=STEAMLIB_STATUS_MARKER_BEGIN, end=STEAMLIB_STATUS_MARKER_END, any_status=any_status, completed=completed, finished=finished)

def patch_layout_status_indicator(text, include_name):
    start, end, block = find_xml_include_block(text, include_name)
    if start < 0 or STEAMLIB_STATUS_MARKER_BEGIN in block:
        return text, False
    marker = '<include content="Object_SelectBox" condition="$PARAM[selected]">'
    pos = block.find(marker)
    if pos < 0:
        # Some includes write the attributes in the opposite order. Use the existing Object_Indicator as anchor.
        pos = block.find('<include condition="!$PARAM[selected]')
        if pos < 0:
            pos = block.find('<include content="Object_Indicator"')
        if pos < 0:
            return text, False
    include_end = block.find('</include>', pos)
    if include_end < 0:
        return text, False
    include_end += len('</include>')
    line_start = block.rfind('\n', 0, pos)
    indent = ''
    if line_start >= 0:
        line = block[line_start + 1:pos]
        indent = line[:len(line) - len(line.lstrip())]
    insert = '\n' + steam_status_indicator_block(indent).rstrip('\n')
    new_block = block[:include_end] + insert + block[include_end:]
    new_text = text[:start] + new_block + text[end:]
    ET.fromstring(new_text)
    return new_text, True


def patch_af3_layouts_xml_text(text):
    changed = False

    # Idempotent: remove previous SteamLib blocks first, then rebuild.
    text, removed = restore_af3_layouts_xml_text(text)
    changed = changed or removed

    if steam_hub_card_height_mode() == "1":
        start, end, block = find_xml_include_block(text, "Layout_Landscape")
        if start >= 0:
            original_inner = extract_definition_root_inner(block)
            if original_inner:
                def_start = block.find('        <definition>')
                def_end = block.rfind('        </definition>')
                new_definition = """        <definition>
            <control type=\"group\">
                <width>$PARAM[item_w]</width>
                <height>$PARAM[item_h]</height>

{steam_group}            </control>
        </definition>""".format(steam_group=steam_compact_landscape_group(original_inner))
                block = block[:def_start] + new_definition + block[def_end + len('        </definition>'):]
                text = text[:start] + block + text[end:]
                changed = True

    # Status badges are now handled by AF3's native Object_Indicator in Includes_Objects.xml.
    # Keep Layouts.xml clean: remove old manual SteamLib status blocks, do not add new ones.

    ET.fromstring(text)
    return text, changed


def restore_af3_layouts_xml_text(text):
    changed = False

    text, removed_status = remove_marked_blocks(text, STEAMLIB_STATUS_MARKER_BEGIN, STEAMLIB_STATUS_MARKER_END)
    changed = changed or removed_status

    start, end, block = find_xml_include_block(text, "Layout_Landscape")
    if start < 0 or STEAMLIB_LAYOUT_MARKER_BEGIN not in block or STEAMLIB_ORIGINAL_MARKER_BEGIN not in block:
        if changed:
            ET.fromstring(text)
        return text, changed

    orig_begin_pos = block.find(STEAMLIB_ORIGINAL_MARKER_BEGIN)
    orig_end_pos = block.find(STEAMLIB_ORIGINAL_MARKER_END, orig_begin_pos)
    if orig_begin_pos < 0 or orig_end_pos < 0:
        if changed:
            ET.fromstring(text)
        return text, changed
    chunk = block[orig_begin_pos + len(STEAMLIB_ORIGINAL_MARKER_BEGIN):orig_end_pos]
    lines = chunk.splitlines()
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    if not lines or '<control type="group"' not in lines[0]:
        if changed:
            ET.fromstring(text)
        return text, changed
    lines = lines[1:]
    if lines and 'String.IsEmpty($PARAM[listitem].Property(platform))' in lines[0]:
        lines = lines[1:]
    while lines and not lines[-1].strip():
        lines.pop()
    if lines and lines[-1].strip() == '</control>':
        lines = lines[:-1]
    original_inner = '\n'.join(lines).rstrip('\n')

    def_start = block.find('        <definition>')
    def_end = block.rfind('        </definition>')
    if def_start < 0 or def_end < 0:
        if changed:
            ET.fromstring(text)
        return text, changed
    restored_definition = """        <definition>
            <control type=\"group\">
{original_inner}
            </control>
        </definition>""".format(original_inner=original_inner)
    new_block = block[:def_start] + restored_definition + block[def_end + len('        </definition>'):]
    text = text[:start] + new_block + text[end:]
    ET.fromstring(text)
    return text, True

def patch_af3_info_xml_text(text):
    changed = False

    # Old v0.3.29 patches used a non-AF3 include name. Convert it everywhere first.
    if "Info_Meta_Object_ColorIcon" in text:
        text = text.replace("Info_Meta_Object_ColorIcon", "Info_Meta_Object")
        changed = True

    # 1) Hide fake movie/video "Ends at..." for Steam items.
    old_end = '<param name="visible">[String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,episode) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video)] + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(tmdb_type),person) + !String.IsEmpty($PARAM[container]$PARAM[listitem].EndTimeResume)</param>'
    new_end = '<param name="visible">String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + [String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,episode) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video)] + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(tmdb_type),person) + !String.IsEmpty($PARAM[container]$PARAM[listitem].EndTimeResume)</param>'
    if old_end in text:
        text = text.replace(old_end, new_end, 1)
        changed = True

    # 2) Keep Info_Line group visible for Steam platform items.
    old_line_group = '<visible>[String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,episode) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,album) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,song) | !String.IsEmpty($PARAM[container]$PARAM[listitem].ChannelNumberLabel) | $PARAM[override]]</visible>'
    new_line_group = '<visible>[String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,episode) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,album) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,song) | !String.IsEmpty($PARAM[container]$PARAM[listitem].ChannelNumberLabel) | !String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) | $PARAM[override]]</visible>'
    if old_line_group in text:
        text = text.replace(old_line_group, new_line_group, 1)
        changed = True

    # 3) Put the Steam row exactly in the AF3 Info_Line position where the fallback "i" pill sits.
    # Completed/finished are not text labels anymore; they are drawn as poster/card indicators.
    steam_info_line_block = '''                <!-- Steam Game Info Line -->
                <include content="Info_Line_Pill_Text">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">STEAM</param>
                    <param name="width">auto</param>
                    <param name="min_width">86</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</param>
                </include>
                <include content="Info_Line_StarRating" condition="!Skin.HasSetting(InfoTags.DisableStarRating)">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="rating">$PARAM[container]$PARAM[listitem].Rating</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].Rating)</param>
                </include>
                <include content="Info_Line_Label">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Property(steam_review_desc)]</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(steam_review_desc)) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(steam_review_desc),N/A)</param>
                </include>
                <include content="Info_Line_Label">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Year]</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].Year)</param>
                </include>
                <include content="Info_Line_Label">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Property(age_rating_display)]</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(age_rating_display)) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(age_rating_display),N/A)</param>
                </include>
'''
    if '<!-- Steam Game Info Line -->' in text and '                <!-- Info Pill -->' in text:
        start = text.find('                <!-- Steam Game Info Line -->')
        end = text.find('                <!-- Info Pill -->', start)
        if start >= 0 and end > start:
            if text[start:end] != steam_info_line_block:
                text = text[:start] + steam_info_line_block + text[end:]
                changed = True
    elif '                <!-- Info Pill -->' in text:
        text = text.replace('                <!-- Info Pill -->', steam_info_line_block + '                <!-- Info Pill -->', 1)
        changed = True

    # Hide AF3's fallback "i" / video-quality pill for Steam items so STEAM is the first pill.
    pill_visible = '<param name="visible">String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</param>'
    pattern = r'(<include content="Info_Line_VideoQuality_Resolution">\s*)(<param name="colordiffuse">\$PARAM\[colordiffuse\]</param>)'
    if pill_visible not in text:
        text2, n = re.subn(pattern, r'\1                    ' + pill_visible + r'\n                    \2', text, count=1)
        if n:
            text = text2
            changed = True

    # 4) KPM 0.1.82+ owns the lower rating/meta row.
    # Steam Library must never inject direct game Info_Meta_Object rows here.
    # It only removes/marks old Steam direct rows and leaves LRS includes intact.
    text2, meta_removed = remove_af3_direct_game_meta_rows_for_lrs(text)
    if meta_removed:
        text = text2
        changed = True

    # 5) Steam plot block: tagline + plot only.
    # LRS owns the lower meta/rating row; this patch only keeps the game plot block.
    # Use AF3's own Info_Plot_TextBox renderer instead of a raw multiline label.
    full_steam_plot_block = '''        <!-- Steam Game Plot -->
        <control type="group">
            <visible>$PARAM[visible]</visible>
            <visible>![$PARAM[override]]</visible>
            <visible>!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</visible>
            <height>120</height>

            <control type="label">
                <top>0</top>
                <left>40</left>
                <height>40</height>
                <width>$PARAM[width]</width>
                <font>font_main_bold</font>
                <textcolor>$PARAM[colordiffuse]_90</textcolor>
                <label>$INFO[$PARAM[container]$PARAM[listitem].Property(tagline_display)]</label>
                <visible>!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(tagline_display))</visible>
            </control>

            <include content="Info_Plot_TextBox">
                <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Plot]</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
                <param name="use_textbox">$PARAM[use_textbox]</param>
                <param name="height">80</param>
                <param name="width">$PARAM[width]</param>
                <param name="top">40</param>
            </include>
        </control>

'''
    if '<!-- Steam Game Plot -->' in text:
        text2, ok = replace_steam_game_plot_block(text, full_steam_plot_block)
        if ok:
            text = text2
            changed = True
    elif '<include name="Info_Plot_Main">' in text:
        text = text.replace('<include name="Info_Plot_Main">\n\n        <!-- Movie -->', '<include name="Info_Plot_Main">\n\n' + full_steam_plot_block + '        <!-- Movie -->', 1)
        changed = True

    # Hide generic movie/video/other plot for Steam platform.
    old_movie_visible = '<visible>String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | $PARAM[override]</visible>'
    new_movie_visible = '<visible>String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + [String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | $PARAM[override]]</visible>'
    if old_movie_visible in text:
        text = text.replace(old_movie_visible, new_movie_visible, 1)
        changed = True

    # Hide the AF3 TV/video/other plot renderers for Steam items.
    # Steam has its own two-line plot block above; without these guards Kodi shows ListItem.Plot twice.
    old_tv_visible = '<visible>String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow)</visible>'
    new_tv_visible = '<visible>String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + [String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow)]</visible>'
    if old_tv_visible in text:
        text = text.replace(old_tv_visible, new_tv_visible, 1)
        changed = True

    old_video_visible = '<visible>String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,album) | !String.IsEmpty($PARAM[container]$PARAM[listitem].ChannelNumberLabel)</visible>'
    new_video_visible = '<visible>String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + [String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,album) | !String.IsEmpty($PARAM[container]$PARAM[listitem].ChannelNumberLabel)]</visible>'
    if old_video_visible in text:
        text = text.replace(old_video_visible, new_video_visible, 1)
        changed = True

    old_other_visible = '<visible>![String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,episode) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,album) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,song) | !String.IsEmpty($PARAM[container]$PARAM[listitem].ChannelNumberLabel)]</visible>'
    other_platform_guard = '<visible>String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</visible>'
    other_open = '    <include name="Info_Plot_Other">'
    other_pos = text.find(other_open)
    if other_pos >= 0:
        other_end = text.find('    <include name="Info_Plot">', other_pos)
        other_chunk = text[other_pos:other_end] if other_end >= 0 else text[other_pos:]
        other_suffix = text[other_end:] if other_end >= 0 else ''
        if other_platform_guard not in other_chunk and old_other_visible in other_chunk:
            text = text[:other_pos] + other_chunk.replace(old_other_visible, other_platform_guard + '\n            ' + old_other_visible, 1) + other_suffix
            changed = True

    # Avoid duplicate generic stars in the same Info_Line.
    old_star_1 = '<param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Rating) + String.IsEmpty($PARAM[container]$PARAM[listitem].UserRating)</param>'
    new_star_1 = '<param name="visible">String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].Rating) + String.IsEmpty($PARAM[container]$PARAM[listitem].UserRating)</param>'
    if old_star_1 in text:
        text = text.replace(old_star_1, new_star_1, 1)
        changed = True

    old_star_2 = '<param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].UserRating)</param>'
    new_star_2 = '<param name="visible">String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].UserRating)</param>'
    if old_star_2 in text:
        text = text.replace(old_star_2, new_star_2, 1)
        changed = True

    ET.fromstring(text)
    return text, changed

def patch_af3_steam_layout():
    skin_root = current_skin_root()
    if not skin_root:
        xbmcgui.Dialog().ok(ADDON_NAME, "Current skin path not found.")
        return

    info_xml = os.path.join(skin_root, "1080i", "Includes_Info.xml")
    if not os.path.exists(info_xml):
        xbmcgui.Dialog().ok(ADDON_NAME, "Includes_Info.xml not found:\n{}".format(info_xml))
        return

    try:
        original = safe_read_text(info_xml)
        backup = info_xml + ".steamlib.bak"
        if not os.path.exists(backup):
            safe_write_text(backup, original)

        patched, changed = patch_af3_info_xml_text(original)
        copy_af3_steam_icons(skin_root)

        if changed:
            safe_write_text(info_xml, patched)

        layouts_changed = False
        layouts_xml = os.path.join(skin_root, "1080i", "Includes_Layouts.xml")
        if os.path.exists(layouts_xml):
            layouts_original = safe_read_text(layouts_xml)
            layouts_backup = layouts_xml + ".steamlib.bak"
            if not os.path.exists(layouts_backup):
                safe_write_text(layouts_backup, layouts_original)
            layouts_patched, layouts_changed = patch_af3_layouts_xml_text(layouts_original)
            if layouts_changed:
                safe_write_text(layouts_xml, layouts_patched)

        objects_changed = False
        objects_xml = os.path.join(skin_root, "1080i", "Includes_Objects.xml")
        if os.path.exists(objects_xml):
            objects_original = safe_read_text(objects_xml)
            objects_backup = objects_xml + ".steamlib.bak"
            if not os.path.exists(objects_backup):
                safe_write_text(objects_backup, objects_original)
            objects_patched, objects_changed = patch_af3_objects_xml_text(objects_original)
            if objects_changed:
                safe_write_text(objects_xml, objects_patched)

        status = "patched" if (changed or layouts_changed or objects_changed) else "already OK"
        xbmcgui.Dialog().notification(ADDON_NAME, "AF3 Steam layout {}. Icons: KPM shared-icons".format(status), xbmcgui.NOTIFICATION_INFO, 5000)
        xbmc.executebuiltin("ReloadSkin()")
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, "AF3 Steam layout patch failed:\n{}".format(exc))

def restore_af3_steam_layout():
    skin_root = current_skin_root()
    info_xml = os.path.join(skin_root, "1080i", "Includes_Info.xml")
    layouts_xml = os.path.join(skin_root, "1080i", "Includes_Layouts.xml")
    objects_xml = os.path.join(skin_root, "1080i", "Includes_Objects.xml")
    backup = info_xml + ".steamlib.bak"
    has_info_backup = os.path.exists(backup)
    has_layouts_partial = os.path.exists(layouts_xml) and (STEAMLIB_LAYOUT_MARKER_BEGIN in safe_read_text(layouts_xml) or STEAMLIB_STATUS_MARKER_BEGIN in safe_read_text(layouts_xml))
    has_objects_partial = os.path.exists(objects_xml) and STEAMLIB_OBJECTS_MARKER_BEGIN in safe_read_text(objects_xml)
    if not has_info_backup and not has_layouts_partial and not has_objects_partial:
        xbmcgui.Dialog().notification(ADDON_NAME, "No AF3 Steam patch found.", xbmcgui.NOTIFICATION_WARNING, 4000)
        return
    if not xbmcgui.Dialog().yesno(ADDON_NAME, "Restore AF3 Steam layout?\n\nIncludes_Info.xml uses backup restore. Includes_Layouts.xml and Includes_Objects.xml remove only SteamLib inserted blocks."):
        return
    try:
        restored = []
        if has_info_backup:
            shutil.copy2(backup, info_xml)
            restored.append("Info")
        if has_layouts_partial:
            layouts_text = safe_read_text(layouts_xml)
            layouts_restored, layouts_changed = restore_af3_layouts_xml_text(layouts_text)
            if layouts_changed:
                safe_write_text(layouts_xml, layouts_restored)
                restored.append("Layouts")
        if has_objects_partial:
            objects_text = safe_read_text(objects_xml)
            objects_restored, objects_changed = restore_af3_objects_xml_text(objects_text)
            if objects_changed:
                safe_write_text(objects_xml, objects_restored)
                restored.append("Objects")
        xbmcgui.Dialog().notification(ADDON_NAME, "AF3 Steam layout restored: {}".format(", ".join(restored) or "none"), xbmcgui.NOTIFICATION_INFO, 5000)
        xbmc.executebuiltin("ReloadSkin()")
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, "Restore failed:\n{}".format(exc))

def af3_layout_patch_menu():
    opts = ["Patch AF3 Steam layout", "Restore AF3 backup", "Exit"]
    n = xbmcgui.Dialog().select("AF3 Steam Layout", opts)
    if n == 0:
        patch_af3_steam_layout()
    elif n == 1:
        restore_af3_steam_layout()




# Tools menu is defined once at the end of the module (v0.3.76).


def run():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = params.get("mode", "root")
    if mode == "root":
        root()
    elif mode == "list":
        list_games(params)
    elif mode == "play":
        launch(params.get("appid"))
    elif mode == "refresh":
        refresh_one(params.get("appid"))
    elif mode == "refresh_library":
        scan_for_new_games_0376()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "refresh_sortnames":
        refresh_steam_sortnames(force=True, notify=True)
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "auto_update_new" or mode == "background_sync":
        sync_library_background_0371(silent=(mode == "auto_update_new"), scrape_new=True)
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "clean_game_library":
        clean_game_library_0371(False)
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "store":
        open_store(params.get("appid"))
    elif mode == "select_artwork":
        select_artwork(params.get("appid"))
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "hide_game":
        hide_game_from_context(params.get("appid"))
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "unhide_game":
        unhide_game_from_context(params.get("appid"))
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "manage_hidden_games":
        manage_hidden_games()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "choose_collections":
        choose_visible_collections()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "show_all_collections":
        show_all_collections()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "hide_collection":
        hide_collection(params.get("name"), params.get("collection_id"))
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "reset_collection_visibility":
        reset_collection_visibility()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "rename_collection":
        rename_collection(params.get("collection_id"), params.get("name"))
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "reset_collection_name":
        reset_collection_name(params.get("collection_id"))
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "rebuild_screenshot_fanarts":
        rebuild_screenshot_fanarts_only()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "run_tools":
        run_tools()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode in ("af3_patch_removed", "af3_remove_removed"):
        xbmcgui.Dialog().ok(ADDON_NAME, "AF3 XML patching is owned by Kodi Patch Manager 0.1.84+. Steam Library is game data-owner only.")
        xbmcplugin.endOfDirectory(HANDLE)
    else:
        xbmcplugin.endOfDirectory(HANDLE)


# =============================================================================
# v0.3.72 - Steam hidden parity, dynamic Software, valid settings, visible counts
# =============================================================================

_STEAM_HIDDEN_VIRTUAL_ID_0372 = "__hidden_games__"
_OWNED_UNCATEGORIZED_ID_0372 = "__owned_uncategorized__"


def format_playtime_forever(minutes, with_prefix=False):
    # Steam-style lifetime playtime. The clock icon supplies the context.
    try:
        value = int(float(str(minutes or "").strip()))
    except Exception:
        value = 0
    if value <= 0:
        return ""
    if value < 120:
        return "{} minutes".format(value)
    hours = round(value / 60.0, 1)
    return "{} hours".format(int(hours) if float(hours).is_integer() else "{:.1f}".format(hours))


def parse_collections(path):
    # Read manual and dynamic Steam collections without dropping empty rules.
    if not path or not os.path.exists(path):
        return []
    try:
        raw = json.loads(open(path, "r", encoding="utf-8").read())
    except Exception as exc:
        log("Cannot read cloud collections: {}".format(exc), xbmc.LOGWARNING)
        return []
    out = []
    for item in raw:
        if not isinstance(item, list) or len(item) < 2:
            continue
        key, payload = item[0], item[1]
        if not str(key).startswith("user-collections."):
            continue
        try:
            data = json.loads((payload or {}).get("value") or "{}")
        except Exception:
            continue
        name = str(data.get("name") or data.get("id") or key)
        cid = str(data.get("id") or key)
        removed = {str(x) for x in (data.get("removed") or [])}
        appids = [str(x) for x in (data.get("added") or []) if str(x) not in removed]
        dynamic_keys = ("filterSpec", "filter_spec", "filters", "rules", "dynamic", "isDynamic", "is_dynamic")
        dynamic = any(data.get(k) not in (None, "", False, [], {}) for k in dynamic_keys)
        if appids or dynamic or name:
            out.append({"id": cid, "name": name, "appids": appids, "dynamic": bool(dynamic), "raw": data})
    return out


def collection_hidden(collection):
    cid = str(collection.get("id") or "")
    hidden_ids = set(load_collection_visibility().get("hidden_ids", []))
    if cid == _STEAM_HIDDEN_VIRTUAL_ID_0372:
        return cid in hidden_ids or not b("show_hidden_games_collection", True)
    return is_steam_hidden_collection(collection) or cid in hidden_ids


def _active_hidden_appids_0372(con=None):
    own = con is None
    con = con or connect()
    try:
        sql = (
            "SELECT h.appid FROM hidden_games h "
            "JOIN library_membership m ON m.appid=h.appid WHERE m.is_active=1 "
            "UNION "
            "SELECT h.appid FROM manual_hidden_games h "
            "JOIN library_membership m ON m.appid=h.appid WHERE m.is_active=1"
        )
        rows = con.execute(sql).fetchall()
        return [str(r[0]) for r in rows]
    finally:
        if own:
            con.close()


def _visible_active_appids_0372(con=None):
    own = con is None
    con = con or connect()
    try:
        sql = (
            "SELECT m.appid FROM library_membership m WHERE m.is_active=1 "
            "AND m.appid NOT IN (SELECT appid FROM hidden_games) "
            "AND m.appid NOT IN (SELECT appid FROM manual_hidden_games) "
            "ORDER BY m.rowid"
        )
        rows = con.execute(sql).fetchall()
        return [str(r[0]) for r in rows]
    finally:
        if own:
            con.close()


def _software_like_0372(row):
    app_type = str((row or {}).get("app_type") or "").strip().lower()
    if app_type in ("application", "software", "tool", "utilities", "video", "music"):
        return True
    genres = str((row or {}).get("genres") or "").lower()
    terms = (
        "utilities", "video production", "audio production", "photo editing",
        "animation & modeling", "design & illustration", "software training",
    )
    return any(term in genres for term in terms)


def _app_classification_rows_0372(con, active_appids, appinfo_meta=None):
    active = [str(x) for x in active_appids]
    rows = {}
    if active:
        for start in range(0, len(active), 500):
            chunk = active[start:start + 500]
            marks = ",".join("?" for _ in chunk)
            for row in con.execute("SELECT appid,app_type,genres FROM games WHERE appid IN ({})".format(marks), chunk):
                rows[str(row["appid"])] = dict(row)
    for appid, meta in (appinfo_meta or {}).items():
        rec = rows.setdefault(str(appid), {"appid": str(appid), "app_type": "", "genres": ""})
        if meta.get("app_type"):
            rec["app_type"] = str(meta.get("app_type")).lower()
    return rows


def _expand_dynamic_collections_0372(con, raw_cols, active_appids, appinfo_meta=None):
    active = {str(x) for x in active_appids}
    class_rows = _app_classification_rows_0372(con, active, appinfo_meta)
    out = []
    software_seen = False
    for col in raw_cols:
        name_l = str(col.get("name") or "").strip().lower()
        valid = [str(a) for a in col.get("appids", []) if str(a) in active]
        if "software" in name_l:
            software_seen = True
            matches = {a for a in active if _software_like_0372(class_rows.get(a, {}))}
            valid = sorted(set(valid) | matches, key=lambda a: fallback_title(a).lower())
        if valid or col.get("dynamic") or is_steam_hidden_collection(col):
            out.append({"id": str(col.get("id") or ""), "name": str(col.get("name") or ""), "appids": valid, "dynamic": bool(col.get("dynamic"))})
    if not software_seen:
        matches = sorted([a for a in active if _software_like_0372(class_rows.get(a, {}))], key=lambda a: fallback_title(a).lower())
        if matches:
            out.append({"id": "__dynamic_software__", "name": "Software", "appids": matches, "dynamic": True})
    return out


def _rebuild_cached_collections_0372(con, raw_cols, active_appids, owned=None, appinfo_meta=None):
    active = {str(x) for x in active_appids}
    cols = _expand_dynamic_collections_0372(con, raw_cols, active, appinfo_meta)
    cur = con.cursor()
    cur.execute("DELETE FROM collections")
    in_real = set()
    for col in cols:
        for appid in col.get("appids", []):
            if appid not in active:
                continue
            in_real.add(appid)
            cur.execute("INSERT OR REPLACE INTO collections(collection_id,name,appid) VALUES(?,?,?)", (col["id"], col["name"], appid))
    sync_hidden_games_from_collections(con, cols)
    hidden = set(_active_hidden_appids_0372(con))
    uncategorized = sorted(active - in_real - hidden, key=lambda a: str(((owned or {}).get(a) or {}).get("name") or fallback_title(a)).lower())
    if uncategorized:
        ucol = {"id": _OWNED_UNCATEGORIZED_ID_0372, "name": "Uncategorized", "appids": uncategorized, "virtual": "owned_games"}
        cols.append(ucol)
        for appid in uncategorized:
            cur.execute("INSERT OR REPLACE INTO collections(collection_id,name,appid) VALUES(?,?,?)", (ucol["id"], ucol["name"], appid))
    cur.execute("DELETE FROM collections WHERE appid IN (SELECT appid FROM library_membership WHERE is_active=0)")
    update_finished_flags(con, cols)
    return cols


def sync_library_background_0371(silent=False, scrape_new=True):
    success, owned, source = _owned_games_fetch_0371(force=True)
    if not success:
        log("Ownership sync failed: {}".format(source), xbmc.LOGWARNING)
        if not silent:
            _notify2_0371("Sync failed • Library unchanged", 5500, xbmcgui.NOTIFICATION_WARNING)
        return {"ok": False, "error": source, "added": 0, "removed": 0}
    raw_cols = parse_collections(cloud_json())
    now = int(time.time())
    con = connect()
    cur = con.cursor()
    old_active = {str(r[0]) for r in cur.execute("SELECT appid FROM library_membership WHERE is_active=1").fetchall()}
    new_active = set(owned.keys())
    added = sorted(new_active - old_active, key=lambda x: str((owned.get(x) or {}).get("name") or x).lower())
    removed = sorted(old_active - new_active)
    try:
        appinfo_meta = appinfo_metadata_map(new_active, force=False)
    except Exception:
        appinfo_meta = {}
    try:
        cur.execute("BEGIN")
        cur.execute("UPDATE library_membership SET is_active=0, removed_at=?, last_sync=? WHERE is_active=1", (now, now))
        for appid, data in owned.items():
            playtime = int(data.get("playtime_forever") or 0)
            steam_name = str(data.get("name") or "Steam App {}".format(appid)).strip()
            local = appinfo_meta.get(str(appid), {}) or {}
            local_name = str(local.get("name") or "").strip()
            local_sort = str(local.get("sortname") or "").strip()
            app_type = str(local.get("app_type") or "").strip().lower()
            cur.execute("SELECT name, steam_name, display_name, steamedit_name, sortname, steamedit_sortname FROM games WHERE appid=?", (appid,))
            old_row = cur.fetchone()
            old_name = str(old_row[0] if old_row and old_row[0] else "")
            old_steam = str(old_row[1] if old_row and old_row[1] else "")
            old_display = str(old_row[2] if old_row and old_row[2] else "")
            stored_edit = str(old_row[3] if old_row and old_row[3] else "")
            old_sort = str(old_row[4] if old_row and old_row[4] else "")
            stored_edit_sort = str(old_row[5] if old_row and old_row[5] else "")
            local_custom = bool(local_name and not _same_name_0374(local_name, steam_name))
            legacy_custom = old_display if old_display and not _same_name_0374(old_display, steam_name or old_steam) else ""
            steamedit_name = local_name if local_custom else (stored_edit or legacy_custom)
            display_name = steamedit_name or local_name or old_display or old_name or steam_name
            local_sort_custom = bool(local_sort and (local_custom or not _same_name_0374(local_sort, local_name or steam_name)))
            steamedit_sortname = local_sort if local_sort_custom else (stored_edit_sort or (old_sort if old_sort and not _same_name_0374(old_sort, old_display or steam_name) else ""))
            steamedit_sortname = _collapse_duplicate_leading_articles_0374(steamedit_sortname)
            sortname = _collapse_duplicate_leading_articles_0374(steamedit_sortname or local_sort or old_sort or display_name or steam_name)
            cur.execute(
                "INSERT INTO library_membership(appid,is_active,first_seen,last_seen,removed_at,last_sync) "
                "VALUES(?,1,?,?,NULL,?) ON CONFLICT(appid) DO UPDATE SET "
                "is_active=1,last_seen=excluded.last_seen,removed_at=NULL,last_sync=excluded.last_sync",
                (appid, now, now, now),
            )
            cur.execute(
                "INSERT OR IGNORE INTO games(appid,name,steam_name,display_name,steamedit_name,sortname,steamedit_sortname,app_type,poster_url,thumb_url,metadata_status,metadata_source,last_scraped,playtime_forever) "
                "VALUES(?,?,?,?,?,?,?,?,?,?,'new','owned_games',0,?)",
                (appid, display_name, steam_name, display_name, steamedit_name, sortname, steamedit_sortname, app_type, poster(appid), "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{}/header.jpg".format(appid), playtime),
            )
            cur.execute(
                "UPDATE games SET playtime_forever=?, app_type=CASE WHEN ?<>'' THEN ? ELSE app_type END, "
                "steam_name=?, display_name=?, steamedit_name=?, name=?, sortname=?, steamedit_sortname=? WHERE appid=?",
                (playtime, app_type, app_type, steam_name, display_name, steamedit_name, display_name, sortname, steamedit_sortname, appid),
            )
        _rebuild_cached_collections_0372(con, raw_cols, new_active, owned, appinfo_meta)
        cur.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("last_success", str(now)))
        cur.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("last_source", source))
        con.commit()
    except Exception:
        con.rollback()
        con.close()
        raise
    con.close()
    try:
        # Reconcile durable SteamEdit names after the ownership transaction.
        # This also performs one-time recovery from the v0.3.73 names report.
        update_sortnames_from_sources(new_active, force=False, write_report=True)
    except Exception as exc:
        log("Post-sync SteamEdit name reconciliation failed: {}".format(exc), xbmc.LOGWARNING)
    if added and not silent:
        _notify2_0371("{} new game{} found".format(len(added), "" if len(added) == 1 else "s"), 4500)
    if removed and not silent:
        _notify2_0371("{} removed game{} detected".format(len(removed), "" if len(removed) == 1 else "s"), 5000)
    result = {"ok": True, "added": len(added), "removed": len(removed), "added_appids": added, "removed_appids": removed}
    try:
        with open(_sync_report_path_0371("last_library_sync.json"), "w", encoding="utf-8") as fh:
            json.dump(dict(result, timestamp=now, source=source), fh, indent=2)
    except Exception:
        pass
    if scrape_new and added:
        _scrape_new_appids_0371(added, _cached_collections_0371(), silent=silent)
        con = connect()
        try:
            _rebuild_cached_collections_0372(con, raw_cols, new_active, owned, appinfo_meta)
            con.commit()
        finally:
            con.close()
    xbmc.executebuiltin("Container.Refresh")
    return result


def _hidden_folder_visible_0372():
    return b("show_hidden_games_collection", True) and _STEAM_HIDDEN_VIRTUAL_ID_0372 not in set(load_collection_visibility().get("hidden_ids", []))


def root():
    all_cols = _cached_collections_0371()
    visible_cols = [c for c in filter_collections(all_cols) if collection_visible_appids(c)]
    visible_appids = _visible_active_appids_0372()
    hidden_ids = _active_hidden_appids_0372()
    if visible_appids or hidden_ids:
        if b("show_all_games", True) and visible_appids:
            add_dir("All Games ({})".format(len(visible_appids)), "list", collection="__all__")
        for c in visible_cols:
            if is_steam_hidden_collection(c):
                continue
            appids = collection_visible_appids(c)
            if appids:
                add_dir("{} ({})".format(collection_display_name(c), len(appids)), "list", collection_id=c["id"], collection_name_for_context=c["name"], collection_id_for_context=c["id"])
        if hidden_ids and _hidden_folder_visible_0372():
            add_dir("Hidden Games ({})".format(len(hidden_ids)), "list", collection="__hidden__", collection_name_for_context="Hidden Games", collection_id_for_context=_STEAM_HIDDEN_VIRTUAL_ID_0372)
    else:
        li = xbmcgui.ListItem(label="Steam library is syncing")
        li.setInfo("video", {"plot": "The local cache is empty. Startup sync will populate it without blocking this folder."})
        li.addContextMenuItems([("Scan for New Games", "RunPlugin({})".format(url_for(mode="scan_new_games"))), ("Steam Library tools", "RunPlugin({})".format(url_for(mode="run_tools")))])
        xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="noop"), li, False)
    xbmcplugin.endOfDirectory(HANDLE, cacheToDisc=True)


def appids_for(params):
    all_cols = _cached_collections_0371()
    if params.get("collection") == "__all__":
        return _visible_active_appids_0372(), all_cols
    if params.get("collection") == "__hidden__":
        return _active_hidden_appids_0372(), all_cols
    cid = params.get("collection_id")
    for c in all_cols:
        if c["id"] == cid:
            return collection_visible_appids(c), all_cols
    return [], filter_collections(all_cols)


def choose_visible_collections():
    cols = _cached_collections_0371()
    choices = [c for c in cols if not is_steam_hidden_collection(c)]
    choices.append({"id": _STEAM_HIDDEN_VIRTUAL_ID_0372, "name": "Hidden Games", "appids": _active_hidden_appids_0372()})
    labels = [collection_display_name(c) for c in choices]
    hidden = set(load_collection_visibility().get("hidden_ids", []))
    preselected = [idx for idx, c in enumerate(choices) if str(c.get("id")) not in hidden]
    selected = xbmcgui.Dialog().multiselect("Visible collections", labels, preselect=preselected)
    if selected is None:
        return
    selected_ids = {str(choices[idx].get("id")) for idx in selected}
    save_collection_visibility({"hidden_ids": [str(c.get("id")) for c in choices if str(c.get("id")) not in selected_ids]})
    xbmc.executebuiltin("Container.Refresh")


# ============================================================================
# v0.3.75 - simplified Name/Sortname schema and physical hidden-game storage
# ============================================================================

DESIRED_GAME_COLUMNS = [
    ("appid", "TEXT PRIMARY KEY"),
    ("name", "TEXT"),
    ("sortname", "TEXT"),
    ("app_type", "TEXT"),
    ("year", "TEXT"),
    ("developer", "TEXT"),
    ("publisher", "TEXT"),
    ("genres", "TEXT"),
    ("tagline", "TEXT"),
    ("short_description", "TEXT"),
    ("steam_review_percent", "TEXT"),
    ("steam_review_desc", "TEXT"),
    ("steam_review_total", "TEXT"),
    ("steam250_rank", "TEXT"),
    ("steam250_score", "TEXT"),
    ("achievement_unlocked", "TEXT"),
    ("achievement_total", "TEXT"),
    ("completed", "TEXT"),
    ("finished", "TEXT"),
    ("metacritic_score", "TEXT"),
    ("esrb", "TEXT"),
    ("pegi", "TEXT"),
    ("poster_url", "TEXT"),
    ("thumb_url", "TEXT"),
    ("clearlogo_url", "TEXT"),
    ("fanart_url", "TEXT"),
    ("fanart1_url", "TEXT"),
    ("fanart2_url", "TEXT"),
    ("fanart3_url", "TEXT"),
    ("fanart4_url", "TEXT"),
    ("metadata_status", "TEXT"),
    ("metadata_source", "TEXT"),
    ("last_scraped", "INTEGER"),
    ("playtime_forever", "INTEGER"),
]
_GAME_COLS_0375 = [name for name, _ in DESIRED_GAME_COLUMNS]
_HIDDEN_EXTRA_0375 = [("source_collection_id", "TEXT"), ("source_collection_name", "TEXT"), ("hidden_at", "INTEGER")]
_MANUAL_EXTRA_0375 = [("hidden_at", "INTEGER")]


def _dict_0375(row):
    return dict(row) if row is not None else {}


def _valid_text_0375(value):
    value = str(value or "").strip()
    return value if value and value.upper() not in ("N/A", "NA", "NONE", "NULL") else ""


def _normal_sort_0375(name, sortname):
    name = _valid_text_0375(name)
    sortname = _valid_text_0375(sortname)
    if not sortname or _same_name_0374(name, sortname):
        return ""
    return sortname


def _legacy_effective_name_0375(row):
    row = row or {}
    for key in ("name", "steamedit_name", "display_name", "steam_name"):
        value = _valid_text_0375(row.get(key))
        if value:
            return value
    return "Steam App {}".format(row.get("appid") or "")


def _legacy_effective_sort_0375(row, name):
    row = row or {}
    sortname = _valid_text_0375(row.get("sortname"))
    if not sortname or _same_name_0374(sortname, name):
        return ""
    original = _valid_text_0375(row.get("steam_name"))
    if original and not _same_name_0374(name, original) and _same_name_0374(sortname, original):
        return ""
    return sortname


def _create_data_table_0375(cur, table_name, extras=()):
    definitions = list(DESIRED_GAME_COLUMNS) + list(extras)
    cur.execute("CREATE TABLE IF NOT EXISTS {} ({})".format(
        table_name, ", ".join('"{}" {}'.format(name, coltype) for name, coltype in definitions)
    ))


def _insert_data_row_0375(cur, table_name, row, extras=None):
    row = dict(row or {})
    data = {key: row.get(key) for key in _GAME_COLS_0375}
    data["appid"] = str(data.get("appid") or row.get("appid") or "").strip()
    data["name"] = _legacy_effective_name_0375(row)
    data["sortname"] = _normal_sort_0375(data["name"], _legacy_effective_sort_0375(row, data["name"]))
    if extras:
        data.update(extras)
    keys = list(data)
    cur.execute(
        "INSERT OR REPLACE INTO {} ({}) VALUES ({})".format(table_name, ",".join(keys), ",".join("?" for _ in keys)),
        [data[key] for key in keys],
    )


def _schema_names_0375(con, table_name):
    try:
        return [str(row[1]) for row in con.execute("PRAGMA table_info({})".format(table_name)).fetchall()]
    except Exception:
        return []


def ensure_games_schema(con):
    cur = con.cursor()
    desired = list(_GAME_COLS_0375)
    old_cols = _schema_names_0375(con, "games")
    if not old_cols:
        _create_data_table_0375(cur, "games")
        return
    if old_cols == desired:
        return
    rows = [dict(row) for row in cur.execute("SELECT * FROM games").fetchall()]
    cur.execute("ALTER TABLE games RENAME TO games_pre_0375")
    _create_data_table_0375(cur, "games")
    for row in rows:
        _insert_data_row_0375(cur, "games", row)
    cur.execute("DROP TABLE games_pre_0375")


def _ensure_hidden_schema_0375(con):
    cur = con.cursor()
    desired_hidden = _GAME_COLS_0375 + [name for name, _ in _HIDDEN_EXTRA_0375]
    old_cols = _schema_names_0375(con, "hidden_games")
    if not old_cols:
        _create_data_table_0375(cur, "hidden_games", _HIDDEN_EXTRA_0375)
    elif old_cols != desired_hidden:
        old_rows = [dict(row) for row in cur.execute("SELECT * FROM hidden_games").fetchall()]
        cur.execute("ALTER TABLE hidden_games RENAME TO hidden_games_pre_0375")
        _create_data_table_0375(cur, "hidden_games", _HIDDEN_EXTRA_0375)
        for old in old_rows:
            appid = str(old.get("appid") or "")
            game = cur.execute("SELECT * FROM games WHERE appid=?", (appid,)).fetchone()
            merged = dict(game) if game else {}
            merged.update({key: value for key, value in old.items() if value not in (None, "")})
            _insert_data_row_0375(cur, "hidden_games", merged, {
                "source_collection_id": old.get("source_collection_id") or "hidden",
                "source_collection_name": old.get("source_collection_name") or "Hidden",
                "hidden_at": old.get("hidden_at") or int(time.time()),
            })
        cur.execute("DROP TABLE hidden_games_pre_0375")

    desired_manual = _GAME_COLS_0375 + [name for name, _ in _MANUAL_EXTRA_0375]
    manual_cols = _schema_names_0375(con, "manual_hidden_games")
    if not manual_cols:
        _create_data_table_0375(cur, "manual_hidden_games", _MANUAL_EXTRA_0375)
    elif manual_cols != desired_manual:
        old_rows = [dict(row) for row in cur.execute("SELECT * FROM manual_hidden_games").fetchall()]
        cur.execute("ALTER TABLE manual_hidden_games RENAME TO manual_hidden_games_pre_0375")
        _create_data_table_0375(cur, "manual_hidden_games", _MANUAL_EXTRA_0375)
        for old in old_rows:
            appid = str(old.get("appid") or "")
            merged = {}
            try:
                payload = json.loads(old.get("metadata_json") or "{}")
                if isinstance(payload, dict):
                    merged.update(payload)
            except Exception:
                pass
            game = cur.execute("SELECT * FROM games WHERE appid=?", (appid,)).fetchone()
            if game:
                merged.update(dict(game))
            merged.update({key: value for key, value in old.items() if key in _GAME_COLS_0375 and value not in (None, "")})
            merged["appid"] = appid
            if old.get("name"):
                merged["name"] = old.get("name")
            _insert_data_row_0375(cur, "manual_hidden_games", merged, {"hidden_at": old.get("hidden_at") or int(time.time())})
        cur.execute("DROP TABLE manual_hidden_games_pre_0375")

    # A game belongs to exactly one physical metadata table.
    cur.execute("DELETE FROM games WHERE appid IN (SELECT appid FROM hidden_games)")
    cur.execute("DELETE FROM games WHERE appid IN (SELECT appid FROM manual_hidden_games)")


def _normalise_table_sortnames_0375(con, table_name):
    try:
        rows = con.execute("SELECT appid,name,sortname FROM {}".format(table_name)).fetchall()
        for row in rows:
            clean = _normal_sort_0375(row["name"], row["sortname"])
            if clean != str(row["sortname"] or ""):
                con.execute("UPDATE {} SET sortname=? WHERE appid=?".format(table_name), (clean, str(row["appid"])))
    except Exception:
        pass


def connect():
    ensure()
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    ensure_games_schema(con)
    con.execute("""CREATE TABLE IF NOT EXISTS collections (
        collection_id TEXT, name TEXT, appid TEXT, PRIMARY KEY(collection_id, appid)
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS library_membership (
        appid TEXT PRIMARY KEY,
        is_active INTEGER NOT NULL DEFAULT 1,
        first_seen INTEGER,
        last_seen INTEGER,
        removed_at INTEGER,
        last_sync INTEGER
    )""")
    con.execute("CREATE INDEX IF NOT EXISTS idx_library_membership_active ON library_membership(is_active)")
    con.execute("CREATE TABLE IF NOT EXISTS library_sync_state (key TEXT PRIMARY KEY, value TEXT)")
    _ensure_hidden_schema_0375(con)
    _normalise_table_sortnames_0375(con, "games")
    _normalise_table_sortnames_0375(con, "hidden_games")
    _normalise_table_sortnames_0375(con, "manual_hidden_games")
    con.execute("CREATE INDEX IF NOT EXISTS idx_games_name ON games(name)")
    con.execute("CREATE INDEX IF NOT EXISTS idx_hidden_games_name ON hidden_games(name)")
    con.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("schema_version", "0.3.75"))
    con.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("name_schema", "name_sortname_only"))
    _bootstrap_membership_local_0371(con)
    con.commit()
    return con


def _effective_name_0373(row, fallback=""):
    value = _valid_text_0375((row or {}).get("name"))
    return value or str(fallback or "").strip()


def _fetch_any_game_row_0375(con, appid):
    appid = str(appid)
    for table in ("games", "hidden_games", "manual_hidden_games"):
        row = con.execute("SELECT * FROM {} WHERE appid=?".format(table), (appid,)).fetchone()
        if row:
            return table, dict(row)
    return "", {}


def _target_table_0375(con, appid):
    appid = str(appid)
    if con.execute("SELECT 1 FROM manual_hidden_games WHERE appid=?", (appid,)).fetchone():
        return "manual_hidden_games"
    if con.execute("SELECT 1 FROM hidden_games WHERE appid=?", (appid,)).fetchone():
        return "hidden_games"
    return "games"


def _move_game_row_0375(con, appid, target, extras=None, row_override=None):
    appid = str(appid)
    source, row = _fetch_any_game_row_0375(con, appid)
    if row_override:
        merged = dict(row or {})
        merged.update(dict(row_override))
        row = merged
    if not row:
        row = {"appid": appid, "name": "Steam App {}".format(appid), "sortname": "", "metadata_status": "new", "metadata_source": "library_sync", "last_scraped": 0, "playtime_forever": 0}
    row["appid"] = appid
    if target == "hidden_games":
        current = con.execute("SELECT source_collection_id,source_collection_name,hidden_at FROM hidden_games WHERE appid=?", (appid,)).fetchone()
        ext = dict(current) if current else {}
        ext.update(extras or {})
        ext.setdefault("hidden_at", int(time.time()))
        _insert_data_row_0375(con.cursor(), target, row, ext)
    elif target == "manual_hidden_games":
        current = con.execute("SELECT hidden_at FROM manual_hidden_games WHERE appid=?", (appid,)).fetchone()
        ext = dict(current) if current else {}
        ext.update(extras or {})
        ext.setdefault("hidden_at", int(time.time()))
        _insert_data_row_0375(con.cursor(), target, row, ext)
    else:
        _insert_data_row_0375(con.cursor(), target, row)
    for table in ("games", "hidden_games", "manual_hidden_games"):
        if table != target:
            con.execute("DELETE FROM {} WHERE appid=?".format(table), (appid,))


def existing_title(appid):
    try:
        con = connect()
        _, row = _fetch_any_game_row_0375(con, appid)
        con.close()
        title = _valid_text_0375(row.get("name"))
        if title and not title.startswith("Steam App "):
            return title
    except Exception:
        pass
    return ""


def sync_hidden_games_from_collections(con, cols):
    hidden_collections = [c for c in (cols or []) if is_steam_hidden_collection(c)]
    new_hidden = set()
    source = {}
    for collection in hidden_collections:
        cid = str(collection.get("id") or "hidden")
        cname = str(collection.get("name") or "Hidden")
        for appid in collection.get("appids", []):
            appid = str(appid)
            new_hidden.add(appid)
            source[appid] = (cid, cname)

    old_hidden = {str(row[0]) for row in con.execute("SELECT appid FROM hidden_games").fetchall()}
    for appid in sorted(old_hidden - new_hidden):
        _move_game_row_0375(con, appid, "games")
    for appid in sorted(new_hidden):
        cid, cname = source.get(appid, ("hidden", "Hidden"))
        _move_game_row_0375(con, appid, "hidden_games", {
            "source_collection_id": cid,
            "source_collection_name": cname,
            "hidden_at": int(time.time()),
        })
    return len(new_hidden)


def hide_game_manual(appid, name=""):
    appid = str(appid or "").strip()
    if not appid:
        return False
    con = connect()
    _, row = _fetch_any_game_row_0375(con, appid)
    if name and not _valid_text_0375(row.get("name")):
        row["name"] = str(name).strip()
    _move_game_row_0375(con, appid, "manual_hidden_games", {"hidden_at": int(time.time())})
    con.commit()
    con.close()
    return True


def unhide_game_manual(appid):
    appid = str(appid or "").strip()
    if not appid:
        return False
    con = connect()
    if not con.execute("SELECT 1 FROM manual_hidden_games WHERE appid=?", (appid,)).fetchone():
        con.close()
        return False
    _move_game_row_0375(con, appid, "games")
    con.commit()
    con.close()
    return True


def manual_hidden_games_rows():
    try:
        con = connect()
        rows = [dict(row) for row in con.execute(
            "SELECT appid,name,hidden_at FROM manual_hidden_games ORDER BY LOWER(COALESCE(NULLIF(name,''),appid))"
        ).fetchall()]
        con.close()
        return rows
    except Exception as exc:
        log("Failed reading manual hidden game rows: {}".format(exc), xbmc.LOGWARNING)
        return []


def update_finished_flags(con, cols):
    for table in ("games", "hidden_games", "manual_hidden_games"):
        con.execute("UPDATE {} SET finished='0' WHERE appid IS NOT NULL".format(table))
    done = set()
    for collection in (cols or []):
        if finished_keywords(collection.get("name")) or finished_keywords(collection.get("id")):
            done.update(str(appid) for appid in collection.get("appids", []))
    for appid in done:
        for table in ("games", "hidden_games", "manual_hidden_games"):
            con.execute("UPDATE {} SET finished='1' WHERE appid=?".format(table), (appid,))


def cached_games_for_listing(appids, cols=None, include_hidden=False):
    ordered = [str(appid) for appid in (appids or [])]
    out = {}
    con = connect()
    try:
        tables = ("hidden_games", "manual_hidden_games") if include_hidden else ("games",)
        for table in tables:
            for start in range(0, len(ordered), 500):
                chunk = ordered[start:start + 500]
                if not chunk:
                    continue
                marks = ",".join("?" for _ in chunk)
                for row in con.execute("SELECT * FROM {} WHERE appid IN ({})".format(table, marks), chunk).fetchall():
                    out[str(row["appid"])] = dict(row)
    finally:
        con.close()
    for appid in ordered:
        if appid not in out:
            out[appid] = partial_game(appid, "missing_metadata_cache_only", cols or [])
    return out


def save_game(g):
    if not g or not g.get("appid"):
        return
    appid = str(g.get("appid"))
    con = connect()
    target = _target_table_0375(con, appid)
    _, old = _fetch_any_game_row_0375(con, appid)
    incoming = dict(g)
    data = {key: incoming.get(key) for key in _GAME_COLS_0375}
    data["appid"] = appid
    # Metadata refresh owns metadata, not the user's Name/Sortname.
    old_name = _valid_text_0375(old.get("name"))
    data["name"] = old_name or _valid_text_0375(incoming.get("name")) or "Steam App {}".format(appid)
    old_sort = _valid_text_0375(old.get("sortname"))
    data["sortname"] = _normal_sort_0375(data["name"], old_sort if old else incoming.get("sortname"))
    if old:
        if _valid_text_0375(incoming.get("tagline")) == "" and _valid_text_0375(old.get("tagline")):
            data["tagline"] = old.get("tagline")
        if incoming.get("playtime_forever") in (None, "", NA) and old.get("playtime_forever") is not None:
            data["playtime_forever"] = old.get("playtime_forever")
        for key in ("poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"):
            if _valid_text_0375(old.get(key)):
                data[key] = old.get(key)
    if target == "hidden_games":
        ext = con.execute("SELECT source_collection_id,source_collection_name,hidden_at FROM hidden_games WHERE appid=?", (appid,)).fetchone()
        _insert_data_row_0375(con.cursor(), target, data, dict(ext) if ext else {"hidden_at": int(time.time())})
    elif target == "manual_hidden_games":
        ext = con.execute("SELECT hidden_at FROM manual_hidden_games WHERE appid=?", (appid,)).fetchone()
        _insert_data_row_0375(con.cursor(), target, data, dict(ext) if ext else {"hidden_at": int(time.time())})
    else:
        _insert_data_row_0375(con.cursor(), target, data)
    con.commit()
    con.close()


def sync_collections(force_owned=False):
    con = connect()
    path = cloud_json()
    cols = parse_collections(path)
    con.execute("DELETE FROM collections")
    for collection in cols:
        for appid in collection.get("appids", []):
            con.execute("INSERT OR REPLACE INTO collections(collection_id,name,appid) VALUES(?,?,?)", (
                str(collection.get("id") or ""), str(collection.get("name") or ""), str(appid)
            ))
    sync_hidden_games_from_collections(con, cols)
    update_finished_flags(con, cols)
    con.commit()
    con.close()
    return with_owned_uncategorized_collection(cols, force_owned=force_owned), path


def _new_game_seed_0375(appid, owned_row, local_row):
    steam_name = _valid_text_0375((owned_row or {}).get("name")) or "Steam App {}".format(appid)
    local_name = _valid_text_0375((local_row or {}).get("name"))
    name = local_name or steam_name
    local_sort = _valid_text_0375((local_row or {}).get("sortname"))
    sortname = _normal_sort_0375(name, local_sort)
    app_type = _valid_text_0375((local_row or {}).get("app_type"))
    return {
        "appid": str(appid), "name": name, "sortname": sortname, "app_type": app_type,
        "poster_url": poster(appid),
        "thumb_url": "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{}/header.jpg".format(appid),
        "metadata_status": "new", "metadata_source": "owned_games", "last_scraped": 0,
        "playtime_forever": int((owned_row or {}).get("playtime_forever") or 0),
    }


def sync_library_background_0371(silent=False, scrape_new=True):
    success, owned, source_name = _owned_games_fetch_0371(force=True)
    if not success:
        log("Ownership sync failed: {}".format(source_name), xbmc.LOGWARNING)
        if not silent:
            _notify2_0371("Sync failed • Library unchanged", 5500, xbmcgui.NOTIFICATION_WARNING)
        return {"ok": False, "error": source_name, "added": 0, "removed": 0}

    raw_cols = parse_collections(cloud_json())
    hidden_set = set()
    hidden_source = {}
    for collection in raw_cols:
        if is_steam_hidden_collection(collection):
            for appid in collection.get("appids", []):
                appid = str(appid)
                hidden_set.add(appid)
                hidden_source[appid] = (str(collection.get("id") or "hidden"), str(collection.get("name") or "Hidden"))
    new_active = set(str(appid) for appid in owned)
    now = int(time.time())
    try:
        appinfo_meta = appinfo_metadata_map(new_active, force=False)
    except Exception:
        appinfo_meta = {}

    con = connect()
    old_active = {str(row[0]) for row in con.execute("SELECT appid FROM library_membership WHERE is_active=1").fetchall()}
    added = sorted(new_active - old_active, key=lambda appid: str((owned.get(appid) or {}).get("name") or appid).casefold())
    removed = sorted(old_active - new_active)
    try:
        con.execute("BEGIN")
        con.execute("UPDATE library_membership SET is_active=0, removed_at=?, last_sync=? WHERE is_active=1", (now, now))
        for appid, owned_row in owned.items():
            appid = str(appid)
            con.execute(
                "INSERT INTO library_membership(appid,is_active,first_seen,last_seen,removed_at,last_sync) VALUES(?,1,?,?,NULL,?) "
                "ON CONFLICT(appid) DO UPDATE SET is_active=1,last_seen=excluded.last_seen,removed_at=NULL,last_sync=excluded.last_sync",
                (appid, now, now, now),
            )
            current_table, current = _fetch_any_game_row_0375(con, appid)
            row = current or _new_game_seed_0375(appid, owned_row, appinfo_meta.get(appid, {}) or {})
            row["appid"] = appid
            row["playtime_forever"] = int((owned_row or {}).get("playtime_forever") or 0)
            local_type = _valid_text_0375((appinfo_meta.get(appid, {}) or {}).get("app_type"))
            if local_type:
                row["app_type"] = local_type
            if current_table == "manual_hidden_games":
                target = "manual_hidden_games"
                extras = {"hidden_at": current.get("hidden_at") or now}
            elif appid in hidden_set:
                target = "hidden_games"
                cid, cname = hidden_source.get(appid, ("hidden", "Hidden"))
                extras = {"source_collection_id": cid, "source_collection_name": cname, "hidden_at": current.get("hidden_at") or now}
            else:
                target = "games"
                extras = None
            _move_game_row_0375(con, appid, target, extras, row_override=row)
            # The row is now in its physical target table; apply playtime/type without touching Name/Sortname.
            con.execute("UPDATE {} SET playtime_forever=?, app_type=CASE WHEN ?<>'' THEN ? ELSE app_type END WHERE appid=?".format(target),
                        (row.get("playtime_forever") or 0, local_type, local_type, appid))

        _rebuild_cached_collections_0372(con, raw_cols, new_active, owned, appinfo_meta)
        con.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("last_success", str(now)))
        con.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("last_source", source_name))
        con.commit()
    except Exception:
        con.rollback()
        con.close()
        raise
    con.close()

    if added and not silent:
        _notify2_0371("{} new game{} found".format(len(added), "" if len(added) == 1 else "s"), 4500)
    if removed and not silent:
        _notify2_0371("{} removed game{} detected".format(len(removed), "" if len(removed) == 1 else "s"), 5000)
    result = {"ok": True, "added": len(added), "removed": len(removed), "added_appids": added, "removed_appids": removed}
    try:
        with open(_sync_report_path_0371("last_library_sync.json"), "w", encoding="utf-8") as fh:
            json.dump(dict(result, timestamp=now, source=source_name), fh, indent=2)
    except Exception:
        pass
    if scrape_new and added:
        visible_added = [appid for appid in added if appid not in hidden_set]
        if visible_added:
            _scrape_new_appids_0371(visible_added, _cached_collections_0371(), silent=silent)
    xbmc.executebuiltin("Container.Refresh")
    return result


def _name_source_maps_0375(appids, force=True):
    appids = [str(appid) for appid in appids]
    try:
        local = appinfo_metadata_map(appids, force=force)
    except Exception:
        local = {}
    try:
        owned = owned_games_map(force=force)
    except Exception:
        owned = {}
    return local, owned


def refresh_name_sortname_overwrite(force=True, notify=True):
    con = connect()
    appids = [str(row[0]) for row in con.execute("SELECT appid FROM library_membership WHERE is_active=1 ORDER BY rowid").fetchall()]
    con.close()
    local, owned = _name_source_maps_0375(appids, force=force)
    changed = 0
    con = connect()
    for appid in appids:
        table, current = _fetch_any_game_row_0375(con, appid)
        table = table or "games"
        local_row = local.get(appid, {}) or {}
        owned_row = owned.get(appid, {}) or {}
        new_name = _valid_text_0375(local_row.get("name")) or _valid_text_0375(owned_row.get("name")) or _valid_text_0375(current.get("name")) or "Steam App {}".format(appid)
        candidate = _valid_text_0375(local_row.get("sortname"))
        if not candidate:
            candidate = _valid_text_0375(owned_row.get("sort_as") or owned_row.get("sortas") or owned_row.get("sortname") or owned_row.get("sort_name"))
        new_sort = _normal_sort_0375(new_name, candidate)
        if new_name != str(current.get("name") or "") or new_sort != str(current.get("sortname") or ""):
            changed += 1
        if current:
            con.execute("UPDATE {} SET name=?,sortname=? WHERE appid=?".format(table), (new_name, new_sort, appid))
        else:
            _insert_data_row_0375(con.cursor(), "games", {"appid": appid, "name": new_name, "sortname": new_sort, "metadata_status": "new", "metadata_source": "name_refresh", "last_scraped": 0})
    con.commit()
    con.close()
    if notify:
        xbmcgui.Dialog().notification(ADDON_NAME, "Name/Sortname refreshed: {} changed".format(changed), xbmcgui.NOTIFICATION_INFO, 5000)
        xbmc.executebuiltin("Container.Refresh")
    return changed


def add_missing_sortname(force=True, notify=True):
    con = connect()
    rows = []
    for table in ("games", "hidden_games", "manual_hidden_games"):
        for row in con.execute("SELECT appid,name,sortname FROM {} WHERE TRIM(COALESCE(sortname,''))=''".format(table)).fetchall():
            rows.append((table, str(row["appid"]), str(row["name"] or "")))
    con.close()
    local, owned = _name_source_maps_0375([appid for _, appid, _ in rows], force=force)
    added = 0
    con = connect()
    for table, appid, name in rows:
        local_row = local.get(appid, {}) or {}
        owned_row = owned.get(appid, {}) or {}
        candidate = _valid_text_0375(local_row.get("sortname"))
        if not candidate:
            candidate = _valid_text_0375(owned_row.get("sort_as") or owned_row.get("sortas") or owned_row.get("sortname") or owned_row.get("sort_name"))
        candidate = _normal_sort_0375(name, candidate)
        if candidate:
            cur = con.execute("UPDATE {} SET sortname=? WHERE appid=? AND TRIM(COALESCE(sortname,''))=''".format(table), (candidate, appid))
            added += int(cur.rowcount or 0)
    con.commit()
    con.close()
    if notify:
        xbmcgui.Dialog().notification(ADDON_NAME, "Missing Sortname added: {}".format(added), xbmcgui.NOTIFICATION_INFO, 5000)
        xbmc.executebuiltin("Container.Refresh")
    return added


def refresh_steam_sortnames(force=True, notify=True):
    return refresh_name_sortname_overwrite(force=force, notify=notify)


def artwork_urls(include_hidden=False):
    tables = ["games"] + (["hidden_games", "manual_hidden_games"] if include_hidden else [])
    con = connect()
    rows = []
    for table in tables:
        rows.extend(con.execute("SELECT appid,name,poster_url,thumb_url,clearlogo_url,fanart_url,fanart1_url,fanart2_url,fanart3_url,fanart4_url FROM {} ORDER BY name".format(table)).fetchall())
    con.close()
    urls, seen = [], set()
    for row in rows:
        for art_type, url in (("poster", row["poster_url"]), ("thumb", row["thumb_url"]), ("clearlogo", row["clearlogo_url"]),
                              ("fanart", row["fanart_url"]), ("fanart1", row["fanart1_url"]), ("fanart2", row["fanart2_url"]),
                              ("fanart3", row["fanart3_url"]), ("fanart4", row["fanart4_url"])):
            url = art_or_empty(url)
            key = (art_type, url)
            if not url or key in seen:
                continue
            seen.add(key)
            urls.append({"appid": row["appid"], "name": row["name"] or row["appid"], "art_type": art_type, "url": url})
    return urls


def clean_game_library_0371(silent=False):
    con = connect()
    rows = con.execute(
        "SELECT m.appid,COALESCE(g.name,h.name,mh.name,m.appid) AS name FROM library_membership m "
        "LEFT JOIN games g ON g.appid=m.appid LEFT JOIN hidden_games h ON h.appid=m.appid "
        "LEFT JOIN manual_hidden_games mh ON mh.appid=m.appid WHERE m.is_active=0 ORDER BY name COLLATE NOCASE"
    ).fetchall()
    report = []
    for idx, row in enumerate(rows, 1):
        appid = str(row["appid"])
        name = str(row["name"] or appid)
        if not silent:
            _notify2_0371("Cleaning {}/{} • {}".format(idx, len(rows), name), 3500)
        for table in ("collections", "games", "hidden_games", "manual_hidden_games", "library_membership"):
            con.execute("DELETE FROM {} WHERE appid=?".format(table), (appid,))
        report.append({"appid": appid, "game": name, "reason": "no_longer_owned", "action": "deleted"})
    con.commit()
    con.close()
    try:
        with open(_sync_report_path_0371("clean_game_library.csv"), "w", encoding="utf-8-sig", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=["appid", "game", "reason", "action"])
            writer.writeheader(); writer.writerows(report)
    except Exception:
        pass
    if not silent:
        _notify2_0371("Clean complete • {} game{} removed".format(len(rows), "" if len(rows) == 1 else "s"), 5000)
    xbmc.executebuiltin("Container.Refresh")
    return len(rows)


def view_status():
    cols = _cached_collections_0371()
    con = connect()
    last = con.execute("SELECT value FROM library_sync_state WHERE key='last_success'").fetchone()
    last_text = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(int(last[0]))) if last and str(last[0]).isdigit() else 'never'
    active = con.execute("SELECT COUNT(*) FROM library_membership WHERE is_active=1").fetchone()[0]
    removed = con.execute("SELECT COUNT(*) FROM library_membership WHERE is_active=0").fetchone()[0]
    visible = con.execute("SELECT COUNT(*) FROM games").fetchone()[0]
    hidden = con.execute("SELECT COUNT(*) FROM hidden_games").fetchone()[0]
    manual = con.execute("SELECT COUNT(*) FROM manual_hidden_games").fetchone()[0]
    playtime = sum(con.execute("SELECT COUNT(*) FROM {} WHERE playtime_forever>0".format(table)).fetchone()[0] for table in ("games", "hidden_games", "manual_hidden_games"))
    con.close()
    xbmcgui.Dialog().ok(ADDON_NAME, (
        "Collections: {}\nActive owned games: {}\nVisible games table: {}\nSteam hidden table: {}\nManually hidden table: {}\n"
        "Removed pending clean: {}\nPlaytime values: {}\n\nLast successful sync: {}\n\nDB:\n{}"
    ).format(len(cols), active, visible, hidden, manual, removed, playtime, last_text, DB_PATH))



def hide_games(appids, source_collection_id="", source_collection_name=""):
    appids = [str(appid) for appid in (appids or []) if str(appid)]
    if not appids:
        return 0
    con = connect()
    now = int(time.time())
    for appid in appids:
        _move_game_row_0375(con, appid, "hidden_games", {
            "source_collection_id": str(source_collection_id or "hidden"),
            "source_collection_name": str(source_collection_name or "Hidden"),
            "hidden_at": now,
        })
    con.commit()
    con.close()
    return len(appids)


def get_current_game(appid):
    con = connect()
    _, row = _fetch_any_game_row_0375(con, appid)
    con.close()
    return row if row else partial_game(appid, "not_in_db")


def _update_target_columns_0375(appid, assignments, values):
    con = connect()
    table = _target_table_0375(con, appid)
    if not con.execute("SELECT 1 FROM {} WHERE appid=?".format(table), (str(appid),)).fetchone():
        _insert_data_row_0375(con.cursor(), "games", {"appid": str(appid), "name": fallback_title(appid), "sortname": "", "metadata_status": "new", "metadata_source": "manual_update", "last_scraped": 0})
        table = "games"
    con.execute("UPDATE {} SET {} WHERE appid=?".format(table, assignments), list(values) + [str(appid)])
    con.commit()
    con.close()


def update_art_url(appid, column, url):
    if column not in ("poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"):
        return
    _update_target_columns_0375(appid, "{}=?".format(column), [url])


def reset_auto_art(appid):
    try:
        js = http_json("https://store.steampowered.com/api/appdetails?appids={}&cc=US&l=english&v=1".format(appid), 25)
        app = js.get(str(appid), {})
        if not app.get("success"):
            xbmcgui.Dialog().notification(ADDON_NAME, "Store appdetails unavailable.", xbmcgui.NOTIFICATION_WARNING, 4000)
            return
        art = auto_art(appid, app.get("data") or {}, steam_store_html(appid))
        columns = [key for key in art if key in ("poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url")]
        if columns:
            _update_target_columns_0375(appid, ",".join("{}=?".format(key) for key in columns), [art.get(key) for key in columns])
        xbmc.executebuiltin("Container.Refresh")
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, "Reset artwork failed:\n{}".format(exc))


def update_fanart_slots(appid, slots):
    columns = ("fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url")
    _update_target_columns_0375(appid, ",".join("{}=?".format(key) for key in columns), [slots.get(key) or NA for key in columns])


def refresh_steam250_ranks(force=True, notify=True):
    ranks = fetch_steam250_top250(force=force)
    if not ranks:
        if notify:
            xbmcgui.Dialog().notification(ADDON_NAME, "Steam250 Top 250 not available", xbmcgui.NOTIFICATION_WARNING, 5000)
        return 0
    con = connect()
    matched = 0
    for table in ("games", "hidden_games", "manual_hidden_games"):
        con.execute("UPDATE {} SET steam250_rank=NULL,steam250_score=NULL".format(table))
        for appid, data in ranks.items():
            cur = con.execute("UPDATE {} SET steam250_rank=?,steam250_score=? WHERE appid=?".format(table), (
                steam_display_or_na(data.get("rank")), steam_display_or_na(data.get("score")), str(appid)
            ))
            matched += int(cur.rowcount or 0)
    con.commit()
    con.close()
    if notify:
        xbmcgui.Dialog().notification(ADDON_NAME, "Steam250 ranks updated: {} library matches".format(matched), xbmcgui.NOTIFICATION_INFO, 5000)
        xbmc.executebuiltin("Container.Refresh")
    return matched



def _cache_artwork_after_metadata_0376():
    """Cache every currently pending visible artwork URL after a manual metadata action."""
    try:
        cache_artwork()
        return True
    except Exception as exc:
        log("Automatic artwork cache failed: {}".format(exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            "Metadata saved, but artwork cache failed",
            xbmcgui.NOTIFICATION_WARNING,
            6000,
        )
        return False


def scan_for_new_games_0376():
    result = sync_library_background_0371(silent=False, scrape_new=True)
    if result and result.get("ok") and int(result.get("added") or 0) > 0:
        _cache_artwork_after_metadata_0376()
    return result


def refresh_all_metadata_0376():
    # Full metadata refresh, followed by authoritative SteamEdit Name/Sortname overwrite.
    refresh_all(False)
    refresh_name_sortname_overwrite(force=True, notify=False)
    _cache_artwork_after_metadata_0376()
    xbmc.executebuiltin("Container.Refresh")


def scrape_missing_metadata_0376():
    # Missing-only metadata refresh; existing Name/Sortname remain protected.
    refresh_all(True)
    add_missing_sortname(force=True, notify=False)
    _cache_artwork_after_metadata_0376()
    xbmc.executebuiltin("Container.Refresh")



# ---------------------------------------------------------------------------
# v0.3.77 - game-only database and immediate membership pruning
# ---------------------------------------------------------------------------
_connect_0376 = connect


def _app_type_0377(value):
    value = _valid_text_0375(value)
    return value.strip().lower() if value else ""


def _delete_appid_everywhere_0377(con, appid, delete_membership=True):
    appid = str(appid or "").strip()
    if not appid:
        return
    for table in ("collections", "games", "hidden_games", "manual_hidden_games"):
        con.execute("DELETE FROM {} WHERE appid=?".format(table), (appid,))
    if delete_membership:
        con.execute("DELETE FROM library_membership WHERE appid=?", (appid,))


def _enforce_game_only_0377(con):
    """Keep only owned Steam entries whose resolved app type is exactly game."""
    rejected = set()
    for table in ("games", "hidden_games", "manual_hidden_games"):
        try:
            rows = con.execute(
                "SELECT appid FROM {} WHERE LOWER(TRIM(COALESCE(app_type,'')))<>'game'".format(table)
            ).fetchall()
            rejected.update(str(row[0]) for row in rows if row and row[0] is not None)
        except Exception:
            pass

    for appid in rejected:
        _delete_appid_everywhere_0377(con, appid, delete_membership=True)

    # Removed or inactive ownership is not retained as a pending game row.
    inactive = [str(row[0]) for row in con.execute(
        "SELECT appid FROM library_membership WHERE COALESCE(is_active,0)<>1"
    ).fetchall()]
    for appid in inactive:
        _delete_appid_everywhere_0377(con, appid, delete_membership=True)

    # Metadata rows must always have an active membership record.
    for table in ("games", "hidden_games", "manual_hidden_games"):
        con.execute(
            "DELETE FROM {} WHERE NOT EXISTS ("
            "SELECT 1 FROM library_membership m "
            "WHERE m.appid={}.appid AND m.is_active=1)".format(table, table)
        )

    # Collection rows are meaningful only for active game memberships.
    con.execute(
        "DELETE FROM collections WHERE NOT EXISTS ("
        "SELECT 1 FROM library_membership m WHERE m.appid=collections.appid AND m.is_active=1)"
    )
    return len(rejected) + len(inactive)


def connect():
    con = _connect_0376()
    _enforce_game_only_0377(con)
    con.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("schema_version", "0.3.77"))
    con.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("library_filter", "active_game_only"))
    con.commit()
    return con


def _stored_app_type_0377(con, appid):
    appid = str(appid)
    for table in ("games", "hidden_games", "manual_hidden_games"):
        row = con.execute("SELECT app_type FROM {} WHERE appid=?".format(table), (appid,)).fetchone()
        if row:
            return _app_type_0377(row[0])
    return ""


def _active_game_appids_0377(con):
    rows = con.execute(
        "SELECT m.appid FROM library_membership m WHERE m.is_active=1 AND ("
        "EXISTS(SELECT 1 FROM games g WHERE g.appid=m.appid AND LOWER(TRIM(COALESCE(g.app_type,'')))='game') OR "
        "EXISTS(SELECT 1 FROM hidden_games h WHERE h.appid=m.appid AND LOWER(TRIM(COALESCE(h.app_type,'')))='game') OR "
        "EXISTS(SELECT 1 FROM manual_hidden_games mh WHERE mh.appid=m.appid AND LOWER(TRIM(COALESCE(mh.app_type,'')))='game'))"
    ).fetchall()
    return {str(row[0]) for row in rows}


def sync_hidden_games_from_collections(con, cols):
    active_games = _active_game_appids_0377(con)
    hidden_collections = [c for c in (cols or []) if is_steam_hidden_collection(c)]
    new_hidden = set()
    source = {}
    for collection in hidden_collections:
        cid = str(collection.get("id") or "hidden")
        cname = str(collection.get("name") or "Hidden")
        for appid in collection.get("appids", []):
            appid = str(appid)
            if appid not in active_games:
                continue
            new_hidden.add(appid)
            source[appid] = (cid, cname)

    old_hidden = {str(row[0]) for row in con.execute("SELECT appid FROM hidden_games").fetchall()}
    for appid in sorted(old_hidden - new_hidden):
        if appid in active_games:
            _move_game_row_0375(con, appid, "games")
        else:
            _delete_appid_everywhere_0377(con, appid, delete_membership=True)
    for appid in sorted(new_hidden):
        cid, cname = source.get(appid, ("hidden", "Hidden"))
        _move_game_row_0375(con, appid, "hidden_games", {
            "source_collection_id": cid,
            "source_collection_name": cname,
            "hidden_at": int(time.time()),
        })
    return len(new_hidden)


def sync_collections(force_owned=False):
    con = connect()
    path = cloud_json()
    cols = parse_collections(path)
    active_games = _active_game_appids_0377(con)
    filtered = []
    con.execute("DELETE FROM collections")
    for collection in cols:
        clean = dict(collection)
        clean["appids"] = [str(appid) for appid in collection.get("appids", []) if str(appid) in active_games]
        filtered.append(clean)
        for appid in clean["appids"]:
            con.execute("INSERT OR REPLACE INTO collections(collection_id,name,appid) VALUES(?,?,?)", (
                str(clean.get("id") or ""), str(clean.get("name") or ""), appid
            ))
    sync_hidden_games_from_collections(con, filtered)
    update_finished_flags(con, filtered)
    _enforce_game_only_0377(con)
    con.commit()
    con.close()
    return with_owned_uncategorized_collection(filtered, force_owned=force_owned), path


def save_game(g):
    if not g or not g.get("appid"):
        return
    appid = str(g.get("appid"))
    con = connect()
    membership = con.execute(
        "SELECT 1 FROM library_membership WHERE appid=? AND is_active=1", (appid,)
    ).fetchone()
    target = _target_table_0375(con, appid)
    _, old = _fetch_any_game_row_0375(con, appid)
    incoming = dict(g)
    effective_type = _app_type_0377(incoming.get("app_type")) or _app_type_0377(old.get("app_type"))
    if not membership or effective_type != "game":
        _delete_appid_everywhere_0377(con, appid, delete_membership=True)
        con.commit()
        con.close()
        return

    data = {key: incoming.get(key) for key in _GAME_COLS_0375}
    data["appid"] = appid
    data["app_type"] = "game"
    old_name = _valid_text_0375(old.get("name"))
    data["name"] = old_name or _valid_text_0375(incoming.get("name")) or "Steam App {}".format(appid)
    old_sort = _valid_text_0375(old.get("sortname"))
    data["sortname"] = _normal_sort_0375(data["name"], old_sort if old else incoming.get("sortname"))
    if old:
        if _valid_text_0375(incoming.get("tagline")) == "" and _valid_text_0375(old.get("tagline")):
            data["tagline"] = old.get("tagline")
        if incoming.get("playtime_forever") in (None, "", NA) and old.get("playtime_forever") is not None:
            data["playtime_forever"] = old.get("playtime_forever")
        for key in ("poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"):
            if _valid_text_0375(old.get(key)):
                data[key] = old.get(key)
    if target == "hidden_games":
        ext = con.execute("SELECT source_collection_id,source_collection_name,hidden_at FROM hidden_games WHERE appid=?", (appid,)).fetchone()
        _insert_data_row_0375(con.cursor(), target, data, dict(ext) if ext else {"hidden_at": int(time.time())})
    elif target == "manual_hidden_games":
        ext = con.execute("SELECT hidden_at FROM manual_hidden_games WHERE appid=?", (appid,)).fetchone()
        _insert_data_row_0375(con.cursor(), target, data, dict(ext) if ext else {"hidden_at": int(time.time())})
    else:
        _insert_data_row_0375(con.cursor(), target, data)
    con.commit()
    con.close()


def sync_library_background_0371(silent=False, scrape_new=True):
    success, owned, source_name = _owned_games_fetch_0371(force=True)
    if not success:
        log("Ownership sync failed: {}".format(source_name), xbmc.LOGWARNING)
        if not silent:
            _notify2_0371("Sync failed • Library unchanged", 5500, xbmcgui.NOTIFICATION_WARNING)
        return {"ok": False, "error": source_name, "added": 0, "removed": 0}

    raw_cols = parse_collections(cloud_json())
    owned_ids = set(str(appid) for appid in owned)
    try:
        appinfo_meta = appinfo_metadata_map(owned_ids, force=False)
    except Exception:
        appinfo_meta = {}

    con = connect()
    eligible = set()
    skipped = set()
    for appid in owned_ids:
        local_type = _app_type_0377((appinfo_meta.get(appid, {}) or {}).get("app_type"))
        stored_type = _stored_app_type_0377(con, appid)
        # New unknown entries are not admitted. Existing confirmed games survive a temporary appinfo miss.
        if local_type == "game" or (not local_type and stored_type == "game"):
            eligible.add(appid)
        else:
            skipped.add(appid)

    hidden_set = set()
    hidden_source = {}
    for collection in raw_cols:
        if is_steam_hidden_collection(collection):
            for appid in collection.get("appids", []):
                appid = str(appid)
                if appid not in eligible:
                    continue
                hidden_set.add(appid)
                hidden_source[appid] = (str(collection.get("id") or "hidden"), str(collection.get("name") or "Hidden"))

    now = int(time.time())
    old_active = {str(row[0]) for row in con.execute("SELECT appid FROM library_membership WHERE is_active=1").fetchall()}
    added = sorted(eligible - old_active, key=lambda appid: str((owned.get(appid) or {}).get("name") or appid).casefold())
    removed = sorted(old_active - eligible)
    try:
        con.execute("BEGIN")
        con.execute("UPDATE library_membership SET is_active=0, removed_at=?, last_sync=? WHERE is_active=1", (now, now))
        for appid in sorted(eligible):
            owned_row = owned.get(appid) or {}
            con.execute(
                "INSERT INTO library_membership(appid,is_active,first_seen,last_seen,removed_at,last_sync) VALUES(?,1,?,?,NULL,?) "
                "ON CONFLICT(appid) DO UPDATE SET is_active=1,last_seen=excluded.last_seen,removed_at=NULL,last_sync=excluded.last_sync",
                (appid, now, now, now),
            )
            current_table, current = _fetch_any_game_row_0375(con, appid)
            row = current or _new_game_seed_0375(appid, owned_row, appinfo_meta.get(appid, {}) or {})
            row["appid"] = appid
            row["app_type"] = "game"
            row["playtime_forever"] = int(owned_row.get("playtime_forever") or 0)
            if current_table == "manual_hidden_games":
                target = "manual_hidden_games"
                extras = {"hidden_at": current.get("hidden_at") or now}
            elif appid in hidden_set:
                target = "hidden_games"
                cid, cname = hidden_source.get(appid, ("hidden", "Hidden"))
                extras = {"source_collection_id": cid, "source_collection_name": cname, "hidden_at": current.get("hidden_at") or now}
            else:
                target = "games"
                extras = None
            _move_game_row_0375(con, appid, target, extras, row_override=row)
            con.execute("UPDATE {} SET playtime_forever=?,app_type='game' WHERE appid=?".format(target),
                        (row.get("playtime_forever") or 0, appid))

        for appid in skipped:
            _delete_appid_everywhere_0377(con, appid, delete_membership=True)

        _rebuild_cached_collections_0372(con, raw_cols, eligible, owned, appinfo_meta)
        _enforce_game_only_0377(con)
        con.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("last_success", str(now)))
        con.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("last_source", source_name))
        con.execute("INSERT OR REPLACE INTO library_sync_state(key,value) VALUES(?,?)", ("last_non_game_skipped", str(len(skipped))))
        con.commit()
    except Exception:
        con.rollback()
        con.close()
        raise
    con.close()

    if added and not silent:
        _notify2_0371("{} new game{} found".format(len(added), "" if len(added) == 1 else "s"), 4500)
    if removed and not silent:
        _notify2_0371("{} non-member/removed game{} deleted".format(len(removed), "" if len(removed) == 1 else "s"), 5000)
    result = {
        "ok": True,
        "added": len(added),
        "removed": len(removed),
        "skipped_non_game": len(skipped),
        "added_appids": added,
        "removed_appids": removed,
    }
    try:
        with open(_sync_report_path_0371("last_library_sync.json"), "w", encoding="utf-8") as fh:
            json.dump(dict(result, timestamp=now, source=source_name), fh, indent=2)
    except Exception:
        pass
    if scrape_new and added:
        visible_added = [appid for appid in added if appid not in hidden_set]
        if visible_added:
            _scrape_new_appids_0371(visible_added, _cached_collections_0371(), silent=silent)
    xbmc.executebuiltin("Container.Refresh")
    return result


def clean_game_library_0371(silent=False):
    con = connect()
    before = sum(con.execute("SELECT COUNT(*) FROM {}".format(table)).fetchone()[0] for table in ("games", "hidden_games", "manual_hidden_games"))
    _enforce_game_only_0377(con)
    after = sum(con.execute("SELECT COUNT(*) FROM {}".format(table)).fetchone()[0] for table in ("games", "hidden_games", "manual_hidden_games"))
    con.commit()
    con.close()
    removed = max(0, int(before) - int(after))
    if not silent:
        _notify2_0371("Clean complete • {} invalid row{} removed".format(removed, "" if removed == 1 else "s"), 5000)
    xbmc.executebuiltin("Container.Refresh")
    return removed

def run_tools():
    options = [
        "Scan for New Games",
        "Refresh All Metadata",
        "Scrape Missing Metadata",
        "Update Steam250 ranks",
        "Clean Game Library",
        "Unhide manually hidden games",
        "Steam Account Settings",
        "View status",
        "Export diagnostics ZIP",
    ]
    selected = xbmcgui.Dialog().select("Steam Library - Tools", options)
    if selected is None or selected < 0:
        return
    try:
        if selected == 0:
            scan_for_new_games_0376()
        elif selected == 1:
            refresh_all_metadata_0376()
        elif selected == 2:
            scrape_missing_metadata_0376()
        elif selected == 3:
            refresh_steam250_ranks(force=True, notify=True)
        elif selected == 4:
            clean_game_library_0371(False)
        elif selected == 5:
            manage_hidden_games()
        elif selected == 6:
            steam_account_settings_menu()
        elif selected == 7:
            view_status()
        elif selected == 8:
            export_diag()
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, "Tools error:\n{}".format(exc))


_legacy_run_0376 = run

def run():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    if _redirect_legacy_listing_path_0379(params):
        return
    mode = params.get("mode", "root")
    if mode == "scan_new_games":
        scan_for_new_games_0376()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "refresh_names_sortnames":
        refresh_name_sortname_overwrite(force=True, notify=True)
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "add_missing_sortname":
        add_missing_sortname(force=True, notify=True)
        xbmcplugin.endOfDirectory(HANDLE)
    else:
        _legacy_run_0376()


# ---------------------------------------------------------------------------
# v0.3.78 - clean-schema database, no runtime migration
# ---------------------------------------------------------------------------
_REQUIRED_GAME_TABLES_0378 = (
    "games",
    "hidden_games",
    "manual_hidden_games",
    "collections",
    "library_membership",
    "library_sync_state",
)


def _open_db_0378():
    """Open the existing clean database without performing any schema/data writes."""
    ensure()
    con = sqlite3.connect(DB_PATH, timeout=30.0)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=30000")
    return con


def _table_exists_0378(con, table_name):
    row = con.execute(
        "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (str(table_name),)
    ).fetchone()
    return bool(row)


def _clean_schema_ready_0378(con):
    """Validate the supplied clean DB structurally. This function is read-only."""
    if not all(_table_exists_0378(con, table) for table in _REQUIRED_GAME_TABLES_0378):
        return False
    if _schema_names_0375(con, "games") != list(_GAME_COLS_0375):
        return False
    if _schema_names_0375(con, "hidden_games") != list(_GAME_COLS_0375) + [name for name, _ in _HIDDEN_EXTRA_0375]:
        return False
    if _schema_names_0375(con, "manual_hidden_games") != list(_GAME_COLS_0375) + [name for name, _ in _MANUAL_EXTRA_0375]:
        return False
    return True


def connect():
    """
    Open the already-clean Steam Library database.

    No migration, DELETE, normalisation, membership bootstrap, or schema marker
    write is allowed here. Cleanup happens only inside explicit sync/clean flows.
    """
    con = _open_db_0378()
    if _clean_schema_ready_0378(con):
        return con
    con.close()
    raise sqlite3.DatabaseError(
        "Steam Library database is missing or uses an unsupported old schema. "
        "Install the supplied clean database before opening the library."
    )

if __name__ == "__main__":
    run()

# -*- coding: utf-8 -*-
from __future__ import annotations

import concurrent.futures
import csv
import glob
import html
import json
import os
import re
import sqlite3
import subprocess
import sys
import time
import traceback
import urllib.parse
import urllib.request
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
UA = "Kodi-Steam-Library/0.3.22"
STEAM_BROWSER_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0"
NA = "N/A"


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_NAME, msg), level)


def bg_create(prog):
    try:
        prog.create(ADDON_NAME, "")
    except Exception:
        try:
            prog.create(ADDON_NAME)
        except Exception:
            pass


def bg_update(prog, pct, line):
    if not prog:
        return
    try:
        prog.update(int(pct), ADDON_NAME, str(line))
        return
    except Exception:
        pass
    try:
        prog.update(int(pct), str(line))
    except Exception:
        pass


def bg_close(prog):
    if not prog:
        return
    try:
        prog.close()
    except Exception:
        pass


def tr(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return xbmc.translatePath(path)


PROFILE = tr("special://profile/addon_data/{}/".format(ADDON_ID))
DB_PATH = os.path.join(PROFILE, "steam_library.db")
DIAG = os.path.join(PROFILE, "diagnostics")
ALIASES_PATH = os.path.join(PROFILE, "collection_aliases.json")
VISIBILITY_PATH = os.path.join(PROFILE, "collection_visibility.json")
OWNED_CACHE_PATH = os.path.join(PROFILE, "owned_games_cache.json")


DESIRED_GAME_COLUMNS = [
    ("appid", "TEXT PRIMARY KEY"),
    ("name", "TEXT"),
    ("year", "TEXT"),
    ("developer", "TEXT"),
    ("publisher", "TEXT"),
    ("genres", "TEXT"),
    ("short_description", "TEXT"),
    ("steam_review_percent", "TEXT"),
    ("steam_review_desc", "TEXT"),
    ("steam_review_total", "TEXT"),
    ("achievement_unlocked", "TEXT"),
    ("achievement_total", "TEXT"),
    ("completed", "TEXT"),
    ("finished", "TEXT"),
    ("metacritic_score", "TEXT"),
    ("esrb", "TEXT"),
    ("pegi", "TEXT"),
    ("poster_url", "TEXT"),
    ("thumb_url", "TEXT"),
    ("clearlogo_url", "TEXT"),
    ("fanart_url", "TEXT"),
    ("fanart1_url", "TEXT"),
    ("fanart2_url", "TEXT"),
    ("fanart3_url", "TEXT"),
    ("fanart4_url", "TEXT"),
    ("metadata_status", "TEXT"),
    ("metadata_source", "TEXT"),
    ("last_scraped", "INTEGER"),
]


def ensure():
    os.makedirs(PROFILE, exist_ok=True)
    os.makedirs(DIAG, exist_ok=True)


def s(key, default=""):
    v = ADDON.getSetting(key)
    return v if v else default


def b(key, default=False):
    v = ADDON.getSetting(key)
    return default if v == "" else str(v).lower() == "true"


def i(key, default=0):
    try:
        return int(ADDON.getSetting(key))
    except Exception:
        return default


def nz(value, default=NA):
    if value is None:
        return default
    value = str(value).strip()
    return value if value else default


def art_or_empty(value):
    if not value or str(value).strip() == NA:
        return ""
    return str(value).strip()


def create_games_table(cur, table_name):
    cols = ", ".join(["{} {}".format(k, t) for k, t in DESIRED_GAME_COLUMNS])
    cur.execute("CREATE TABLE IF NOT EXISTS {} ({})".format(table_name, cols))


def ensure_games_schema(con):
    cur = con.cursor()
    cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='games'")
    if not cur.fetchone():
        create_games_table(cur, "games")
        con.commit()
        return

    cur.execute("PRAGMA table_info(games)")
    old_cols = [r[1] for r in cur.fetchall()]
    desired = [k for k, _ in DESIRED_GAME_COLUMNS]

    if old_cols == desired:
        return

    create_games_table(cur, "games_new")
    expressions = []
    for col in desired:
        if col in old_cols:
            expressions.append(col)
        elif col == "developer" and "developers" in old_cols:
            expressions.append("developers")
        elif col == "publisher" and "publishers" in old_cols:
            expressions.append("publishers")
        elif col == "thumb_url" and "header_image" in old_cols:
            expressions.append("header_image")
        elif col == "metadata_status":
            expressions.append("'migrated'")
        elif col == "metadata_source":
            expressions.append("'legacy'")
        elif col == "completed" and "achievement_status" in old_cols:
            expressions.append("CASE WHEN achievement_status='COMPLETED' THEN '1' ELSE 'N/A' END")
        else:
            expressions.append("NULL")

    cur.execute(
        "INSERT OR REPLACE INTO games_new({}) SELECT {} FROM games".format(
            ", ".join(desired), ", ".join(expressions)
        )
    )
    cur.execute("DROP TABLE games")
    cur.execute("ALTER TABLE games_new RENAME TO games")
    con.commit()


def connect():
    ensure()
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    ensure_games_schema(con)
    con.execute("""CREATE TABLE IF NOT EXISTS collections (
        collection_id TEXT, name TEXT, appid TEXT, PRIMARY KEY(collection_id, appid)
    )""")
    con.execute("""CREATE TABLE IF NOT EXISTS hidden_games (
        appid TEXT PRIMARY KEY,
        source_collection_id TEXT,
        source_collection_name TEXT,
        hidden_at INTEGER
    )""")
    con.commit()
    return con


def load_collection_visibility():
    try:
        if os.path.exists(VISIBILITY_PATH):
            data = json.loads(open(VISIBILITY_PATH, "r", encoding="utf-8").read())
            if isinstance(data, dict):
                hidden = data.get("hidden_ids", [])
                if isinstance(hidden, list):
                    return {"hidden_ids": [str(x) for x in hidden]}
    except Exception as exc:
        log("Failed reading collection visibility: {}".format(exc), xbmc.LOGWARNING)
    return {"hidden_ids": []}


def save_collection_visibility(data):
    ensure()
    hidden = data.get("hidden_ids", [])
    with open(VISIBILITY_PATH, "w", encoding="utf-8") as f:
        f.write(json.dumps({"hidden_ids": [str(x) for x in hidden]}, indent=2, ensure_ascii=False))


def hidden_collection_keywords(value):
    text = str(value or "").strip().lower()
    text = re.sub(r"\s+", " ", text)
    return text in ("hidden", "hidden games", "steam hidden", "steamlibrary hidden") or text.endswith("hidden games")


def is_steam_hidden_collection(collection):
    # Only Steam's actual Hidden/Hidden Games collection is treated as hidden_games.
    # Manually hiding a collection folder does NOT hide its games anymore.
    return hidden_collection_keywords(collection.get("name")) or hidden_collection_keywords(collection.get("id"))


def collection_hidden(collection):
    cid = str(collection.get("id") or "")
    return is_steam_hidden_collection(collection) or cid in set(load_collection_visibility().get("hidden_ids", []))


def hidden_appids():
    try:
        con = connect()
        cur = con.cursor()
        cur.execute("SELECT appid FROM hidden_games")
        vals = set(str(r[0]) for r in cur.fetchall())
        con.close()
        return vals
    except Exception as exc:
        log("Failed reading hidden games: {}".format(exc), xbmc.LOGWARNING)
        return set()


def is_hidden_game(appid):
    if not appid:
        return False
    return str(appid) in hidden_appids()


def filter_hidden_appids(appids):
    hidden = hidden_appids()
    return [str(a) for a in appids if str(a) not in hidden]


def hide_games(appids, source_collection_id="", source_collection_name=""):
    appids = [str(a) for a in (appids or []) if str(a)]
    if not appids:
        return 0
    con = connect()
    cur = con.cursor()
    now = int(time.time())
    for appid in appids:
        cur.execute("""INSERT OR REPLACE INTO hidden_games(appid, source_collection_id, source_collection_name, hidden_at)
                       VALUES(?,?,?,?)""", (appid, str(source_collection_id or ""), str(source_collection_name or ""), now))
    con.commit()
    con.close()
    return len(appids)


def sync_hidden_games_from_collections(con, cols):
    # Rebuild hidden_games ONLY from Steam's actual Hidden/Hidden Games collection.
    # This also cleans old bad rows created by earlier versions when "Hide this collection"
    # inserted every collection member into hidden_games.
    cur = con.cursor()
    cur.execute("DELETE FROM hidden_games")
    now = int(time.time())
    count = 0
    for c in cols:
        if not is_steam_hidden_collection(c):
            continue
        cid = str(c.get("id") or "")
        name = str(c.get("name") or "")
        for appid in c.get("appids", []):
            cur.execute("""INSERT OR REPLACE INTO hidden_games(appid, source_collection_id, source_collection_name, hidden_at)
                           VALUES(?,?,?,?)""", (str(appid), cid, name, now))
            count += 1
    return count


def collection_visible_appids(collection):
    return filter_hidden_appids([str(a) for a in collection.get("appids", [])])


def purge_hidden_games_from_runtime_rows():
    # Keep DB rows for diagnostics/history, but active runtime queries always skip hidden_games.
    return


def load_collection_aliases():
    try:
        if os.path.exists(ALIASES_PATH):
            data = json.loads(open(ALIASES_PATH, "r", encoding="utf-8").read())
            if isinstance(data, dict):
                return data
    except Exception as exc:
        log("Failed reading collection aliases: {}".format(exc), xbmc.LOGWARNING)
    return {}


def save_collection_aliases(data):
    ensure()
    with open(ALIASES_PATH, "w", encoding="utf-8") as f:
        f.write(json.dumps(data, indent=2, ensure_ascii=False))


def collection_display_name(collection):
    aliases = load_collection_aliases()
    cid = str(collection.get("id") or "")
    original = str(collection.get("name") or cid)
    alias = aliases.get(cid, "")
    return alias if alias else original


def split_names(value):
    if not value:
        return set()
    out = set()
    for chunk in str(value).replace(";", ",").split(","):
        x = chunk.strip().lower()
        if x:
            out.add(x)
    return out


def collection_visible(collection):
    # Visibility is now based on stable Steam collection_id, not name.
    return not collection_hidden(collection)


def filter_collections(cols):
    return [c for c in cols if collection_visible(c)]


def all_games_source_collections(all_cols, visible_cols):
    # If enabled, All Games follows collection visibility and excludes hidden collection folders.
    # Default TRUE because the user wants All Games except hidden.
    return visible_cols if b("all_games_exclude_hidden", True) else all_cols


def url_for(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def steam_request_headers(url="", extra=None):
    # Steam Store sometimes rejects bare/custom urllib clients with 403.
    # Use browser-like headers and mature-content cookies for appdetails/html/reviews/assets.
    u = str(url or "").lower()
    is_steam = (
        "store.steampowered.com" in u or
        "steamcommunity.com" in u or
        "steamstatic.com" in u or
        "akamai.steamstatic.com" in u or
        "fastly.steamstatic.com" in u
    )
    h = {
        "User-Agent": STEAM_BROWSER_UA if is_steam else UA,
        "Accept": "application/json,text/html,image/avif,image/webp,*/*",
        "Accept-Language": "en-US,en;q=0.9",
        "Connection": "close",
    }
    if "store.steampowered.com" in u:
        h["Referer"] = "https://store.steampowered.com/"
        h["Cookie"] = "birthtime=568022401; lastagecheckage=1-January-1988; wants_mature_content=1; mature_content=1"
    if extra:
        h.update(extra)
    return h


def http_json(url, timeout=25, headers=None):
    req = urllib.request.Request(url, headers=steam_request_headers(url, headers))
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace"))


def http_text(url, timeout=20, headers=None):
    req = urllib.request.Request(url, headers=steam_request_headers(url, headers))
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode("utf-8", errors="replace")


def url_exists(url, timeout=6):
    if not url or url == NA:
        return False
    try:
        req = urllib.request.Request(url, headers=steam_request_headers(url), method="HEAD")
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return 200 <= int(r.status) < 400
    except Exception:
        try:
            req = urllib.request.Request(url, headers=steam_request_headers(url, {"Range": "bytes=0-0"}))
            with urllib.request.urlopen(req, timeout=timeout) as r:
                return 200 <= int(r.status) < 400
        except Exception:
            return False


def cloud_json():
    manual = os.path.expandvars((s("cloud_json_path") or "").strip().strip('"'))
    if manual and os.path.exists(manual):
        return manual
    roots = [os.path.expandvars(r"%ProgramFiles(x86)%\Steam\userdata"), os.path.expandvars(r"%ProgramFiles%\Steam\userdata")]
    found = []
    for root in roots:
        if root and "%" not in root and os.path.isdir(root):
            found += glob.glob(os.path.join(root, "*", "config", "cloudstorage", "cloud-storage-namespace-1.json"))
    found = [(os.path.getmtime(p), p) for p in set(found) if os.path.exists(p)]
    found.sort(reverse=True)
    return found[0][1] if found else ""


def parse_collections(path):
    if not path or not os.path.exists(path):
        return []
    try:
        raw = json.loads(open(path, "r", encoding="utf-8").read())
    except Exception as exc:
        log("Cannot read cloud collections: {}".format(exc), xbmc.LOGWARNING)
        return []
    out = []
    for item in raw:
        if not isinstance(item, list) or len(item) < 2:
            continue
        key, payload = item[0], item[1]
        if not str(key).startswith("user-collections."):
            continue
        try:
            data = json.loads(payload.get("value") or "{}")
        except Exception:
            continue
        name = str(data.get("name") or data.get("id") or key)
        cid = str(data.get("id") or key)
        removed = set(str(x) for x in (data.get("removed") or []))
        appids = [str(x) for x in (data.get("added") or []) if str(x) not in removed]
        if appids:
            out.append({"id": cid, "name": name, "appids": appids})
    return out


def finished_keywords(text):
    t = (text or "").lower()
    return ("finished" in t) or ("completed" in t) or ("complete" in t)


def update_finished_flags(con, cols):
    cur = con.cursor()
    cur.execute("UPDATE games SET finished='0' WHERE appid IS NOT NULL")
    done = set()
    for c in cols:
        if finished_keywords(c.get("name")) or finished_keywords(c.get("id")):
            done.update(str(a) for a in c.get("appids", []))
    for appid in done:
        cur.execute("UPDATE games SET finished='1' WHERE appid=?", (appid,))
    con.commit()


def sync_collections():
    con = connect()
    cur = con.cursor()
    path = cloud_json()
    cols = parse_collections(path)
    cur.execute("DELETE FROM collections")
    for c in cols:
        for appid in c["appids"]:
            cur.execute("INSERT OR REPLACE INTO collections(collection_id,name,appid) VALUES(?,?,?)", (c["id"], c["name"], appid))
    sync_hidden_games_from_collections(con, cols)
    con.commit()
    update_finished_flags(con, cols)
    con.close()
    return cols, path


def all_appids(cols, include_hidden=False):
    seen, appids = set(), []
    hidden = set() if include_hidden else hidden_appids()
    for c in cols:
        for a in c["appids"]:
            a = str(a)
            if a in hidden:
                continue
            if a not in seen:
                seen.add(a)
                appids.append(a)
    return appids


def finished_for_appid(appid, cols):
    appid = str(appid)
    for c in cols:
        if appid in [str(x) for x in c.get("appids", [])]:
            if finished_keywords(c.get("name")) or finished_keywords(c.get("id")):
                return "1"
    return "0"


def poster(appid):
    return "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{}/library_600x900.jpg".format(appid)


def steam_logo_direct(appid):
    return "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{}/logo.png".format(appid)


def parse_store_logo(html_text, appid):
    if not html_text:
        return ""
    text = html_text.replace("\\/", "/")
    pattern = r'https?://shared\.fastly\.steamstatic\.com/store_item_assets/steam/apps/{}/[^"\']*?logo\.png'.format(re.escape(str(appid)))
    m = re.search(pattern, text, flags=re.I)
    if m:
        return html.unescape(m.group(0))
    return ""


def steam_store_html(appid):
    try:
        return http_text("https://store.steampowered.com/app/{}/".format(appid), timeout=18)
    except Exception as exc:
        log("Store HTML failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return ""


def parse_ratings(html_text, data):
    # Steam rating display is inconsistent by region/app. Keep N/A when no clear rating is present.
    esrb = NA
    pegi = NA
    text = html.unescape(re.sub(r"\s+", " ", html_text or ""))

    m = re.search(r'\bESRB\b[^<]{0,120}\b(E|E10\+|T|M|AO|RP)\b', text, re.I)
    if m:
        esrb = m.group(1).upper()

    m = re.search(r'\bPEGI\b[^0-9]{0,120}\b(3|7|12|16|18)\b', text, re.I)
    if m:
        pegi = m.group(1)

    # required_age is not ESRB/PEGI, but keep as a weak ESRB-style fallback only if no rating block exists.
    req_age = str((data or {}).get("required_age") or "").strip()
    if esrb == NA and req_age and req_age not in ("0", "None"):
        esrb = "{}+".format(req_age)

    return esrb, pegi


def owned_games_map(force=False):
    key, sid = s("steam_api_key"), s("steam_id64")
    if not key or not sid:
        return {}
    try:
        if not force and os.path.exists(OWNED_CACHE_PATH):
            data = json.loads(open(OWNED_CACHE_PATH, "r", encoding="utf-8").read())
            if time.time() - float(data.get("timestamp", 0)) < 86400:
                return {str(g.get("appid")): g for g in data.get("games", []) if g.get("appid")}
    except Exception:
        pass

    try:
        url = "https://api.steampowered.com/IPlayerService/GetOwnedGames/v0001/?key={}&steamid={}&include_appinfo=1&include_played_free_games=1&format=json".format(
            urllib.parse.quote(key), urllib.parse.quote(sid)
        )
        js = http_json(url, timeout=30)
        games = ((js.get("response") or {}).get("games") or [])
        ensure()
        open(OWNED_CACHE_PATH, "w", encoding="utf-8").write(json.dumps({"timestamp": time.time(), "games": games}, ensure_ascii=False))
        return {str(g.get("appid")): g for g in games if g.get("appid")}
    except Exception as exc:
        log("OwnedGames fallback failed: {}".format(exc), xbmc.LOGWARNING)
        return {}


def steam_library_roots():
    roots = []
    default = os.path.expandvars(r"%ProgramFiles(x86)%\Steam")
    if default and "%" not in default and os.path.isdir(default):
        roots.append(default)
        vdf = os.path.join(default, "steamapps", "libraryfolders.vdf")
        try:
            txt = open(vdf, "r", encoding="utf-8", errors="replace").read()
            for p in re.findall(r'"path"\s+"([^"]+)"', txt):
                p = p.replace("\\\\", "\\")
                if os.path.isdir(p):
                    roots.append(p)
        except Exception:
            pass
    seen = []
    for r in roots:
        if r not in seen:
            seen.append(r)
    return seen


def appmanifest_title(appid):
    appid = str(appid)
    for root in steam_library_roots():
        p = os.path.join(root, "steamapps", "appmanifest_{}.acf".format(appid))
        if os.path.exists(p):
            try:
                txt = open(p, "r", encoding="utf-8", errors="replace").read()
                m = re.search(r'"name"\s+"([^"]+)"', txt)
                if m:
                    return m.group(1).strip()
            except Exception:
                pass
    return ""


def existing_title(appid):
    try:
        con = connect()
        cur = con.cursor()
        cur.execute("SELECT name FROM games WHERE appid=?", (str(appid),))
        row = cur.fetchone()
        con.close()
        if row and row[0] and not str(row[0]).startswith("Steam App "):
            return str(row[0]).strip()
    except Exception:
        pass
    return ""


def steamcommunity_title(appid):
    try:
        html_text = http_text("https://steamcommunity.com/app/{}".format(appid), timeout=20)
        m = re.search(r"<title>\s*Steam Community\s*::\s*(.*?)\s*</title>", html_text, re.I | re.S)
        if m:
            title = html.unescape(re.sub(r"\s+", " ", m.group(1))).strip()
            if title and title.lower() not in ("error", "steam community"):
                return title
        m = re.search(r'class=["\']apphub_AppName["\'][^>]*>\s*(.*?)\s*</', html_text, re.I | re.S)
        if m:
            title = html.unescape(re.sub(r"<[^>]+>", "", m.group(1))).strip()
            if title:
                return title
    except Exception as exc:
        log("Steam Community title fallback failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
    return ""


def fallback_title(appid):
    og = owned_games_map(False)
    owned = og.get(str(appid), {})
    return (
        existing_title(appid)
        or nz(owned.get("name"), "")
        or appmanifest_title(appid)
        or steamcommunity_title(appid)
        or "Steam App {}".format(appid)
    )


def sgdb_headers():
    key = s("steamgriddb_api_key")
    return {"Authorization": "Bearer {}".format(key)} if key else {}


def sgdb_game_id(appid):
    headers = sgdb_headers()
    if not headers:
        return ""
    try:
        js = http_json("https://www.steamgriddb.com/api/v2/games/steam/{}".format(appid), timeout=20, headers=headers)
        data = js.get("data") or {}
        return str(data.get("id") or "")
    except Exception as exc:
        log("SGDB game lookup failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return ""


def sgdb_assets(appid, kind, limit=12):
    gid = sgdb_game_id(appid)
    headers = sgdb_headers()
    if not gid or not headers:
        return []
    try:
        js = http_json("https://www.steamgriddb.com/api/v2/{}/game/{}".format(kind, gid), timeout=25, headers=headers)
        arr = js.get("data") or []
        out = []
        for a in arr[:limit]:
            url = a.get("url")
            if not url:
                continue
            out.append({
                "url": url,
                "width": a.get("width") or "",
                "height": a.get("height") or "",
                "source": "SteamGridDB",
                "label": "SteamGridDB {} {}x{}".format(kind, a.get("width") or "", a.get("height") or "").strip()
            })
        return out
    except Exception as exc:
        log("SGDB assets failed {} {}: {}".format(kind, appid, exc), xbmc.LOGWARNING)
        return []


def first_sgdb_asset(appid, kind):
    arr = sgdb_assets(appid, kind, limit=1)
    return arr[0]["url"] if arr else ""


def reviews(appid):
    if not b("fetch_steam_reviews", True):
        return {"steam_review_percent": NA, "steam_review_desc": NA, "steam_review_total": NA}
    try:
        js = http_json("https://store.steampowered.com/appreviews/{}?json=1&language=all&purchase_type=all&num_per_page=0".format(appid), 20)
        q = js.get("query_summary") or {}
        pos, neg = int(q.get("total_positive") or 0), int(q.get("total_negative") or 0)
        total = int(q.get("total_reviews") or pos + neg)
        if total <= 0:
            return {"steam_review_percent": NA, "steam_review_desc": NA, "steam_review_total": NA}
        pct = str(int(round(pos * 100.0 / total)))
        return {
            "steam_review_percent": pct,
            "steam_review_desc": q.get("review_score_desc") or NA,
            "steam_review_total": str(total),
        }
    except Exception as exc:
        log("Reviews failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return {"_review_error": str(exc)}


def achievements(appid):
    if not b("fetch_achievements", True):
        return {"achievement_unlocked": NA, "achievement_total": NA, "completed": NA}
    key, sid = s("steam_api_key"), s("steam_id64")
    if not key or not sid:
        return {"achievement_unlocked": NA, "achievement_total": NA, "completed": NA}
    try:
        url = "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v0001/?appid={}&key={}&steamid={}&l=en".format(
            urllib.parse.quote(str(appid)), urllib.parse.quote(key), urllib.parse.quote(sid)
        )
        js = http_json(url, 20)
        arr = ((js.get("playerstats") or {}).get("achievements") or [])
        total = len(arr)
        if total <= 0:
            return {"achievement_unlocked": NA, "achievement_total": NA, "completed": NA}
        unlocked = sum(1 for a in arr if int(a.get("achieved") or 0) == 1)
        return {
            "achievement_unlocked": str(unlocked),
            "achievement_total": str(total),
            "completed": "1" if unlocked == total else "0",
        }
    except Exception as exc:
        log("Achievements failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return {"_achievement_error": str(exc)}


def unique_urls(urls):
    out, seen = [], set()
    for u in urls:
        u = art_or_empty(u)
        if u and u not in seen:
            seen.add(u)
            out.append(u)
    return out


def auto_art(appid, data=None, store_html_text=""):
    data = data or {}
    appid = str(appid)

    header = data.get("header_image") or ""
    thumb = header or data.get("capsule_image") or NA

    steam_poster = poster(appid)
    poster_url = steam_poster
    # SGDB grids only if Steam poster is proven missing.
    if not url_exists(steam_poster, timeout=4):
        poster_url = first_sgdb_asset(appid, "grids") or NA

    shots = [x.get("path_full") for x in (data.get("screenshots") or []) if x.get("path_full")]
    # Auto fanart: Steam screenshots 1-5 only.
    fan_candidates = unique_urls(shots)
    fan_slots = fan_candidates[:5]
    while len(fan_slots) < 5:
        fan_slots.append(NA)

    logo = parse_store_logo(store_html_text, appid)
    if not logo:
        direct = steam_logo_direct(appid)
        logo = direct if url_exists(direct, timeout=4) else ""
    if not logo:
        logo = first_sgdb_asset(appid, "logos") or NA

    return {
        "poster_url": nz(poster_url),
        "thumb_url": nz(thumb),
        "clearlogo_url": nz(logo),
        "fanart_url": nz(fan_slots[0]),
        "fanart1_url": nz(fan_slots[1]),
        "fanart2_url": nz(fan_slots[2]),
        "fanart3_url": nz(fan_slots[3]),
        "fanart4_url": nz(fan_slots[4]),
    }


def partial_game(appid, reason, cols=None):
    title = fallback_title(appid)
    g = {k: None for k, _ in DESIRED_GAME_COLUMNS}
    g.update({
        "appid": str(appid),
        "name": title,
        "year": NA,
        "developer": NA,
        "publisher": NA,
        "genres": NA,
        "short_description": NA,
        "steam_review_percent": NA,
        "steam_review_desc": NA,
        "steam_review_total": NA,
        "achievement_unlocked": NA,
        "achievement_total": NA,
        "completed": NA,
        "finished": finished_for_appid(appid, cols or []),
        "metacritic_score": NA,
        "esrb": NA,
        "pegi": NA,
        "poster_url": poster(appid),
        "thumb_url": NA,
        "clearlogo_url": NA,
        "fanart_url": NA,
        "fanart1_url": NA,
        "fanart2_url": NA,
        "fanart3_url": NA,
        "fanart4_url": NA,
        "metadata_status": "partial_title_only",
        "metadata_source": "steamcommunity_or_ownedgames",
        "last_scraped": int(time.time()),
        "_partial_reason": reason,
    })
    return g


def scrape(appid, cols=None):
    cols = cols or []
    try:
        js = http_json("https://store.steampowered.com/api/appdetails?appids={}&cc=US&l=english&v=1".format(appid), 30)
    except Exception as exc:
        # Do not leave DB empty just because Steam Store temporarily blocks appdetails.
        # Save a partial title row from OwnedGames/appmanifest/community and retry later.
        return partial_game(appid, "appdetails_request_failed: {}".format(exc), cols)

    app = js.get(str(appid), {})
    if not app.get("success"):
        return partial_game(appid, "appdetails_success_false", cols)

    d = app.get("data") or {}
    release = ((d.get("release_date") or {}).get("date") or "")
    year = ""
    for t in release.replace(",", " ").split():
        if t.isdigit() and len(t) == 4:
            year = t
            break

    store_html_text = steam_store_html(appid)
    esrb, pegi = parse_ratings(store_html_text, d)
    art = auto_art(appid, d, store_html_text)

    g = {k: None for k, _ in DESIRED_GAME_COLUMNS}
    g.update({
        "appid": str(appid),
        "name": nz(d.get("name"), fallback_title(appid)),
        "year": nz(year),
        "developer": nz(" / ".join(d.get("developers") or [])),
        "publisher": nz(" / ".join(d.get("publishers") or [])),
        "genres": nz(" / ".join([x.get("description", "") for x in (d.get("genres") or []) if x.get("description")])),
        "short_description": nz(d.get("short_description")),
        "steam_review_percent": "",
        "steam_review_desc": "",
        "steam_review_total": "",
        "achievement_unlocked": "",
        "achievement_total": "",
        "completed": "",
        "finished": finished_for_appid(appid, cols),
        "metacritic_score": nz((d.get("metacritic") or {}).get("score")),
        "esrb": nz(esrb),
        "pegi": nz(pegi),
        "metadata_status": "ok",
        "metadata_source": "steam_appdetails",
        "last_scraped": int(time.time()),
    })
    g.update(art)

    rv = reviews(appid)
    if "_review_error" not in rv:
        g.update(rv)

    ach = achievements(appid)
    if "_achievement_error" not in ach:
        g.update(ach)

    return g


def save_game(g):
    if g and is_hidden_game(g.get("appid")):
        return
    cols = [k for k, _ in DESIRED_GAME_COLUMNS]
    data = {}
    for k in cols:
        data[k] = g.get(k)
    placeholders = ",".join([":" + k for k in cols])
    con = connect()
    cur = con.cursor()
    cur.execute(
        "INSERT OR REPLACE INTO games({}) VALUES({})".format(",".join(cols), placeholders),
        data,
    )
    con.commit()
    con.close()


def get_game(appid, force=False, cols=None):
    if is_hidden_game(appid):
        return partial_game(appid, "hidden_game_skipped", cols or [])
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT * FROM games WHERE appid=?", (str(appid),))
    row = cur.fetchone()
    con.close()
    if row and not force:
        last = row["last_scraped"] or 0
        if int(time.time()) - int(last) < i("cache_days", 30) * 86400:
            return dict(row)
    try:
        g = scrape(appid, cols or [])
        save_game(g)
        return g
    except Exception as exc:
        log("Scrape failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        if row:
            return dict(row)
        return partial_game(appid, "scrape_error_not_saved: {}".format(exc), cols or [])


def clean_html(text):
    if not text:
        return ""
    text = re.sub(r"<br\s*/?>", "\n", str(text), flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    return html.unescape(text).strip()


def steam_meta_line(g):
    parts = ["STEAM"]

    if str(g.get("completed") or "") == "1":
        parts.append("COMPLETED")
    elif str(g.get("finished") or "") == "1":
        parts.append("FINISHED")

    pct = g.get("steam_review_percent")
    desc = g.get("steam_review_desc")
    if pct and pct != NA:
        review = "{}%".format(pct)
        if desc and desc != NA:
            review += " {}".format(desc)
        parts.append(review)

    year = g.get("year")
    if year and year != NA:
        parts.append(str(year))

    esrb = g.get("esrb")
    pegi = g.get("pegi")
    if esrb and esrb != NA:
        parts.append("Rating {}".format(esrb))
    elif pegi and pegi != NA:
        parts.append("PEGI {}".format(pegi))

    return " • ".join(parts)


def force_poster_view():
    # AF3 includes View_502_Poster_Row, so this is the safest first step before skin XML patching.
    try:
        xbmc.executebuiltin("Container.SetViewMode(502)")
    except Exception as exc:
        log("SetViewMode(502) failed: {}".format(exc), xbmc.LOGWARNING)


def make_game_item(g):
    appid = g["appid"]
    title = g.get("name") or "Steam App {}".format(appid)
    li = xbmcgui.ListItem(label=title)
    li.setProperty("IsPlayable", "true")

    plot = []
    if g.get("short_description") and g.get("short_description") != NA:
        plot.append(clean_html(g.get("short_description")))

    meta = []
    if g.get("steam_review_percent") and g.get("steam_review_percent") != NA:
        line = "Steam: {}%".format(g.get("steam_review_percent"))
        if g.get("steam_review_desc") and g.get("steam_review_desc") != NA:
            line += " {}".format(g.get("steam_review_desc"))
        if g.get("steam_review_total") and g.get("steam_review_total") != NA:
            line += " ({})".format(g.get("steam_review_total"))
        meta.append(line)
    if g.get("achievement_total") and g.get("achievement_total") != NA:
        meta.append("Achievements: {}/{}".format(g.get("achievement_unlocked") or "0", g.get("achievement_total")))
    if g.get("completed") == "1":
        meta.append("COMPLETED")
    if g.get("finished") == "1":
        meta.append("FINISHED")
    if g.get("developer") and g.get("developer") != NA:
        meta.append("Developer: " + g.get("developer"))
    if g.get("publisher") and g.get("publisher") != NA:
        meta.append("Publisher: " + g.get("publisher"))
    if g.get("metacritic_score") and g.get("metacritic_score") != NA:
        meta.append("Metacritic: " + g.get("metacritic_score"))
    if meta:
        plot.append("\n".join(meta))

    meta_line = steam_meta_line(g)

    try:
        li.setInfo("video", {
            "title": title,
            "originaltitle": title,
            "sorttitle": title,
            "mediatype": "movie",
            "plot": "\n\n".join(plot),
            "plotoutline": clean_html(g.get("short_description") or "") if g.get("short_description") != NA else "",
            "tagline": meta_line,
            "genre": "" if g.get("genres") == NA else (g.get("genres") or ""),
            "year": int(g["year"]) if str(g.get("year") or "").isdigit() else 0,
            "studio": "" if g.get("developer") == NA else (g.get("developer") or ""),
            "mpaa": "" if g.get("esrb") == NA else (g.get("esrb") or ""),
        })
    except Exception:
        pass

    poster_art = art_or_empty(g.get("poster_url"))
    thumb_art = poster_art or art_or_empty(g.get("thumb_url"))
    fanart_art = art_or_empty(g.get("fanart_url"))
    art = {
        "poster": poster_art,
        "thumb": thumb_art,
        "icon": thumb_art,
        "fanart": fanart_art,
        "landscape": fanart_art or art_or_empty(g.get("thumb_url")) or poster_art,
        "clearlogo": art_or_empty(g.get("clearlogo_url")),
    }
    li.setArt({k: v for k, v in art.items() if v})

    for k in ["appid","steam_review_percent","steam_review_desc","steam_review_total","achievement_unlocked","achievement_total","completed","finished","year","developer","publisher","esrb","pegi"]:
        li.setProperty(k, str(g.get(k) or ""))
    for idx, col in enumerate(["fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"], 0):
        li.setProperty("fanart{}".format(idx if idx else ""), art_or_empty(g.get(col)))

    li.setProperty("steam_meta_line", meta_line)
    li.setProperty("steam_poster_view", "true")
    li.setProperty("steam_appid", appid)
    li.addContextMenuItems([
        ("Refresh metadata", "RunPlugin({})".format(url_for(mode="refresh", appid=appid))),
        ("Select artwork", "RunPlugin({})".format(url_for(mode="select_artwork", appid=appid))),
        ("Open Steam store page", "RunPlugin({})".format(url_for(mode="store", appid=appid))),
        ("Steam Library Tools", "RunPlugin({})".format(url_for(mode="run_tools"))),
        ("Addon settings", "Addon.OpenSettings({})".format(ADDON_ID)),
    ])
    return li


def add_dir(label, mode, **kwargs):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": "DefaultFolder.png"})
    cm = [
        ("Steam Library Tools", "RunPlugin({})".format(url_for(mode="run_tools"))),
    ]
    cname = kwargs.pop("collection_name_for_context", "")
    cid_ctx = kwargs.pop("collection_id_for_context", "")
    if cname:
        cm.insert(0, ("Hide this collection", "RunPlugin({})".format(url_for(mode="hide_collection", collection_id=cid_ctx, name=cname))))
        if cid_ctx:
            cm.insert(0, ("Rename collection", "RunPlugin({})".format(url_for(mode="rename_collection", collection_id=cid_ctx, name=cname))))
    li.addContextMenuItems(cm)
    params = {"mode": mode}
    params.update(kwargs)
    xbmcplugin.addDirectoryItem(HANDLE, url_for(**params), li, True)


def root():
    all_cols, path = sync_collections()
    visible_cols = [c for c in filter_collections(all_cols) if collection_visible_appids(c)]

    if all_cols:
        if b("show_all_games", True):
            all_games_cols = all_games_source_collections(all_cols, visible_cols)
            add_dir("All Games ({})".format(len(all_appids(all_games_cols))), "list", collection="__all__")
        for c in visible_cols:
            add_dir("{} ({})".format(collection_display_name(c), len(collection_visible_appids(c))), "list", collection_id=c["id"], collection_name_for_context=c["name"], collection_id_for_context=c["id"])
        if not visible_cols:
            li = xbmcgui.ListItem(label="No visible collection folders")
            li.setInfo("video", {"plot": "All collection folders are hidden. Use Steam Library Tools > Reset collection visibility."})
            li.addContextMenuItems([
                ("Reset collection visibility", "RunPlugin({})".format(url_for(mode="reset_collection_visibility"))),
                ("Steam Library Tools", "RunPlugin({})".format(url_for(mode="run_tools"))),
                ("Addon settings", "Addon.OpenSettings({})".format(ADDON_ID)),
            ])
            xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="noop"), li, False)
    else:
        li = xbmcgui.ListItem(label="No Steam client collections")
        li.setInfo("video", {"plot": "No Steam collections found.\nCloud JSON: {}".format(path or "not found")})
        li.addContextMenuItems([("Steam Library Tools", "RunPlugin({})".format(url_for(mode="run_tools"))), ("Addon settings", "Addon.OpenSettings({})".format(ADDON_ID))])
        xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="noop"), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def appids_for(params):
    all_cols, _ = sync_collections()
    visible_cols = filter_collections(all_cols)
    if params.get("collection") == "__all__":
        all_games_cols = all_games_source_collections(all_cols, visible_cols)
        return all_appids(all_games_cols), all_games_cols
    cid = params.get("collection_id")
    for c in all_cols:
        if c["id"] == cid:
            return collection_visible_appids(c), all_cols
    return [], visible_cols


def list_games(params):
    appids, cols = appids_for(params)
    # Use movie content type so AF3 chooses the same poster/media include family as video shelves.
    # Items still launch through plugin.program.steam.library mode=play.
    xbmcplugin.setContent(HANDLE, "movies")
    total = len(appids)
    progress = None
    if total > 30:
        progress = xbmcgui.DialogProgressBG()
        try:
            progress.create(ADDON_NAME, "")
        except Exception:
            progress = None
    for idx, appid in enumerate(appids, 1):
        if progress and (idx == 1 or idx % 10 == 0 or idx == total):
            bg_update(progress, int(idx * 100 / max(total, 1)), "LOADING - {}/{}".format(idx, total))
        g = get_game(appid, False, cols)
        xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="play", appid=appid), make_game_item(g), False, total)
    bg_close(progress)
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE)
    force_poster_view()


def launch(appid):
    steam_url = "steam://rungameid/{}".format(appid)
    try:
        method = i("launch_method", 0)
        if method == 0 and hasattr(os, "startfile"):
            os.startfile(steam_url)
        elif method == 1:
            subprocess.Popen(["cmd", "/c", "start", "", steam_url], shell=False)
        else:
            xbmc.executebuiltin('System.Exec("{}")'.format(steam_url))
        xbmcgui.Dialog().notification(ADDON_NAME, "Launching Steam app {}".format(appid), xbmcgui.NOTIFICATION_INFO, 2500)
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, "Gagal launch Steam app {}\n{}".format(appid, exc))


def refresh_one(appid):
    if is_hidden_game(appid):
        xbmcgui.Dialog().notification(ADDON_NAME, "Hidden game skipped.", xbmcgui.NOTIFICATION_INFO, 2500)
        return
    cols, _ = sync_collections()
    g = scrape(appid, cols)
    save_game(g)
    xbmcgui.Dialog().notification(ADDON_NAME, "Metadata refreshed: {}".format(g.get("name") or appid), xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")


def open_store(appid):
    try:
        os.startfile("https://store.steampowered.com/app/{}/".format(appid))
    except Exception:
        xbmc.executebuiltin("System.Exec({})".format("https://store.steampowered.com/app/{}/".format(appid)))


def choose_visible_collections():
    cols, path = sync_collections()
    if not cols:
        xbmcgui.Dialog().ok(ADDON_NAME, "No Steam client collections found.\n{}".format(path or "cloud JSON not found"))
        return
    labels = [collection_display_name(c) for c in cols]
    hidden = set(load_collection_visibility().get("hidden_ids", []))
    pre = [idx for idx, c in enumerate(cols) if str(c.get("id")) not in hidden]
    try:
        selected = xbmcgui.Dialog().multiselect("Visible Steam Collections", labels, preselect=pre)
    except TypeError:
        selected = xbmcgui.Dialog().multiselect("Visible Steam Collections", labels)
    if selected is None:
        return
    selected_ids = set(str(cols[i].get("id")) for i in selected)
    hidden_ids = [str(c.get("id")) for c in cols if str(c.get("id")) not in selected_ids]
    save_collection_visibility({"hidden_ids": hidden_ids})
    xbmc.executebuiltin("Container.Refresh")


def show_all_collections():
    reset_collection_visibility()


def hide_collection(name=None, collection_id=None):
    if not collection_id:
        return
    cid = str(collection_id)

    data = load_collection_visibility()
    hidden = data.get("hidden_ids", [])
    if cid not in hidden:
        hidden.append(cid)
    save_collection_visibility({"hidden_ids": hidden})

    # Important: hiding a collection folder does NOT insert its games into hidden_games.
    # Only Steam's real Hidden/Hidden Games collection is synced into hidden_games.
    xbmcgui.Dialog().notification(ADDON_NAME, "Collection folder hidden", xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def reset_collection_visibility():
    save_collection_visibility({"hidden_ids": []})
    ADDON.setSetting("hidden_collection_names", "")
    ADDON.setSetting("visible_collection_names", "")
    ADDON.setSetting("collection_filter_mode", "0")
    sync_collections()
    xbmc.executebuiltin("Container.Refresh")


def rename_collection(collection_id, name):
    if not collection_id:
        return
    aliases = load_collection_aliases()
    current = aliases.get(str(collection_id), name or "")
    try:
        new_name = xbmcgui.Dialog().input("Rename collection", defaultt=current or name or "")
    except TypeError:
        new_name = xbmcgui.Dialog().input("Rename collection", current or name or "")
    if new_name is None:
        return
    new_name = str(new_name).strip()
    if not new_name:
        return
    aliases[str(collection_id)] = new_name
    save_collection_aliases(aliases)
    xbmc.executebuiltin("Container.Refresh")


def reset_collection_name(collection_id):
    if not collection_id:
        return
    aliases = load_collection_aliases()
    if str(collection_id) in aliases:
        del aliases[str(collection_id)]
        save_collection_aliases(aliases)
    xbmc.executebuiltin("Container.Refresh")


def refresh_all(missing=False):
    cols, _ = sync_collections()
    appids = all_appids(cols)
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT appid FROM games")
    existing = set(str(r[0]) for r in cur.fetchall())
    con.close()

    if missing:
        appids = [a for a in appids if a not in existing]

    if not appids:
        xbmcgui.Dialog().notification(ADDON_NAME, "Nothing to scrape.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    prog = xbmcgui.DialogProgressBG()
    bg_create(prog)

    rows, ok, partial, fail = [], 0, 0, 0
    total = len(appids)

    for idx, appid in enumerate(appids, 1):
        pct = int(idx * 100 / max(total, 1))
        title = fallback_title(appid)

        try:
            g = scrape(appid, cols)
            save_game(g)
            title = g.get("name") or title
            if g.get("_partial_reason"):
                partial += 1
                rows.append({"appid": appid, "status": "partial_title_only", "name": title, "error": g.get("_partial_reason")})
            else:
                ok += 1
                rows.append({"appid": appid, "status": "ok", "name": title, "error": ""})
        except Exception as exc:
            fail += 1
            rows.append({"appid": appid, "status": "failed", "name": title, "error": str(exc)})

        bg_update(prog, pct, "{}/{} METADATA - {}".format(idx, total, title)[:95])
        xbmc.sleep(150)

    bg_update(prog, 100, "{}/{} METADATA - DONE".format(total, total))
    xbmc.sleep(300)
    bg_close(prog)

    report = os.path.join(DIAG, "metadata_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["appid","status","name","error"])
        w.writeheader()
        w.writerows(rows)

    summary = {
        "mode": "missing" if missing else "all",
        "total": total,
        "ok": ok,
        "partial_title_only": partial,
        "failed": fail,
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    open(os.path.join(PROFILE, "last_run_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        "Metadata done: OK {} / Partial {} / Failed {}".format(ok, partial, fail),
        xbmcgui.NOTIFICATION_INFO if fail == 0 else xbmcgui.NOTIFICATION_WARNING,
        6000
    )


def game_rows_for_rebuild():
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT appid, name FROM games ORDER BY name")
    rows = cur.fetchall()
    con.close()
    if rows:
        hidden = hidden_appids()
        return [(str(r["appid"]), str(r["name"] or r["appid"])) for r in rows if str(r["appid"]) not in hidden]

    # Fallback: if DB is empty, use collection AppIDs.
    cols, _ = sync_collections()
    return [(str(appid), fallback_title(appid)) for appid in all_appids(cols)]


def steam_screenshot_slots(appid):
    # Screenshot-only fanart rebuild. Do not use background_raw/background here.
    js = http_json("https://store.steampowered.com/api/appdetails?appids={}&cc=US&l=english&v=1".format(appid), 30)
    app = js.get(str(appid), {})
    if not app.get("success"):
        raise RuntimeError("appdetails_success_false")
    data = app.get("data") or {}
    shots = unique_urls([x.get("path_full") for x in (data.get("screenshots") or []) if x.get("path_full")])
    slots = shots[:5]
    while len(slots) < 5:
        slots.append(NA)
    return {
        "fanart_url": nz(slots[0]),
        "fanart1_url": nz(slots[1]),
        "fanart2_url": nz(slots[2]),
        "fanart3_url": nz(slots[3]),
        "fanart4_url": nz(slots[4]),
    }


def update_fanart_slots(appid, slots):
    con = connect()
    cur = con.cursor()
    cur.execute("""UPDATE games SET
        fanart_url=?, fanart1_url=?, fanart2_url=?, fanart3_url=?, fanart4_url=?
        WHERE appid=?""", (
        slots.get("fanart_url") or NA,
        slots.get("fanart1_url") or NA,
        slots.get("fanart2_url") or NA,
        slots.get("fanart3_url") or NA,
        slots.get("fanart4_url") or NA,
        str(appid)
    ))
    con.commit()
    con.close()


def rebuild_screenshot_fanarts_only():
    rows_to_process = game_rows_for_rebuild()
    if not rows_to_process:
        xbmcgui.Dialog().notification(ADDON_NAME, "No games to rebuild.", xbmcgui.NOTIFICATION_WARNING, 4000)
        return

    prog = xbmcgui.DialogProgressBG()
    bg_create(prog)

    report_rows = []
    ok, no_data, fail = 0, 0, 0
    total = len(rows_to_process)

    for idx, (appid, title) in enumerate(rows_to_process, 1):
        pct = int(idx * 100 / max(total, 1))
        try:
            slots = steam_screenshot_slots(appid)
            update_fanart_slots(appid, slots)
            count_urls = sum(1 for v in slots.values() if v and v != NA)
            if count_urls > 0:
                ok += 1
                status = "ok"
                err = ""
            else:
                no_data += 1
                status = "no_screenshots"
                err = ""
            report_rows.append({
                "appid": appid,
                "name": title,
                "status": status,
                "fanart_count": count_urls,
                "fanart_url": slots.get("fanart_url", NA),
                "fanart1_url": slots.get("fanart1_url", NA),
                "fanart2_url": slots.get("fanart2_url", NA),
                "fanart3_url": slots.get("fanart3_url", NA),
                "fanart4_url": slots.get("fanart4_url", NA),
                "error": err,
            })
        except Exception as exc:
            # Important: if the provider errors, do not overwrite old fanart URLs.
            fail += 1
            report_rows.append({
                "appid": appid,
                "name": title,
                "status": "error_not_overwritten",
                "fanart_count": "",
                "fanart_url": "",
                "fanart1_url": "",
                "fanart2_url": "",
                "fanart3_url": "",
                "fanart4_url": "",
                "error": str(exc),
            })

        bg_update(prog, pct, "{}/{} SCREENSHOTS - {}".format(idx, total, title)[:95])
        xbmc.sleep(120)

    bg_update(prog, 100, "{}/{} SCREENSHOTS - DONE".format(total, total))
    xbmc.sleep(300)
    bg_close(prog)

    report = os.path.join(DIAG, "screenshot_fanart_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["appid","name","status","fanart_count","fanart_url","fanart1_url","fanart2_url","fanart3_url","fanart4_url","error"])
        w.writeheader()
        w.writerows(report_rows)

    summary = {
        "mode": "rebuild_screenshot_fanarts_only",
        "total": total,
        "ok": ok,
        "no_screenshots": no_data,
        "failed_not_overwritten": fail,
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    open(os.path.join(PROFILE, "last_screenshot_fanart_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        "Screenshot fanarts: OK {} / N/A {} / Error {}".format(ok, no_data, fail),
        xbmcgui.NOTIFICATION_INFO if fail == 0 else xbmcgui.NOTIFICATION_WARNING,
        6000
    )
    xbmc.executebuiltin("Container.Refresh")


def art_is_missing_value(value):
    if value is None:
        return True
    value = str(value).strip()
    return value == "" or value.upper() == "N/A"


def missing_artwork_rows():
    con = connect()
    cur = con.cursor()
    cur.execute("""SELECT appid, name, poster_url, thumb_url, clearlogo_url,
                          fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url
                   FROM games
                   ORDER BY name""")
    rows = cur.fetchall()
    con.close()

    hidden = hidden_appids()
    out = []
    for r in rows:
        if str(r["appid"]) in hidden:
            continue
        wanted = []
        for col in ["poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"]:
            if art_is_missing_value(r[col]):
                wanted.append(col)
        if wanted:
            out.append((str(r["appid"]), str(r["name"] or r["appid"]), wanted))
    if out:
        return out

    # Fallback when DB is empty.
    cols, _ = sync_collections()
    return [(str(appid), fallback_title(appid), ["poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"]) for appid in all_appids(cols)]


def auto_art_for_rebuild(appid):
    js = http_json("https://store.steampowered.com/api/appdetails?appids={}&cc=US&l=english&v=1".format(appid), 30)
    app = js.get(str(appid), {})
    if not app.get("success"):
        raise RuntimeError("appdetails_success_false")
    data = app.get("data") or {}
    return auto_art(appid, data, steam_store_html(appid))


def update_missing_artwork_columns(appid, art, wanted_columns):
    # Missing-only update: existing filled URLs are preserved.
    valid_columns = ["poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"]
    wanted = [c for c in wanted_columns if c in valid_columns]
    if not wanted:
        return 0, {}

    con = connect()
    cur = con.cursor()
    cur.execute("""SELECT poster_url, thumb_url, clearlogo_url,
                          fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url
                   FROM games WHERE appid=?""", (str(appid),))
    row = cur.fetchone()
    if not row:
        con.close()
        save_game(partial_game(appid, "missing_artwork_rebuild_created"))
        con = connect()
        cur = con.cursor()
        cur.execute("""SELECT poster_url, thumb_url, clearlogo_url,
                              fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url
                       FROM games WHERE appid=?""", (str(appid),))
        row = cur.fetchone()

    updates = {}
    for col in wanted:
        current = row[col] if row else ""
        new_value = art.get(col, NA)
        # Only fill missing current values. Do not overwrite filled manual/old URLs.
        if art_is_missing_value(current):
            updates[col] = new_value if new_value else NA

    if not updates:
        con.close()
        return 0, {}

    set_clause = ", ".join(["{}=?".format(col) for col in updates.keys()])
    values = list(updates.values()) + [str(appid)]
    cur.execute("UPDATE games SET {} WHERE appid=?".format(set_clause), values)
    con.commit()
    con.close()
    return len(updates), updates


def rebuild_missing_artwork_urls():
    rows_to_process = missing_artwork_rows()
    if not rows_to_process:
        xbmcgui.Dialog().notification(ADDON_NAME, "No missing artwork URLs.", xbmcgui.NOTIFICATION_INFO, 4000)
        return

    prog = xbmcgui.DialogProgressBG()
    bg_create(prog)

    report_rows = []
    ok, skipped, no_data, fail = 0, 0, 0, 0
    total = len(rows_to_process)

    for idx, (appid, title, wanted) in enumerate(rows_to_process, 1):
        pct = int(idx * 100 / max(total, 1))
        try:
            art = auto_art_for_rebuild(appid)
            changed_count, updates = update_missing_artwork_columns(appid, art, wanted)

            if changed_count > 0:
                ok += 1
                status = "updated_missing_only"
            else:
                # Provider returned only N/A or everything became filled before this item ran.
                if all(art_is_missing_value(art.get(c)) for c in wanted):
                    no_data += 1
                    status = "no_artwork_data"
                else:
                    skipped += 1
                    status = "already_filled_skipped"

            report_rows.append({
                "appid": appid,
                "name": title,
                "status": status,
                "wanted_columns": ",".join(wanted),
                "updated_columns": ",".join(updates.keys()),
                "poster_url": updates.get("poster_url", ""),
                "thumb_url": updates.get("thumb_url", ""),
                "clearlogo_url": updates.get("clearlogo_url", ""),
                "fanart_url": updates.get("fanart_url", ""),
                "fanart1_url": updates.get("fanart1_url", ""),
                "fanart2_url": updates.get("fanart2_url", ""),
                "fanart3_url": updates.get("fanart3_url", ""),
                "fanart4_url": updates.get("fanart4_url", ""),
                "error": "",
            })
        except Exception as exc:
            # Provider error: do not overwrite any existing artwork.
            fail += 1
            report_rows.append({
                "appid": appid,
                "name": title,
                "status": "error_not_overwritten",
                "wanted_columns": ",".join(wanted),
                "updated_columns": "",
                "poster_url": "",
                "thumb_url": "",
                "clearlogo_url": "",
                "fanart_url": "",
                "fanart1_url": "",
                "fanart2_url": "",
                "fanart3_url": "",
                "fanart4_url": "",
                "error": str(exc),
            })

        bg_update(prog, pct, "{}/{} ARTWORK URLS - {}".format(idx, total, title)[:95])
        xbmc.sleep(120)

    bg_update(prog, 100, "{}/{} ARTWORK URLS - DONE".format(total, total))
    xbmc.sleep(300)
    bg_close(prog)

    report = os.path.join(DIAG, "missing_artwork_rebuild_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        fields = ["appid","name","status","wanted_columns","updated_columns","poster_url","thumb_url","clearlogo_url","fanart_url","fanart1_url","fanart2_url","fanart3_url","fanart4_url","error"]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(report_rows)

    summary = {
        "mode": "rebuild_missing_artwork_urls",
        "total": total,
        "updated": ok,
        "already_filled_skipped": skipped,
        "no_artwork_data": no_data,
        "failed_not_overwritten": fail,
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    open(os.path.join(PROFILE, "last_missing_artwork_rebuild_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        "Artwork URLs: Updated {} / Error {}".format(ok, fail),
        xbmcgui.NOTIFICATION_INFO if fail == 0 else xbmcgui.NOTIFICATION_WARNING,
        6000
    )
    xbmc.executebuiltin("Container.Refresh")


def json_rpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    data = json.loads(raw or "{}")
    if data.get("error"):
        raise RuntimeError("{}: {}".format(method, data.get("error")))
    return data.get("result")


def kodi_setting(setting_id, default=None):
    try:
        result = json_rpc("Settings.GetSettingValue", {"setting": setting_id})
        if isinstance(result, dict) and "value" in result:
            return result.get("value")
    except Exception as exc:
        log("Cannot read Kodi setting {}: {}".format(setting_id, exc), xbmc.LOGWARNING)
    return default


def kodi_webserver_config():
    enabled = bool(kodi_setting("services.webserver", False))
    port = kodi_setting("services.webserverport", 8080)
    username = kodi_setting("services.webserverusername", "") or ""
    password = kodi_setting("services.webserverpassword", "") or ""
    ssl = bool(kodi_setting("services.webserverssl", False))
    try:
        port = int(port)
    except Exception:
        port = 8080
    return {
        "enabled": enabled,
        "port": port,
        "username": str(username),
        "password": str(password),
        "scheme": "https" if ssl else "http",
    }


def kodi_quote_image(image_string):
    # Match LAC / Kodi behavior:
    # remote URL -> image://<encoded remote URL>/
    # then the whole image:// string is URL-encoded for the /image endpoint.
    if not image_string:
        return ""
    image_string = str(image_string)
    if image_string.startswith("image://"):
        return image_string
    result = "image://{}/".format(urllib.parse.quote(image_string, safe="()!"))
    return re.sub(r"%[0-9A-F]{2}", lambda mo: mo.group().lower(), result)


def kodi_unquote_image(image_string):
    # Textures.GetTextures usually returns image://https%3a%2f%2f.../
    # Convert it back to the original remote URL before comparing with our DB URLs.
    if not image_string:
        return ""
    image_string = str(image_string)
    if image_string.startswith("image://") and not image_string.startswith(("image://video", "image://music")):
        inner = image_string[8:]
        if inner.endswith("/"):
            inner = inner[:-1]
        return urllib.parse.unquote(inner)
    return image_string


def kodi_image_url(original_url, config):
    # LAC-compatible Kodi image cache URL:
    # raw remote URL -> image://quoted-raw-url/ -> quote the whole image:// string for /image/.
    # Calling /image/<encoded raw https URL> returns 404 on Kodi.
    image_url = kodi_quote_image(original_url)
    encoded = urllib.parse.quote(image_url, safe="")
    return "{}://127.0.0.1:{}/image/{}".format(config["scheme"], config["port"], encoded)


def get_cached_texture_urls():
    # Read Kodi texture cache via JSON-RPC and normalize back to original artwork URLs.
    # This matches LAC's pykodi.unquoteimage(texture['url']) behavior.
    cached = set()
    start = 0
    page = 1000

    while True:
        params = {
            "properties": ["url"],
            "limits": {"start": start, "end": start + page}
        }
        try:
            result = json_rpc("Textures.GetTextures", params) or {}
        except Exception as exc:
            if start == 0:
                try:
                    result = json_rpc("Textures.GetTextures", {"properties": ["url"]}) or {}
                except Exception as exc2:
                    raise RuntimeError("Textures.GetTextures failed: {}".format(exc2))
            else:
                raise RuntimeError("Textures.GetTextures failed: {}".format(exc))

        textures = result.get("textures") or []
        for item in textures:
            url = item.get("url")
            if not url:
                continue
            url = str(url)
            cached.add(url)
            cached.add(kodi_unquote_image(url))

        limits = result.get("limits") or {}
        total = int(limits.get("total") or len(textures) or 0)
        end = int(limits.get("end") or (start + len(textures)))
        if not textures or end >= total:
            break
        start = end

    return cached

def cacheable_artwork_rows():
    rows = artwork_urls()
    out, seen = [], set()
    hidden = hidden_appids()
    for item in rows:
        if str(item.get("appid") or "") in hidden:
            continue
        url = art_or_empty(item.get("url"))
        if not url:
            continue
        if url in seen:
            continue
        seen.add(url)
        out.append({
            "appid": item.get("appid") or "",
            "name": item.get("name") or item.get("appid") or "",
            "art_type": item.get("art_type") or "",
            "url": url,
        })
    return out


def download_via_kodi_image_endpoint(item, config):
    url = item["url"]
    endpoint = kodi_image_url(url, config)
    item["endpoint"] = endpoint
    req = urllib.request.Request(endpoint, headers={"User-Agent": UA})

    if config.get("username") or config.get("password"):
        import base64
        token = base64.b64encode(("{}:{}".format(config.get("username", ""), config.get("password", ""))).encode("utf-8")).decode("ascii")
        req.add_header("Authorization", "Basic {}".format(token))

    with urllib.request.urlopen(req, timeout=60) as response:
        total_read = 0
        while True:
            chunk = response.read(1024 * 64)
            if not chunk:
                break
            total_read += len(chunk)
        status = getattr(response, "status", 200)
        if int(status) < 200 or int(status) >= 400:
            raise RuntimeError("HTTP {}".format(status))
        return total_read


def cache_artwork_lac_style():
    all_urls = cacheable_artwork_rows()
    total_urls = len(all_urls)
    if not all_urls:
        xbmcgui.Dialog().notification(ADDON_NAME, "No artwork URLs in DB. Run metadata first.", xbmcgui.NOTIFICATION_WARNING, 5000)
        return

    config = kodi_webserver_config()
    if not config.get("enabled"):
        xbmcgui.Dialog().ok(
            ADDON_NAME,
            "Kodi web server is disabled.\n\nEnable:\nSettings > Services > Control > Allow remote control via HTTP\n\nThis cache method uses Kodi /image endpoint like LAC."
        )
        return

    prog = xbmcgui.DialogProgressBG()
    bg_create(prog)
    bg_update(prog, 0, "CHECKING TEXTURE CACHE")

    try:
        cached_urls = get_cached_texture_urls()
    except Exception as exc:
        bg_close(prog)
        xbmcgui.Dialog().ok(ADDON_NAME, "Cannot read Kodi texture cache:\n{}".format(exc))
        return

    pending = [item for item in all_urls if item["url"] not in cached_urls]
    already_cached = total_urls - len(pending)

    report_rows = []
    for item in all_urls:
        if item["url"] in cached_urls:
            report_rows.append({**item, "endpoint": "", "status": "already_cached", "bytes": "", "error": ""})

    if not pending:
        bg_update(prog, 100, "0/0 CACHING - DONE")
        xbmc.sleep(300)
        bg_close(prog)

        report = os.path.join(DIAG, "artwork_cache_report.csv")
        with open(report, "w", encoding="utf-8-sig", newline="") as f:
            w = csv.DictWriter(f, fieldnames=["appid","name","art_type","url","endpoint","status","bytes","error"])
            w.writeheader()
            w.writerows(report_rows)

        summary = {
            "mode": "lac_style_kodi_image_endpoint",
            "total_urls": total_urls,
            "already_cached": already_cached,
            "pending": 0,
            "cached": 0,
            "failed": 0,
            "report": report,
            "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
        }
        open(os.path.join(PROFILE, "last_artwork_cache_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))
        xbmcgui.Dialog().notification(ADDON_NAME, "Artwork cache: {} already cached".format(already_cached), xbmcgui.NOTIFICATION_INFO, 6000)
        return

    cached_count, failed_count, done = 0, 0, 0
    pending_total = len(pending)

    def worker(item):
        bytes_read = download_via_kodi_image_endpoint(item, config)
        return item, bytes_read

    max_workers = min(4, max(1, pending_total))
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        future_map = {executor.submit(worker, item): item for item in pending}
        for future in concurrent.futures.as_completed(future_map):
            item = future_map[future]
            done += 1
            pct = int(done * 100 / max(pending_total, 1))
            try:
                item2, bytes_read = future.result()
                cached_count += 1
                report_rows.append({**item2, "status": "cached", "bytes": bytes_read, "error": ""})
            except Exception as exc:
                failed_count += 1
                report_rows.append({**item, "status": "failed", "bytes": "", "error": str(exc)})

            title = item.get("name") or item.get("appid") or ""
            bg_update(prog, pct, "{}/{} CACHING - {}".format(done, pending_total, title)[:95])

    bg_update(prog, 100, "{}/{} CACHING - DONE".format(pending_total, pending_total))
    xbmc.sleep(300)
    bg_close(prog)

    report = os.path.join(DIAG, "artwork_cache_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["appid","name","art_type","url","endpoint","status","bytes","error"])
        w.writeheader()
        w.writerows(report_rows)

    summary = {
        "mode": "lac_style_kodi_image_endpoint",
        "total_urls": total_urls,
        "already_cached": already_cached,
        "pending": pending_total,
        "cached": cached_count,
        "failed": failed_count,
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    open(os.path.join(PROFILE, "last_artwork_cache_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        "Artwork cache: Cached {} / Failed {} / Skipped {}".format(cached_count, failed_count, already_cached),
        xbmcgui.NOTIFICATION_INFO if failed_count == 0 else xbmcgui.NOTIFICATION_WARNING,
        7000
    )


def artwork_urls(include_hidden=False):
    con = connect()
    cur = con.cursor()
    cur.execute("""SELECT appid, name, poster_url, thumb_url, clearlogo_url, fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url
                   FROM games ORDER BY name""")
    rows = cur.fetchall()
    con.close()
    hidden = set() if include_hidden else hidden_appids()
    urls, seen = [], set()
    for r in rows:
        if str(r["appid"]) in hidden:
            continue
        pairs = [
            ("poster", r["poster_url"]),
            ("thumb", r["thumb_url"]),
            ("clearlogo", r["clearlogo_url"]),
            ("fanart", r["fanart_url"]),
            ("fanart1", r["fanart1_url"]),
            ("fanart2", r["fanart2_url"]),
            ("fanart3", r["fanart3_url"]),
            ("fanart4", r["fanart4_url"]),
        ]
        for typ, url in pairs:
            url = art_or_empty(url)
            if not url:
                continue
            key = (typ, url)
            if key in seen:
                continue
            seen.add(key)
            urls.append({"appid": r["appid"], "name": r["name"] or r["appid"], "art_type": typ, "url": url})
    return urls


def cache_artwork():
    cache_artwork_lac_style()

def get_current_game(appid):
    if is_hidden_game(appid):
        return partial_game(appid, "hidden_game_skipped")
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT * FROM games WHERE appid=?", (str(appid),))
    row = cur.fetchone()
    con.close()
    return dict(row) if row else partial_game(appid, "not_in_db")


def artwork_candidates(appid, art_type):
    appid = str(appid)
    candidates = []
    data = {}
    store_html_text = ""

    try:
        js = http_json("https://store.steampowered.com/api/appdetails?appids={}&cc=US&l=english&v=1".format(appid), 25)
        app = js.get(appid, {})
        if app.get("success"):
            data = app.get("data") or {}
            store_html_text = steam_store_html(appid)
    except Exception:
        pass

    def add(label, url):
        url = art_or_empty(url)
        if url:
            candidates.append({"label": label, "url": url})

    if art_type == "poster":
        add("Steam • library_600x900", poster(appid))
        for a in sgdb_assets(appid, "grids", limit=20):
            add(a.get("label") or "SteamGridDB grid", a["url"])

    elif art_type == "thumb":
        add("Steam • header", data.get("header_image") or "")
        add("Steam • capsule", data.get("capsule_image") or "")
        add("Steam • capsule 616x353", data.get("capsule_imagev5") or "")

    elif art_type == "clearlogo":
        logo = parse_store_logo(store_html_text, appid)
        add("Steam • logo", logo)
        add("Steam • logo direct", steam_logo_direct(appid))
        for a in sgdb_assets(appid, "logos", limit=20):
            add(a.get("label") or "SteamGridDB logo", a["url"])

    elif art_type == "fanart":
        add("Steam • background_raw", data.get("background_raw") or "")
        for idx, ss in enumerate((data.get("screenshots") or []), 1):
            add("Steam • screenshot {}".format(idx), ss.get("path_full") or "")
        for a in sgdb_assets(appid, "heroes", limit=20):
            add(a.get("label") or "SteamGridDB hero", a["url"])

    # de-duplicate
    out, seen = [], set()
    for c in candidates:
        if c["url"] not in seen:
            seen.add(c["url"])
            out.append(c)
    return out


def choose_candidate(heading, candidates):
    if not candidates:
        xbmcgui.Dialog().notification(ADDON_NAME, "No artwork candidates found.", xbmcgui.NOTIFICATION_WARNING, 4000)
        return ""
    items = []
    for c in candidates:
        li = xbmcgui.ListItem(label=c["label"])
        li.setArt({"thumb": c["url"], "icon": c["url"], "fanart": c["url"]})
        items.append(li)
    try:
        idx = xbmcgui.Dialog().select(heading, items, useDetails=True)
    except Exception:
        idx = xbmcgui.Dialog().select(heading, [c["label"] for c in candidates])
    if idx is None or idx < 0:
        return ""
    return candidates[idx]["url"]


def update_art_url(appid, column, url):
    if column not in ["poster_url","thumb_url","clearlogo_url","fanart_url","fanart1_url","fanart2_url","fanart3_url","fanart4_url"]:
        return
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT appid FROM games WHERE appid=?", (str(appid),))
    if not cur.fetchone():
        save_game(partial_game(appid, "artwork_manual_created"))
        con = connect()
        cur = con.cursor()
    cur.execute("UPDATE games SET {}=? WHERE appid=?".format(column), (url, str(appid)))
    con.commit()
    con.close()


def reset_auto_art(appid):
    try:
        js = http_json("https://store.steampowered.com/api/appdetails?appids={}&cc=US&l=english&v=1".format(appid), 25)
        app = js.get(str(appid), {})
        if not app.get("success"):
            xbmcgui.Dialog().notification(ADDON_NAME, "Store appdetails unavailable.", xbmcgui.NOTIFICATION_WARNING, 4000)
            return
        data = app.get("data") or {}
        art = auto_art(appid, data, steam_store_html(appid))
        con = connect()
        cur = con.cursor()
        for col, val in art.items():
            cur.execute("UPDATE games SET {}=? WHERE appid=?".format(col), (val, str(appid)))
        con.commit()
        con.close()
        xbmc.executebuiltin("Container.Refresh")
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, "Reset artwork failed:\n{}".format(exc))


def select_artwork(appid):
    g = get_current_game(appid)
    title = g.get("name") or str(appid)
    opts = ["Poster", "Fanart", "Thumb", "Clearlogo", "Reset all artwork to auto", "Exit"]
    n = xbmcgui.Dialog().select("Select artwork - {}".format(title), opts)
    if n < 0 or n == 5:
        return
    if n == 4:
        reset_auto_art(appid)
        return

    art_type = ["poster", "fanart", "thumb", "clearlogo"][n]
    column = {
        "poster": "poster_url",
        "thumb": "thumb_url",
        "clearlogo": "clearlogo_url",
    }.get(art_type)

    if art_type == "fanart":
        slots = ["Main fanart", "Fanart 1", "Fanart 2", "Fanart 3", "Fanart 4"]
        si = xbmcgui.Dialog().select("Select fanart slot", slots)
        if si is None or si < 0:
            return
        column = ["fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"][si]

    cand = artwork_candidates(appid, art_type)
    url = choose_candidate("{} - {}".format(opts[n], title), cand)
    if not url:
        return
    update_art_url(appid, column, url)
    xbmcgui.Dialog().notification(ADDON_NAME, "Artwork updated.", xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin("Container.Refresh")


def view_status():
    cols, path = sync_collections()
    appids = all_appids(cols)
    con = connect()
    cur = con.cursor()
    def count(sql):
        cur.execute(sql)
        return cur.fetchone()[0]
    hidden_count = count("SELECT COUNT(*) FROM hidden_games")
    msg = "Collections: {}\nActive Steam AppIDs: {}\nHidden games ignored: {}\nGames in DB: {}\nPoster URLs: {}\nClearlogos: {}\nFanart main: {}\nCompleted: {}\nFinished: {}\nReview scores: {}\nAchievements: {}\n\nDB:\n{}\n\nCloud JSON:\n{}".format(
        len(cols),
        len(appids),
        hidden_count,
        count("SELECT COUNT(*) FROM games"),
        count("SELECT COUNT(*) FROM games WHERE poster_url!='' AND poster_url!='N/A'"),
        count("SELECT COUNT(*) FROM games WHERE clearlogo_url!='' AND clearlogo_url!='N/A'"),
        count("SELECT COUNT(*) FROM games WHERE fanart_url!='' AND fanart_url!='N/A'"),
        count("SELECT COUNT(*) FROM games WHERE completed='1'"),
        count("SELECT COUNT(*) FROM games WHERE finished='1'"),
        count("SELECT COUNT(*) FROM games WHERE steam_review_percent!='' AND steam_review_percent!='N/A'"),
        count("SELECT COUNT(*) FROM games WHERE achievement_total!='' AND achievement_total!='N/A'"),
        DB_PATH,
        path or "not found"
    )
    con.close()
    xbmcgui.Dialog().ok(ADDON_NAME, msg)


def export_diag():
    ensure()

    # Auto-delete older diagnostic ZIPs from addon_data root before creating a new one.
    for old_zip in glob.glob(os.path.join(PROFILE, "steam-library-diagnostics-*.zip")) + glob.glob(os.path.join(PROFILE, "steam-library-diagnostics.zip")):
        try:
            os.remove(old_zip)
        except Exception:
            pass

    zip_path = os.path.join(PROFILE, "steam-library-diagnostics-{}.zip".format(time.strftime("%Y%m%d-%H%M%S")))

    settings_snapshot = {
        "addon_id": ADDON_ID,
        "created_at": time.strftime("%Y-%m-%d %H:%M:%S"),
        "settings": {
            "steam_api_key_set": bool(s("steam_api_key")),
            "steam_id64": s("steam_id64"),
            "steamgriddb_api_key_set": bool(s("steamgriddb_api_key")),
            "cloud_json_path": s("cloud_json_path"),
            "show_all_games": b("show_all_games", True),
            "all_games_exclude_hidden": b("all_games_exclude_hidden", True),
            "fetch_steam_reviews": b("fetch_steam_reviews", True),
            "fetch_achievements": b("fetch_achievements", True),
            "cache_days": i("cache_days", 30),
            "launch_method": i("launch_method", 0),
        },
        "collection_aliases": load_collection_aliases(),
        "collection_visibility": load_collection_visibility(),
        "hidden_games_count": 0,
    }
    try:
        con = connect()
        settings_snapshot["hidden_games_count"] = con.execute("SELECT COUNT(*) FROM hidden_games").fetchone()[0]
        con.close()
    except Exception:
        pass

    tmp_settings = os.path.join(PROFILE, "settings_snapshot.json")
    with open(tmp_settings, "w", encoding="utf-8") as f:
        f.write(json.dumps(settings_snapshot, indent=2, ensure_ascii=False))

    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        # Root: only DB + settings snapshot.
        if os.path.exists(DB_PATH):
            z.write(DB_PATH, "steam_library.db")
        z.write(tmp_settings, "settings.json")

        # Everything else goes into diagnostics/.
        for p in glob.glob(os.path.join(DIAG, "*")):
            z.write(p, "diagnostics/" + os.path.basename(p))
        for f in ["last_run_summary.json", "last_artwork_cache_summary.json", "last_screenshot_fanart_summary.json", "last_missing_artwork_rebuild_summary.json", "last_prune_artwork_cache_summary.json", "owned_games_cache.json"]:
            p = os.path.join(PROFILE, f)
            if os.path.exists(p):
                z.write(p, "diagnostics/" + f)
        if os.path.exists(ALIASES_PATH):
            z.write(ALIASES_PATH, "diagnostics/collection_aliases.json")
        if os.path.exists(VISIBILITY_PATH):
            z.write(VISIBILITY_PATH, "diagnostics/collection_visibility.json")

    try:
        os.remove(tmp_settings)
    except Exception:
        pass

    xbmcgui.Dialog().notification(ADDON_NAME, "Diagnostics exported", xbmcgui.NOTIFICATION_INFO, 4000)


def edit_setting_value(setting_id, label, hidden=False):
    current = ADDON.getSetting(setting_id)
    try:
        value = xbmcgui.Dialog().input(
            label,
            defaultt=current,
            type=xbmcgui.INPUT_ALPHANUM,
            option=xbmcgui.ALPHANUM_HIDE_INPUT if hidden and hasattr(xbmcgui, "ALPHANUM_HIDE_INPUT") else 0
        )
    except TypeError:
        value = xbmcgui.Dialog().input(label, current)
    if value is None:
        return
    ADDON.setSetting(setting_id, str(value).strip())
    xbmcgui.Dialog().notification(ADDON_NAME, "{} saved".format(label), xbmcgui.NOTIFICATION_INFO, 2000)


def steam_account_settings_menu():
    opts = [
        "Steam Web API Key",
        "SteamID64",
        "SteamGridDB API Key",
        "Steam cloud-storage-namespace-1.json path",
        "Open Kodi settings",
        "Exit"
    ]
    while True:
        n = xbmcgui.Dialog().select("Steam Account Settings", opts)
        if n is None or n < 0 or n == 5:
            return
        if n == 0:
            edit_setting_value("steam_api_key", "Steam Web API Key", True)
        elif n == 1:
            edit_setting_value("steam_id64", "SteamID64", False)
        elif n == 2:
            edit_setting_value("steamgriddb_api_key", "SteamGridDB API Key", True)
        elif n == 3:
            edit_setting_value("cloud_json_path", "Steam cloud-storage-namespace-1.json path", False)
        elif n == 4:
            ADDON.openSettings()


def latest_textures_db_path():
    db_dir = xbmcvfs.translatePath("special://database/")
    files = glob.glob(os.path.join(db_dir, "Textures*.db"))
    if not files:
        return ""
    return max(files, key=lambda p: os.path.getmtime(p))


def thumbnail_file_path(cachedurl):
    if not cachedurl:
        return ""
    base = xbmcvfs.translatePath("special://thumbnails/")
    return os.path.join(base, str(cachedurl).replace("/", os.sep))


def collect_known_steam_artwork_urls():
    # Use DB URLs including hidden games, plus prior cache/rebuild reports.
    # This allows pruning even after some rows were hidden or after a prior failed cache run.
    urls = set()

    try:
        for item in artwork_urls(include_hidden=True):
            url = art_or_empty(item.get("url"))
            if url:
                urls.add(url)
    except Exception as exc:
        log("Collect prune URLs from DB failed: {}".format(exc), xbmc.LOGWARNING)

    report_files = [
        os.path.join(DIAG, "artwork_cache_report.csv"),
        os.path.join(DIAG, "missing_artwork_rebuild_report.csv"),
        os.path.join(DIAG, "screenshot_fanart_report.csv"),
    ]
    artwork_fields = ["url", "poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url", "fanart3_url", "fanart4_url"]

    for report in report_files:
        if not os.path.exists(report):
            continue
        try:
            with open(report, "r", encoding="utf-8-sig", newline="") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    for field in artwork_fields:
                        url = art_or_empty(row.get(field))
                        if url:
                            urls.add(url)
        except Exception as exc:
            log("Collect prune URLs from {} failed: {}".format(report, exc), xbmc.LOGWARNING)

    return urls


def sql_quote_ident(name):
    return '"' + str(name).replace('"', '""') + '"'


def table_columns(cur, table):
    return [str(c[1]) for c in cur.execute("PRAGMA table_info({})".format(sql_quote_ident(table))).fetchall()]


def choose_texture_id_column(cols):
    # Kodi texture DB schema is not identical across versions.
    # Some use idtexture/idTexture, some builds only expose id/rowid.
    lower = {c.lower(): c for c in cols}
    for key in ["idtexture", "id_texture", "textureid", "id"]:
        if key in lower:
            return lower[key]
    return ""


def delete_texture_rows_and_files(texture_db, target_urls):
    if not texture_db or not os.path.exists(texture_db):
        raise RuntimeError("Textures DB not found")

    con = sqlite3.connect(texture_db, timeout=30)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=10000")
    cur = con.cursor()

    texture_cols = table_columns(cur, "texture")
    if "url" not in texture_cols or "cachedurl" not in texture_cols:
        con.close()
        raise RuntimeError("Unsupported Textures DB schema: texture table has {}".format(", ".join(texture_cols)))

    id_col = choose_texture_id_column(texture_cols)

    if id_col:
        cur.execute("SELECT rowid AS __rowid, {} AS __id, url, cachedurl FROM texture".format(sql_quote_ident(id_col)))
    else:
        # Fallback for schemas without idtexture: rowid is enough to delete from texture itself.
        cur.execute("SELECT rowid AS __rowid, rowid AS __id, url, cachedurl FROM texture")
    rows = cur.fetchall()

    matches = []
    target = set(str(x) for x in target_urls if x)
    for r in rows:
        url = str(r["url"] or "")
        raw = kodi_unquote_image(url)
        if url in target or raw in target:
            matches.append({
                "texture_id": int(r["__id"]),
                "rowid": int(r["__rowid"]),
                "id_column": id_col or "rowid",
                "url": url,
                "raw_url": raw,
                "cachedurl": str(r["cachedurl"] or ""),
            })

    file_deleted, file_missing = 0, 0
    report_rows = []
    for m in matches:
        thumb = thumbnail_file_path(m["cachedurl"])
        deleted = False
        missing = False
        try:
            if thumb and xbmcvfs.exists(thumb):
                deleted = bool(xbmcvfs.delete(thumb))
            else:
                missing = True
        except Exception as exc:
            log("Delete thumbnail failed {}: {}".format(thumb, exc), xbmc.LOGWARNING)

        if deleted:
            file_deleted += 1
        elif missing:
            file_missing += 1

        report_rows.append({
            "texture_id": m["texture_id"],
            "rowid": m["rowid"],
            "id_column": m["id_column"],
            "url": m["url"],
            "raw_url": m["raw_url"],
            "cachedurl": m["cachedurl"],
            "thumbnail": thumb,
            "file_deleted": "1" if deleted else "0",
            "file_missing": "1" if missing else "0",
        })

    if matches:
        # Delete dependent rows only when those tables contain a matching texture-id column.
        cur.execute("SELECT name FROM sqlite_master WHERE type='table'")
        tables = [str(r[0]) for r in cur.fetchall()]
        candidate_cols = []
        if id_col:
            candidate_cols.extend([id_col, "idtexture", "idTexture", "id_texture", "textureid", "texture_id"])
        candidate_cols.append("idtexture")
        candidate_cols = list(dict.fromkeys(candidate_cols))

        ids = [m["texture_id"] for m in matches]
        for tbl in tables:
            if tbl == "texture":
                continue
            try:
                cols = table_columns(cur, tbl)
                for dep_col in candidate_cols:
                    if dep_col in cols:
                        cur.executemany(
                            'DELETE FROM {} WHERE {}=?'.format(sql_quote_ident(tbl), sql_quote_ident(dep_col)),
                            [(i,) for i in ids]
                        )
                        break
            except Exception as exc:
                log("Skip dependent texture table {}: {}".format(tbl, exc), xbmc.LOGWARNING)

        # Delete from main texture table. Use rowid to work across all Kodi texture schemas.
        cur.executemany("DELETE FROM texture WHERE rowid=?", [(m["rowid"],) for m in matches])
        con.commit()

    con.close()

    report = os.path.join(DIAG, "prune_artwork_cache_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        fields = ["texture_id", "rowid", "id_column", "url", "raw_url", "cachedurl", "thumbnail", "file_deleted", "file_missing"]
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(report_rows)

    summary = {
        "mode": "prune_steam_artwork_cache",
        "texture_db": texture_db,
        "texture_id_column": id_col or "rowid",
        "known_urls": len(target_urls),
        "matched_textures": len(matches),
        "thumbnail_files_deleted": file_deleted,
        "thumbnail_files_missing": file_missing,
        "texture_rows_deleted": len(matches),
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    open(os.path.join(PROFILE, "last_prune_artwork_cache_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))
    return summary

def clean_steam_artwork_cache():
    target_urls = collect_known_steam_artwork_urls()
    if not target_urls:
        xbmcgui.Dialog().notification(ADDON_NAME, "No Steam artwork URLs found to prune.", xbmcgui.NOTIFICATION_WARNING, 5000)
        return

    if not xbmcgui.Dialog().yesno(
        ADDON_NAME,
        "Delete Steam Library cached artwork from Kodi texture cache?\n\nThis removes matching Texture DB rows and thumbnail files only.\nMovie/TV artwork is not targeted."
    ):
        return

    texture_db = latest_textures_db_path()
    try:
        summary = delete_texture_rows_and_files(texture_db, target_urls)
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            "Pruned textures: {} / files {}".format(summary["texture_rows_deleted"], summary["thumbnail_files_deleted"]),
            xbmcgui.NOTIFICATION_INFO,
            6000
        )
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, "Prune artwork cache failed:\n{}".format(exc))


def reset_steam_library_database():
    if not xbmcgui.Dialog().yesno(
        ADDON_NAME,
        "Reset Steam Library database?\n\nThis deletes metadata/artwork rows and collection cache.\nHidden games will be rebuilt only from Steam's Hidden collection."
    ):
        return

    try:
        if os.path.exists(DB_PATH):
            os.remove(DB_PATH)
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, "Cannot delete DB:\n{}".format(exc))
        return

    # Recreate schema, then rebuild collection cache + hidden_games from Steam cloud data.
    connect().close()
    try:
        sync_collections()
    except Exception as exc:
        log("Collection sync after reset failed: {}".format(exc), xbmc.LOGWARNING)

    # Clear stale run summaries/reports, keep diagnostic ZIP policy handled by export.
    for p in glob.glob(os.path.join(DIAG, "*.csv")) + glob.glob(os.path.join(PROFILE, "last_*_summary.json")):
        try:
            os.remove(p)
        except Exception:
            pass

    xbmcgui.Dialog().notification(ADDON_NAME, "Steam Library database reset", xbmcgui.NOTIFICATION_INFO, 5000)
    xbmc.executebuiltin("Container.Refresh")



def run_tools():
    opts = ["Refresh all metadata", "Scrape missing metadata", "Cache artwork URLs", "Clean Steam artwork cache", "Reset Steam Library database", "Steam Account Settings", "View status", "Export diagnostics ZIP", "Exit"]
    n = xbmcgui.Dialog().select("Steam Library - Tools", opts)
    if n is None or n < 0 or n == 8:
        return
    try:
        if n == 0:
            refresh_all(False)
        elif n == 1:
            refresh_all(True)
        elif n == 2:
            cache_artwork()
        elif n == 3:
            clean_steam_artwork_cache()
        elif n == 4:
            reset_steam_library_database()
        elif n == 5:
            steam_account_settings_menu()
        elif n == 6:
            view_status()
        elif n == 7:
            export_diag()
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, "Tools error:\n{}".format(exc))


def run():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = params.get("mode", "root")
    if mode == "root":
        root()
    elif mode == "list":
        list_games(params)
    elif mode == "play":
        launch(params.get("appid"))
    elif mode == "refresh":
        refresh_one(params.get("appid"))
    elif mode == "store":
        open_store(params.get("appid"))
    elif mode == "select_artwork":
        select_artwork(params.get("appid"))
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "choose_collections":
        choose_visible_collections()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "show_all_collections":
        show_all_collections()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "hide_collection":
        hide_collection(params.get("name"), params.get("collection_id"))
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "reset_collection_visibility":
        reset_collection_visibility()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "rename_collection":
        rename_collection(params.get("collection_id"), params.get("name"))
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "reset_collection_name":
        reset_collection_name(params.get("collection_id"))
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "rebuild_screenshot_fanarts":
        rebuild_screenshot_fanarts_only()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "run_tools":
        run_tools()
        xbmcplugin.endOfDirectory(HANDLE)
    else:
        xbmcplugin.endOfDirectory(HANDLE)


if __name__ == "__main__":
    run()

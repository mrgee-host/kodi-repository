Steam Library 0.4.03 - Native Flipped radio with explicit AF3 focus pill

Fix
- Keeps Flipped as a native Kodi radiobutton.
- Adds a 184 x 52 AF3 accent pill behind the radio only while Control.HasFocus(1200).
- Checked/unchecked state remains owned by the native radiobutton icon.
- Focus state is now visually distinct from checked state:
  * Check/radio icon = Flipped ON or OFF.
  * Orange pill = remote focus is currently on Flipped.
- Makes the radiobutton's own background transparent to prevent duplicate focus layers.

Unchanged
- Flipped remains above the fanart list.
- Seven fanart candidates still fit with 87 px pitch.
- Candidate radio size, thumbnail size, scrollbar, preview geometry,
  live mirror preview, and physical flipped-file apply behavior are unchanged.

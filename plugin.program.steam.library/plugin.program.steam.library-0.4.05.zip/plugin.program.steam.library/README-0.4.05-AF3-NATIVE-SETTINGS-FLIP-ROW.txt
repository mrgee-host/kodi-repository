Steam Library 0.4.05 - AF3 native settings Flipped row

Root cause fixed
================
0.4.04 overrode Arctic Fuse 3 defaults with colors/maincolor.png and custom circle icons.
That is not how AF3 v3.2.14 styles addon-setting radiobuttons, so Kodi could focus
the control without rendering the expected orange pill.

New implementation
==================
- Uses AF3 Settings_Button with control=radiobutton and dialog=true.
- Uses AF3 Texture_Button internally: common/menu.png + ColorHighlight.
- Uses AF3 check-on.png / check-off.png and ColorSelected/dialog colors.
- Keeps a compact 36 px radio gutter so the label fits the narrow artwork rail.
- Uses the native 80 px settings-row height.
- Candidate rows use 84 px pitch, so all seven candidates remain visible.
- Python intercepts Up on candidate 1 and explicitly focuses control 1200.
- Toggle state remains Window.Property(artwork.flip_enabled).
- Live preview and physical mirrored fanart Apply behavior are unchanged.

Focus flow
==========
First candidate + Up -> Flipped
Flipped + Down/Left -> candidate list
Flipped + Right -> Close
OK on Flipped -> toggle state and keep focus on Flipped

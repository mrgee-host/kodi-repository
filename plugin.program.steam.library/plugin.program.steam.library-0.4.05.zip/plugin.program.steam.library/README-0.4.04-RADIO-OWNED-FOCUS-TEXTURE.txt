Steam Library 0.4.04 - Radio-owned Flipped focus texture

- Keeps Flipped (id 1200) and the candidate list as separate controls in one rail group.
- Removes the external image controlled by Control.HasFocus(1200).
- Assigns the AF3 accent pill directly to the radiobutton's texturefocus.
- Checked state remains owned by the native radio textures.
- No list geometry, preview geometry, thumbnail size, radio size, paging, or flip/apply logic changed.

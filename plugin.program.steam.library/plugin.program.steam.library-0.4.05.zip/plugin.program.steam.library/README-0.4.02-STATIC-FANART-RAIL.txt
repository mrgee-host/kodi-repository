Steam Library 0.4.02 - Static fanart rail and safe heading

Fixes
- Moves the header label 40 px inside the safe area so the first character is not clipped.
- Removes both conditional -60 px list/scrollbar animations.
- Uses DialogSteamArtworkPicker.xml only for fanart.
- Uses DialogSteamArtworkPickerPlain.xml for poster, thumb, clearlogo, and other artwork.
- Fanart layout is permanent: Flipped at y=0, list and scrollbar at y=64.
- Non-fanart layout is permanent: list and scrollbar at y=0.
- Fanart keeps 7 candidates with 87 px row pitch.
- Non-fanart keeps the 94 px compact row pitch.
- Candidate radio size, thumbnail size, preview geometry, live mirror preview,
  and physical flipped-file apply behavior are unchanged.

Focus
- Fanart: first list item Up -> Flipped; Flipped Down -> list; Flipped Right -> Close.
- List Right -> Scrollbar; Scrollbar Left -> list; Scrollbar Right -> Close.
- Non-fanart: list and scrollbar use the original focus flow without a hidden Flipped control.

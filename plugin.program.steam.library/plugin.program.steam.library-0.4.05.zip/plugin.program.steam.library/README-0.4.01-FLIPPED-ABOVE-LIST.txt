Steam Library 0.4.01 - Flipped above candidate list

Changes
=======
- Removed the cramped Flipped radiobutton from the header.
- Placed the native Kodi/AF3 radiobutton directly above the candidate list.
- Full label and checked/unchecked marker are now readable.
- Tightened candidate row pitch from 94 px to 87 px so seven candidates remain visible.
- Candidate radio and thumbnail sizes are unchanged.
- Scrollbar follows the compacted list.
- Non-fanart artwork pickers slide the list and scrollbar back to the original top position.
- Focus flow:
    first list item UP -> Flipped
    Flipped DOWN -> list
    Flipped RIGHT -> close
    list RIGHT -> scrollbar
    scrollbar RIGHT -> close
    close LEFT -> Flipped (fanart) or scrollbar (other artwork)
- Live preview mirror and applied physical flipped fanart file remain unchanged.

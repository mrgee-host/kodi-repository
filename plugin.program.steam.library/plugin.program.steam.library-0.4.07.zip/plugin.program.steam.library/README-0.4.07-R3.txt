Steam Library 0.4.07
- Legacy query order and URL encoding are normalized internally without failing the current directory request.
- Notification maximum remains 58 characters.

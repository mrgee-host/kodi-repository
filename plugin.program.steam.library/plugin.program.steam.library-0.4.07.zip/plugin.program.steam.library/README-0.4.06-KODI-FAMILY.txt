Steam Library 0.4.06
- All background progress uses COUNTER TITLE - ACTION, uppercase, maximum 58 characters.
- Diagnostics export uses a toast, validates the replacement ZIP first, and keeps only the newest root ZIP.
- Generated state/reports/logs/exports are migrated under runtime/.
- Short reports use normal dialogs; long reports are scrollable.
- Common footer: View Status, Export diagnostics ZIP, Settings, Exit.

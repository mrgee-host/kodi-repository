v0.3.65 - LRS 1.5.28 DisplaySlot coordination

Base: v0.3.64 native indicator visibility.

Changes:
- Steam Library no longer injects direct AF3 lower Info_Meta game rows for Steam review, Metacritic, or achievements.
- AF3 Steam patch removes old direct Steam game meta rows and writes marker:
  STEAM-LIBRARY-AF3-DIRECT-GAME-META-REMOVED-LRS-DISPLAYSLOT
- LRS includes and LibraryRatings.* DisplaySlot / EndsAt properties are left untouched.
- Steam Library still publishes game ListItem properties for LRS:
  platform, lrs_game, lrs_item_type, library_ratings_type, DBTYPE/dbtype, MediaType/mediatype,
  steam_rating_display, metacritic_score, achievement_display, steam_review_desc,
  age_rating_display, tagline_display, steam_appid, achievement_unlocked, achievement_total.
- Removed obsolete AF3 meta row style setting because LRS now owns the lower rating row.

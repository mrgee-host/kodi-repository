Steam Library 0.3.67

Bridge-only update for LRS 1.5.30.
- keeps direct lower Info_Meta game row removed.
- supplies RatingSlot1/2/3 Source/Icon/IconFile/IconPath/Label/Value.
- Steam lower slot label is percentage, not review text.
- Very Positive remains only for top meta line.

Steam Library for Kodi v0.2.0

New:
- Steam review percentage + label from appreviews endpoint.
- Achievement count from Steam Web API when API key + SteamID64 are set.
- Achievement status: COMPLETED / IN PROGRESS.
- Review and achievement values added to ListItem properties and plot.
- Background progress while loading large collections.
- Root stays clean: only All Games + visible real Steam client collections.

Still no AKL:
- no akl.db
- no AKL rendered views
- no custom skin XML
- native Kodi ListItems

Steam Library 0.3.75

- games naming columns are now only: name, sortname.
- Redundant sortname values equal to name are stored as blank.
- Steam Hidden collection rows are physically moved from games to hidden_games.
- Manually hidden rows are physically moved to manual_hidden_games.
- Normal startup/library sync preserves existing name and sortname.
- Refresh Name & Sortname overwrites both fields from current SteamEdit/appinfo data.
- Add Missing Sortname fills only blank sortname values and only when the source differs from name.
- Tools menu reduced to the requested 15 actions.

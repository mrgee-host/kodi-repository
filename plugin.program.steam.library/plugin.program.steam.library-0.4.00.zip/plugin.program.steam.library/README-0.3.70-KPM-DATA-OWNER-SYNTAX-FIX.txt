Steam Library 0.3.70

- Fixes the duplicated `elif n == 3` in Tools so addon.py compiles/runs again.
- Keeps AF3 XML patching moved to Kodi Patch Manager.
- Steam Library remains the game database/scraper/data provider.

Steam Library 0.4.00 - Native AF3 Flipped Radiobutton

Changes
- Replaced the custom group/button imitation with a real Kodi radiobutton control (id 1200).
- Compact header position is unchanged: immediately before the close button.
- Focus uses the AF3 main accent pill.
- OFF uses the AF3 empty circle icon.
- ON uses the AF3 circle-check icon.
- No ON/OFF text is displayed.
- Existing live preview flip and physical flipped-file apply pipeline are unchanged.
- Focus flow remains List <-> Scrollbar <-> Flipped <-> Close.

Compatibility
- Designed against Arctic Fuse 3 v3.2.14 assets and Kodi radiobutton control semantics.

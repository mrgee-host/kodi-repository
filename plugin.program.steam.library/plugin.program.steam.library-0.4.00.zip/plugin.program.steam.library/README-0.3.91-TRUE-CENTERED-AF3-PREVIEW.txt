Steam Library 0.3.91
====================

Artwork picker correction
-------------------------
0.3.90 still looked unchanged because its preview control itself was only
1060 px wide and left-aligned after the rail. The 16:9 image filled that
small control, leaving all unused AF3 dialog width on the right.

0.3.91 keeps the safe rail geometry but changes the preview CONTROL to span
the entire remaining AF3 body area:

- Rail width: 150 px
- Gap after rail: 15 px
- Right preview control: left 165, width 1315
- Preview image control: 1315 x 628, aspectratio keep, align center
- Visible 16:9 image at max height: about 1116 x 628
- Equal unused space inside the right area: about 99.5 px each side
- Single source label: centered under preview
- URL: removed

No AF3 backing, blur, colour, texture, highlight, scrollbar or animation
settings are overridden.

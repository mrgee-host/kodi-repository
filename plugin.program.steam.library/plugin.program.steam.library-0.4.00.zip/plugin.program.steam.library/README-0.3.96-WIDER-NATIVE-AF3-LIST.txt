Steam Library 0.3.96
- selected/list item width increased by 53 px to match the Photoshop mockup
- list grows 45 px left and 8 px right
- right edge still ends exactly at the scrollbar gutter
- native AF3 radio indicator size is unchanged
- item height remains 97 px, preserving seven rows per page
- preview, header label and scrollbar positions are unchanged from 0.3.95

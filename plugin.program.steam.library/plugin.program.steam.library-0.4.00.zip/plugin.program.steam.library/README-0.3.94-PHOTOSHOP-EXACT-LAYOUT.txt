Steam Library 0.3.94
Exact Photoshop mockup mapping from a 1919x1079 Kodi screenshot:
- left rail: +60 px X
- preview image: +30 px X, same 1138x640 rendered size
- candidate label: +422 px X / -716 px Y, moved into header right
- bottom candidate label removed
- separate scrollbar gutter and 7-item paging retained

Steam Library 0.3.71
- Opens root and game folders from local SQLite only; no network or collection rebuild on navigation.
- Startup service synchronizes GetOwnedGames, collections, playtime_forever, added and removed games.
- Removed/refunded games become inactive immediately and disappear from Steam Library and MediaHub.
- Clean Game Library physically deletes inactive metadata and writes a CSV report.
- New games retain two-line AF3 notifications: heading Steam Library, compact one-line progress.
- Playtime is stored only as playtime_forever minutes and exposed as Steam-style Play Time text.

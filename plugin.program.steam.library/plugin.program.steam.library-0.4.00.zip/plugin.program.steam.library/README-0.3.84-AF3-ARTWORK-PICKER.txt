Steam Library 0.3.84 - AF3 artwork picker polish
=================================================

- Large artwork picker now follows Arctic Fuse 3 dialog geometry:
  rounded dialog/panel textures, AF3 dialog colors, fonts, spacing and thin scrollbar.
- Focus rows use a rounded pill instead of a square rectangle.
- Candidate URLs are split once in Python and displayed as exactly two static labels.
  No textbox scrolling and no marquee.
- SteamGridDB hero candidates use compact labels: SGDB WIDTHxHEIGHT.
- Existing Sort title ownership, reports and standard-picker fallback remain unchanged.

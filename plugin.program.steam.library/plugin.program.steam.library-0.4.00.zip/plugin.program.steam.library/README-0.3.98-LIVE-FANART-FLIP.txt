Steam Library 0.3.98 - Live fanart flip toggle

- Adds a compact Flip OFF/ON toggle below the current candidate source label.
- Toggle is visible only when selecting fanart.
- Focus flow: List <-> Scrollbar <-> Flip <-> Close.
- Preview flips instantly in XML without writing a file.
- Selecting/applying while Flip is ON creates a real horizontally mirrored image.
- The mirrored file is stored under addon_data cache/transformed/fanart_flip.
- The game artwork column points to the mirrored file, so Home, widgets and screensavers use it.
- Original remote/local artwork is never overwritten.
- Requires script.module.pil 1.1.7, already used by the Arctic Fuse texture toolchain.

Steam Library v0.3.77

Database admission rules:
- app_type must resolve to game.
- membership must be active.
- non-game entries are excluded from all game metadata tables and collection cache.
- no-longer-owned entries are removed immediately during sync.
- existing app_type=game rows survive a temporary local appinfo read failure.

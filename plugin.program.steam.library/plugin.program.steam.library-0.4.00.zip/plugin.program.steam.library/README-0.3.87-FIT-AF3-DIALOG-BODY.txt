Steam Library 0.3.87
====================

- Moves the artwork preview left by narrowing the thumbnail-only rail.
- Reduces candidate row height from 128 to 96.
- Fits preview + selected label + two URL lines inside AF3 DialogFullMenu body.
- Preview geometry: 860 x 484, preserving 16:9 without forced stretching.
- Keeps native AF3 dialog backing, colours, transparency, blur, textures, rounding and focus navigation.
- Keeps radio + thumbnail only on the left rail.

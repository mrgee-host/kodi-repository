# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon

ADDON_ID = "plugin.program.steam.library"


def run_service():
    addon = xbmcaddon.Addon(ADDON_ID)
    monitor = xbmc.Monitor()
    try:
        def setting_bool(key, default=False):
            value = addon.getSetting(key)
            return default if value == "" else str(value).lower() == "true"

        def setting_int(key, default=0):
            try:
                return int(addon.getSetting(key))
            except Exception:
                return default

        if setting_bool("auto_sync_library_on_startup", True):
            delay = max(5, setting_int("auto_scan_startup_delay", 25))
            if not monitor.waitForAbort(delay):
                xbmc.executebuiltin(
                    "RunPlugin(plugin://{}/?mode=background_sync)".format(
                        ADDON_ID
                    )
                )
    finally:
        # Explicitly release the Python/SWIG wrappers when the startup service
        # invocation ends.
        del monitor
        del addon


if __name__ == "__main__":
    run_service()

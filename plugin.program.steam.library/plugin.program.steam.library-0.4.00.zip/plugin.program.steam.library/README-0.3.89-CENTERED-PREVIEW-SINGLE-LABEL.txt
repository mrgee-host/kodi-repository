Steam Library 0.3.89
====================

- Removed URL text from the custom AF3 artwork picker.
- Enlarged and centered the preview in the available area between the thumbnail rail and the right edge of the dialog.
- Kept the rail thumbnail-only.
- Normalized fanart labels to:
  Steam • Screenshot 1
  Steam • Background Raw
  SGDB 1920x1080
- Preserved native AF3 dialog backing, blur, transparency, colours, textures, focus styling, animations and scrollbar navigation.

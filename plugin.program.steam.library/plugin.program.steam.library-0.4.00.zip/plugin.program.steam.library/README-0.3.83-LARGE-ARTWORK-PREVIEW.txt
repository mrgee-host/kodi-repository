Steam Library 0.3.83
====================

- Replaces the compact artwork candidate selector with a two-pane picker.
- Candidate list remains on the left.
- The focused artwork is shown immediately in a large preview panel on the right.
- Up/down changes the preview; Enter selects; Back cancels.
- Falls back to Kodi's standard select dialog if the custom XML cannot load.
- Retains UNSORTED Kodi view state and plugin-owned Sort title ordering.

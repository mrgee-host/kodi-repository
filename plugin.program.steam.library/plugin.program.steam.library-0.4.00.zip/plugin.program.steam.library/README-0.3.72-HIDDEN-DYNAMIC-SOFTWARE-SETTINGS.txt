Steam Library 0.3.72

Valid settings; Steam Hidden global exclusion; optional Hidden Games folder; visible All Games count; dynamic Software reconstruction; Uncategorized after dynamic/hidden; compact playtime.

Steam Library 0.3.88
====================

- Enlarges the fanart preview to 1020x574 inside the available AF3 dialog body.
- Moves the preview left by narrowing the candidate rail.
- Reduces list focus-pill height and width without intentionally shrinking thumbnails.
- Keeps selected candidate label and two-line URL inside the dialog.
- Preserves native AF3 backing, colours, transparency, blur, rounding and focus navigation.

Steam Library 0.3.79
====================

Normalizes root/list plugin URLs to one canonical path:
plugin://plugin.program.steam.library/?mode=list&collection=__all__

This prevents Kodi ViewModes6.db from treating query-order and missing-slash
variants as separate folders with separate sort settings.

Steam Library 0.3.95
- header candidate label lowered by 10 px
- preview lowered by 17 px
- left rail restored to native Arctic Fuse 3 List_Dialog styling
- native Part_Scrollbar placed in its own dedicated gutter
- focus route: List <-> Scrollbar <-> Close
- exact seven-item paging retained with 97 px item height
- custom hard-coded focus/radio PNG assets removed

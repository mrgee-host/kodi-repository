Steam Library 0.3.73

- steam_name stores the original API title.
- display_name stores the local SteamEdit/appinfo title and remains the visible Kodi name.
- name mirrors display_name for compatibility with MediaHub and older tools.
- sortname is used first for Sort title, then display_name, then steam_name.
- No automatic cleanup of A A / The The or other user-authored SortAs values.
- Default sort mapping fixed: 0 Steam order, 1 Name, 2 Sort title.
- Kodi Select sort method now exposes Sort title.
- hidden_games remains a simple flag table and gains only a name column.
- manual_hidden_games stores metadata_json with a full game-row snapshot.
- Hidden Games folder reads cached metadata without exposing hidden games elsewhere.

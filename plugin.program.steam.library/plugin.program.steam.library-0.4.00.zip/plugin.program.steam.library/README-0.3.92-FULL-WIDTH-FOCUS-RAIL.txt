Steam Library 0.3.92
- artwork picker rail switched to a custom compact thumbnail list
- focused item pill now spans the full rail width
- thumbnail size adjusted to fit the tighter rail cleanly
- right preview enlarged safely
- URL remains removed; single source label retained

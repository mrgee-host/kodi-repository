Steam Library 0.3.86
====================

Artwork picker layout refinement:
- Left rail now contains only AF3 radio indicators and artwork thumbnails.
- Candidate labels no longer marquee or consume horizontal space in the rail.
- Large preview is expanded and remains borderless on native AF3 dialog backing.
- Full candidate label and URL remain under the preview.
- URL remains exactly two static lines without scrolling.
- AF3 colours, blur, transparency, textures, rounding and scrollbar navigation are unchanged.
- Standard picker fallback still uses the original candidate labels.

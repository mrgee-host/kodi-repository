Steam Library 0.3.90
====================

- Fixes the 0.3.89 preview/list overlap.
- The left rail now has explicit item_w and itemlayout_w values.
- Rail: 150 px. Preview starts at x=165. Gap: 15 px.
- Preview: 1060 x 596. Right edge remains x=1225, the proven safe AF3 body edge from 0.3.88.
- Artwork URL remains removed.
- One source label remains below preview.

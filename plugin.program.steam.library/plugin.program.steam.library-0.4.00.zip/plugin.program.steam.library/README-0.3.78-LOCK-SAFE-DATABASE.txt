Steam Library 0.3.78
====================

- Removed all runtime database migration and cleanup from connect().
- The addon now expects the supplied clean Name/Sortname + physical hidden tables schema.
- Opening All Games, collections, widgets, and status pages is read-only at connection time.
- connect() only opens SQLite, applies busy_timeout=30000, and validates table structure.
- Game-only/member-only cleanup runs only during library sync or Clean Game Library.
- Fixes sqlite3.OperationalError: database is locked caused by DELETE migration during list opens.

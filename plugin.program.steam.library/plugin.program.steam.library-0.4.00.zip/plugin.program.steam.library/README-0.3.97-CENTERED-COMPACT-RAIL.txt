Steam Library 0.3.97
- moves the widened artwork list 19 px right to center it between the visual rail bounds
- changes row pitch from 97 px to 94 px so the last item fits fully
- radio size unchanged
- thumbnail size unchanged
- scrollbar, preview, and header unchanged

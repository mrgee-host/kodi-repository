Steam Library 0.3.99 - Compact Flipped header toggle

Changes from 0.3.98:
- Removed the broken Flip ON / Flip OFF text.
- Added a compact AF3-style "Flipped" pill immediately before the close button.
- Checked state is represented by the AF3 circle-check icon.
- Focused or checked state uses the active AF3 accent pill.
- Candidate source is displayed after the title in parentheses and updates live.
- Long headings are clipped before the toggle, so Flipped and X remain intact.
- Navigation remains List <-> Scrollbar <-> Flipped <-> X.
- Live XML mirror preview and physical flipped-file apply behavior are unchanged.

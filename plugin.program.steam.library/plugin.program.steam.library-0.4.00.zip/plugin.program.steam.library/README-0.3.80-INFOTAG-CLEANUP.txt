Steam Library 0.3.80
=========================

Kodi 22 API migration:
- Replaces every ListItem.setInfo("video", ...) call with InfoTagVideo.
- Uses InfoTagVideo.setResumePoint if resume data is supplied.
- Creates plugin ListItems with offscreen=True.
- Removes the module-scope xbmcaddon.Addon wrapper.
- Moves the startup service Addon and Monitor wrappers into run_service()
  and explicitly releases them when the invocation ends.

Preserved:
- SteamEdit display name and sort title.
- Canonical listing paths from 0.3.79.
- KPM properties and game identity.
- Poster/fanart/clearlogo selection.
- Playtime, achievements, Steam/Metacritic data.
- Current database schema and synchronization behavior.

The source contains no ListItem.addStreamInfo calls and no legacy
resumetime/totaltime property writes. If those warnings remain after this
update, they originate from another concurrently invoked add-on.

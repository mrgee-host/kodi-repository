Steam Library 0.3.81
====================

- Game listings now expose only Kodi SORT_METHOD_UNSORTED.
- Steam Library remains the sole owner of ordering through the existing
  library_game_sort setting: Steam order, Name, or Sort title.
- Kodi can no longer reapply/persist LABEL (sortMethod=1) over the plugin order
  when a listing is reopened or Kodi restarts.
- Existing ViewModes rows do not need manual deletion. Once the folder is
  opened and the view state is saved, the only available method is NONE/0.

Steam Library 0.3.69 clean game data-owner

Role: Steam/game scanning, game DB, Top250 and metadata. Display/layout settings remain here; KPM reads them. No LRS RatingSlot bridge contract.

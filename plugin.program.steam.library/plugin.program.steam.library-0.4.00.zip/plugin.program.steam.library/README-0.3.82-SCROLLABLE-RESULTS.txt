Steam Library 0.3.82

- Keeps plugin-owned Sort title ordering with Kodi UNSORTED.
- Long status and diagnostics results now open in DialogTextViewer and can be scrolled.

Steam Library 0.3.85 - Native AF3 artwork picker
=================================================

- Replaces manually painted black dialog/panel layers with Arctic Fuse 3 native includes:
  Part_Dim_Overlay, Part_Dialog_Backing, Animation_BounceIn_Dialog,
  Part_HeadText, Part_ItemPage, Part_CloseButton, List_Dialog and Part_Scrollbar.
- Therefore follows AF3 active dialog theme, image/blur/crop mode, transparency,
  palette, focus colour, textures, spacing, rounding and animation.
- Removes all preview bordertexture, black backing and thumbnail frame controls.
- Fixes focus trap: scrollbar Left returns to candidate list; Right moves to close.
  Python also provides a defensive focus fallback.
- URL remains two fixed lines without marquee.
- SteamGridDB hero labels remain compact: SGDB <resolution>.

Steam Library 0.3.76

Tools menu:
1. Scan for New Games
2. Refresh All Metadata
3. Scrape Missing Metadata
4. Update Steam250 ranks
5. Clean Game Library
6. Unhide manually hidden games
7. Steam Account Settings
8. View status
9. Export diagnostics ZIP

Changes:
- Removed Refresh Steam Library from Tools; startup service already syncs the library.
- Refresh All Metadata now also overwrites Name and Sortname from SteamEdit/appinfo.
- Scrape Missing Metadata now also fills only missing Sortname values.
- Removed Cache Artwork URLs; pending visible artwork is cached automatically after Scan for New Games and both metadata actions.
- Removed Clean Steam Artwork Cache.
- Removed Reset Steam Library Database.
- Folder context menu now says Scan for New Games instead of Refresh library.

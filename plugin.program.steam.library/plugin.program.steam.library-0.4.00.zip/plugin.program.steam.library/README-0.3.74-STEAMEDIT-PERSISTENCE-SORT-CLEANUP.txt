Steam Library 0.3.74

- Adds durable steamedit_name and steamedit_sortname fields.
- A local appinfo title only replaces the stored override when it differs from Steam API title.
- If Steam resets appinfo to the original title, the last confirmed SteamEdit name remains visible.
- Recovers a custom name from the previous steam_names_report.csv when v0.3.73 already overwrote it.
- Collapses only duplicated leading articles in SortAs: A A -> A, An An -> An, The The -> The.
- Does not remove a single article and does not change display names.
- Natural sorting keeps Unicode letters, preventing Chinese/Japanese/Korean titles from jumping ahead because their prefix was deleted.

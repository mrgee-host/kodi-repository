Steam Library v0.3.0

Single-addon version.

Kodi behavior:
- This is a plugin source addon, so Add-on Information shows Open, not Run.
- Root library remains clean:
  All Games + visible real Steam client collections only.
- Tools are hidden from the library root and accessed from context menu:
  Steam Library Tools

Tools menu:
- Refresh all metadata
- Scrape missing metadata
- Cache artwork URLs
- View status
- Export diagnostics ZIP
- Settings
- Exit

Remote-only artwork:
- addon stores Steam artwork URLs in steam_library.db
- ListItems use remote art URLs
- Kodi handles Textures DB and Thumbnails
- addon does not download artwork locally


v0.3.1:
- Refresh all metadata uses DialogProgressBG, not foreground modal progress.
- Scrape missing metadata uses DialogProgressBG.
- Cache artwork URLs uses background progress and avoids WindowDialog focus steal.
- Finish result uses notification; full details are written to reports/status JSON.


v0.3.2:
- Fixed DialogProgressBG heading/message mapping.
- Progress heading stays addon name: Steam Library.
- Progress body line now contains: 120/470 METADATA - Title - 25%.
- Metadata progress updates after each scrape so title is available instead of only AppID.

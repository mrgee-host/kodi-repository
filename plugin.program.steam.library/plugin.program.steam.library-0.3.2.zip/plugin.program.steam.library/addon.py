# -*- coding: utf-8 -*-
from __future__ import annotations

import csv
import glob
import json
import os
import sqlite3
import subprocess
import sys
import time
import traceback
import urllib.parse
import urllib.request
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
UA = "Kodi-Steam-Library/0.3.2"


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_NAME, msg), level)


def bg_create(prog):
    try:
        prog.create(ADDON_NAME, "")
    except Exception:
        try:
            prog.create(ADDON_NAME)
        except Exception:
            pass


def bg_update(prog, pct, line):
    if not prog:
        return
    # Prefer the 3-arg DialogProgressBG API:
    # heading stays "Steam Library", message is the progress line.
    try:
        prog.update(int(pct), ADDON_NAME, str(line))
        return
    except Exception:
        pass

    # Fallback for Kodi builds exposing only update(percent, message).
    try:
        prog.update(int(pct), str(line))
    except Exception:
        pass


def bg_close(prog):
    if not prog:
        return
    try:
        prog.close()
    except Exception:
        pass


def tr(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return xbmc.translatePath(path)


PROFILE = tr("special://profile/addon_data/{}/".format(ADDON_ID))
DB_PATH = os.path.join(PROFILE, "steam_library.db")
DIAG = os.path.join(PROFILE, "diagnostics")


def ensure():
    os.makedirs(PROFILE, exist_ok=True)
    os.makedirs(DIAG, exist_ok=True)


def s(key, default=""):
    v = ADDON.getSetting(key)
    return v if v else default


def b(key, default=False):
    v = ADDON.getSetting(key)
    return default if v == "" else str(v).lower() == "true"


def i(key, default=0):
    try:
        return int(ADDON.getSetting(key))
    except Exception:
        return default


def split_names(value):
    if not value:
        return set()
    out = set()
    for chunk in str(value).replace(";", ",").split(","):
        x = chunk.strip().lower()
        if x:
            out.add(x)
    return out


def collection_visible(name):
    n = (name or "").strip().lower()
    mode = i("collection_filter_mode", 0)
    hidden = split_names(s("hidden_collection_names", ""))
    visible = split_names(s("visible_collection_names", ""))
    if mode == 1:
        return n in visible if visible else True
    return n not in hidden


def filter_collections(cols):
    return [c for c in cols if collection_visible(c.get("name"))]


def url_for(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def http_json(url, timeout=25):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace"))


def connect():
    ensure()
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS games (
        appid TEXT PRIMARY KEY, name TEXT, sort_name TEXT, release_date TEXT, year TEXT,
        developers TEXT, publishers TEXT, genres TEXT, categories TEXT,
        short_description TEXT, detailed_description TEXT, metacritic_score TEXT,
        review_total TEXT, header_image TEXT, poster_url TEXT, fanart_url TEXT,
        screenshot_urls TEXT, last_scraped INTEGER)""")
    con.execute("""CREATE TABLE IF NOT EXISTS collections (
        collection_id TEXT, name TEXT, appid TEXT, PRIMARY KEY(collection_id, appid))""")
    cur = con.cursor()
    cur.execute("PRAGMA table_info(games)")
    cols = [r[1] for r in cur.fetchall()]
    for col in ["steam_review_percent", "steam_review_desc", "steam_review_total", "achievement_unlocked", "achievement_total", "achievement_status"]:
        if col not in cols:
            cur.execute("ALTER TABLE games ADD COLUMN {} TEXT".format(col))
    con.commit()
    return con


def cloud_json():
    manual = os.path.expandvars((s("cloud_json_path") or "").strip().strip('"'))
    if manual and os.path.exists(manual):
        return manual
    roots = [os.path.expandvars(r"%ProgramFiles(x86)%\Steam\userdata"), os.path.expandvars(r"%ProgramFiles%\Steam\userdata")]
    found = []
    for root in roots:
        if root and "%" not in root and os.path.isdir(root):
            found += glob.glob(os.path.join(root, "*", "config", "cloudstorage", "cloud-storage-namespace-1.json"))
    found = [(os.path.getmtime(p), p) for p in set(found) if os.path.exists(p)]
    found.sort(reverse=True)
    return found[0][1] if found else ""


def parse_collections(path):
    if not path or not os.path.exists(path):
        return []
    try:
        raw = json.loads(open(path, "r", encoding="utf-8").read())
    except Exception as exc:
        log("Cannot read cloud collections: {}".format(exc), xbmc.LOGWARNING)
        return []
    out = []
    for item in raw:
        if not isinstance(item, list) or len(item) < 2:
            continue
        key, payload = item[0], item[1]
        if not str(key).startswith("user-collections."):
            continue
        try:
            data = json.loads(payload.get("value") or "{}")
        except Exception:
            continue
        name = str(data.get("name") or data.get("id") or key)
        cid = str(data.get("id") or key)
        removed = set(str(x) for x in (data.get("removed") or []))
        appids = [str(x) for x in (data.get("added") or []) if str(x) not in removed]
        if appids:
            out.append({"id": cid, "name": name, "appids": appids})
    return out


def sync_collections():
    con = connect()
    cur = con.cursor()
    path = cloud_json()
    cols = parse_collections(path)
    cur.execute("DELETE FROM collections")
    for c in cols:
        for appid in c["appids"]:
            cur.execute("INSERT OR REPLACE INTO collections(collection_id,name,appid) VALUES(?,?,?)", (c["id"], c["name"], appid))
    con.commit()
    con.close()
    return cols, path


def all_appids(cols):
    seen, appids = set(), []
    for c in cols:
        for a in c["appids"]:
            if a not in seen:
                seen.add(a)
                appids.append(a)
    return appids


def poster(appid):
    return "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{}/library_600x900.jpg".format(appid)


def reviews(appid):
    if not b("fetch_steam_reviews", True):
        return {}
    try:
        js = http_json("https://store.steampowered.com/appreviews/{}?json=1&language=all&purchase_type=all&num_per_page=0".format(appid), 20)
        q = js.get("query_summary") or {}
        pos, neg = int(q.get("total_positive") or 0), int(q.get("total_negative") or 0)
        total = int(q.get("total_reviews") or pos + neg)
        pct = str(int(round(pos * 100.0 / total))) if total else ""
        return {"steam_review_percent": pct, "steam_review_desc": q.get("review_score_desc") or "", "steam_review_total": str(total) if total else ""}
    except Exception as exc:
        log("Reviews failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return {}


def achievements(appid):
    if not b("fetch_achievements", True):
        return {}
    key, sid = s("steam_api_key"), s("steam_id64")
    if not key or not sid:
        return {}
    try:
        url = "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v0001/?appid={}&key={}&steamid={}&l=en".format(urllib.parse.quote(str(appid)), urllib.parse.quote(key), urllib.parse.quote(sid))
        js = http_json(url, 20)
        arr = ((js.get("playerstats") or {}).get("achievements") or [])
        total = len(arr)
        unlocked = sum(1 for a in arr if int(a.get("achieved") or 0) == 1)
        return {"achievement_unlocked": str(unlocked) if total else "", "achievement_total": str(total) if total else "", "achievement_status": "COMPLETED" if total and unlocked == total else ("IN PROGRESS" if total else "")}
    except Exception as exc:
        log("Achievements failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return {}


def scrape(appid):
    js = http_json("https://store.steampowered.com/api/appdetails?appids={}&filters=basic,genres,categories,screenshots,metacritic,recommendations".format(appid), 25)
    app = js.get(str(appid), {})
    if not app.get("success"):
        raise RuntimeError("appdetails success=false")
    d = app.get("data") or {}
    shots = [x.get("path_full") for x in (d.get("screenshots") or []) if x.get("path_full")]
    n = max(i("screenshot_number", 2), 1) - 1
    fanart = shots[n] if len(shots) > n else (shots[0] if shots else "")
    release = ((d.get("release_date") or {}).get("date") or "")
    year = ""
    for t in release.replace(",", " ").split():
        if t.isdigit() and len(t) == 4:
            year = t
            break
    g = {
        "appid": str(appid),
        "name": d.get("name") or "Steam App {}".format(appid),
        "sort_name": d.get("name") or "Steam App {}".format(appid),
        "release_date": release,
        "year": year,
        "developers": " / ".join(d.get("developers") or []),
        "publishers": " / ".join(d.get("publishers") or []),
        "genres": " / ".join([x.get("description", "") for x in (d.get("genres") or []) if x.get("description")]),
        "categories": " / ".join([x.get("description", "") for x in (d.get("categories") or []) if x.get("description")]),
        "short_description": d.get("short_description") or "",
        "detailed_description": d.get("detailed_description") or d.get("about_the_game") or "",
        "metacritic_score": str((d.get("metacritic") or {}).get("score") or ""),
        "review_total": str((d.get("recommendations") or {}).get("total") or ""),
        "header_image": d.get("header_image") or "",
        "poster_url": poster(appid),
        "fanart_url": fanart,
        "screenshot_urls": json.dumps(shots),
        "last_scraped": int(time.time()),
        "steam_review_percent": "",
        "steam_review_desc": "",
        "steam_review_total": "",
        "achievement_unlocked": "",
        "achievement_total": "",
        "achievement_status": "",
    }
    g.update(reviews(appid))
    g.update(achievements(appid))
    return g


def save_game(g):
    con = connect()
    cur = con.cursor()
    cur.execute("""INSERT OR REPLACE INTO games(appid,name,sort_name,release_date,year,developers,publishers,genres,categories,short_description,detailed_description,metacritic_score,review_total,header_image,poster_url,fanart_url,screenshot_urls,last_scraped,steam_review_percent,steam_review_desc,steam_review_total,achievement_unlocked,achievement_total,achievement_status)
    VALUES(:appid,:name,:sort_name,:release_date,:year,:developers,:publishers,:genres,:categories,:short_description,:detailed_description,:metacritic_score,:review_total,:header_image,:poster_url,:fanart_url,:screenshot_urls,:last_scraped,:steam_review_percent,:steam_review_desc,:steam_review_total,:achievement_unlocked,:achievement_total,:achievement_status)""", g)
    con.commit()
    con.close()


def get_game(appid, force=False):
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT * FROM games WHERE appid=?", (str(appid),))
    row = cur.fetchone()
    con.close()
    if row and not force:
        last = row["last_scraped"] or 0
        if int(time.time()) - int(last) < i("cache_days", 30) * 86400:
            return dict(row)
    try:
        g = scrape(appid)
        save_game(g)
        return g
    except Exception as exc:
        log("Scrape failed {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return {
            "appid": str(appid),
            "name": "Steam App {}".format(appid),
            "sort_name": "Steam App {}".format(appid),
            "release_date": "",
            "year": "",
            "developers": "",
            "publishers": "",
            "genres": "",
            "categories": "",
            "short_description": "",
            "detailed_description": "",
            "metacritic_score": "",
            "review_total": "",
            "header_image": "",
            "poster_url": poster(appid),
            "fanart_url": "",
            "screenshot_urls": "[]",
            "last_scraped": 0,
            "steam_review_percent": "",
            "steam_review_desc": "",
            "steam_review_total": "",
            "achievement_unlocked": "",
            "achievement_total": "",
            "achievement_status": "",
        }


def clean_html(text):
    import re
    if not text:
        return ""
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    return text.replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'").strip()


def make_game_item(g):
    appid = g["appid"]
    li = xbmcgui.ListItem(label=g.get("name") or "Steam App {}".format(appid))
    li.setProperty("IsPlayable", "true")
    plot = []
    if g.get("short_description"):
        plot.append(clean_html(g.get("short_description")))
    meta = []
    if g.get("steam_review_percent") or g.get("steam_review_desc"):
        line = "Steam: "
        if g.get("steam_review_percent"):
            line += "{}%".format(g.get("steam_review_percent"))
        if g.get("steam_review_desc"):
            line += " {}".format(g.get("steam_review_desc"))
        if g.get("steam_review_total"):
            line += " ({})".format(g.get("steam_review_total"))
        meta.append(line)
    if g.get("achievement_total"):
        a = "Achievements: {}/{}".format(g.get("achievement_unlocked") or "0", g.get("achievement_total"))
        if g.get("achievement_status"):
            a += " - {}".format(g.get("achievement_status"))
        meta.append(a)
    if g.get("developers"):
        meta.append("Developer: " + g.get("developers"))
    if g.get("publishers"):
        meta.append("Publisher: " + g.get("publishers"))
    if g.get("metacritic_score"):
        meta.append("Metacritic: " + g.get("metacritic_score"))
    if meta:
        plot.append("\n".join(meta))
    try:
        li.setInfo("video", {
            "title": g.get("name") or "",
            "plot": "\n\n".join(plot),
            "genre": g.get("genres") or "",
            "year": int(g["year"]) if str(g.get("year") or "").isdigit() else 0,
            "studio": g.get("developers") or g.get("publishers") or "",
        })
    except Exception:
        pass
    li.setArt({k: v for k, v in {
        "poster": g.get("poster_url") or g.get("header_image") or "",
        "thumb": g.get("header_image") or g.get("poster_url") or "",
        "icon": g.get("header_image") or g.get("poster_url") or "",
        "fanart": g.get("fanart_url") or "",
        "landscape": g.get("fanart_url") or g.get("header_image") or "",
    }.items() if v})
    for k in ["appid","steam_review_percent","steam_review_desc","steam_review_total","achievement_unlocked","achievement_total","achievement_status","release_date"]:
        li.setProperty(k, str(g.get(k) or ""))
    li.setProperty("steam_appid", appid)
    li.setProperty("developer", g.get("developers") or "")
    li.setProperty("publisher", g.get("publishers") or "")
    li.addContextMenuItems([
        ("Refresh metadata", "RunPlugin({})".format(url_for(mode="refresh", appid=appid))),
        ("Open Steam store page", "RunPlugin({})".format(url_for(mode="store", appid=appid))),
        ("Steam Library Tools", "RunPlugin({})".format(url_for(mode="run_tools"))),
        ("Addon settings", "Addon.OpenSettings({})".format(ADDON_ID)),
    ])
    return li


def add_dir(label, mode, **kwargs):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": "DefaultFolder.png"})
    cm = [
        ("Steam Library Tools", "RunPlugin({})".format(url_for(mode="run_tools"))),
        ("Choose visible collections", "RunPlugin({})".format(url_for(mode="choose_collections"))),
        ("Show all collections", "RunPlugin({})".format(url_for(mode="show_all_collections"))),
        ("Addon settings", "Addon.OpenSettings({})".format(ADDON_ID)),
    ]
    cname = kwargs.pop("collection_name_for_context", "")
    if cname:
        cm.insert(0, ("Hide this collection", "RunPlugin({})".format(url_for(mode="hide_collection", name=cname))))
    li.addContextMenuItems(cm)
    params = {"mode": mode}
    params.update(kwargs)
    xbmcplugin.addDirectoryItem(HANDLE, url_for(**params), li, True)


def root():
    cols, path = sync_collections()
    cols = filter_collections(cols)
    if cols:
        if b("show_all_games", True):
            add_dir("All Games ({})".format(len(all_appids(cols))), "list", collection="__all__")
        for c in cols:
            add_dir("{} ({})".format(c["name"], len(c["appids"])), "list", collection_id=c["id"], collection_name_for_context=c["name"])
    else:
        li = xbmcgui.ListItem(label="No visible Steam client collections")
        li.setInfo("video", {"plot": "No Steam collections visible. Check settings.\nCloud JSON: {}".format(path or "not found")})
        li.addContextMenuItems([("Steam Library Tools", "RunPlugin({})".format(url_for(mode="run_tools"))), ("Addon settings", "Addon.OpenSettings({})".format(ADDON_ID))])
        xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="noop"), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def appids_for(params):
    cols, _ = sync_collections()
    cols = filter_collections(cols)
    if params.get("collection") == "__all__":
        return all_appids(cols)
    cid = params.get("collection_id")
    for c in cols:
        if c["id"] == cid:
            return c["appids"]
    return []


def list_games(params):
    appids = appids_for(params)
    xbmcplugin.setContent(HANDLE, "games")
    total = len(appids)
    progress = None
    if total > 30:
        progress = xbmcgui.DialogProgressBG()
        try:
            progress.create(ADDON_NAME, "Loading Steam metadata...")
        except Exception:
            progress = None
    for idx, appid in enumerate(appids, 1):
        if progress and idx % 5 == 0:
            try:
                progress.update(int(idx * 100 / max(total, 1)), "Loading {}/{}".format(idx, total))
            except Exception:
                pass
        g = get_game(appid, False)
        xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="play", appid=appid), make_game_item(g), False, total)
    if progress:
        try:
            progress.close()
        except Exception:
            pass
    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE)


def launch(appid):
    steam_url = "steam://rungameid/{}".format(appid)
    try:
        method = i("launch_method", 0)
        if method == 0 and hasattr(os, "startfile"):
            os.startfile(steam_url)
        elif method == 1:
            subprocess.Popen(["cmd", "/c", "start", "", steam_url], shell=False)
        else:
            xbmc.executebuiltin('System.Exec("{}")'.format(steam_url))
        xbmcgui.Dialog().notification(ADDON_NAME, "Launching Steam app {}".format(appid), xbmcgui.NOTIFICATION_INFO, 2500)
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, "Gagal launch Steam app {}\n{}".format(appid, exc))


def refresh_one(appid):
    g = scrape(appid)
    save_game(g)
    xbmcgui.Dialog().notification(ADDON_NAME, "Metadata refreshed: {}".format(appid), xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")


def open_store(appid):
    try:
        os.startfile("https://store.steampowered.com/app/{}/".format(appid))
    except Exception:
        xbmc.executebuiltin("System.Exec({})".format("https://store.steampowered.com/app/{}/".format(appid)))


def choose_visible_collections():
    cols, path = sync_collections()
    if not cols:
        xbmcgui.Dialog().ok(ADDON_NAME, "No Steam client collections found.\n{}".format(path or "cloud JSON not found"))
        return
    names = [c["name"] for c in cols]
    visible = split_names(s("visible_collection_names", ""))
    hidden = split_names(s("hidden_collection_names", ""))
    mode = i("collection_filter_mode", 0)
    pre = []
    for idx, name in enumerate(names):
        n = name.strip().lower()
        if mode == 1:
            if not visible or n in visible:
                pre.append(idx)
        else:
            if n not in hidden:
                pre.append(idx)
    try:
        selected = xbmcgui.Dialog().multiselect("Visible Steam Collections", names, preselect=pre)
    except TypeError:
        selected = xbmcgui.Dialog().multiselect("Visible Steam Collections", names)
    if selected is None:
        return
    ADDON.setSetting("collection_filter_mode", "1")
    ADDON.setSetting("visible_collection_names", ", ".join([names[i] for i in selected]))
    ADDON.setSetting("hidden_collection_names", "")
    xbmc.executebuiltin("Container.Refresh")


def show_all_collections():
    ADDON.setSetting("collection_filter_mode", "0")
    ADDON.setSetting("visible_collection_names", "")
    ADDON.setSetting("hidden_collection_names", "")
    xbmc.executebuiltin("Container.Refresh")


def hide_collection(name):
    if not name:
        return
    raw = s("hidden_collection_names", "")
    parts = [p.strip() for p in raw.replace(";", ",").split(",") if p.strip()]
    if name not in parts:
        parts.append(name)
    ADDON.setSetting("collection_filter_mode", "0")
    ADDON.setSetting("hidden_collection_names", ", ".join(parts))
    ADDON.setSetting("visible_collection_names", "")
    xbmc.executebuiltin("Container.Refresh")


def refresh_all(missing=False):
    cols, _ = sync_collections()
    appids = all_appids(cols)
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT appid FROM games")
    existing = set(str(r[0]) for r in cur.fetchall())
    con.close()

    if missing:
        appids = [a for a in appids if a not in existing]

    if not appids:
        xbmcgui.Dialog().notification(ADDON_NAME, "Nothing to scrape.", xbmcgui.NOTIFICATION_INFO, 3000)
        return

    prog = xbmcgui.DialogProgressBG()
    bg_create(prog)

    rows, ok, fail = [], 0, 0
    total = len(appids)

    for idx, appid in enumerate(appids, 1):
        pct = int(idx * 100 / max(total, 1))
        title = appid

        try:
            g = scrape(appid)
            save_game(g)
            title = g.get("name") or appid
            ok += 1
            rows.append({"appid": appid, "status": "ok", "name": title, "error": ""})
        except Exception as exc:
            fail += 1
            rows.append({"appid": appid, "status": "failed", "name": "", "error": str(exc)})

        # Update after scrape so the title is known. Heading remains addon name.
        if idx == 1 or idx % 3 == 0 or idx == total:
            bg_update(prog, pct, "{}/{} METADATA - {} - {}%".format(idx, total, title, pct)[:95])

        xbmc.sleep(150)

    bg_update(prog, 100, "{}/{} METADATA - DONE - 100%".format(total, total))
    xbmc.sleep(300)
    bg_close(prog)

    report = os.path.join(DIAG, "metadata_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["appid","status","name","error"])
        w.writeheader()
        w.writerows(rows)

    summary = {
        "mode": "missing" if missing else "all",
        "total": total,
        "ok": ok,
        "failed": fail,
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    open(os.path.join(PROFILE, "last_run_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        "Metadata done: OK {} / Failed {}".format(ok, fail),
        xbmcgui.NOTIFICATION_INFO if fail == 0 else xbmcgui.NOTIFICATION_WARNING,
        6000
    )



def artwork_urls():
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT appid, name, poster_url, fanart_url, header_image FROM games ORDER BY name")
    rows = cur.fetchall()
    con.close()
    urls, seen = [], set()
    for r in rows:
        for typ, url in [("poster", r["poster_url"]), ("fanart", r["fanart_url"]), ("thumb", r["header_image"])]:
            if not url:
                continue
            key = (typ, url)
            if key in seen:
                continue
            seen.add(key)
            urls.append({"appid": r["appid"], "name": r["name"] or r["appid"], "art_type": typ, "url": url})
    return urls


def cache_artwork():
    urls = artwork_urls()
    if not urls:
        xbmcgui.Dialog().notification(ADDON_NAME, "No artwork URLs in DB. Run metadata first.", xbmcgui.NOTIFICATION_WARNING, 5000)
        return

    prog = xbmcgui.DialogProgressBG()
    bg_create(prog)

    img = None
    win = None
    rows, ok, fail = [], 0, 0
    total = len(urls)

    try:
        try:
            current_id = xbmcgui.getCurrentWindowId()
            win = xbmcgui.Window(current_id)
            img = xbmcgui.ControlImage(0, 0, 1, 1, "")
            win.addControl(img)
        except Exception as exc:
            log("Non-modal artwork prewarm control failed: {}".format(exc), xbmc.LOGWARNING)
            win = None
            img = None

        for idx, item in enumerate(urls, 1):
            pct = int(idx * 100 / max(total, 1))

            try:
                if img:
                    img.setImage(item["url"])
                    xbmc.sleep(180)
                    status = "queued_to_kodi_texture_cache"
                else:
                    xbmc.sleep(30)
                    status = "url_recorded_no_render_control"

                ok += 1
                rows.append({**item, "status": status, "error": ""})
            except Exception as exc:
                fail += 1
                rows.append({**item, "status": "failed", "error": str(exc)})

            if idx == 1 or idx % 10 == 0 or idx == total:
                bg_update(prog, pct, "{}/{} ARTWORK - {} - {}%".format(idx, total, item["art_type"], pct)[:95])

    finally:
        try:
            if win and img:
                win.removeControl(img)
        except Exception:
            pass
        bg_update(prog, 100, "{}/{} ARTWORK - DONE - 100%".format(total, total))
        xbmc.sleep(300)
        bg_close(prog)

    report = os.path.join(DIAG, "artwork_cache_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["appid","name","art_type","url","status","error"])
        w.writeheader()
        w.writerows(rows)

    summary = {
        "mode": "remote_only_kodi_texture_cache",
        "total_urls": total,
        "queued": ok,
        "failed": fail,
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S")
    }
    open(os.path.join(PROFILE, "last_artwork_cache_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))

    xbmcgui.Dialog().notification(
        ADDON_NAME,
        "Artwork cache done: {} URLs".format(ok),
        xbmcgui.NOTIFICATION_INFO if fail == 0 else xbmcgui.NOTIFICATION_WARNING,
        6000
    )



def view_status():
    cols, path = sync_collections()
    appids = all_appids(cols)
    con = connect()
    cur = con.cursor()
    def count(sql):
        cur.execute(sql)
        return cur.fetchone()[0]
    msg = "Collections: {}\nSteam AppIDs: {}\nGames in DB: {}\nPoster URLs: {}\nFanart URLs: {}\nReview scores: {}\nAchievements: {}\n\nDB:\n{}\n\nCloud JSON:\n{}".format(
        len(cols), len(appids), count("SELECT COUNT(*) FROM games"), count("SELECT COUNT(*) FROM games WHERE poster_url!=''"), count("SELECT COUNT(*) FROM games WHERE fanart_url!=''"), count("SELECT COUNT(*) FROM games WHERE steam_review_percent!=''"), count("SELECT COUNT(*) FROM games WHERE achievement_total!=''"), DB_PATH, path or "not found")
    con.close()
    xbmcgui.Dialog().ok(ADDON_NAME, msg)


def export_diag():
    ensure()
    zip_path = os.path.join(PROFILE, "steam-library-diagnostics-{}.zip".format(time.strftime("%Y%m%d-%H%M%S")))
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        if os.path.exists(DB_PATH):
            z.write(DB_PATH, "steam_library.db")
        for p in glob.glob(os.path.join(DIAG, "*")):
            z.write(p, "diagnostics/" + os.path.basename(p))
        sfile = os.path.join(PROFILE, "last_run_summary.json")
        if os.path.exists(sfile):
            z.write(sfile, "last_run_summary.json")
    xbmcgui.Dialog().ok(ADDON_NAME, "Diagnostics exported:\n{}".format(zip_path))


def run_tools():
    opts = ["Refresh all metadata", "Scrape missing metadata", "Cache artwork URLs", "View status", "Export diagnostics ZIP", "Settings", "Exit"]
    n = xbmcgui.Dialog().select("Steam Library - Tools", opts)
    if n < 0 or n == 6:
        return
    try:
        if n == 0:
            refresh_all(False)
        elif n == 1:
            refresh_all(True)
        elif n == 2:
            cache_artwork()
        elif n == 3:
            view_status()
        elif n == 4:
            export_diag()
        elif n == 5:
            ADDON.openSettings()
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, "Tools error:\n{}".format(exc))


def run():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = params.get("mode", "root")
    if mode == "root":
        root()
    elif mode == "list":
        list_games(params)
    elif mode == "play":
        launch(params.get("appid"))
    elif mode == "refresh":
        refresh_one(params.get("appid"))
    elif mode == "store":
        open_store(params.get("appid"))
    elif mode == "choose_collections":
        choose_visible_collections()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "show_all_collections":
        show_all_collections()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "hide_collection":
        hide_collection(params.get("name"))
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "run_tools":
        run_tools()
        xbmcplugin.endOfDirectory(HANDLE)
    else:
        xbmcplugin.endOfDirectory(HANDLE)


if __name__ == "__main__":
    run()

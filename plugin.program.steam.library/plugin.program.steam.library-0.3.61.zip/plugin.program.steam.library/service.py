# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon("plugin.program.steam.library")
ADDON_ID = "plugin.program.steam.library"

def setting_bool(key, default=False):
    v = ADDON.getSetting(key)
    return default if v == "" else str(v).lower() == "true"

def setting_int(key, default=0):
    try:
        return int(ADDON.getSetting(key))
    except Exception:
        return default

monitor = xbmc.Monitor()
if setting_bool("auto_scan_new_on_startup", False):
    delay = max(5, setting_int("auto_scan_startup_delay", 25))
    if not monitor.waitForAbort(delay):
        xbmc.executebuiltin("RunPlugin(plugin://{}/?mode=auto_update_new)".format(ADDON_ID))

# -*- coding: utf-8 -*-
from __future__ import annotations

import glob
import json
import os
import sqlite3
import subprocess
import sys
import time
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
HANDLE = int(sys.argv[1])
BASE_URL = sys.argv[0]
USER_AGENT = "Kodi-Steam-Library/0.2.5"


def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{}] {}".format(ADDON_NAME, msg), level)


def tr(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return xbmc.translatePath(path)


PROFILE = tr("special://profile/addon_data/{}/".format(ADDON_ID))
DB_PATH = os.path.join(PROFILE, "steam_library.db")


def setting_bool(key, default=False):
    v = ADDON.getSetting(key)
    if v == "":
        return default
    return str(v).lower() == "true"


def setting_int(key, default=0):
    try:
        return int(ADDON.getSetting(key))
    except Exception:
        return default


def setting_str(key, default=""):
    v = ADDON.getSetting(key)
    return v if v else default


def split_names(value):
    if not value:
        return set()
    parts = []
    for chunk in str(value).replace(";", ",").split(","):
        s = chunk.strip().lower()
        if s:
            parts.append(s)
    return set(parts)


def collection_visible(name):
    n = (name or "").strip().lower()
    mode = setting_int("collection_filter_mode", 0)
    hidden = split_names(setting_str("hidden_collection_names", ""))
    visible = split_names(setting_str("visible_collection_names", ""))

    if mode == 1:
        return n in visible if visible else True

    return n not in hidden


def filter_collections(collections):
    return [c for c in collections if collection_visible(c.get("name"))]


def notify(msg):
    try:
        xbmcgui.Dialog().notification(ADDON_NAME, msg, xbmcgui.NOTIFICATION_INFO, 3000)
    except Exception:
        pass


def choose_visible_collections():
    collections, path = sync_collections()
    if not collections:
        xbmcgui.Dialog().ok(ADDON_NAME, "No Steam client collections found.\n{}".format(path or "cloud JSON not found"))
        return

    names = [c["name"] for c in collections]
    currently_visible = split_names(setting_str("visible_collection_names", ""))
    hidden = split_names(setting_str("hidden_collection_names", ""))
    mode = setting_int("collection_filter_mode", 0)

    preselect = []
    for idx, name in enumerate(names):
        n = name.strip().lower()
        if mode == 1:
            if not currently_visible or n in currently_visible:
                preselect.append(idx)
        else:
            if n not in hidden:
                preselect.append(idx)

    try:
        selected = xbmcgui.Dialog().multiselect("Visible Steam Collections", names, preselect=preselect)
    except TypeError:
        # Some Kodi builds do not accept preselect keyword.
        selected = xbmcgui.Dialog().multiselect("Visible Steam Collections", names)

    if selected is None:
        return

    selected_names = [names[i] for i in selected]
    ADDON.setSetting("collection_filter_mode", "1")
    ADDON.setSetting("visible_collection_names", ", ".join(selected_names))
    ADDON.setSetting("hidden_collection_names", "")

    notify("Visible collections saved")
    xbmc.executebuiltin("Container.Refresh")


def show_all_collections():
    ADDON.setSetting("collection_filter_mode", "0")
    ADDON.setSetting("visible_collection_names", "")
    ADDON.setSetting("hidden_collection_names", "")
    notify("All collections visible")
    xbmc.executebuiltin("Container.Refresh")


def hide_collection_by_name(name):
    if not name:
        return
    hidden = split_names(setting_str("hidden_collection_names", ""))
    hidden.add(name.strip().lower())

    # Preserve original case where possible by appending raw name.
    raw = setting_str("hidden_collection_names", "")
    parts = [p.strip() for p in raw.replace(";", ",").split(",") if p.strip()]
    if name not in parts:
        parts.append(name)

    ADDON.setSetting("collection_filter_mode", "0")
    ADDON.setSetting("hidden_collection_names", ", ".join(parts))
    ADDON.setSetting("visible_collection_names", "")
    notify("Collection hidden: {}".format(name))
    xbmc.executebuiltin("Container.Refresh")


def url_for(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def ensure_profile():
    if not os.path.isdir(PROFILE):
        os.makedirs(PROFILE, exist_ok=True)


def ensure_col(cur, table, col, spec):
    cur.execute("PRAGMA table_info({})".format(table))
    cols = [r[1] for r in cur.fetchall()]
    if col not in cols:
        cur.execute("ALTER TABLE {} ADD COLUMN {} {}".format(table, col, spec))


def db():
    ensure_profile()
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("""
        CREATE TABLE IF NOT EXISTS games (
            appid TEXT PRIMARY KEY,
            name TEXT,
            sort_name TEXT,
            release_date TEXT,
            year TEXT,
            developers TEXT,
            publishers TEXT,
            genres TEXT,
            categories TEXT,
            short_description TEXT,
            detailed_description TEXT,
            metacritic_score TEXT,
            review_total TEXT,
            header_image TEXT,
            poster_url TEXT,
            fanart_url TEXT,
            screenshot_urls TEXT,
            last_scraped INTEGER
        )
    """)
    con.execute("""
        CREATE TABLE IF NOT EXISTS collections (
            collection_id TEXT,
            name TEXT,
            appid TEXT,
            PRIMARY KEY(collection_id, appid)
        )
    """)
    cur = con.cursor()
    ensure_col(cur, "games", "steam_review_percent", "TEXT")
    ensure_col(cur, "games", "steam_review_desc", "TEXT")
    ensure_col(cur, "games", "steam_review_total", "TEXT")
    ensure_col(cur, "games", "achievement_unlocked", "TEXT")
    ensure_col(cur, "games", "achievement_total", "TEXT")
    ensure_col(cur, "games", "achievement_status", "TEXT")
    con.commit()
    return con


def http_json(url, timeout=25):
    req = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8", errors="replace"))


def expand_path(path):
    if not path:
        return ""
    return os.path.expandvars(os.path.expanduser(path.strip().strip('"')))


def auto_find_cloud_json():
    # Do not hardcode userdata id. Search the real Steam client userdata folders.
    candidates = []

    roots = [
        os.path.expandvars(r"%ProgramFiles(x86)%\Steam\userdata"),
        os.path.expandvars(r"%ProgramFiles%\Steam\userdata"),
    ]

    for root in roots:
        if not root or "%" in root or not os.path.isdir(root):
            continue
        pattern = os.path.join(root, "*", "config", "cloudstorage", "cloud-storage-namespace-1.json")
        candidates.extend(glob.glob(pattern))

    # fallback common old path only if present
    old = r"C:\Program Files (x86)\Steam\userdata\123183459\config\cloudstorage\cloud-storage-namespace-1.json"
    if os.path.exists(old):
        candidates.append(old)

    good = []
    for p in set(candidates):
        try:
            good.append((os.path.getmtime(p), p))
        except Exception:
            pass

    if not good:
        return ""

    good.sort(reverse=True)
    return good[0][1]


def cloud_json_path():
    manual = expand_path(setting_str("cloud_json_path", ""))
    if manual and os.path.exists(manual):
        return manual
    return auto_find_cloud_json()


def parse_cloud_collections(path):
    if not path or not os.path.exists(path):
        return []

    try:
        raw = json.loads(open(path, "r", encoding="utf-8").read())
    except Exception as exc:
        log("Cannot read cloud collections: {}".format(exc), xbmc.LOGWARNING)
        return []

    collections = []

    for item in raw:
        if not isinstance(item, list) or len(item) < 2:
            continue
        key, payload = item[0], item[1]
        if not str(key).startswith("user-collections."):
            continue

        value = payload.get("value")
        if not value:
            continue

        try:
            data = json.loads(value)
        except Exception:
            continue

        name = data.get("name") or data.get("id") or key
        cid = data.get("id") or key
        added = data.get("added") or []
        removed = set(str(x) for x in (data.get("removed") or []))
        appids = [str(x) for x in added if str(x) not in removed]

        if not appids:
            continue

        collections.append({
            "id": str(cid),
            "key": key,
            "name": str(name),
            "appids": appids,
        })

    # Keep real Steam client order from file.
    return collections


def sync_collections():
    con = db()
    cur = con.cursor()

    path = cloud_json_path()
    collections = parse_cloud_collections(path)

    cur.execute("DELETE FROM collections")
    for c in collections:
        for appid in c["appids"]:
            cur.execute(
                "INSERT OR REPLACE INTO collections(collection_id, name, appid) VALUES(?,?,?)",
                (c["id"], c["name"], appid),
            )
    con.commit()
    con.close()
    return collections, path


def owned_games_appids():
    api_key = setting_str("steam_api_key")
    steam_id = setting_str("steam_id64")
    if not api_key or not steam_id:
        return []

    url = (
        "https://api.steampowered.com/IPlayerService/GetOwnedGames/v1/"
        "?key={}&steamid={}&include_appinfo=1&include_played_free_games=1"
    ).format(urllib.parse.quote(api_key), urllib.parse.quote(steam_id))

    try:
        js = http_json(url)
        games = ((js.get("response") or {}).get("games") or [])
        return [str(g.get("appid")) for g in games if g.get("appid")]
    except Exception as exc:
        log("Owned games API failed: {}".format(exc), xbmc.LOGWARNING)
        return []


def appids_from_real_client_collections(collections):
    appids = []
    seen = set()
    for c in collections:
        for appid in c["appids"]:
            if appid not in seen:
                seen.add(appid)
                appids.append(appid)
    return appids


def direct_poster_url(appid):
    return "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{}/library_600x900.jpg".format(appid)


def fetch_review_summary(appid):
    if not setting_bool("fetch_steam_reviews", True):
        return {"steam_review_percent": "", "steam_review_desc": "", "steam_review_total": ""}
    url = "https://store.steampowered.com/appreviews/{}?json=1&language=all&purchase_type=all&num_per_page=0".format(appid)
    try:
        js = http_json(url, timeout=20)
        qs = js.get("query_summary") or {}
        pos = int(qs.get("total_positive") or 0)
        neg = int(qs.get("total_negative") or 0)
        total = int(qs.get("total_reviews") or (pos + neg) or 0)
        pct = str(int(round((pos * 100.0) / float(total)))) if total > 0 else ""
        return {
            "steam_review_percent": pct,
            "steam_review_desc": qs.get("review_score_desc") or "",
            "steam_review_total": str(total) if total else "",
        }
    except Exception as exc:
        log("Review summary failed for {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return {"steam_review_percent": "", "steam_review_desc": "", "steam_review_total": ""}


def fetch_achievements(appid):
    if not setting_bool("fetch_achievements", True):
        return {"achievement_unlocked": "", "achievement_total": "", "achievement_status": ""}
    api_key = setting_str("steam_api_key")
    steam_id = setting_str("steam_id64")
    if not api_key or not steam_id:
        return {"achievement_unlocked": "", "achievement_total": "", "achievement_status": ""}
    url = (
        "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v0001/"
        "?appid={}&key={}&steamid={}&l=en"
    ).format(urllib.parse.quote(str(appid)), urllib.parse.quote(api_key), urllib.parse.quote(steam_id))
    try:
        js = http_json(url, timeout=20)
        achievements = ((js.get("playerstats") or {}).get("achievements") or [])
        total = len(achievements)
        unlocked = 0
        for a in achievements:
            try:
                if int(a.get("achieved") or 0) == 1:
                    unlocked += 1
            except Exception:
                pass
        status = "COMPLETED" if total > 0 and unlocked == total else ("IN PROGRESS" if total > 0 else "")
        return {
            "achievement_unlocked": str(unlocked) if total > 0 else "",
            "achievement_total": str(total) if total > 0 else "",
            "achievement_status": status,
        }
    except Exception as exc:
        log("Achievements failed for {}: {}".format(appid, exc), xbmc.LOGWARNING)
        return {"achievement_unlocked": "", "achievement_total": "", "achievement_status": ""}


def scrape_game(appid, force=False):
    cache_days = setting_int("cache_days", 30)
    now = int(time.time())

    con = db()
    cur = con.cursor()

    cur.execute("SELECT * FROM games WHERE appid=?", (str(appid),))
    row = cur.fetchone()
    if row and not force:
        last = row["last_scraped"] or 0
        if now - int(last) < cache_days * 86400:
            con.close()
            return dict(row)

    url = "https://store.steampowered.com/api/appdetails?appids={}&filters=basic,genres,categories,screenshots,metacritic,recommendations".format(appid)

    try:
        js = http_json(url)
        app = js.get(str(appid), {})
        if not app.get("success"):
            raise RuntimeError("appdetails success=false")

        data = app.get("data") or {}
        screenshots = data.get("screenshots") or []
        ss_urls = [x.get("path_full") for x in screenshots if x.get("path_full")]
        ss_index = max(setting_int("screenshot_number", 2), 1) - 1
        fanart = ss_urls[ss_index] if len(ss_urls) > ss_index else (ss_urls[0] if ss_urls else "")

        release = ((data.get("release_date") or {}).get("date") or "")
        year = ""
        for token in release.replace(",", " ").split():
            if token.isdigit() and len(token) == 4:
                year = token
                break

        developers = " / ".join(data.get("developers") or [])
        publishers = " / ".join(data.get("publishers") or [])
        genres = " / ".join([g.get("description", "") for g in (data.get("genres") or []) if g.get("description")])
        categories = " / ".join([g.get("description", "") for g in (data.get("categories") or []) if g.get("description")])
        metacritic = str((data.get("metacritic") or {}).get("score") or "")
        review_total_appdetails = str((data.get("recommendations") or {}).get("total") or "")
        review = fetch_review_summary(appid)
        achievements = fetch_achievements(appid)

        game = {
            "appid": str(appid),
            "name": data.get("name") or "Steam App {}".format(appid),
            "sort_name": data.get("name") or "Steam App {}".format(appid),
            "release_date": release,
            "year": year,
            "developers": developers,
            "publishers": publishers,
            "genres": genres,
            "categories": categories,
            "short_description": data.get("short_description") or "",
            "detailed_description": data.get("detailed_description") or data.get("about_the_game") or "",
            "metacritic_score": metacritic,
            "review_total": review_total_appdetails,
            "header_image": data.get("header_image") or "",
            "poster_url": direct_poster_url(appid),
            "fanart_url": fanart,
            "screenshot_urls": json.dumps(ss_urls),
            "last_scraped": now,
            "steam_review_percent": review.get("steam_review_percent") or "",
            "steam_review_desc": review.get("steam_review_desc") or "",
            "steam_review_total": review.get("steam_review_total") or review_total_appdetails or "",
            "achievement_unlocked": achievements.get("achievement_unlocked") or "",
            "achievement_total": achievements.get("achievement_total") or "",
            "achievement_status": achievements.get("achievement_status") or "",
        }

        cur.execute("""
            INSERT OR REPLACE INTO games(
                appid, name, sort_name, release_date, year, developers, publishers,
                genres, categories, short_description, detailed_description,
                metacritic_score, review_total, header_image, poster_url, fanart_url,
                screenshot_urls, last_scraped, steam_review_percent, steam_review_desc,
                steam_review_total, achievement_unlocked, achievement_total, achievement_status
            ) VALUES(
                :appid, :name, :sort_name, :release_date, :year, :developers, :publishers,
                :genres, :categories, :short_description, :detailed_description,
                :metacritic_score, :review_total, :header_image, :poster_url, :fanart_url,
                :screenshot_urls, :last_scraped, :steam_review_percent, :steam_review_desc,
                :steam_review_total, :achievement_unlocked, :achievement_total, :achievement_status
            )
        """, game)
        con.commit()
        con.close()
        return game

    except Exception as exc:
        log("Scrape failed for {}: {}".format(appid, exc), xbmc.LOGWARNING)
        fallback = {
            "appid": str(appid), "name": "Steam App {}".format(appid), "sort_name": "Steam App {}".format(appid),
            "release_date": "", "year": "", "developers": "", "publishers": "", "genres": "", "categories": "",
            "short_description": "", "detailed_description": "", "metacritic_score": "", "review_total": "",
            "header_image": "", "poster_url": direct_poster_url(appid), "fanart_url": "", "screenshot_urls": "[]",
            "last_scraped": 0, "steam_review_percent": "", "steam_review_desc": "", "steam_review_total": "",
            "achievement_unlocked": "", "achievement_total": "", "achievement_status": "",
        }
        con.close()
        return fallback


def clean_html(text):
    import re
    if not text:
        return ""
    text = re.sub(r"<br\s*/?>", "\n", text, flags=re.I)
    text = re.sub(r"<[^>]+>", "", text)
    return text.replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'").strip()


def make_game_item(game):
    appid = game["appid"]
    li = xbmcgui.ListItem(label=game.get("name") or "Steam App {}".format(appid))
    li.setProperty("IsPlayable", "true")

    plot_lines = []
    if game.get("short_description"):
        plot_lines.append(clean_html(game.get("short_description")))

    meta = []
    review_pct = game.get("steam_review_percent") or ""
    review_desc = game.get("steam_review_desc") or ""
    review_total = game.get("steam_review_total") or game.get("review_total") or ""
    if review_pct or review_desc:
        label = "Steam: "
        if review_pct:
            label += "{}%".format(review_pct)
        if review_desc:
            label += " {}".format(review_desc)
        if review_total:
            label += " ({})".format(review_total)
        meta.append(label)

    if game.get("achievement_total"):
        ach = "Achievements: {}/{}".format(game.get("achievement_unlocked") or "0", game.get("achievement_total"))
        if game.get("achievement_status"):
            ach += " - {}".format(game.get("achievement_status"))
        meta.append(ach)

    if game.get("developers"):
        meta.append("Developer: " + game.get("developers"))
    if game.get("publishers"):
        meta.append("Publisher: " + game.get("publishers"))
    if game.get("metacritic_score"):
        meta.append("Metacritic: " + game.get("metacritic_score"))
    if meta:
        plot_lines.append("\n".join(meta))

    info = {
        "title": game.get("name") or "",
        "plot": "\n\n".join(plot_lines),
        "genre": game.get("genres") or "",
        "year": int(game["year"]) if str(game.get("year") or "").isdigit() else 0,
        "studio": game.get("developers") or game.get("publishers") or "",
    }
    try:
        li.setInfo("video", info)
    except Exception:
        pass

    art = {
        "poster": game.get("poster_url") or game.get("header_image") or "",
        "thumb": game.get("header_image") or game.get("poster_url") or "",
        "icon": game.get("header_image") or game.get("poster_url") or "",
        "fanart": game.get("fanart_url") or "",
        "landscape": game.get("fanart_url") or game.get("header_image") or "",
    }
    li.setArt({k: v for k, v in art.items() if v})

    li.setProperty("appid", appid)
    li.setProperty("steam_appid", appid)
    li.setProperty("developer", game.get("developers") or "")
    li.setProperty("publisher", game.get("publishers") or "")
    li.setProperty("metacritic_score", game.get("metacritic_score") or "")
    li.setProperty("steam_review_percent", review_pct)
    li.setProperty("steam_review_desc", review_desc)
    li.setProperty("steam_review_total", review_total)
    li.setProperty("achievement_unlocked", game.get("achievement_unlocked") or "")
    li.setProperty("achievement_total", game.get("achievement_total") or "")
    li.setProperty("achievement_status", game.get("achievement_status") or "")
    li.setProperty("release_date", game.get("release_date") or "")

    li.addContextMenuItems([
        ("Refresh metadata", "RunPlugin({})".format(url_for(mode="refresh", appid=appid))),
        ("Open Steam store page", "RunPlugin({})".format(url_for(mode="store", appid=appid))),
        ("Addon settings", "Addon.OpenSettings({})".format(ADDON_ID)),
    ])
    return li


def add_dir(label, mode, **kwargs):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": "DefaultFolder.png"})

    cm = [
        ("Choose visible collections", "RunPlugin({})".format(url_for(mode="choose_collections"))),
        ("Show all collections", "RunPlugin({})".format(url_for(mode="show_all_collections"))),
        ("Addon settings", "Addon.OpenSettings({})".format(ADDON_ID)),
    ]

    collection_name = kwargs.get("collection_name_for_context")
    if collection_name:
        cm.insert(0, ("Hide this collection", "RunPlugin({})".format(url_for(mode="hide_collection", name=collection_name))))

    li.addContextMenuItems(cm)

    params = {"mode": mode}
    # collection_name_for_context is only for context menu, not URL payload.
    kwargs.pop("collection_name_for_context", None)
    params.update(kwargs)
    xbmcplugin.addDirectoryItem(HANDLE, url_for(**params), li, True)

def root():
    collections, path = sync_collections()
    collections = filter_collections(collections)

    # Root is clean: only real Steam client collections plus optional All Games.
    # No Settings / Sync helper folders here.
    if collections:
        if setting_bool("show_all_games", True):
            all_count = len(appids_from_real_client_collections(collections))
            add_dir("All Games ({})".format(all_count), "list", collection="__all_client__")

        for c in collections:
            add_dir("{} ({})".format(c["name"], len(c["appids"])), "list", collection_id=c["id"], collection_name_for_context=c["name"])
    else:
        li = xbmcgui.ListItem(label="No visible Steam client collections")
        li.setInfo("video", {"plot": "No Steam collections are visible. Check collection filter settings.\nDetected path: {}".format(path or "not found")})
        xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="noop"), li, False)

    xbmcplugin.endOfDirectory(HANDLE)


def appids_for_collection(collection=None, collection_id=None):
    collections, _ = sync_collections()
    visible_collections = filter_collections(collections)

    if collection == "__all_client__":
        return appids_from_real_client_collections(visible_collections)

    for c in visible_collections:
        if c["id"] == collection_id:
            return c["appids"]

    return []


def list_games(params):
    appids = appids_for_collection(
        collection=params.get("collection"),
        collection_id=params.get("collection_id"),
    )

    total = len(appids)
    xbmcplugin.setContent(HANDLE, "games")

    progress = None
    if total > 30:
        try:
            progress = xbmcgui.DialogProgressBG()
            progress.create(ADDON_NAME, "Loading Steam metadata...")
        except Exception:
            progress = None

    for idx, appid in enumerate(appids, 1):
        if progress and idx % 5 == 0:
            try:
                progress.update(int((idx / max(total, 1)) * 100), "Loading {}/{}".format(idx, total))
            except Exception:
                pass
        game = scrape_game(appid, force=False)
        li = make_game_item(game)
        xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="play", appid=appid), li, False, total)

    if progress:
        try:
            progress.close()
        except Exception:
            pass

    xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
    xbmcplugin.endOfDirectory(HANDLE)


def refresh(appid):
    scrape_game(appid, force=True)
    xbmcgui.Dialog().notification(ADDON_NAME, "Metadata refreshed: {}".format(appid), xbmcgui.NOTIFICATION_INFO, 3000)
    xbmc.executebuiltin("Container.Refresh")


def open_store(appid):
    try:
        os.startfile("https://store.steampowered.com/app/{}/".format(appid))
    except Exception:
        xbmc.executebuiltin("System.Exec({})".format("https://store.steampowered.com/app/{}/".format(appid)))


def launch(appid):
    steam_url = "steam://rungameid/{}".format(appid)
    method = setting_int("launch_method", 0)
    try:
        if method == 0 and hasattr(os, "startfile"):
            os.startfile(steam_url)
        elif method == 1:
            subprocess.Popen(["cmd", "/c", "start", "", steam_url], shell=False)
        else:
            xbmc.executebuiltin('System.Exec("{}")'.format(steam_url))
        xbmcgui.Dialog().notification(ADDON_NAME, "Launching Steam app {}".format(appid), xbmcgui.NOTIFICATION_INFO, 2500)
    except Exception as exc:
        xbmcgui.Dialog().ok(ADDON_NAME, "Gagal launch Steam app {}\n{}".format(appid, exc))


def run():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    mode = params.get("mode", "root")

    if mode == "root":
        root()
    elif mode == "list":
        list_games(params)
    elif mode == "play":
        launch(params.get("appid"))
    elif mode == "refresh":
        refresh(params.get("appid"))
    elif mode == "store":
        open_store(params.get("appid"))
    elif mode == "choose_collections":
        choose_visible_collections()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "show_all_collections":
        show_all_collections()
        xbmcplugin.endOfDirectory(HANDLE)
    elif mode == "hide_collection":
        hide_collection_by_name(params.get("name"))
        xbmcplugin.endOfDirectory(HANDLE)
    else:
        xbmcplugin.endOfDirectory(HANDLE)


if __name__ == "__main__":
    run()

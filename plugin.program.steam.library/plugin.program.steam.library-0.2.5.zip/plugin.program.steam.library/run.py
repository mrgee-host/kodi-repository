# -*- coding: utf-8 -*-
from __future__ import annotations
import csv, glob, json, os, sqlite3, time, traceback, urllib.parse, urllib.request, zipfile
import xbmc, xbmcaddon, xbmcgui, xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
UA = "Kodi-Steam-Library-Run/0.2.5"

def log(msg, level=xbmc.LOGINFO):
    xbmc.log("[{} Run] {}".format(ADDON_NAME, msg), level)

def tr(path):
    try: return xbmcvfs.translatePath(path)
    except Exception: return xbmc.translatePath(path)

PROFILE = tr("special://profile/addon_data/{}/".format(ADDON_ID))
DB_PATH = os.path.join(PROFILE, "steam_library.db")
DIAG = os.path.join(PROFILE, "diagnostics")

def ensure():
    os.makedirs(PROFILE, exist_ok=True)
    os.makedirs(DIAG, exist_ok=True)

def s(key, default=""):
    v = ADDON.getSetting(key)
    return v if v else default

def b(key, default=False):
    v = ADDON.getSetting(key)
    return default if v == "" else str(v).lower() == "true"

def i(key, default=0):
    try: return int(ADDON.getSetting(key))
    except Exception: return default

def http_json(url, timeout=25):
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return json.loads(r.read().decode("utf-8", errors="replace"))

def connect():
    ensure()
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row
    con.execute("""CREATE TABLE IF NOT EXISTS games (
        appid TEXT PRIMARY KEY, name TEXT, sort_name TEXT, release_date TEXT, year TEXT,
        developers TEXT, publishers TEXT, genres TEXT, categories TEXT,
        short_description TEXT, detailed_description TEXT, metacritic_score TEXT,
        review_total TEXT, header_image TEXT, poster_url TEXT, fanart_url TEXT,
        screenshot_urls TEXT, last_scraped INTEGER)""")
    con.execute("""CREATE TABLE IF NOT EXISTS collections (
        collection_id TEXT, name TEXT, appid TEXT, PRIMARY KEY(collection_id, appid))""")
    cur = con.cursor()
    cur.execute("PRAGMA table_info(games)")
    cols = [r[1] for r in cur.fetchall()]
    for col in ["steam_review_percent","steam_review_desc","steam_review_total","achievement_unlocked","achievement_total","achievement_status"]:
        if col not in cols:
            cur.execute("ALTER TABLE games ADD COLUMN {} TEXT".format(col))
    con.commit()
    return con

def cloud_json():
    manual = os.path.expandvars((s("cloud_json_path") or "").strip().strip('"'))
    if manual and os.path.exists(manual):
        return manual
    roots = [os.path.expandvars(r"%ProgramFiles(x86)%\Steam\userdata"), os.path.expandvars(r"%ProgramFiles%\Steam\userdata")]
    found = []
    for root in roots:
        if root and "%" not in root and os.path.isdir(root):
            found += glob.glob(os.path.join(root, "*", "config", "cloudstorage", "cloud-storage-namespace-1.json"))
    found = [(os.path.getmtime(p), p) for p in set(found) if os.path.exists(p)]
    found.sort(reverse=True)
    return found[0][1] if found else ""

def parse_collections(path):
    if not path or not os.path.exists(path): return []
    raw = json.loads(open(path, "r", encoding="utf-8").read())
    out = []
    for item in raw:
        if not isinstance(item, list) or len(item) < 2: continue
        key, payload = item[0], item[1]
        if not str(key).startswith("user-collections."): continue
        try: data = json.loads(payload.get("value") or "{}")
        except Exception: continue
        name = str(data.get("name") or data.get("id") or key)
        cid = str(data.get("id") or key)
        removed = set(str(x) for x in (data.get("removed") or []))
        appids = [str(x) for x in (data.get("added") or []) if str(x) not in removed]
        if appids: out.append({"id":cid, "name":name, "appids":appids})
    return out

def sync_collections():
    con = connect(); cur = con.cursor()
    path = cloud_json()
    cols = parse_collections(path)
    cur.execute("DELETE FROM collections")
    for c in cols:
        for appid in c["appids"]:
            cur.execute("INSERT OR REPLACE INTO collections(collection_id,name,appid) VALUES(?,?,?)", (c["id"], c["name"], appid))
    con.commit(); con.close()
    return cols, path

def all_appids(cols):
    seen, appids = set(), []
    for c in cols:
        for a in c["appids"]:
            if a not in seen:
                seen.add(a); appids.append(a)
    return appids

def poster(appid):
    return "https://shared.fastly.steamstatic.com/store_item_assets/steam/apps/{}/library_600x900.jpg".format(appid)

def reviews(appid):
    if not b("fetch_steam_reviews", True): return {}
    try:
        js = http_json("https://store.steampowered.com/appreviews/{}?json=1&language=all&purchase_type=all&num_per_page=0".format(appid), 20)
        q = js.get("query_summary") or {}
        pos, neg = int(q.get("total_positive") or 0), int(q.get("total_negative") or 0)
        total = int(q.get("total_reviews") or pos + neg)
        pct = str(int(round(pos * 100.0 / total))) if total else ""
        return {"steam_review_percent":pct, "steam_review_desc":q.get("review_score_desc") or "", "steam_review_total":str(total) if total else ""}
    except Exception:
        return {}

def achievements(appid):
    if not b("fetch_achievements", True): return {}
    key, sid = s("steam_api_key"), s("steam_id64")
    if not key or not sid: return {}
    try:
        url = "https://api.steampowered.com/ISteamUserStats/GetPlayerAchievements/v0001/?appid={}&key={}&steamid={}&l=en".format(urllib.parse.quote(str(appid)), urllib.parse.quote(key), urllib.parse.quote(sid))
        js = http_json(url, 20)
        arr = ((js.get("playerstats") or {}).get("achievements") or [])
        total = len(arr); unlocked = sum(1 for a in arr if int(a.get("achieved") or 0) == 1)
        return {"achievement_unlocked":str(unlocked) if total else "", "achievement_total":str(total) if total else "", "achievement_status":"COMPLETED" if total and unlocked == total else ("IN PROGRESS" if total else "")}
    except Exception:
        return {}

def scrape(appid):
    js = http_json("https://store.steampowered.com/api/appdetails?appids={}&filters=basic,genres,categories,screenshots,metacritic,recommendations".format(appid), 25)
    app = js.get(str(appid), {})
    if not app.get("success"): raise RuntimeError("appdetails success=false")
    d = app.get("data") or {}
    shots = [x.get("path_full") for x in (d.get("screenshots") or []) if x.get("path_full")]
    n = max(i("screenshot_number", 2), 1) - 1
    fanart = shots[n] if len(shots) > n else (shots[0] if shots else "")
    release = ((d.get("release_date") or {}).get("date") or "")
    year = ""
    for t in release.replace(",", " ").split():
        if t.isdigit() and len(t) == 4: year = t; break
    g = {"appid":str(appid), "name":d.get("name") or "Steam App {}".format(appid), "sort_name":d.get("name") or "Steam App {}".format(appid),
         "release_date":release, "year":year, "developers":" / ".join(d.get("developers") or []), "publishers":" / ".join(d.get("publishers") or []),
         "genres":" / ".join([x.get("description","") for x in (d.get("genres") or []) if x.get("description")]),
         "categories":" / ".join([x.get("description","") for x in (d.get("categories") or []) if x.get("description")]),
         "short_description":d.get("short_description") or "", "detailed_description":d.get("detailed_description") or d.get("about_the_game") or "",
         "metacritic_score":str((d.get("metacritic") or {}).get("score") or ""), "review_total":str((d.get("recommendations") or {}).get("total") or ""),
         "header_image":d.get("header_image") or "", "poster_url":poster(appid), "fanart_url":fanart, "screenshot_urls":json.dumps(shots), "last_scraped":int(time.time())}
    g.update({"steam_review_percent":"","steam_review_desc":"","steam_review_total":"","achievement_unlocked":"","achievement_total":"","achievement_status":""})
    g.update(reviews(appid)); g.update(achievements(appid))
    return g

def save(game):
    con = connect(); cur = con.cursor()
    cur.execute("""INSERT OR REPLACE INTO games(appid,name,sort_name,release_date,year,developers,publishers,genres,categories,short_description,detailed_description,metacritic_score,review_total,header_image,poster_url,fanart_url,screenshot_urls,last_scraped,steam_review_percent,steam_review_desc,steam_review_total,achievement_unlocked,achievement_total,achievement_status)
    VALUES(:appid,:name,:sort_name,:release_date,:year,:developers,:publishers,:genres,:categories,:short_description,:detailed_description,:metacritic_score,:review_total,:header_image,:poster_url,:fanart_url,:screenshot_urls,:last_scraped,:steam_review_percent,:steam_review_desc,:steam_review_total,:achievement_unlocked,:achievement_total,:achievement_status)""", game)
    con.commit(); con.close()

def refresh_all(missing=False):
    cols, path = sync_collections(); appids = all_appids(cols)
    con = connect(); cur = con.cursor(); cur.execute("SELECT appid FROM games"); existing = set(str(r[0]) for r in cur.fetchall()); con.close()
    if missing: appids = [a for a in appids if a not in existing]
    if not appids:
        xbmcgui.Dialog().ok(ADDON_NAME, "Nothing to scrape."); return
    prog = xbmcgui.DialogProgress(); prog.create(ADDON_NAME, "Starting metadata scrape...")
    rows=[]; ok=fail=0
    for idx, appid in enumerate(appids, 1):
        prog.update(int(idx*100/max(len(appids),1)), "{}/{} METADATA - {}".format(idx, len(appids), appid))
        if prog.iscanceled(): break
        try:
            game = scrape(appid); save(game); ok += 1
            rows.append({"appid":appid,"status":"ok","name":game["name"],"error":""})
        except Exception as e:
            fail += 1; rows.append({"appid":appid,"status":"failed","name":"","error":str(e)})
        xbmc.sleep(150)
    prog.close()
    report = os.path.join(DIAG, "metadata_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        w=csv.DictWriter(f, fieldnames=["appid","status","name","error"]); w.writeheader(); w.writerows(rows)
    summary={"mode":"missing" if missing else "all","total":len(appids),"ok":ok,"failed":fail,"report":report,"timestamp":time.strftime("%Y-%m-%d %H:%M:%S")}
    open(os.path.join(PROFILE, "last_run_summary.json"), "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))
    xbmcgui.Dialog().ok(ADDON_NAME, "Done.\nOK: {}\nFailed: {}\n\n{}".format(ok, fail, report))

def status():
    cols, path = sync_collections(); appids = all_appids(cols)
    con=connect(); cur=con.cursor()
    def count(sql): cur.execute(sql); return cur.fetchone()[0]
    msg = "Collections: {}\nSteam AppIDs: {}\nGames in DB: {}\nPoster URLs: {}\nFanart URLs: {}\nReview scores: {}\nAchievements: {}\n\nDB:\n{}\n\nCloud JSON:\n{}".format(
        len(cols), len(appids), count("SELECT COUNT(*) FROM games"), count("SELECT COUNT(*) FROM games WHERE poster_url!=''"), count("SELECT COUNT(*) FROM games WHERE fanart_url!=''"), count("SELECT COUNT(*) FROM games WHERE steam_review_percent!=''"), count("SELECT COUNT(*) FROM games WHERE achievement_total!=''"), DB_PATH, path or "not found")
    con.close(); xbmcgui.Dialog().ok(ADDON_NAME, msg)

def export_diag():
    ensure()
    zip_path = os.path.join(PROFILE, "steam-library-diagnostics-{}.zip".format(time.strftime("%Y%m%d-%H%M%S")))
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as z:
        if os.path.exists(DB_PATH): z.write(DB_PATH, "steam_library.db")
        for p in glob.glob(os.path.join(DIAG, "*")): z.write(p, "diagnostics/" + os.path.basename(p))
        sfile = os.path.join(PROFILE, "last_run_summary.json")
        if os.path.exists(sfile): z.write(sfile, "last_run_summary.json")
    xbmcgui.Dialog().ok(ADDON_NAME, "Diagnostics exported:\n{}".format(zip_path))

def _artwork_urls_from_db(missing_only=True):
    con = connect()
    cur = con.cursor()
    cur.execute("SELECT appid, name, poster_url, fanart_url, header_image FROM games ORDER BY name")
    rows = cur.fetchall()
    con.close()

    urls = []
    seen = set()
    for r in rows:
        appid = str(r["appid"])
        name = r["name"] or appid
        for art_type, url in [
            ("poster", r["poster_url"]),
            ("fanart", r["fanart_url"]),
            ("thumb", r["header_image"]),
        ]:
            if not url:
                continue
            key = (art_type, url)
            if key in seen:
                continue
            seen.add(key)
            urls.append({
                "appid": appid,
                "name": name,
                "art_type": art_type,
                "url": url,
            })
    return urls


def cache_artwork(missing_only=True):
    # Remote-only artwork cache:
    # Does NOT download artwork to addon_data.
    # It pre-warms Kodi's own texture cache by rendering each remote URL briefly.
    urls = _artwork_urls_from_db(missing_only=missing_only)
    if not urls:
        xbmcgui.Dialog().ok(ADDON_NAME, "No artwork URLs in DB.\nRun Refresh all metadata first.")
        return

    confirm = xbmcgui.Dialog().yesno(
        ADDON_NAME,
        "Cache artwork to Kodi Textures/Thumbnails?\n\n"
        "Remote-only mode: addon will not save images locally.\n"
        "Kodi will handle Textures DB and Thumbnails."
    )
    if not confirm:
        return

    progress = xbmcgui.DialogProgress()
    progress.create(ADDON_NAME, "Caching artwork URLs...")

    rows = []
    ok = 0
    failed = 0

    # Real Kodi texture cache is triggered when the image is rendered.
    # Use a small temporary WindowDialog and ControlImage.
    win = None
    img = None
    try:
        win = xbmcgui.WindowDialog()
        img = xbmcgui.ControlImage(0, 0, 32, 32, "")
        win.addControl(img)
        win.show()

        total = len(urls)
        for idx, item in enumerate(urls, 1):
            pct = int(idx * 100 / max(total, 1))
            label = "{}/{} ARTWORK - {} - {}".format(idx, total, item["art_type"], item["name"])
            progress.update(pct, label[:90])
            if progress.iscanceled():
                break

            try:
                # setImage makes Kodi resolve/cache the remote URL.
                img.setImage(item["url"])
                xbmc.sleep(180)
                ok += 1
                rows.append({
                    "appid": item["appid"],
                    "name": item["name"],
                    "art_type": item["art_type"],
                    "url": item["url"],
                    "status": "queued_to_kodi_cache",
                    "error": "",
                })
            except Exception as exc:
                failed += 1
                rows.append({
                    "appid": item["appid"],
                    "name": item["name"],
                    "art_type": item["art_type"],
                    "url": item["url"],
                    "status": "failed",
                    "error": str(exc),
                })

    finally:
        try:
            if win:
                win.close()
        except Exception:
            pass
        try:
            progress.close()
        except Exception:
            pass

    report = os.path.join(DIAG, "artwork_cache_report.csv")
    with open(report, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["appid", "name", "art_type", "url", "status", "error"])
        w.writeheader()
        for r in rows:
            w.writerow(r)

    summary_path = os.path.join(PROFILE, "last_artwork_cache_summary.json")
    summary = {
        "mode": "remote_only_kodi_texture_cache",
        "total_urls": len(urls),
        "queued": ok,
        "failed": failed,
        "report": report,
        "timestamp": time.strftime("%Y-%m-%d %H:%M:%S"),
    }
    open(summary_path, "w", encoding="utf-8").write(json.dumps(summary, indent=2, ensure_ascii=False))

    xbmcgui.Dialog().ok(
        ADDON_NAME,
        "Artwork cache queued.\nURLs: {}\nQueued: {}\nFailed: {}\n\nKodi handles Textures/Thumbnails.\n{}".format(
            len(urls), ok, failed, report
        )
    )


def menu():
    opts=["Refresh all metadata","Scrape missing metadata","Cache artwork URLs","View status","Export diagnostics ZIP","Settings","Exit"]
    n = xbmcgui.Dialog().select("Steam Library - Run", opts)
    if n < 0 or n == 6: return
    try:
        if n == 0: refresh_all(False)
        elif n == 1: refresh_all(True)
        elif n == 2: cache_artwork(missing_only=False)
        elif n == 3: status()
        elif n == 4: export_diag()
        elif n == 5: ADDON.openSettings()
    except Exception as e:
        log(traceback.format_exc(), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(ADDON_NAME, "Run error:\n{}".format(e))

if __name__ == "__main__":
    menu()

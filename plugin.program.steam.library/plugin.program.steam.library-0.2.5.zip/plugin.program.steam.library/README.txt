Steam Library for Kodi v0.2.0

New:
- Steam review percentage + label from appreviews endpoint.
- Achievement count from Steam Web API when API key + SteamID64 are set.
- Achievement status: COMPLETED / IN PROGRESS.
- Review and achievement values added to ListItem properties and plot.
- Background progress while loading large collections.
- Root stays clean: only All Games + visible real Steam client collections.

Still no AKL:
- no akl.db
- no AKL rendered views
- no custom skin XML
- native Kodi ListItems


v0.2.1:
- Added interactive collection picker via context menu.
- On any root folder: context menu -> Choose visible collections.
- Multi-select Steam client collections to show.
- Stores selection in visible_collection_names and sets filter mode to Show only listed.
- Context menu also has Hide this collection and Show all collections.


v0.2.2:
- Main library root remains clean: only All Games + visible real Steam client collections.
- Added run.py for addon information Run menu.
- Run menu:
  Refresh all metadata
  Scrape missing metadata
  View status
  Export diagnostics ZIP
  Settings
- Artwork remains remote-only: URLs are stored in steam_library.db and Kodi handles Textures/Thumbnails.


v0.2.3:
- Added Run menu option: Cache artwork URLs.
- This is remote-only caching, like LAC:
  * addon stores artwork URLs in steam_library.db
  * Kodi renders remote URLs
  * Kodi handles Textures DB and Thumbnails
  * addon does not download images to addon_data/artwork
- Cache artwork works by temporarily rendering poster/fanart/thumb URLs so Kodi queues them into its texture cache.


v0.2.4:
- Rebuilt package with higher version to force Kodi update.
- Updated addon icon and fanart from supplied Steam Library artwork.
- Added icon.png and fanart.png at root too for skins/repo views.
- Kept library root clean.
- Run tools remain in Add-on information -> Run.


v0.2.5:
- Fixed addon.xml XML declaration.
- Previous v0.2.4 accidentally changed XML declaration to version="0.2.4", so import tools could not parse addon.xml.
- Addon version is now correctly 0.2.5 while XML declaration remains version="1.0".

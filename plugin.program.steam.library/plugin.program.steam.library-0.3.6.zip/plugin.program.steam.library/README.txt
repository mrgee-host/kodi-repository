Steam Library v0.3.0

Single-addon version.

Kodi behavior:
- This is a plugin source addon, so Add-on Information shows Open, not Run.
- Root library remains clean:
  All Games + visible real Steam client collections only.
- Tools are hidden from the library root and accessed from context menu:
  Steam Library Tools

Tools menu:
- Refresh all metadata
- Scrape missing metadata
- Cache artwork URLs
- View status
- Export diagnostics ZIP
- Settings
- Exit

Remote-only artwork:
- addon stores Steam artwork URLs in steam_library.db
- ListItems use remote art URLs
- Kodi handles Textures DB and Thumbnails
- addon does not download artwork locally


v0.3.1:
- Refresh all metadata uses DialogProgressBG, not foreground modal progress.
- Scrape missing metadata uses DialogProgressBG.
- Cache artwork URLs uses background progress and avoids WindowDialog focus steal.
- Finish result uses notification; full details are written to reports/status JSON.


v0.3.2:
- Fixed DialogProgressBG heading/message mapping.
- Progress heading stays addon name: Steam Library.
- Progress body line now contains: 120/470 METADATA - Title - 25%.
- Metadata progress updates after each scrape so title is available instead of only AppID.


v0.3.3:
- Removed manual percent from progress body to avoid duplicate percent in AF3.
- Metadata progress format:
  {idx}/{total} METADATA - {title}
  {total}/{total} METADATA - DONE
- Caching progress format:
  {idx}/{total} CACHING - {title}
  {total}/{total} CACHING - DONE
- Added fallback title scraping from Steam Community page:
  https://steamcommunity.com/app/<appid>
- Delisted/removed Store apps are saved as partial_title_only instead of hard failed when a fallback title is found.


v0.3.4:
- Fixed missing http_json function introduced by v0.3.3 patch.
- Scrape missing no longer turns all items into partial_title_only because of NameError.
- Progress update is no longer throttled by 3/10-item intervals; metadata/caching updates every processed item.
- Added collection display rename:
  Context menu on collection -> Rename collection
  Context menu on collection -> Reset collection name
- Rename is addon-only display alias stored in addon_data collection_aliases.json; it does not edit Steam client collection names.


v0.3.5:
- icon.png is now 256x256.
- Clean games schema for active metadata only.
- Removed active use of sort_name, release_date, categories, detailed_description, achievement_status.
- Added developer, publisher, year, completed, finished, esrb, pegi, clearlogo_url.
- Added fanart total 5 slots including main:
  fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url.
- Empty valid no-data fields are stored as N/A.
- Temporary provider errors are not treated as N/A when possible.
- Full Steam appdetails URL is used, not the old filtered appdetails call.
- Steam clearlogo logo.png is used before SteamGridDB logos.
- SteamGridDB is only auto fallback for poster/clearlogo.
- SteamGridDB heroes are not used automatically for fanart.
- Manual Select artwork fetches candidates live and writes directly to the active URL column.
- Select artwork includes Steam assets and SteamGridDB candidates.


v0.3.6:
- Rebuilt settings.xml cleanly.
- Steam Account settings now contain Steam Web API Key, SteamID64, SteamGridDB API Key, and cloud JSON path.

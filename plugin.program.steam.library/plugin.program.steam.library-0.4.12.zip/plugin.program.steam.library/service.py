# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.program.steam.library"


def run_service():
    addon = xbmcaddon.Addon(ADDON_ID)
    monitor = xbmc.Monitor()
    try:
        def setting_bool(key, default=False):
            value = addon.getSetting(key)
            return default if value == "" else str(value).lower() == "true"

        def setting_int(key, default=0):
            try:
                return int(addon.getSetting(key))
            except Exception:
                return default

        if setting_bool("auto_sync_library_on_startup", True):
            # Do not sleep for a blind 25 seconds. Wait briefly for MediaHub's
            # startup order transaction, then use the user setting as a small
            # grace period. A missing/disabled MediaHub falls back after 10s.
            home = xbmcgui.Window(10000)
            waited = 0.0
            while waited < 10.0 and not monitor.abortRequested():
                ready = home.getProperty("MediaHub.Widget.SessionOrderReady.0137") == "true"
                if ready:
                    break
                if monitor.waitForAbort(0.25):
                    return
                waited += 0.25
            grace = max(1, setting_int("auto_scan_startup_delay", 1))
            if not monitor.waitForAbort(grace):
                xbmc.executebuiltin(
                    "RunPlugin(plugin://{}/?mode=background_sync&automatic=true)".format(
                        ADDON_ID
                    )
                )
    finally:
        # Explicitly release the Python/SWIG wrappers when the startup service
        # invocation ends.
        del monitor
        del addon


if __name__ == "__main__":
    run_service()

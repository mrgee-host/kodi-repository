Steam Library v0.3.0

Single-addon version.

Kodi behavior:
- This is a plugin source addon, so Add-on Information shows Open, not Run.
- Root library remains clean:
  All Games + visible real Steam client collections only.
- Tools are hidden from the library root and accessed from context menu:
  Steam Library Tools

Tools menu:
- Refresh all metadata
- Scrape missing metadata
- Cache artwork URLs
- View status
- Export diagnostics ZIP
- Settings
- Exit

Remote-only artwork:
- addon stores Steam artwork URLs in steam_library.db
- ListItems use remote art URLs
- Kodi handles Textures DB and Thumbnails
- addon does not download artwork locally


v0.3.1:
- Refresh all metadata uses DialogProgressBG, not foreground modal progress.
- Scrape missing metadata uses DialogProgressBG.
- Cache artwork URLs uses background progress and avoids WindowDialog focus steal.
- Finish result uses notification; full details are written to reports/status JSON.


v0.3.2:
- Fixed DialogProgressBG heading/message mapping.
- Progress heading stays addon name: Steam Library.
- Progress body line now contains: 120/470 METADATA - Title - 25%.
- Metadata progress updates after each scrape so title is available instead of only AppID.


v0.3.3:
- Removed manual percent from progress body to avoid duplicate percent in AF3.
- Metadata progress format:
  {idx}/{total} METADATA - {title}
  {total}/{total} METADATA - DONE
- Caching progress format:
  {idx}/{total} CACHING - {title}
  {total}/{total} CACHING - DONE
- Added fallback title scraping from Steam Community page:
  https://steamcommunity.com/app/<appid>
- Delisted/removed Store apps are saved as partial_title_only instead of hard failed when a fallback title is found.


v0.3.4:
- Fixed missing http_json function introduced by v0.3.3 patch.
- Scrape missing no longer turns all items into partial_title_only because of NameError.
- Progress update is no longer throttled by 3/10-item intervals; metadata/caching updates every processed item.
- Added collection display rename:
  Context menu on collection -> Rename collection
  Context menu on collection -> Reset collection name
- Rename is addon-only display alias stored in addon_data collection_aliases.json; it does not edit Steam client collection names.


v0.3.5:
- icon.png is now 256x256.
- Clean games schema for active metadata only.
- Removed active use of sort_name, release_date, categories, detailed_description, achievement_status.
- Added developer, publisher, year, completed, finished, esrb, pegi, clearlogo_url.
- Added fanart total 5 slots including main:
  fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url.
- Empty valid no-data fields are stored as N/A.
- Temporary provider errors are not treated as N/A when possible.
- Full Steam appdetails URL is used, not the old filtered appdetails call.
- Steam clearlogo logo.png is used before SteamGridDB logos.
- SteamGridDB is only auto fallback for poster/clearlogo.
- SteamGridDB heroes are not used automatically for fanart.
- Manual Select artwork fetches candidates live and writes directly to the active URL column.
- Select artwork includes Steam assets and SteamGridDB candidates.

v0.3.8:
- Replaced Kodi settings.xml with legacy syntax because the current Kodi/AF3 settings dialog was hiding new-format edit/string controls.
- Steam Account category should now show directly in Add-on settings.
- Added Steam Account Settings inside Tools as fallback.


v0.3.9:
- Auto fanart uses Steam screenshots 1-5 only.
- Auto fanart no longer uses Steam background_raw or Steam background.
- Manual fanart picker includes Steam background_raw first, then Steam screenshots, then SteamGridDB heroes.
- Steam background is excluded completely.
- Collection hide uses collection_id instead of name.
- All Games always uses all Steam collection AppIDs; hiding a folder no longer removes everything from All Games.
- Added Reset collection visibility in Tools and recovery context menu.


v0.3.10:
- Added Tools > Rebuild screenshot fanarts only.
- Rebuild updates only fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url.
- Rebuild uses Steam screenshots 1-5 only.
- Rebuild does not touch metadata, poster, thumb, clearlogo, reviews, or achievements.
- If Steam appdetails errors, old fanart URLs are not overwritten.
- Writes diagnostics/screenshot_fanart_report.csv and last_screenshot_fanart_summary.json.


v0.3.11:
- Added Tools > Rebuild missing artwork URLs.
- Rebuilds missing poster_url, thumb_url, clearlogo_url, fanart_url, fanart1_url, fanart2_url, fanart3_url, fanart4_url.
- Missing means empty or N/A.
- Existing filled URLs are skipped and preserved, including manual fanart selections.
- Provider errors never overwrite existing artwork.
- Report: diagnostics/missing_artwork_rebuild_report.csv.


v0.3.12:
- Added Collections setting: All Games excludes hidden collections.
- Default is ON, so All Games follows hidden collection visibility.
- If OFF, All Games includes every Steam collection AppID even when folders are hidden.


v0.3.13:
- Cache artwork URLs now uses LAC-style verified Kodi cache.
- Removed queue-only ControlImage cache method.
- One menu remains: Cache artwork URLs.
- Collects unique active artwork URLs from DB.
- Reads Kodi texture cache using Textures.GetTextures.
- Already cached URLs are skipped.
- Missing URLs are cached through Kodi webserver /image endpoint.
- The /image response stream is read until EOF before counting an item as cached.
- Progress total is pending/missing URLs only, not all URLs.
- Report now includes already_cached, cached, and failed statuses.
- Requires Kodi web server / remote control via HTTP enabled.


v0.3.14:
- Fixed Kodi /image endpoint URL format.
- v0.3.13 incorrectly called /image/<encoded raw https URL>, which made Kodi return 404 for every artwork URL.
- Now it matches LAC: raw URL -> image://encoded-url/ -> URL-encode that image:// string for /image/.
- Texture cache comparison now unquotes Kodi Textures.GetTextures URLs back to raw DB URLs, so already-cached items can be skipped correctly.


v0.3.15:
- Cleaned collection context menu: kept Rename collection, Hide this collection, Steam Library Tools.
- Removed reset collection name, choose visible collections, show all collections, and addon settings from addon context menus.
- Cleaned Tools menu: kept Refresh all metadata, Scrape missing metadata, Cache artwork URLs, Steam Account Settings, View status, Export diagnostics ZIP.
- Removed rebuild-only tools, reset visibility, and Kodi settings from Tools.
- Added hidden_games table. Hiding a collection also writes its games to hidden_games.
- Hidden games are treated as inactive: skipped from listing, All Games, metadata refresh, missing scrape, artwork cache, and artwork rebuild flows.
- Diagnostics export now auto-deletes older diagnostic ZIPs first.
- Diagnostics ZIP root contains only steam_library.db and settings.json; other files are placed under diagnostics/.
- Export diagnostics now shows notification only, no OK popup.


v0.3.16:
- Added Tools > Clean Steam artwork cache.
  It prunes matching Steam Library artwork from Kodi Textures DB and Thumbnails.
  It targets URLs from steam_library.db plus prior artwork cache/rebuild reports.
- Added Tools > Reset Steam Library database.
  It resets games/collections metadata while preserving hidden_games.
- Hidden games remain skipped after DB reset.
- Reset DB clears stale CSV reports and last_*_summary.json files.


v0.3.17:
- Removed bundled addon fanart image from the ZIP.
- Addon icon remains included.


v0.3.18:
- Fixed Clean Steam artwork cache on Kodi texture DB schemas without idtexture.
- Cleaner now introspects the texture table schema and deletes matched rows by rowid.
- Dependent tables are cleaned only when a matching texture id column exists.
- prune_artwork_cache_report.csv now records texture_id, rowid, and detected id_column.


v0.3.19:
- Changed hidden_games behavior.
- Hide this collection now hides only the collection folder; it no longer inserts every game from that folder into hidden_games.
- hidden_games is rebuilt only from Steam's real Hidden/Hidden Games collection.
- Old bad hidden_games rows from earlier versions are cleaned automatically on collection sync.
- Steam Hidden/Hidden Games collection is automatically hidden from root and its games are skipped from listing, scraping, and cache.
- Reset database no longer preserves stale hidden_games; it rebuilds hidden_games from Steam cloud collections.


v0.3.20:
- Fixed Steam Store 403 on Refresh all metadata.
- Steam Store requests now use browser-like headers plus mature-content cookies.
- appdetails request failure no longer leaves the DB empty: the addon saves a partial title row from OwnedGames/appmanifest/community and can retry later.
- Hidden games behavior from v0.3.19 is preserved: only Steam's real Hidden/Hidden Games collection fills hidden_games.


v0.3.21:
- Fixed Cache artwork URLs 404 failure.
- v0.3.20 still called Kodi /image with encoded raw https:// URL.
- Now it really matches LAC: raw URL -> image://encoded-url/ -> encode the whole image:// value for /image.
- artwork_cache_report.csv now includes endpoint for easier cache debugging.


v0.3.22:
- Steam game listing now uses Kodi content type "movies" while keeping game launch actions.
- Forces AF3 view mode 502 after opening a game folder.
- Game list items expose mediatype=movie plus poster, fanart, clearlogo, tagline, plotoutline, mpaa, studio, genre, and year.
- Added steam_meta_line property for future AF3 skin patching.
- Poster art is now the primary thumb/icon fallback to make the shelf more movie-poster-like.


v0.3.23:
- Movie poster view polish.
- Removed IsPlayable from game list items so AF3 should stop showing fake video "Ends at" furniture.
- Kept click-to-launch plugin URL behavior.
- Plot is now clean short_description only.
- Added steam_detail_line property: DEV ... • PUB ... • ACH ...
- studio info is filled with steam_detail_line for skins that expose studio/details.
- Removed Addon settings from game context menu.


v0.3.24:
- Keeps AF3 poster/movie row trick, but stops marking game items as true movie DBTYPE.
- Removed mediatype=movie and mpaa from ListItem video info.
- Shortened age rating in STEAM meta line to avoid "Rati..." truncation.
- Added steam_no_video_furniture property for future AF3 XML patch.


v0.3.25:
- Added Steam star-rating mapping from review percent for AF3 top row stars.
- Stopped using video tagline for Steam summary so AF3 can show genres above plot.
- Added developer_display, publisher_display, achievement_display, and age_rating_display properties for AF3 skin patch.


v0.3.26:
- Fixed missing AF3 Steam top layout by setting ListItem.Property(platform)=steam.
- AF3 Steam/AKL metadata blocks use Property(platform) as their visibility condition.
- Added is_steam_library, steam_platform, completed_bool, and finished_bool aliases for skin conditions.


v0.3.27:
- Added Tools > AF3 Steam layout patch.
- The addon now patches active Arctic Fuse 3 Includes_Info.xml directly and safely instead of requiring manual skin ZIP overwrite.
- The patcher creates Includes_Info.xml.steamlib.bak once and supports restore.
- AF3 Steam icon paths are written directly to KPM shared-icons; no icons are copied into the active skin.
- Developer and publisher display now uses the first studio only. Example: "RGG / XBOX / XXX" -> "RGG".


v0.3.28:
- Fixed AF3 patcher for Includes_Info.xml files that have no old "AKL Steam Badge" marker.
- The patcher now inserts the Steam summary row before the generic Star Rating block when the old marker is missing.
- Added Steam-specific plot block: Genre row + plot below.
- Generic movie/video plot and generic star row are hidden for Steam platform items.


v0.3.29:
- Fixed current AF3 view where Info_Line and Info_Meta are not visible.
- Steam summary row and dev/pub/achievement icons are now drawn directly inside the Steam Game Plot block.
- Steam Game Plot now contains: STEAM row, genre, two-line plot, and dev/pub/achievement row.

v0.3.32:
- Fixes AF3 duplicate Steam plot by disabling Info_Plot_Other for Steam platform items.
- Adds Steam platform guards to TV/video plot branches so only the Steam two-line plot renderer is active.

v0.3.31:
- Fixed AF3 Steam plot overlap by removing the DEV/PUB/ACH text row from the Steam plot block.
- Steam plot is now clipped to a fixed two-line label under the genre row.
- Developer, publisher, and achievements now stay in AF3 Info_Meta using the bundled icon row so their position matches movie metadata.

v0.3.30:
- Fixed AF3 Steam top summary row placement: STEAM now replaces the fallback info pill in the original Info_Line row.
- Removed the duplicate Steam summary row from Steam Game Plot. The plot area now contains genre, plot, and DEV/PUB/ACH only.
- Replaced the invalid Info_Meta_Object_ColorIcon include with AF3's Info_Meta_Object.
- Added explicit DEV / PUB / ACH text fallback in the Steam plot area so the row is not blank when metadata exists.


0.3.35
- Fast library listing: list containers from local SQLite cache only by default.
- Loading popup while opening library is now optional and off by default.
- AF3 ratings row Steam percent suffix is now compact (95%).


v0.3.41
- Added Hub card artwork setting (Fanart / Thumb). Thumb mode maps ListItem.Art(landscape) to Steam thumb/header while keeping ListItem.Art(fanart) for the focused background.

# -*- coding: utf-8 -*-
import xbmc
import xbmcaddon
import xbmcgui

ADDON_ID = "plugin.program.steam.library"


def run_service():
    addon = xbmcaddon.Addon(ADDON_ID)
    monitor = xbmc.Monitor()
    try:
        def setting_bool(key, default=False):
            value = addon.getSetting(key)
            return default if value == "" else str(value).lower() == "true"

        if setting_bool("auto_sync_library_on_startup", True):
            # Current fresh-install contract: wait for MediaHub readiness,
            # then use one fixed second of grace. No stored setting from an
            # older package can alter this startup path.
            home = xbmcgui.Window(10000)
            waited = 0.0
            while waited < 10.0 and not monitor.abortRequested():
                ready = home.getProperty("MediaHub.Widget.SessionOrderReady.0137") == "true"
                if ready:
                    break
                if monitor.waitForAbort(0.25):
                    return
                waited += 0.25
            if not monitor.waitForAbort(1.0):
                xbmc.executebuiltin(
                    "RunPlugin(plugin://{}/?mode=background_sync&automatic=true)".format(
                        ADDON_ID
                    )
                )
    finally:
        # Explicitly release the Python/SWIG wrappers when the startup service
        # invocation ends.
        del monitor
        del addon


if __name__ == "__main__":
    run_service()

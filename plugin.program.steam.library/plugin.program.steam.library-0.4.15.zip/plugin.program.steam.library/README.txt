Steam Library 0.4.14

- Fresh-install baseline only.
- Startup waits for MediaHub readiness, then exactly one second.
- No old delay setting, setting migration, schema migration, or legacy file conversion.
- Automatic no-change checks do not write steam_library.db.
- Manual scans and explicit maintenance actions remain available.

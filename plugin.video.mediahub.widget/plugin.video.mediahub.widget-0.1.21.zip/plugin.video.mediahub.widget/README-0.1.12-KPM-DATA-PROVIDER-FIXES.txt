MediaHub Widget 0.1.12

- Adds missing fmt_percent() used by game KPM properties.
- safe_set_info() removes runtime from ListItem.setInfo(video, ...) to avoid Kodi 22 NEWADDON Unknown Video Info Key runtime spam. Runtime is kept as properties and InfoTagVideo duration when available.
- MediaHub remains data provider; KPM owns visual/XML integration.

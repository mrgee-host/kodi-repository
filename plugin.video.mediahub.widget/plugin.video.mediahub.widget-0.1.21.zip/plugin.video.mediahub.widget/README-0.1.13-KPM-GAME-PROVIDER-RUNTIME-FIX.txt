MediaHub Widget 0.1.13

- Fixes runtime Games read crash by restoring truthy().
- Uses the same bool parser for completed/finished and completed_bool/finished_bool.
- Keeps runtime out of ListItem.setInfo(video) and stores it as properties/video tag duration instead.
- Continues exposing KPM game props: platform, kpm_item_type, steam_appid, ratings, achievements, developer/publisher, completed/finished.

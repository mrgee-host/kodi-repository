MediaHub 0.1.15: active-only, excludes Steam/manual hidden, compact playtime, preserves KPM game properties.

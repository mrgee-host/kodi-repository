MediaHub Widget 0.1.18

- Reads steam_name, display_name and sortname when available.
- Uses display_name as the visible title.
- Orders games by sortname, then display_name, name, steam_name.
- Keeps active/hidden filtering and KPM game property parity.

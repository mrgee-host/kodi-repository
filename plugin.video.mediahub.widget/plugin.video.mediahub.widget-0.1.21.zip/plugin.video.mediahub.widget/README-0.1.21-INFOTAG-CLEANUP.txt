MediaHub Widget 0.1.21
===========================

Kodi 22 API migration:
- Replaces ListItem.setInfo("video", ...) with InfoTagVideo setters.
- Uses InfoTagVideo.setResumePoint when resume data is supplied.
- Keeps runtime/duration custom properties for existing AF3 skin XML.
- Creates plugin ListItems with offscreen=True.
- Removes the module-scope xbmcaddon.Addon wrapper.

Metadata covered:
title, original title, sort title, plot, outline, tagline, year, genres,
studios, directors, writers, rating, user rating, play count, MPAA,
premiered, date added, last played, episode, season, duration, media type,
database id, and resume point.

No visual properties, KPM game properties, artwork filtering, sorting,
screensaver aliases, or playtime icon behavior were removed.

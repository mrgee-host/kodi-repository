MediaHub 0.1.14 reads only active Steam membership when the table exists and forwards playtime_forever/playtime_display to KPM.

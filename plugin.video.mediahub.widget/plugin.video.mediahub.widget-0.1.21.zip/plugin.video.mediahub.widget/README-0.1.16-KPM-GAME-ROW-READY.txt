MediaHub Widget 0.1.16

- Publishes kpm_game_row_ready=true only after all game properties are assembled.
- Declares the provider order schema: steam, metacritic, achievement, playtime.
- Continues to forward playtime_forever and compact playtime_display.
- Visual order remains owned by KPM.

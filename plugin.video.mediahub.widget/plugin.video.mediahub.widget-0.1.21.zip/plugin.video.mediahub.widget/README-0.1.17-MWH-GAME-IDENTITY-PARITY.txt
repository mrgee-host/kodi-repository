MediaHub Widget 0.1.17

- Forces an explicit game identity through kpm_item_type/mediahub_type/DBTYPE while
  retaining Kodi movie mediatype compatibility for AF3 furniture.
- Exposes a complete canonical game-row snapshot in the order:
  Steam -> Metacritic -> Achievement -> Playtime.
- Steam display now includes Steam250 rank when available, matching Steam Library.
- KPM remains the only lower-row renderer; MediaHub is data provider only.

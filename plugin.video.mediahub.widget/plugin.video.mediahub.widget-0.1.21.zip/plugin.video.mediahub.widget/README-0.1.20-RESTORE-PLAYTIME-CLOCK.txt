MediaHub Widget 0.1.20 - Restore lifetime playtime clock icon

Base: clean 0.1.18.

- Lifetime playtime publishes source steam_playtime with IconFile ends.png.
- Library, Home, Hub, and screensaver can use the same clock artwork.
- Corrective upgrade for the mistaken 0.1.19 dedicated-icon change.

MediaHub Widget 0.1.11 clean data provider

Role: widget/list provider with neutral game/artwork properties. KPM renders visual rows. No LRS RatingSlot bridge contract.

MediaHub Widget 0.1.30

Each prepared screensaver item now carries its own CropV2 path and rating slots.
The overlay no longer depends on a polling race between MWH and LRS.

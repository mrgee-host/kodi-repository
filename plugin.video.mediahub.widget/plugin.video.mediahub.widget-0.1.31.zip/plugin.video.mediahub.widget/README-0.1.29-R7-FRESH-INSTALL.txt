MediaHub Widget 0.1.29 - R7 Fresh-Install Baseline

- Creates its current runtime folders directly; no old-folder mover runs.
- Keeps current prepared screensaver cache, one slide per item, random cached
  fanart selection, stable mediahub_item_key handling, and diagnostics.
- Uses the new MediaHub Widget icon supplied for the MrGee family.

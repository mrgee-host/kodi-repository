MediaHub Widget 0.1.29
======================

Fresh-install Movies, TV Shows, and Steam mixed-content provider for the Mr.Gee Kodi Family.

- Creates current runtime/cache paths directly.
- Keeps prepared screensaver cache, current property aliases, and notification-safe output.
- Does not move historical runtime folders.
- KPM remains the Arctic Fuse 3 visual integration owner.

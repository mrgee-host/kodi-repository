MediaHub Widget 0.1.32

- Removes the R10 LRS display-contract consumer.
- Removes per-slide movie/series rating and CropV2 output properties.
- Keeps stable mediahub_item_key and existing game RatingSlotN properties.
- Keeps prepared cached fanart, one random fanart per item, 1080p filtering,
  actual CropV2 readiness filtering, atomic cache writes and diagnostics.
- LRS again owns all live movie/series rating selection, icons and CropV2.

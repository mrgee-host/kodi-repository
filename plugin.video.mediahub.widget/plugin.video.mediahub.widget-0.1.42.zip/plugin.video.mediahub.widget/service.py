# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import time

import xbmc
import xbmcgui

from addon import (
    _catalog_is_usable_0135,
    _catalog_needs_refresh_0135,
    _catalog_read_metadata_0135,
    _catalog_source_signatures_0135,
    catalog_delete_single_0135,
    catalog_refresh_episode_parent_0135,
    catalog_refresh_single_0135,
    log,
    refresh_master_catalog,
    refresh_resolver_catalog_incremental_0137,
    refresh_steam_catalog_incremental_0135,
    shuffle_catalog_orders_0135,
    steam_db_path,
)


class Monitor(xbmc.Monitor):
    def __init__(self):
        super().__init__()
        self.video_full_refresh_due = 0.0
        self.last_steam_signature = ''

    def onNotification(self, sender, method, data):
        method = str(method or '')
        try:
            payload = json.loads(data or '{}') if isinstance(data, str) else (data or {})
        except Exception:
            payload = {}
        if method in ('VideoLibrary.OnScanFinished', 'VideoLibrary.OnCleanFinished'):
            self.video_full_refresh_due = time.time() + 2.0
            return
        if method not in ('VideoLibrary.OnUpdate', 'VideoLibrary.OnRemove'):
            return
        item = payload.get('item') or {}
        media_type = str(item.get('type') or '').lower()
        source_id = str(item.get('id') or '').strip()
        if media_type in ('movie', 'tvshow') and source_id:
            if method == 'VideoLibrary.OnRemove':
                catalog_delete_single_0135(media_type, source_id)
            else:
                catalog_refresh_single_0135(media_type, source_id, reason=method)
        elif media_type == 'episode' and source_id:
            catalog_refresh_episode_parent_0135(source_id, reason=method)


def _library_busy():
    try:
        return bool(
            xbmc.getCondVisibility('Library.IsScanningVideo')
            or xbmc.getCondVisibility('Library.IsScanningMusic')
        )
    except Exception:
        return False


def _file_signature(path):
    import os
    try:
        st = os.stat(path)
        return '{}:{}'.format(int(st.st_mtime_ns), int(st.st_size))
    except Exception:
        return ''


if __name__ == '__main__':
    monitor = Monitor()
    log('Persistent master catalog service started', xbmc.LOGINFO)
    next_signature_check = 0.0
    next_shuffle_retry = 0.0
    home = xbmcgui.Window(10000)
    session_shuffle_property = 'MediaHub.Widget.SessionOrderReady.0139'
    session_state_property = 'MediaHub.Widget.SessionOrderState.0139'
    home.clearProperty(session_shuffle_property)
    home.setProperty(session_state_property, 'pending')
    session_id = '{}-{}'.format(os.getpid(), int(time.time() * 1000))
    while not monitor.abortRequested():
        now = time.time()
        try:
            idle = not xbmc.getCondVisibility('Player.HasMedia') and not _library_busy()

            # Randomize the already-valid catalog first. Widgets that start
            # loading immediately therefore receive this session's order. A
            # later replacement build preserves those same ranks.
            if idle and home.getProperty(session_shuffle_property) != 'true' and now >= next_shuffle_retry:
                if _catalog_is_usable_0135():
                    if shuffle_catalog_orders_0135(session_id=session_id, notify_user=False):
                        home.setProperty(session_shuffle_property, 'true')
                        home.setProperty(session_state_property, 'ready')
                    else:
                        home.setProperty(session_state_property, 'retrying')
                        next_shuffle_retry = now + 2.0
                else:
                    result = refresh_master_catalog(
                        force=True,
                        reason='startup_missing_catalog',
                        randomize_orders=True,
                        shuffle_session_id=session_id,
                    )
                    if result.get('status') == 'rebuilt' and result.get('shuffle_applied'):
                        home.setProperty(session_shuffle_property, 'true')
                        home.setProperty(session_state_property, 'ready')
                    else:
                        home.setProperty(session_state_property, 'retrying')
                        next_shuffle_retry = now + 2.0

            # Rebuild only when a semantic source/settings signature changed.
            # Existing catalog remains readable, and current-session ranks are
            # preserved in the replacement DB.
            if idle and _catalog_is_usable_0135() and _catalog_needs_refresh_0135():
                refresh_master_catalog(force=True, reason='startup_or_signature_change')

            if idle and monitor.video_full_refresh_due and now >= monitor.video_full_refresh_due:
                monitor.video_full_refresh_due = 0.0
                refresh_master_catalog(force=False, reason='video_library_notification')

            if now >= next_signature_check:
                next_signature_check = now + 60.0
                signatures = _catalog_source_signatures_0135()
                metadata = _catalog_read_metadata_0135()
                sig = signatures.get('steam', '')
                if idle and sig != metadata.get('signature_steam', ''):
                    refresh_steam_catalog_incremental_0135(reason='steam_content_changed')
                resolver_sig = signatures.get('resolver', '')
                if idle and resolver_sig != metadata.get('signature_resolver', ''):
                    refresh_resolver_catalog_incremental_0137(reason='resolver_content_changed')
                monitor.last_steam_signature = sig
        except Exception as exc:
            log('Persistent master catalog service failed: {}'.format(exc), xbmc.LOGWARNING)
        if monitor.waitForAbort(1.0):
            break

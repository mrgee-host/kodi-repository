0.1.42: Games use Steam Library as the artwork owner. MWH keeps fast direct-DB metadata, reads fanart from Steam ListItem Art, preserves all validated game candidates in the persistent master catalog, and republishes them as native Art(fanartN). Movies/Series are unchanged.

MediaHub Widget 0.1.29
======================

Fresh-install Movies, TV Shows, and Steam mixed-content provider for the Mr.Gee Kodi Family.

- Creates current runtime/cache paths directly.
- Keeps prepared screensaver cache, current property aliases, and notification-safe output.
- Does not move historical runtime folders.
- KPM remains the Arctic Fuse 3 visual integration owner.

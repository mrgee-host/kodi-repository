MediaHub Widget 0.1.34

This release aligns the MWH slide list with the LRS 1.6.6 and KPM 0.2.27 atomic screensaver metadata bundle.
Every prepared slide must have a stable mediahub_item_key. Old cache contract v4 is rejected and rebuilt as contract v5.
The live rating and CropV2 source remains LRS. MWH still owns slide selection, fanart, plot, identity, and Steam game slots.

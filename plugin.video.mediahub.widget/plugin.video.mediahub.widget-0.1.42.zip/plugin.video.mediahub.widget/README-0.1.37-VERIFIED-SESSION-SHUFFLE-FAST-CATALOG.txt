MediaHub Widget 0.1.37
==========================

Verified session shuffle
- Existing valid catalog is shuffled before startup widgets read it.
- The session-ready property is set only after SQLite commits and the before/after hashes differ.
- A failed or locked shuffle is retried instead of being logged as success.
- Order remains stable during the Kodi session and is reshuffled at the next Kodi launch.

Fast catalog maintenance
- Steam changes use a semantic content signature, not database mtime.
- CropV2 resolver changes use a semantic mapping signature, ignoring bookkeeping timestamps.
- Resolver changes update screensaver membership incrementally.
- No-change VideoLibrary.OnScanFinished events do not force a full rebuild.
- Full rebuilds batch Textures DB and CropV2 lookups, batch SQLite inserts, validate with quick_check, then atomically replace the live database.

The previous mediahub-master.db remains usable. Do not delete it during installation.

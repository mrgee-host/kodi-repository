MediaHub Widget 0.1.35

- One persistent master SQLite catalog serves all widget types and Spotlight slideshows.
- Spotlight remains a slideshow of the full widget list; it is not reduced to one item.
- Stable random order is retained across Kodi restarts and skin reloads.
- Old catalog stays active while a new catalog is built and validated.
- Screensaver reads the same catalog and prefetches local fanart.

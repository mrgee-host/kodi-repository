MediaHub Widget 0.1.36

- The master SQLite catalog remains persistent.
- Every complete list is shuffled once per Kodi process, not on every widget call.
- ReloadSkin, playback return, hub navigation, Spotlight slideshow, and screensaver reuse the same order for the active session.
- Final ListItems alternate mediahub_bundle_slot A/B for safe 400 ms metadata crossfades.

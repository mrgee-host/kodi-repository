# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import random as random_mod
import re
import sqlite3
import sys
import traceback
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and str(sys.argv[1]).lstrip("-").isdigit() else -1

STEAM_DEFAULT_ADDON_ID = "plugin.program.steam.library"


# -----------------------------------------------------------------------------
# Small Kodi-safe helpers
# -----------------------------------------------------------------------------

def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[{}] {}".format(ADDON_NAME, msg), level)
    except Exception:
        pass


def tr(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        try:
            return xbmc.translatePath(path)
        except Exception:
            return path


def setting(key, default=""):
    try:
        value = ADDON.getSetting(key)
        return value if value != "" else default
    except Exception:
        return default


def setting_bool(key, default=False):
    value = str(setting(key, "")).strip().lower()
    if value == "":
        return bool(default)
    return value in ("1", "true", "yes", "on")


def setting_int(key, default=0):
    try:
        return int(setting(key, str(default)))
    except Exception:
        return int(default)


def clean_text(value):
    if value is None:
        return ""
    text = str(value)
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
    return text.strip()


def as_bool(value, default=False):
    if value is None or str(value).strip() == "":
        return default
    return str(value).strip().lower() in ("1", "true", "yes", "on", "random")


def as_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def url_for(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def parse_params():
    try:
        raw = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
        return dict(urllib.parse.parse_qsl(raw))
    except Exception:
        return {}


def set_item_path(li, path):
    try:
        li.setPath(path)
    except Exception:
        pass


def safe_set_info(li, info):
    try:
        li.setInfo("video", info)
    except Exception as exc:
        log("setInfo failed for {}: {}".format(info.get("title", "?"), exc), xbmc.LOGDEBUG)


def safe_set_art(li, art):
    clean = {k: v for k, v in (art or {}).items() if v and str(v).strip()}
    if not clean:
        return
    try:
        li.setArt(clean)
    except Exception as exc:
        log("setArt failed: {}".format(exc), xbmc.LOGDEBUG)


def notify(message):
    try:
        xbmcgui.Dialog().notification(ADDON_NAME, message, xbmcgui.NOTIFICATION_INFO, 2500)
    except Exception:
        pass


# -----------------------------------------------------------------------------
# JSON-RPC video library readers
# -----------------------------------------------------------------------------

def jsonrpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    data = json.loads(raw or "{}")
    if data.get("error"):
        raise RuntimeError("{}: {}".format(method, data["error"]))
    return data.get("result") or {}


def pick_art(raw, media_type="movie"):
    art = raw.get("art") if isinstance(raw, dict) else {}
    if not isinstance(art, dict):
        art = {}

    poster = art.get("poster") or art.get("tvshow.poster") or raw.get("thumbnail") or ""
    thumb = art.get("thumb") or raw.get("thumbnail") or poster
    fanart = art.get("fanart") or art.get("tvshow.fanart") or raw.get("fanart") or ""
    landscape = art.get("landscape") or art.get("tvshow.landscape") or fanart or thumb
    clearlogo = art.get("clearlogo") or art.get("tvshow.clearlogo") or ""
    banner = art.get("banner") or art.get("tvshow.banner") or ""

    return {
        "poster": poster,
        "thumb": thumb,
        "icon": thumb or poster,
        "fanart": fanart,
        "landscape": landscape,
        "clearlogo": clearlogo,
        "banner": banner,
    }


def first_number(value, default=0):
    try:
        if isinstance(value, (int, float)):
            return value
        text = str(value or "").strip()
        return float(text) if text else default
    except Exception:
        return default


def genre_text(value):
    if isinstance(value, list):
        return " / ".join([str(x) for x in value if str(x).strip()])
    return str(value or "")


def library_movies():
    props = [
        "title", "originaltitle", "sorttitle", "year", "genre", "plot", "plotoutline",
        "tagline", "rating", "userrating", "playcount", "runtime", "studio", "director",
        "writer", "mpaa", "premiered", "dateadded", "lastplayed", "thumbnail", "fanart", "art",
    ]
    fallback_props = ["title", "year", "genre", "plot", "rating", "thumbnail", "fanart", "art"]
    params = {
        "properties": props,
        "sort": {"method": "title", "order": "ascending", "ignorearticle": True},
        "limits": {"start": 0, "end": 100000},
    }
    try:
        result = jsonrpc("VideoLibrary.GetMovies", params)
    except Exception:
        params["properties"] = fallback_props
        result = jsonrpc("VideoLibrary.GetMovies", params)

    items = []
    for m in result.get("movies", []) or []:
        movieid = m.get("movieid")
        title = m.get("title") or "Movie {}".format(movieid)
        plot = clean_text(m.get("plot") or m.get("plotoutline") or "")
        year = as_int(m.get("year"), 0)
        art = pick_art(m, "movie")
        url = url_for(mode="play_movie", movieid=movieid)
        items.append({
            "kind": "movie",
            "label": title,
            "url": url,
            "is_folder": False,
            "art": art,
            "info": {
                "mediatype": "movie",
                "dbid": int(movieid) if str(movieid).isdigit() else 0,
                "title": title,
                "originaltitle": m.get("originaltitle") or title,
                "sorttitle": m.get("sorttitle") or title,
                "plot": plot,
                "plotoutline": clean_text(m.get("plotoutline") or plot),
                "tagline": clean_text(m.get("tagline") or ""),
                "year": year,
                "genre": genre_text(m.get("genre")),
                "rating": first_number(m.get("rating"), 0),
                "userrating": as_int(m.get("userrating"), 0),
                "playcount": as_int(m.get("playcount"), 0),
                "runtime": as_int(m.get("runtime"), 0),
                "studio": genre_text(m.get("studio")),
                "mpaa": m.get("mpaa") or "",
                "premiered": m.get("premiered") or "",
                "dateadded": m.get("dateadded") or "",
                "lastplayed": m.get("lastplayed") or "",
            },
            "props": {
                "mediahub_type": "movie",
                "dbid": str(movieid or ""),
                "source": "Kodi Movies",
                "IsPlayable": "true",
            },
        })
    return items


def library_series():
    props = [
        "title", "year", "genre", "plot", "rating", "userrating", "playcount", "studio",
        "mpaa", "premiered", "dateadded", "lastplayed", "thumbnail", "fanart", "art",
        "episode", "season",
    ]
    fallback_props = ["title", "year", "genre", "plot", "rating", "thumbnail", "fanart", "art"]
    params = {
        "properties": props,
        "sort": {"method": "title", "order": "ascending", "ignorearticle": True},
        "limits": {"start": 0, "end": 100000},
    }
    try:
        result = jsonrpc("VideoLibrary.GetTVShows", params)
    except Exception:
        params["properties"] = fallback_props
        result = jsonrpc("VideoLibrary.GetTVShows", params)

    items = []
    for s in result.get("tvshows", []) or []:
        tvshowid = s.get("tvshowid")
        title = s.get("title") or "Series {}".format(tvshowid)
        plot = clean_text(s.get("plot") or "")
        year = as_int(s.get("year"), 0)
        art = pick_art(s, "tvshow")
        url = url_for(mode="open_series", tvshowid=tvshowid)
        episode = as_int(s.get("episode"), 0)
        season = as_int(s.get("season"), 0)
        items.append({
            "kind": "series",
            "label": title,
            "url": url,
            "is_folder": False,
            "art": art,
            "info": {
                "mediatype": "tvshow",
                "dbid": int(tvshowid) if str(tvshowid).isdigit() else 0,
                "title": title,
                "sorttitle": title,
                "plot": plot,
                "plotoutline": plot,
                "year": year,
                "genre": genre_text(s.get("genre")),
                "rating": first_number(s.get("rating"), 0),
                "userrating": as_int(s.get("userrating"), 0),
                "playcount": as_int(s.get("playcount"), 0),
                "studio": genre_text(s.get("studio")),
                "mpaa": s.get("mpaa") or "",
                "premiered": s.get("premiered") or "",
                "dateadded": s.get("dateadded") or "",
                "lastplayed": s.get("lastplayed") or "",
                "episode": episode,
                "season": season,
            },
            "props": {
                "mediahub_type": "series",
                "dbid": str(tvshowid or ""),
                "source": "Kodi TV Shows",
                "episode_count": str(episode),
                "season_count": str(season),
                "IsPlayable": "false",
            },
        })
    return items


# -----------------------------------------------------------------------------
# Steam Library reader
# -----------------------------------------------------------------------------

def steam_db_path():
    custom = setting("steam_db_path", "").strip()
    if custom:
        return tr(custom)
    steam_addon_id = setting("steam_addon_id", STEAM_DEFAULT_ADDON_ID).strip() or STEAM_DEFAULT_ADDON_ID
    return tr("special://profile/addon_data/{}/steam_library.db".format(steam_addon_id))


def steam_addon_id():
    return setting("steam_addon_id", STEAM_DEFAULT_ADDON_ID).strip() or STEAM_DEFAULT_ADDON_ID


def db_col_exists(cols, name):
    return name in cols




def game_lrs_props(g, appid, steam_score, mc_score):
    """Expose game ratings as stable ListItem properties for LRS/skin bridges.

    Kodi has no native game media type in the video library path, so the item is
    still emitted as a playable video-plugin item. These properties are the clean
    contract that lets script.library.ratings.scraper detect a game and publish
    Steam/Metacritic/Achievement slots without scraping it as a movie.
    """
    ach_unlocked = as_int(g.get("achievement_unlocked"), 0)
    ach_total = as_int(g.get("achievement_total"), 0)
    completed = as_bool(g.get("completed"), False)
    finished = as_bool(g.get("finished"), False)

    steam_label = "{}%".format(steam_score) if steam_score else ""
    mc_label = str(mc_score) if mc_score else ""
    ach_label = "{}/{}".format(ach_unlocked, ach_total) if ach_total else ""

    props = {
        # hard game markers
        "lrs_game": "true",
        "lrs_item_type": "game",
        "lrs_media_type": "game",
        "lrs_skip_scrape": "true",
        "library_ratings_type": "game",
        "DBTYPE": "game",
        "dbtype": "game",
        "MediaType": "game",
        "mediatype": "game",

        # source identifiers
        "game_platform": "steam",
        "lrs_game_platform": "steam",
        "lrs_game_appid": str(appid or ""),
        "lrs_game_source_addon": steam_addon_id(),

        # normalized rating values
        "lrs_steam_score": str(steam_score or ""),
        "lrs_steam_percent": str(steam_score or ""),
        "lrs_steam_label": steam_label,
        "lrs_steam_desc": str(g.get("steam_review_desc") or ""),
        "lrs_steam_total": str(g.get("steam_review_total") or ""),
        "lrs_steam250_rank": str(g.get("steam250_rank") or ""),
        "lrs_steam250_score": str(g.get("steam250_score") or ""),
        "lrs_top250_rank": str(g.get("steam250_rank") or ""),
        "lrs_top250_label": steam250_rank_display(g),
        "lrs_top250_icon": "top250.png",
        "lrs_metacritic_score": str(mc_score or ""),
        "lrs_metacritic_label": mc_label,
        "lrs_achievement_unlocked": str(ach_unlocked if ach_total else ""),
        "lrs_achievement_total": str(ach_total or ""),
        "lrs_achievement_label": ach_label,
        "lrs_completed": "true" if completed else "false",
        "lrs_finished": "true" if finished else "false",

        # icon contract for LRS/skin. The actual png files live in LRS/skin media.
        "lrs_steam_icon": "steam.png",
        "lrs_metacritic_icon": "metacritic.png",
        "lrs_top250_icon": "top250.png",
        "lrs_achievement_icon": "steam-ach.png",
    }

    # Prebuilt generic slots. LRS can copy these directly to
    # LibraryRatings.Screensaver.RatingSlotN_* when it detects lrs_game=true.
    slots = []
    if steam_score:
        slots.append({
            "Source": "steam",
            "Icon": "steam",
            "IconFile": "steam.png",
            "Label": steam_label,
            "Value": str(steam_score),
        })
    if mc_score:
        slots.append({
            "Source": "metacritic",
            "Icon": "metacritic",
            "IconFile": "metacritic.png",
            "Label": mc_label,
            "Value": str(mc_score),
        })
    top250_label = steam250_rank_display(g)
    if top250_label:
        slots.append({
            "Source": "top250",
            "Icon": "top250",
            "IconFile": "top250.png",
            "Label": top250_label,
            "Value": str(g.get("steam250_rank") or "").lstrip("#"),
        })
    if ach_label:
        slots.append({
            "Source": "steam-achievement",
            "Icon": "steam-ach",
            "IconFile": "steam-ach.png",
            "Label": ach_label,
            "Value": ach_label,
        })

    props["lrs_game_slot_count"] = str(len(slots))
    props["lrs_game_has_ratings"] = "true" if slots else "false"
    for idx, slot in enumerate(slots[:6], 1):
        for key, value in slot.items():
            props["RatingSlot{0}_{1}".format(idx, key)] = value
            props["lrs_RatingSlot{0}_{1}".format(idx, key)] = value
            props["lrs_game_slot{0}_{1}".format(idx, key.lower())] = value

    return props


def steam_display_or_na(value):
    txt = str(value or "").strip()
    return txt if txt and txt.upper() != "N/A" else "N/A"


def first_credit(value):
    text = str(value or "").strip()
    if not text or text.upper() == "N/A":
        return "N/A"
    parts = re.split(r"\s*/\s*|\s*;\s*|\s*,\s*", text)
    for part in parts:
        part = part.strip()
        if part:
            return part
    return text


def steam250_rank_display(g):
    rank = steam_display_or_na(g.get("steam250_rank"))
    if rank == "N/A":
        return ""
    return "#{}".format(str(rank).lstrip("#"))


def steam_achievement_display(g):
    unlocked = steam_display_or_na(g.get("achievement_unlocked"))
    total = steam_display_or_na(g.get("achievement_total"))
    if total != "N/A":
        return "{}/{}".format("0" if unlocked == "N/A" else unlocked, total)
    return "N/A"


def steam_age_rating_display(g):
    esrb = steam_display_or_na(g.get("esrb"))
    pegi = steam_display_or_na(g.get("pegi"))
    if esrb != "N/A":
        return "Rating {}".format(esrb)
    if pegi != "N/A":
        return "PEGI {}".format(pegi)
    return "N/A"

def steam_games():
    path = steam_db_path()
    if not path or not os.path.exists(path):
        log("Steam database not found: {}".format(path), xbmc.LOGWARNING)
        return []

    con = None
    try:
        con = sqlite3.connect(path)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("PRAGMA table_info(games)")
        cols = set([r[1] for r in cur.fetchall()])
        if not cols:
            return []

        select_cols = [
            "appid", "name", "year", "developer", "publisher", "genres", "short_description",
            "steam_review_percent", "steam_review_desc", "steam_review_total", "steam250_rank", "steam250_score", "achievement_unlocked",
            "achievement_total", "completed", "finished", "metacritic_score", "esrb", "pegi",
            "poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url",
            "fanart3_url", "fanart4_url",
        ]
        usable_cols = [c for c in select_cols if db_col_exists(cols, c)]
        sql = "SELECT {} FROM games".format(", ".join(usable_cols))
        args = []

        exclude_hidden = setting_bool("exclude_hidden_games", True)
        if exclude_hidden:
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='hidden_games'")
            if cur.fetchone():
                sql += " WHERE appid NOT IN (SELECT appid FROM hidden_games)"

        sql += " ORDER BY name COLLATE NOCASE"
        rows = cur.execute(sql, args).fetchall()
    except Exception as exc:
        log("Steam DB read failed: {}\n{}".format(exc, traceback.format_exc()), xbmc.LOGERROR)
        return []
    finally:
        try:
            if con:
                con.close()
        except Exception:
            pass

    items = []
    for row in rows:
        g = dict(row)
        appid = str(g.get("appid") or "").strip()
        if not appid:
            continue
        title = clean_text(g.get("name") or "Steam App {}".format(appid))
        plot = clean_text(g.get("short_description") or "")
        poster = g.get("poster_url") or ""
        thumb = g.get("thumb_url") or poster
        fanart = g.get("fanart_url") or g.get("fanart1_url") or thumb
        clearlogo = g.get("clearlogo_url") or ""
        steam_score = as_int(g.get("steam_review_percent"), 0)
        mc_score = as_int(g.get("metacritic_score"), 0)
        rating = round(float(steam_score) / 10.0, 1) if steam_score else 0
        detail_bits = []
        if g.get("developer"):
            detail_bits.append(str(g.get("developer")))
        if g.get("genres"):
            detail_bits.append(str(g.get("genres")))
        if steam_score:
            detail_bits.append("Steam {}%".format(steam_score))
        if mc_score:
            detail_bits.append("Metacritic {}".format(mc_score))
        top250_label = steam250_rank_display(g)
        if top250_label:
            detail_bits.append("Top250 {}".format(top250_label))

        url = url_for(mode="play_game", appid=appid)
        items.append({
            "kind": "game",
            "label": title,
            "url": url,
            "is_folder": False,
            "art": {
                "poster": poster,
                "thumb": thumb,
                "icon": thumb or poster,
                "fanart": fanart,
                "landscape": fanart or thumb,
                "clearlogo": clearlogo,
            },
            "info": {
                "mediatype": "movie",
                "title": title,
                "originaltitle": title,
                "sorttitle": title,
                "plot": plot,
                "plotoutline": plot,
                "year": as_int(g.get("year"), 0),
                "genre": g.get("genres") or "",
                "studio": g.get("developer") or g.get("publisher") or "",
                "rating": rating,
                "tagline": " / ".join(detail_bits),
            },
            "props": dict({
                "mediahub_type": "game",
                "source": "Steam Library",
                "platform": "steam",
                "steam_platform": "steam",
                "steam_appid": appid,
                "appid": appid,
                "developer": str(g.get("developer") or ""),
                "publisher": str(g.get("publisher") or ""),
                "esrb": str(g.get("esrb") or ""),
                "pegi": str(g.get("pegi") or ""),
                "steam_review_percent": str(g.get("steam_review_percent") or ""),
                "steam_review_desc": str(g.get("steam_review_desc") or ""),
                "steam_review_total": str(g.get("steam_review_total") or ""),
                "steam250_rank": str(g.get("steam250_rank") or ""),
                "steam250_score": str(g.get("steam250_score") or ""),
                "metacritic_score": str(g.get("metacritic_score") or ""),
                "achievement_unlocked": str(g.get("achievement_unlocked") or ""),
                "achievement_total": str(g.get("achievement_total") or ""),
                "completed": str(g.get("completed") or ""),
                "finished": str(g.get("finished") or ""),

                # AF3 / Steam Library compatible aliases.
                # Home spotlight/widget skin patches usually read these direct
                # properties, not the generic RatingSlotN_* bridge used by LRS.
                "developer_display": steam_display_or_na(first_credit(g.get("developer"))),
                "publisher_display": steam_display_or_na(first_credit(g.get("publisher"))),
                "achievement_display": steam_achievement_display(g),
                "steam250_rank_display": steam250_rank_display(g) or "N/A",
                "top250_rank_display": steam250_rank_display(g) or "N/A",
                "top250_display": steam250_rank_display(g) or "N/A",
                "age_rating_display": steam_age_rating_display(g),
                "completed_bool": "true" if str(g.get("completed") or "") == "1" else "",
                "finished_bool": "true" if str(g.get("finished") or "") == "1" else "",
                "steam_poster_view": "true",
                "is_steam_library": "true",
                "steam_no_video_furniture": "true",
                "program_plugin": steam_addon_id(),
                "IsPlayable": "true",
            }, **game_lrs_props(g, appid, steam_score, mc_score)),
        })
    return items


# -----------------------------------------------------------------------------
# Directory output
# -----------------------------------------------------------------------------

def limit_and_sort(items, params):
    default_limit = setting_int("default_limit", 100)
    limit = as_int(params.get("limit"), default_limit)
    randomize = as_bool(params.get("random"), setting_bool("default_random", True))
    seed = params.get("seed") or ""

    if randomize:
        rnd = random_mod.Random(seed) if seed else random_mod.Random()
        rnd.shuffle(items)
    else:
        items.sort(key=lambda x: re.sub(r"^(the|a|an)\s+", "", x.get("label", "").lower()))

    if limit > 0:
        items = items[:limit]
    return items


def add_media_item(item, total=0):
    li = xbmcgui.ListItem(label=item.get("label") or "")
    safe_set_info(li, item.get("info") or {})
    safe_set_art(li, item.get("art") or {})

    for k, v in (item.get("props") or {}).items():
        try:
            li.setProperty(str(k), str(v))
        except Exception:
            pass

    kind = item.get("kind") or "media"
    li.setProperty("mediahub_widget", "true")
    li.setProperty("mediahub_kind", kind)
    li.setProperty("source_addon", ADDON_ID)

    if kind == "game":
        # Extra runtime aliases for services that inspect only focused ListItem props.
        li.setProperty("lrs_game", "true")
        li.setProperty("lrs_item_type", "game")
        li.setProperty("library_ratings_type", "game")
        li.setProperty("DBTYPE", "game")
        li.setProperty("dbtype", "game")
        li.setProperty("MediaType", "game")
        li.setProperty("mediatype", "game")

    if kind == "movie":
        li.addContextMenuItems([("Play movie", "RunPlugin({})".format(item.get("url")))])
    elif kind == "series":
        li.addContextMenuItems([("Open series", "RunPlugin({})".format(item.get("url")))])
    elif kind == "game":
        li.addContextMenuItems([("Launch Steam game", "RunPlugin({})".format(item.get("url")))])

    set_item_path(li, item.get("url"))
    xbmcplugin.addDirectoryItem(HANDLE, item.get("url"), li, bool(item.get("is_folder", False)), total)


def add_dir(label, mode, **kwargs):
    params = {"mode": mode}
    params.update(kwargs)
    url = url_for(**params)
    li = xbmcgui.ListItem(label=label)
    li.setProperty("mediahub_widget_folder", "true")
    safe_set_art(li, {"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
    safe_set_info(li, {"title": label, "plot": "MediaHub Widget path: {}".format(url)})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, True)


def root():
    add_dir("All Media: Movies + Series + Games", "mix", limit=setting_int("default_limit", 100), random=str(setting_bool("default_random", True)).lower())
    add_dir("All Media: Random Screensaver Mix", "screensaver_mix", limit=100, random="true")
    add_dir("Movies only", "movies", limit=setting_int("default_limit", 100), random=str(setting_bool("default_random", True)).lower())
    add_dir("Series / TV Shows only", "series", limit=setting_int("default_limit", 100), random=str(setting_bool("default_random", True)).lower())
    add_dir("Steam Games only", "games", limit=setting_int("default_limit", 100), random=str(setting_bool("default_random", True)).lower())
    add_dir("All Media: Unlimited / no limit", "mix", limit=0, random="false")

    li = xbmcgui.ListItem(label="Settings")
    safe_set_art(li, {"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="settings"), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def output_items(items, content="movies", params=None):
    params = params or {}
    items = limit_and_sort(list(items), params)
    try:
        xbmcplugin.setContent(HANDLE, content)
    except Exception:
        pass

    total = len(items)
    for item in items:
        add_media_item(item, total)

    try:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    except Exception:
        pass

    xbmcplugin.endOfDirectory(HANDLE)

    if setting_bool("force_poster_view", False):
        try:
            xbmc.executebuiltin("Container.SetViewMode({})".format(setting_int("poster_view_id", 502)))
        except Exception:
            pass


def mixed_items():
    items = []
    if setting_bool("include_movies", True):
        try:
            items.extend(library_movies())
        except Exception as exc:
            log("Movies read failed: {}".format(exc), xbmc.LOGERROR)
    if setting_bool("include_series", True):
        try:
            items.extend(library_series())
        except Exception as exc:
            log("Series read failed: {}".format(exc), xbmc.LOGERROR)
    if setting_bool("include_games", True):
        try:
            items.extend(steam_games())
        except Exception as exc:
            log("Games read failed: {}".format(exc), xbmc.LOGERROR)
    return items


# -----------------------------------------------------------------------------
# Actions
# -----------------------------------------------------------------------------

def play_movie(movieid):
    try:
        movieid_int = int(movieid)
        jsonrpc("Player.Open", {"item": {"movieid": movieid_int}})
    except Exception as exc:
        log("Play movie failed: {}".format(exc), xbmc.LOGERROR)
        notify("Gagal play movie")


def open_series(tvshowid):
    try:
        tvshowid_int = int(tvshowid)
        xbmc.executebuiltin("ActivateWindow(Videos,videodb://tvshows/titles/{}/,return)".format(tvshowid_int))
    except Exception as exc:
        log("Open series failed: {}".format(exc), xbmc.LOGERROR)
        notify("Gagal buka series")


def play_game(appid):
    appid = str(appid or "").strip()
    if not appid:
        return
    try:
        xbmc.executebuiltin("RunPlugin(plugin://{}?mode=play&appid={})".format(steam_addon_id(), urllib.parse.quote(appid)))
    except Exception as exc:
        log("Launch game failed: {}".format(exc), xbmc.LOGERROR)
        notify("Gagal launch game")


def open_settings():
    try:
        xbmcaddon.Addon(ADDON_ID).openSettings()
    except Exception:
        xbmc.executebuiltin("Addon.OpenSettings({})".format(ADDON_ID))


# -----------------------------------------------------------------------------
# Router
# -----------------------------------------------------------------------------

def normalize_mode(mode):
    mode = (mode or "root").strip().lower()
    aliases = {
        "home_mix": "mix",
        "screensaver_mix": "mix",
        "all": "mix",
        "all_media": "mix",
        "tv": "series",
        "tvshows": "series",
        "shows": "series",
        "show": "series",
        "steam": "games",
        "steam_games": "games",
        "screensaver_movies": "movies",
        "screensaver_series": "series",
        "screensaver_games": "games",
        "home_movies": "movies",
        "home_series": "series",
        "home_games": "games",
    }
    return aliases.get(mode, mode)


def run():
    params = parse_params()
    mode = normalize_mode(params.get("mode", "root"))

    try:
        if mode == "root":
            root()
        elif mode == "mix":
            output_items(mixed_items(), "movies", params)
        elif mode == "movies":
            output_items(library_movies(), "movies", params)
        elif mode == "series":
            output_items(library_series(), "tvshows", params)
        elif mode == "games":
            output_items(steam_games(), "movies", params)
        elif mode == "play_movie":
            play_movie(params.get("movieid"))
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "open_series":
            open_series(params.get("tvshowid"))
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "play_game":
            play_game(params.get("appid"))
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "settings":
            open_settings()
            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcplugin.endOfDirectory(HANDLE)
    except Exception as exc:
        log("Router error: {}\n{}".format(exc, traceback.format_exc()), xbmc.LOGERROR)
        try:
            li = xbmcgui.ListItem(label="MediaHub Widget error")
            safe_set_info(li, {"title": "MediaHub Widget error", "plot": str(exc)})
            xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="root"), li, False)
            xbmcplugin.endOfDirectory(HANDLE)
        except Exception:
            pass


if __name__ == "__main__":
    run()

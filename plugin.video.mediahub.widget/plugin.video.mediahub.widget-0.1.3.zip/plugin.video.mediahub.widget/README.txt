MediaHub Widget for Kodi
========================

Purpose:
- Provides one Kodi plugin path that can list Movies, Series/TV Shows, and Steam games together.
- Designed for Home widgets, Spotlight rows, and Screensaver source/path pickers.
- It does not replace plugin.program.steam.library. It reads that addon's local database and launches games through it.

Main paths:
- plugin://plugin.video.mediahub.widget/?mode=mix&limit=100&random=true
- plugin://plugin.video.mediahub.widget/?mode=movies&limit=100&random=true
- plugin://plugin.video.mediahub.widget/?mode=series&limit=100&random=true
- plugin://plugin.video.mediahub.widget/?mode=games&limit=100&random=true

Compatibility aliases:
- plugin://plugin.video.mediahub.widget/?mode=screensaver_mix&limit=100
- plugin://plugin.video.mediahub.widget/?mode=home_mix&limit=100

Notes:
- Movies and Series are read from Kodi's VideoLibrary through JSON-RPC.
- Games are read from special://profile/addon_data/plugin.program.steam.library/steam_library.db by default.
- Clicking a Movie plays it through Kodi.
- Clicking a Series opens the TV show in Kodi's library.
- Clicking a Game launches Steam through plugin.program.steam.library.


Version 0.1.1:
- Adds explicit game markers for LRS bridges: lrs_game=true, lrs_item_type=game, DBTYPE=game.
- Adds prebuilt Steam/Metacritic/Achievement rating slot ListItem properties for game items.
- Slot icon contract: steam.png, metacritic.png, steam-ach.png.
- Does not patch LRS itself; LRS still needs a runtime bridge to publish these item properties to Window(Home).Property(LibraryRatings.*).


Version 0.1.2:
- Adds AF3/Steam Library compatible game aliases for home widgets/spotlight:
  achievement_display, developer_display, publisher_display, age_rating_display,
  completed_bool, finished_bool, steam_poster_view, is_steam_library,
  steam_no_video_furniture, program_plugin.
- This fixes achievement icons/text not appearing in AF3 home widgets that read
  achievement_display directly instead of RatingSlot3_* properties.


v0.1.3
- Added Steam250 / Top250 bridge from Steam Library DB.
- Reads steam250_rank and steam250_score.
- Publishes steam250_rank_display, top250_rank_display, top250_display, lrs_top250_* and RatingSlot Top250 aliases.

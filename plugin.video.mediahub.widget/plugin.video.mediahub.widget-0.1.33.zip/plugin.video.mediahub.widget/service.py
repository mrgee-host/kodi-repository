# -*- coding: utf-8 -*-
from __future__ import annotations
import xbmc
from addon import prepare_screensaver_cache, load_screensaver_cache, log

class Monitor(xbmc.Monitor):
    pass


def _library_busy():
    try:
        return xbmc.getCondVisibility('Library.IsScanningVideo') or xbmc.getCondVisibility('Library.IsScanningMusic')
    except Exception:
        return False


if __name__ == '__main__':
    monitor = Monitor()
    log('Screensaver cache service started', xbmc.LOGINFO)
    monitor.waitForAbort(3.0)
    while not monitor.abortRequested():
        try:
            if not xbmc.getCondVisibility('Player.HasMedia') and not _library_busy():
                if load_screensaver_cache(max_age=1800) is None:
                    payload = prepare_screensaver_cache(force=True)
                    log('Screensaver cache warmup finished: prepared={}'.format(len((payload or {}).get('items') or [])), xbmc.LOGINFO)
        except Exception as exc:
            log('Screensaver cache service failed: {}'.format(exc), xbmc.LOGWARNING)
        if monitor.waitForAbort(300.0):
            break

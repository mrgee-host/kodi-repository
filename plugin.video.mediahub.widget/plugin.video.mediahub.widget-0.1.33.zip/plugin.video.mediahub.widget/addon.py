# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import glob
import hashlib
import os
import random as random_mod
import re
import struct
import sqlite3
import sys
import traceback
import urllib.parse
import time
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


ADDON_ID = "plugin.video.mediahub.widget"


def addon_instance():
    """Return a short-lived Addon wrapper.

    Plugin invocations are brief. Keeping xbmcaddon.Addon at module scope can
    leave a SWIG wrapper referenced when the Python invoker tears down.
    """
    return xbmcaddon.Addon(ADDON_ID)


def _addon_name():
    addon = addon_instance()
    try:
        return addon.getAddonInfo("name") or "MediaHub Widget"
    finally:
        del addon


ADDON_NAME = _addon_name()
KPM_SHARED_ICON_BASE = "special://home/addons/script.kodi.patch.manager/resources/media/shared-icons"


def kpm_shared_icon(filename):
    return KPM_SHARED_ICON_BASE.rstrip("/") + "/" + filename


BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and str(sys.argv[1]).lstrip("-").isdigit() else -1

STEAM_DEFAULT_ADDON_ID = "plugin.program.steam.library"


# -----------------------------------------------------------------------------
# Small Kodi-safe helpers
# -----------------------------------------------------------------------------

def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[{}] {}".format(ADDON_NAME, msg), level)
    except Exception:
        pass


def tr(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        try:
            return xbmc.translatePath(path)
        except Exception:
            return path


PROFILE = tr("special://profile/addon_data/{}/".format(ADDON_ID))
CACHE_DIR = os.path.join(PROFILE, "cache")
RUNTIME_DIR = os.path.join(PROFILE, "runtime")
STATE_DIR = os.path.join(RUNTIME_DIR, "state")
DIAG_DIR = os.path.join(RUNTIME_DIR, "diagnostics")
REPORTS_DIR = os.path.join(RUNTIME_DIR, "reports")
LOGS_DIR = os.path.join(RUNTIME_DIR, "logs")
EXPORTS_DIR = os.path.join(RUNTIME_DIR, "exports")
SCREENSAVER_CACHE_FILE = os.path.join(CACHE_DIR, 'screensaver-items-v2.json')
SCREENSAVER_STATUS_FILE = os.path.join(STATE_DIR, 'screensaver-cache-status.json')


def ensure_runtime_dirs():
    for folder in (PROFILE, CACHE_DIR, RUNTIME_DIR, STATE_DIR, DIAG_DIR, REPORTS_DIR, LOGS_DIR, EXPORTS_DIR):
        try:
            os.makedirs(folder, exist_ok=True)
        except Exception:
            pass


def setting(key, default=""):
    addon = None
    try:
        addon = addon_instance()
        value = addon.getSetting(key)
        return value if value != "" else default
    except Exception:
        return default
    finally:
        if addon is not None:
            del addon


def setting_bool(key, default=False):
    value = str(setting(key, "")).strip().lower()
    if value == "":
        return bool(default)
    return value in ("1", "true", "yes", "on")


def setting_int(key, default=0):
    try:
        return int(setting(key, str(default)))
    except Exception:
        return int(default)


def clean_text(value):
    if value is None:
        return ""
    text = str(value)
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
    return text.strip()


def as_bool(value, default=False):
    if value is None or str(value).strip() == "":
        return default
    return str(value).strip().lower() in ("1", "true", "yes", "on", "random")

def truthy(value, default=False):
    """Kodi-safe bool parser for Steam DB fields.

    Handles both numeric flags (1/0) and textual values sometimes written by
    older Steam/MediaHub cache versions.
    """
    if value is None or str(value).strip() == "":
        return bool(default)
    text = str(value).strip().lower()
    if text in ("0", "false", "no", "off", "none", "null", "n/a", "na", "-"):
        return False
    return text in ("1", "true", "yes", "on", "completed", "complete", "finished", "finish", "done", "random")


def as_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def url_for(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def parse_params():
    try:
        raw = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
        return dict(urllib.parse.parse_qsl(raw))
    except Exception:
        return {}


def set_item_path(li, path):
    try:
        li.setPath(path)
    except Exception:
        pass


def _int_value(value, default=0):
    try:
        return int(value)
    except Exception:
        return int(default)


def _float_value(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return float(default)


def _string_list(value):
    if isinstance(value, (list, tuple)):
        return [str(part).strip() for part in value if str(part).strip()]
    text = str(value or "").strip()
    if not text:
        return []
    # Existing MWH readers join JSON-RPC arrays with " / ". Preserve names
    # containing commas while restoring those joined arrays to Kodi lists.
    if " / " in text:
        return [part.strip() for part in text.split(" / ") if part.strip()]
    return [text]


def _set_tag_value(tag, method_name, value, converter=None):
    if value in (None, ""):
        return
    method = getattr(tag, method_name, None)
    if not callable(method):
        return
    try:
        method(converter(value) if converter else value)
    except Exception as exc:
        log(
            "InfoTagVideo {} failed for {!r}: {}".format(method_name, value, exc),
            xbmc.LOGDEBUG,
        )


def safe_set_info(li, info):
    """Populate video metadata through InfoTagVideo on Kodi 20+.

    ListItem.setInfo("video", ...) is intentionally not used on supported Kodi
    versions, removing one warning per item while preserving custom properties.
    """
    clean = dict(info or {})
    try:
        tag = li.getVideoInfoTag()
    except Exception as exc:
        log("getVideoInfoTag failed: {}".format(exc), xbmc.LOGDEBUG)
        return

    runtime_value = clean.get("runtime")
    if runtime_value not in (None, ""):
        # Retain the custom aliases used by skin XML while using the canonical
        # video tag for Kodi's duration field.
        try:
            li.setProperty("runtime", str(runtime_value))
            li.setProperty("duration", str(runtime_value))
        except Exception:
            pass

    scalar_map = (
        ("title", "setTitle", str),
        ("originaltitle", "setOriginalTitle", str),
        ("sorttitle", "setSortTitle", str),
        ("plot", "setPlot", str),
        ("plotoutline", "setPlotOutline", str),
        ("tagline", "setTagLine", str),
        ("year", "setYear", _int_value),
        ("userrating", "setUserRating", _int_value),
        ("playcount", "setPlaycount", _int_value),
        ("mpaa", "setMpaa", str),
        ("premiered", "setPremiered", str),
        ("dateadded", "setDateAdded", str),
        ("lastplayed", "setLastPlayed", str),
        ("episode", "setEpisode", _int_value),
        ("season", "setSeason", _int_value),
        ("runtime", "setDuration", _int_value),
        ("mediatype", "setMediaType", str),
        ("dbid", "setDbId", _int_value),
    )
    for key, method_name, converter in scalar_map:
        if key in clean:
            _set_tag_value(tag, method_name, clean.get(key), converter)

    if clean.get("genre") not in (None, ""):
        _set_tag_value(tag, "setGenres", _string_list(clean.get("genre")))
    if clean.get("studio") not in (None, ""):
        _set_tag_value(tag, "setStudios", _string_list(clean.get("studio")))
    if clean.get("director") not in (None, ""):
        _set_tag_value(tag, "setDirectors", _string_list(clean.get("director")))
    if clean.get("writer") not in (None, ""):
        _set_tag_value(tag, "setWriters", _string_list(clean.get("writer")))

    rating = _float_value(clean.get("rating"), 0.0)
    if rating:
        try:
            tag.setRating(rating, 0, "default", True)
        except Exception as exc:
            log("InfoTagVideo setRating failed: {}".format(exc), xbmc.LOGDEBUG)

    resume_time = _float_value(
        clean.get("resumetime", clean.get("resume_time", 0.0)), 0.0
    )
    total_time = _float_value(
        clean.get("totaltime", clean.get("total_time", runtime_value or 0.0)), 0.0
    )
    if resume_time or total_time:
        try:
            tag.setResumePoint(resume_time, total_time)
        except Exception as exc:
            log("InfoTagVideo setResumePoint failed: {}".format(exc), xbmc.LOGDEBUG)


def safe_set_art(li, art):
    clean = {k: v for k, v in (art or {}).items() if v and str(v).strip()}
    if not clean:
        return
    try:
        li.setArt(clean)
    except Exception as exc:
        log("setArt failed: {}".format(exc), xbmc.LOGDEBUG)


def _family_message_r4(message, limit=58):
    text = re.sub(r"\s+", " ", str(message or "").strip()).upper().rstrip()
    if len(text) <= int(limit):
        return text
    parts = text.replace(" • ", " - ").split(" - ")
    protected = ("ERROR", "FAILED", "UPDATED", "ARTWORK", "ITEM", "CACHED", "MOVED", "SCRAPED", "N/A")
    if len(parts) > 1 and any(token in " - ".join(parts[1:]) for token in protected):
        suffix = " - " + " - ".join(parts[1:])
        budget = max(4, int(limit) - len(suffix))
        action = parts[0]
        if len(action) > budget:
            action = action[:max(1, budget - 3)].rstrip() + "..."
        return (action + suffix)[:int(limit)].rstrip()
    raw = text[:max(1, int(limit) - 3)].rstrip()
    return (raw.rsplit(" ", 1)[0] if " " in raw else raw) + "..."


def notify(message):
    try:
        xbmcgui.Dialog().notification(ADDON_NAME, _family_message_r4(message, 58), xbmcgui.NOTIFICATION_INFO, 5000)
    except Exception:
        pass


def show_report(title, message):
    body = str(message or "").strip()
    if len(body) <= 520 and len(body.splitlines()) <= 7:
        xbmcgui.Dialog().ok(str(title or ADDON_NAME), body or "NO DETAILS")
    else:
        xbmcgui.Dialog().textviewer(str(title or ADDON_NAME), body)


# -----------------------------------------------------------------------------
# JSON-RPC video library readers
# -----------------------------------------------------------------------------

def jsonrpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    data = json.loads(raw or "{}")
    if data.get("error"):
        raise RuntimeError("{}: {}".format(method, data["error"]))
    return data.get("result") or {}


def collect_fanart_candidates(raw, primary=""):
    """Collect main fanart and registered extra fanart without opening remote URLs."""
    values = []
    seen = set()

    def add(value):
        value = str(value or "").strip()
        if not value or value in seen:
            return
        seen.add(value)
        values.append(value)

    add(primary)
    art = raw.get("art") if isinstance(raw, dict) else {}
    if isinstance(art, dict):
        for key, value in art.items():
            name = str(key or "").strip().lower()
            if re.search(r"(^|\.)(?:extra)?fanart(?:\d+)?$", name):
                add(value)
    if isinstance(raw, dict):
        add(raw.get("fanart"))
    return values


def pick_art(raw, media_type="movie"):
    art = raw.get("art") if isinstance(raw, dict) else {}
    if not isinstance(art, dict):
        art = {}

    poster = art.get("poster") or art.get("tvshow.poster") or raw.get("thumbnail") or ""
    thumb = art.get("thumb") or raw.get("thumbnail") or poster
    fanart = art.get("fanart") or art.get("tvshow.fanart") or raw.get("fanart") or ""
    landscape = art.get("landscape") or art.get("tvshow.landscape") or fanart or thumb
    clearlogo = art.get("clearlogo") or art.get("tvshow.clearlogo") or ""
    banner = art.get("banner") or art.get("tvshow.banner") or ""

    return {
        "poster": poster,
        "thumb": thumb,
        "icon": thumb or poster,
        "fanart": fanart,
        "landscape": landscape,
        "clearlogo": clearlogo,
        "banner": banner,
    }


def first_number(value, default=0):
    try:
        if isinstance(value, (int, float)):
            return value
        text = str(value or "").strip()
        return float(text) if text else default
    except Exception:
        return default


def fmt_percent(value):
    text = str(value or '').strip()
    if not text or text.upper() in ('N/A', 'NA', 'NONE', 'NULL', '-'):
        return ''
    if text.endswith('%'):
        return text
    try:
        num = float(text)
        text = str(int(num)) if num.is_integer() else ('%.1f' % num).rstrip('0').rstrip('.')
        return text + '%'
    except Exception:
        return text


def genre_text(value):
    if isinstance(value, list):
        return " / ".join([str(x) for x in value if str(x).strip()])
    return str(value or "")


def mediahub_item_key(kind, dbid="", steam_appid=""):
    """Return the stable item identity shared with LRS and KPM."""
    kind = str(kind or "").strip().lower()
    if kind == "movie" and str(dbid or "").strip():
        return "movie|{}".format(str(dbid).strip())
    if kind in ("series", "tvshow") and str(dbid or "").strip():
        return "tvshow|{}".format(str(dbid).strip())
    if kind == "game" and str(steam_appid or dbid or "").strip():
        return "game|steam|{}".format(str(steam_appid or dbid).strip())
    return ""


def library_movies():
    props = [
        "title", "originaltitle", "sorttitle", "year", "genre", "plot", "plotoutline",
        "tagline", "rating", "userrating", "playcount", "runtime", "studio", "director",
        "writer", "mpaa", "premiered", "dateadded", "lastplayed", "thumbnail", "fanart", "art",
    ]
    fallback_props = ["title", "year", "genre", "plot", "rating", "thumbnail", "fanart", "art"]
    params = {
        "properties": props,
        "sort": {"method": "title", "order": "ascending", "ignorearticle": True},
        "limits": {"start": 0, "end": 100000},
    }
    try:
        result = jsonrpc("VideoLibrary.GetMovies", params)
    except Exception:
        params["properties"] = fallback_props
        result = jsonrpc("VideoLibrary.GetMovies", params)

    items = []
    for m in result.get("movies", []) or []:
        movieid = m.get("movieid")
        title = m.get("title") or "Movie {}".format(movieid)
        plot = clean_text(m.get("plot") or m.get("plotoutline") or "")
        year = as_int(m.get("year"), 0)
        art = pick_art(m, "movie")
        fanart_candidates = collect_fanart_candidates(m, art.get("fanart"))
        url = url_for(mode="play_movie", movieid=movieid)
        items.append({
            "kind": "movie",
            "label": title,
            "url": url,
            "is_folder": False,
            "art": art,
            "_fanart_candidates": fanart_candidates,
            "info": {
                "mediatype": "movie",
                "dbid": int(movieid) if str(movieid).isdigit() else 0,
                "title": title,
                "originaltitle": m.get("originaltitle") or title,
                "sorttitle": m.get("sorttitle") or title,
                "plot": plot,
                "plotoutline": clean_text(m.get("plotoutline") or plot),
                "tagline": clean_text(m.get("tagline") or ""),
                "year": year,
                "genre": genre_text(m.get("genre")),
                "rating": first_number(m.get("rating"), 0),
                "userrating": as_int(m.get("userrating"), 0),
                "playcount": as_int(m.get("playcount"), 0),
                "runtime": as_int(m.get("runtime"), 0),
                "studio": genre_text(m.get("studio")),
                "mpaa": m.get("mpaa") or "",
                "premiered": m.get("premiered") or "",
                "dateadded": m.get("dateadded") or "",
                "lastplayed": m.get("lastplayed") or "",
            },
            "props": {
                "mediahub_type": "movie",
                "mediahub_item_key": mediahub_item_key("movie", movieid),
                "dbid": str(movieid or ""),
                "source": "Kodi Movies",
                "IsPlayable": "true",
            },
        })
    return items


def library_series():
    props = [
        "title", "year", "genre", "plot", "rating", "userrating", "playcount", "studio",
        "mpaa", "premiered", "dateadded", "lastplayed", "thumbnail", "fanart", "art",
        "episode", "season",
    ]
    fallback_props = ["title", "year", "genre", "plot", "rating", "thumbnail", "fanart", "art"]
    params = {
        "properties": props,
        "sort": {"method": "title", "order": "ascending", "ignorearticle": True},
        "limits": {"start": 0, "end": 100000},
    }
    try:
        result = jsonrpc("VideoLibrary.GetTVShows", params)
    except Exception:
        params["properties"] = fallback_props
        result = jsonrpc("VideoLibrary.GetTVShows", params)

    items = []
    for s in result.get("tvshows", []) or []:
        tvshowid = s.get("tvshowid")
        title = s.get("title") or "Series {}".format(tvshowid)
        plot = clean_text(s.get("plot") or "")
        year = as_int(s.get("year"), 0)
        art = pick_art(s, "tvshow")
        fanart_candidates = collect_fanart_candidates(s, art.get("fanart"))
        url = url_for(mode="open_series", tvshowid=tvshowid)
        episode = as_int(s.get("episode"), 0)
        season = as_int(s.get("season"), 0)
        items.append({
            "kind": "series",
            "label": title,
            "url": url,
            "is_folder": False,
            "art": art,
            "_fanart_candidates": fanart_candidates,
            "info": {
                "mediatype": "tvshow",
                "dbid": int(tvshowid) if str(tvshowid).isdigit() else 0,
                "title": title,
                "sorttitle": title,
                "plot": plot,
                "plotoutline": plot,
                "year": year,
                "genre": genre_text(s.get("genre")),
                "rating": first_number(s.get("rating"), 0),
                "userrating": as_int(s.get("userrating"), 0),
                "playcount": as_int(s.get("playcount"), 0),
                "studio": genre_text(s.get("studio")),
                "mpaa": s.get("mpaa") or "",
                "premiered": s.get("premiered") or "",
                "dateadded": s.get("dateadded") or "",
                "lastplayed": s.get("lastplayed") or "",
                "episode": episode,
                "season": season,
            },
            "props": {
                "mediahub_type": "series",
                "mediahub_item_key": mediahub_item_key("tvshow", tvshowid),
                "dbid": str(tvshowid or ""),
                "source": "Kodi TV Shows",
                "episode_count": str(episode),
                "season_count": str(season),
                "IsPlayable": "false",
            },
        })
    return items


# -----------------------------------------------------------------------------
# Steam Library reader
# -----------------------------------------------------------------------------

def steam_db_path():
    custom = setting("steam_db_path", "").strip()
    if custom:
        return tr(custom)
    steam_addon_id = setting("steam_addon_id", STEAM_DEFAULT_ADDON_ID).strip() or STEAM_DEFAULT_ADDON_ID
    return tr("special://profile/addon_data/{}/steam_library.db".format(steam_addon_id))


def steam_addon_id():
    return setting("steam_addon_id", STEAM_DEFAULT_ADDON_ID).strip() or STEAM_DEFAULT_ADDON_ID


def db_col_exists(cols, name):
    return name in cols




def format_playtime_forever(minutes, with_prefix=False):
    try:
        value = int(float(str(minutes or '').strip()))
    except Exception:
        value = 0
    if value <= 0:
        return ''
    if value < 120:
        body = '{0} minutes'.format(value)
    else:
        hours = round(value / 60.0, 1)
        body = '{0} hours'.format(int(hours) if float(hours).is_integer() else '{0:.1f}'.format(hours))
    return body

def format_playtime_compact_0133(minutes):
    try:
        value = int(float(str(minutes or '').strip()))
    except Exception:
        value = 0
    if value <= 0:
        return ''
    if value < 120:
        return '{0}m'.format(value)
    hours = round(value / 60.0, 1)
    return '{0}h'.format(int(hours) if float(hours).is_integer() else '{0:.1f}'.format(hours))


def _minutes_from_playtime_label_0133(label):
    text = str(label or '').strip().lower()
    if not text:
        return 0
    try:
        if text.endswith(' minutes'):
            return int(float(text[:-8].strip()))
        if text.endswith(' minute'):
            return int(float(text[:-7].strip()))
        if text.endswith(' hours'):
            return int(round(float(text[:-6].strip()) * 60.0))
        if text.endswith(' hour'):
            return int(round(float(text[:-5].strip()) * 60.0))
        if text.endswith('m'):
            return int(float(text[:-1].strip()))
        if text.endswith('h'):
            return int(round(float(text[:-1].strip()) * 60.0))
    except Exception:
        return 0
    return 0


def build_game_row_alias_props_0117(g, steam_score, mc_score):
    """Stable game-row aliases in canonical order for diagnostics/fallbacks.

    KPM remains the visual owner; these properties only expose a complete item
    snapshot and never patch AF3 directly.
    """
    steam_label = steam_rating_display(g)
    if steam_label == "N/A":
        steam_label = ""
    mc_label = str(mc_score or "").strip()
    ach_label = steam_achievement_display(g)
    if ach_label == "N/A":
        ach_label = ""
    playtime_label = format_playtime_forever(g.get("playtime_forever"), with_prefix=False)
    slots = []
    if steam_label:
        slots.append(("steam", "steam.png", steam_label))
    if mc_label and mc_label != "0":
        slots.append(("metacritic", "metacritic.png", mc_label))
    if ach_label:
        slots.append(("achievement", "steam-ach.png", ach_label))
    if playtime_label:
        slots.append(("steam_playtime", "ends.png", playtime_label))
    props = {"GameRowOrder": ",".join(x[0] for x in slots), "RatingSlotCount": str(len(slots))}
    for idx, (source, icon, label) in enumerate(slots, start=1):
        props["RatingSlot{}_Source".format(idx)] = source
        props["RatingSlot{}_IconFile".format(idx)] = icon
        props["RatingSlot{}_Label".format(idx)] = label
        props["RatingSlot{}_Value".format(idx)] = label
    return props


def game_kpm_props(g, appid, steam_score, mc_score):
    steam_label = steam_rating_display(g)
    if steam_label == "N/A":
        steam_label = ""
    mc_label = str(mc_score or "").strip()
    ach_unlocked = g.get("achievement_unlocked")
    ach_total = g.get("achievement_total")
    ach_label = "{}/{}".format(ach_unlocked or "0", ach_total) if ach_total else ""
    completed = truthy(g.get("completed"))
    finished = truthy(g.get("finished"))
    return {
        "kpm_item_type": "game",
        "lrs_item_type": "game",
        "mediahub_type": "game",
        "mediahub_item_key": mediahub_item_key("game", steam_appid=appid),
        "DBTYPE": "game",
        "dbtype": "game",
        "MediaType": "game",
        "mediatype": "game",
        "kpm_data_owner": "plugin.video.mediahub.widget",
        "kpm_game_row_ready": "true",
        "kpm_game_row_schema": "2",
        "kpm_game_row_order": "steam,metacritic,achievement,playtime",
        "platform": "steam",
        "steam_appid": str(appid or ""),
        "steam_rating_display": steam_label,
        "steam_review_percent": str(steam_score or ""),
        "steam_review_desc": str(g.get("steam_review_desc") or ""),
        "steam_review_total": str(g.get("steam_review_total") or ""),
        "steam250_rank": str(g.get("steam250_rank") or ""),
        "steam250_score": str(g.get("steam250_score") or ""),
        "steam250_rank_display": steam250_rank_display(g),
        "metacritic_score": str(mc_score or ""),
        "achievement_unlocked": str(ach_unlocked or ""),
        "achievement_total": str(ach_total or ""),
        "achievement_display": ach_label,
        "playtime_forever": str(g.get("playtime_forever") or ""),
        "playtime_display": format_playtime_forever(g.get("playtime_forever"), with_prefix=False),
        "completed": "true" if completed else "false",
        "finished": "true" if finished else "false",
        "completed_bool": "true" if completed else "",
        "finished_bool": "true" if finished else "",
        "kpm_shared_icon_base": KPM_SHARED_ICON_BASE,
    }

def steam_display_or_na(value):
    txt = str(value or "").strip()
    return txt if txt and txt.upper() != "N/A" else "N/A"


def first_credit(value):
    text = str(value or "").strip()
    if not text or text.upper() == "N/A":
        return "N/A"
    parts = re.split(r"\s*/\s*|\s*;\s*|\s*,\s*", text)
    for part in parts:
        part = part.strip()
        if part:
            return part
    return text


def steam_achievement_display(g):
    unlocked = steam_display_or_na(g.get("achievement_unlocked"))
    total = steam_display_or_na(g.get("achievement_total"))
    if total != "N/A":
        return "{}/{}".format("0" if unlocked == "N/A" else unlocked, total)
    return "N/A"


def steam_rating_display(g):
    pct = steam_display_or_na(g.get("steam_review_percent"))
    rank = steam_display_or_na(g.get("steam250_rank"))
    parts = []
    if pct != "N/A":
        parts.append("{}%".format(pct))
    if rank != "N/A":
        rank = str(rank).strip().lstrip("#")
        if rank:
            parts.append("#{}".format(rank))
    return " ".join(parts) if parts else "N/A"


def steam250_rank_display(g):
    rank = steam_display_or_na(g.get("steam250_rank"))
    if rank == "N/A":
        return "N/A"
    rank = str(rank).strip().lstrip("#")
    return "#{}".format(rank) if rank else "N/A"


def normalize_age_rating_value(value):
    txt = steam_display_or_na(value)
    if txt == "N/A":
        return "N/A"

    raw = str(txt).strip()
    upper = raw.upper()

    # Remove provider/presentation prefixes so the UI never shows ESRB/PEGI.
    upper = re.sub(r"^\s*(ESRB|PEGI|USK|CERO|GRAC|CLASSIND)\s*[:\-]?\s*", "", upper)
    upper = re.sub(r"^\s*RATING\s*[:\-]?\s*", "", upper)
    upper = upper.strip()

    esrb_map = {
        "EC": "3+",
        "E": "6+",
        "EVERYONE": "6+",
        "E10": "10+",
        "E10+": "10+",
        "EVERYONE 10+": "10+",
        "T": "13+",
        "TEEN": "13+",
        "M": "17+",
        "MATURE": "17+",
        "MATURE 17+": "17+",
        "AO": "18+",
        "ADULTS ONLY": "18+",
        "ADULTS ONLY 18+": "18+",
    }
    if upper in esrb_map:
        return esrb_map[upper]

    if upper in ("RP", "RATING PENDING", "PENDING", "UNRATED", "NR", "N/A", "NA", "NONE", "0"):
        return "N/A"

    # PEGI/required_age numeric values, including values already saved as 16+.
    m = re.search(r"(\d{1,2})\s*\+?", upper)
    if m:
        age = m.group(1)
        if age == "0":
            return "N/A"
        return "{}+".format(age)

    return "N/A"


def steam_age_rating_display(g):
    esrb_age = normalize_age_rating_value(g.get("esrb"))
    pegi_age = normalize_age_rating_value(g.get("pegi"))
    if esrb_age != "N/A":
        return "Rating {}".format(esrb_age)
    if pegi_age != "N/A":
        return "Rating {}".format(pegi_age)
    return "N/A"


def steam_tagline_display(g):
    tagline = steam_display_or_na(clean_text(g.get("tagline")))
    if tagline != "N/A":
        return tagline
    return steam_display_or_na(g.get("genres"))

def steam_games():
    path = steam_db_path()
    if not path or not os.path.exists(path):
        log("Steam database not found: {}".format(path), xbmc.LOGWARNING)
        return []

    con = None
    try:
        con = sqlite3.connect(path)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("PRAGMA table_info(games)")
        cols = set([r[1] for r in cur.fetchall()])
        if not cols:
            return []

        select_cols = [
            "appid", "name", "steam_name", "display_name", "sortname", "year", "developer", "publisher", "genres", "tagline", "short_description",
            "steam_review_percent", "steam_review_desc", "steam_review_total", "steam250_rank",
            "steam250_score", "achievement_unlocked", "achievement_total", "completed", "finished",
            "metacritic_score", "playtime_forever", "esrb", "pegi",
            "poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url",
            "fanart3_url", "fanart4_url",
        ]
        usable_cols = [c for c in select_cols if db_col_exists(cols, c)]
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='library_membership'")
        has_membership = bool(cur.fetchone())
        sql = "SELECT {} FROM games".format(", ".join(["games.{0} AS {0}".format(c) for c in usable_cols]))
        clauses = []
        if has_membership:
            sql += " JOIN library_membership ON library_membership.appid=games.appid"
            clauses.append("library_membership.is_active=1")
        args = []

        exclude_hidden = setting_bool("exclude_hidden_games", True)
        if exclude_hidden:
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='hidden_games'")
            if cur.fetchone():
                clauses.append("games.appid NOT IN (SELECT appid FROM hidden_games)")
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='manual_hidden_games'")
            if cur.fetchone():
                clauses.append("games.appid NOT IN (SELECT appid FROM manual_hidden_games)")
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        order_cols = [c for c in ("sortname", "display_name", "name", "steam_name", "appid") if c in cols]
        if order_cols:
            exprs = ["NULLIF(games.{0},'')".format(c) for c in order_cols[:-1]] + ["games.{0}".format(order_cols[-1])]
            sql += " ORDER BY COALESCE({}) COLLATE NOCASE".format(", ".join(exprs))
        rows = cur.execute(sql, args).fetchall()
    except Exception as exc:
        log("Steam DB read failed: {}\n{}".format(exc, traceback.format_exc()), xbmc.LOGERROR)
        return []
    finally:
        try:
            if con:
                con.close()
        except Exception:
            pass

    items = []
    for row in rows:
        g = dict(row)
        appid = str(g.get("appid") or "").strip()
        if not appid:
            continue
        title = clean_text(g.get("display_name") or g.get("name") or g.get("steam_name") or "Steam App {}".format(appid))
        plot = clean_text(g.get("short_description") or "")
        raw_genres = str(g.get("genres") or "").strip()
        tagline_text = steam_tagline_display(g)
        tagline_for_ui = "" if tagline_text == "N/A" else tagline_text
        age_rating_for_ui = steam_age_rating_display(g)
        poster = g.get("poster_url") or ""
        thumb = g.get("thumb_url") or poster
        fanart_candidates = []
        for candidate in (
            g.get("fanart_url"), g.get("fanart1_url"), g.get("fanart2_url"),
            g.get("fanart3_url"), g.get("fanart4_url"),
        ):
            candidate = str(candidate or "").strip()
            if candidate and candidate not in fanart_candidates:
                fanart_candidates.append(candidate)
        fanart = (fanart_candidates[0] if fanart_candidates else "") or thumb
        clearlogo = g.get("clearlogo_url") or ""
        steam_score = as_int(g.get("steam_review_percent"), 0)
        mc_score = as_int(g.get("metacritic_score"), 0)
        rating = round(float(steam_score) / 10.0, 1) if steam_score else 0
        detail_bits = []
        if g.get("developer"):
            detail_bits.append(str(g.get("developer")))
        if g.get("genres"):
            detail_bits.append(str(g.get("genres")))
        if steam_score:
            detail_bits.append("Steam {}%".format(steam_score))
        if mc_score:
            detail_bits.append("Metacritic {}".format(mc_score))

        url = url_for(mode="play_game", appid=appid)
        items.append({
            "kind": "game",
            "label": title,
            "url": url,
            "is_folder": False,
            "art": {
                "poster": poster,
                "thumb": thumb,
                "icon": thumb or poster,
                "fanart": fanart,
                "landscape": fanart or thumb,
                "clearlogo": clearlogo,
            },
            "_fanart_candidates": fanart_candidates,
            "info": {
                "mediatype": "movie",
                "title": title,
                "originaltitle": title,
                "sorttitle": title,
                "plot": plot,
                "plotoutline": plot,
                "year": as_int(g.get("year"), 0),
                # AF3 row compatibility: games use tagline in the old genre headline slot.
                "genre": tagline_for_ui,
                "studio": g.get("developer") or g.get("publisher") or "",
                "rating": rating,
                "mpaa": "",
                "tagline": tagline_for_ui,
            },
            "props": dict({
                "mediahub_type": "game",
                "source": "Steam Library",
                "platform": "steam",
                "steam_platform": "steam",
                "steam_appid": appid,
                "appid": appid,
                "developer": str(g.get("developer") or ""),
                "publisher": str(g.get("publisher") or ""),
                "genres": raw_genres,
                "tagline": str(g.get("tagline") or ""),
                "tagline_display": tagline_for_ui,
                "genre_display": tagline_for_ui,
                "genres_display": raw_genres or "N/A",
                "esrb": str(g.get("esrb") or ""),
                "pegi": str(g.get("pegi") or ""),
                "steam_review_percent": str(g.get("steam_review_percent") or ""),
                "steam_review_desc": str(g.get("steam_review_desc") or ""),
                "steam_review_total": str(g.get("steam_review_total") or ""),
                "steam250_rank": str(g.get("steam250_rank") or ""),
                "steam250_score": str(g.get("steam250_score") or ""),
                "metacritic_score": str(g.get("metacritic_score") or ""),
                "achievement_unlocked": str(g.get("achievement_unlocked") or ""),
                "achievement_total": str(g.get("achievement_total") or ""),
                "completed": str(g.get("completed") or ""),
                "finished": str(g.get("finished") or ""),

                # AF3 / Steam Library compatible aliases.
                # Home spotlight/widget skin patches usually read these direct
                # properties, not the generic RatingSlotN_* bridge used by LRS.
                "developer_display": steam_display_or_na(first_credit(g.get("developer"))),
                "publisher_display": steam_display_or_na(first_credit(g.get("publisher"))),
                "achievement_display": steam_achievement_display(g),
                "playtime_forever": str(g.get("playtime_forever") or ""),
                "playtime_display": format_playtime_forever(g.get("playtime_forever"), with_prefix=False),
                "steam_rating_display": steam_rating_display(g),
                "steam250_rank_display": steam250_rank_display(g),
                "top250_display": steam250_rank_display(g),
                "age_rating_display": age_rating_for_ui,
                "completed_bool": "true" if truthy(g.get("completed")) else "",
                "finished_bool": "true" if truthy(g.get("finished")) else "",
                "steam_poster_view": "true",
                "is_steam_library": "true",
                "steam_no_video_furniture": "true",
                "program_plugin": steam_addon_id(),
                "IsPlayable": "true",
            }, **game_kpm_props(g, appid, steam_score, mc_score), **build_game_row_alias_props_0117(g, steam_score, mc_score)),
        })
    return items




# -----------------------------------------------------------------------------
# Artwork filters: clearlogo + cached fanart resolution via Textures DB
# -----------------------------------------------------------------------------

MIN_1080P_WIDTH = 1920
MIN_1080P_HEIGHT = 1080
_TEXTURE_SIZE_CACHE = {}


def is_http_url(value):
    txt = str(value or "").strip().lower()
    return txt.startswith("http://") or txt.startswith("https://")


def image_url_candidates(url):
    raw = str(url or "").strip()
    if not raw:
        return []
    candidates = []

    def add(v):
        v = str(v or "").strip()
        if v and v not in candidates:
            candidates.append(v)

    add(raw)

    # Kodi's texture DB commonly stores artwork as image://<urlencoded-source>/.
    if raw.startswith("image://"):
        inner = raw[8:]
        if inner.endswith("/"):
            inner = inner[:-1]
        decoded = urllib.parse.unquote(inner)
        add(decoded)
        add("image://{}/".format(urllib.parse.quote(decoded, safe="")))
        add("image://{}/".format(urllib.parse.quote(decoded, safe=":/")))
    else:
        add("image://{}/".format(urllib.parse.quote(raw, safe="")))
        add("image://{}/".format(urllib.parse.quote(raw, safe=":/")))

    return candidates


def texture_db_path():
    db_dir = tr("special://profile/Database")
    candidates = []
    try:
        candidates = glob.glob(os.path.join(db_dir, "Textures*.db"))
    except Exception:
        candidates = []
    if not candidates:
        fixed = os.path.join(db_dir, "Textures13.db")
        return fixed if os.path.exists(fixed) else ""

    def version(path):
        m = re.search(r"Textures(\d+)\.db$", os.path.basename(path), re.I)
        return int(m.group(1)) if m else 0

    candidates.sort(key=version, reverse=True)
    return candidates[0]


def cached_texture_path(cachedurl):
    cachedurl = str(cachedurl or "").strip()
    if not cachedurl:
        return ""
    if cachedurl.startswith("special://"):
        return tr(cachedurl)
    if os.path.isabs(cachedurl):
        return cachedurl
    return os.path.join(tr("special://profile/Thumbnails"), cachedurl.replace("/", os.sep))


def read_file_head(path, max_bytes=512 * 1024):
    try:
        real = tr(path)
        if not real or not os.path.exists(real):
            return b""
        with open(real, "rb") as fh:
            return fh.read(max_bytes)
    except Exception:
        return b""


def image_size_from_bytes(data):
    if not data:
        return None
    try:
        # PNG
        if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24:
            width, height = struct.unpack(">II", data[16:24])
            return int(width), int(height)

        # JPEG: scan SOF markers.
        if data[:2] == b"\xff\xd8":
            i = 2
            size = len(data)
            while i + 9 < size:
                if data[i] != 0xFF:
                    i += 1
                    continue
                marker = data[i + 1]
                i += 2
                if marker in (0xD8, 0xD9):
                    continue
                if i + 2 > size:
                    break
                block_len = struct.unpack(">H", data[i:i + 2])[0]
                if block_len < 2:
                    break
                if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                    if i + 7 <= size:
                        height, width = struct.unpack(">HH", data[i + 3:i + 7])
                        return int(width), int(height)
                    break
                i += block_len

        # WebP VP8X / VP8L partial support.
        if data.startswith(b"RIFF") and data[8:12] == b"WEBP" and len(data) >= 30:
            chunk = data[12:16]
            if chunk == b"VP8X" and len(data) >= 30:
                width = 1 + int.from_bytes(data[24:27], "little")
                height = 1 + int.from_bytes(data[27:30], "little")
                return int(width), int(height)
            if chunk == b"VP8L" and len(data) >= 25 and data[20] == 0x2f:
                b0, b1, b2, b3 = data[21], data[22], data[23], data[24]
                width = 1 + (((b1 & 0x3F) << 8) | b0)
                height = 1 + (((b3 & 0x0F) << 10) | (b2 << 2) | ((b1 & 0xC0) >> 6))
                return int(width), int(height)
    except Exception:
        return None
    return None


def image_size_from_file(path):
    return image_size_from_bytes(read_file_head(path))


def local_source_from_image_url(url):
    raw = str(url or "").strip()
    if raw.startswith("image://"):
        inner = raw[8:]
        if inner.endswith("/"):
            inner = inner[:-1]
        raw = urllib.parse.unquote(inner)
    if is_http_url(raw):
        return ""
    if raw.startswith("special://"):
        return tr(raw)
    if os.path.isabs(raw):
        return raw
    return ""


def texture_size_from_db(url):
    raw = str(url or "").strip()
    if not raw:
        return None
    if raw in _TEXTURE_SIZE_CACHE:
        return _TEXTURE_SIZE_CACHE[raw]

    result = None
    db_path = texture_db_path()
    if db_path and os.path.exists(db_path):
        con = None
        try:
            con = sqlite3.connect(db_path)
            con.row_factory = sqlite3.Row
            cur = con.cursor()
            cur.execute("PRAGMA table_info(texture)")
            texture_cols = [r[1] for r in cur.fetchall()]
            if "url" in texture_cols:
                candidates = image_url_candidates(raw)
                placeholders = ",".join(["?"] * len(candidates))
                sql = "SELECT rowid AS _rowid, * FROM texture WHERE url IN ({}) ORDER BY rowid DESC LIMIT 1".format(placeholders)
                row = cur.execute(sql, candidates).fetchone()

                if row:
                    row_keys = set(row.keys())
                    width = as_int(row["width"], 0) if "width" in row_keys else 0
                    height = as_int(row["height"], 0) if "height" in row_keys else 0
                    if width and height:
                        result = (width, height, "texture-db")

                    # Some Kodi schemas store dimensions in a sizes table.
                    if result is None:
                        try:
                            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sizes'")
                            if cur.fetchone():
                                cur.execute("PRAGMA table_info(sizes)")
                                size_cols = [r[1] for r in cur.fetchall()]
                                if "width" in size_cols and "height" in size_cols:
                                    id_value = None
                                    for id_col in ("idtexture", "id", "_rowid"):
                                        if id_col in row_keys:
                                            id_value = row[id_col]
                                            break
                                    if id_value is not None:
                                        if "idtexture" in size_cols:
                                            srow = cur.execute(
                                                "SELECT width, height FROM sizes WHERE idtexture=? ORDER BY (width * height) DESC LIMIT 1",
                                                (id_value,),
                                            ).fetchone()
                                        else:
                                            srow = cur.execute(
                                                "SELECT width, height FROM sizes ORDER BY (width * height) DESC LIMIT 1"
                                            ).fetchone()
                                        if srow and as_int(srow["width"], 0) and as_int(srow["height"], 0):
                                            result = (as_int(srow["width"], 0), as_int(srow["height"], 0), "texture-sizes")
                        except Exception:
                            pass

                    if result is None and "cachedurl" in row_keys:
                        cpath = cached_texture_path(row["cachedurl"])
                        size = image_size_from_file(cpath)
                        if size:
                            result = (size[0], size[1], "thumbnail-cache")
        except Exception as exc:
            log("Texture DB check failed for {}: {}".format(raw, exc), xbmc.LOGDEBUG)
        finally:
            try:
                if con:
                    con.close()
            except Exception:
                pass

    # Local artwork fallback. Remote URLs are deliberately not downloaded.
    if result is None:
        local = local_source_from_image_url(raw)
        if local:
            size = image_size_from_file(local)
            if size:
                result = (size[0], size[1], "local-file")

    _TEXTURE_SIZE_CACHE[raw] = result
    return result



LRS_RATINGS_DB = tr("special://profile/addon_data/script.library.ratings.scraper/ratings-cache.db")
KPM_CLEARLOGO_RESOLVER_DB = tr("special://profile/addon_data/script.kodi.patch.manager/runtime/state/clearlogo-resolver-cache.db")


def _cropv2_directory():
    custom = ""
    addon = None
    try:
        addon = xbmcaddon.Addon("plugin.video.themoviedb.helper")
        custom = str(addon.getSetting("image_location") or "").strip()
    except Exception:
        custom = ""
    finally:
        if addon is not None:
            del addon
    base = custom or "special://profile/addon_data/plugin.video.themoviedb.helper"
    return tr(os.path.join(base.rstrip("/\\"), "crop_v2"))


def _cropv2_from_source(source):
    source = str(source or "").strip()
    if not source:
        return ""
    exact = os.path.join(_cropv2_directory(), "cropped-{}.png".format(hashlib.md5(source.encode("utf-8")).hexdigest()))
    if os.path.isfile(exact) and os.path.getsize(exact) > 0:
        return exact
    return ""


def _resolver_cropv2(item_key, source):
    # Exact CropV2 hash is the primary path and makes the prepared cache
    # independent from LRS polling order. The persistent resolver remains a
    # verified fallback and diagnostics source.
    direct = _cropv2_from_source(source)
    if direct:
        return {"status": "resolved", "path": direct, "source": "exact_cropv2_hash"}
    if not os.path.isfile(KPM_CLEARLOGO_RESOLVER_DB):
        return {"status": "cache_unbuilt", "path": "", "source": "resolver_db_missing"}
    conn = None
    try:
        conn = sqlite3.connect(KPM_CLEARLOGO_RESOLVER_DB, timeout=5)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT status,resolved_path,canonical_source,source_hash FROM resolver_items WHERE item_key=?",
            (str(item_key or ""),),
        ).fetchone()
        if not row:
            return {"status": "not_indexed", "path": "", "source": "resolver_db"}
        path = str(row["resolved_path"] or "")
        valid = bool(path and os.path.isfile(path) and os.path.getsize(path) > 0)
        return {
            "status": "resolved" if valid else str(row["status"] or "missing"),
            "path": path if valid else "", "source": "resolver_db",
            "source_hash": str(row["source_hash"] or ""),
        }
    except Exception as exc:
        return {"status": "resolver_error", "path": "", "source": "resolver_db", "error": str(exc)}
    finally:
        if conn is not None:
            conn.close()


def has_clearlogo(item):
    art = item.get("art") or {}
    return bool(str(art.get("clearlogo") or "").strip())


def fanart_is_1080p_or_better(item):
    art = item.get("art") or {}
    fanart = str(art.get("fanart") or "").strip()
    if not fanart:
        return False
    size = texture_size_from_db(fanart)
    if not size:
        return False
    width, height, _source = size
    return int(width) >= MIN_1080P_WIDTH and int(height) >= MIN_1080P_HEIGHT


def is_screensaver_request(params):
    if as_bool((params or {}).get("_screensaver"), False):
        return True
    try:
        return bool(xbmc.getCondVisibility("System.ScreenSaverActive"))
    except Exception:
        return False


def choose_one_random_cached_fanart_per_item(items, params):
    """Choice 1: keep one slide per item, but randomly select one cached fanart."""
    if not is_screensaver_request(params):
        return items

    seed = str((params or {}).get("seed") or "").strip()
    rnd = random_mod.Random(seed + "|fanart") if seed else random_mod.Random()
    require_1080p = setting_bool("exclude_fanart_below_1080p", True)
    changed = 0

    for item in items:
        art = dict(item.get("art") or {})
        candidates = list(item.get("_fanart_candidates") or [])
        current = str(art.get("fanart") or "").strip()
        if current and current not in candidates:
            candidates.insert(0, current)

        valid = list(item.get('_valid_fanart_candidates') or [])
        if valid:
            candidates = []
        for candidate in candidates:
            candidate = str(candidate or "").strip()
            if not candidate or candidate in valid:
                continue
            size = texture_size_from_db(candidate)
            # Remote artwork must already exist in Kodi texture cache. Local files
            # are accepted by texture_size_from_db without network access.
            if not size:
                continue
            width, height, _source = size
            if require_1080p and (int(width) < MIN_1080P_WIDTH or int(height) < MIN_1080P_HEIGHT):
                continue
            valid.append(candidate)

        if not valid:
            continue
        chosen = rnd.choice(valid)
        art["fanart"] = chosen
        art["landscape"] = chosen
        item["art"] = art
        item.setdefault("props", {})["mediahub_random_fanart"] = "true"
        item["props"]["mediahub_random_fanart_count"] = str(len(valid))
        if chosen != current:
            changed += 1

    log("Screensaver random fanart: items={}, changed={}".format(len(items), changed), xbmc.LOGINFO)
    return items


def apply_item_filters(items):
    require_clearlogo = setting_bool("exclude_without_clearlogo", True)
    require_1080p = setting_bool("exclude_fanart_below_1080p", True)
    if not require_clearlogo and not require_1080p:
        return list(items)

    kept = []
    skipped_logo = 0
    skipped_fanart = 0
    for item in items:
        if require_clearlogo and not has_clearlogo(item):
            skipped_logo += 1
            continue
        if require_1080p and not fanart_is_1080p_or_better(item):
            skipped_fanart += 1
            continue
        kept.append(item)

    log("Artwork filters: kept={}, skipped_no_clearlogo={}, skipped_below_or_unknown_1080p={}".format(
        len(kept), skipped_logo, skipped_fanart
    ), xbmc.LOGINFO)
    return kept


def _screensaver_session_limit():
    return max(50, min(600, setting_int('screensaver_session_limit', 300)))


def prepare_screensaver_cache(force=False):
    ensure_runtime_dirs()
    started = time.time()
    items = mixed_items()
    # Fanart filtering remains independent. Clearlogo is validated against the
    # actual CropV2 path below, not merely against a native source URL.
    require_1080p = setting_bool('exclude_fanart_below_1080p', True)
    require_cropv2 = setting_bool('exclude_without_clearlogo', True)
    prepared = []
    overlay_samples = []
    skipped_cropv2 = 0
    skipped_fanart = 0
    for item in items:
        clone = _prepare_screensaver_overlay(item)
        props = clone.get('props') or {}
        if require_cropv2 and not str(props.get('screensaver_cropv2') or '').strip():
            skipped_cropv2 += 1
            if len(overlay_samples) < 80:
                overlay_samples.append({
                    'title': clone.get('label'), 'item_key': props.get('mediahub_item_key'),
                    'cropv2_status': props.get('screensaver_cropv2_status'),
                    'cropv2_path': props.get('screensaver_cropv2'),
                    'rating_status': props.get('screensaver_rating_status'),
                    'rating_count': props.get('screensaver_rating_count'),
                    'prepared': False, 'reason': 'cropv2_not_ready',
                })
            continue
        art = dict(clone.get('art') or {})
        candidates = list(clone.get('_fanart_candidates') or [])
        current = str(art.get('fanart') or '').strip()
        if current and current not in candidates:
            candidates.insert(0, current)
        valid = []
        for candidate in candidates:
            candidate = str(candidate or '').strip()
            if not candidate or candidate in valid:
                continue
            size = texture_size_from_db(candidate)
            if not size:
                continue
            width, height, _source = size
            if require_1080p and (int(width) < MIN_1080P_WIDTH or int(height) < MIN_1080P_HEIGHT):
                continue
            valid.append(candidate)
        if not valid:
            skipped_fanart += 1
            continue
        clone['_valid_fanart_candidates'] = valid
        prepared.append(clone)
        if len(overlay_samples) < 80:
            overlay_samples.append({
                'title': clone.get('label'), 'item_key': props.get('mediahub_item_key'),
                'cropv2_status': props.get('screensaver_cropv2_status'),
                'cropv2_path': props.get('screensaver_cropv2'),
                'rating_status': props.get('screensaver_rating_status'),
                'rating_count': props.get('screensaver_rating_count'),
                'prepared': True,
            })
    payload = {
        'version': 2, 'built_at': int(time.time()), 'source_items': len(items),
        'prepared_items': len(prepared), 'skipped_cropv2': skipped_cropv2,
        'skipped_fanart': skipped_fanart, 'elapsed_ms': int((time.time()-started)*1000),
        'overlay_samples': overlay_samples, 'items': prepared,
    }
    tmp = SCREENSAVER_CACHE_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(payload, fh, ensure_ascii=False, separators=(',', ':'), default=str)
        fh.flush()
        try:
            os.fsync(fh.fileno())
        except OSError:
            pass
    os.replace(tmp, SCREENSAVER_CACHE_FILE)
    with open(SCREENSAVER_STATUS_FILE, 'w', encoding='utf-8') as fh:
        json.dump({k:v for k,v in payload.items() if k not in ('items',)}, fh, indent=2, ensure_ascii=False)
    log('Screensaver cache v2 built: source={}, prepared={}, cropv2_skip={}, fanart_skip={}, elapsed_ms={}'.format(
        len(items), len(prepared), skipped_cropv2, skipped_fanart, payload['elapsed_ms']), xbmc.LOGINFO)
    return payload


def load_screensaver_cache(max_age=1800):
    try:
        if not os.path.isfile(SCREENSAVER_CACHE_FILE):
            return None
        with open(SCREENSAVER_CACHE_FILE, 'r', encoding='utf-8') as fh:
            payload = json.load(fh)
        if not isinstance(payload, dict) or not isinstance(payload.get('items'), list):
            return None
        if time.time() - float(payload.get('built_at') or 0) > max_age:
            return None
        return payload
    except Exception as exc:
        log('Screensaver cache read failed: {}'.format(exc), xbmc.LOGWARNING)
        return None


def cached_screensaver_items():
    payload = load_screensaver_cache()
    if payload is None:
        payload = _load_screensaver_cache_any_0133()
    if payload is None:
        payload = prepare_screensaver_cache(force=True)
    items = list(payload.get('items') or [])
    rnd = random_mod.Random()
    rnd.shuffle(items)
    items = items[:_screensaver_session_limit()]
    return [_screensaver_compactify_item_0133(item) for item in items]


# -----------------------------------------------------------------------------
# Directory output
# -----------------------------------------------------------------------------

def limit_and_sort(items, params):
    # All MediaHub widget output is unlimited by default. This also overrides
    # old widget URLs that still carry limit=100.
    force_unlimited = setting_bool("force_unlimited_output", True)
    default_limit = setting_int("default_limit", 0)
    limit = 0 if force_unlimited else as_int(
        params.get("limit"), default_limit
    )
    randomize = as_bool(params.get("random"), setting_bool("default_random", True))
    seed = params.get("seed") or ""

    if randomize:
        rnd = random_mod.Random(seed) if seed else random_mod.Random()
        rnd.shuffle(items)
    else:
        items.sort(key=lambda x: re.sub(r"^(the|a|an)\s+", "", x.get("label", "").lower()))

    if limit > 0:
        items = items[:limit]
    return items


def add_media_item(item, total=0):
    li = xbmcgui.ListItem(label=item.get("label") or "", offscreen=True)
    safe_set_info(li, item.get("info") or {})
    safe_set_art(li, item.get("art") or {})

    for k, v in (item.get("props") or {}).items():
        try:
            li.setProperty(str(k), str(v))
        except Exception:
            pass

    kind = item.get("kind") or "media"
    props = item.get("props") or {}
    stable_key = str(props.get("mediahub_item_key") or "").strip()
    if not stable_key:
        stable_key = mediahub_item_key(
            kind,
            props.get("dbid") or (item.get("info") or {}).get("dbid"),
            props.get("steam_appid") or props.get("appid"),
        )
    li.setProperty("mediahub_widget", "true")
    li.setProperty("mediahub_kind", kind)
    li.setProperty("source_addon", ADDON_ID)
    li.setProperty("mediahub_item_key", stable_key)

    if kind == "game":
        # Extra runtime aliases for services that inspect only focused ListItem props.
        li.setProperty("kpm_item_type", "game")
        li.setProperty("kpm_data_owner", ADDON_ID)
        li.setProperty("DBTYPE", "game")
        li.setProperty("dbtype", "game")
        li.setProperty("MediaType", "game")
        li.setProperty("mediatype", "game")

    if kind == "movie":
        li.addContextMenuItems([
            ("Play movie", "RunPlugin({})".format(item.get("url"))),
            ("Open library item", "ActivateWindow(Videos,videodb://movies/titles/{}/,return)".format(props.get("dbid") or item.get("info", {}).get("dbid") or "")),
            ("View item properties", "RunPlugin({})".format(url_for(mode="view_item_properties", kind=kind, dbid=props.get("dbid") or "", label=item.get("label") or ""))),
        ])
    elif kind == "series":
        li.addContextMenuItems([
            ("Open series", "RunPlugin({})".format(item.get("url"))),
            ("Open library item", "ActivateWindow(Videos,videodb://tvshows/titles/{}/,return)".format(props.get("dbid") or item.get("info", {}).get("dbid") or "")),
            ("View item properties", "RunPlugin({})".format(url_for(mode="view_item_properties", kind=kind, dbid=props.get("dbid") or "", label=item.get("label") or ""))),
        ])
    elif kind == "game":
        appid = props.get("steam_appid") or props.get("appid") or item.get("info", {}).get("dbid") or ""
        li.addContextMenuItems([
            ("Launch Steam game", "RunPlugin({})".format(item.get("url"))),
            ("Open in Steam Library", "ActivateWindow(Programs,plugin://{}?mode=list&collection=__all__,return)".format(steam_addon_id())),
            ("View game properties", "RunPlugin({})".format(url_for(mode="view_item_properties", kind=kind, appid=appid, label=item.get("label") or ""))),
        ])

    set_item_path(li, item.get("url"))
    xbmcplugin.addDirectoryItem(HANDLE, item.get("url"), li, bool(item.get("is_folder", False)), total)


def add_dir(label, mode, **kwargs):
    params = {"mode": mode}
    params.update(kwargs)
    url = url_for(**params)
    li = xbmcgui.ListItem(label=label, offscreen=True)
    li.setProperty("mediahub_widget_folder", "true")
    li.setProperty("kpm_item_type", "folder")
    li.setProperty("kpm_visual_clear", "true")
    li.setProperty("DBTYPE", "folder")
    safe_set_art(li, {"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
    safe_set_info(li, {"title": label, "plot": "MediaHub Widget path: {}".format(url)})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, True)


def root():
    add_dir("All Media: Movies + Series + Games", "mix", limit=0, random=str(setting_bool("default_random", True)).lower())
    add_dir("All Media: Random Screensaver Mix", "screensaver_mix", limit=0, random="true")
    add_dir("Movies only", "movies", limit=0, random=str(setting_bool("default_random", True)).lower())
    add_dir("Series / TV Shows only", "series", limit=0, random=str(setting_bool("default_random", True)).lower())
    add_dir("Steam Games only", "games", limit=0, random=str(setting_bool("default_random", True)).lower())
    add_dir("All Media: Unlimited / no limit", "mix", limit=0, random="false")

    add_dir("Tools", "tools")

    li = xbmcgui.ListItem(label="View Status", offscreen=True)
    safe_set_art(li, {"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="view_status"), li, False)

    li = xbmcgui.ListItem(label="Export diagnostics ZIP", offscreen=True)
    safe_set_art(li, {"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="export_diagnostics"), li, False)

    li = xbmcgui.ListItem(label="Settings", offscreen=True)
    safe_set_art(li, {"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="settings"), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def output_items(items, content="movies", params=None):
    params = params or {}
    # Choice 1: one item remains one slide; only its fanart is selected randomly.
    items = choose_one_random_cached_fanart_per_item(list(items), params)
    # Filter first, then randomize/limit. This prevents limit=100 from shrinking
    # to a smaller final list after low-quality artwork gets excluded.
    if not as_bool(params.get('_screensaver_cached'), False):
        items = apply_item_filters(items)
    items = limit_and_sort(items, params)
    try:
        xbmcplugin.setContent(HANDLE, content)
    except Exception:
        pass

    total = len(items)
    for item in items:
        add_media_item(item, total)

    try:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    except Exception:
        pass

    xbmcplugin.endOfDirectory(HANDLE)

    if setting_bool("force_poster_view", False):
        try:
            xbmc.executebuiltin("Container.SetViewMode({})".format(setting_int("poster_view_id", 502)))
        except Exception:
            pass


def mixed_items():
    items = []
    if setting_bool("include_movies", True):
        try:
            items.extend(library_movies())
        except Exception as exc:
            log("Movies read failed: {}".format(exc), xbmc.LOGERROR)
    if setting_bool("include_series", True):
        try:
            items.extend(library_series())
        except Exception as exc:
            log("Series read failed: {}".format(exc), xbmc.LOGERROR)
    if setting_bool("include_games", True):
        try:
            items.extend(steam_games())
        except Exception as exc:
            log("Games read failed: {}".format(exc), xbmc.LOGERROR)
    return items


# -----------------------------------------------------------------------------
# Actions
# -----------------------------------------------------------------------------

def play_movie(movieid):
    try:
        movieid_int = int(movieid)
        jsonrpc("Player.Open", {"item": {"movieid": movieid_int}})
    except Exception as exc:
        log("Play movie failed: {}".format(exc), xbmc.LOGERROR)
        notify("Gagal play movie")


def open_series(tvshowid):
    try:
        tvshowid_int = int(tvshowid)
        xbmc.executebuiltin("ActivateWindow(Videos,videodb://tvshows/titles/{}/,return)".format(tvshowid_int))
    except Exception as exc:
        log("Open series failed: {}".format(exc), xbmc.LOGERROR)
        notify("Gagal buka series")


def play_game(appid):
    appid = str(appid or "").strip()
    if not appid:
        return
    try:
        xbmc.executebuiltin("RunPlugin(plugin://{}?mode=play&appid={})".format(steam_addon_id(), urllib.parse.quote(appid)))
    except Exception as exc:
        log("Launch game failed: {}".format(exc), xbmc.LOGERROR)
        notify("Gagal launch game")



def _steam_db_path():
    return tr("special://profile/addon_data/{}/steam_library.db".format(steam_addon_id()))


def view_status():
    ensure_runtime_dirs()
    lines = [ADDON_NAME + " status", "=" * 60, "Addon ID: " + ADDON_ID]
    try:
        movies = library_movies() if setting_bool("include_movies", True) else []
        series = library_series() if setting_bool("include_series", True) else []
        games = steam_games() if setting_bool("include_games", True) else []
        lines.extend(["Movies: {}".format(len(movies)), "Series: {}".format(len(series)), "Steam games: {}".format(len(games))])
    except Exception as exc:
        lines.append("Status read error: {}".format(exc))
    lines.append("Steam Library DB: {}".format(_steam_db_path()))
    show_report(ADDON_NAME + " - View Status", "\n".join(lines))


def export_diagnostics():
    ensure_runtime_dirs()
    stamp = time.strftime("%Y%m%d-%H%M%S")
    zip_path = os.path.join(PROFILE, "mediahub-widget-diagnostics-{}.zip".format(stamp))
    tmp_path = zip_path + ".tmp"
    manifest = {"addon_id": ADDON_ID, "addon_name": ADDON_NAME, "addon_version": addon_instance().getAddonInfo("version"), "created_at": time.strftime("%Y-%m-%d %H:%M:%S"), "zip_layout": "runtime-v1"}
    try:
        with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
            settings_snapshot = {"include_movies": setting_bool("include_movies", True), "include_series": setting_bool("include_series", True), "include_games": setting_bool("include_games", True), "default_limit": setting_int("default_limit", 0), "force_unlimited_output": setting_bool("force_unlimited_output", True), "default_random": setting_bool("default_random", True), "steam_addon_id": steam_addon_id(), "exclude_fanart_below_1080p": setting_bool("exclude_fanart_below_1080p", True), "exclude_without_clearlogo": setting_bool("exclude_without_clearlogo", True)}
            zf.writestr("summary/settings-redacted.json", json.dumps(settings_snapshot, indent=2, ensure_ascii=False) + "\n")
            try:
                counts = {"movies": len(library_movies()), "series": len(library_series()), "games": len(steam_games())}
            except Exception as exc:
                counts = {"error": str(exc)}
            zf.writestr("summary/status.json", json.dumps(counts, indent=2, ensure_ascii=False) + "\n")
            steam_db = _steam_db_path()
            zf.writestr("reports/source-health.txt", "Steam DB: {}\nSteam DB exists: {}\n".format(steam_db, os.path.exists(steam_db)))
            if os.path.isfile(SCREENSAVER_STATUS_FILE):
                zf.write(SCREENSAVER_STATUS_FILE, 'runtime/state/screensaver-cache-status.json')
            if os.path.isfile(SCREENSAVER_CACHE_FILE):
                try:
                    cache_payload = load_screensaver_cache(max_age=10**9) or {}
                    zf.writestr('summary/screensaver-cache.txt',
                        'Version: {}\nBuilt at: {}\nSource items: {}\nPrepared items: {}\nSkipped CropV2: {}\nSkipped fanart: {}\nBuild elapsed ms: {}\nSession limit: {}\nCache bytes: {}\n'.format(
                            cache_payload.get('version'), cache_payload.get('built_at'), cache_payload.get('source_items'),
                            cache_payload.get('prepared_items'), cache_payload.get('skipped_cropv2'), cache_payload.get('skipped_fanart'), cache_payload.get('elapsed_ms'),
                            _screensaver_session_limit(), os.path.getsize(SCREENSAVER_CACHE_FILE)))
                    zf.writestr('summary/screensaver-overlay-samples.json', json.dumps(cache_payload.get('overlay_samples') or [], indent=2, ensure_ascii=False) + '\n')
                except Exception as exc:
                    zf.writestr('summary/screensaver-cache-error.txt', str(exc))
        with zipfile.ZipFile(tmp_path, "r") as test_zf:
            bad = test_zf.testzip()
            if bad:
                raise RuntimeError("Diagnostics ZIP validation failed at {}".format(bad))
        for name in os.listdir(PROFILE) if os.path.isdir(PROFILE) else []:
            if name.startswith("mediahub-widget-diagnostics-") and name.endswith(".zip"):
                try:
                    os.remove(os.path.join(PROFILE, name))
                except Exception:
                    pass
        os.replace(tmp_path, zip_path)
    except Exception:
        try:
            if os.path.isfile(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        raise
    notify("DIAGNOSTICS EXPORTED - MWH-{}".format(os.path.basename(zip_path).split("mediahub-widget-", 1)[-1]))

def tools_menu():
    opts = ["View Status", "Export diagnostics ZIP", "Settings", "Exit"]
    n = xbmcgui.Dialog().select(ADDON_NAME + " - Tools", opts)
    if n == 0:
        view_status()
    elif n == 1:
        export_diagnostics()
    elif n == 2:
        open_settings()


def view_item_properties(params):
    lines = ["MediaHub item properties", "=" * 60]
    for key in sorted(params):
        lines.append("{}: {}".format(key, params.get(key)))
    show_report(ADDON_NAME + " - Item Properties", "\n".join(lines))

def open_settings():
    try:
        xbmcaddon.Addon(ADDON_ID).openSettings()
    except Exception:
        xbmc.executebuiltin("Addon.OpenSettings({})".format(ADDON_ID))


# -----------------------------------------------------------------------------
# Router
# -----------------------------------------------------------------------------

def normalize_mode(mode):
    mode = (mode or "root").strip().lower()
    aliases = {
        "home_mix": "mix",
        "screensaver_mix": "mix",
        "all": "mix",
        "all_media": "mix",
        "tv": "series",
        "tvshows": "series",
        "shows": "series",
        "show": "series",
        "steam": "games",
        "steam_games": "games",
        "screensaver_movies": "movies",
        "screensaver_series": "series",
        "screensaver_games": "games",
        "home_movies": "movies",
        "home_series": "series",
        "home_games": "games",
    }
    return aliases.get(mode, mode)


def run():
    params = parse_params()
    raw_mode = str(params.get("mode", "root") or "root").strip().lower()
    if raw_mode.startswith("screensaver_"):
        params["_screensaver"] = "true"
    mode = normalize_mode(raw_mode)

    try:
        if mode == "root":
            root()
        elif mode == "mix":
            if is_screensaver_request(params):
                params['_screensaver_cached'] = 'true'
                output_items(cached_screensaver_items(), "movies", params)
            else:
                output_items(mixed_items(), "movies", params)
        elif mode == "movies":
            output_items(library_movies(), "movies", params)
        elif mode == "series":
            output_items(library_series(), "tvshows", params)
        elif mode == "games":
            output_items(steam_games(), "movies", params)
        elif mode == "play_movie":
            play_movie(params.get("movieid"))
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "open_series":
            open_series(params.get("tvshowid"))
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "play_game":
            play_game(params.get("appid"))
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "tools":
            tools_menu()
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "view_status":
            view_status()
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "export_diagnostics":
            export_diagnostics()
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "view_item_properties":
            view_item_properties(params)
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "settings":
            open_settings()
            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcplugin.endOfDirectory(HANDLE)
    except Exception as exc:
        log("Router error: {}\n{}".format(exc, traceback.format_exc()), xbmc.LOGERROR)
        try:
            li = xbmcgui.ListItem(label="MediaHub Widget error", offscreen=True)
            safe_set_info(li, {"title": "MediaHub Widget error", "plot": str(exc)})
            xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="root"), li, False)
            xbmcplugin.endOfDirectory(HANDLE)
        except Exception:
            pass


# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# v0.1.32 - proven live LRS screensaver bridge
# -----------------------------------------------------------------------------
# MediaHub owns slide selection, cached fanart, item identity and game slots.
# It does not read the LRS database, does not choose movie/series ratings and
# does not place rating/CropV2 output on ListItem properties. LRS publishes the
# live LibraryRatings.Screensaver.* namespace for the current slide.
SCREENSAVER_CACHE_CONTRACT_0132 = 4
SCREENSAVER_BRIDGE_MODE_0132 = "live-lrs-window-properties"


def _strip_r10_screensaver_overlay_props_0132(props):
    clean = {}
    for key, value in dict(props or {}).items():
        name = str(key or "")
        if name.startswith("screensaver_"):
            continue
        clean[name] = value
    return clean


def _screensaver_settings_signature_0132():
    values = {
        "exclude_without_clearlogo": setting_bool("exclude_without_clearlogo", True),
        "exclude_fanart_below_1080p": setting_bool("exclude_fanart_below_1080p", True),
        "include_movies": setting_bool("include_movies", True),
        "include_series": setting_bool("include_series", True),
        "include_games": setting_bool("include_games", True),
        "session_limit": _screensaver_session_limit(),
    }
    return hashlib.sha256(json.dumps(values, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def _file_signature_0132(path):
    try:
        stat = os.stat(path)
        return [int(stat.st_size), int(getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1000000000)))]
    except OSError:
        return [0, 0]


def _current_screensaver_input_signature_0132():
    payload = {
        "cache_contract": SCREENSAVER_CACHE_CONTRACT_0132,
        "bridge_mode": SCREENSAVER_BRIDGE_MODE_0132,
        "addon_version": str(addon_instance().getAddonInfo("version") or ""),
        "steam_db": _file_signature_0132(_steam_db_path()),
        "resolver_db": _file_signature_0132(KPM_CLEARLOGO_RESOLVER_DB),
        "settings": _screensaver_settings_signature_0132(),
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def prepare_screensaver_cache(force=False):
    """Build fanart/item cache only; ratings and CropV2 stay live-owned by LRS."""
    ensure_runtime_dirs()
    started = time.time()
    items = mixed_items()
    require_1080p = setting_bool("exclude_fanart_below_1080p", True)
    require_cropv2 = setting_bool("exclude_without_clearlogo", True)
    prepared = []
    samples = []
    skipped_cropv2 = 0
    skipped_fanart = 0

    for item in items:
        clone = dict(item)
        props = _strip_r10_screensaver_overlay_props_0132(clone.get("props") or {})
        art = dict(clone.get("art") or {})
        clone["props"] = props
        key = str(props.get("mediahub_item_key") or "").strip()
        source_logo = str(art.get("clearlogo") or "").strip()
        resolver = _resolver_cropv2(key, source_logo)

        # Preserve R9/R10 quality filtering, but never carry the resolved path
        # into the slide. LRS resolves and publishes the path live.
        if require_cropv2 and not str(resolver.get("path") or "").strip():
            skipped_cropv2 += 1
            if len(samples) < 100:
                samples.append({
                    "title": clone.get("label"), "item_key": key,
                    "cropv2_status": resolver.get("status"),
                    "prepared": False, "reason": "cropv2_not_ready",
                    "game_slot_count": sum(1 for i in range(1, 8) if props.get("RatingSlot{}_Label".format(i))),
                })
            continue

        candidates = list(clone.get("_fanart_candidates") or [])
        current = str(art.get("fanart") or "").strip()
        if current and current not in candidates:
            candidates.insert(0, current)
        valid = []
        for candidate in candidates:
            candidate = str(candidate or "").strip()
            if not candidate or candidate in valid:
                continue
            size = texture_size_from_db(candidate)
            if not size:
                continue
            width, height, _source = size
            if require_1080p and (int(width) < MIN_1080P_WIDTH or int(height) < MIN_1080P_HEIGHT):
                continue
            valid.append(candidate)
        if not valid:
            skipped_fanart += 1
            continue

        clone["_valid_fanart_candidates"] = valid
        prepared.append(clone)
        if len(samples) < 100:
            samples.append({
                "title": clone.get("label"), "item_key": key,
                "cropv2_status": resolver.get("status"),
                "cropv2_path": resolver.get("path"),
                "prepared": True,
                "game_slot_count": sum(1 for i in range(1, 8) if props.get("RatingSlot{}_Label".format(i))),
            })

    payload = {
        "version": SCREENSAVER_CACHE_CONTRACT_0132,
        "bridge_mode": SCREENSAVER_BRIDGE_MODE_0132,
        "built_at": int(time.time()),
        "input_signature": _current_screensaver_input_signature_0132(),
        "source_items": len(items),
        "prepared_items": len(prepared),
        "skipped_cropv2": skipped_cropv2,
        "skipped_fanart": skipped_fanart,
        "elapsed_ms": int((time.time() - started) * 1000),
        "live_bridge_samples": samples,
        "items": prepared,
    }
    tmp = SCREENSAVER_CACHE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"), default=str)
        handle.flush()
        try:
            os.fsync(handle.fileno())
        except OSError:
            pass
    os.replace(tmp, SCREENSAVER_CACHE_FILE)

    status_payload = {key: value for key, value in payload.items() if key != "items"}
    status_tmp = SCREENSAVER_STATUS_FILE + ".tmp"
    with open(status_tmp, "w", encoding="utf-8") as handle:
        json.dump(status_payload, handle, indent=2, ensure_ascii=False)
        handle.flush()
        try:
            os.fsync(handle.fileno())
        except OSError:
            pass
    os.replace(status_tmp, SCREENSAVER_STATUS_FILE)
    log("Screensaver live-bridge cache built: source={}, prepared={}, cropv2_skip={}, fanart_skip={}, elapsed_ms={}".format(
        len(items), len(prepared), skipped_cropv2, skipped_fanart, payload["elapsed_ms"]), xbmc.LOGINFO)
    return payload


def load_screensaver_cache(max_age=1800):
    try:
        if not os.path.isfile(SCREENSAVER_CACHE_FILE):
            return None
        with open(SCREENSAVER_CACHE_FILE, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
            return None
        if int(payload.get("version") or 0) != SCREENSAVER_CACHE_CONTRACT_0132:
            return None
        if str(payload.get("bridge_mode") or "") != SCREENSAVER_BRIDGE_MODE_0132:
            return None
        if time.time() - float(payload.get("built_at") or 0) > max_age:
            return None
        if str(payload.get("input_signature") or "") != _current_screensaver_input_signature_0132():
            return None
        return payload
    except Exception as exc:
        log("Screensaver live-bridge cache read failed: {}".format(exc), xbmc.LOGWARNING)
        return None


def _load_screensaver_cache_any_0133():
    try:
        if not os.path.isfile(SCREENSAVER_CACHE_FILE):
            return None
        with open(SCREENSAVER_CACHE_FILE, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if not isinstance(payload, dict) or not isinstance(payload.get('items'), list):
            return None
        if int(payload.get('version') or 0) != SCREENSAVER_CACHE_CONTRACT_0132:
            return None
        if str(payload.get('bridge_mode') or '') != SCREENSAVER_BRIDGE_MODE_0132:
            return None
        return payload
    except Exception as exc:
        log('Screensaver stale cache read failed: {}'.format(exc), xbmc.LOGWARNING)
        return None


def _screensaver_compactify_item_0133(item):
    clone = dict(item or {})
    props = dict(clone.get('props') or {})
    minutes = 0
    try:
        minutes = int(float(str(props.get('playtime_forever') or '').strip()))
    except Exception:
        minutes = 0
    for idx in range(1, 8):
        source_key = 'RatingSlot{}_Source'.format(idx)
        label_key = 'RatingSlot{}_Label'.format(idx)
        value_key = 'RatingSlot{}_Value'.format(idx)
        if str(props.get(source_key) or '').strip() != 'steam_playtime':
            continue
        slot_minutes = minutes or _minutes_from_playtime_label_0133(props.get(label_key) or props.get(value_key) or '')
        compact = format_playtime_compact_0133(slot_minutes)
        if compact:
            props[label_key] = compact
            props[value_key] = compact
            props['playtime_display'] = compact
    clone['props'] = props
    return clone


if __name__ == "__main__":
    run()

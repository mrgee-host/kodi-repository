MediaHub Widget 0.1.26
- Adds persistent prepared screensaver cache and a 300-item session sample.
- Folder items explicitly clear KPM visual rows.
- Diagnostics include screensaver cache timing and size.
- Fixes Settings opening twice.
- Notification maximum remains 58 characters.

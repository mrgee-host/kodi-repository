# -*- coding: utf-8 -*-
from __future__ import annotations
import time
import xbmc
from addon import prepare_screensaver_cache, load_screensaver_cache, log

class Monitor(xbmc.Monitor):
    pass

if __name__ == '__main__':
    monitor = Monitor()
    monitor.waitForAbort(8.0)
    while not monitor.abortRequested():
        try:
            if load_screensaver_cache(max_age=1800) is None and not xbmc.getCondVisibility('Player.HasMedia'):
                prepare_screensaver_cache(force=True)
        except Exception as exc:
            log('Screensaver cache service failed: {}'.format(exc), xbmc.LOGWARNING)
        if monitor.waitForAbort(300.0):
            break

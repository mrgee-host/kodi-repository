MediaHub Widget 0.1.25
- Diagnostics and runtime layout aligned with the Kodi family standard.
- Uppercase compact notifications.
- Short status uses a normal dialog; long status remains scrollable.

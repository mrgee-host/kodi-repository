plugin.video.mediahub.widget 0.1.27 - R4

MrGee Kodi Family R4 runtime and consistency fixes.

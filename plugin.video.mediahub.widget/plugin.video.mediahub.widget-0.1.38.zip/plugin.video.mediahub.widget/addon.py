# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import glob
import hashlib
import os
import random as random_mod
import re
import struct
import sqlite3
import sys
import traceback
import urllib.parse
import time
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


ADDON_ID = "plugin.video.mediahub.widget"


def addon_instance():
    """Return a short-lived Addon wrapper.

    Plugin invocations are brief. Keeping xbmcaddon.Addon at module scope can
    leave a SWIG wrapper referenced when the Python invoker tears down.
    """
    return xbmcaddon.Addon(ADDON_ID)


def _addon_name():
    addon = addon_instance()
    try:
        return addon.getAddonInfo("name") or "MediaHub Widget"
    finally:
        del addon


ADDON_NAME = _addon_name()
KPM_SHARED_ICON_BASE = "special://home/addons/script.kodi.patch.manager/resources/media/shared-icons"


def kpm_shared_icon(filename):
    return KPM_SHARED_ICON_BASE.rstrip("/") + "/" + filename


BASE_URL = sys.argv[0]
HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and str(sys.argv[1]).lstrip("-").isdigit() else -1

STEAM_DEFAULT_ADDON_ID = "plugin.program.steam.library"


# -----------------------------------------------------------------------------
# Small Kodi-safe helpers
# -----------------------------------------------------------------------------

def log(msg, level=xbmc.LOGINFO):
    try:
        xbmc.log("[{}] {}".format(ADDON_NAME, msg), level)
    except Exception:
        pass


def tr(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        try:
            return xbmc.translatePath(path)
        except Exception:
            return path


PROFILE = tr("special://profile/addon_data/{}/".format(ADDON_ID))
CACHE_DIR = os.path.join(PROFILE, "cache")
RUNTIME_DIR = os.path.join(PROFILE, "runtime")
STATE_DIR = os.path.join(RUNTIME_DIR, "state")
DIAG_DIR = os.path.join(RUNTIME_DIR, "diagnostics")
REPORTS_DIR = os.path.join(RUNTIME_DIR, "reports")
LOGS_DIR = os.path.join(RUNTIME_DIR, "logs")
EXPORTS_DIR = os.path.join(RUNTIME_DIR, "exports")
SCREENSAVER_CACHE_FILE = os.path.join(CACHE_DIR, 'screensaver-items-v2.json')
SCREENSAVER_STATUS_FILE = os.path.join(STATE_DIR, 'screensaver-cache-status.json')


def ensure_runtime_dirs():
    for folder in (PROFILE, CACHE_DIR, RUNTIME_DIR, STATE_DIR, DIAG_DIR, REPORTS_DIR, LOGS_DIR, EXPORTS_DIR):
        try:
            os.makedirs(folder, exist_ok=True)
        except Exception:
            pass


def setting(key, default=""):
    addon = None
    try:
        addon = addon_instance()
        value = addon.getSetting(key)
        return value if value != "" else default
    except Exception:
        return default
    finally:
        if addon is not None:
            del addon


def setting_bool(key, default=False):
    value = str(setting(key, "")).strip().lower()
    if value == "":
        return bool(default)
    return value in ("1", "true", "yes", "on")


def setting_int(key, default=0):
    try:
        return int(setting(key, str(default)))
    except Exception:
        return int(default)


def clean_text(value):
    if value is None:
        return ""
    text = str(value)
    text = re.sub(r"<[^>]+>", "", text)
    text = text.replace("&amp;", "&").replace("&quot;", '"').replace("&#39;", "'")
    return text.strip()


def as_bool(value, default=False):
    if value is None or str(value).strip() == "":
        return default
    return str(value).strip().lower() in ("1", "true", "yes", "on", "random")

def truthy(value, default=False):
    """Kodi-safe bool parser for Steam DB fields.

    Handles both numeric flags (1/0) and textual values sometimes written by
    older Steam/MediaHub cache versions.
    """
    if value is None or str(value).strip() == "":
        return bool(default)
    text = str(value).strip().lower()
    if text in ("0", "false", "no", "off", "none", "null", "n/a", "na", "-"):
        return False
    return text in ("1", "true", "yes", "on", "completed", "complete", "finished", "finish", "done", "random")


def as_int(value, default=0):
    try:
        return int(value)
    except Exception:
        return default


def url_for(**kwargs):
    return BASE_URL + "?" + urllib.parse.urlencode(kwargs)


def parse_params():
    try:
        raw = sys.argv[2][1:] if len(sys.argv) > 2 and sys.argv[2].startswith("?") else ""
        return dict(urllib.parse.parse_qsl(raw))
    except Exception:
        return {}


def set_item_path(li, path):
    try:
        li.setPath(path)
    except Exception:
        pass


def _int_value(value, default=0):
    try:
        return int(value)
    except Exception:
        return int(default)


def _float_value(value, default=0.0):
    try:
        return float(value)
    except Exception:
        return float(default)


def _string_list(value):
    if isinstance(value, (list, tuple)):
        return [str(part).strip() for part in value if str(part).strip()]
    text = str(value or "").strip()
    if not text:
        return []
    # Existing MWH readers join JSON-RPC arrays with " / ". Preserve names
    # containing commas while restoring those joined arrays to Kodi lists.
    if " / " in text:
        return [part.strip() for part in text.split(" / ") if part.strip()]
    return [text]


def _set_tag_value(tag, method_name, value, converter=None):
    if value in (None, ""):
        return
    method = getattr(tag, method_name, None)
    if not callable(method):
        return
    try:
        method(converter(value) if converter else value)
    except Exception as exc:
        log(
            "InfoTagVideo {} failed for {!r}: {}".format(method_name, value, exc),
            xbmc.LOGDEBUG,
        )


def safe_set_info(li, info):
    """Populate video metadata through InfoTagVideo on Kodi 20+.

    ListItem.setInfo("video", ...) is intentionally not used on supported Kodi
    versions, removing one warning per item while preserving custom properties.
    """
    clean = dict(info or {})
    try:
        tag = li.getVideoInfoTag()
    except Exception as exc:
        log("getVideoInfoTag failed: {}".format(exc), xbmc.LOGDEBUG)
        return

    runtime_value = clean.get("runtime")
    if runtime_value not in (None, ""):
        # Retain the custom aliases used by skin XML while using the canonical
        # video tag for Kodi's duration field.
        try:
            li.setProperty("runtime", str(runtime_value))
            li.setProperty("duration", str(runtime_value))
        except Exception:
            pass

    scalar_map = (
        ("title", "setTitle", str),
        ("originaltitle", "setOriginalTitle", str),
        ("sorttitle", "setSortTitle", str),
        ("plot", "setPlot", str),
        ("plotoutline", "setPlotOutline", str),
        ("tagline", "setTagLine", str),
        ("year", "setYear", _int_value),
        ("userrating", "setUserRating", _int_value),
        ("playcount", "setPlaycount", _int_value),
        ("mpaa", "setMpaa", str),
        ("premiered", "setPremiered", str),
        ("dateadded", "setDateAdded", str),
        ("lastplayed", "setLastPlayed", str),
        ("episode", "setEpisode", _int_value),
        ("season", "setSeason", _int_value),
        ("runtime", "setDuration", _int_value),
        ("mediatype", "setMediaType", str),
        ("dbid", "setDbId", _int_value),
    )
    for key, method_name, converter in scalar_map:
        if key in clean:
            _set_tag_value(tag, method_name, clean.get(key), converter)

    if clean.get("genre") not in (None, ""):
        _set_tag_value(tag, "setGenres", _string_list(clean.get("genre")))
    if clean.get("studio") not in (None, ""):
        _set_tag_value(tag, "setStudios", _string_list(clean.get("studio")))
    if clean.get("director") not in (None, ""):
        _set_tag_value(tag, "setDirectors", _string_list(clean.get("director")))
    if clean.get("writer") not in (None, ""):
        _set_tag_value(tag, "setWriters", _string_list(clean.get("writer")))

    rating = _float_value(clean.get("rating"), 0.0)
    if rating:
        try:
            tag.setRating(rating, 0, "default", True)
        except Exception as exc:
            log("InfoTagVideo setRating failed: {}".format(exc), xbmc.LOGDEBUG)

    resume_time = _float_value(
        clean.get("resumetime", clean.get("resume_time", 0.0)), 0.0
    )
    total_time = _float_value(
        clean.get("totaltime", clean.get("total_time", runtime_value or 0.0)), 0.0
    )
    if resume_time or total_time:
        try:
            tag.setResumePoint(resume_time, total_time)
        except Exception as exc:
            log("InfoTagVideo setResumePoint failed: {}".format(exc), xbmc.LOGDEBUG)


def safe_set_art(li, art):
    clean = {k: v for k, v in (art or {}).items() if v and str(v).strip()}
    if not clean:
        return
    try:
        li.setArt(clean)
    except Exception as exc:
        log("setArt failed: {}".format(exc), xbmc.LOGDEBUG)


def _family_message_r4(message, limit=58):
    text = re.sub(r"\s+", " ", str(message or "").strip()).upper().rstrip()
    if len(text) <= int(limit):
        return text
    parts = text.replace(" • ", " - ").split(" - ")
    protected = ("ERROR", "FAILED", "UPDATED", "ARTWORK", "ITEM", "CACHED", "MOVED", "SCRAPED", "N/A")
    if len(parts) > 1 and any(token in " - ".join(parts[1:]) for token in protected):
        suffix = " - " + " - ".join(parts[1:])
        budget = max(4, int(limit) - len(suffix))
        action = parts[0]
        if len(action) > budget:
            action = action[:max(1, budget - 3)].rstrip() + "..."
        return (action + suffix)[:int(limit)].rstrip()
    raw = text[:max(1, int(limit) - 3)].rstrip()
    return (raw.rsplit(" ", 1)[0] if " " in raw else raw) + "..."


def notify(message):
    try:
        xbmcgui.Dialog().notification(ADDON_NAME, _family_message_r4(message, 58), xbmcgui.NOTIFICATION_INFO, 5000)
    except Exception:
        pass


def show_report(title, message):
    body = str(message or "").strip()
    if len(body) <= 520 and len(body.splitlines()) <= 7:
        xbmcgui.Dialog().ok(str(title or ADDON_NAME), body or "NO DETAILS")
    else:
        xbmcgui.Dialog().textviewer(str(title or ADDON_NAME), body)


# -----------------------------------------------------------------------------
# JSON-RPC video library readers
# -----------------------------------------------------------------------------

def jsonrpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    data = json.loads(raw or "{}")
    if data.get("error"):
        raise RuntimeError("{}: {}".format(method, data["error"]))
    return data.get("result") or {}


def collect_fanart_candidates(raw, primary=""):
    """Collect main fanart and registered extra fanart without opening remote URLs."""
    values = []
    seen = set()

    def add(value):
        value = str(value or "").strip()
        if not value or value in seen:
            return
        seen.add(value)
        values.append(value)

    add(primary)
    art = raw.get("art") if isinstance(raw, dict) else {}
    if isinstance(art, dict):
        for key, value in art.items():
            name = str(key or "").strip().lower()
            if re.search(r"(^|\.)(?:extra)?fanart(?:\d+)?$", name):
                add(value)
    if isinstance(raw, dict):
        add(raw.get("fanart"))
    return values


def pick_art(raw, media_type="movie"):
    art = raw.get("art") if isinstance(raw, dict) else {}
    if not isinstance(art, dict):
        art = {}

    poster = art.get("poster") or art.get("tvshow.poster") or raw.get("thumbnail") or ""
    thumb = art.get("thumb") or raw.get("thumbnail") or poster
    fanart = art.get("fanart") or art.get("tvshow.fanart") or raw.get("fanart") or ""
    landscape = art.get("landscape") or art.get("tvshow.landscape") or fanart or thumb
    clearlogo = art.get("clearlogo") or art.get("tvshow.clearlogo") or ""
    banner = art.get("banner") or art.get("tvshow.banner") or ""

    return {
        "poster": poster,
        "thumb": thumb,
        "icon": thumb or poster,
        "fanart": fanart,
        "landscape": landscape,
        "clearlogo": clearlogo,
        "banner": banner,
    }


def first_number(value, default=0):
    try:
        if isinstance(value, (int, float)):
            return value
        text = str(value or "").strip()
        return float(text) if text else default
    except Exception:
        return default


def fmt_percent(value):
    text = str(value or '').strip()
    if not text or text.upper() in ('N/A', 'NA', 'NONE', 'NULL', '-'):
        return ''
    if text.endswith('%'):
        return text
    try:
        num = float(text)
        text = str(int(num)) if num.is_integer() else ('%.1f' % num).rstrip('0').rstrip('.')
        return text + '%'
    except Exception:
        return text


def genre_text(value):
    if isinstance(value, list):
        return " / ".join([str(x) for x in value if str(x).strip()])
    return str(value or "")


def mediahub_item_key(kind, dbid="", steam_appid=""):
    """Return the stable item identity shared with LRS and KPM."""
    kind = str(kind or "").strip().lower()
    if kind == "movie" and str(dbid or "").strip():
        return "movie|{}".format(str(dbid).strip())
    if kind in ("series", "tvshow") and str(dbid or "").strip():
        return "tvshow|{}".format(str(dbid).strip())
    if kind == "game" and str(steam_appid or dbid or "").strip():
        return "game|steam|{}".format(str(steam_appid or dbid).strip())
    return ""


def library_movies():
    props = [
        "title", "originaltitle", "sorttitle", "year", "genre", "plot", "plotoutline",
        "tagline", "rating", "userrating", "playcount", "runtime", "studio", "director",
        "writer", "mpaa", "premiered", "dateadded", "lastplayed", "thumbnail", "fanart", "art",
    ]
    fallback_props = ["title", "year", "genre", "plot", "rating", "thumbnail", "fanart", "art"]
    params = {
        "properties": props,
        "sort": {"method": "title", "order": "ascending", "ignorearticle": True},
        "limits": {"start": 0, "end": 100000},
    }
    try:
        result = jsonrpc("VideoLibrary.GetMovies", params)
    except Exception:
        params["properties"] = fallback_props
        result = jsonrpc("VideoLibrary.GetMovies", params)

    items = []
    for m in result.get("movies", []) or []:
        movieid = m.get("movieid")
        title = m.get("title") or "Movie {}".format(movieid)
        plot = clean_text(m.get("plot") or m.get("plotoutline") or "")
        year = as_int(m.get("year"), 0)
        art = pick_art(m, "movie")
        fanart_candidates = collect_fanart_candidates(m, art.get("fanart"))
        url = url_for(mode="play_movie", movieid=movieid)
        items.append({
            "kind": "movie",
            "label": title,
            "url": url,
            "is_folder": False,
            "art": art,
            "_fanart_candidates": fanart_candidates,
            "info": {
                "mediatype": "movie",
                "dbid": int(movieid) if str(movieid).isdigit() else 0,
                "title": title,
                "originaltitle": m.get("originaltitle") or title,
                "sorttitle": m.get("sorttitle") or title,
                "plot": plot,
                "plotoutline": clean_text(m.get("plotoutline") or plot),
                "tagline": clean_text(m.get("tagline") or ""),
                "year": year,
                "genre": genre_text(m.get("genre")),
                "rating": first_number(m.get("rating"), 0),
                "userrating": as_int(m.get("userrating"), 0),
                "playcount": as_int(m.get("playcount"), 0),
                "runtime": as_int(m.get("runtime"), 0),
                "studio": genre_text(m.get("studio")),
                "mpaa": m.get("mpaa") or "",
                "premiered": m.get("premiered") or "",
                "dateadded": m.get("dateadded") or "",
                "lastplayed": m.get("lastplayed") or "",
            },
            "props": {
                "mediahub_type": "movie",
                "mediahub_item_key": mediahub_item_key("movie", movieid),
                "dbid": str(movieid or ""),
                "source": "Kodi Movies",
                "IsPlayable": "true",
            },
        })
    return items


def library_series():
    props = [
        "title", "year", "genre", "plot", "rating", "userrating", "playcount", "studio",
        "mpaa", "premiered", "dateadded", "lastplayed", "thumbnail", "fanart", "art",
        "episode", "season",
    ]
    fallback_props = ["title", "year", "genre", "plot", "rating", "thumbnail", "fanart", "art"]
    params = {
        "properties": props,
        "sort": {"method": "title", "order": "ascending", "ignorearticle": True},
        "limits": {"start": 0, "end": 100000},
    }
    try:
        result = jsonrpc("VideoLibrary.GetTVShows", params)
    except Exception:
        params["properties"] = fallback_props
        result = jsonrpc("VideoLibrary.GetTVShows", params)

    items = []
    for s in result.get("tvshows", []) or []:
        tvshowid = s.get("tvshowid")
        title = s.get("title") or "Series {}".format(tvshowid)
        plot = clean_text(s.get("plot") or "")
        year = as_int(s.get("year"), 0)
        art = pick_art(s, "tvshow")
        fanart_candidates = collect_fanart_candidates(s, art.get("fanart"))
        url = url_for(mode="open_series", tvshowid=tvshowid)
        episode = as_int(s.get("episode"), 0)
        season = as_int(s.get("season"), 0)
        items.append({
            "kind": "series",
            "label": title,
            "url": url,
            "is_folder": False,
            "art": art,
            "_fanart_candidates": fanart_candidates,
            "info": {
                "mediatype": "tvshow",
                "dbid": int(tvshowid) if str(tvshowid).isdigit() else 0,
                "title": title,
                "sorttitle": title,
                "plot": plot,
                "plotoutline": plot,
                "year": year,
                "genre": genre_text(s.get("genre")),
                "rating": first_number(s.get("rating"), 0),
                "userrating": as_int(s.get("userrating"), 0),
                "playcount": as_int(s.get("playcount"), 0),
                "studio": genre_text(s.get("studio")),
                "mpaa": s.get("mpaa") or "",
                "premiered": s.get("premiered") or "",
                "dateadded": s.get("dateadded") or "",
                "lastplayed": s.get("lastplayed") or "",
                "episode": episode,
                "season": season,
            },
            "props": {
                "mediahub_type": "series",
                "mediahub_item_key": mediahub_item_key("tvshow", tvshowid),
                "dbid": str(tvshowid or ""),
                "source": "Kodi TV Shows",
                "episode_count": str(episode),
                "season_count": str(season),
                "IsPlayable": "false",
            },
        })
    return items


# -----------------------------------------------------------------------------
# Steam Library reader
# -----------------------------------------------------------------------------

def steam_db_path():
    custom = setting("steam_db_path", "").strip()
    if custom:
        return tr(custom)
    steam_addon_id = setting("steam_addon_id", STEAM_DEFAULT_ADDON_ID).strip() or STEAM_DEFAULT_ADDON_ID
    return tr("special://profile/addon_data/{}/steam_library.db".format(steam_addon_id))


def steam_addon_id():
    return setting("steam_addon_id", STEAM_DEFAULT_ADDON_ID).strip() or STEAM_DEFAULT_ADDON_ID


def db_col_exists(cols, name):
    return name in cols




def format_playtime_forever(minutes, with_prefix=False):
    try:
        value = int(float(str(minutes or '').strip()))
    except Exception:
        value = 0
    if value <= 0:
        return ''
    if value < 120:
        body = '{0} minutes'.format(value)
    else:
        hours = round(value / 60.0, 1)
        body = '{0} hours'.format(int(hours) if float(hours).is_integer() else '{0:.1f}'.format(hours))
    return body

def format_playtime_compact_0133(minutes):
    try:
        value = int(float(str(minutes or '').strip()))
    except Exception:
        value = 0
    if value <= 0:
        return ''
    if value < 120:
        return '{0}m'.format(value)
    hours = round(value / 60.0, 1)
    return '{0}h'.format(int(hours) if float(hours).is_integer() else '{0:.1f}'.format(hours))


def _minutes_from_playtime_label_0133(label):
    text = str(label or '').strip().lower()
    if not text:
        return 0
    try:
        if text.endswith(' minutes'):
            return int(float(text[:-8].strip()))
        if text.endswith(' minute'):
            return int(float(text[:-7].strip()))
        if text.endswith(' hours'):
            return int(round(float(text[:-6].strip()) * 60.0))
        if text.endswith(' hour'):
            return int(round(float(text[:-5].strip()) * 60.0))
        if text.endswith('m'):
            return int(float(text[:-1].strip()))
        if text.endswith('h'):
            return int(round(float(text[:-1].strip()) * 60.0))
    except Exception:
        return 0
    return 0


def build_game_row_alias_props_0117(g, steam_score, mc_score):
    """Stable game-row aliases in canonical order for diagnostics/fallbacks.

    KPM remains the visual owner; these properties only expose a complete item
    snapshot and never patch AF3 directly.
    """
    steam_label = steam_rating_display(g)
    if steam_label == "N/A":
        steam_label = ""
    mc_label = str(mc_score or "").strip()
    ach_label = steam_achievement_display(g)
    if ach_label == "N/A":
        ach_label = ""
    playtime_label = format_playtime_forever(g.get("playtime_forever"), with_prefix=False)
    slots = []
    if steam_label:
        slots.append(("steam", "steam.png", steam_label))
    if mc_label and mc_label != "0":
        slots.append(("metacritic", "metacritic.png", mc_label))
    if ach_label:
        slots.append(("achievement", "steam-ach.png", ach_label))
    if playtime_label:
        slots.append(("steam_playtime", "ends.png", playtime_label))
    props = {"GameRowOrder": ",".join(x[0] for x in slots), "RatingSlotCount": str(len(slots))}
    for idx, (source, icon, label) in enumerate(slots, start=1):
        props["RatingSlot{}_Source".format(idx)] = source
        props["RatingSlot{}_IconFile".format(idx)] = icon
        props["RatingSlot{}_Label".format(idx)] = label
        props["RatingSlot{}_Value".format(idx)] = label
    return props


def game_kpm_props(g, appid, steam_score, mc_score):
    steam_label = steam_rating_display(g)
    if steam_label == "N/A":
        steam_label = ""
    mc_label = str(mc_score or "").strip()
    ach_unlocked = g.get("achievement_unlocked")
    ach_total = g.get("achievement_total")
    ach_label = "{}/{}".format(ach_unlocked or "0", ach_total) if ach_total else ""
    completed = truthy(g.get("completed"))
    finished = truthy(g.get("finished"))
    return {
        "kpm_item_type": "game",
        "lrs_item_type": "game",
        "mediahub_type": "game",
        "mediahub_item_key": mediahub_item_key("game", steam_appid=appid),
        "DBTYPE": "game",
        "dbtype": "game",
        "MediaType": "game",
        "mediatype": "game",
        "kpm_data_owner": "plugin.video.mediahub.widget",
        "kpm_game_row_ready": "true",
        "kpm_game_row_schema": "2",
        "kpm_game_row_order": "steam,metacritic,achievement,playtime",
        "platform": "steam",
        "steam_appid": str(appid or ""),
        "steam_rating_display": steam_label,
        "steam_review_percent": str(steam_score or ""),
        "steam_review_desc": str(g.get("steam_review_desc") or ""),
        "steam_review_total": str(g.get("steam_review_total") or ""),
        "steam250_rank": str(g.get("steam250_rank") or ""),
        "steam250_score": str(g.get("steam250_score") or ""),
        "steam250_rank_display": steam250_rank_display(g),
        "metacritic_score": str(mc_score or ""),
        "achievement_unlocked": str(ach_unlocked or ""),
        "achievement_total": str(ach_total or ""),
        "achievement_display": ach_label,
        "playtime_forever": str(g.get("playtime_forever") or ""),
        "playtime_display": format_playtime_forever(g.get("playtime_forever"), with_prefix=False),
        "completed": "true" if completed else "false",
        "finished": "true" if finished else "false",
        "completed_bool": "true" if completed else "",
        "finished_bool": "true" if finished else "",
        "kpm_shared_icon_base": KPM_SHARED_ICON_BASE,
    }

def steam_display_or_na(value):
    txt = str(value or "").strip()
    return txt if txt and txt.upper() != "N/A" else "N/A"


def first_credit(value):
    text = str(value or "").strip()
    if not text or text.upper() == "N/A":
        return "N/A"
    parts = re.split(r"\s*/\s*|\s*;\s*|\s*,\s*", text)
    for part in parts:
        part = part.strip()
        if part:
            return part
    return text


def steam_achievement_display(g):
    unlocked = steam_display_or_na(g.get("achievement_unlocked"))
    total = steam_display_or_na(g.get("achievement_total"))
    if total != "N/A":
        return "{}/{}".format("0" if unlocked == "N/A" else unlocked, total)
    return "N/A"


def steam_rating_display(g):
    pct = steam_display_or_na(g.get("steam_review_percent"))
    rank = steam_display_or_na(g.get("steam250_rank"))
    parts = []
    if pct != "N/A":
        parts.append("{}%".format(pct))
    if rank != "N/A":
        rank = str(rank).strip().lstrip("#")
        if rank:
            parts.append("#{}".format(rank))
    return " ".join(parts) if parts else "N/A"


def steam250_rank_display(g):
    rank = steam_display_or_na(g.get("steam250_rank"))
    if rank == "N/A":
        return "N/A"
    rank = str(rank).strip().lstrip("#")
    return "#{}".format(rank) if rank else "N/A"


def normalize_age_rating_value(value):
    txt = steam_display_or_na(value)
    if txt == "N/A":
        return "N/A"

    raw = str(txt).strip()
    upper = raw.upper()

    # Remove provider/presentation prefixes so the UI never shows ESRB/PEGI.
    upper = re.sub(r"^\s*(ESRB|PEGI|USK|CERO|GRAC|CLASSIND)\s*[:\-]?\s*", "", upper)
    upper = re.sub(r"^\s*RATING\s*[:\-]?\s*", "", upper)
    upper = upper.strip()

    esrb_map = {
        "EC": "3+",
        "E": "6+",
        "EVERYONE": "6+",
        "E10": "10+",
        "E10+": "10+",
        "EVERYONE 10+": "10+",
        "T": "13+",
        "TEEN": "13+",
        "M": "17+",
        "MATURE": "17+",
        "MATURE 17+": "17+",
        "AO": "18+",
        "ADULTS ONLY": "18+",
        "ADULTS ONLY 18+": "18+",
    }
    if upper in esrb_map:
        return esrb_map[upper]

    if upper in ("RP", "RATING PENDING", "PENDING", "UNRATED", "NR", "N/A", "NA", "NONE", "0"):
        return "N/A"

    # PEGI/required_age numeric values, including values already saved as 16+.
    m = re.search(r"(\d{1,2})\s*\+?", upper)
    if m:
        age = m.group(1)
        if age == "0":
            return "N/A"
        return "{}+".format(age)

    return "N/A"


def steam_age_rating_display(g):
    esrb_age = normalize_age_rating_value(g.get("esrb"))
    pegi_age = normalize_age_rating_value(g.get("pegi"))
    if esrb_age != "N/A":
        return "Rating {}".format(esrb_age)
    if pegi_age != "N/A":
        return "Rating {}".format(pegi_age)
    return "N/A"


def steam_tagline_display(g):
    tagline = steam_display_or_na(clean_text(g.get("tagline")))
    if tagline != "N/A":
        return tagline
    return steam_display_or_na(g.get("genres"))

def steam_games():
    path = steam_db_path()
    if not path or not os.path.exists(path):
        log("Steam database not found: {}".format(path), xbmc.LOGWARNING)
        return []

    con = None
    try:
        con = sqlite3.connect(path)
        con.row_factory = sqlite3.Row
        cur = con.cursor()
        cur.execute("PRAGMA table_info(games)")
        cols = set([r[1] for r in cur.fetchall()])
        if not cols:
            return []

        select_cols = [
            "appid", "name", "steam_name", "display_name", "sortname", "year", "developer", "publisher", "genres", "tagline", "short_description",
            "steam_review_percent", "steam_review_desc", "steam_review_total", "steam250_rank",
            "steam250_score", "achievement_unlocked", "achievement_total", "completed", "finished",
            "metacritic_score", "playtime_forever", "esrb", "pegi",
            "poster_url", "thumb_url", "clearlogo_url", "fanart_url", "fanart1_url", "fanart2_url",
            "fanart3_url", "fanart4_url",
        ]
        usable_cols = [c for c in select_cols if db_col_exists(cols, c)]
        cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='library_membership'")
        has_membership = bool(cur.fetchone())
        sql = "SELECT {} FROM games".format(", ".join(["games.{0} AS {0}".format(c) for c in usable_cols]))
        clauses = []
        if has_membership:
            sql += " JOIN library_membership ON library_membership.appid=games.appid"
            clauses.append("library_membership.is_active=1")
        args = []

        exclude_hidden = setting_bool("exclude_hidden_games", True)
        if exclude_hidden:
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='hidden_games'")
            if cur.fetchone():
                clauses.append("games.appid NOT IN (SELECT appid FROM hidden_games)")
            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='manual_hidden_games'")
            if cur.fetchone():
                clauses.append("games.appid NOT IN (SELECT appid FROM manual_hidden_games)")
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        order_cols = [c for c in ("sortname", "display_name", "name", "steam_name", "appid") if c in cols]
        if order_cols:
            exprs = ["NULLIF(games.{0},'')".format(c) for c in order_cols[:-1]] + ["games.{0}".format(order_cols[-1])]
            sql += " ORDER BY COALESCE({}) COLLATE NOCASE".format(", ".join(exprs))
        rows = cur.execute(sql, args).fetchall()
    except Exception as exc:
        log("Steam DB read failed: {}\n{}".format(exc, traceback.format_exc()), xbmc.LOGERROR)
        return []
    finally:
        try:
            if con:
                con.close()
        except Exception:
            pass

    items = []
    for row in rows:
        g = dict(row)
        appid = str(g.get("appid") or "").strip()
        if not appid:
            continue
        title = clean_text(g.get("display_name") or g.get("name") or g.get("steam_name") or "Steam App {}".format(appid))
        plot = clean_text(g.get("short_description") or "")
        raw_genres = str(g.get("genres") or "").strip()
        tagline_text = steam_tagline_display(g)
        tagline_for_ui = "" if tagline_text == "N/A" else tagline_text
        age_rating_for_ui = steam_age_rating_display(g)
        poster = g.get("poster_url") or ""
        thumb = g.get("thumb_url") or poster
        fanart_candidates = []
        for candidate in (
            g.get("fanart_url"), g.get("fanart1_url"), g.get("fanart2_url"),
            g.get("fanart3_url"), g.get("fanart4_url"),
        ):
            candidate = str(candidate or "").strip()
            if candidate and candidate not in fanart_candidates:
                fanart_candidates.append(candidate)
        fanart = (fanart_candidates[0] if fanart_candidates else "") or thumb
        clearlogo = g.get("clearlogo_url") or ""
        steam_score = as_int(g.get("steam_review_percent"), 0)
        mc_score = as_int(g.get("metacritic_score"), 0)
        rating = round(float(steam_score) / 10.0, 1) if steam_score else 0
        detail_bits = []
        if g.get("developer"):
            detail_bits.append(str(g.get("developer")))
        if g.get("genres"):
            detail_bits.append(str(g.get("genres")))
        if steam_score:
            detail_bits.append("Steam {}%".format(steam_score))
        if mc_score:
            detail_bits.append("Metacritic {}".format(mc_score))

        url = url_for(mode="play_game", appid=appid)
        items.append({
            "kind": "game",
            "label": title,
            "url": url,
            "is_folder": False,
            "art": {
                "poster": poster,
                "thumb": thumb,
                "icon": thumb or poster,
                "fanart": fanart,
                "landscape": fanart or thumb,
                "clearlogo": clearlogo,
            },
            "_fanart_candidates": fanart_candidates,
            "info": {
                "mediatype": "movie",
                "title": title,
                "originaltitle": title,
                "sorttitle": title,
                "plot": plot,
                "plotoutline": plot,
                "year": as_int(g.get("year"), 0),
                # AF3 row compatibility: games use tagline in the old genre headline slot.
                "genre": tagline_for_ui,
                "studio": g.get("developer") or g.get("publisher") or "",
                "rating": rating,
                "mpaa": "",
                "tagline": tagline_for_ui,
            },
            "props": dict({
                "mediahub_type": "game",
                "source": "Steam Library",
                "platform": "steam",
                "steam_platform": "steam",
                "steam_appid": appid,
                "appid": appid,
                "developer": str(g.get("developer") or ""),
                "publisher": str(g.get("publisher") or ""),
                "genres": raw_genres,
                "tagline": str(g.get("tagline") or ""),
                "tagline_display": tagline_for_ui,
                "genre_display": tagline_for_ui,
                "genres_display": raw_genres or "N/A",
                "esrb": str(g.get("esrb") or ""),
                "pegi": str(g.get("pegi") or ""),
                "steam_review_percent": str(g.get("steam_review_percent") or ""),
                "steam_review_desc": str(g.get("steam_review_desc") or ""),
                "steam_review_total": str(g.get("steam_review_total") or ""),
                "steam250_rank": str(g.get("steam250_rank") or ""),
                "steam250_score": str(g.get("steam250_score") or ""),
                "metacritic_score": str(g.get("metacritic_score") or ""),
                "achievement_unlocked": str(g.get("achievement_unlocked") or ""),
                "achievement_total": str(g.get("achievement_total") or ""),
                "completed": str(g.get("completed") or ""),
                "finished": str(g.get("finished") or ""),

                # AF3 / Steam Library compatible aliases.
                # Home spotlight/widget skin patches usually read these direct
                # properties, not the generic RatingSlotN_* bridge used by LRS.
                "developer_display": steam_display_or_na(first_credit(g.get("developer"))),
                "publisher_display": steam_display_or_na(first_credit(g.get("publisher"))),
                "achievement_display": steam_achievement_display(g),
                "playtime_forever": str(g.get("playtime_forever") or ""),
                "playtime_display": format_playtime_forever(g.get("playtime_forever"), with_prefix=False),
                "steam_rating_display": steam_rating_display(g),
                "steam250_rank_display": steam250_rank_display(g),
                "top250_display": steam250_rank_display(g),
                "age_rating_display": age_rating_for_ui,
                "completed_bool": "true" if truthy(g.get("completed")) else "",
                "finished_bool": "true" if truthy(g.get("finished")) else "",
                "steam_poster_view": "true",
                "is_steam_library": "true",
                "steam_no_video_furniture": "true",
                "program_plugin": steam_addon_id(),
                "IsPlayable": "true",
            }, **game_kpm_props(g, appid, steam_score, mc_score), **build_game_row_alias_props_0117(g, steam_score, mc_score)),
        })
    return items




# -----------------------------------------------------------------------------
# Artwork filters: clearlogo + cached fanart resolution via Textures DB
# -----------------------------------------------------------------------------

MIN_1080P_WIDTH = 1920
MIN_1080P_HEIGHT = 1080
_TEXTURE_SIZE_CACHE = {}


def is_http_url(value):
    txt = str(value or "").strip().lower()
    return txt.startswith("http://") or txt.startswith("https://")


def image_url_candidates(url):
    raw = str(url or "").strip()
    if not raw:
        return []
    candidates = []

    def add(v):
        v = str(v or "").strip()
        if v and v not in candidates:
            candidates.append(v)

    add(raw)

    # Kodi's texture DB commonly stores artwork as image://<urlencoded-source>/.
    if raw.startswith("image://"):
        inner = raw[8:]
        if inner.endswith("/"):
            inner = inner[:-1]
        decoded = urllib.parse.unquote(inner)
        add(decoded)
        add("image://{}/".format(urllib.parse.quote(decoded, safe="")))
        add("image://{}/".format(urllib.parse.quote(decoded, safe=":/")))
    else:
        add("image://{}/".format(urllib.parse.quote(raw, safe="")))
        add("image://{}/".format(urllib.parse.quote(raw, safe=":/")))

    return candidates


def texture_db_path():
    db_dir = tr("special://profile/Database")
    candidates = []
    try:
        candidates = glob.glob(os.path.join(db_dir, "Textures*.db"))
    except Exception:
        candidates = []
    if not candidates:
        fixed = os.path.join(db_dir, "Textures13.db")
        return fixed if os.path.exists(fixed) else ""

    def version(path):
        m = re.search(r"Textures(\d+)\.db$", os.path.basename(path), re.I)
        return int(m.group(1)) if m else 0

    candidates.sort(key=version, reverse=True)
    return candidates[0]


def cached_texture_path(cachedurl):
    cachedurl = str(cachedurl or "").strip()
    if not cachedurl:
        return ""
    if cachedurl.startswith("special://"):
        return tr(cachedurl)
    if os.path.isabs(cachedurl):
        return cachedurl
    return os.path.join(tr("special://profile/Thumbnails"), cachedurl.replace("/", os.sep))


def read_file_head(path, max_bytes=512 * 1024):
    try:
        real = tr(path)
        if not real or not os.path.exists(real):
            return b""
        with open(real, "rb") as fh:
            return fh.read(max_bytes)
    except Exception:
        return b""


def image_size_from_bytes(data):
    if not data:
        return None
    try:
        # PNG
        if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24:
            width, height = struct.unpack(">II", data[16:24])
            return int(width), int(height)

        # JPEG: scan SOF markers.
        if data[:2] == b"\xff\xd8":
            i = 2
            size = len(data)
            while i + 9 < size:
                if data[i] != 0xFF:
                    i += 1
                    continue
                marker = data[i + 1]
                i += 2
                if marker in (0xD8, 0xD9):
                    continue
                if i + 2 > size:
                    break
                block_len = struct.unpack(">H", data[i:i + 2])[0]
                if block_len < 2:
                    break
                if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF):
                    if i + 7 <= size:
                        height, width = struct.unpack(">HH", data[i + 3:i + 7])
                        return int(width), int(height)
                    break
                i += block_len

        # WebP VP8X / VP8L partial support.
        if data.startswith(b"RIFF") and data[8:12] == b"WEBP" and len(data) >= 30:
            chunk = data[12:16]
            if chunk == b"VP8X" and len(data) >= 30:
                width = 1 + int.from_bytes(data[24:27], "little")
                height = 1 + int.from_bytes(data[27:30], "little")
                return int(width), int(height)
            if chunk == b"VP8L" and len(data) >= 25 and data[20] == 0x2f:
                b0, b1, b2, b3 = data[21], data[22], data[23], data[24]
                width = 1 + (((b1 & 0x3F) << 8) | b0)
                height = 1 + (((b3 & 0x0F) << 10) | (b2 << 2) | ((b1 & 0xC0) >> 6))
                return int(width), int(height)
    except Exception:
        return None
    return None


def image_size_from_file(path):
    return image_size_from_bytes(read_file_head(path))


def local_source_from_image_url(url):
    raw = str(url or "").strip()
    if raw.startswith("image://"):
        inner = raw[8:]
        if inner.endswith("/"):
            inner = inner[:-1]
        raw = urllib.parse.unquote(inner)
    if is_http_url(raw):
        return ""
    if raw.startswith("special://"):
        return tr(raw)
    if os.path.isabs(raw):
        return raw
    return ""


def texture_size_from_db(url):
    raw = str(url or "").strip()
    if not raw:
        return None
    if raw in _TEXTURE_SIZE_CACHE:
        return _TEXTURE_SIZE_CACHE[raw]

    result = None
    db_path = texture_db_path()
    if db_path and os.path.exists(db_path):
        con = None
        try:
            con = sqlite3.connect(db_path)
            con.row_factory = sqlite3.Row
            cur = con.cursor()
            cur.execute("PRAGMA table_info(texture)")
            texture_cols = [r[1] for r in cur.fetchall()]
            if "url" in texture_cols:
                candidates = image_url_candidates(raw)
                placeholders = ",".join(["?"] * len(candidates))
                sql = "SELECT rowid AS _rowid, * FROM texture WHERE url IN ({}) ORDER BY rowid DESC LIMIT 1".format(placeholders)
                row = cur.execute(sql, candidates).fetchone()

                if row:
                    row_keys = set(row.keys())
                    width = as_int(row["width"], 0) if "width" in row_keys else 0
                    height = as_int(row["height"], 0) if "height" in row_keys else 0
                    if width and height:
                        result = (width, height, "texture-db")

                    # Some Kodi schemas store dimensions in a sizes table.
                    if result is None:
                        try:
                            cur.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='sizes'")
                            if cur.fetchone():
                                cur.execute("PRAGMA table_info(sizes)")
                                size_cols = [r[1] for r in cur.fetchall()]
                                if "width" in size_cols and "height" in size_cols:
                                    id_value = None
                                    for id_col in ("idtexture", "id", "_rowid"):
                                        if id_col in row_keys:
                                            id_value = row[id_col]
                                            break
                                    if id_value is not None:
                                        if "idtexture" in size_cols:
                                            srow = cur.execute(
                                                "SELECT width, height FROM sizes WHERE idtexture=? ORDER BY (width * height) DESC LIMIT 1",
                                                (id_value,),
                                            ).fetchone()
                                        else:
                                            srow = cur.execute(
                                                "SELECT width, height FROM sizes ORDER BY (width * height) DESC LIMIT 1"
                                            ).fetchone()
                                        if srow and as_int(srow["width"], 0) and as_int(srow["height"], 0):
                                            result = (as_int(srow["width"], 0), as_int(srow["height"], 0), "texture-sizes")
                        except Exception:
                            pass

                    if result is None and "cachedurl" in row_keys:
                        cpath = cached_texture_path(row["cachedurl"])
                        size = image_size_from_file(cpath)
                        if size:
                            result = (size[0], size[1], "thumbnail-cache")
        except Exception as exc:
            log("Texture DB check failed for {}: {}".format(raw, exc), xbmc.LOGDEBUG)
        finally:
            try:
                if con:
                    con.close()
            except Exception:
                pass

    # Local artwork fallback. Remote URLs are deliberately not downloaded.
    if result is None:
        local = local_source_from_image_url(raw)
        if local:
            size = image_size_from_file(local)
            if size:
                result = (size[0], size[1], "local-file")

    _TEXTURE_SIZE_CACHE[raw] = result
    return result



LRS_RATINGS_DB = tr("special://profile/addon_data/script.library.ratings.scraper/ratings-cache.db")
KPM_CLEARLOGO_RESOLVER_DB = tr("special://profile/addon_data/script.kodi.patch.manager/runtime/state/clearlogo-resolver-cache.db")


def _cropv2_directory():
    custom = ""
    addon = None
    try:
        addon = xbmcaddon.Addon("plugin.video.themoviedb.helper")
        custom = str(addon.getSetting("image_location") or "").strip()
    except Exception:
        custom = ""
    finally:
        if addon is not None:
            del addon
    base = custom or "special://profile/addon_data/plugin.video.themoviedb.helper"
    return tr(os.path.join(base.rstrip("/\\"), "crop_v2"))


def _cropv2_from_source(source):
    source = str(source or "").strip()
    if not source:
        return ""
    exact = os.path.join(_cropv2_directory(), "cropped-{}.png".format(hashlib.md5(source.encode("utf-8")).hexdigest()))
    if os.path.isfile(exact) and os.path.getsize(exact) > 0:
        return exact
    return ""


def _resolver_cropv2(item_key, source):
    # Exact CropV2 hash is the primary path and makes the prepared cache
    # independent from LRS polling order. The persistent resolver remains a
    # verified fallback and diagnostics source.
    direct = _cropv2_from_source(source)
    if direct:
        return {"status": "resolved", "path": direct, "source": "exact_cropv2_hash"}
    if not os.path.isfile(KPM_CLEARLOGO_RESOLVER_DB):
        return {"status": "cache_unbuilt", "path": "", "source": "resolver_db_missing"}
    conn = None
    try:
        conn = sqlite3.connect(KPM_CLEARLOGO_RESOLVER_DB, timeout=5)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT status,resolved_path,canonical_source,source_hash FROM resolver_items WHERE item_key=?",
            (str(item_key or ""),),
        ).fetchone()
        if not row:
            return {"status": "not_indexed", "path": "", "source": "resolver_db"}
        path = str(row["resolved_path"] or "")
        valid = bool(path and os.path.isfile(path) and os.path.getsize(path) > 0)
        return {
            "status": "resolved" if valid else str(row["status"] or "missing"),
            "path": path if valid else "", "source": "resolver_db",
            "source_hash": str(row["source_hash"] or ""),
        }
    except Exception as exc:
        return {"status": "resolver_error", "path": "", "source": "resolver_db", "error": str(exc)}
    finally:
        if conn is not None:
            conn.close()


def has_clearlogo(item):
    art = item.get("art") or {}
    return bool(str(art.get("clearlogo") or "").strip())


def fanart_is_1080p_or_better(item):
    art = item.get("art") or {}
    fanart = str(art.get("fanart") or "").strip()
    if not fanart:
        return False
    size = texture_size_from_db(fanart)
    if not size:
        return False
    width, height, _source = size
    return int(width) >= MIN_1080P_WIDTH and int(height) >= MIN_1080P_HEIGHT


def is_screensaver_request(params):
    if as_bool((params or {}).get("_screensaver"), False):
        return True
    try:
        return bool(xbmc.getCondVisibility("System.ScreenSaverActive"))
    except Exception:
        return False


def choose_one_random_cached_fanart_per_item(items, params):
    """Choice 1: keep one slide per item, but randomly select one cached fanart."""
    if not is_screensaver_request(params):
        return items

    seed = str((params or {}).get("seed") or "").strip()
    rnd = random_mod.Random(seed + "|fanart") if seed else random_mod.Random()
    require_1080p = setting_bool("exclude_fanart_below_1080p", True)
    changed = 0

    for item in items:
        art = dict(item.get("art") or {})
        candidates = list(item.get("_fanart_candidates") or [])
        current = str(art.get("fanart") or "").strip()
        if current and current not in candidates:
            candidates.insert(0, current)

        valid = list(item.get('_valid_fanart_candidates') or [])
        if valid:
            candidates = []
        for candidate in candidates:
            candidate = str(candidate or "").strip()
            if not candidate or candidate in valid:
                continue
            size = texture_size_from_db(candidate)
            # Remote artwork must already exist in Kodi texture cache. Local files
            # are accepted by texture_size_from_db without network access.
            if not size:
                continue
            width, height, _source = size
            if require_1080p and (int(width) < MIN_1080P_WIDTH or int(height) < MIN_1080P_HEIGHT):
                continue
            valid.append(candidate)

        if not valid:
            continue
        chosen = rnd.choice(valid)
        art["fanart"] = chosen
        art["landscape"] = chosen
        item["art"] = art
        item.setdefault("props", {})["mediahub_random_fanart"] = "true"
        item["props"]["mediahub_random_fanart_count"] = str(len(valid))
        if chosen != current:
            changed += 1

    log("Screensaver random fanart: items={}, changed={}".format(len(items), changed), xbmc.LOGINFO)
    return items


def apply_item_filters(items):
    require_clearlogo = setting_bool("exclude_without_clearlogo", True)
    require_1080p = setting_bool("exclude_fanart_below_1080p", True)
    if not require_clearlogo and not require_1080p:
        return list(items)

    kept = []
    skipped_logo = 0
    skipped_fanart = 0
    for item in items:
        if require_clearlogo and not has_clearlogo(item):
            skipped_logo += 1
            continue
        if require_1080p and not fanart_is_1080p_or_better(item):
            skipped_fanart += 1
            continue
        kept.append(item)

    log("Artwork filters: kept={}, skipped_no_clearlogo={}, skipped_below_or_unknown_1080p={}".format(
        len(kept), skipped_logo, skipped_fanart
    ), xbmc.LOGINFO)
    return kept


def _screensaver_session_limit():
    return max(50, min(600, setting_int('screensaver_session_limit', 300)))


def prepare_screensaver_cache(force=False):
    ensure_runtime_dirs()
    started = time.time()
    items = mixed_items()
    # Fanart filtering remains independent. Clearlogo is validated against the
    # actual CropV2 path below, not merely against a native source URL.
    require_1080p = setting_bool('exclude_fanart_below_1080p', True)
    require_cropv2 = setting_bool('exclude_without_clearlogo', True)
    prepared = []
    overlay_samples = []
    skipped_identity = 0
    skipped_cropv2 = 0
    skipped_fanart = 0
    for item in items:
        clone = _prepare_screensaver_overlay(item)
        props = clone.get('props') or {}
        if require_cropv2 and not str(props.get('screensaver_cropv2') or '').strip():
            skipped_cropv2 += 1
            if len(overlay_samples) < 80:
                overlay_samples.append({
                    'title': clone.get('label'), 'item_key': props.get('mediahub_item_key'),
                    'cropv2_status': props.get('screensaver_cropv2_status'),
                    'cropv2_path': props.get('screensaver_cropv2'),
                    'rating_status': props.get('screensaver_rating_status'),
                    'rating_count': props.get('screensaver_rating_count'),
                    'prepared': False, 'reason': 'cropv2_not_ready',
                })
            continue
        art = dict(clone.get('art') or {})
        candidates = list(clone.get('_fanart_candidates') or [])
        current = str(art.get('fanart') or '').strip()
        if current and current not in candidates:
            candidates.insert(0, current)
        valid = []
        for candidate in candidates:
            candidate = str(candidate or '').strip()
            if not candidate or candidate in valid:
                continue
            size = texture_size_from_db(candidate)
            if not size:
                continue
            width, height, _source = size
            if require_1080p and (int(width) < MIN_1080P_WIDTH or int(height) < MIN_1080P_HEIGHT):
                continue
            valid.append(candidate)
        if not valid:
            skipped_fanart += 1
            continue
        clone['_valid_fanart_candidates'] = valid
        prepared.append(clone)
        if len(overlay_samples) < 80:
            overlay_samples.append({
                'title': clone.get('label'), 'item_key': props.get('mediahub_item_key'),
                'cropv2_status': props.get('screensaver_cropv2_status'),
                'cropv2_path': props.get('screensaver_cropv2'),
                'rating_status': props.get('screensaver_rating_status'),
                'rating_count': props.get('screensaver_rating_count'),
                'prepared': True,
            })
    payload = {
        'version': 2, 'built_at': int(time.time()), 'source_items': len(items),
        'prepared_items': len(prepared), 'skipped_cropv2': skipped_cropv2,
        'skipped_fanart': skipped_fanart, 'elapsed_ms': int((time.time()-started)*1000),
        'overlay_samples': overlay_samples, 'items': prepared,
    }
    tmp = SCREENSAVER_CACHE_FILE + '.tmp'
    with open(tmp, 'w', encoding='utf-8') as fh:
        json.dump(payload, fh, ensure_ascii=False, separators=(',', ':'), default=str)
        fh.flush()
        try:
            os.fsync(fh.fileno())
        except OSError:
            pass
    os.replace(tmp, SCREENSAVER_CACHE_FILE)
    with open(SCREENSAVER_STATUS_FILE, 'w', encoding='utf-8') as fh:
        json.dump({k:v for k,v in payload.items() if k not in ('items',)}, fh, indent=2, ensure_ascii=False)
    log('Screensaver cache v2 built: source={}, prepared={}, cropv2_skip={}, fanart_skip={}, elapsed_ms={}'.format(
        len(items), len(prepared), skipped_cropv2, skipped_fanart, payload['elapsed_ms']), xbmc.LOGINFO)
    return payload


def load_screensaver_cache(max_age=1800):
    try:
        if not os.path.isfile(SCREENSAVER_CACHE_FILE):
            return None
        with open(SCREENSAVER_CACHE_FILE, 'r', encoding='utf-8') as fh:
            payload = json.load(fh)
        if not isinstance(payload, dict) or not isinstance(payload.get('items'), list):
            return None
        if time.time() - float(payload.get('built_at') or 0) > max_age:
            return None
        return payload
    except Exception as exc:
        log('Screensaver cache read failed: {}'.format(exc), xbmc.LOGWARNING)
        return None


def cached_screensaver_items():
    payload = load_screensaver_cache()
    if payload is None:
        payload = _load_screensaver_cache_any_0133()
    if payload is None:
        payload = prepare_screensaver_cache(force=True)
    items = list(payload.get('items') or [])
    rnd = random_mod.Random()
    rnd.shuffle(items)
    items = items[:_screensaver_session_limit()]
    return [_screensaver_compactify_item_0133(item) for item in items]


# -----------------------------------------------------------------------------
# Directory output
# -----------------------------------------------------------------------------

def limit_and_sort(items, params):
    # All MediaHub widget output is unlimited by default. This also overrides
    # old widget URLs that still carry limit=100.
    force_unlimited = setting_bool("force_unlimited_output", True)
    default_limit = setting_int("default_limit", 0)
    limit = 0 if force_unlimited else as_int(
        params.get("limit"), default_limit
    )
    randomize = as_bool(params.get("random"), setting_bool("default_random", True))
    seed = params.get("seed") or ""

    if randomize:
        rnd = random_mod.Random(seed) if seed else random_mod.Random()
        rnd.shuffle(items)
    else:
        items.sort(key=lambda x: re.sub(r"^(the|a|an)\s+", "", x.get("label", "").lower()))

    if limit > 0:
        items = items[:limit]
    return items


def add_media_item(item, total=0, bundle_slot=''):
    li = xbmcgui.ListItem(label=item.get("label") or "", offscreen=True)
    safe_set_info(li, item.get("info") or {})
    safe_set_art(li, item.get("art") or {})

    for k, v in (item.get("props") or {}).items():
        try:
            li.setProperty(str(k), str(v))
        except Exception:
            pass

    kind = item.get("kind") or "media"
    props = item.get("props") or {}
    stable_key = str(props.get("mediahub_item_key") or "").strip()
    if not stable_key:
        stable_key = mediahub_item_key(
            kind,
            props.get("dbid") or (item.get("info") or {}).get("dbid"),
            props.get("steam_appid") or props.get("appid"),
        )
    li.setProperty("mediahub_widget", "true")
    li.setProperty("mediahub_kind", kind)
    li.setProperty("source_addon", ADDON_ID)
    li.setProperty("mediahub_item_key", stable_key)
    if bundle_slot in ("A", "B"):
        li.setProperty("mediahub_bundle_slot", bundle_slot)

    if kind == "game":
        # Extra runtime aliases for services that inspect only focused ListItem props.
        li.setProperty("kpm_item_type", "game")
        li.setProperty("kpm_data_owner", ADDON_ID)
        li.setProperty("DBTYPE", "game")
        li.setProperty("dbtype", "game")
        li.setProperty("MediaType", "game")
        li.setProperty("mediatype", "game")

    if kind == "movie":
        li.addContextMenuItems([
            ("Play movie", "RunPlugin({})".format(item.get("url"))),
            ("Open library item", "ActivateWindow(Videos,videodb://movies/titles/{}/,return)".format(props.get("dbid") or item.get("info", {}).get("dbid") or "")),
            ("View item properties", "RunPlugin({})".format(url_for(mode="view_item_properties", kind=kind, dbid=props.get("dbid") or "", label=item.get("label") or ""))),
        ])
    elif kind == "series":
        li.addContextMenuItems([
            ("Open series", "RunPlugin({})".format(item.get("url"))),
            ("Open library item", "ActivateWindow(Videos,videodb://tvshows/titles/{}/,return)".format(props.get("dbid") or item.get("info", {}).get("dbid") or "")),
            ("View item properties", "RunPlugin({})".format(url_for(mode="view_item_properties", kind=kind, dbid=props.get("dbid") or "", label=item.get("label") or ""))),
        ])
    elif kind == "game":
        appid = props.get("steam_appid") or props.get("appid") or item.get("info", {}).get("dbid") or ""
        li.addContextMenuItems([
            ("Launch Steam game", "RunPlugin({})".format(item.get("url"))),
            ("Open in Steam Library", "ActivateWindow(Programs,plugin://{}?mode=list&collection=__all__,return)".format(steam_addon_id())),
            ("View game properties", "RunPlugin({})".format(url_for(mode="view_item_properties", kind=kind, appid=appid, label=item.get("label") or ""))),
        ])

    set_item_path(li, item.get("url"))
    xbmcplugin.addDirectoryItem(HANDLE, item.get("url"), li, bool(item.get("is_folder", False)), total)


def add_dir(label, mode, **kwargs):
    params = {"mode": mode}
    params.update(kwargs)
    url = url_for(**params)
    li = xbmcgui.ListItem(label=label, offscreen=True)
    li.setProperty("mediahub_widget_folder", "true")
    li.setProperty("kpm_item_type", "folder")
    li.setProperty("kpm_visual_clear", "true")
    li.setProperty("DBTYPE", "folder")
    safe_set_art(li, {"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
    safe_set_info(li, {"title": label, "plot": "MediaHub Widget path: {}".format(url)})
    xbmcplugin.addDirectoryItem(HANDLE, url, li, True)


def root():
    add_dir("All Media: Movies + Series + Games", "mix", limit=0, random=str(setting_bool("default_random", True)).lower())
    add_dir("All Media: Random Screensaver Mix", "screensaver_mix", limit=0, random="true")
    add_dir("Movies only", "movies", limit=0, random=str(setting_bool("default_random", True)).lower())
    add_dir("Series / TV Shows only", "series", limit=0, random=str(setting_bool("default_random", True)).lower())
    add_dir("Steam Games only", "games", limit=0, random=str(setting_bool("default_random", True)).lower())
    add_dir("All Media: Unlimited / no limit", "mix", limit=0, random="false")

    add_dir("Tools", "tools")

    li = xbmcgui.ListItem(label="View Status", offscreen=True)
    safe_set_art(li, {"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="view_status"), li, False)

    li = xbmcgui.ListItem(label="Export diagnostics ZIP", offscreen=True)
    safe_set_art(li, {"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="export_diagnostics"), li, False)

    li = xbmcgui.ListItem(label="Settings", offscreen=True)
    safe_set_art(li, {"icon": "DefaultAddonProgram.png"})
    xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="settings"), li, False)
    xbmcplugin.endOfDirectory(HANDLE)


def output_items(items, content="movies", params=None):
    params = params or {}
    # Choice 1: one item remains one slide; only its fanart is selected randomly.
    items = choose_one_random_cached_fanart_per_item(list(items), params)
    # Filter first, then randomize/limit. This prevents limit=100 from shrinking
    # to a smaller final list after low-quality artwork gets excluded.
    if not as_bool(params.get('_screensaver_cached'), False):
        items = apply_item_filters(items)
    items = limit_and_sort(items, params)
    try:
        xbmcplugin.setContent(HANDLE, content)
    except Exception:
        pass

    total = len(items)
    for index, item in enumerate(items):
        # Two persistent display slots let the outgoing screensaver metadata
        # retain its own snapshot while the incoming slide is prepared.
        add_media_item(item, total, 'A' if index % 2 == 0 else 'B')

    try:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    except Exception:
        pass

    xbmcplugin.endOfDirectory(HANDLE)

    if setting_bool("force_poster_view", False):
        try:
            xbmc.executebuiltin("Container.SetViewMode({})".format(setting_int("poster_view_id", 502)))
        except Exception:
            pass


def mixed_items():
    items = []
    if setting_bool("include_movies", True):
        try:
            items.extend(library_movies())
        except Exception as exc:
            log("Movies read failed: {}".format(exc), xbmc.LOGERROR)
    if setting_bool("include_series", True):
        try:
            items.extend(library_series())
        except Exception as exc:
            log("Series read failed: {}".format(exc), xbmc.LOGERROR)
    if setting_bool("include_games", True):
        try:
            items.extend(steam_games())
        except Exception as exc:
            log("Games read failed: {}".format(exc), xbmc.LOGERROR)
    return items


# -----------------------------------------------------------------------------
# Actions
# -----------------------------------------------------------------------------

def play_movie(movieid):
    try:
        movieid_int = int(movieid)
        jsonrpc("Player.Open", {"item": {"movieid": movieid_int}})
    except Exception as exc:
        log("Play movie failed: {}".format(exc), xbmc.LOGERROR)
        notify("Gagal play movie")


def open_series(tvshowid):
    try:
        tvshowid_int = int(tvshowid)
        xbmc.executebuiltin("ActivateWindow(Videos,videodb://tvshows/titles/{}/,return)".format(tvshowid_int))
    except Exception as exc:
        log("Open series failed: {}".format(exc), xbmc.LOGERROR)
        notify("Gagal buka series")


def play_game(appid):
    appid = str(appid or "").strip()
    if not appid:
        return
    try:
        xbmc.executebuiltin("RunPlugin(plugin://{}?mode=play&appid={})".format(steam_addon_id(), urllib.parse.quote(appid)))
    except Exception as exc:
        log("Launch game failed: {}".format(exc), xbmc.LOGERROR)
        notify("Gagal launch game")



def _steam_db_path():
    return tr("special://profile/addon_data/{}/steam_library.db".format(steam_addon_id()))


def view_status():
    ensure_runtime_dirs()
    lines = [ADDON_NAME + " status", "=" * 60, "Addon ID: " + ADDON_ID]
    try:
        movies = library_movies() if setting_bool("include_movies", True) else []
        series = library_series() if setting_bool("include_series", True) else []
        games = steam_games() if setting_bool("include_games", True) else []
        lines.extend(["Movies: {}".format(len(movies)), "Series: {}".format(len(series)), "Steam games: {}".format(len(games))])
    except Exception as exc:
        lines.append("Status read error: {}".format(exc))
    lines.append("Steam Library DB: {}".format(_steam_db_path()))
    show_report(ADDON_NAME + " - View Status", "\n".join(lines))


def export_diagnostics():
    ensure_runtime_dirs()
    stamp = time.strftime("%Y%m%d-%H%M%S")
    zip_path = os.path.join(PROFILE, "mediahub-widget-diagnostics-{}.zip".format(stamp))
    tmp_path = zip_path + ".tmp"
    manifest = {"addon_id": ADDON_ID, "addon_name": ADDON_NAME, "addon_version": addon_instance().getAddonInfo("version"), "created_at": time.strftime("%Y-%m-%d %H:%M:%S"), "zip_layout": "runtime-v1"}
    try:
        with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False) + "\n")
            settings_snapshot = {"include_movies": setting_bool("include_movies", True), "include_series": setting_bool("include_series", True), "include_games": setting_bool("include_games", True), "default_limit": setting_int("default_limit", 0), "force_unlimited_output": setting_bool("force_unlimited_output", True), "default_random": setting_bool("default_random", True), "steam_addon_id": steam_addon_id(), "exclude_fanart_below_1080p": setting_bool("exclude_fanart_below_1080p", True), "exclude_without_clearlogo": setting_bool("exclude_without_clearlogo", True)}
            zf.writestr("summary/settings-redacted.json", json.dumps(settings_snapshot, indent=2, ensure_ascii=False) + "\n")
            try:
                counts = {"movies": len(library_movies()), "series": len(library_series()), "games": len(steam_games())}
            except Exception as exc:
                counts = {"error": str(exc)}
            zf.writestr("summary/status.json", json.dumps(counts, indent=2, ensure_ascii=False) + "\n")
            steam_db = _steam_db_path()
            zf.writestr("reports/source-health.txt", "Steam DB: {}\nSteam DB exists: {}\n".format(steam_db, os.path.exists(steam_db)))
            if os.path.isfile(SCREENSAVER_STATUS_FILE):
                zf.write(SCREENSAVER_STATUS_FILE, 'runtime/state/screensaver-cache-status.json')
            if os.path.isfile(SCREENSAVER_CACHE_FILE):
                try:
                    cache_payload = load_screensaver_cache(max_age=10**9) or {}
                    zf.writestr('summary/screensaver-cache.txt',
                        'Version: {}\nBuilt at: {}\nSource items: {}\nPrepared items: {}\nSkipped CropV2: {}\nSkipped fanart: {}\nBuild elapsed ms: {}\nSession limit: {}\nCache bytes: {}\n'.format(
                            cache_payload.get('version'), cache_payload.get('built_at'), cache_payload.get('source_items'),
                            cache_payload.get('prepared_items'), cache_payload.get('skipped_cropv2'), cache_payload.get('skipped_fanart'), cache_payload.get('elapsed_ms'),
                            _screensaver_session_limit(), os.path.getsize(SCREENSAVER_CACHE_FILE)))
                    zf.writestr('summary/screensaver-overlay-samples.json', json.dumps(cache_payload.get('overlay_samples') or [], indent=2, ensure_ascii=False) + '\n')
                except Exception as exc:
                    zf.writestr('summary/screensaver-cache-error.txt', str(exc))
        with zipfile.ZipFile(tmp_path, "r") as test_zf:
            bad = test_zf.testzip()
            if bad:
                raise RuntimeError("Diagnostics ZIP validation failed at {}".format(bad))
        for name in os.listdir(PROFILE) if os.path.isdir(PROFILE) else []:
            if name.startswith("mediahub-widget-diagnostics-") and name.endswith(".zip"):
                try:
                    os.remove(os.path.join(PROFILE, name))
                except Exception:
                    pass
        os.replace(tmp_path, zip_path)
    except Exception:
        try:
            if os.path.isfile(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        raise
    notify("DIAGNOSTICS EXPORTED - MWH-{}".format(os.path.basename(zip_path).split("mediahub-widget-", 1)[-1]))

def tools_menu():
    opts = ["View Status", "Export diagnostics ZIP", "Settings", "Exit"]
    n = xbmcgui.Dialog().select(ADDON_NAME + " - Tools", opts)
    if n == 0:
        view_status()
    elif n == 1:
        export_diagnostics()
    elif n == 2:
        open_settings()


def view_item_properties(params):
    lines = ["MediaHub item properties", "=" * 60]
    for key in sorted(params):
        lines.append("{}: {}".format(key, params.get(key)))
    show_report(ADDON_NAME + " - Item Properties", "\n".join(lines))

def open_settings():
    try:
        xbmcaddon.Addon(ADDON_ID).openSettings()
    except Exception:
        xbmc.executebuiltin("Addon.OpenSettings({})".format(ADDON_ID))


# -----------------------------------------------------------------------------
# Router
# -----------------------------------------------------------------------------

def normalize_mode(mode):
    mode = (mode or "root").strip().lower()
    aliases = {
        "home_mix": "mix",
        "screensaver_mix": "mix",
        "all": "mix",
        "all_media": "mix",
        "tv": "series",
        "tvshows": "series",
        "shows": "series",
        "show": "series",
        "steam": "games",
        "steam_games": "games",
        "screensaver_movies": "movies",
        "screensaver_series": "series",
        "screensaver_games": "games",
        "home_movies": "movies",
        "home_series": "series",
        "home_games": "games",
    }
    return aliases.get(mode, mode)


def run():
    params = parse_params()
    raw_mode = str(params.get("mode", "root") or "root").strip().lower()
    if raw_mode.startswith("screensaver_"):
        params["_screensaver"] = "true"
    mode = normalize_mode(raw_mode)

    try:
        if mode == "root":
            root()
        elif mode == "mix":
            if is_screensaver_request(params):
                params['_screensaver_cached'] = 'true'
                output_items(cached_screensaver_items(), "movies", params)
            else:
                output_items(mixed_items(), "movies", params)
        elif mode == "movies":
            output_items(library_movies(), "movies", params)
        elif mode == "series":
            output_items(library_series(), "tvshows", params)
        elif mode == "games":
            output_items(steam_games(), "movies", params)
        elif mode == "play_movie":
            play_movie(params.get("movieid"))
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "open_series":
            open_series(params.get("tvshowid"))
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "play_game":
            play_game(params.get("appid"))
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "tools":
            tools_menu()
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "view_status":
            view_status()
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "export_diagnostics":
            export_diagnostics()
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "view_item_properties":
            view_item_properties(params)
            xbmcplugin.endOfDirectory(HANDLE)
        elif mode == "settings":
            open_settings()
            xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcplugin.endOfDirectory(HANDLE)
    except Exception as exc:
        log("Router error: {}\n{}".format(exc, traceback.format_exc()), xbmc.LOGERROR)
        try:
            li = xbmcgui.ListItem(label="MediaHub Widget error", offscreen=True)
            safe_set_info(li, {"title": "MediaHub Widget error", "plot": str(exc)})
            xbmcplugin.addDirectoryItem(HANDLE, url_for(mode="root"), li, False)
            xbmcplugin.endOfDirectory(HANDLE)
        except Exception:
            pass


# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------
# v0.1.32 - proven live LRS screensaver bridge
# -----------------------------------------------------------------------------
# MediaHub owns slide selection, cached fanart, item identity and game slots.
# It does not read the LRS database, does not choose movie/series ratings and
# does not place rating/CropV2 output on ListItem properties. LRS publishes the
# live LibraryRatings.Screensaver.* namespace for the current slide.
SCREENSAVER_CACHE_CONTRACT_0132 = 5
SCREENSAVER_BRIDGE_MODE_0132 = "atomic-live-lrs-window-properties-v1"


def _strip_r10_screensaver_overlay_props_0132(props):
    clean = {}
    for key, value in dict(props or {}).items():
        name = str(key or "")
        if name.startswith("screensaver_"):
            continue
        clean[name] = value
    return clean


def _screensaver_settings_signature_0132():
    values = {
        "exclude_without_clearlogo": setting_bool("exclude_without_clearlogo", True),
        "exclude_fanart_below_1080p": setting_bool("exclude_fanart_below_1080p", True),
        "include_movies": setting_bool("include_movies", True),
        "include_series": setting_bool("include_series", True),
        "include_games": setting_bool("include_games", True),
        "session_limit": _screensaver_session_limit(),
    }
    return hashlib.sha256(json.dumps(values, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def _file_signature_0132(path):
    try:
        stat = os.stat(path)
        return [int(stat.st_size), int(getattr(stat, "st_mtime_ns", int(stat.st_mtime * 1000000000)))]
    except OSError:
        return [0, 0]


def _current_screensaver_input_signature_0132():
    payload = {
        "cache_contract": SCREENSAVER_CACHE_CONTRACT_0132,
        "bridge_mode": SCREENSAVER_BRIDGE_MODE_0132,
        "addon_version": str(addon_instance().getAddonInfo("version") or ""),
        "steam_db": _file_signature_0132(_steam_db_path()),
        "resolver_db": _file_signature_0132(KPM_CLEARLOGO_RESOLVER_DB),
        "settings": _screensaver_settings_signature_0132(),
    }
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()


def prepare_screensaver_cache(force=False):
    """Build fanart/item cache only; ratings and CropV2 stay live-owned by LRS."""
    ensure_runtime_dirs()
    started = time.time()
    items = mixed_items()
    require_1080p = setting_bool("exclude_fanart_below_1080p", True)
    require_cropv2 = setting_bool("exclude_without_clearlogo", True)
    prepared = []
    samples = []
    skipped_identity = 0
    skipped_cropv2 = 0
    skipped_fanart = 0

    for item in items:
        clone = dict(item)
        props = _strip_r10_screensaver_overlay_props_0132(clone.get("props") or {})
        art = dict(clone.get("art") or {})
        clone["props"] = props
        key = str(props.get("mediahub_item_key") or "").strip()
        if not key:
            skipped_identity += 1
            if len(samples) < 100:
                samples.append({
                    "title": clone.get("label"), "item_key": "",
                    "prepared": False, "reason": "missing_mediahub_item_key",
                    "atomic_bundle_contract": "v1",
                })
            continue
        props["mediahub_bundle_item_key"] = key
        props["mediahub_bundle_contract"] = "atomic-v1"
        clone["props"] = props
        source_logo = str(art.get("clearlogo") or "").strip()
        resolver = _resolver_cropv2(key, source_logo)

        # Preserve R9/R10 quality filtering, but never carry the resolved path
        # into the slide. LRS resolves and publishes the path live.
        if require_cropv2 and not str(resolver.get("path") or "").strip():
            skipped_cropv2 += 1
            if len(samples) < 100:
                samples.append({
                    "title": clone.get("label"), "item_key": key,
                    "cropv2_status": resolver.get("status"),
                    "prepared": False, "reason": "cropv2_not_ready",
                    "atomic_bundle_contract": "v1",
                    "game_slot_count": sum(1 for i in range(1, 8) if props.get("RatingSlot{}_Label".format(i))),
                })
            continue

        candidates = list(clone.get("_fanart_candidates") or [])
        current = str(art.get("fanart") or "").strip()
        if current and current not in candidates:
            candidates.insert(0, current)
        valid = []
        for candidate in candidates:
            candidate = str(candidate or "").strip()
            if not candidate or candidate in valid:
                continue
            size = texture_size_from_db(candidate)
            if not size:
                continue
            width, height, _source = size
            if require_1080p and (int(width) < MIN_1080P_WIDTH or int(height) < MIN_1080P_HEIGHT):
                continue
            valid.append(candidate)
        if not valid:
            skipped_fanart += 1
            continue

        clone["_valid_fanart_candidates"] = valid
        prepared.append(clone)
        if len(samples) < 100:
            samples.append({
                "title": clone.get("label"), "item_key": key,
                "cropv2_status": resolver.get("status"),
                "cropv2_path": resolver.get("path"),
                "prepared": True,
                "atomic_bundle_contract": "v1",
                "game_slot_count": sum(1 for i in range(1, 8) if props.get("RatingSlot{}_Label".format(i))),
            })

    payload = {
        "version": SCREENSAVER_CACHE_CONTRACT_0132,
        "bridge_mode": SCREENSAVER_BRIDGE_MODE_0132,
        "built_at": int(time.time()),
        "input_signature": _current_screensaver_input_signature_0132(),
        "source_items": len(items),
        "prepared_items": len(prepared),
        "atomic_bundle_contract": "v1",
        "skipped_identity": skipped_identity,
        "skipped_cropv2": skipped_cropv2,
        "skipped_fanart": skipped_fanart,
        "elapsed_ms": int((time.time() - started) * 1000),
        "live_bridge_samples": samples,
        "items": prepared,
    }
    tmp = SCREENSAVER_CACHE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, separators=(",", ":"), default=str)
        handle.flush()
        try:
            os.fsync(handle.fileno())
        except OSError:
            pass
    os.replace(tmp, SCREENSAVER_CACHE_FILE)

    status_payload = {key: value for key, value in payload.items() if key != "items"}
    status_tmp = SCREENSAVER_STATUS_FILE + ".tmp"
    with open(status_tmp, "w", encoding="utf-8") as handle:
        json.dump(status_payload, handle, indent=2, ensure_ascii=False)
        handle.flush()
        try:
            os.fsync(handle.fileno())
        except OSError:
            pass
    os.replace(status_tmp, SCREENSAVER_STATUS_FILE)
    log("Screensaver atomic live-bridge cache built: source={}, prepared={}, identity_skip={}, cropv2_skip={}, fanart_skip={}, elapsed_ms={}".format(
        len(items), len(prepared), skipped_identity, skipped_cropv2, skipped_fanart, payload["elapsed_ms"]), xbmc.LOGINFO)
    return payload


def load_screensaver_cache(max_age=1800):
    try:
        if not os.path.isfile(SCREENSAVER_CACHE_FILE):
            return None
        with open(SCREENSAVER_CACHE_FILE, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        if not isinstance(payload, dict) or not isinstance(payload.get("items"), list):
            return None
        if int(payload.get("version") or 0) != SCREENSAVER_CACHE_CONTRACT_0132:
            return None
        if str(payload.get("bridge_mode") or "") != SCREENSAVER_BRIDGE_MODE_0132:
            return None
        if str(payload.get("atomic_bundle_contract") or "") != "v1":
            return None
        if time.time() - float(payload.get("built_at") or 0) > max_age:
            return None
        if str(payload.get("input_signature") or "") != _current_screensaver_input_signature_0132():
            return None
        return payload
    except Exception as exc:
        log("Screensaver live-bridge cache read failed: {}".format(exc), xbmc.LOGWARNING)
        return None


def _load_screensaver_cache_any_0133():
    try:
        if not os.path.isfile(SCREENSAVER_CACHE_FILE):
            return None
        with open(SCREENSAVER_CACHE_FILE, 'r', encoding='utf-8') as handle:
            payload = json.load(handle)
        if not isinstance(payload, dict) or not isinstance(payload.get('items'), list):
            return None
        if int(payload.get('version') or 0) != SCREENSAVER_CACHE_CONTRACT_0132:
            return None
        if str(payload.get('bridge_mode') or '') != SCREENSAVER_BRIDGE_MODE_0132:
            return None
        if str(payload.get('atomic_bundle_contract') or '') != 'v1':
            return None
        return payload
    except Exception as exc:
        log('Screensaver stale cache read failed: {}'.format(exc), xbmc.LOGWARNING)
        return None


def _screensaver_compactify_item_0133(item):
    clone = dict(item or {})
    props = dict(clone.get('props') or {})
    stable_key = str(props.get('mediahub_item_key') or '').strip()
    if stable_key:
        props['mediahub_bundle_item_key'] = stable_key
        props['mediahub_bundle_contract'] = 'atomic-v1'
    minutes = 0
    try:
        minutes = int(float(str(props.get('playtime_forever') or '').strip()))
    except Exception:
        minutes = 0
    for idx in range(1, 8):
        source_key = 'RatingSlot{}_Source'.format(idx)
        label_key = 'RatingSlot{}_Label'.format(idx)
        value_key = 'RatingSlot{}_Value'.format(idx)
        if str(props.get(source_key) or '').strip() != 'steam_playtime':
            continue
        slot_minutes = minutes or _minutes_from_playtime_label_0133(props.get(label_key) or props.get(value_key) or '')
        compact = format_playtime_compact_0133(slot_minutes)
        if compact:
            props[label_key] = compact
            props[value_key] = compact
            props['playtime_display'] = compact
    clone['props'] = props
    return clone


# -----------------------------------------------------------------------------
# v0.1.35 - persistent master catalog for every widget and screensaver
# -----------------------------------------------------------------------------
MASTER_CATALOG_DB_0135 = os.path.join(CACHE_DIR, 'mediahub-master.db')
MASTER_CATALOG_TMP_0135 = MASTER_CATALOG_DB_0135 + '.new'
MASTER_CATALOG_LOCK_0135 = MASTER_CATALOG_DB_0135 + '.lock'
MASTER_CATALOG_SCHEMA_0135 = 1
MASTER_CATALOG_CONTRACT_0135 = 'persistent-master-v1'
MASTER_METRICS_FILE_0135 = os.path.join(STATE_DIR, 'master-catalog-metrics.json')
_CATALOG_TEXTURE_LOCAL_CACHE_0137 = {}

_source_library_movies_0135 = library_movies
_source_library_series_0135 = library_series
_source_steam_games_0135 = steam_games
_source_mixed_items_0135 = mixed_items
_source_limit_and_sort_0135 = limit_and_sort
_source_choose_fanart_0135 = choose_one_random_cached_fanart_per_item
_source_export_diagnostics_0135 = export_diagnostics


def _catalog_now_0135():
    return int(time.time())


def _catalog_json_0135(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(',', ':'), default=str)


def _catalog_hash_0135(value):
    return hashlib.sha256(_catalog_json_0135(value).encode('utf-8')).hexdigest()


def _catalog_db_connect_0135(path=None, readonly=False):
    target = path or MASTER_CATALOG_DB_0135
    if readonly:
        uri = 'file:{}?mode=ro'.format(urllib.parse.quote(os.path.abspath(target).replace('\\', '/'), safe='/:'))
        con = sqlite3.connect(uri, uri=True, timeout=5.0)
        try:
            con.execute('PRAGMA query_only=ON')
        except Exception:
            pass
    else:
        con = sqlite3.connect(target, timeout=30.0)
        try:
            con.execute('PRAGMA busy_timeout=30000')
        except Exception:
            pass
    con.row_factory = sqlite3.Row
    return con


def _catalog_init_schema_0135(con, fast_build=False):
    if fast_build:
        # The replacement DB is private until quick_check + os.replace. The
        # previous live catalog remains the crash-safe copy throughout.
        con.executescript("""
            PRAGMA journal_mode=OFF;
            PRAGMA synchronous=OFF;
            PRAGMA temp_store=MEMORY;
            PRAGMA locking_mode=EXCLUSIVE;
        """)
    else:
        con.executescript("""
            PRAGMA journal_mode=DELETE;
            PRAGMA synchronous=NORMAL;
            PRAGMA temp_store=MEMORY;
        """)
    con.executescript("""
        CREATE TABLE IF NOT EXISTS metadata (
            key TEXT PRIMARY KEY,
            value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS items (
            item_key TEXT PRIMARY KEY,
            media_type TEXT NOT NULL,
            source_id TEXT NOT NULL,
            item_json TEXT NOT NULL,
            item_hash TEXT NOT NULL,
            fanart_local TEXT NOT NULL DEFAULT '',
            screensaver_ready INTEGER NOT NULL DEFAULT 0,
            source_updated_at TEXT NOT NULL DEFAULT '',
            updated_at INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS idx_items_type ON items(media_type);
        CREATE TABLE IF NOT EXISTS list_order (
            list_name TEXT NOT NULL,
            item_key TEXT NOT NULL,
            random_rank REAL NOT NULL,
            PRIMARY KEY(list_name, item_key)
        );
        CREATE INDEX IF NOT EXISTS idx_list_order_rank ON list_order(list_name, random_rank);
        CREATE TABLE IF NOT EXISTS phase_metrics (
            phase TEXT PRIMARY KEY,
            elapsed_ms INTEGER NOT NULL,
            item_count INTEGER NOT NULL,
            detail_json TEXT NOT NULL,
            recorded_at INTEGER NOT NULL
        );
    """)
    con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('schema_version', str(MASTER_CATALOG_SCHEMA_0135)))
    con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('contract', MASTER_CATALOG_CONTRACT_0135))

def _catalog_record_metric_0135(con, phase, started, item_count=0, detail=None):
    elapsed = int((time.perf_counter() - started) * 1000)
    con.execute(
        'INSERT OR REPLACE INTO phase_metrics(phase,elapsed_ms,item_count,detail_json,recorded_at) VALUES(?,?,?,?,?)',
        (str(phase), elapsed, int(item_count or 0), _catalog_json_0135(detail or {}), _catalog_now_0135()),
    )
    return elapsed


def _catalog_file_signature_0135(path):
    real = str(path or '').strip()
    try:
        if real and os.path.isfile(real):
            st = os.stat(real)
            return '{}:{}:{}'.format(os.path.basename(real), int(st.st_mtime_ns), int(st.st_size))
    except Exception:
        pass
    return ''


def _catalog_latest_video_db_0135():
    db_dir = tr('special://profile/Database')
    candidates = glob.glob(os.path.join(db_dir, 'MyVideos*.db'))
    def version(path):
        m = re.search(r'MyVideos(\d+)\.db$', os.path.basename(path), re.I)
        return int(m.group(1)) if m else 0
    candidates.sort(key=version, reverse=True)
    return candidates[0] if candidates else ''


def _catalog_settings_signature_0135():
    payload = {
        'include_movies': setting_bool('include_movies', True),
        'include_series': setting_bool('include_series', True),
        'include_games': setting_bool('include_games', True),
        'exclude_fanart_below_1080p': setting_bool('exclude_fanart_below_1080p', True),
        'exclude_without_clearlogo': setting_bool('exclude_without_clearlogo', True),
        'exclude_hidden_games': setting_bool('exclude_hidden_games', True),
        'steam_addon_id': steam_addon_id(),
        'contract': MASTER_CATALOG_CONTRACT_0135,
    }
    return _catalog_hash_0135(payload)


def _catalog_source_signatures_0135():
    return {
        'video': _catalog_file_signature_0135(_catalog_latest_video_db_0135()),
        'steam': _catalog_file_signature_0135(steam_db_path()),
        'resolver': _catalog_file_signature_0135(KPM_CLEARLOGO_RESOLVER_DB),
        'settings': _catalog_settings_signature_0135(),
    }


def _catalog_read_metadata_0135(path=None):
    target = path or MASTER_CATALOG_DB_0135
    if not os.path.isfile(target):
        return {}
    con = None
    try:
        con = _catalog_db_connect_0135(target, readonly=True)
        return {str(row['key']): str(row['value']) for row in con.execute('SELECT key,value FROM metadata')}
    except Exception:
        return {}
    finally:
        if con:
            con.close()


def _catalog_is_usable_0135():
    meta = _catalog_read_metadata_0135()
    return bool(
        meta.get('schema_version') == str(MASTER_CATALOG_SCHEMA_0135)
        and meta.get('contract') == MASTER_CATALOG_CONTRACT_0135
        and os.path.isfile(MASTER_CATALOG_DB_0135)
    )


def _catalog_needs_refresh_0135():
    if not _catalog_is_usable_0135():
        return True
    meta = _catalog_read_metadata_0135()
    current = _catalog_source_signatures_0135()
    # Steam metadata changes are handled by the AppID incremental refresher.
    # They must not force a full Movies/Series/Games rebuild at startup.
    return any(meta.get('signature_' + key, '') != current.get(key, '') for key in ('video','settings'))


def _catalog_acquire_lock_0135():
    ensure_runtime_dirs()
    try:
        fd = os.open(MASTER_CATALOG_LOCK_0135, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        os.write(fd, '{}\n'.format(os.getpid()).encode('ascii', 'ignore'))
        os.close(fd)
        return True
    except FileExistsError:
        try:
            if time.time() - os.path.getmtime(MASTER_CATALOG_LOCK_0135) > 900:
                os.remove(MASTER_CATALOG_LOCK_0135)
                return _catalog_acquire_lock_0135()
        except Exception:
            pass
        return False
    except Exception:
        return False


def _catalog_release_lock_0135():
    try:
        if os.path.exists(MASTER_CATALOG_LOCK_0135):
            os.remove(MASTER_CATALOG_LOCK_0135)
    except Exception:
        pass


def _catalog_collect_fanart_urls_0137(items):
    urls = []
    seen = set()
    for item in items or []:
        art = item.get('art') or {}
        candidates = list(item.get('_fanart_candidates') or []) + [art.get('fanart')]
        for value in candidates:
            raw = str(value or '').strip()
            if raw and raw not in seen:
                seen.add(raw)
                urls.append(raw)
    return urls


def _catalog_batch_texture_lookup_0137(items):
    """Prime fanart size/local caches using one Textures DB connection."""
    urls = _catalog_collect_fanart_urls_0137(items)
    pending = [u for u in urls if u not in _TEXTURE_SIZE_CACHE or u not in _CATALOG_TEXTURE_LOCAL_CACHE_0137]
    if not pending:
        return {'urls': len(urls), 'resolved': 0, 'db_queries': 0}

    variant_map = {}
    for raw in pending:
        for variant in image_url_candidates(raw):
            variant_map.setdefault(variant, []).append(raw)

    resolved_rows = {}
    texture_id_for_raw = {}
    size_by_id = {}
    query_count = 0
    db_path = texture_db_path()
    con = None
    try:
        if db_path and os.path.isfile(db_path) and variant_map:
            uri = 'file:{}?mode=ro'.format(urllib.parse.quote(os.path.abspath(db_path).replace('\\', '/'), safe='/:'))
            con = sqlite3.connect(uri, uri=True, timeout=5.0)
            con.row_factory = sqlite3.Row
            texture_cols = {str(r[1]) for r in con.execute('PRAGMA table_info(texture)').fetchall()}
            if 'url' in texture_cols:
                variants = list(variant_map)
                for offset in range(0, len(variants), 400):
                    part = variants[offset:offset + 400]
                    placeholders = ','.join(['?'] * len(part))
                    sql = 'SELECT rowid AS _rowid,* FROM texture WHERE url IN ({}) ORDER BY rowid DESC'.format(placeholders)
                    query_count += 1
                    for row in con.execute(sql, part):
                        stored = str(row['url'] or '')
                        row_keys = set(row.keys())
                        texture_id = None
                        for id_col in ('idtexture', 'id', '_rowid'):
                            if id_col in row_keys and row[id_col] is not None:
                                texture_id = int(row[id_col])
                                break
                        for raw in variant_map.get(stored, []):
                            if raw not in resolved_rows:
                                resolved_rows[raw] = row
                                if texture_id is not None:
                                    texture_id_for_raw[raw] = texture_id

                size_exists = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='sizes'").fetchone()
                size_cols = {str(r[1]) for r in con.execute('PRAGMA table_info(sizes)').fetchall()} if size_exists else set()
                if {'idtexture', 'width', 'height'}.issubset(size_cols):
                    ids = sorted(set(texture_id_for_raw.values()))
                    for offset in range(0, len(ids), 500):
                        part = ids[offset:offset + 500]
                        placeholders = ','.join(['?'] * len(part))
                        query_count += 1
                        for row in con.execute(
                            'SELECT idtexture,width,height FROM sizes WHERE idtexture IN ({}) ORDER BY (width*height) DESC'.format(placeholders),
                            part,
                        ):
                            tid = int(row['idtexture'])
                            if tid not in size_by_id and as_int(row['width'], 0) and as_int(row['height'], 0):
                                size_by_id[tid] = (as_int(row['width'], 0), as_int(row['height'], 0))
    except Exception as exc:
        log('Batch texture lookup failed: {}'.format(exc), xbmc.LOGWARNING)
    finally:
        if con is not None:
            con.close()

    resolved = 0
    file_header_reads = 0
    for raw in pending:
        row = resolved_rows.get(raw)
        result = None
        local = ''
        if row is not None:
            keys = set(row.keys())
            width = as_int(row['width'], 0) if 'width' in keys else 0
            height = as_int(row['height'], 0) if 'height' in keys else 0
            tid = texture_id_for_raw.get(raw)
            if not (width and height) and tid in size_by_id:
                width, height = size_by_id[tid]
            if 'cachedurl' in keys and row['cachedurl']:
                candidate = cached_texture_path(row['cachedurl'])
                if candidate and os.path.isfile(candidate):
                    local = candidate
            if width and height:
                result = (width, height, 'texture-db-batch')
            elif local:
                file_header_reads += 1
                size = image_size_from_file(local)
                if size:
                    result = (size[0], size[1], 'thumbnail-cache-batch')
        if result is None:
            local_source = local_source_from_image_url(raw)
            if local_source and os.path.isfile(local_source):
                local = local_source
                file_header_reads += 1
                size = image_size_from_file(local_source)
                if size:
                    result = (size[0], size[1], 'local-file-batch')
        _TEXTURE_SIZE_CACHE[raw] = result
        _CATALOG_TEXTURE_LOCAL_CACHE_0137[raw] = local
        if result:
            resolved += 1
    return {
        'urls': len(urls), 'resolved': resolved, 'db_queries': query_count,
        'file_header_reads': file_header_reads,
    }

def _catalog_batch_cropv2_lookup_0137(items):
    result = {}
    unresolved = []
    for item in items or []:
        props = item.get('props') or {}
        art = item.get('art') or {}
        key = str(props.get('mediahub_item_key') or '').strip()
        if not key:
            continue
        direct = _cropv2_from_source(str(art.get('clearlogo') or '').strip())
        if direct:
            result[key] = direct
        else:
            unresolved.append(key)
    if not unresolved or not os.path.isfile(KPM_CLEARLOGO_RESOLVER_DB):
        return result
    con = None
    try:
        uri = 'file:{}?mode=ro'.format(urllib.parse.quote(os.path.abspath(KPM_CLEARLOGO_RESOLVER_DB).replace('\\', '/'), safe='/:'))
        con = sqlite3.connect(uri, uri=True, timeout=5.0)
        con.row_factory = sqlite3.Row
        for offset in range(0, len(unresolved), 500):
            part = unresolved[offset:offset + 500]
            placeholders = ','.join(['?'] * len(part))
            for row in con.execute(
                'SELECT item_key,resolved_path FROM resolver_items WHERE item_key IN ({})'.format(placeholders),
                part,
            ):
                path = str(row['resolved_path'] or '')
                if path and os.path.isfile(path) and os.path.getsize(path) > 0:
                    result[str(row['item_key'])] = path
    except Exception as exc:
        log('Batch CropV2 lookup failed: {}'.format(exc), xbmc.LOGWARNING)
    finally:
        if con is not None:
            con.close()
    return result


def _catalog_cached_texture_local_0135(url):
    raw = str(url or '').strip()
    if not raw:
        return ''
    if raw in _CATALOG_TEXTURE_LOCAL_CACHE_0137:
        return _CATALOG_TEXTURE_LOCAL_CACHE_0137.get(raw) or ''
    local = local_source_from_image_url(raw)
    if local and os.path.isfile(local):
        return local
    db_path = texture_db_path()
    if not db_path or not os.path.isfile(db_path):
        return ''
    con = None
    try:
        con = sqlite3.connect(db_path, timeout=2.0)
        con.row_factory = sqlite3.Row
        candidates = image_url_candidates(raw)
        placeholders = ','.join(['?'] * len(candidates))
        row = con.execute(
            'SELECT cachedurl FROM texture WHERE url IN ({}) ORDER BY rowid DESC LIMIT 1'.format(placeholders),
            candidates,
        ).fetchone()
        if row and row['cachedurl']:
            path = cached_texture_path(row['cachedurl'])
            return path if os.path.isfile(path) else ''
    except Exception:
        return ''
    finally:
        if con:
            con.close()
    return ''


def _catalog_pick_stable_fanart_0135(item):
    clone = dict(item or {})
    clone['art'] = dict(clone.get('art') or {})
    clone['props'] = dict(clone.get('props') or {})
    key = str(clone['props'].get('mediahub_item_key') or '').strip()
    candidates = []
    for candidate in list(clone.get('_fanart_candidates') or []) + [clone['art'].get('fanart')]:
        candidate = str(candidate or '').strip()
        if candidate and candidate not in candidates:
            candidates.append(candidate)
    valid = []
    for source in candidates:
        size = texture_size_from_db(source)
        if not size:
            continue
        if setting_bool('exclude_fanart_below_1080p', True) and (int(size[0]) < MIN_1080P_WIDTH or int(size[1]) < MIN_1080P_HEIGHT):
            continue
        local = _catalog_cached_texture_local_0135(source)
        valid.append((source, local))
    if valid:
        digest = int(hashlib.sha1((key or clone.get('label', '')).encode('utf-8')).hexdigest()[:12], 16)
        source, local = valid[digest % len(valid)]
        clone['props']['mediahub_fanart_source'] = source
        clone['props']['mediahub_fanart_local'] = local
        clone['props']['mediahub_catalog_fanart_ready'] = 'true'
        clone['art']['fanart'] = local or source
        clone['_fanart_candidates'] = [local or source]
        clone['_valid_fanart_candidates'] = [local or source]
    return clone


def _catalog_screensaver_ready_0135(item, cropv2_map=None):
    props = item.get('props') or {}
    art = item.get('art') or {}
    key = str(props.get('mediahub_item_key') or '').strip()
    if not key:
        return 0
    if setting_bool('exclude_without_clearlogo', True):
        if cropv2_map is not None:
            if not str(cropv2_map.get(key) or '').strip():
                return 0
        else:
            resolver = _resolver_cropv2(key, str(art.get('clearlogo') or '').strip())
            if not str(resolver.get('path') or '').strip():
                return 0
    if not str(art.get('fanart') or '').strip():
        return 0
    return 1

def _catalog_preserved_orders_0135():
    result = {}
    if not _catalog_is_usable_0135():
        return result
    con = None
    try:
        con = _catalog_db_connect_0135(readonly=True)
        for row in con.execute('SELECT list_name,item_key,random_rank FROM list_order'):
            result[(str(row['list_name']), str(row['item_key']))] = float(row['random_rank'])
    except Exception:
        return {}
    finally:
        if con:
            con.close()
    return result


def _catalog_rank_0135(preserved, list_name, item_key):
    found = preserved.get((list_name, item_key))
    if found is not None:
        return float(found)
    return random_mod.SystemRandom().random()


def _catalog_source_id_0135(item):
    props = item.get('props') or {}
    info = item.get('info') or {}
    if item.get('kind') == 'game':
        return str(props.get('steam_appid') or props.get('appid') or info.get('dbid') or '')
    return str(props.get('dbid') or info.get('dbid') or '')


def _catalog_source_updated_0135(item):
    info = item.get('info') or {}
    return str(info.get('lastplayed') or info.get('dateadded') or '')


def _catalog_order_hash_from_rows_0137(rows):
    digest = hashlib.sha256()
    for list_name, item_key, rank in rows:
        digest.update(str(list_name).encode('utf-8'))
        digest.update(b'\x1f')
        digest.update(str(item_key).encode('utf-8'))
        digest.update(b'\x1f')
        digest.update(('{:.17g}'.format(float(rank))).encode('ascii'))
        digest.update(b'\n')
    return digest.hexdigest()


def refresh_master_catalog(force=False, reason='manual', randomize_orders=False, shuffle_session_id=''):
    ensure_runtime_dirs()
    if not force and not _catalog_needs_refresh_0135():
        return {'status': 'fresh', 'path': MASTER_CATALOG_DB_0135, 'shuffle_applied': False}
    if not _catalog_acquire_lock_0135():
        return {'status': 'busy', 'path': MASTER_CATALOG_DB_0135, 'shuffle_applied': False}
    started_all = time.perf_counter()
    preserved = {} if randomize_orders else _catalog_preserved_orders_0135()
    try:
        try:
            if os.path.exists(MASTER_CATALOG_TMP_0135):
                os.remove(MASTER_CATALOG_TMP_0135)
        except Exception:
            pass
        con = _catalog_db_connect_0135(MASTER_CATALOG_TMP_0135)
        _catalog_init_schema_0135(con, fast_build=True)
        source_started = time.perf_counter()
        movies = _source_library_movies_0135() if setting_bool('include_movies', True) else []
        series = _source_library_series_0135() if setting_bool('include_series', True) else []
        games = _source_steam_games_0135() if setting_bool('include_games', True) else []
        all_source = movies + series + games
        _catalog_record_metric_0135(con, 'source_read', source_started, len(all_source), {
            'movies': len(movies), 'series': len(series), 'games': len(games), 'reason': reason,
        })

        filter_started = time.perf_counter()
        texture_batch = _catalog_batch_texture_lookup_0137(all_source)
        movies = apply_item_filters(movies)
        series = apply_item_filters(series)
        games = apply_item_filters(games)
        prepared = [_catalog_pick_stable_fanart_0135(item) for item in movies + series + games]
        cropv2_map = _catalog_batch_cropv2_lookup_0137(prepared)
        _catalog_record_metric_0135(con, 'filter', filter_started, len(prepared), {
            'movies': len(movies), 'series': len(series), 'games': len(games), 'texture_batch': texture_batch,
            'cropv2_ready': len(cropv2_map),
        })

        write_started = time.perf_counter()
        type_keys = {'movies': [], 'series': [], 'games': [], 'mix': [], 'screensaver': []}
        item_rows = []
        now_value = _catalog_now_0135()
        for item in prepared:
            props = item.get('props') or {}
            key = str(props.get('mediahub_item_key') or '').strip()
            if not key:
                continue
            media_type = str(item.get('kind') or '')
            ready = _catalog_screensaver_ready_0135(item, cropv2_map=cropv2_map)
            payload = _catalog_json_0135(item)
            item_hash = hashlib.sha256(payload.encode('utf-8')).hexdigest()
            local = str((item.get('art') or {}).get('fanart') or '') if str(props.get('mediahub_fanart_local') or '') else ''
            item_rows.append((
                key, media_type, _catalog_source_id_0135(item), payload, item_hash, local, ready,
                _catalog_source_updated_0135(item), now_value,
            ))
            list_name = 'movies' if media_type == 'movie' else ('series' if media_type == 'series' else 'games')
            type_keys[list_name].append(key)
            type_keys['mix'].append(key)
            if ready:
                type_keys['screensaver'].append(key)

        con.executemany(
            'INSERT OR REPLACE INTO items(item_key,media_type,source_id,item_json,item_hash,fanart_local,screensaver_ready,source_updated_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)',
            item_rows,
        )
        rng = random_mod.SystemRandom()
        order_rows = []
        for list_name, keys in type_keys.items():
            for key in keys:
                rank = rng.random() if randomize_orders else _catalog_rank_0135(preserved, list_name, key)
                order_rows.append((list_name, key, rank))
        con.executemany('INSERT OR REPLACE INTO list_order(list_name,item_key,random_rank) VALUES(?,?,?)', order_rows)

        signatures = _catalog_source_signatures_0135()
        for key, value in signatures.items():
            con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('signature_' + key, value))
        con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('built_at', str(now_value)))
        con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('build_reason', str(reason)))
        if randomize_orders:
            after_hash = _catalog_order_hash_from_rows_0137(sorted(order_rows, key=lambda r: (r[0], r[1])))
            con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('last_shuffle_at', str(now_value)))
            con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('shuffle_session_id', str(shuffle_session_id or 'startup-build')))
            con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('shuffle_after_hash', after_hash))
            con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('shuffle_item_count', str(len(order_rows))))
            con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('shuffle_status', 'success'))
        _catalog_record_metric_0135(con, 'catalog_write', write_started, len(item_rows), {'lists': {k: len(v) for k, v in type_keys.items()}})
        _catalog_record_metric_0135(con, 'total_build', started_all, len(item_rows), {'reason': reason})
        con.commit()
        quick = con.execute('PRAGMA quick_check').fetchone()[0]
        con.close()
        if str(quick).lower() != 'ok':
            raise RuntimeError('Master catalog quick_check failed: {}'.format(quick))
        os.replace(MASTER_CATALOG_TMP_0135, MASTER_CATALOG_DB_0135)
        metrics = catalog_metrics_snapshot_0135()
        tmp_metrics = MASTER_METRICS_FILE_0135 + '.tmp'
        with open(tmp_metrics, 'w', encoding='utf-8') as handle:
            json.dump(metrics, handle, indent=2, ensure_ascii=False)
        os.replace(tmp_metrics, MASTER_METRICS_FILE_0135)
        elapsed = int((time.perf_counter() - started_all) * 1000)
        log('Master catalog ready: movies={}, series={}, games={}, mix={}, screensaver={}, shuffled={}, elapsed_ms={}'.format(
            len(type_keys['movies']), len(type_keys['series']), len(type_keys['games']), len(type_keys['mix']),
            len(type_keys['screensaver']), bool(randomize_orders), elapsed
        ), xbmc.LOGINFO)
        return {
            'status': 'rebuilt', 'counts': {k: len(v) for k, v in type_keys.items()},
            'path': MASTER_CATALOG_DB_0135, 'shuffle_applied': bool(randomize_orders), 'elapsed_ms': elapsed,
        }
    except Exception as exc:
        log('Master catalog refresh failed: {}\n{}'.format(exc, traceback.format_exc()), xbmc.LOGERROR)
        try:
            if os.path.exists(MASTER_CATALOG_TMP_0135):
                os.remove(MASTER_CATALOG_TMP_0135)
        except Exception:
            pass
        return {'status': 'error', 'error': str(exc), 'path': MASTER_CATALOG_DB_0135, 'shuffle_applied': False}
    finally:
        _catalog_release_lock_0135()

def _catalog_list_name_0135(kind):
    value = str(kind or '').strip().lower()
    if value in ('movie', 'movies'):
        return 'movies'
    if value in ('series', 'tvshow', 'tvshows'):
        return 'series'
    if value in ('game', 'games'):
        return 'games'
    if value in ('screensaver', 'screensaver_mix'):
        return 'screensaver'
    return 'mix'


def catalog_items_0135(list_name='mix'):
    list_name = _catalog_list_name_0135(list_name)
    if not _catalog_is_usable_0135():
        refresh_master_catalog(force=True, reason='first_widget_request')
    if not _catalog_is_usable_0135():
        return []
    con = None
    started = time.perf_counter()
    try:
        con = _catalog_db_connect_0135(readonly=True)
        rows = con.execute('''
            SELECT i.item_json
            FROM list_order o
            JOIN items i ON i.item_key=o.item_key
            WHERE o.list_name=?
            ORDER BY o.random_rank ASC
        ''', (list_name,)).fetchall()
        result = [json.loads(row['item_json']) for row in rows]
        elapsed_ms = (time.perf_counter()-started)*1000.0
        log('Master catalog read: list={}, items={}, elapsed_ms={}'.format(list_name, len(result), int(elapsed_ms)), xbmc.LOGINFO)
        try:
            _runtime_metrics_update_0135('cache_read', elapsed_ms, len(result), {'list': list_name})
        except Exception:
            pass
        return result
    except Exception as exc:
        log('Master catalog read failed: {}'.format(exc), xbmc.LOGWARNING)
        return []
    finally:
        if con:
            con.close()


def _catalog_rank_map_0135(list_name, keys):
    if not keys or not _catalog_is_usable_0135():
        return {}
    con = None
    try:
        con = _catalog_db_connect_0135(readonly=True)
        result = {}
        chunk = list(keys)
        for start in range(0, len(chunk), 500):
            part = chunk[start:start+500]
            placeholders = ','.join(['?'] * len(part))
            args = [list_name] + part
            for row in con.execute('SELECT item_key,random_rank FROM list_order WHERE list_name=? AND item_key IN ({})'.format(placeholders), args):
                result[str(row['item_key'])] = float(row['random_rank'])
        return result
    except Exception:
        return {}
    finally:
        if con:
            con.close()


def _catalog_item_key_0135(item):
    return str((item.get('props') or {}).get('mediahub_item_key') or '').strip()


def library_movies():
    items = catalog_items_0135('movies')
    return items if items else _source_library_movies_0135()


def library_series():
    items = catalog_items_0135('series')
    return items if items else _source_library_series_0135()


def steam_games():
    items = catalog_items_0135('games')
    return items if items else _source_steam_games_0135()


def mixed_items():
    items = catalog_items_0135('mix')
    return items if items else _source_mixed_items_0135()


def choose_one_random_cached_fanart_per_item(items, params):
    if items and all(str((item.get('props') or {}).get('mediahub_catalog_fanart_ready') or '') == 'true' for item in items[:20]):
        return list(items)
    return _source_choose_fanart_0135(items, params)


def limit_and_sort(items, params):
    force_unlimited = setting_bool('force_unlimited_output', True)
    default_limit = setting_int('default_limit', 0)
    limit = 0 if force_unlimited else as_int(params.get('limit'), default_limit)
    randomize = as_bool(params.get('random'), setting_bool('default_random', True))
    if randomize:
        list_name = _catalog_list_name_0135(params.get('_catalog_list') or params.get('mode') or 'mix')
        keys = [_catalog_item_key_0135(item) for item in items]
        ranks = _catalog_rank_map_0135(list_name, [key for key in keys if key])
        items.sort(key=lambda item: (ranks.get(_catalog_item_key_0135(item), 2.0), _catalog_item_key_0135(item)))
    else:
        items.sort(key=lambda x: re.sub(r'^(the|a|an)\s+', '', x.get('label', '').lower()))
    if limit > 0:
        items = items[:limit]
    return items


def _prefetch_local_fanart_0135(items, count=16):
    warmed = 0
    for item in list(items)[:max(0, int(count))]:
        path = str((item.get('art') or {}).get('fanart') or '').strip()
        if path.startswith('special://'):
            path = tr(path)
        if path and os.path.isfile(path):
            try:
                with open(path, 'rb') as handle:
                    handle.read(128 * 1024)
                warmed += 1
            except Exception:
                pass
    return warmed


def cached_screensaver_items():
    items = catalog_items_0135('screensaver')
    if not items:
        payload = _load_screensaver_cache_any_0133() or prepare_screensaver_cache(force=True)
        items = list((payload or {}).get('items') or [])
    items = items[:_screensaver_session_limit()]
    _prefetch_local_fanart_0135(items, 24)
    return [_screensaver_compactify_item_0133(item) for item in items]


def prepare_screensaver_cache(force=False):
    result = refresh_master_catalog(force=bool(force), reason='screensaver_warmup')
    items = catalog_items_0135('screensaver')
    payload = {
        'version': 5,
        'bridge_mode': SCREENSAVER_BRIDGE_MODE_0132,
        'atomic_bundle_contract': 'v1',
        'master_catalog_contract': MASTER_CATALOG_CONTRACT_0135,
        'built_at': _catalog_now_0135(),
        'source_items': len(catalog_items_0135('mix')),
        'prepared_items': len(items),
        'elapsed_ms': 0,
        'items': items,
        'refresh': result,
    }
    return payload


def load_screensaver_cache(max_age=1800):
    if not _catalog_is_usable_0135():
        return None
    meta = _catalog_read_metadata_0135()
    try:
        built_at = int(meta.get('built_at') or 0)
    except Exception:
        built_at = 0
    if max_age < 10**8 and built_at and time.time() - built_at > max_age and _catalog_needs_refresh_0135():
        return None
    return {
        'version': 5,
        'bridge_mode': SCREENSAVER_BRIDGE_MODE_0132,
        'atomic_bundle_contract': 'v1',
        'master_catalog_contract': MASTER_CATALOG_CONTRACT_0135,
        'built_at': built_at,
        'source_items': len(catalog_items_0135('mix')),
        'prepared_items': len(catalog_items_0135('screensaver')),
        'items': catalog_items_0135('screensaver'),
    }


def catalog_metrics_snapshot_0135():
    result = {'path': MASTER_CATALOG_DB_0135, 'exists': os.path.isfile(MASTER_CATALOG_DB_0135), 'metadata': {}, 'counts': {}, 'phases': []}
    if not result['exists']:
        return result
    con = None
    try:
        con = _catalog_db_connect_0135(readonly=True)
        result['metadata'] = {str(row['key']): str(row['value']) for row in con.execute('SELECT key,value FROM metadata')}
        result['counts'] = {str(row['media_type']): int(row['count']) for row in con.execute('SELECT media_type,COUNT(*) AS count FROM items GROUP BY media_type')}
        result['counts']['screensaver'] = int(con.execute('SELECT COUNT(*) FROM items WHERE screensaver_ready=1').fetchone()[0])
        for row in con.execute('SELECT phase,elapsed_ms,item_count,detail_json,recorded_at FROM phase_metrics ORDER BY phase'):
            entry = dict(row)
            try:
                entry['detail'] = json.loads(entry.pop('detail_json'))
            except Exception:
                entry['detail'] = entry.pop('detail_json')
            result['phases'].append(entry)
        result['bytes'] = os.path.getsize(MASTER_CATALOG_DB_0135)
    except Exception as exc:
        result['error'] = str(exc)
    finally:
        if con:
            con.close()
    return result


def catalog_refresh_single_0135(media_type, source_id, reason='notification'):
    # True per-DBID refresh for Kodi movies/TV shows. Steam updates are compared
    # by AppID during the periodic source refresh because Steam exposes no Kodi
    # notification per changed game.
    media_type = str(media_type or '').lower()
    source_id = str(source_id or '').strip()
    if media_type not in ('movie', 'tvshow', 'series') or not source_id.isdigit() or not _catalog_is_usable_0135():
        return False
    try:
        numeric = int(source_id)
        if media_type == 'movie':
            props = [
                'title','originaltitle','sorttitle','year','genre','plot','plotoutline','tagline','rating','userrating','playcount','runtime','studio','director','writer','mpaa','premiered','dateadded','lastplayed','thumbnail','fanart','art'
            ]
            raw = jsonrpc('VideoLibrary.GetMovieDetails', {'movieid': numeric, 'properties': props}).get('moviedetails') or {}
            if not raw:
                return catalog_delete_single_0135('movie', source_id)
            raw['movieid'] = numeric
            # Reuse the canonical converter by temporarily wrapping one result.
            item = None
            title = raw.get('title') or 'Movie {}'.format(numeric)
            art = pick_art(raw, 'movie')
            item = {
                'kind':'movie','label':title,'url':url_for(mode='play_movie',movieid=numeric),'is_folder':False,
                'art':art,'_fanart_candidates':collect_fanart_candidates(raw, art.get('fanart')),
                'info':{'mediatype':'movie','dbid':numeric,'title':title,'originaltitle':raw.get('originaltitle') or title,'sorttitle':raw.get('sorttitle') or title,'plot':clean_text(raw.get('plot') or raw.get('plotoutline') or ''),'plotoutline':clean_text(raw.get('plotoutline') or raw.get('plot') or ''),'tagline':clean_text(raw.get('tagline') or ''),'year':as_int(raw.get('year'),0),'genre':genre_text(raw.get('genre')),'rating':first_number(raw.get('rating'),0),'userrating':as_int(raw.get('userrating'),0),'playcount':as_int(raw.get('playcount'),0),'runtime':as_int(raw.get('runtime'),0),'studio':genre_text(raw.get('studio')),'mpaa':raw.get('mpaa') or '','premiered':raw.get('premiered') or '','dateadded':raw.get('dateadded') or '','lastplayed':raw.get('lastplayed') or ''},
                'props':{'mediahub_type':'movie','mediahub_item_key':mediahub_item_key('movie',numeric),'dbid':source_id,'source':'Kodi Movies','IsPlayable':'true'},
            }
        else:
            props = ['title','year','genre','plot','rating','userrating','playcount','studio','mpaa','premiered','dateadded','lastplayed','thumbnail','fanart','art','episode','season']
            raw = jsonrpc('VideoLibrary.GetTVShowDetails', {'tvshowid': numeric, 'properties': props}).get('tvshowdetails') or {}
            if not raw:
                return catalog_delete_single_0135('series', source_id)
            title = raw.get('title') or 'Series {}'.format(numeric)
            art = pick_art(raw, 'tvshow')
            item = {
                'kind':'series','label':title,'url':url_for(mode='open_series',tvshowid=numeric),'is_folder':False,
                'art':art,'_fanart_candidates':collect_fanart_candidates(raw, art.get('fanart')),
                'info':{'mediatype':'tvshow','dbid':numeric,'title':title,'sorttitle':title,'plot':clean_text(raw.get('plot') or ''),'plotoutline':clean_text(raw.get('plot') or ''),'year':as_int(raw.get('year'),0),'genre':genre_text(raw.get('genre')),'rating':first_number(raw.get('rating'),0),'userrating':as_int(raw.get('userrating'),0),'playcount':as_int(raw.get('playcount'),0),'studio':genre_text(raw.get('studio')),'mpaa':raw.get('mpaa') or '','premiered':raw.get('premiered') or '','dateadded':raw.get('dateadded') or '','lastplayed':raw.get('lastplayed') or '','episode':as_int(raw.get('episode'),0),'season':as_int(raw.get('season'),0)},
                'props':{'mediahub_type':'series','mediahub_item_key':mediahub_item_key('tvshow',numeric),'dbid':source_id,'source':'Kodi TV Shows','episode_count':str(as_int(raw.get('episode'),0)),'season_count':str(as_int(raw.get('season'),0)),'IsPlayable':'false'},
            }
        filtered = apply_item_filters([item])
        if not filtered:
            return catalog_delete_single_0135(item.get('kind'), source_id)
        item = _catalog_pick_stable_fanart_0135(filtered[0])
        return catalog_upsert_single_0135(item, reason)
    except Exception as exc:
        log('Incremental catalog refresh failed for {} {}: {}'.format(media_type, source_id, exc), xbmc.LOGWARNING)
        return False


def catalog_upsert_single_0135(item, reason='incremental'):
    if not _catalog_is_usable_0135():
        return False
    props = item.get('props') or {}
    key = str(props.get('mediahub_item_key') or '').strip()
    if not key:
        return False
    media_type = str(item.get('kind') or '')
    payload = _catalog_json_0135(item)
    ready = _catalog_screensaver_ready_0135(item)
    payload_hash = hashlib.sha256(payload.encode('utf-8')).hexdigest()
    source_id = _catalog_source_id_0135(item)
    fanart_local = str(props.get('mediahub_fanart_local') or '')
    source_updated = _catalog_source_updated_0135(item)
    list_name = 'movies' if media_type == 'movie' else ('series' if media_type == 'series' else 'games')
    desired_lists = {list_name, 'mix'} | ({'screensaver'} if ready else set())
    con = _catalog_db_connect_0135()
    try:
        old = con.execute('SELECT media_type,source_id,item_hash,fanart_local,screensaver_ready,source_updated_at FROM items WHERE item_key=?', (key,)).fetchone()
        old_lists = {str(row[0]) for row in con.execute('SELECT list_name FROM list_order WHERE item_key=?', (key,)).fetchall()}
        if old is not None and (
            str(old[0] or '') == media_type
            and str(old[1] or '') == str(source_id or '')
            and str(old[2] or '') == payload_hash
            and str(old[3] or '') == fanart_local
            and int(old[4] or 0) == int(ready or 0)
            and str(old[5] or '') == str(source_updated or '')
            and old_lists == desired_lists
        ):
            return False
        con.execute('BEGIN IMMEDIATE')
        con.execute('INSERT OR REPLACE INTO items(item_key,media_type,source_id,item_json,item_hash,fanart_local,screensaver_ready,source_updated_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)', (
            key, media_type, source_id, payload, payload_hash, fanart_local, ready, source_updated, _catalog_now_0135()
        ))
        for name in (list_name, 'mix') + (('screensaver',) if ready else tuple()):
            exists = con.execute('SELECT 1 FROM list_order WHERE list_name=? AND item_key=?', (name,key)).fetchone()
            if not exists:
                con.execute('INSERT INTO list_order(list_name,item_key,random_rank) VALUES(?,?,?)', (name,key,random_mod.SystemRandom().random()))
        if not ready:
            con.execute('DELETE FROM list_order WHERE list_name=? AND item_key=?', ('screensaver',key))
        con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('last_incremental_reason', str(reason)))
        con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('last_incremental_at', str(_catalog_now_0135())))
        con.commit()
        return True
    finally:
        con.close()


def catalog_delete_single_0135(media_type, source_id):
    if not _catalog_is_usable_0135():
        return False
    kind = 'tvshow' if str(media_type).lower() in ('tvshow','series') else str(media_type).lower()
    key = mediahub_item_key(kind, source_id)
    if not key:
        return False
    con = _catalog_db_connect_0135()
    try:
        exists = con.execute('SELECT 1 FROM items WHERE item_key=?', (key,)).fetchone()
        if not exists:
            return False
        con.execute('BEGIN IMMEDIATE')
        con.execute('DELETE FROM list_order WHERE item_key=?', (key,))
        con.execute('DELETE FROM items WHERE item_key=?', (key,))
        con.commit()
        return True
    finally:
        con.close()


def export_diagnostics():
    _source_export_diagnostics_0135()
    try:
        candidates = [os.path.join(PROFILE, name) for name in os.listdir(PROFILE) if name.startswith('mediahub-widget-diagnostics-') and name.endswith('.zip')]
        if not candidates:
            return
        path = max(candidates, key=os.path.getmtime)
        snapshot = catalog_metrics_snapshot_0135()
        with zipfile.ZipFile(path, 'a', zipfile.ZIP_DEFLATED) as zf:
            zf.writestr('summary/master-catalog.json', json.dumps(snapshot, indent=2, ensure_ascii=False) + '\n')
            if os.path.isfile(MASTER_METRICS_FILE_0135):
                zf.write(MASTER_METRICS_FILE_0135, 'runtime/state/master-catalog-metrics.json')
    except Exception as exc:
        log('Master catalog diagnostics append failed: {}'.format(exc), xbmc.LOGWARNING)


def run():
    params = parse_params()
    raw_mode = str(params.get('mode', 'root') or 'root').strip().lower()
    if raw_mode.startswith('screensaver_'):
        params['_screensaver'] = 'true'
    mode = normalize_mode(raw_mode)
    params['_catalog_list'] = 'screensaver' if is_screensaver_request(params) else _catalog_list_name_0135(mode)
    try:
        if mode == 'root':
            root()
        elif mode == 'mix':
            if is_screensaver_request(params):
                params['_screensaver_cached'] = 'true'
                output_items(cached_screensaver_items(), 'movies', params)
            else:
                output_items(mixed_items(), 'movies', params)
        elif mode == 'movies':
            output_items(library_movies(), 'movies', params)
        elif mode == 'series':
            output_items(library_series(), 'tvshows', params)
        elif mode == 'games':
            output_items(steam_games(), 'movies', params)
        elif mode == 'play_movie':
            play_movie(params.get('movieid')); xbmcplugin.endOfDirectory(HANDLE)
        elif mode == 'open_series':
            open_series(params.get('tvshowid')); xbmcplugin.endOfDirectory(HANDLE)
        elif mode == 'play_game':
            play_game(params.get('appid')); xbmcplugin.endOfDirectory(HANDLE)
        elif mode == 'tools':
            tools_menu(); xbmcplugin.endOfDirectory(HANDLE)
        elif mode == 'view_status':
            view_status(); xbmcplugin.endOfDirectory(HANDLE)
        elif mode == 'export_diagnostics':
            export_diagnostics(); xbmcplugin.endOfDirectory(HANDLE)
        elif mode == 'view_item_properties':
            view_item_properties(params); xbmcplugin.endOfDirectory(HANDLE)
        elif mode == 'settings':
            open_settings(); xbmcplugin.endOfDirectory(HANDLE)
        else:
            xbmcplugin.endOfDirectory(HANDLE)
    except Exception as exc:
        log('Router error: {}\n{}'.format(exc, traceback.format_exc()), xbmc.LOGERROR)
        try:
            li = xbmcgui.ListItem(label='MediaHub Widget error', offscreen=True)
            safe_set_info(li, {'title':'MediaHub Widget error','plot':str(exc)})
            xbmcplugin.addDirectoryItem(HANDLE, url_for(mode='root'), li, False)
            xbmcplugin.endOfDirectory(HANDLE)
        except Exception:
            pass


_MWH_OUTPUT_TIMING_0135 = {'listitem_build_ms': 0.0, 'kodi_output_ms': 0.0, 'count': 0}


def _runtime_metrics_update_0135(phase, elapsed_ms, item_count=0, detail=None):
    ensure_runtime_dirs()
    payload = {}
    try:
        if os.path.isfile(MASTER_METRICS_FILE_0135):
            with open(MASTER_METRICS_FILE_0135, 'r', encoding='utf-8') as handle:
                payload = json.load(handle)
    except Exception:
        payload = {}
    runtime = payload.setdefault('runtime_phases', {})
    runtime[str(phase)] = {
        'elapsed_ms': int(round(float(elapsed_ms or 0))),
        'item_count': int(item_count or 0),
        'detail': detail or {},
        'recorded_at': _catalog_now_0135(),
    }
    tmp = MASTER_METRICS_FILE_0135 + '.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, indent=2, ensure_ascii=False)
        os.replace(tmp, MASTER_METRICS_FILE_0135)
    except Exception:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except Exception:
            pass


def add_media_item(item, total=0, bundle_slot=''):
    build_started = time.perf_counter()
    li = xbmcgui.ListItem(label=item.get('label') or '', offscreen=True)
    safe_set_info(li, item.get('info') or {})
    safe_set_art(li, item.get('art') or {})
    for k, v in (item.get('props') or {}).items():
        try:
            li.setProperty(str(k), str(v))
        except Exception:
            pass
    kind = item.get('kind') or 'media'
    props = item.get('props') or {}
    stable_key = str(props.get('mediahub_item_key') or '').strip()
    if not stable_key:
        stable_key = mediahub_item_key(
            kind,
            props.get('dbid') or (item.get('info') or {}).get('dbid'),
            props.get('steam_appid') or props.get('appid'),
        )
    li.setProperty('mediahub_widget', 'true')
    li.setProperty('mediahub_kind', kind)
    li.setProperty('source_addon', ADDON_ID)
    li.setProperty('mediahub_item_key', stable_key)
    if bundle_slot in ('A', 'B'):
        li.setProperty('mediahub_bundle_slot', bundle_slot)
    if kind == 'game':
        li.setProperty('kpm_item_type', 'game')
        li.setProperty('kpm_data_owner', ADDON_ID)
        li.setProperty('DBTYPE', 'game')
        li.setProperty('dbtype', 'game')
        li.setProperty('MediaType', 'game')
        li.setProperty('mediatype', 'game')
    if kind == 'movie':
        li.addContextMenuItems([
            ('Play movie', 'RunPlugin({})'.format(item.get('url'))),
            ('Open library item', 'ActivateWindow(Videos,videodb://movies/titles/{}/,return)'.format(props.get('dbid') or item.get('info', {}).get('dbid') or '')),
            ('View item properties', 'RunPlugin({})'.format(url_for(mode='view_item_properties', kind=kind, dbid=props.get('dbid') or '', label=item.get('label') or ''))),
        ])
    elif kind == 'series':
        li.addContextMenuItems([
            ('Open series', 'RunPlugin({})'.format(item.get('url'))),
            ('Open library item', 'ActivateWindow(Videos,videodb://tvshows/titles/{}/,return)'.format(props.get('dbid') or item.get('info', {}).get('dbid') or '')),
            ('View item properties', 'RunPlugin({})'.format(url_for(mode='view_item_properties', kind=kind, dbid=props.get('dbid') or '', label=item.get('label') or ''))),
        ])
    elif kind == 'game':
        appid = props.get('steam_appid') or props.get('appid') or item.get('info', {}).get('dbid') or ''
        li.addContextMenuItems([
            ('Launch Steam game', 'RunPlugin({})'.format(item.get('url'))),
            ('Open in Steam Library', 'ActivateWindow(Programs,plugin://{}?mode=list&collection=__all__,return)'.format(steam_addon_id())),
            ('View game properties', 'RunPlugin({})'.format(url_for(mode='view_item_properties', kind=kind, appid=appid, label=item.get('label') or ''))),
        ])
    set_item_path(li, item.get('url'))
    _MWH_OUTPUT_TIMING_0135['listitem_build_ms'] += (time.perf_counter() - build_started) * 1000.0
    output_started = time.perf_counter()
    xbmcplugin.addDirectoryItem(HANDLE, item.get('url'), li, bool(item.get('is_folder', False)), total)
    _MWH_OUTPUT_TIMING_0135['kodi_output_ms'] += (time.perf_counter() - output_started) * 1000.0
    _MWH_OUTPUT_TIMING_0135['count'] += 1


def output_items(items, content='movies', params=None):
    params = params or {}
    total_started = time.perf_counter()
    _MWH_OUTPUT_TIMING_0135.update({'listitem_build_ms': 0.0, 'kodi_output_ms': 0.0, 'count': 0})
    filter_started = time.perf_counter()
    items = choose_one_random_cached_fanart_per_item(list(items), params)
    catalog_ready = bool(items) and all(
        str((item.get('props') or {}).get('mediahub_catalog_fanart_ready') or '') == 'true'
        for item in items[:min(20, len(items))]
    )
    if not catalog_ready and not as_bool(params.get('_screensaver_cached'), False):
        items = apply_item_filters(items)
    items = limit_and_sort(items, params)
    filter_ms = (time.perf_counter() - filter_started) * 1000.0
    try:
        xbmcplugin.setContent(HANDLE, content)
    except Exception:
        pass
    total = len(items)
    for index, item in enumerate(items):
        # Two display slots preserve the outgoing metadata snapshot while the
        # incoming screensaver slide is prepared.
        add_media_item(item, total, 'A' if index % 2 == 0 else 'B')
    end_started = time.perf_counter()
    try:
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_LABEL_IGNORE_THE)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_YEAR)
        xbmcplugin.addSortMethod(HANDLE, xbmcplugin.SORT_METHOD_VIDEO_RATING)
    except Exception:
        pass
    xbmcplugin.endOfDirectory(HANDLE)
    _MWH_OUTPUT_TIMING_0135['kodi_output_ms'] += (time.perf_counter() - end_started) * 1000.0
    if setting_bool('force_poster_view', False):
        try:
            xbmc.executebuiltin('Container.SetViewMode({})'.format(setting_int('poster_view_id', 502)))
        except Exception:
            pass
    list_name = _catalog_list_name_0135(params.get('_catalog_list') or 'mix')
    _runtime_metrics_update_0135('filter', filter_ms, total, {'list': list_name, 'catalog_ready': catalog_ready})
    _runtime_metrics_update_0135('listitem_build', _MWH_OUTPUT_TIMING_0135['listitem_build_ms'], total, {'list': list_name})
    _runtime_metrics_update_0135('kodi_output', _MWH_OUTPUT_TIMING_0135['kodi_output_ms'], total, {'list': list_name})
    _runtime_metrics_update_0135('widget_total', (time.perf_counter()-total_started)*1000.0, total, {'list': list_name})


def _catalog_video_structure_signature_0135():
    path = _catalog_latest_video_db_0135()
    if not path or not os.path.isfile(path):
        return ''
    con = None
    result = {}
    try:
        con = sqlite3.connect('file:{}?mode=ro'.format(urllib.parse.quote(os.path.abspath(path).replace('\\','/'), safe='/:')), uri=True, timeout=2.0)
        for table, id_col in (('movie','idMovie'), ('tvshow','idShow')):
            exists = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
            if not exists:
                result[table] = [0,0]
                continue
            row = con.execute('SELECT COUNT(*), COALESCE(MAX({}),0) FROM {}'.format(id_col, table)).fetchone()
            result[table] = [int(row[0] or 0), int(row[1] or 0)]
        return _catalog_hash_0135(result)
    except Exception:
        return _catalog_file_signature_0135(path)
    finally:
        if con:
            con.close()


def _catalog_steam_semantic_signature_0137():
    path = steam_db_path()
    if not path or not os.path.isfile(path):
        return ''
    con = None
    digest = hashlib.sha256()
    try:
        uri = 'file:{}?mode=ro'.format(urllib.parse.quote(os.path.abspath(path).replace('\\', '/'), safe='/:'))
        con = sqlite3.connect(uri, uri=True, timeout=5.0)
        con.row_factory = sqlite3.Row
        cols = [str(r[1]) for r in con.execute('PRAGMA table_info(games)').fetchall()]
        wanted = [c for c in (
            'appid','name','steam_name','display_name','sortname','year','developer','publisher','genres','tagline','short_description',
            'steam_review_percent','steam_review_desc','steam_review_total','steam250_rank','steam250_score',
            'achievement_unlocked','achievement_total','completed','finished','metacritic_score','playtime_forever','esrb','pegi',
            'poster_url','thumb_url','clearlogo_url','fanart_url','fanart1_url','fanart2_url','fanart3_url','fanart4_url'
        ) if c in cols]
        if not wanted:
            return _catalog_file_signature_0135(path)
        sql = 'SELECT {} FROM games ORDER BY appid'.format(','.join(['"{}"'.format(c) for c in wanted]))
        digest.update(('games:' + ','.join(wanted) + '\n').encode('utf-8'))
        for row in con.execute(sql):
            for col in wanted:
                digest.update(str(row[col] if row[col] is not None else '').encode('utf-8', 'surrogatepass'))
                digest.update(b'\x1f')
            digest.update(b'\n')
        for table, columns in (
            ('library_membership', ('appid','is_active')),
            ('hidden_games', ('appid',)),
            ('manual_hidden_games', ('appid',)),
        ):
            exists = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
            if not exists:
                continue
            available = {str(r[1]) for r in con.execute('PRAGMA table_info("{}")'.format(table)).fetchall()}
            selected = [c for c in columns if c in available]
            if not selected:
                continue
            digest.update(('table:' + table + ':' + ','.join(selected) + '\n').encode('utf-8'))
            query = 'SELECT {} FROM "{}" ORDER BY {}'.format(','.join(selected), table, selected[0])
            for row in con.execute(query):
                digest.update('|'.join(str(row[c] if row[c] is not None else '') for c in selected).encode('utf-8'))
                digest.update(b'\n')
        return 'steam-content-v1:' + digest.hexdigest()
    except Exception as exc:
        log('Steam semantic signature fallback: {}'.format(exc), xbmc.LOGWARNING)
        return _catalog_file_signature_0135(path)
    finally:
        if con is not None:
            con.close()


def _catalog_resolver_semantic_signature_0137():
    """Hash only resolver data that can change MWH output.

    KPM may update SQLite timestamps even when the resolved CropV2 paths are
    unchanged. A file-mtime signature therefore caused needless full catalog
    rebuilds. Ignore bookkeeping columns and hash the effective mapping only.
    """
    path = KPM_CLEARLOGO_RESOLVER_DB
    if not path or not os.path.isfile(path):
        return ''
    con = None
    digest = hashlib.sha256()
    try:
        uri = 'file:{}?mode=ro'.format(urllib.parse.quote(os.path.abspath(path).replace('\\', '/'), safe='/:'))
        con = sqlite3.connect(uri, uri=True, timeout=5.0)
        con.row_factory = sqlite3.Row
        exists = con.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name='resolver_items'").fetchone()
        if not exists:
            return _catalog_file_signature_0135(path)
        available = {str(r[1]) for r in con.execute('PRAGMA table_info(resolver_items)').fetchall()}
        wanted = [c for c in ('item_key','status','resolved_path','canonical_source','source_hash') if c in available]
        if 'item_key' not in wanted:
            return _catalog_file_signature_0135(path)
        digest.update(('resolver_items:' + ','.join(wanted) + '\n').encode('utf-8'))
        sql = 'SELECT {} FROM resolver_items ORDER BY item_key'.format(','.join(['"{}"'.format(c) for c in wanted]))
        for row in con.execute(sql):
            for col in wanted:
                digest.update(str(row[col] if row[col] is not None else '').encode('utf-8', 'surrogatepass'))
                digest.update(b'\x1f')
            digest.update(b'\n')
        return 'resolver-content-v1:' + digest.hexdigest()
    except Exception as exc:
        log('Resolver semantic signature fallback: {}'.format(exc), xbmc.LOGWARNING)
        return _catalog_file_signature_0135(path)
    finally:
        if con is not None:
            con.close()


def _catalog_source_signatures_0135():
    return {
        'video': _catalog_video_structure_signature_0135(),
        'steam': _catalog_steam_semantic_signature_0137(),
        'resolver': _catalog_resolver_semantic_signature_0137(),
        'settings': _catalog_settings_signature_0135(),
    }


def refresh_resolver_catalog_incremental_0137(reason='resolver_content_changed'):
    """Refresh screensaver membership without rebuilding source media."""
    if not _catalog_is_usable_0135():
        return refresh_master_catalog(force=True, reason=reason)
    current_sig = _catalog_resolver_semantic_signature_0137()
    meta = _catalog_read_metadata_0135()
    if meta.get('signature_resolver', '') == current_sig:
        return {'status': 'fresh', 'source': 0, 'changed': 0}
    started = time.perf_counter()
    con = _catalog_db_connect_0135()
    try:
        rows = con.execute('SELECT item_key,item_json,screensaver_ready FROM items').fetchall()
        items = []
        prior = {}
        for row in rows:
            try:
                item = json.loads(str(row['item_json'] or '{}'))
            except Exception:
                continue
            key = str(row['item_key'])
            item.setdefault('props', {})['mediahub_item_key'] = key
            items.append(item)
            prior[key] = int(row['screensaver_ready'] or 0)
        cropv2_map = _catalog_batch_cropv2_lookup_0137(items)
        rng = random_mod.SystemRandom()
        changed = 0
        con.execute('BEGIN IMMEDIATE')
        for item in items:
            key = str((item.get('props') or {}).get('mediahub_item_key') or '')
            ready = _catalog_screensaver_ready_0135(item, cropv2_map=cropv2_map)
            if ready != prior.get(key, 0):
                con.execute('UPDATE items SET screensaver_ready=?,updated_at=? WHERE item_key=?', (ready, _catalog_now_0135(), key))
                changed += 1
            if ready:
                exists = con.execute("SELECT 1 FROM list_order WHERE list_name='screensaver' AND item_key=?", (key,)).fetchone()
                if not exists:
                    con.execute("INSERT INTO list_order(list_name,item_key,random_rank) VALUES('screensaver',?,?)", (key, rng.random()))
            else:
                con.execute("DELETE FROM list_order WHERE list_name='screensaver' AND item_key=?", (key,))
        con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('signature_resolver', current_sig))
        con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('last_incremental_reason', reason))
        con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('last_incremental_at', str(_catalog_now_0135())))
        elapsed = int((time.perf_counter() - started) * 1000)
        con.execute('INSERT OR REPLACE INTO phase_metrics(phase,elapsed_ms,item_count,detail_json,recorded_at) VALUES(?,?,?,?,?)', (
            'resolver_incremental', elapsed, len(items), _catalog_json_0135({'changed': changed, 'reason': reason}), _catalog_now_0135(),
        ))
        con.commit()
        log('Resolver catalog incremental refresh: source={}, changed={}, elapsed_ms={}'.format(len(items), changed, elapsed), xbmc.LOGINFO)
        return {'status': 'incremental', 'source': len(items), 'changed': changed, 'elapsed_ms': elapsed}
    except Exception as exc:
        try:
            con.rollback()
        except Exception:
            pass
        log('Resolver incremental refresh failed: {}'.format(exc), xbmc.LOGWARNING)
        return {'status': 'error', 'error': str(exc)}
    finally:
        con.close()


def catalog_refresh_episode_parent_0135(episode_id, reason='episode_update'):
    try:
        episode_id = int(episode_id)
        details = jsonrpc('VideoLibrary.GetEpisodeDetails', {
            'episodeid': episode_id,
            'properties': ['tvshowid'],
        }).get('episodedetails') or {}
        tvshowid = str(details.get('tvshowid') or '').strip()
        return catalog_refresh_single_0135('tvshow', tvshowid, reason=reason) if tvshowid else False
    except Exception as exc:
        log('Episode parent refresh failed for {}: {}'.format(episode_id, exc), xbmc.LOGWARNING)
        return False


def refresh_steam_catalog_incremental_0135(reason='steam_db_changed'):
    if not _catalog_is_usable_0135():
        return refresh_master_catalog(force=True, reason=reason)
    current_sig = _catalog_source_signatures_0135().get('steam', '')
    meta = _catalog_read_metadata_0135()
    if current_sig and meta.get('signature_steam', '') == current_sig:
        return {'status': 'fresh', 'source': 0, 'changed': 0, 'removed': 0}
    started = time.perf_counter()
    source = _source_steam_games_0135() if setting_bool('include_games', True) else []
    texture_batch = _catalog_batch_texture_lookup_0137(source)
    source = apply_item_filters(source)
    source = [_catalog_pick_stable_fanart_0135(item) for item in source]
    cropv2_map = _catalog_batch_cropv2_lookup_0137(source)
    con = _catalog_db_connect_0135()
    changed = 0
    removed = 0
    try:
        con.execute('BEGIN IMMEDIATE')
        existing = {
            str(row['item_key']): str(row['item_hash'])
            for row in con.execute("SELECT item_key,item_hash FROM items WHERE media_type='game'")
        }
        existing_orders = {(str(row['list_name']), str(row['item_key'])) for row in con.execute(
            "SELECT list_name,item_key FROM list_order WHERE list_name IN ('games','mix','screensaver')"
        )}
        seen = set()
        rng = random_mod.SystemRandom()
        for item in source:
            props = item.get('props') or {}
            key = str(props.get('mediahub_item_key') or '').strip()
            if not key:
                continue
            seen.add(key)
            payload = _catalog_json_0135(item)
            item_hash = hashlib.sha256(payload.encode('utf-8')).hexdigest()
            ready = _catalog_screensaver_ready_0135(item, cropv2_map=cropv2_map)
            if existing.get(key) != item_hash:
                con.execute('INSERT OR REPLACE INTO items(item_key,media_type,source_id,item_json,item_hash,fanart_local,screensaver_ready,source_updated_at,updated_at) VALUES(?,?,?,?,?,?,?,?,?)', (
                    key, 'game', _catalog_source_id_0135(item), payload, item_hash,
                    str(props.get('mediahub_fanart_local') or ''), ready,
                    _catalog_source_updated_0135(item), _catalog_now_0135(),
                ))
                changed += 1
            wanted_lists = ('games','mix') + (('screensaver',) if ready else tuple())
            for list_name in wanted_lists:
                if (list_name, key) not in existing_orders:
                    con.execute('INSERT INTO list_order(list_name,item_key,random_rank) VALUES(?,?,?)', (list_name,key,rng.random()))
            if not ready:
                con.execute("DELETE FROM list_order WHERE list_name='screensaver' AND item_key=?", (key,))
        for key in set(existing) - seen:
            con.execute('DELETE FROM list_order WHERE item_key=?', (key,))
            con.execute('DELETE FROM items WHERE item_key=?', (key,))
            removed += 1
        con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('signature_steam', current_sig))
        con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('last_incremental_reason', reason))
        con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('last_incremental_at', str(_catalog_now_0135())))
        elapsed = int((time.perf_counter()-started)*1000)
        con.execute('INSERT OR REPLACE INTO phase_metrics(phase,elapsed_ms,item_count,detail_json,recorded_at) VALUES(?,?,?,?,?)', (
            'steam_incremental', elapsed, len(source),
            _catalog_json_0135({'changed':changed,'removed':removed,'reason':reason,'texture_batch':texture_batch}), _catalog_now_0135(),
        ))
        con.commit()
        log('Steam catalog incremental refresh: source={}, changed={}, removed={}, elapsed_ms={}'.format(len(source),changed,removed,elapsed), xbmc.LOGINFO)
        return {'status':'incremental','source':len(source),'changed':changed,'removed':removed,'elapsed_ms':elapsed}
    except Exception as exc:
        try: con.rollback()
        except Exception: pass
        log('Steam incremental refresh failed: {}'.format(exc), xbmc.LOGWARNING)
        return {'status':'error','error':str(exc)}
    finally:
        con.close()

def _catalog_order_hash_0137(con):
    rows = con.execute('SELECT list_name,item_key,random_rank FROM list_order ORDER BY list_name,item_key').fetchall()
    return _catalog_order_hash_from_rows_0137([
        (str(row['list_name']), str(row['item_key']), float(row['random_rank'])) for row in rows
    ]), len(rows)


def shuffle_catalog_orders_0135(session_id='', notify_user=True):
    if not _catalog_is_usable_0135():
        refresh_master_catalog(force=True, reason='shuffle_missing_catalog', randomize_orders=True, shuffle_session_id=session_id)
    if not _catalog_is_usable_0135():
        if notify_user:
            notify('CATALOG NOT READY')
        return False
    started = time.perf_counter()
    con = _catalog_db_connect_0135()
    try:
        con.execute('BEGIN IMMEDIATE')
        before_hash, count = _catalog_order_hash_0137(con)
        con.execute('UPDATE list_order SET random_rank=(random() + 9223372036854775808.0) / 18446744073709551616.0')
        after_hash, _ = _catalog_order_hash_0137(con)
        if count > 1 and after_hash == before_hash:
            con.execute('UPDATE list_order SET random_rank=(random() + 9223372036854775808.0) / 18446744073709551616.0')
            after_hash, _ = _catalog_order_hash_0137(con)
        if count > 1 and after_hash == before_hash:
            raise RuntimeError('shuffle verification hash did not change')
        now_value = _catalog_now_0135()
        for key, value in (
            ('last_shuffle_at', str(now_value)),
            ('shuffle_session_id', str(session_id or 'manual')),
            ('shuffle_before_hash', before_hash),
            ('shuffle_after_hash', after_hash),
            ('shuffle_item_count', str(count)),
            ('shuffle_status', 'success'),
        ):
            con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', (key, value))
        con.commit()
        elapsed = int((time.perf_counter() - started) * 1000)
        log('Persistent catalog shuffle committed: rows={}, elapsed_ms={}, before={}, after={}, session={}'.format(
            count, elapsed, before_hash[:12], after_hash[:12], session_id or 'manual'
        ), xbmc.LOGINFO)
        if notify_user:
            notify('PERSISTENT LISTS SHUFFLED')
        return True
    except Exception as exc:
        try:
            con.rollback()
        except Exception:
            pass
        try:
            con.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', ('shuffle_status', 'failed:' + str(exc)))
            con.commit()
        except Exception:
            pass
        log('Persistent list shuffle failed: {}'.format(exc), xbmc.LOGERROR)
        if notify_user:
            notify('SHUFFLE FAILED')
        return False
    finally:
        con.close()

def tools_menu():
    opts = ['View Status', 'Rebuild Master Catalog', 'Shuffle Persistent Lists', 'Export diagnostics ZIP', 'Settings', 'Exit']
    n = xbmcgui.Dialog().select(ADDON_NAME + ' - Tools', opts)
    if n == 0:
        view_status()
    elif n == 1:
        result = refresh_master_catalog(force=True, reason='manual_rebuild')
        notify('CATALOG REBUILT' if result.get('status') == 'rebuilt' else 'CATALOG ' + str(result.get('status') or 'FAILED').upper())
    elif n == 2:
        shuffle_catalog_orders_0135()
    elif n == 3:
        export_diagnostics()
    elif n == 4:
        open_settings()


if __name__ == "__main__":
    run()

MediaHub Widget 0.1.22
=========================

- Force unlimited output for every widget = ON by default.
- Default item limit = 0.
- All root widget paths use limit=0.
- Old widget URLs with limit=100 are ignored while force-unlimited is ON.
- Movies, series, Steam games, mixed output, and screensaver output share the
  same unlimited policy.
- Filtering and randomization remain unchanged.

Turn Force unlimited output OFF to restore normal URL/default-limit behavior.

MediaHub Widget 0.1.23
======================

- Adds mediahub_item_key to every output ListItem.
- Movie format: movie|<Kodi movie DBID>.
- TV show format: tvshow|<Kodi TV show DBID>.
- Steam game format: game|steam|<Steam AppID>.
- The key is exposed both in the item property payload and directly on the Kodi ListItem.
- KPM/LRS can now fail closed during Arctic Mirage transitions instead of reusing the previous slide logo.

MediaHub Widget 0.1.24
========================

- Arctic Mirage screensaver keeps exactly one slide per movie, TV show, or game.
- Each screensaver build randomly selects one fanart from the main fanart and registered extra fanart candidates.
- Only artwork already available through Kodi texture cache or a local file is eligible; no network download is performed.
- The 1080p filter is applied per candidate before random selection.
- Clearlogo identity and mediahub_item_key behavior from 0.1.23 are unchanged.

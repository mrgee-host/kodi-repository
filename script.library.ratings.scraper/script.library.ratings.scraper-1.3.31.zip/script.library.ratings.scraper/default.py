# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import xbmcgui
from resources.lib import core

TITLE = "Library Ratings Scraper"


def online_sources():
    keys = core.api_keys()
    online = []
    if core.bool_setting("use_mdblist", True) and keys.get("mdblist"):
        online.append("MDBList")
    if core.bool_setting("use_tmdb", True) and keys.get("tmdb"):
        online.append("TMDb")
    if core.bool_setting("use_omdb", True) and keys.get("omdb"):
        online.append("OMDb")
    return online


def show_stats() -> None:
    stats = core.cache_stats(core.load_cache())
    sources = ", ".join("{0}: {1}".format(k, v) for k, v in sorted(stats.get("sources", {}).items())) or "belum ada"
    xbmcgui.Dialog().textviewer(
        TITLE,
        "Total cache: {0}\nFilm: {1}\nSerial: {2}\nEpisode: {3}\nCache segar: {4}\nItem dengan rating: {5}\nIMDb Top 250: {6}\n\nSumber rating:\n{7}".format(
            stats["total"], stats["movie"], stats["tvshow"], stats["episode"], stats["fresh"], stats["with_ratings"], stats.get("imdb_top250", 0), sources
        ),
    )


def queue_scrape(force: bool = False) -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if state.get("status") in ("queued", "running", "finishing"):
        dialog.notification(TITLE, "Scrape background masih berjalan", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return

    online = online_sources()
    if not online:
        if not dialog.yesno(
            TITLE,
            "Tidak ada API key online yang terbaca.\n\nLanjutkan hanya untuk menyalin rating lokal Kodi ke cache?",
            nolabel="Batal",
            yeslabel="Lanjutkan",
        ):
            return

    mode = "refresh paksa seluruh library" if force else "item baru dan cache kedaluwarsa"
    if not dialog.yesno(
        TITLE,
        "Mulai scrape di latar belakang?\n\nMode: {0}\nSumber online: {1}\n\nKodi tetap dapat dipakai selama proses berjalan.".format(mode, ", ".join(online) or "tidak ada"),
        nolabel="Batal",
        yeslabel="Mulai",
    ):
        return

    core.queue_background_job("scrape", force=force)
    dialog.notification(TITLE, "Scrape masuk antrean background", xbmcgui.NOTIFICATION_INFO, 5000, False)


def queue_top250() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if state.get("status") in ("queued", "running", "finishing"):
        dialog.notification(TITLE, "Proses background masih berjalan", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return
    core.queue_background_job("top250", force=True)
    dialog.notification(TITLE, "Sinkronisasi IMDb Top 250 film/serial dimulai di background", xbmcgui.NOTIFICATION_INFO, 5000, False)


def show_background_status() -> None:
    state = core.background_job_state()
    status = state.get("status") or "idle"
    action = state.get("action") or "-"
    total = state.get("total") or 0
    processed = state.get("processed") or 0
    percent = state.get("percent") or 0
    updated = state.get("updated") or 0
    skipped = state.get("skipped") or 0
    failed = state.get("failed") or 0
    current = state.get("current") or "-"
    started = state.get("started_at") or "-"
    finished = state.get("finished_at") or "-"
    report = state.get("report") or "-"
    extra = ""
    if action == "top250":
        sync = core.top250_last_sync()
        if sync:
            extra = "\n\nTop250 detail:\nChart movie: {0}\nChart TV: {1}\nMovie match: {2}\nTV match: {3}\nMissing IMDb ID: {4}".format(
                sync.get("movie_chart_items") or 0,
                sync.get("tv_chart_items") or 0,
                sync.get("movie_matched") or 0,
                sync.get("tv_matched") or 0,
                sync.get("missing_imdb") or 0,
            )
    xbmcgui.Dialog().textviewer(
        TITLE,
        "Status: {0}\nAksi: {1}\nProgress: {2}% ({3}/{4})\nSedang diproses: {5}\n\nDiperbarui: {6}\nSkip: {7}\nGagal: {8}{12}\n\nMulai: {9}\nSelesai: {10}\nLaporan CSV: {11}".format(
            status, action, percent, processed, total, current, updated, skipped, failed, started, finished, report, extra
        ),
    )


def cancel_background() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if state.get("status") not in ("queued", "running", "finishing", "force_stop_requested"):
        dialog.notification(TITLE, "Tidak ada scrape background aktif", xbmcgui.NOTIFICATION_INFO, 4000, False)
        return
    if dialog.yesno(TITLE, "Batalkan proses background yang sedang berjalan?", nolabel="Tidak", yeslabel="Batalkan"):
        core.request_background_cancel()
        dialog.notification(TITLE, "Permintaan pembatalan dikirim", xbmcgui.NOTIFICATION_INFO, 4000, False)


def force_stop_background() -> None:
    dialog = xbmcgui.Dialog()
    if dialog.yesno(TITLE, "FORCE STOP proses background sekarang?\n\nIni lebih kasar dari batal biasa. Proses akan dihentikan secepat service kembali dari request yang sedang berjalan.", nolabel="Tidak", yeslabel="Force stop"):
        core.request_background_force_stop()
        dialog.notification(TITLE, "Force stop dikirim", xbmcgui.NOTIFICATION_WARNING, 5000, False)



def _enabled_media_text() -> str:
    parts = [
        "Movies={0}".format("ON" if core.bool_setting("include_movies", True) else "OFF"),
        "Series={0}".format("ON" if core.bool_setting("include_tvshows", True) else "OFF"),
        "Episodes={0}".format("ON" if core.bool_setting("include_episodes", True) else "OFF"),
    ]
    return ", ".join(parts)

def test_random_ratings() -> None:
    dialog = xbmcgui.Dialog()
    sample_size = max(1, min(25, core.int_setting("sample_check_size", 5)))
    enabled_media = _enabled_media_text()
    if not dialog.yesno(
        TITLE,
        "Cek LIVE internet sesuai setting sekarang?\n\nJenis media: {0}\nSample: {1} item per jenis aktif\n\nRating yang dicek mengikuti checkbox Movies/Series/Episodes. Cache tidak dipakai sebagai hasil dan tidak disimpan.".format(enabled_media, sample_size),
        nolabel="Batal",
        yeslabel="Mulai",
    ):
        return
    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Cek rating random...")
    try:
        report = core.sample_rating_test(sample_size, progress)
    finally:
        try:
            progress.close()
        except Exception:  # pylint: disable=broad-except
            pass
    log_path = core.write_sample_rating_test_log(report)
    text = core.format_sample_rating_test_report(report)
    text += "\n\nLog detail disimpan di:\n{0}".format(log_path)
    dialog.textviewer(TITLE + " - Check Random Live", text)


def export_only() -> None:
    path = core.export_csv(core.load_cache())
    xbmcgui.Dialog().ok(TITLE, "Laporan CSV diperbarui:", path)


def clear_cache() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if state.get("status") in ("queued", "running", "finishing"):
        dialog.ok(TITLE, "Scrape background masih berjalan. Batalkan atau tunggu selesai sebelum menghapus cache.")
        return
    if not dialog.yesno(
        TITLE,
        "Hapus cache rating scraper ini?\n\nCache TMDbHelper dan database video Kodi tidak akan disentuh.",
        nolabel="Batal",
        yeslabel="Hapus",
    ):
        return
    try:
        for path in (core.CACHE_FILE, core.REPORT_FILE, core.SUMMARY_FILE, core.BACKGROUND_STATE_FILE, core.BACKGROUND_REQUEST_FILE, core.BACKGROUND_CANCEL_FILE, core.BACKGROUND_FORCE_STOP_FILE):
            if os.path.exists(path):
                os.remove(path)
    except OSError as exc:
        dialog.ok(TITLE, "Gagal menghapus cache:\n{0}".format(exc))
        return
    dialog.ok(TITLE, "Cache scraper sudah dihapus.")


def main() -> None:
    dialog = xbmcgui.Dialog()
    options = [
        "Scrape item baru / cache kedaluwarsa (background)",
        "Refresh paksa seluruh library (background)",
        "Lihat status scrape background",
        "Batalkan scrape background",
        "Force stop scrape background",
        "Check random LIVE internet",
        "Lihat statistik cache",
        "Export ulang laporan CSV",
        "Sinkronkan ranking IMDb Top 250 film/serial (background)",
        "Buka pengaturan",
        "Hapus cache scraper",
    ]
    choice = dialog.select(TITLE, options)
    if choice == 0:
        queue_scrape(False)
    elif choice == 1:
        queue_scrape(True)
    elif choice == 2:
        show_background_status()
    elif choice == 3:
        cancel_background()
    elif choice == 4:
        force_stop_background()
    elif choice == 5:
        test_random_ratings()
    elif choice == 6:
        show_stats()
    elif choice == 7:
        export_only()
    elif choice == 8:
        queue_top250()
    elif choice == 9:
        core.ADDON.openSettings()
    elif choice == 10:
        clear_cache()


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import time
import xbmc
import xbmcgui
from resources.lib import core

POLL_SECONDS = 0.10
STATE_FILE = os.path.join(core.PROFILE, "service-state.json")
TITLE = "Library Ratings Scraper"


def load_state():
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as handle:
            row = json.load(handle)
        return row if isinstance(row, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(state):
    os.makedirs(core.PROFILE, exist_ok=True)
    temp = STATE_FILE + ".tmp"
    with open(temp, "w", encoding="utf-8") as handle:
        json.dump(state, handle, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(temp, STATE_FILE)


def current_context_item():
    if core.player_context_active():
        return "player", core.player_item()

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item
    item = core.lrs_active_item()
    if core.valid_library_item(item):
        return "lrs_active", item
    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity
    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}


def context_log(state, context, item_key, title, published, reason):
    # Heavy focus/publish trace. Keep it out of kodi.log unless verbose diagnostics is enabled.
    try:
        if not core.verbose_debug_enabled():
            return
    except Exception:
        return
    signature = "{0}|{1}|{2}|{3}".format(context, item_key, int(bool(published)), reason)
    if state.get("last_context_log") == signature:
        return
    state["last_context_log"] = signature
    clean_title = str(title or "").replace("\\n", " ")[:80]
    core.log(
        "context={0} item_key={1} title={2} published={3} reason={4}".format(
            context, item_key or "", clean_title, "yes" if published else "no", reason
        ),
        xbmc.LOGDEBUG,
    )


def _record_from_cache(cache, item, preload=None):
    preload = preload or {}
    identity = core.identity_key(item)
    cached = preload.get(identity)
    if isinstance(cached, dict):
        return cached
    return core.cache_record(cache, item)


def queue_item(queue, queued, item, front=False):
    # Background lookup requires a Kodi DBID. Title-only hub fallbacks can still
    # publish cached values, but should not be looked up online as a new item.
    if not core.resolvable_library_item(item):
        return
    key = core.item_key(item)
    if key in queued:
        return
    queued.add(key)
    if front:
        queue.insert(0, item)
    else:
        queue.append(item)


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}

    if not core.valid_library_item(item):
        core.clear_af3_properties(compatibility)
        context_log(state, context, "", item.get("title") if isinstance(item, dict) else "", False, "identity_missing")
        return ""

    active_key = core.identity_key(item)
    if active_key != previous_key:
        # Clear first on every context/key change. If cache lookup misses or waits
        # one cycle, AF3 sees blank properties instead of the previous item.
        core.publish_af3_properties({}, active_key, compatibility)

    record = _record_from_cache(cache, item, preload)
    if not record and context == "player":
        # Player/OSD must not stay blank just because the service loaded cache
        # before a manual scrape/rebuild finished. Reload DB once on player miss.
        try:
            fresh_cache = core.load_cache()
            record = _record_from_cache(fresh_cache, item, preload)
            if record:
                cache.clear(); cache.update(fresh_cache)
        except Exception:  # pylint: disable=broad-except
            record = None
    if not record:
        core.publish_af3_properties({}, active_key, compatibility)
        context_log(state, context, active_key, item.get("title"), False, "cache_miss")
        return active_key

    if not core.context_matches_record(item, record):
        core.publish_af3_properties({}, active_key, compatibility)
        context_log(state, context, active_key, item.get("title"), False, "stale_guard")
        return active_key

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    core.publish_af3_properties(values, publish_key, compatibility)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), True, "cache_hit")
    return active_key


def item_label(item):
    title = item.get("title") or "Untitled"
    if item.get("type") == "episode":
        return "{0} - S{1:02d}E{2:02d} - {3}".format(
            item.get("showtitle") or "Series",
            core.safe_int(item.get("season")) or 0,
            core.safe_int(item.get("episode")) or 0,
            title,
        )
    return title


def notify(message, icon=xbmcgui.NOTIFICATION_INFO, duration=5000):
    xbmcgui.Dialog().notification(TITLE, message, icon, duration, False)


def write_job_state(job, status=None):
    item_total = len(job.get("items") or [])
    raw_total = job.get("total")
    total = int(raw_total) if raw_total not in (None, "") and int(raw_total or 0) > 0 else item_total
    processed = int(job.get("processed") or job.get("index") or 0)
    if total and processed > total:
        processed = total
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    state = {
        "status": status or job.get("status") or "running",
        "action": job.get("action") or "scrape",
        "force": bool(job.get("force")),
        "requested_at": job.get("requested_at") or "",
        "started_at": job.get("started_at") or "",
        "finished_at": job.get("finished_at") or "",
        "total": total,
        "processed": processed,
        "percent": percent,
        "updated": int(job.get("updated") or 0),
        "matched": int(job.get("matched") or 0),
        "skipped": int(job.get("skipped") or 0),
        "failed": int(job.get("failed") or 0),
        "current": job.get("current") or "",
        "report": job.get("report") or "",
    }
    core.save_background_state(state)


def compact_text(value, limit=26):
    text = str(value or "Preparing...").replace("\n", " ").strip()
    return text if len(text) <= limit else text[: max(0, limit - 3)].rstrip() + "..."


def update_bg(job, message=None):
    progress = job.get("progress")
    if progress is None:
        return
    total = int(job.get("total") or len(job.get("items") or []))
    processed = int(job.get("processed") or job.get("index") or 0)
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    # Keep the background notification deliberately minimal. Arctic Fuse 3
    # only has room for one compact body line. Detailed counters remain
    # available from the add-on menu: "View background status".
    text = message or "{0}/{1}  {2}".format(
        processed,
        total,
        compact_text(job.get("current")),
    )
    progress.update(percent, TITLE, compact_text(text, 58))


def new_scrape_job(request):
    items = core.library_items()
    action = request.get("action") or "scrape"
    awards_only = action == "awards"
    if awards_only:
        items = [item for item in items if core.media_setting_type(item.get("type")) in ("movie", "tvshow")]
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, "0/0 awards - Starting" if awards_only else "0/0 ratings - Starting")
    total = len(items)
    job = {
        "action": action,
        "awards_only": awards_only,
        "force": bool(request.get("force")),
        "requested_at": request.get("requested_at") or core.now_iso(),
        "started_at": core.now_iso(),
        "items": items,
        "keys": core.api_keys(),
        "index": 0,
        "updated": 0,
        "matched": 0,
        "processed": 0,
        "total": total,
        "skipped": 0,
        "failed": 0,
        "looked_up": 0,
        "current": "Preparing...",
        "next_at": 0.0,
        "progress": progress,
        "status": "running",
    }
    write_job_state(job)
    notify("Awards-only scrape running" if awards_only else "Background scrape running", xbmcgui.NOTIFICATION_INFO, 5000)
    return job


def new_top250_job(request):
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, "0/0 top250 - Starting")
    job = {
        "action": "top250",
        "force": True,
        "requested_at": request.get("requested_at") or core.now_iso(),
        "started_at": core.now_iso(),
        "items": [],
        "index": 0,
        "updated": 0,
        "skipped": 0,
        "failed": 0,
        "matched": 0,
        "processed": 0,
        "total": 0,
        "current": "IMDb Top 250",
        "progress": progress,
        "status": "running",
    }
    write_job_state(job)
    notify("IMDb Top 250 update running in background", xbmcgui.NOTIFICATION_INFO, 5000)
    return job


def finish_job(job, cache, canceled=False, stopped_reason=""):
    job["status"] = "finishing"
    write_job_state(job, "finishing")
    update_bg(job, "Saving cache...")
    core.save_cache(cache)

    if job.get("action") == "scrape" and not canceled and not stopped_reason:
        job["phase"] = "top250"
        job["current"] = "Starting"
        update_bg(job)
        try:
            stats = core.sync_imdb_top250_to_library(False, None)
            job["matched"] = int(stats.get("matched") or 0)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("IMDb Top 250 sync failed after background scrape: {0}".format(exc), xbmc.LOGWARNING)
    elif job.get("action") == "top250" and not canceled:
        job["phase"] = "top250"
        job["current"] = "Starting"
        update_bg(job)
        try:
            stats = core.sync_imdb_top250_to_library(True, None)
            job["updated"] = int(stats.get("updated") or 0)
            job["matched"] = int(stats.get("matched") or 0)
            job["total"] = int(stats.get("total") or 0)
            job["processed"] = int(stats.get("processed") or stats.get("total") or 0)
            job["percent"] = 100
            cache = core.load_cache()
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] = 1
            core.log("Manual IMDb Top 250 sync failed: {0}".format(exc), xbmc.LOGWARNING)

    update_bg(job, "Exporting CSV report...")
    report = core.export_csv(core.load_cache())
    job["report"] = report

    summary = {
        "started_at": job.get("started_at"),
        "finished_at": core.now_iso(),
        "items_total": int(job.get("total") or len(job.get("items") or [])),
        "matched": int(job.get("matched") or 0),
        "updated": int(job.get("updated") or 0),
        "matched": int(job.get("matched") or 0),
        "skipped": int(job.get("skipped") or 0),
        "failed": int(job.get("failed") or 0),
        "online_lookups": int(job.get("looked_up") or 0),
        "report": report,
        "canceled": bool(canceled),
        "stopped_reason": stopped_reason or "",
        "action": job.get("action"),
    }
    core.save_summary(summary)
    job["finished_at"] = summary["finished_at"]
    if stopped_reason:
        job["status"] = "stopped"
        job["current"] = stopped_reason
    else:
        job["status"] = "canceled" if canceled else "completed"
        job["current"] = "Canceled" if canceled else "Finished"
    if job.get("progress") is not None:
        job["progress"].close()
    write_job_state(job, job["status"])
    if stopped_reason:
        notify(stopped_reason, xbmcgui.NOTIFICATION_WARNING, 8000)
    elif canceled:
        notify("Background scrape canceled", xbmcgui.NOTIFICATION_WARNING, 6000)
    else:
        notify("Background scrape completed", xbmcgui.NOTIFICATION_INFO, 6000)


def force_stop_job(job):
    if job and job.get("progress") is not None:
        try:
            job["progress"].close()
        except Exception:  # pylint: disable=broad-except
            pass
    state = {
        "status": "force_stopped",
        "action": (job or {}).get("action", "scrape"),
        "force": bool((job or {}).get("force")),
        "requested_at": (job or {}).get("requested_at", ""),
        "started_at": (job or {}).get("started_at", ""),
        "finished_at": core.now_iso(),
        "percent": int((job or {}).get("percent") or 0),
        "processed": int((job or {}).get("index") or 0),
        "total": len((job or {}).get("items") or []),
        "updated": int((job or {}).get("updated") or 0),
        "skipped": int((job or {}).get("skipped") or 0),
        "failed": int((job or {}).get("failed") or 0),
        "current": "Force stopped",
    }
    core.save_background_state(state)


def advance_scrape(job, cache):
    if time.time() < float(job.get("next_at") or 0):
        return False
    items = job.get("items") or []
    total = len(items)
    job["total"] = total
    job["processed"] = int(job.get("index") or 0)
    if job.get("index", 0) >= total:
        finish_job(job, cache, False)
        return True

    # Skip fresh rows quickly in one UI cycle. Stop after the first online/local
    # resolve so API pacing remains predictable and the service stays responsive.
    handled = 0
    while job.get("index", 0) < total and handled < 100:
        item = items[job["index"]]
        job["index"] += 1
        job["processed"] = int(job.get("index") or 0)
        handled += 1
        key = core.item_key(item)
        existing = (cache.get("items") or {}).get(key) or {}
        label = item_label(item)
        job["current"] = label
        if not job.get("force") and existing and not core.record_needs_update(item, existing):
            job["skipped"] += 1
            update_bg(job)
            continue
        try:
            if job.get("action") == "awards":
                if existing and not core.record_missing_awards(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                cache.setdefault("items", {})[key] = core.resolve_awards_only(item, job.get("keys") or core.api_keys(), existing)
            else:
                cache.setdefault("items", {})[key] = core.resolve_item(item, job.get("keys") or core.api_keys(), existing, missing_only=not job.get("force"), include_local=False)
            job["updated"] += 1
            job["looked_up"] += 1
        except core.ProviderLimitReached as exc:
            message = "Stopped: {0} API limit reached".format(exc.provider)
            detail = str(exc)
            job["failed"] += 1
            job["current"] = message
            job["stopped_reason"] = message
            core.log("{0}. {1}".format(message, detail), xbmc.LOGWARNING)
            core.save_cache(cache)
            finish_job(job, cache, False, message)
            return True
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] += 1
            core.log("Background full scrape failed for {0}: {1}".format(label, exc), xbmc.LOGWARNING)
        if job["index"] % max(1, core.int_setting("save_every", 10)) == 0:
            core.save_cache(cache)
        delay = max(0, core.int_setting("delay_ms", 1100)) / 1000.0
        job["next_at"] = time.time() + delay
        update_bg(job)
        write_job_state(job)
        return False

    job["processed"] = int(job.get("index") or 0)
    write_job_state(job)
    if job.get("index", 0) >= total:
        finish_job(job, cache, False)
        return True
    return False


def advance_job(job, cache):
    if core.consume_background_force_stop():
        force_stop_job(job)
        return True
    if core.consume_background_cancel():
        finish_job(job, cache, True)
        return True
    if job.get("action") == "top250":
        finish_job(job, cache, False)
        return True
    return advance_scrape(job, cache)


# -----------------------------------------------------------------------------
# v1.3.74 AF3/LRS active bridge + sticky publisher overrides (superseded by v1.3.75 below)
# -----------------------------------------------------------------------------
def current_context_item():
    # Player/OSD always wins.
    if core.player_context_active():
        return "player", core.player_item()

    # AF3 skin bridge is the highest priority for hub/library panels because
    # it represents the item currently being drawn, not the focused button.
    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus
    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item
    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity
    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}

    # Invalid focus/button/dialog should not clear the visible media row.
    if not core.valid_library_item(item):
        context_log(state, context, previous_key or "", item.get("title") if isinstance(item, dict) else "", False, "identity_missing_keep_last")
        return previous_key or ""

    active_key = core.identity_key(item)
    record = _record_from_cache(cache, item, preload)
    if not record and context == "player":
        try:
            fresh_cache = core.load_cache()
            record = _record_from_cache(fresh_cache, item, preload)
            if record:
                cache.clear(); cache.update(fresh_cache)
        except Exception:  # pylint: disable=broad-except
            record = None

    if not record:
        # If the incoming identity is incomplete/title-only, keep the previous
        # row rather than blanking. If it is a strong different media id, clear
        # to avoid showing stale values for a real new item.
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "cache_miss_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "cache_miss_keep_last")
        return previous_key or active_key

    if not core.context_matches_record(item, record):
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "stale_guard_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "stale_guard_keep_last")
        return previous_key or active_key

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    core.publish_af3_properties(values, publish_key, compatibility)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), True, "cache_hit_bridge")
    return active_key



# -----------------------------------------------------------------------------
# v1.3.75 AF3/LRS active bridge + strict episode sticky publisher
# -----------------------------------------------------------------------------
def current_context_item():
    # Player/OSD always wins.
    if core.player_context_active():
        return "player", core.player_item()

    # Screensaver must use the screensaver container. Do not let a stale hub
    # bridge override the active slide.
    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    # AF3 skin bridge wins for hub/library panels because it represents the
    # item being drawn, not the focused Play/Options button.
    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item
    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus
    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity
    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}

    if not core.valid_library_item(item):
        context_log(state, context, previous_key or "", item.get("title") if isinstance(item, dict) else "", False, "identity_missing_keep_last")
        return previous_key or ""

    active_key = core.identity_key(item)
    record = _record_from_cache(cache, item, preload)
    if not record and context == "player":
        try:
            fresh_cache = core.load_cache()
            record = _record_from_cache(fresh_cache, item, preload)
            if record:
                cache.clear(); cache.update(fresh_cache)
        except Exception:  # pylint: disable=broad-except
            record = None

    if not record:
        # Strong new media IDs should clear; weak/title-only button/dialog focus
        # keeps the last row to avoid flicker.
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "cache_miss_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "cache_miss_keep_last")
        return previous_key or active_key

    if not core.context_matches_record(item, record):
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "strict_guard_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "strict_guard_keep_last")
        return previous_key or active_key

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    try:
        core._lrs_log_publish_values(context, record, values)  # pylint: disable=protected-access
    except Exception:  # pylint: disable=broad-except
        pass
    core.publish_af3_properties(values, publish_key, compatibility)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), True, "cache_hit_strict")
    return active_key


# -----------------------------------------------------------------------------
# v1.3.76 context override: do not let AF3 Home buttons replace episode focus with parent tvshow
# -----------------------------------------------------------------------------
def current_context_item():
    if core.player_context_active():
        item = core.player_item()
        if core.valid_library_item(item):
            return "player", item

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus

    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        # When AF3 Home focus is on Play/More Options, TMDbHelper often exposes
        # the parent tvshow while the visible panel is an episode. Publishing that
        # parent causes exactly the wrong episode/series rating. Keep last valid
        # row until a strong visual/list/player identity is available.
        if core.af3_home_action_button_focused() and str(tmdb_identity.get("type") or "").lower() == "tvshow":
            return "identity_missing", {}
        return "tmdbhelper", tmdb_identity

    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}



# -----------------------------------------------------------------------------
# v1.3.78 context override: AF3 visual item wins; TMDbHelper cannot override
# Home/Hub buttons or category tabs with stale media.
# -----------------------------------------------------------------------------
def current_context_item():
    if core.player_context_active():
        item = core.player_item()
        if core.valid_library_item(item):
            return "player", item

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    # In AF3 Home/Hub the focused control can be a button/tab while the visual
    # item is drawn from a widget/spotlight container. Read that container first.
    if core.af3_hub_window_active():
        visual = core.af3_visual_item()
        if core.valid_library_item(visual):
            return "af3_visual", visual
        active = core.lrs_active_item()
        if core.valid_library_item(active):
            return "lrs_active", active
        hub_focus = core.hub_focus_container_item()
        if core.valid_library_item(hub_focus):
            return "hub", hub_focus
        # If focus is on a Home/Hub button or selector and the visual resolver is
        # empty, keep the previous published row. Do not let stale TMDbHelper or
        # stale ListItem values overwrite the current background/title.
        if core.af3_button_or_selector_focused():
            return "identity_missing", {}
        item = core.selected_library_item()
        if core.valid_library_item(item):
            return "listitem", item
        hub_item = core.hub_primary_item()
        if core.valid_library_item(hub_item):
            return "hub_fallback", hub_item
        return "identity_missing", {}

    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus

    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity

    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}

AUTO_LIBRARY_SCAN_FINISHED_AT = 0.0

class LRSAutoMonitor(xbmc.Monitor):
    def onScanFinished(self, library):  # pylint: disable=invalid-name
        global AUTO_LIBRARY_SCAN_FINISHED_AT
        try:
            if str(library or "").lower() in ("video", "") and core.bool_setting("auto_scrape_new_items_after_library_update", False):
                AUTO_LIBRARY_SCAN_FINISHED_AT = time.time() + 10.0
                core.log("Auto scrape scheduled after video library scan", xbmc.LOGINFO)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("Auto scrape schedule failed: {0}".format(exc), xbmc.LOGWARNING)

def main():
    global AUTO_LIBRARY_SCAN_FINISHED_AT
    monitor = LRSAutoMonitor()
    cache = core.load_cache()
    cache_mtime = core.cache_db_mtime()
    state = load_state()
    queue = []
    queued = set()
    previous_key = ""
    preloaded_key = ""
    preloaded_cache = {}
    next_lookup_at = 0.0
    manual_job = None
    compatibility = core.bool_setting("publish_af3_cache", True)
    core.clear_af3_properties(compatibility)
    core.reset_stale_background_on_service_start()
    core.log("Library Ratings Scraper service started", xbmc.LOGINFO)

    while not monitor.abortRequested():
        now = time.time()
        if core.consume_background_force_stop():
            queue = []
            queued = set()
            if manual_job is not None:
                force_stop_job(manual_job)
                manual_job = None
                cache = core.load_cache()
            notify("Force stop background", xbmcgui.NOTIFICATION_WARNING, 5000)
            previous_key = ""
            preloaded_key = ""
            preloaded_cache = {}

        latest_cache_mtime = core.cache_db_mtime()
        # v1.3.65: Do not reload the in-memory scrape cache from disk while a
        # manual scrape is running. The service itself writes ratings-cache.db
        # every save_every items. Older builds saw their own DB mtime change,
        # reloaded from disk before the next item, and discarded unsaved rows
        # between save points. That is why the DB contained movie|1..10 then
        # movie|20, movie|30, movie|40, etc.
        if manual_job is None:
            if latest_cache_mtime and latest_cache_mtime != cache_mtime:
                try:
                    cache = core.load_cache()
                    # load_cache may touch schema/meta and update file mtime;
                    # store the post-load mtime, not the stale value read before.
                    cache_mtime = core.cache_db_mtime()
                    previous_key = ""
                except Exception as exc:  # pylint: disable=broad-except
                    core.log("Cache reload after external update failed: {0}".format(exc), xbmc.LOGWARNING)
            elif not latest_cache_mtime and cache_mtime:
                # User deleted ratings-cache.db while Kodi/service was still running.
                # Do not keep the old in-memory cache and write it back again.
                cache = {"version": core.CACHE_VERSION, "updated_at": "", "backend": "sqlite-ratings-only", "items": {}}
                cache_mtime = 0.0
                previous_key = ""
                preloaded_cache = {}
                core.clear_af3_properties(compatibility)
                core.log("ratings-cache.db disappeared; cleared in-memory LRS cache", xbmc.LOGWARNING)

        context, item = current_context_item()
        if context == "screensaver":
            try:
                core.update_screensaver_clearlogo_properties(item)
            except Exception as exc:  # pylint: disable=broad-except
                core.log("Screensaver clearlogo mode update failed: {0}".format(exc), xbmc.LOGWARNING)
        else:
            try:
                core.clear_screensaver_clearlogo_properties()
            except Exception:
                pass
        previous_key = publish_current(cache, item, previous_key, context, state, preloaded_cache)

        request = core.consume_background_request()
        if request:
            if manual_job is not None:
                notify("Previous background process is still running", xbmcgui.NOTIFICATION_WARNING, 5000)
            elif request.get("action") == "top250":
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                manual_job = new_top250_job(request)
            else:
                # Always reload from disk when a manual scrape starts. If user has
                # deleted ratings-cache.db, this starts from an empty cache instead
                # of the old service RAM cache.
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                manual_job = new_scrape_job(request)

        # Optional auto scrape after Kodi video library scan completes.
        if manual_job is None and AUTO_LIBRARY_SCAN_FINISHED_AT and time.time() >= AUTO_LIBRARY_SCAN_FINISHED_AT:
            AUTO_LIBRARY_SCAN_FINISHED_AT = 0.0
            if core.bool_setting("auto_scrape_new_items_after_library_update", False):
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                auto_request = {"action": "scrape", "force": False, "requested_at": core.now_iso()}
                manual_job = new_scrape_job(auto_request)
                notify("Auto scrape missing data queued after library update", xbmcgui.NOTIFICATION_INFO, 5000)

        # Manual-only: focus changes never queue online scraping.

        # Screensaver one-item cache preload only. No online scrape is queued here.
        # This simply resolves current/next slide identity against the in-memory LRS
        # cache so the next publish can happen immediately after the slide changes.
        if xbmc.getCondVisibility("System.ScreenSaverActive"):
            upcoming = {}
            for offset in (1, 2, -1):
                candidate = core.screensaver_item(offset)
                if core.valid_library_item(candidate):
                    upcoming = candidate
                    break
            upcoming_key = core.identity_key(upcoming) if core.valid_library_item(upcoming) else ""
            if upcoming_key and upcoming_key != preloaded_key:
                preloaded_key = upcoming_key
                record = core.cache_record(cache, upcoming)
                preloaded_cache = {upcoming_key: record} if record else {}
                context_log(state, "screensaver", upcoming_key, upcoming.get("title"), bool(record), "preload_cache_hit" if record else "preload_cache_miss")
        else:
            preloaded_key = ""
            preloaded_cache = {}

        # Manual-only: no automatic refresh, no automatic Top 250 sync.

        # Manual library scrape has priority but executes inside this background
        # service. Kodi's UI remains usable and DialogProgressBG appears only in
        # the notification area.
        if manual_job is not None:
            if advance_job(manual_job, cache):
                manual_job = None
                cache_mtime = core.cache_db_mtime()
                previous_key = ""
            else:
                # save_cache may have run inside advance_scrape; keep this mtime
                # synchronized so the next non-manual loop does not treat our own
                # write as an external DB replacement.
                cache_mtime = core.cache_db_mtime() or cache_mtime
        # Strict manual-only mode: no focus/screensaver/idle item is ever
        # resolved online here. Online scraping only happens from explicit
        # menu actions that create manual_job.

        wait_seconds = 0.10 if (xbmc.getCondVisibility("System.ScreenSaverActive") or core.player_context_active()) else POLL_SECONDS
        monitor.waitForAbort(wait_seconds)

    if manual_job is not None and manual_job.get("progress") is not None:
        manual_job["progress"].close()
    core.clear_af3_properties(core.bool_setting("publish_af3_cache", True))
    core.log("Library Ratings Scraper service stopped", xbmc.LOGINFO)


# __main__ call moved to end by v1.3.90
# -----------------------------------------------------------------------------
# v1.3.86 final screensaver publish guard
# -----------------------------------------------------------------------------
def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}

    if not core.valid_library_item(item):
        context_log(state, context, previous_key or "", item.get("title") if isinstance(item, dict) else "", False, "identity_missing_keep_last_1386")
        return previous_key or ""

    active_key = core.identity_key(item)
    record = _record_from_cache(cache, item, preload)

    # Screensaver can start before the service has noticed an external DB/cache
    # update. Reload once before deciding the slide really has no LRS record.
    if not record and context in ("player", "screensaver"):
        try:
            fresh_cache = core.load_cache()
            record = _record_from_cache(fresh_cache, item, preload)
            if record:
                cache.clear(); cache.update(fresh_cache)
        except Exception:  # pylint: disable=broad-except
            record = None

    if not record:
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            # Clear for a real new media item with no cached row so stale ratings do not
            # remain visible. XML now reads Screensaver.* values, so this no longer
            # blanks valid slides that publish a moment later.
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "cache_miss_clear_new_media_1386")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "cache_miss_keep_last_1386")
        return previous_key or active_key

    if not core.context_matches_record(item, record):
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "strict_guard_clear_new_media_1386")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "strict_guard_keep_last_1386")
        return previous_key or active_key

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    try:
        core._lrs_log_publish_values(context, record, values)  # pylint: disable=protected-access
    except Exception:  # pylint: disable=broad-except
        pass
    core.publish_af3_properties(values, publish_key, compatibility)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), True, "cache_hit_1386")
    return active_key


# v1.3.88 awards-only relevant-key fix lives in core.py; service flow unchanged.


# -----------------------------------------------------------------------------
# v1.3.90 manual job flow: ratings first, then OMDb-only awards pass.
# -----------------------------------------------------------------------------
_new_scrape_job_1390_base = new_scrape_job

def new_scrape_job(request):
    job = _new_scrape_job_1390_base(request)
    if job.get("action") == "scrape":
        job["phase"] = "ratings"
        job["awards_after_ratings"] = True
        job["ratings_total"] = int(job.get("total") or len(job.get("items") or []))
    elif job.get("action") == "awards":
        job["phase"] = "awards"
    return job


def _start_omdb_awards_phase_1390(job, cache):
    core.save_cache(cache)
    all_items = core.library_items()
    awards_items = [item for item in all_items if core.media_setting_type(item.get("type")) in ("movie", "tvshow")]
    job["phase"] = "awards"
    job["action"] = "scrape"  # keep final summary as scrape/refresh all
    job["items"] = awards_items
    job["index"] = 0
    job["processed"] = 0
    job["total"] = len(awards_items)
    job["current"] = "Starting"
    job["awards_phase_started_at"] = core.now_iso()
    update_bg(job, "Starting")
    write_job_state(job)


def advance_scrape(job, cache):
    if time.time() < float(job.get("next_at") or 0):
        return False
    items = job.get("items") or []
    total = len(items)
    job["total"] = total
    job["processed"] = int(job.get("index") or 0)
    phase = job.get("phase") or ("awards" if job.get("action") == "awards" else "ratings")

    if job.get("index", 0) >= total:
        if job.get("awards_after_ratings") and phase == "ratings" and core.bool_setting("scrape_awards_wins", True):
            _start_omdb_awards_phase_1390(job, cache)
            return False
        finish_job(job, cache, False)
        return True

    handled = 0
    while job.get("index", 0) < total and handled < 100:
        item = items[job["index"]]
        job["index"] += 1
        job["processed"] = int(job.get("index") or 0)
        handled += 1
        key = core.item_key(item)
        existing = (cache.get("items") or {}).get(key) or {}
        label = item_label(item)
        job["current"] = ("Awards: " if phase == "awards" else "Ratings: ") + label

        try:
            if phase == "awards" or job.get("action") == "awards":
                # Awards pass is OMDb only. Missing mode skips already checked rows;
                # force refresh all rechecks every movie/show awards row.
                if existing and not job.get("force") and not core.record_missing_awards(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                cache.setdefault("items", {})[key] = core.resolve_awards_only(item, job.get("keys") or core.api_keys(), existing)
            else:
                if not job.get("force") and existing and not core.record_needs_update(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                cache.setdefault("items", {})[key] = core.resolve_item(item, job.get("keys") or core.api_keys(), existing, missing_only=not job.get("force"), include_local=False)
            job["updated"] += 1
            job["looked_up"] += 1
        except core.ProviderLimitReached as exc:
            message = "Stopped: {0} API limit reached".format(exc.provider)
            detail = str(exc)
            job["failed"] += 1
            job["current"] = message
            job["stopped_reason"] = message
            core.log("{0}. {1}".format(message, detail), xbmc.LOGWARNING)
            core.save_cache(cache)
            finish_job(job, cache, False, message)
            return True
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] += 1
            core.log("Background scrape failed for {0}: {1}".format(label, exc), xbmc.LOGWARNING)
        if job["index"] % max(1, core.int_setting("save_every", 10)) == 0:
            core.save_cache(cache)
        delay = max(0, core.int_setting("delay_ms", 1100)) / 1000.0
        job["next_at"] = time.time() + delay
        update_bg(job)
        write_job_state(job)
        return False

    job["processed"] = int(job.get("index") or 0)
    write_job_state(job)
    if job.get("index", 0) >= total:
        if job.get("awards_after_ratings") and phase == "ratings" and core.bool_setting("scrape_awards_wins", True):
            _start_omdb_awards_phase_1390(job, cache)
            return False
        finish_job(job, cache, False)
        return True
    return False



# -----------------------------------------------------------------------------
# v1.3.93 manual job flow: ratings -> awards -> Rotten Tomatoes detail badges.
# -----------------------------------------------------------------------------
_new_scrape_job_1393_base = new_scrape_job


def _rtbadge_items_1393():
    return [item for item in core.library_items() if core.media_setting_type(item.get("type")) in ("movie", "tvshow")]


def new_scrape_job(request):
    action = request.get("action") or "scrape"
    if action == "rtbadges":
        items = _rtbadge_items_1393()
        progress = xbmcgui.DialogProgressBG()
        progress.create(TITLE, "0/0 rt badges - Starting")
        try:
            core.start_rt_badge_report_1393("rtbadges")
        except Exception:  # pylint: disable=broad-except
            pass
        job = {
            "action": "rtbadges",
            "phase": "rtbadges",
            "force": bool(request.get("force")),
            "requested_at": request.get("requested_at") or core.now_iso(),
            "started_at": core.now_iso(),
            "items": items,
            "keys": core.api_keys(),
            "index": 0,
            "updated": 0,
            "matched": 0,
            "processed": 0,
            "total": len(items),
            "skipped": 0,
            "failed": 0,
            "looked_up": 0,
            "current": "Preparing RT badges...",
            "next_at": 0.0,
            "progress": progress,
            "status": "running",
            "report": getattr(core, "RT_BADGE_REPORT_FILE", ""),
        }
        write_job_state(job)
        notify("Rotten Tomatoes badge sync running", xbmcgui.NOTIFICATION_INFO, 5000)
        return job

    job = _new_scrape_job_1393_base(request)
    if job.get("action") == "scrape":
        job["rtbadges_after_previous"] = True
    return job


def _start_rt_badges_phase_1393(job, cache):
    core.save_cache(cache)
    items = _rtbadge_items_1393()
    try:
        core.start_rt_badge_report_1393("after_" + str(job.get("action") or "scrape"))
    except Exception:  # pylint: disable=broad-except
        pass
    job["phase"] = "rtbadges"
    job["action"] = "scrape" if job.get("action") != "rtbadges" else "rtbadges"
    job["items"] = items
    job["index"] = 0
    job["processed"] = 0
    job["total"] = len(items)
    job["current"] = "Starting"
    job["rtbadges_phase_started_at"] = core.now_iso()
    update_bg(job, "Starting")
    write_job_state(job)


def _finish_or_start_rtbadges_1393(job, cache, phase):
    if job.get("rtbadges_after_previous") and phase in ("ratings", "awards"):
        # If ratings finished, awards phase still has priority when enabled.
        if phase == "ratings" and job.get("awards_after_ratings") and core.bool_setting("scrape_awards_wins", True):
            _start_omdb_awards_phase_1390(job, cache)
            return False
        _start_rt_badges_phase_1393(job, cache)
        return False
    finish_job(job, cache, False)
    return True


def advance_scrape(job, cache):
    if time.time() < float(job.get("next_at") or 0):
        return False
    items = job.get("items") or []
    total = len(items)
    job["total"] = total
    job["processed"] = int(job.get("index") or 0)
    phase = job.get("phase") or ("awards" if job.get("action") == "awards" else ("rtbadges" if job.get("action") == "rtbadges" else "ratings"))

    if job.get("index", 0) >= total:
        return _finish_or_start_rtbadges_1393(job, cache, phase)

    handled = 0
    while job.get("index", 0) < total and handled < 100:
        item = items[job["index"]]
        job["index"] += 1
        job["processed"] = int(job.get("index") or 0)
        handled += 1
        key = core.item_key(item)
        existing = (cache.get("items") or {}).get(key) or {}
        label = item_label(item)
        prefix = "RT Badges: " if phase == "rtbadges" else ("Awards: " if phase == "awards" else "Ratings: ")
        job["current"] = prefix + label

        try:
            if phase == "rtbadges" or job.get("action") == "rtbadges":
                if existing and not bool(job.get("force")) and not core.record_missing_rt_badge(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                updated_entry = core.resolve_rt_badge_only(item, job.get("keys") or core.api_keys(), existing, force=bool(job.get("force")))
                cache.setdefault("items", {})[key] = updated_entry
            elif phase == "awards" or job.get("action") == "awards":
                if existing and not job.get("force") and not core.record_missing_awards(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                cache.setdefault("items", {})[key] = core.resolve_awards_only(item, job.get("keys") or core.api_keys(), existing)
            else:
                if not job.get("force") and existing and not core.record_needs_update(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                cache.setdefault("items", {})[key] = core.resolve_item(item, job.get("keys") or core.api_keys(), existing, missing_only=not job.get("force"), include_local=False)
            job["updated"] += 1
            job["looked_up"] += 1
            if phase == "rtbadges":
                job["matched"] += 1
        except core.ProviderLimitReached as exc:
            message = "Stopped: {0} API limit reached".format(exc.provider)
            detail = str(exc)
            job["failed"] += 1
            job["current"] = message
            job["stopped_reason"] = message
            core.log("{0}. {1}".format(message, detail), xbmc.LOGWARNING)
            core.save_cache(cache)
            finish_job(job, cache, False, message)
            return True
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] += 1
            core.log("Background {0} failed for {1}: {2}".format(phase, label, exc), xbmc.LOGWARNING)
        if job["index"] % max(1, core.int_setting("save_every", 10)) == 0:
            core.save_cache(cache)
        delay = max(0, core.int_setting("delay_ms", 1100)) / 1000.0
        job["next_at"] = time.time() + delay
        update_bg(job)
        write_job_state(job)
        return False

    job["processed"] = int(job.get("index") or 0)
    write_job_state(job)
    if job.get("index", 0) >= total:
        return _finish_or_start_rtbadges_1393(job, cache, phase)
    return False

# __main__ call moved to true end by v1.3.99.

# -----------------------------------------------------------------------------
# v1.3.97 uniform progress text
# -----------------------------------------------------------------------------
def _phase_label_1397(job):
    phase = str((job or {}).get("phase") or "").strip().lower()
    action = str((job or {}).get("action") or "").strip().lower()
    if phase == "rtbadges" or action == "rtbadges":
        return "rt badges"
    if phase == "awards" or action == "awards":
        return "awards"
    if phase == "top250" or action == "top250":
        return "top250"
    return "ratings"


def _clean_current_1397(value):
    text = str(value or "Starting").replace("\n", " ").strip()
    for prefix in ("Ratings: ", "Awards: ", "RT Badges: ", "RT badges: ", "Top250: "):
        if text.startswith(prefix):
            return text[len(prefix):].strip() or "Starting"
    return text or "Starting"


def update_bg(job, message=None):
    progress = job.get("progress")
    if progress is None:
        return
    total = int(job.get("total") or len(job.get("items") or []))
    processed = int(job.get("processed") or job.get("index") or 0)
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    phase = _phase_label_1397(job)
    title = _clean_current_1397(message if message is not None else job.get("current"))
    # Keep the DialogProgressBG body to one short line. Long movie titles make
    # AF3/Kodi notifications wrap and feel heavy, so truncate only the title.
    title = compact_text(title, 28)
    text = "{0}/{1} {2} - {3}".format(processed, total, phase, title)
    progress.update(percent, TITLE, compact_text(text, 50))



# -----------------------------------------------------------------------------
# v1.4.2 - auto scrape only newly added library items, no fixed delay
# -----------------------------------------------------------------------------
AUTO_LIBRARY_SCAN_STARTED_KEYS = set()
AUTO_LIBRARY_SCAN_PENDING = None


def _library_key_snapshot_1420():
    try:
        return set(core.item_key(item) for item in core.library_items() if core.resolvable_library_item(item))
    except Exception as exc:  # pylint: disable=broad-except
        core.log("Auto scrape library snapshot failed: {0}".format(exc), xbmc.LOGDEBUG)
        return set()


def _auto_new_items_after_scan_1420(cache, before_keys):
    items = core.library_items()
    cache_keys = set((cache.get("items") or {}).keys())
    before_keys = set(before_keys or [])
    selected = []
    seen = set()
    for item in items:
        if not core.resolvable_library_item(item):
            continue
        key = core.item_key(item)
        if not key or key in seen:
            continue
        is_new_from_scan = bool(before_keys) and key not in before_keys
        is_uncached_fallback = not before_keys and key not in cache_keys
        if is_new_from_scan or is_uncached_fallback:
            selected.append(item)
            seen.add(key)
    return selected


def _new_scoped_scrape_job_1420(request, items):
    action = request.get("action") or "scrape"
    awards_only = action == "awards"
    items = list(items or [])
    if awards_only:
        items = [item for item in items if core.media_setting_type(item.get("type")) in ("movie", "tvshow")]
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, "0/0 awards - Starting" if awards_only else "0/0 ratings - Starting")
    job = {
        "action": action,
        "phase": "awards" if awards_only else "ratings",
        "awards_only": awards_only,
        "awards_after_ratings": action == "scrape",
        "rtbadges_after_previous": action == "scrape",
        "force": bool(request.get("force")),
        "requested_at": request.get("requested_at") or core.now_iso(),
        "started_at": core.now_iso(),
        "items": items,
        "scope_items": list(items),
        "auto_new_only": bool(request.get("auto_new_only")),
        "keys": core.api_keys(),
        "index": 0,
        "updated": 0,
        "matched": 0,
        "processed": 0,
        "total": len(items),
        "skipped": 0,
        "failed": 0,
        "looked_up": 0,
        "current": "Preparing...",
        "next_at": 0.0,
        "progress": progress,
        "status": "running",
    }
    write_job_state(job)
    return job


_new_scrape_job_1420_base = new_scrape_job

def new_scrape_job(request):
    scoped_items = request.get("items") if isinstance(request, dict) else None
    if scoped_items is not None:
        return _new_scoped_scrape_job_1420(request, scoped_items)
    return _new_scrape_job_1420_base(request)


_start_omdb_awards_phase_1390_base_1420 = _start_omdb_awards_phase_1390

def _start_omdb_awards_phase_1390(job, cache):
    core.save_cache(cache)
    source_items = list(job.get("scope_items") or [])
    if not source_items:
        source_items = core.library_items()
    awards_items = [item for item in source_items if core.media_setting_type(item.get("type")) in ("movie", "tvshow")]
    job["phase"] = "awards"
    job["action"] = "scrape"
    job["items"] = awards_items
    job["index"] = 0
    job["processed"] = 0
    job["total"] = len(awards_items)
    job["current"] = "Starting"
    job["awards_phase_started_at"] = core.now_iso()
    update_bg(job, "Starting")
    write_job_state(job)


_start_rt_badges_phase_1393_base_1420 = _start_rt_badges_phase_1393

def _start_rt_badges_phase_1393(job, cache):
    core.save_cache(cache)
    source_items = list(job.get("scope_items") or [])
    if source_items:
        items = [item for item in source_items if core.media_setting_type(item.get("type")) in ("movie", "tvshow")]
    else:
        items = _rtbadge_items_1393()
    try:
        core.start_rt_badge_report_1393("after_" + str(job.get("action") or "scrape"))
    except Exception:  # pylint: disable=broad-except
        pass
    job["phase"] = "rtbadges"
    job["action"] = "scrape" if job.get("action") != "rtbadges" else "rtbadges"
    job["items"] = items
    job["index"] = 0
    job["processed"] = 0
    job["total"] = len(items)
    job["current"] = "Starting"
    job["rtbadges_phase_started_at"] = core.now_iso()
    update_bg(job, "Starting")
    write_job_state(job)


_finish_job_1420_base = finish_job

def finish_job(job, cache, canceled=False, stopped_reason=""):
    # For auto-new-item jobs, never run the full-library Top250 sync at finish.
    # The job is intentionally scoped to only the newly added Kodi items.
    if not job.get("auto_new_only"):
        return _finish_job_1420_base(job, cache, canceled, stopped_reason)

    job["status"] = "finishing"
    write_job_state(job, "finishing")
    update_bg(job, "Saving cache...")
    core.save_cache(cache)
    update_bg(job, "Exporting CSV report...")
    report = core.export_csv(core.load_cache())
    job["report"] = report
    summary = {
        "started_at": job.get("started_at"),
        "finished_at": core.now_iso(),
        "items_total": int(job.get("total") or len(job.get("items") or [])),
        "matched": int(job.get("matched") or 0),
        "updated": int(job.get("updated") or 0),
        "skipped": int(job.get("skipped") or 0),
        "failed": int(job.get("failed") or 0),
        "online_lookups": int(job.get("looked_up") or 0),
        "report": report,
        "canceled": bool(canceled),
        "stopped_reason": stopped_reason or "",
        "action": "auto_scrape_new_items",
    }
    core.save_summary(summary)
    job["finished_at"] = summary["finished_at"]
    job["status"] = "canceled" if canceled else ("stopped" if stopped_reason else "completed")
    job["current"] = "Canceled" if canceled else (stopped_reason or "Finished")
    if job.get("progress") is not None:
        job["progress"].close()
    write_job_state(job, job["status"])
    if stopped_reason:
        notify(stopped_reason, xbmcgui.NOTIFICATION_WARNING, 8000)
    elif canceled:
        notify("Auto scrape canceled", xbmcgui.NOTIFICATION_WARNING, 6000)
    else:
        notify("Auto scrape new items completed", xbmcgui.NOTIFICATION_INFO, 5000)


# Replace the monitor/main pair so auto scrape starts immediately after Kodi scan
# and targets only scan-new items. If Kodi DB is locked/not ready, retry briefly.
class LRSAutoMonitor(xbmc.Monitor):
    def onScanStarted(self, library):  # pylint: disable=invalid-name
        global AUTO_LIBRARY_SCAN_STARTED_KEYS
        try:
            if str(library or "").lower() in ("video", "") and core.bool_setting("auto_scrape_new_items_after_library_update", False):
                AUTO_LIBRARY_SCAN_STARTED_KEYS = _library_key_snapshot_1420()
                core.log("Auto scrape snapshot before video library scan: {0} items".format(len(AUTO_LIBRARY_SCAN_STARTED_KEYS)), xbmc.LOGINFO)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("Auto scrape scan-start snapshot failed: {0}".format(exc), xbmc.LOGWARNING)
            AUTO_LIBRARY_SCAN_STARTED_KEYS = set()

    def onScanFinished(self, library):  # pylint: disable=invalid-name
        global AUTO_LIBRARY_SCAN_PENDING
        try:
            if str(library or "").lower() in ("video", "") and core.bool_setting("auto_scrape_new_items_after_library_update", False):
                AUTO_LIBRARY_SCAN_PENDING = {
                    "before_keys": list(AUTO_LIBRARY_SCAN_STARTED_KEYS or []),
                    "next_at": time.time(),
                    "attempts": 0,
                }
                core.log("Auto scrape queued immediately after video library scan", xbmc.LOGINFO)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("Auto scrape schedule failed: {0}".format(exc), xbmc.LOGWARNING)


def _consume_auto_scan_job_1420(cache):
    global AUTO_LIBRARY_SCAN_PENDING
    pending = AUTO_LIBRARY_SCAN_PENDING
    if not pending:
        return None
    if time.time() < float(pending.get("next_at") or 0):
        return None
    pending["attempts"] = int(pending.get("attempts") or 0) + 1
    try:
        items = _auto_new_items_after_scan_1420(cache, pending.get("before_keys") or [])
    except Exception as exc:  # pylint: disable=broad-except
        text = str(exc).lower()
        if "locked" in text or "busy" in text or pending["attempts"] < 10:
            pending["next_at"] = time.time() + 2.0
            AUTO_LIBRARY_SCAN_PENDING = pending
            core.log("Auto scrape waiting for Kodi library DB: {0}".format(exc), xbmc.LOGINFO)
            return None
        AUTO_LIBRARY_SCAN_PENDING = None
        core.log("Auto scrape new-item detection failed: {0}".format(exc), xbmc.LOGWARNING)
        return None
    AUTO_LIBRARY_SCAN_PENDING = None
    if not items:
        core.log("Auto scrape skipped: no newly added video items found", xbmc.LOGINFO)
        return None
    return new_scrape_job({
        "action": "scrape",
        "force": False,
        "items": items,
        "auto_new_only": True,
        "requested_at": core.now_iso(),
    })


def main():
    monitor = LRSAutoMonitor()
    cache = core.load_cache()
    cache_mtime = core.cache_db_mtime()
    state = load_state()
    queue = []
    queued = set()
    previous_key = ""
    preloaded_key = ""
    preloaded_cache = {}
    manual_job = None
    compatibility = core.bool_setting("publish_af3_cache", True)
    core.clear_af3_properties(compatibility)
    core.reset_stale_background_on_service_start()
    core.log("Library Ratings Scraper service started", xbmc.LOGINFO)

    while not monitor.abortRequested():
        if core.consume_background_force_stop():
            queue = []
            queued = set()
            if manual_job is not None:
                force_stop_job(manual_job)
                manual_job = None
                cache = core.load_cache()
            notify("Force stop background", xbmcgui.NOTIFICATION_WARNING, 5000)
            previous_key = ""
            preloaded_key = ""
            preloaded_cache = {}

        latest_cache_mtime = core.cache_db_mtime()
        if manual_job is None:
            if latest_cache_mtime and latest_cache_mtime != cache_mtime:
                try:
                    cache = core.load_cache()
                    cache_mtime = core.cache_db_mtime()
                    previous_key = ""
                except Exception as exc:  # pylint: disable=broad-except
                    core.log("Cache reload after external update failed: {0}".format(exc), xbmc.LOGWARNING)
            elif not latest_cache_mtime and cache_mtime:
                cache = {"version": core.CACHE_VERSION, "updated_at": "", "backend": "sqlite-ratings-only", "items": {}}
                cache_mtime = 0.0
                previous_key = ""
                preloaded_cache = {}
                core.clear_af3_properties(compatibility)
                core.log("ratings-cache.db disappeared; cleared in-memory LRS cache", xbmc.LOGWARNING)

        context, item = current_context_item()
        if context == "screensaver":
            try:
                core.update_screensaver_clearlogo_properties(item)
            except Exception as exc:  # pylint: disable=broad-except
                core.log("Screensaver clearlogo mode update failed: {0}".format(exc), xbmc.LOGWARNING)
        else:
            try:
                core.clear_screensaver_clearlogo_properties()
            except Exception:
                pass
        previous_key = publish_current(cache, item, previous_key, context, state, preloaded_cache)

        request = core.consume_background_request()
        if request:
            if manual_job is not None:
                notify("Previous background process is still running", xbmcgui.NOTIFICATION_WARNING, 5000)
            elif request.get("action") == "top250":
                cache = core.load_cache(); cache_mtime = core.cache_db_mtime(); manual_job = new_top250_job(request)
            else:
                cache = core.load_cache(); cache_mtime = core.cache_db_mtime(); manual_job = new_scrape_job(request)

        if manual_job is None:
            auto_job = _consume_auto_scan_job_1420(cache)
            if auto_job is not None:
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                manual_job = auto_job
                notify("Auto scrape new items queued: {0}".format(len(manual_job.get("scope_items") or manual_job.get("items") or [])), xbmcgui.NOTIFICATION_INFO, 4000)

        if xbmc.getCondVisibility("System.ScreenSaverActive"):
            upcoming = {}
            for offset in (1, 2, -1):
                candidate = core.screensaver_item(offset)
                if core.valid_library_item(candidate):
                    upcoming = candidate
                    break
            upcoming_key = core.identity_key(upcoming) if core.valid_library_item(upcoming) else ""
            if upcoming_key and upcoming_key != preloaded_key:
                preloaded_key = upcoming_key
                record = core.cache_record(cache, upcoming)
                preloaded_cache = {upcoming_key: record} if record else {}
                context_log(state, "screensaver", upcoming_key, upcoming.get("title"), bool(record), "preload_cache_hit" if record else "preload_cache_miss")
        else:
            preloaded_key = ""
            preloaded_cache = {}

        if manual_job is not None:
            if advance_job(manual_job, cache):
                manual_job = None
                cache_mtime = core.cache_db_mtime()
                previous_key = ""
            else:
                cache_mtime = core.cache_db_mtime() or cache_mtime

        wait_seconds = 0.10 if (xbmc.getCondVisibility("System.ScreenSaverActive") or core.player_context_active()) else POLL_SECONDS
        monitor.waitForAbort(wait_seconds)

    if manual_job is not None and manual_job.get("progress") is not None:
        manual_job["progress"].close()
    core.clear_af3_properties(core.bool_setting("publish_af3_cache", True))
    core.log("Library Ratings Scraper service stopped", xbmc.LOGINFO)


# -----------------------------------------------------------------------------
# v1.4.3 - non-library external focus cache
# -----------------------------------------------------------------------------
EXTERNAL_FOCUS_PENDING = {}
EXTERNAL_FOCUS_LAST_KEY = ""
EXTERNAL_FOCUS_LAST_SEEN = 0.0
EXTERNAL_FOCUS_BUSY = False


def _external_focus_enabled_1430():
    # Keep this always available for AF3 Popular/non-library widgets. It only
    # fetches a single focused released item after debounce.
    return True


def _external_focus_key_1430(item):
    try:
        if not core.valid_library_item(item) or core.resolvable_library_item(item):
            return ""
        media = core.media_setting_type(item.get("type"))
        if media not in ("movie", "tvshow"):
            return ""
        return core.external_item_key_1430(item)
    except Exception:
        return ""


def _record_from_cache_1430_base(cache, item, preload=None):
    return _record_from_cache(cache, item, preload)

# Replace helper used by publish_current: library cache first, then external cache.
def _record_from_cache(cache, item, preload=None):
    record = _record_from_cache_1430_base(cache, item, preload)
    if record:
        return record
    try:
        if _external_focus_key_1430(item):
            return core.load_external_record_1430(item)
    except Exception as exc:  # pylint: disable=broad-except
        core.log("External focus cache read failed: {0}".format(exc), xbmc.LOGWARNING)
    return {}


_publish_current_1430_base = publish_current

def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    global EXTERNAL_FOCUS_PENDING, EXTERNAL_FOCUS_LAST_KEY, EXTERNAL_FOCUS_LAST_SEEN
    result_key = _publish_current_1430_base(cache, item, previous_key, context, state, preload)
    try:
        key = _external_focus_key_1430(item)
        if not key or not _external_focus_enabled_1430():
            return result_key
        # If external item has no cached data yet, clear LRS row for this item
        # instead of keeping stale library ratings from previous focus.
        rec = core.load_external_record_1430(item)
        if not rec:
            core.publish_af3_properties({}, key, core.bool_setting("publish_af3_cache", True))
        now = time.time()
        if key != EXTERNAL_FOCUS_LAST_KEY:
            EXTERNAL_FOCUS_LAST_KEY = key
            EXTERNAL_FOCUS_LAST_SEEN = now
        # Debounce fast scroll: fetch only if focus remains stable.
        if not rec and now - EXTERNAL_FOCUS_LAST_SEEN >= 0.65 and core.external_item_released_1430(item):
            EXTERNAL_FOCUS_PENDING = {"key": key, "item": dict(item), "queued_at": now}
    except Exception as exc:  # pylint: disable=broad-except
        core.log("External focus queue failed: {0}".format(exc), xbmc.LOGWARNING)
    return result_key


def _process_external_focus_1430():
    global EXTERNAL_FOCUS_PENDING, EXTERNAL_FOCUS_BUSY
    if EXTERNAL_FOCUS_BUSY or not EXTERNAL_FOCUS_PENDING:
        return False
    pending = EXTERNAL_FOCUS_PENDING
    EXTERNAL_FOCUS_PENDING = {}
    item = pending.get("item") or {}
    key = pending.get("key") or ""
    if not key or not core.valid_library_item(item) or core.resolvable_library_item(item):
        return False
    try:
        EXTERNAL_FOCUS_BUSY = True
        if core.load_external_record_1430(item):
            return False
        record = core.resolve_external_item_1430(item, core.api_keys())
        if record:
            values = core.af3_values(record)
            values["SourceContext"] = "external_focus"
            core.publish_af3_properties(values, core.record_item_key(record) or key, core.bool_setting("publish_af3_cache", True))
            core.log("External ratings cached: {0}".format(str(item.get("title") or "")[:80]), xbmc.LOGINFO)
            return True
    except core.ProviderLimitReached as exc:
        core.log("External ratings stopped: {0}".format(exc), xbmc.LOGWARNING)
    except Exception as exc:  # pylint: disable=broad-except
        core.log("External ratings lookup failed for {0}: {1}".format(str(item.get("title") or "")[:80], exc), xbmc.LOGWARNING)
    finally:
        EXTERNAL_FOCUS_BUSY = False
    return False


_main_1430_base = main

def main():
    # Small wrapper around the 1.4.2 main loop is not enough because the loop is
    # internal. Reuse it by monkey-patching monitor waits would be fragile, so we
    # keep external lookup opportunistic: process just before normal wait through
    # publish_current side effects in the same service thread. The base main calls
    # publish_current each tick; this wrapper runs a lightweight worker from a
    # timer in a companion thread-free callback by replacing POLL_SECONDS effect.
    # Simpler and safe: call the base main; external pending is processed inside
    # the overridden publish_current on the next stable tick when no manual job is
    # active is not visible here, so process immediately after debounce.
    return _main_1430_base()

# Process external pending from publish_current itself on the next call, but never
# in screensaver/player. This tiny hook is used by the overridden publish_current.
_publish_current_1430_with_worker_base = publish_current

def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    key = _publish_current_1430_with_worker_base(cache, item, previous_key, context, state, preload)
    try:
        if context not in ("player", "screensaver"):
            _process_external_focus_1430()
    except Exception:
        pass
    return key

# v1.3.99 true end entrypoint
if __name__ == "__main__":
    main()

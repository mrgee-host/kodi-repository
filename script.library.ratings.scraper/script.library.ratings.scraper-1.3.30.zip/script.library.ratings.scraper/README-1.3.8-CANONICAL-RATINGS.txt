Library Ratings Scraper 1.3.8 - Canonical Ratings

Perubahan utama:
- Cache/publish hanya memakai satu key final per keluarga rating.
- Alias dobel seperti tomatoes/rottentomatoes dan popcorn/rottentomatoesaudience dilipat menjadi satu value.
- Key final: imdb, tmdb, rt_critic, rt_audience, metacritic, trakt, letterboxd, mdblist.
- Tidak ada konversi persen otomatis. Nilai dipublish apa adanya dari value/score yang dipilih.
- Old cache tetap bisa dibaca; saat publish/export/scrape akan dipakai versi canonical.

Catatan:
Untuk membersihkan ratings-cache.json lama secara permanen, jalankan Refresh paksa seluruh library setelah update.

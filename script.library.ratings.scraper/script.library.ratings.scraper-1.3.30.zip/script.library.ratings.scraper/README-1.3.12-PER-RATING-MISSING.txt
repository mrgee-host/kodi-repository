Library Ratings Scraper 1.3.12

Fixes missing-only scrape per selected rating family.

- Enabling a new rating checkbox fills only that missing rating.
- Existing cached ratings are preserved.
- MDBList score OFF no longer disables MDBList as a provider for RT Audience/Popcorn, Trakt, Letterboxd, or fallback values.
- OMDb is tried first for IMDb / RT Critic / Metacritic, then MDBList fills remaining missing values.
- Adds clear errors if MDBList provider is disabled or the API key is missing while RT Audience/other MDBList-backed ratings are requested.

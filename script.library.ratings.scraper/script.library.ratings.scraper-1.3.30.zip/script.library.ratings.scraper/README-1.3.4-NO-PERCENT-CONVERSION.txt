Library Ratings Scraper 1.3.4 Bridge

Perubahan:
- Semua konversi otomatis persen saat publish dimatikan.
- Rotten / Audience / Metacritic / MDBList memakai angka cache/provider apa adanya.
- Nilai 8 tetap 8%, 10 tetap 10%, tidak lagi dikali 10.
- Bridge Hub 1.3.3 tetap dipertahankan.

Install di atas versi lama lalu restart Kodi.
Kalau nilai lama sudah tersimpan salah dari hasil scrape/provider sebelumnya, refresh item/cache terkait.

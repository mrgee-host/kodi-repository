# Library Ratings Scraper 1.2.7

## Perubahan 1.2.4

- Scrape manual seluruh library tidak lagi membuka progress dialog modal.
- Setelah memilih mode scrape, pekerjaan diserahkan kepada service background lalu menu langsung ditutup.
- Progress tampil menggunakan notifikasi progress latar belakang Kodi (`DialogProgressBG`), sehingga Kodi tetap bisa dipakai untuk membuka menu, film, atau serial lain.
- Ditambahkan menu untuk melihat status dan membatalkan scrape background.
- Sinkronisasi IMDb Top 250 manual juga dijalankan di background.
- Cache 30 hari, auto-refresh, IMDb Top 250, publikasi cache ke Arctic Fuse 3, dan preload slide Arctic Mirage tetap dipertahankan.

## Cara update

1. Install `script.library.ratings.scraper-1.2.4.zip` melalui **Settings > Add-ons > Install from zip file**.
2. Restart Kodi agar service versi baru dimuat ulang.
3. Buka **Add-ons > Program add-ons > Library Ratings Scraper**.
4. Pilih **Scrape item baru / cache kedaluwarsa (background)** atau **Refresh paksa seluruh library (background)**.

XML Arctic Mirage tidak perlu disalin ulang bila sebelumnya sudah memakai XML modifikasi dari bundle 1.2.x.


## Perubahan 1.2.5

- Progress background tetap non-blocking.
- Pesan progress dipadatkan menjadi satu baris supaya tidak terpotong pada Arctic Fuse 3.
- Format progress: `5/5797  U:5 S:0 G:0  21 BRIDGES`.


## Perubahan 1.2.6

- Progress background dipersingkat lagi.
- Notifikasi hanya menampilkan posisi item dan judul: `5/5797  21 BRIDGES`.
- Counter `U`, `S`, dan `G` tidak lagi ditampilkan pada notifikasi.
- Detail update, skip, dan gagal tetap tersedia melalui menu **Lihat status scrape background** serta laporan CSV.
- Toast selesai dipersingkat menjadi `Scrape background selesai`.


## Perubahan 1.2.7

- Judul notifikasi background dikembalikan menjadi **Library Ratings Scraper**.


## Version 1.3.1

- Adds Arctic Fuse 3 hub fallback: when the focused control is Play/More Options instead of the media item, the service can identify the cache row through TMDbHelper basic item properties.
- Adds title/year cache fallback for hub and screensaver rows that do not expose a DBID for a moment.
- Prevents title-only hub fallbacks from starting online lookups; they only publish already-scraped cache values.
- Keeps screensaver cache publishing stricter so old ratings are cleared when the current slide is known but not cached.

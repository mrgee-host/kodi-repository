Library Ratings Scraper 1.3.14

Fix TV show / episode rating checks:
- MDBList now tries multiple IDs for TV shows (TMDb first, then IMDb) instead of one fixed lookup.
- This helps RT audience/popcorn and RT critics/tomatoes appear for series when the first MDBList show lookup is partial.
- OMDb episode lookup now retries by show title + season + episode when lookup by episode IMDb ID gives no rating.
- Movies behavior is unchanged.
- No percent conversion is re-enabled.
- Canonical one-value-per-rating behavior is kept.

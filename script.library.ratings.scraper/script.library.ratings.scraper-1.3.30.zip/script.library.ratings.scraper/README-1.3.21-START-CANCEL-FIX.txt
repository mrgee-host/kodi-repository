Library Ratings Scraper 1.3.21

Fix:
- Starting a new background scrape now clears stale cancel/force-stop marker files first.
- This prevents the scrape from entering queued/running and then immediately stopping because an old Force Stop/Cancel flag was still present in addon_data.
- Based on 1.3.19 stable check/sample build.

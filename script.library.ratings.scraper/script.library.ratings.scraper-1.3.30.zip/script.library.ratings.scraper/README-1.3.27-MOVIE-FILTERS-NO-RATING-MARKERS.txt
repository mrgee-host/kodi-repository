Library Ratings Scraper 1.3.27

Adds movie filter settings:
- Include animation short films
- Include Indonesian Movies Collection

Adds no-rating markers for enabled rating fields that were checked by a provider but returned no numeric value. This prevents missing-only scrape from treating those fields as empty and retrying them endlessly. Temporary provider errors such as 401/403/429/5xx are not marked as no-rating, so limit/API failures can still be retried later.

CSV report shows NO_RATING for these markers; Arctic Fuse/TMDbHelper publishing remains blank so the skin does not display fake ratings.

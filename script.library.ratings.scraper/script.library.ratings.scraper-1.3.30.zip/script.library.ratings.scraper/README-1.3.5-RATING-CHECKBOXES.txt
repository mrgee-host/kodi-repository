Library Ratings Scraper 1.3.5

Added checkbox settings to choose which rating families are scraped/published per media type:
- Movies: IMDb, TMDb, RT critics, RT audience, Metacritic, Trakt, Letterboxd, MDBList, IMDb Top 250
- TV shows: IMDb, TMDb, RT critics, RT audience, Metacritic, Trakt, Letterboxd, MDBList
- Episodes: IMDb, TMDb, RT critics, Metacritic

Unchecked ratings are filtered from new scrape results and from old cache when publishing to Arctic Fuse 3.

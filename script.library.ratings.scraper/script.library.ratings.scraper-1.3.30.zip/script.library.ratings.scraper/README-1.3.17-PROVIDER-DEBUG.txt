Library Ratings Scraper 1.3.17

Provider debug fix:
- Live check no longer reports empty HTTP/network failures as response=True.
- OMDb attempts now show http status, response bytes, and real error/body when available.
- MDBList attempts now show http status, response bytes, payload keys, and provider error/message.
- No rating/layout behavior changed.

Library Ratings Scraper 1.3.26

Adds a movie filter setting:
- Include animation short films

When OFF, movie scraping and random live checks skip items detected as animation short films from Kodi genre/tag/set text. Detection is conservative so normal animated feature films are not skipped. Existing cached fields are not modified; this only changes which movie items are queued for new/missing scraping.

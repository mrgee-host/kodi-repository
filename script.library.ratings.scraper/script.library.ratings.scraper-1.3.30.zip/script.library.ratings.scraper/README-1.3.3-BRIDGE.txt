Library Ratings Scraper 1.3.3 Bridge

Fix:
- Perbaikan normalisasi persen agar rating rendah seperti 10% tidak berubah menjadi 100%.
- Tetap memakai flow bridge/compatibility 1.3.2.

Install di atas versi lama lalu restart Kodi. Tidak perlu scrape ulang jika cache berisi score mentah yang benar.

Library Ratings Scraper 1.3.30

Rebuilt from the stable 1.3.27 zip so the original icon and full package structure are preserved.

Changes:
- Fixes the repo update package problem from 1.3.28/1.3.29 by rebuilding from the complete 1.3.27 base.
- Adds bundled IMDb Top 250 TV Shows JSON and Sync IMDb Top 250 Movies + TV Shows.
- Simplifies settings while keeping API keys in Add-on Settings, not the run menu.
- Keeps media checkboxes: Movies, TV shows / Series, Episodes.
- Uses global rating checkboxes; episodes only use IMDb and TMDb internally.
- Removes automatic scrape/cache-age behaviour from the UI and makes scraping manual-only.
- Keeps NO_RATING marker always enabled internally.
- Keeps v1.3.23+ smart missing-only logic: if a provider request is made because one enabled field is missing, all enabled ratings returned by that same response update the cache.

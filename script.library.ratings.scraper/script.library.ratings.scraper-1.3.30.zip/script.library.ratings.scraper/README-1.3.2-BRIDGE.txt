Library Ratings Scraper 1.3.2 Bridge Test

Tujuan:
- Tidak mengubah layout Arctic Fuse 3.
- Tetap jalur aman 1.3.1.
- Menambah fallback identitas Hub/Spotlight: baca Window.Property(TMDbHelper.ListItem.*) selain Window(Home).Property(...).
- Cocokkan cache tidak hanya DBID/title-year, tapi juga IMDb ID dan TMDb ID.
- Siap menerima bridge skin LRS.Active.* nanti bila include Hub_Window sudah ketemu.

Catatan:
Jika Hub masih kosong, kirim file yang berisi <include name="Hub_Window"> agar bisa dibuat bridge skin yang benar-benar mengirim LRS.Active.* dari item yang digambar skin.

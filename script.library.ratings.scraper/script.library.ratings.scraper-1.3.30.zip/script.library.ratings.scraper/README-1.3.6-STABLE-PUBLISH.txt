Library Ratings Scraper 1.3.6

- Keeps 1.3.5 rating checkboxes.
- No percent conversion remains.
- Rotten Tomatoes/Audience now prefers MDBList percent-style rows (tomatoes/popcorn) before Kodi 0-10 local rows.
- Service republishes the current item continuously so TMDbHelper compatibility properties do not alternate while browsing Hub/Spotlight offline.

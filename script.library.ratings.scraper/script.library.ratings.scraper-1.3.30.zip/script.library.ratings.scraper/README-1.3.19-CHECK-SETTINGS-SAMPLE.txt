Library Ratings Scraper 1.3.19

- Random live check now follows enabled media type settings: movies, TV shows, episodes.
- Added setting: Random live check sample size per type.
- Dialog/report show which media types are enabled and how many samples are tested.
- Cache is still ignored as result during live check; cache IDs may be used only to query providers.

Library Ratings Scraper 1.3.13

- Adds Force stop scrape background.
- Adds Check 5 random Movies/Series/Episodes.
- Random check follows the currently enabled rating checkboxes and shows OK/MISS per rating plus provider/source.
- Random check does not save results to ratings-cache.json.

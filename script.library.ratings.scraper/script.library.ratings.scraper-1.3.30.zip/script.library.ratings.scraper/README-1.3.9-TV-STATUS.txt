Library Ratings Scraper 1.3.9

Adds optional TMDb TV show status/date scraping.
Stores TV show status metadata under each tvshow cache row as "series".
Publishes Status/StatusDate and common air-date properties to LibraryRatings.ListItem.* and TMDbHelper.ListItem.* compatibility namespace.
Keeps v1.3.8 canonical one-value-per-rating behavior.

Suggested: install, restart Kodi, then run Refresh paksa seluruh library so existing tvshow cache rows get status metadata.

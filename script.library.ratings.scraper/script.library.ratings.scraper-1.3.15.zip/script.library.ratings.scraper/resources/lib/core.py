# -*- coding: utf-8 -*-
from __future__ import annotations

import csv
import json
import os
import random
import re
import time
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
CACHE_FILE = os.path.join(PROFILE, "ratings-cache.json")
REPORT_FILE = os.path.join(PROFILE, "ratings-report.csv")
SUMMARY_FILE = os.path.join(PROFILE, "last-run-summary.json")
NETWORK_TIMEOUT = 10
CACHE_VERSION = 4
IMDB_TOP250_URL = "https://www.imdb.com/chart/top/"
IMDB_TOP250_CACHE_FILE = os.path.join(PROFILE, "imdb-top250-cache.json")
BACKGROUND_REQUEST_FILE = os.path.join(PROFILE, "background-job-request.json")
BACKGROUND_CANCEL_FILE = os.path.join(PROFILE, "background-job-cancel.json")
BACKGROUND_STATE_FILE = os.path.join(PROFILE, "background-job-state.json")
BACKGROUND_FORCE_STOP_FILE = os.path.join(PROFILE, "background-job-force-stop.json")
SAMPLE_CHECK_LOG_FILE = os.path.join(PROFILE, "last-random-check-debug.txt")


def debug_enabled() -> bool:
    return ADDON.getSetting("debug_logging").lower() == "true"


def log(message: str, level: int = xbmc.LOGDEBUG) -> None:
    if level != xbmc.LOGDEBUG or debug_enabled():
        xbmc.log("[{0}] {1}".format(ADDON_ID, message), level)


def _public_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """Return provider request params without exposing API keys."""
    public: Dict[str, Any] = {}
    for key, value in (params or {}).items():
        if str(key).lower() in ("apikey", "api_key", "key"):
            public[key] = "***"
        else:
            public[key] = value
    return public


def _compact_rating_sources(ratings: Any) -> List[str]:
    output: List[str] = []
    if not isinstance(ratings, list):
        return output
    for row in ratings:
        if not isinstance(row, dict):
            continue
        source = str(row.get("source") or row.get("Source") or "").strip()
        value = row.get("value") if "value" in row else row.get("Value")
        score = row.get("score") if "score" in row else ""
        if source:
            if value not in (None, ""):
                output.append("{0}={1}".format(source, value))
            elif score not in (None, ""):
                output.append("{0}={1}".format(source, score))
            else:
                output.append(source)
    return output


def safe_int(value: Any) -> Optional[int]:
    try:
        if value in (None, ""):
            return None
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None


def safe_float(value: Any) -> Optional[float]:
    try:
        if value in (None, "", "N/A"):
            return None
        match = re.search(r"-?\d+(?:[.,]\d+)?", str(value))
        return float(match.group(0).replace(",", ".")) if match else None
    except (TypeError, ValueError):
        return None


def bool_setting(name: str, default: bool = False) -> bool:
    value = ADDON.getSetting(name)
    return default if value == "" else value.lower() == "true"


def int_setting(name: str, default: int) -> int:
    return safe_int(ADDON.getSetting(name)) or default


RATING_LOGICALS_BY_TYPE = {
    "movie": {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist", "top250"},
    "tvshow": {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist"},
    "episode": {"imdb", "tmdb", "rt_critic", "metacritic"},
}

RATING_SOURCE_TO_LOGICAL = {
    # Canonical keys (v1.3.8 cache format)
    "imdb": "imdb",
    "tmdb": "tmdb",
    "rtcritic": "rt_critic",
    "rtaudience": "rt_audience",
    "metacritic": "metacritic",
    "trakt": "trakt",
    "letterboxd": "letterboxd",
    "mdblist": "mdblist",
    # Kodi / provider aliases observed in existing caches
    "internetmoviedatabase": "imdb",
    "themoviedb": "tmdb",
    "tomatoes": "rt_critic",
    "rottentomatoes": "rt_critic",
    "tomatometer": "rt_critic",
    "tomatometerallcritics": "rt_critic",
    "tomatometerallaudience": "rt_audience",
    "audience": "rt_audience",
    "rottentomatoesaudience": "rt_audience",
    "popcorn": "rt_audience",
    "metascore": "metacritic",
    "metacriticuser": "metacritic",
}

# One visible/cache key per rating family. Aliases such as tomatoes,
# rottentomatoes, popcorn, and rottentomatoesaudience are folded into these
# canonical keys so a single item cannot alternate between duplicate values.
RATING_LOGICAL_TO_CACHE_KEY = {
    "imdb": "imdb",
    "tmdb": "tmdb",
    "rt_critic": "rt_critic",
    "rt_audience": "rt_audience",
    "metacritic": "metacritic",
    "trakt": "trakt",
    "letterboxd": "letterboxd",
    "mdblist": "mdblist",
}

# Provider/source preference inside each rating family. The first available
# candidate wins and all aliases are discarded from the final cache row.
RATING_ALIAS_PRIORITY = {
    "imdb": ["imdb", "internetmoviedatabase"],
    "tmdb": ["tmdb", "themoviedb"],
    "rt_critic": ["tomatoes", "tomatometer", "tomatometerallcritics", "rottentomatoes", "rtcritic"],
    "rt_audience": ["popcorn", "audience", "rtaudience", "tomatometerallaudience", "rottentomatoesaudience"],
    "metacritic": ["metacritic", "metascore", "metacriticuser"],
    "trakt": ["trakt"],
    "letterboxd": ["letterboxd"],
    "mdblist": ["mdblist"],
}

# Provider preference per rating family. This prevents MDBList aggregator rows
# from replacing an original/source-specific row for the same displayed rating.
RATING_PROVIDER_PRIORITY = {
    "imdb": ["omdb", "kodi", "mdblist"],
    "tmdb": ["tmdb", "kodi", "mdblist"],
    "rt_critic": ["omdb", "mdblist", "kodi"],
    "rt_audience": ["mdblist", "kodi", "omdb"],
    "metacritic": ["omdb", "mdblist", "kodi"],
    "trakt": ["kodi", "mdblist"],
    "letterboxd": ["mdblist", "kodi"],
    "mdblist": ["mdblist"],
}

MDBLIST_LOGICALS = {"imdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist"}
OMDB_LOGICALS = {"imdb", "rt_critic", "metacritic"}
# MDBList is an aggregator provider. These are the rating families it can be
# used for when the corresponding checkbox is enabled. The separate
# `ratings_*_mdblist` checkbox controls only the visible MDBList score itself;
# it must not disable MDBList as a source for RT audience/popcorn, Trakt, etc.
MDBLIST_PROVIDER_LOGICALS = {"imdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist"}


def media_setting_type(media_type: Any) -> str:
    value = str(media_type or "").strip().lower()
    if value in ("tv", "show", "series", "season"):
        return "tvshow"
    if value in ("movies",):
        return "movie"
    if value in ("episodes",):
        return "episode"
    return value


def rating_setting_id(media_type: Any, logical: str) -> str:
    return "ratings_{0}_{1}".format(media_setting_type(media_type), logical)


def rating_enabled(media_type: Any, logical: str, default: bool = True) -> bool:
    media_type = media_setting_type(media_type)
    if logical not in RATING_LOGICALS_BY_TYPE.get(media_type, set()):
        return False
    return bool_setting(rating_setting_id(media_type, logical), default)


def any_rating_enabled(media_type: Any, logicals: Iterable[str]) -> bool:
    return any(rating_enabled(media_type, logical, True) for logical in logicals)


def clean_rating_source(source: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(source or "").lower())


def logical_for_rating_source(source: Any) -> str:
    return RATING_SOURCE_TO_LOGICAL.get(clean_rating_source(source), "")


def _rating_alias_rank(logical: str, source: Any) -> int:
    clean = clean_rating_source(source)
    priority = RATING_ALIAS_PRIORITY.get(logical, [])
    return priority.index(clean) if clean in priority else len(priority) + 100


def _provider_rank(logical: str, provider: Any) -> int:
    clean = clean_rating_source(provider)
    priority = RATING_PROVIDER_PRIORITY.get(logical, [])
    return priority.index(clean) if clean in priority else len(priority) + 100


def _candidate_score_for_dedupe(logical: str, alias: str, rating: Dict[str, Any]) -> Tuple[int, int, int, float, int]:
    """Lower tuple wins.

    Pick one stable provider/source for each logical rating. Provider priority
    comes before alias priority so e.g. TMDb direct/Kodi TMDb is not replaced by
    MDBList's aggregate TMDb alias. Votes are only a final tie breaker.
    """
    has_number = 0 if (safe_float(rating.get("score")) is not None or safe_float(rating.get("value")) is not None) else 1
    votes = safe_int(rating.get("votes")) or 0
    return (_provider_rank(logical, rating.get("provider")), _rating_alias_rank(logical, alias), has_number, -float(votes), 0)


def _canonical_rating_row(logical: str, alias: str, rating: Any) -> Dict[str, Any]:
    row = dict(rating) if isinstance(rating, dict) else normalized_rating(alias, rating, None, None, "")
    row.setdefault("provider", "")
    row["source"] = clean_rating_source(row.get("source") or alias)
    row["logical"] = logical
    row["cache_key"] = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
    return row


def filter_ratings_for_item(media_type: Any, ratings: Dict[str, Any]) -> Dict[str, Any]:
    """Apply checkboxes and fold duplicate aliases into one canonical value.

    v1.3.8 cache rule: one key per displayed rating family only:
    imdb, tmdb, rt_critic, rt_audience, metacritic, trakt, letterboxd, mdblist.
    Old aliases from Kodi/MDBList/OMDb are read for compatibility, then dropped.
    """
    media_type = media_setting_type(media_type)
    if not isinstance(ratings, dict) or media_type not in RATING_LOGICALS_BY_TYPE:
        return {}

    grouped: Dict[str, List[Tuple[str, Dict[str, Any]]]] = {}
    for alias, rating in ratings.items():
        logical = logical_for_rating_source(alias)
        if not logical:
            # Do not keep unknown rating names in the final cache/publish map;
            # the user asked for no duplicate/alias rows.
            continue
        if not rating_enabled(media_type, logical, True):
            continue
        grouped.setdefault(logical, []).append((str(alias), _canonical_rating_row(logical, str(alias), rating)))

    output: Dict[str, Any] = {}
    for logical, rows in grouped.items():
        if not rows:
            continue
        rows.sort(key=lambda pair: _candidate_score_for_dedupe(logical, pair[0], pair[1]))
        cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
        output[cache_key] = rows[0][1]
    return output



def now_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def json_rpc(method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}}
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        if response.get("error"):
            log("JSON-RPC error {0}: {1}".format(method, response["error"]), xbmc.LOGWARNING)
            return {}
        result = response.get("result") or {}
        return result if isinstance(result, dict) else {}
    except Exception as exc:  # pylint: disable=broad-except
        log("JSON-RPC failure {0}: {1}".format(method, exc), xbmc.LOGWARNING)
        return {}


def load_cache() -> Dict[str, Any]:
    try:
        with open(CACHE_FILE, "r", encoding="utf-8") as handle:
            parsed = json.load(handle)
        if isinstance(parsed, dict) and isinstance(parsed.get("items"), dict):
            return parsed
    except (OSError, ValueError):
        pass
    return {"version": CACHE_VERSION, "updated_at": "", "items": {}}


def save_cache(cache: Dict[str, Any]) -> None:
    os.makedirs(PROFILE, exist_ok=True)
    cache["version"] = CACHE_VERSION
    cache["updated_at"] = now_iso()
    temp = CACHE_FILE + ".tmp"
    with open(temp, "w", encoding="utf-8") as handle:
        json.dump(cache, handle, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(temp, CACHE_FILE)


def save_summary(summary: Dict[str, Any]) -> None:
    os.makedirs(PROFILE, exist_ok=True)
    with open(SUMMARY_FILE, "w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2, sort_keys=True)


def _atomic_json(path: str, payload: Dict[str, Any]) -> None:
    os.makedirs(PROFILE, exist_ok=True)
    temp = path + ".tmp"
    with open(temp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(temp, path)


def _load_json(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        return payload if isinstance(payload, dict) else {}
    except (OSError, ValueError):
        return {}


def queue_background_job(action: str, force: bool = False) -> None:
    payload = {"action": action, "force": bool(force), "requested_at": now_iso(), "timestamp": int(time.time())}
    _atomic_json(BACKGROUND_REQUEST_FILE, payload)
    _atomic_json(BACKGROUND_STATE_FILE, {"status": "queued", "action": action, "force": bool(force), "requested_at": payload["requested_at"], "percent": 0, "processed": 0, "total": 0})


def request_background_cancel() -> None:
    _atomic_json(BACKGROUND_CANCEL_FILE, {"cancel": True, "requested_at": now_iso(), "timestamp": int(time.time())})


def request_background_force_stop() -> None:
    """Request an immediate hard stop from the service loop.

    Normal cancel lets the service finish the current item and save a clean
    partial cache/report. Force stop is for stuck or unwanted long runs: it
    clears pending request files and tells the service to drop the running job
    as soon as the current HTTP/JSON-RPC call returns.
    """
    try:
        if os.path.exists(BACKGROUND_REQUEST_FILE):
            os.remove(BACKGROUND_REQUEST_FILE)
    except OSError:
        pass
    payload = {"force_stop": True, "requested_at": now_iso(), "timestamp": int(time.time())}
    _atomic_json(BACKGROUND_FORCE_STOP_FILE, payload)
    _atomic_json(BACKGROUND_CANCEL_FILE, {"cancel": True, "force_stop": True, "requested_at": payload["requested_at"], "timestamp": payload["timestamp"]})
    _atomic_json(BACKGROUND_STATE_FILE, {"status": "force_stop_requested", "action": "force_stop", "requested_at": payload["requested_at"], "percent": 0, "processed": 0, "total": 0, "current": "Force stop diminta"})


def background_job_state() -> Dict[str, Any]:
    return _load_json(BACKGROUND_STATE_FILE)


def consume_background_request() -> Dict[str, Any]:
    payload = _load_json(BACKGROUND_REQUEST_FILE)
    if payload:
        try:
            os.remove(BACKGROUND_REQUEST_FILE)
        except OSError:
            pass
    return payload


def consume_background_cancel() -> bool:
    payload = _load_json(BACKGROUND_CANCEL_FILE)
    if payload:
        try:
            os.remove(BACKGROUND_CANCEL_FILE)
        except OSError:
            pass
    return bool(payload.get("cancel"))


def consume_background_force_stop() -> bool:
    payload = _load_json(BACKGROUND_FORCE_STOP_FILE)
    if payload:
        try:
            os.remove(BACKGROUND_FORCE_STOP_FILE)
        except OSError:
            pass
    return bool(payload.get("force_stop"))


def save_background_state(state: Dict[str, Any]) -> None:
    _atomic_json(BACKGROUND_STATE_FILE, state)


def item_key(item: Dict[str, Any]) -> str:
    return "{0}|{1}".format(item.get("type", "unknown"), item.get("dbid", ""))


def fresh(entry: Dict[str, Any]) -> bool:
    stamp = safe_float(entry.get("timestamp")) or 0
    return stamp > 0 and (time.time() - stamp) < max(1, int_setting("cache_days", 14)) * 86400


def get_setting_from(addon: xbmcaddon.Addon, candidates: Iterable[str]) -> str:
    for setting_id in candidates:
        try:
            value = addon.getSetting(setting_id)
        except Exception:  # pylint: disable=broad-except
            value = ""
        if value:
            return value.strip()
    return ""


def api_keys() -> Dict[str, str]:
    keys = {
        "mdblist": ADDON.getSetting("mdblist_apikey").strip(),
        "tmdb": ADDON.getSetting("tmdb_apikey").strip(),
        "omdb": ADDON.getSetting("omdb_apikey").strip(),
    }
    if not bool_setting("try_tmdbhelper_keys", True):
        return keys
    try:
        helper = xbmcaddon.Addon("plugin.video.themoviedb.helper")
    except Exception:  # pylint: disable=broad-except
        return keys
    if not keys["mdblist"]:
        keys["mdblist"] = get_setting_from(helper, ("mdblist_apikey", "mdblist_api_key", "mdblist_key"))
    if not keys["tmdb"]:
        keys["tmdb"] = get_setting_from(helper, ("tmdb_apikey", "tmdb_api_key", "tmdb_key", "tmdb_api"))
    if not keys["omdb"]:
        keys["omdb"] = get_setting_from(helper, ("omdb_apikey", "omdb_api_key", "omdb_key"))
    return keys


def http_json(url: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    request = Request(url, headers={"User-Agent": "Kodi-Library-Ratings-Scraper/1.3.13", "Accept": "application/json"})
    try:
        with urlopen(request, timeout=NETWORK_TIMEOUT) as response:  # nosec B310 fixed HTTPS hosts only
            headers = {k.lower(): v for k, v in response.headers.items()}
            raw = response.read().decode("utf-8", "replace")
        parsed = json.loads(raw)
        return (parsed if isinstance(parsed, dict) else {}), headers
    except HTTPError as exc:
        retry = exc.headers.get("Retry-After", "") if exc.headers else ""
        log("HTTP {0} for {1}; retry-after={2}".format(exc.code, url.split("?")[0], retry), xbmc.LOGWARNING)
    except (URLError, OSError, ValueError, TimeoutError) as exc:
        log("Provider request failed: {0}".format(exc), xbmc.LOGWARNING)
    return {}, {}


def http_text(url: str) -> str:
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Kodi-Library-Ratings-Scraper/1.3.13",
        "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    })
    try:
        with urlopen(request, timeout=NETWORK_TIMEOUT) as response:  # nosec B310 fixed HTTPS host only
            return response.read().decode("utf-8", "replace")
    except HTTPError as exc:
        log("HTTP {0} for IMDb Top 250 chart".format(exc.code), xbmc.LOGWARNING)
    except (URLError, OSError, TimeoutError) as exc:
        log("IMDb Top 250 chart request failed: {0}".format(exc), xbmc.LOGWARNING)
    return ""


def _load_top250_cache() -> Dict[str, Any]:
    try:
        with open(IMDB_TOP250_CACHE_FILE, "r", encoding="utf-8") as handle:
            parsed = json.load(handle)
        return parsed if isinstance(parsed, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_top250_cache(ranks: Dict[str, int]) -> None:
    os.makedirs(PROFILE, exist_ok=True)
    payload = {"timestamp": int(time.time()), "updated_at": now_iso(), "ranks": ranks}
    temp = IMDB_TOP250_CACHE_FILE + ".tmp"
    with open(temp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(temp, IMDB_TOP250_CACHE_FILE)


def _walk_top250_json(node: Any, ranks: Dict[str, int]) -> None:
    if isinstance(node, dict):
        imdb_id = ""
        for key in ("id", "titleId", "const", "tconst"):
            value = node.get(key)
            if isinstance(value, str) and re.fullmatch(r"tt\d+", value):
                imdb_id = value
                break
        rank = None
        for key in ("rank", "currentRank", "position"):
            value = safe_int(node.get(key))
            if value is not None and 1 <= value <= 250:
                rank = value
                break
        if imdb_id and rank is not None:
            ranks.setdefault(imdb_id, rank)
        for value in node.values():
            _walk_top250_json(value, ranks)
    elif isinstance(node, list):
        for value in node:
            _walk_top250_json(value, ranks)


def _parse_imdb_top250(html: str) -> Dict[str, int]:
    ranks: Dict[str, int] = {}
    # IMDb currently embeds chart data in JSON. Walk any script JSON first so
    # explicit rank values win when available.
    for raw in re.findall(r'<script[^>]*type=["\\\']application/json["\\\'][^>]*>(.*?)</script>', html, flags=re.I | re.S):
        try:
            _walk_top250_json(json.loads(raw), ranks)
        except ValueError:
            continue
    if len(ranks) >= 200:
        return dict(sorted(ranks.items(), key=lambda pair: pair[1])[:250])

    # Fallback for server-rendered chart markup. Preserve href order and remove
    # duplicates; the first 250 distinct title IDs are the ranked movie rows.
    ordered: List[str] = []
    seen = set()
    for imdb_id in re.findall(r'/title/(tt\d+)/', html, flags=re.I):
        imdb_id = imdb_id.lower()
        if imdb_id not in seen:
            seen.add(imdb_id)
            ordered.append(imdb_id)
    if len(ordered) >= 200:
        return {imdb_id: index for index, imdb_id in enumerate(ordered[:250], start=1)}
    return {}


def imdb_top250_ranks(force_refresh: bool = False) -> Dict[str, int]:
    cached = _load_top250_cache()
    cached_ranks = cached.get("ranks") or {}
    max_age_hours = max(1, int_setting("imdb_top250_cache_hours", 24))
    stamp = safe_float(cached.get("timestamp")) or 0
    if not force_refresh and cached_ranks and time.time() - stamp < max_age_hours * 3600:
        return {str(key): int(value) for key, value in cached_ranks.items() if safe_int(value) is not None}

    parsed = _parse_imdb_top250(http_text(IMDB_TOP250_URL))
    if parsed:
        _save_top250_cache(parsed)
        return parsed
    # Do not erase the last known chart on a temporary IMDb/network failure.
    return {str(key): int(value) for key, value in cached_ranks.items() if safe_int(value) is not None}


def _movie_imdb_id(movie: Dict[str, Any], ratings_cache: Dict[str, Any]) -> str:
    ids = extract_ids(movie)
    imdb_id = str(ids.get("imdb") or "").lower()
    if imdb_id.startswith("tt"):
        return imdb_id
    cached_entry = (ratings_cache.get("items") or {}).get("movie|{0}".format(movie.get("movieid"))) or {}
    imdb_id = str((cached_entry.get("ids") or {}).get("imdb") or "").lower()
    return imdb_id if imdb_id.startswith("tt") else ""


def sync_imdb_top250_to_library(force_chart_refresh: bool = False, progress: Any = None) -> Dict[str, int]:
    if not rating_enabled("movie", "top250", True):
        return {"movies": 0, "matched": 0, "updated": 0, "missing_imdb": 0, "chart_items": 0, "disabled": 1}
    ranks = imdb_top250_ranks(force_chart_refresh)
    if not ranks:
        return {"movies": 0, "matched": 0, "updated": 0, "missing_imdb": 0, "chart_items": 0}
    ratings_cache = load_cache()
    movies = json_rpc("VideoLibrary.GetMovies", {"properties": ["title", "imdbnumber", "uniqueid", "top250"]}).get("movies", []) or []
    matched = updated = missing_imdb = 0
    for index, movie in enumerate(movies, start=1):
        if not isinstance(movie, dict):
            continue
        if progress is not None:
            progress.update(int(index * 100 / max(1, len(movies))), "[{0}/{1}] {2}".format(index, len(movies), movie.get("title") or "Tanpa judul"))
            if progress.iscanceled():
                break
        imdb_id = _movie_imdb_id(movie, ratings_cache)
        if not imdb_id:
            missing_imdb += 1
        rank = safe_int(ranks.get(imdb_id)) or 0
        if rank:
            matched += 1
        old_rank = safe_int(movie.get("top250")) or 0
        if rank != old_rank:
            result = json_rpc("VideoLibrary.SetMovieDetails", {"movieid": int(movie["movieid"]), "top250": rank})
            # Successful setters return a non-empty result in Kodi; still count
            # the attempted write because JSON-RPC errors are logged centrally.
            if result is not None:
                updated += 1
        cached_entry = (ratings_cache.get("items") or {}).get("movie|{0}".format(movie.get("movieid")))
        if isinstance(cached_entry, dict):
            cached_entry["imdb_top250_rank"] = rank
    save_cache(ratings_cache)
    return {"movies": len(movies), "matched": matched, "updated": updated, "missing_imdb": missing_imdb, "chart_items": len(ranks)}


def normalized_rating(source: str, value: Any = None, score: Any = None, votes: Any = None, provider: str = "") -> Dict[str, Any]:
    clean = re.sub(r"[^a-z0-9]", "", source.lower())
    number = safe_float(value)
    normalized = safe_float(score)
    if normalized is None and number is not None:
        if clean in ("imdb", "letterboxd", "metacriticuser") and number <= 10:
            normalized = number * 10
        else:
            normalized = number
    return {"source": clean, "value": number, "score": normalized, "votes": safe_int(votes), "provider": provider}


def merge_rating(target: Dict[str, Any], rating: Dict[str, Any], overwrite: bool = False) -> None:
    source = rating.get("source", "")
    if source and (overwrite or source not in target):
        target[source] = rating


def local_ratings(row: Dict[str, Any]) -> Dict[str, Any]:
    output: Dict[str, Any] = {}
    ratings = row.get("ratings") or {}
    if not isinstance(ratings, dict):
        return output
    for source, payload in ratings.items():
        if isinstance(payload, dict):
            rating = normalized_rating(str(source), payload.get("rating"), None, payload.get("votes"), "kodi")
        else:
            rating = normalized_rating(str(source), payload, None, None, "kodi")
        merge_rating(output, rating)
    return output


def extract_ids(row: Dict[str, Any]) -> Dict[str, str]:
    ids: Dict[str, str] = {}
    unique = row.get("uniqueid") or {}
    if isinstance(unique, dict):
        for key, value in unique.items():
            if value not in (None, ""):
                ids[str(key).lower()] = str(value).strip()
    number = str(row.get("imdbnumber") or "").strip()
    if number:
        if number.lower().startswith("tt"):
            ids.setdefault("imdb", number)
        elif number.isdigit():
            # Common TMDb scraper output observed in Kodi libraries.
            ids.setdefault("tmdb", number)
    return ids


def parent_show_map() -> Dict[int, Dict[str, Any]]:
    props = ["title", "year", "imdbnumber", "uniqueid", "ratings"]
    shows = json_rpc("VideoLibrary.GetTVShows", {"properties": props}).get("tvshows", []) or []
    output: Dict[int, Dict[str, Any]] = {}
    for row in shows:
        if isinstance(row, dict) and safe_int(row.get("tvshowid")) is not None:
            output[int(row["tvshowid"])] = row
    return output


def library_items() -> List[Dict[str, Any]]:
    output: List[Dict[str, Any]] = []
    common = ["title", "year", "imdbnumber", "uniqueid", "ratings"]
    if bool_setting("include_movies", True):
        movies = json_rpc("VideoLibrary.GetMovies", {"properties": common + ["top250"]}).get("movies", []) or []
        for row in movies:
            if isinstance(row, dict):
                item = dict(row); item["type"] = "movie"; item["dbid"] = row.get("movieid")
                output.append(item)
    shows_map: Dict[int, Dict[str, Any]] = {}
    if bool_setting("include_tvshows", True) or bool_setting("include_episodes", True):
        shows_map = parent_show_map()
    if bool_setting("include_tvshows", True):
        for row in shows_map.values():
            item = dict(row); item["type"] = "tvshow"; item["dbid"] = row.get("tvshowid")
            output.append(item)
    if bool_setting("include_episodes", True):
        episode_props = ["title", "showtitle", "season", "episode", "tvshowid", "firstaired", "uniqueid", "ratings"]
        episodes = json_rpc("VideoLibrary.GetEpisodes", {"properties": episode_props}).get("episodes", []) or []
        for row in episodes:
            if not isinstance(row, dict):
                continue
            item = dict(row); item["type"] = "episode"; item["dbid"] = row.get("episodeid")
            parent = shows_map.get(safe_int(row.get("tvshowid")) or -1, {})
            item["showtitle"] = row.get("showtitle") or parent.get("title") or ""
            item["show_year"] = parent.get("year") or ""
            item["show_ids"] = extract_ids(parent)
            output.append(item)
    return output


def mdblist_lookup(ids: Dict[str, str], media_type: str, key: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    if not key or media_type not in ("movie", "show"):
        return {}, {}

    # v1.3.14: do not rely on one MDBList identity only. Movies often work
    # via IMDb, but TV shows can return a different/partial rating set depending
    # on whether the lookup uses TMDb or IMDb. Try all available stable IDs and
    # merge the first value for each source so series can get popcorn/tomatoes
    # when the primary IMDb show lookup only returns IMDb or nothing.
    candidates: List[Tuple[str, str]] = []

    def add_candidate(provider: str, media_id: Any) -> None:
        media_id = str(media_id or "").strip()
        if not media_id:
            return
        if provider == "imdb" and not media_id.lower().startswith("tt"):
            return
        pair = (provider, media_id)
        if pair not in candidates:
            candidates.append(pair)

    if media_type == "show":
        # TMDb IDs are type-scoped and usually more reliable for show-specific
        # ratings. Keep IMDb as fallback because many libraries only have tt ids.
        add_candidate("tmdb", ids.get("tmdb") or ids.get("show_tmdb"))
        add_candidate("imdb", ids.get("imdb"))
        add_candidate("trakt", ids.get("trakt"))
        add_candidate("mdblist", ids.get("mdblist"))
    else:
        add_candidate("imdb", ids.get("imdb"))
        add_candidate("tmdb", ids.get("tmdb"))
        add_candidate("trakt", ids.get("trakt"))
        add_candidate("mdblist", ids.get("mdblist"))

    output: Dict[str, Any] = {}
    meta: Dict[str, Any] = {"ids": {}, "rate_limit_remaining": "", "attempts": []}
    for provider, media_id in candidates:
        url = "https://api.mdblist.com/{0}/{1}/{2}?{3}".format(provider, media_type, quote(media_id, safe=""), urlencode({"apikey": key}))
        try:
            payload, headers = http_json(url)
        except Exception as exc:  # pylint: disable=broad-except
            meta["attempts"].append({"provider": provider, "id": media_id, "error": str(exc)})
            continue
        rows = payload.get("ratings") or []
        count = len(rows) if isinstance(rows, list) else 0
        meta["attempts"].append({
            "provider": provider,
            "media_type": media_type,
            "id": media_id,
            "ratings": count,
            "sources": _compact_rating_sources(rows),
        })
        if isinstance(rows, list):
            for row in rows:
                if isinstance(row, dict):
                    rating = normalized_rating(str(row.get("source", "")), row.get("value"), row.get("score"), row.get("votes"), "mdblist")
                    # Preserve the first result for a source. Candidate order is
                    # deliberate; later IDs only fill missing sources.
                    merge_rating(output, rating, overwrite=False)
        for id_key, id_value in (payload.get("ids") or {}).items():
            if id_value not in (None, ""):
                meta["ids"].setdefault(str(id_key), str(id_value))
        if headers.get("x-ratelimit-remaining") not in (None, ""):
            meta["rate_limit_remaining"] = headers.get("x-ratelimit-remaining", "")
    return output, meta


def tmdb_get(path: str, key: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not key:
        return {}
    query = {"api_key": key, "language": "en-US"}
    if params:
        query.update(params)
    payload, _ = http_json("https://api.themoviedb.org/3/{0}?{1}".format(path.lstrip("/"), urlencode(query)))
    return payload


def tmdb_search(item: Dict[str, Any], key: str, show: bool = False) -> str:
    title = str(item.get("showtitle") if show else item.get("title") or "").strip()
    if not title:
        return ""
    params: Dict[str, Any] = {"query": title}
    year = safe_int(item.get("show_year") if show else item.get("year"))
    if year:
        params["first_air_date_year" if show else "year"] = year
    payload = tmdb_get("search/tv" if show else "search/movie", key, params)
    rows = payload.get("results") or []
    if isinstance(rows, list) and rows:
        candidate = rows[0] if isinstance(rows[0], dict) else {}
        return str(candidate.get("id") or "")
    return ""


def tmdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    if not key:
        return {}, ids
    output: Dict[str, Any] = {}
    updated_ids = dict(ids)
    media_type = item.get("type")
    payload: Dict[str, Any] = {}
    if media_type == "movie":
        tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, False)
        if tmdb_id:
            updated_ids.setdefault("tmdb", str(tmdb_id))
            payload = tmdb_get("movie/{0}".format(tmdb_id), key)
    elif media_type == "tvshow":
        tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, True)
        if tmdb_id:
            updated_ids.setdefault("tmdb", str(tmdb_id))
            payload = tmdb_get("tv/{0}".format(tmdb_id), key)
    elif media_type == "episode":
        show_ids = dict(item.get("show_ids") or {})
        show_tmdb = show_ids.get("tmdb") or tmdb_search(item, key, True)
        season, episode = safe_int(item.get("season")), safe_int(item.get("episode"))
        if show_tmdb and season is not None and episode is not None:
            payload = tmdb_get("tv/{0}/season/{1}/episode/{2}".format(show_tmdb, season, episode), key)
            updated_ids.setdefault("show_tmdb", str(show_tmdb))
            if payload.get("id") not in (None, ""):
                updated_ids.setdefault("tmdb", str(payload["id"]))
    vote = payload.get("vote_average")
    if vote not in (None, ""):
        merge_rating(output, normalized_rating("tmdb", vote, safe_float(vote) * 10 if safe_float(vote) is not None else None, payload.get("vote_count"), "tmdb"), overwrite=True)
    return output, updated_ids



def _date_display(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    match = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", text)
    if match:
        return "{0}/{1}/{2}".format(match.group(3), match.group(2), match.group(1))
    return text


def _episode_air_date(payload: Any) -> str:
    if isinstance(payload, dict):
        return str(payload.get("air_date") or "").strip()
    return ""


def _series_status_date(payload: Dict[str, Any]) -> Tuple[str, str]:
    next_date = _episode_air_date(payload.get("next_episode_to_air"))
    last_date = _episode_air_date(payload.get("last_episode_to_air")) or str(payload.get("last_air_date") or "").strip()
    first_date = str(payload.get("first_air_date") or "").strip()
    status = str(payload.get("status") or "").strip()
    status_l = status.lower()
    if next_date and status_l in ("returning series", "in production", "planned", "pilot"):
        return next_date, "next_episode_air_date"
    if last_date and status_l in ("ended", "canceled", "cancelled"):
        return last_date, "last_episode_air_date"
    if last_date:
        return last_date, "last_episode_air_date"
    return first_date, "first_air_date"


def tmdb_tv_status_lookup(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    """Fetch TV show status/date metadata from TMDb.

    Stored separately from ratings so there is still only one visible value per
    rating family. Used for AF3's existing TMDbHelper.ListItem.Status display.
    """
    if not key or item.get("type") != "tvshow":
        return {}, ids
    updated_ids = dict(ids)
    tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, True)
    if not tmdb_id:
        return {}, ids
    updated_ids.setdefault("tmdb", str(tmdb_id))
    payload = tmdb_get("tv/{0}".format(tmdb_id), key)
    if not payload:
        return {}, updated_ids
    status = str(payload.get("status") or "").strip()
    date_value, date_kind = _series_status_date(payload)
    meta = {
        "status": status,
        "first_air_date": str(payload.get("first_air_date") or "").strip(),
        "last_air_date": str(payload.get("last_air_date") or "").strip(),
        "next_episode_air_date": _episode_air_date(payload.get("next_episode_to_air")),
        "last_episode_air_date": _episode_air_date(payload.get("last_episode_to_air")),
        "status_date": date_value,
        "status_date_kind": date_kind,
        "status_date_display": _date_display(date_value),
        "source": "tmdb",
        "updated_at": now_iso(),
    }
    return {key: value for key, value in meta.items() if value not in (None, "")}, updated_ids


def omdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str], Dict[str, Any]]:
    meta: Dict[str, Any] = {"attempts": []}
    if not key:
        return {}, ids, meta

    def parse_payload(payload: Dict[str, Any], output: Dict[str, Any], updated_ids: Dict[str, str]) -> None:
        if not payload or str(payload.get("Response", "True")).lower() == "false":
            return
        if str(payload.get("imdbID") or "").lower().startswith("tt"):
            updated_ids.setdefault("imdb", str(payload["imdbID"]))
        if payload.get("imdbRating") not in (None, "", "N/A"):
            merge_rating(output, normalized_rating("imdb", payload.get("imdbRating"), None, payload.get("imdbVotes"), "omdb"), overwrite=False)
        if payload.get("Metascore") not in (None, "", "N/A"):
            merge_rating(output, normalized_rating("metacritic", payload.get("Metascore"), None, None, "omdb"), overwrite=False)
        for row in payload.get("Ratings") or []:
            if not isinstance(row, dict):
                continue
            source, value = str(row.get("Source", "")).lower(), row.get("Value")
            if "rotten tomatoes" in source:
                merge_rating(output, normalized_rating("tomatoes", value, None, None, "omdb"), overwrite=False)
            elif "internet movie database" in source:
                merge_rating(output, normalized_rating("imdb", value, None, None, "omdb"), overwrite=False)
            elif "metacritic" in source:
                merge_rating(output, normalized_rating("metacritic", value, None, None, "omdb"), overwrite=False)

    base: Dict[str, Any] = {"apikey": key, "r": "json", "tomatoes": "true"}
    attempts: List[Dict[str, Any]] = []
    imdb_id = ids.get("imdb", "")
    if imdb_id.lower().startswith("tt"):
        params = dict(base); params["i"] = imdb_id
        attempts.append(params)

    if item.get("type") == "episode":
        if item.get("showtitle") and safe_int(item.get("season")) is not None and safe_int(item.get("episode")) is not None:
            params = dict(base)
            params["t"] = str(item["showtitle"])
            params["Season"] = int(item["season"])
            params["Episode"] = int(item["episode"])
            attempts.append(params)
    elif not attempts:
        title = str(item.get("title") or "").strip()
        if not title:
            return {}, ids, meta
        params = dict(base)
        params["t"] = title
        year = safe_int(item.get("year"))
        if year:
            params["y"] = year
        params["type"] = "series" if item.get("type") == "tvshow" else "movie"
        attempts.append(params)

    output: Dict[str, Any] = {}
    updated_ids = dict(ids)
    seen_urls = set()
    for params in attempts:
        url = "https://www.omdbapi.com/?" + urlencode(params)
        if url in seen_urls:
            continue
        seen_urls.add(url)
        attempt_meta: Dict[str, Any] = {"params": _public_params(params)}
        try:
            payload, _ = http_json(url)
            response = str(payload.get("Response", "True")) if isinstance(payload, dict) else ""
            attempt_meta.update({
                "response": response,
                "title": payload.get("Title") if isinstance(payload, dict) else "",
                "type": payload.get("Type") if isinstance(payload, dict) else "",
                "year": payload.get("Year") if isinstance(payload, dict) else "",
                "imdbID": payload.get("imdbID") if isinstance(payload, dict) else "",
                "error": payload.get("Error") if isinstance(payload, dict) else "",
                "ratings": _compact_rating_sources(payload.get("Ratings") if isinstance(payload, dict) else []),
                "imdbRating": payload.get("imdbRating") if isinstance(payload, dict) else "",
                "Metascore": payload.get("Metascore") if isinstance(payload, dict) else "",
            })
            parse_payload(payload, output, updated_ids)
        except Exception as exc:  # pylint: disable=broad-except
            attempt_meta["error"] = str(exc)
        meta["attempts"].append(attempt_meta)
    meta["found_sources"] = [str(k) for k in output.keys()]
    return output, updated_ids, meta


def resolve_item(item: Dict[str, Any], keys: Dict[str, str], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True) -> Dict[str, Any]:
    media_type = media_setting_type(item.get("type"))
    existing = existing if isinstance(existing, dict) else {}

    # v1.3.10: preserve fresh existing data and only fill fields that are
    # missing according to the current checkboxes. This means enabling TMDb
    # later can fill only TMDb, and enabling TV status can add only status/date
    # without re-scraping IMDb/RT/etc that are already cached.
    ratings = filter_ratings_for_item(media_type, existing.get("ratings") or {}) if missing_only and existing else {}
    ids = dict(existing.get("ids") or {}) if missing_only and existing else {}
    provider_meta: Dict[str, Any] = dict(existing.get("provider_meta") or {}) if missing_only and existing else {}
    series_meta: Dict[str, Any] = dict(existing.get("series") or {}) if missing_only and existing else {}

    # Local Kodi ratings are free and offline. Merge them only into missing
    # canonical families; never create duplicate alias keys.
    local = filter_ratings_for_item(media_type, local_ratings(item))
    for key, row in local.items():
        if key not in ratings:
            ratings[key] = row

    item_ids = extract_ids(item)
    for key, value in item_ids.items():
        if value not in (None, ""):
            ids.setdefault(str(key), str(value))

    errors: List[str] = []
    missing = record_missing_logicals(media_type, {"ratings": ratings})
    status_missing = item.get("type") == "tvshow" and bool_setting("scrape_tv_status", True) and not bool(str(series_meta.get("status") or "").strip())

    # v1.3.12: missing-only is per rating checkbox, not per item.
    # MDBList score OFF only disables the mdblist score. It does NOT disable
    # MDBList as the provider for RT audience (popcorn), Trakt, Letterboxd, etc.
    mdblist_allowed = item.get("type") in ("movie", "tvshow") and bool(missing & MDBLIST_PROVIDER_LOGICALS)
    tmdb_allowed = "tmdb" in missing

    # TMDb may also be needed just to discover an ID for MDBList, or for series status.
    if bool_setting("use_tmdb", True) and keys.get("tmdb") and (tmdb_allowed or status_missing or (mdblist_allowed and not (ids.get("imdb") or ids.get("tmdb")))):
        try:
            found, ids = tmdb_lookup(item, ids, keys["tmdb"])
            for rating in found.values():
                logical = logical_for_rating_source(rating.get("source"))
                cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
                if logical in missing and cache_key and cache_key not in ratings:
                    ratings[cache_key] = _canonical_rating_row(logical, rating.get("source") or cache_key, rating)
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("tmdb: {0}".format(exc))

    if bool_setting("use_tmdb", True) and keys.get("tmdb") and status_missing:
        try:
            found_series, ids = tmdb_tv_status_lookup(item, ids, keys["tmdb"])
            if found_series:
                series_meta.update(found_series)
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("tmdb_status: {0}".format(exc))

    # OMDb first for IMDb / RT critic / Metacritic when enabled.
    # MDBList then fills only still-missing families such as RT audience/popcorn.
    missing = record_missing_logicals(media_type, {"ratings": ratings})
    omdb_allowed = bool(missing & OMDB_LOGICALS)
    if bool_setting("use_omdb", True) and keys.get("omdb") and omdb_allowed:
        try:
            found, ids, omdb_meta = omdb_lookup(item, ids, keys["omdb"])
            provider_meta["omdb"] = omdb_meta
            for rating in found.values():
                logical = logical_for_rating_source(rating.get("source"))
                cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
                if logical in missing and cache_key and cache_key not in ratings:
                    ratings[cache_key] = _canonical_rating_row(logical, rating.get("source") or cache_key, rating)
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("omdb: {0}".format(exc))

    missing = record_missing_logicals(media_type, {"ratings": ratings})
    mdblist_allowed = item.get("type") in ("movie", "tvshow") and bool(missing & MDBLIST_PROVIDER_LOGICALS)
    if item.get("type") in ("movie", "tvshow") and mdblist_allowed:
        if not bool_setting("use_mdblist", True):
            errors.append("mdblist: provider disabled")
        elif not keys.get("mdblist"):
            errors.append("mdblist: api key missing")
        else:
            try:
                found, meta = mdblist_lookup(ids, "movie" if item.get("type") == "movie" else "show", keys["mdblist"])
                provider_meta["mdblist"] = meta
                for rating in found.values():
                    logical = logical_for_rating_source(rating.get("source"))
                    cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
                    if logical in missing and cache_key and cache_key not in ratings:
                        ratings[cache_key] = _canonical_rating_row(logical, rating.get("source") or cache_key, rating)
                for key, value in (meta.get("ids") or {}).items():
                    if value not in (None, ""):
                        ids.setdefault(str(key), str(value))
            except Exception as exc:  # pylint: disable=broad-except
                errors.append("mdblist: {0}".format(exc))

    return {
        "type": item.get("type"), "dbid": item.get("dbid"), "title": item.get("title") or "",
        "year": item.get("year") or "", "showtitle": item.get("showtitle") or "",
        "season": item.get("season") if item.get("type") == "episode" else None,
        "episode": item.get("episode") if item.get("type") == "episode" else None,
        "ids": ids, "ratings": filter_ratings_for_item(media_type, ratings), "provider_meta": provider_meta,
        "series": series_meta,
        "imdb_top250_rank": (safe_int(existing.get("imdb_top250_rank")) or safe_int(item.get("top250")) or 0) if rating_enabled(media_type, "top250", True) else 0,
        "errors": errors, "timestamp": int(time.time()), "updated_at": now_iso(),
    }


def export_csv(cache: Dict[str, Any]) -> str:
    os.makedirs(PROFILE, exist_ok=True)
    entries = list((cache.get("items") or {}).values())
    canonical_entries = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        row = dict(entry)
        row["ratings"] = filter_ratings_for_item(row.get("type"), row.get("ratings") or {})
        canonical_entries.append(row)
    sources = sorted({source for entry in canonical_entries for source in (entry.get("ratings") or {}).keys()})
    fixed = ["type", "dbid", "title", "showtitle", "season", "episode", "year", "tmdb", "imdb", "imdb_top250_rank", "series_status", "series_status_date", "updated_at"]
    columns = fixed + sources
    with open(REPORT_FILE, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for entry in sorted(canonical_entries, key=lambda row: (str(row.get("type")), str(row.get("showtitle")), str(row.get("title")), safe_int(row.get("season")) or -1, safe_int(row.get("episode")) or -1)):
            row = {key: entry.get(key, "") for key in fixed}
            ids = entry.get("ids") or {}; row["tmdb"] = ids.get("tmdb", ""); row["imdb"] = ids.get("imdb", "")
            series = entry.get("series") or {}; row["series_status"] = series.get("status", ""); row["series_status_date"] = series.get("status_date", "")
            for source in sources:
                rating = (entry.get("ratings") or {}).get(source) or {}
                value = rating.get("value")
                row[source] = "" if value in (None, "") else value
            writer.writerow(row)
    return REPORT_FILE


def cache_stats(cache: Dict[str, Any]) -> Dict[str, Any]:
    entries = list((cache.get("items") or {}).values())
    stats: Dict[str, Any] = {"total": len(entries), "movie": 0, "tvshow": 0, "episode": 0, "fresh": 0, "with_ratings": 0, "sources": {}, "imdb_top250": 0}
    for entry in entries:
        kind = str(entry.get("type") or "")
        if kind in stats:
            stats[kind] += 1
        if fresh(entry): stats["fresh"] += 1
        ratings = entry.get("ratings") or {}
        if ratings: stats["with_ratings"] += 1
        if (safe_int(entry.get("imdb_top250_rank")) or 0) > 0: stats["imdb_top250"] += 1
        for source in ratings:
            stats["sources"][source] = stats["sources"].get(source, 0) + 1
    return stats



def _rating_display_for_report(logical: str, rating: Dict[str, Any]) -> str:
    if not isinstance(rating, dict):
        return ""
    if logical in ("imdb", "tmdb", "trakt", "letterboxd"):
        return display_decimal(rating)
    if logical in ("rt_critic", "rt_audience", "metacritic", "mdblist"):
        value = display_percent(rating)
        return value + "%" if value else ""
    return str(rating.get("value") or rating.get("score") or "")


def _rating_label(logical: str) -> str:
    labels = {
        "imdb": "IMDb",
        "tmdb": "TMDb",
        "rt_critic": "RT critics",
        "rt_audience": "RT audience",
        "metacritic": "Metacritic",
        "trakt": "Trakt",
        "letterboxd": "Letterboxd",
        "mdblist": "MDBList",
        "top250": "IMDb Top 250",
    }
    return labels.get(logical, logical)


def _sample_item_title(item: Dict[str, Any]) -> str:
    if item.get("type") == "episode":
        return "{0} S{1:02d}E{2:02d} - {3}".format(
            item.get("showtitle") or "Serial",
            safe_int(item.get("season")) or 0,
            safe_int(item.get("episode")) or 0,
            item.get("title") or "Tanpa judul",
        )
    return str(item.get("title") or "Tanpa judul")


def sample_rating_test(sample_size: int = 5, progress: Any = None) -> Dict[str, Any]:
    """Live-test random items without writing cache.

    Samples up to `sample_size` movies, TV shows, and episodes. For each item it
    resolves only the rating families currently enabled in settings and returns
    a human-readable result so the user can verify whether the selected sources
    actually produce values. Existing cache is used only for IDs/fallback; this
    function does not save resolved rows to ratings-cache.json.
    """
    keys = api_keys()
    all_items = library_items()
    by_type = {"movie": [], "tvshow": [], "episode": []}
    for item in all_items:
        kind = str(item.get("type") or "")
        if kind in by_type:
            by_type[kind].append(item)

    selected: List[Dict[str, Any]] = []
    for kind in ("movie", "tvshow", "episode"):
        rows = by_type.get(kind) or []
        if not rows:
            continue
        random.shuffle(rows)
        selected.extend(rows[:max(1, int(sample_size))])

    cache = load_cache()
    total = len(selected)
    results: List[Dict[str, Any]] = []
    canceled = False
    for index, item in enumerate(selected, start=1):
        if progress is not None:
            try:
                if progress.iscanceled():
                    canceled = True
                    break
                progress.update(int((index - 1) * 100 / max(1, total)), "{0}/{1}  {2}".format(index, total, _sample_item_title(item)))
            except Exception:  # pylint: disable=broad-except
                pass
        existing = (cache.get("items") or {}).get(item_key(item)) or {}
        try:
            # Use cached IDs if available, but force provider checks for the
            # enabled rating families so missing values are visible in the test.
            resolved = resolve_item(item, keys, existing, missing_only=True)
        except Exception as exc:  # pylint: disable=broad-except
            resolved = {"type": item.get("type"), "title": item.get("title"), "errors": [str(exc)], "ratings": {}}
        media_type = media_setting_type(item.get("type"))
        wanted = sorted(enabled_rating_logicals(media_type))
        ratings = filter_ratings_for_item(media_type, resolved.get("ratings") or {})
        rows = []
        for logical in wanted:
            cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
            rating = ratings.get(cache_key)
            if isinstance(rating, dict) and (safe_float(rating.get("score")) is not None or safe_float(rating.get("value")) is not None):
                rows.append({
                    "logical": logical,
                    "label": _rating_label(logical),
                    "value": _rating_display_for_report(logical, rating),
                    "provider": str(rating.get("provider") or ""),
                    "source": str(rating.get("source") or ""),
                    "ok": True,
                })
            else:
                rows.append({"logical": logical, "label": _rating_label(logical), "value": "", "provider": "", "source": "", "ok": False})
        results.append({
            "type": item.get("type"),
            "dbid": item.get("dbid"),
            "title": _sample_item_title(item),
            "ids": resolved.get("ids") or {},
            "ratings": rows,
            "errors": resolved.get("errors") or [],
            "provider_meta": resolved.get("provider_meta") or {},
            "wanted": wanted,
        })
        delay = max(0, int_setting("delay_ms", 1100)) / 1000.0
        if delay:
            time.sleep(delay)

    if progress is not None:
        try:
            progress.update(100, "Selesai")
        except Exception:  # pylint: disable=broad-except
            pass
    return {"canceled": canceled, "total": total, "results": results, "keys": {k: bool(v) for k, v in keys.items()}}


def _format_provider_attempts(provider_meta: Dict[str, Any]) -> List[str]:
    lines: List[str] = []
    omdb = provider_meta.get("omdb") or {}
    if omdb.get("attempts"):
        lines.append("  OMDb attempts:")
        for attempt in omdb.get("attempts") or []:
            params = attempt.get("params") or {}
            if params.get("i"):
                via = "i={0}".format(params.get("i"))
            elif params.get("t"):
                via = "t={0}".format(params.get("t"))
                if params.get("Season") not in (None, ""):
                    via += " S{0}E{1}".format(params.get("Season"), params.get("Episode"))
                elif params.get("type"):
                    via += " type={0}".format(params.get("type"))
            else:
                via = str(params)
            ratings = ", ".join(attempt.get("ratings") or []) or "no ratings array"
            response = attempt.get("response") or ""
            err = attempt.get("error") or ""
            title = attempt.get("title") or ""
            lines.append("    - {0} -> response={1} title={2} imdbRating={3} metascore={4} ratings=[{5}]{6}".format(
                via, response, title, attempt.get("imdbRating") or "", attempt.get("Metascore") or "", ratings, " error=" + str(err) if err else ""
            ))
    mdblist = provider_meta.get("mdblist") or {}
    if mdblist.get("attempts"):
        lines.append("  MDBList attempts:")
        for attempt in mdblist.get("attempts") or []:
            sources = ", ".join(attempt.get("sources") or []) or "no sources"
            err = attempt.get("error") or ""
            lines.append("    - {0}/{1}/{2} -> ratings_count={3} sources=[{4}]{5}".format(
                attempt.get("provider") or "", attempt.get("media_type") or "", attempt.get("id") or "", attempt.get("ratings") or 0, sources, " error=" + str(err) if err else ""
            ))
        remaining = mdblist.get("rate_limit_remaining")
        if remaining not in (None, ""):
            lines.append("    rate_limit_remaining={0}".format(remaining))
    return lines


def write_sample_rating_test_log(report: Dict[str, Any]) -> str:
    os.makedirs(PROFILE, exist_ok=True)
    text = format_sample_rating_test_report(report)
    try:
        with open(SAMPLE_CHECK_LOG_FILE, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.write("\n\n===== RAW JSON =====\n")
            handle.write(json.dumps(report, indent=2, ensure_ascii=False, sort_keys=True))
    except Exception as exc:  # pylint: disable=broad-except
        log("Failed to write sample check log: {0}".format(exc), xbmc.LOGWARNING)
    return SAMPLE_CHECK_LOG_FILE


def format_sample_rating_test_report(report: Dict[str, Any]) -> str:
    lines = []
    keys = report.get("keys") or {}
    lines.append("API key aktif: MDBList={0}, TMDb={1}, OMDb={2}".format("ON" if keys.get("mdblist") else "OFF", "ON" if keys.get("tmdb") else "OFF", "ON" if keys.get("omdb") else "OFF"))
    if report.get("canceled"):
        lines.append("Status: dibatalkan")
    lines.append("")
    current_type = None
    type_labels = {"movie": "MOVIES", "tvshow": "SERIES", "episode": "EPISODES"}
    for row in report.get("results") or []:
        kind = str(row.get("type") or "")
        if kind != current_type:
            current_type = kind
            lines.append("===== {0} =====".format(type_labels.get(kind, kind.upper() or "UNKNOWN")))
        ids = row.get("ids") or {}
        id_text = ""
        if ids.get("imdb") or ids.get("tmdb"):
            id_text = "  [imdb={0} tmdb={1}]".format(ids.get("imdb", "-"), ids.get("tmdb", "-"))
        lines.append("\n{0}{1}".format(row.get("title") or "Tanpa judul", id_text))
        for rating in row.get("ratings") or []:
            if rating.get("ok"):
                source = rating.get("source") or ""
                provider = rating.get("provider") or ""
                detail = "{0}/{1}".format(provider, source).strip("/")
                lines.append("  [OK]   {0}: {1}{2}".format(rating.get("label"), rating.get("value"), "  ({0})".format(detail) if detail else ""))
            else:
                lines.append("  [MISS] {0}".format(rating.get("label")))
        errors = [str(e) for e in (row.get("errors") or []) if str(e).strip()]
        if errors:
            lines.append("  errors: {0}".format(" | ".join(errors[:3])))
        provider_lines = _format_provider_attempts(row.get("provider_meta") or {})
        if provider_lines:
            lines.extend(provider_lines)
    if not (report.get("results") or []):
        lines.append("Tidak ada sample yang diproses.")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Arctic Fuse 3 cache publisher and automatic-maintenance helpers (v1.2.0)
# ---------------------------------------------------------------------------
AF3_PREFIX = "LibraryRatings."
TMDBHELPER_PREFIX = "TMDbHelper."
AF3_PROPERTY_NAMES = (
    "IMDb_Rating", "Top250", "TMDb_Rating", "RottenTomatoes_Rating",
    "RottenTomatoes_UserMeter", "MetaCritic_Rating", "Trakt_Rating",
    "MDBList_Rating", "Letterboxd_Rating", "RottenTomatoesIcon",
    "RottenTomatoesAudienceIcon", "Source", "Status", "StatusDate",
    "StatusDateDisplay", "FirstAirDate", "LastAirDate", "NextAirDate",
    "NextEpisodeAirDate", "LastEpisodeAirDate", "First_Air_Date",
    "Last_Air_Date", "Next_Air_Date", "ItemKey",
)


def _norm_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def cache_record(cache: Dict[str, Any], item: Dict[str, Any]) -> Dict[str, Any]:
    """Find a cached record for the current skin item.

    Normal library windows give us type+DBID, which is exact. Some Arctic Fuse
    3 hub/spotlight controls focus a Play/Options button instead of the media
    item, or expose only title/year through TMDbHelper properties. For those
    cases, fall back to title/year matching so cached library ratings can still
    be published instead of waiting for TMDbHelper's online lookup.
    """
    records = cache.get("items") or {}
    exact = records.get(item_key(item)) if safe_int(item.get("dbid")) is not None else None
    if isinstance(exact, dict) and exact:
        return exact

    kind = str(item.get("type") or "").lower()
    imdb_id = _norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb"))
    tmdb_id = _norm_tmdb(item.get("tmdb_id") or item.get("tmdb"))
    if imdb_id or tmdb_id:
        for row in records.values():
            if not isinstance(row, dict):
                continue
            row_kind = str(row.get("type") or "").lower()
            if kind and row_kind != kind:
                continue
            if not kind and row_kind not in ("movie", "tvshow", "episode"):
                continue
            ids = row.get("ids") or {}
            if imdb_id and _norm_imdb(ids.get("imdb")) == imdb_id:
                return row
            if tmdb_id and _norm_tmdb(ids.get("tmdb")) == tmdb_id:
                return row

    title = _norm_text(item.get("title"))
    year = safe_int(item.get("year"))
    showtitle = _norm_text(item.get("showtitle"))
    season = safe_int(item.get("season"))
    episode = safe_int(item.get("episode"))
    if not title:
        return {}

    candidates = []
    for row in records.values():
        if not isinstance(row, dict):
            continue
        row_kind = str(row.get("type") or "").lower()
        # Hub/spotlight buttons can expose title/year but no DBTYPE. In that
        # case accept movie/tvshow matches. Episodes still need explicit kind.
        if kind and row_kind != kind:
            continue
        if not kind and row_kind not in ("movie", "tvshow"):
            continue
        if _norm_text(row.get("title")) != title:
            continue
        if year is not None and safe_int(row.get("year")) not in (None, year):
            continue
        if kind == "episode":
            if season is not None and safe_int(row.get("season")) != season:
                continue
            if episode is not None and safe_int(row.get("episode")) != episode:
                continue
            if showtitle and _norm_text(row.get("showtitle")) not in ("", showtitle):
                continue
        candidates.append(row)

    if not candidates:
        return {}
    if len(candidates) == 1:
        return candidates[0]

    # Prefer an exact year and then a fresh record when duplicate titles exist.
    if year is not None:
        exact_year = [row for row in candidates if safe_int(row.get("year")) == year]
        if exact_year:
            candidates = exact_year
    fresh_rows = [row for row in candidates if fresh(row)]
    return (fresh_rows or candidates)[0]


def record_is_fresh(record: Dict[str, Any]) -> bool:
    return bool(record) and fresh(record)


def display_percent(rating: Dict[str, Any]) -> str:
    if not isinstance(rating, dict):
        return ""
    # v1.3.4: no automatic 0-10 -> 0-100 conversion.
    # Publish the cached/provider value as-is so values like 8, 9, 10 stay
    # 8%, 9%, 10% and never jump to 80%, 90%, 100%.
    score = safe_float(rating.get("score"))
    value = safe_float(rating.get("value"))
    number = score if score is not None else value
    if number is None:
        return ""
    return str(int(round(number)))


def display_decimal(rating: Dict[str, Any]) -> str:
    if not isinstance(rating, dict): return ""
    number = safe_float(rating.get("value"))
    if number is None:
        score = safe_float(rating.get("score"))
        number = None if score is None else score / 10.0
    return "" if number is None else "{0:.1f}".format(number)


def first_rating(ratings: Dict[str, Any], *names: str) -> Dict[str, Any]:
    for name in names:
        row = ratings.get(name)
        if isinstance(row, dict): return row
    return {}


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    ratings = record.get("ratings") or {}
    if not isinstance(ratings, dict): ratings = {}
    ratings = filter_ratings_for_item(record.get("type"), ratings)
    # v1.3.8: publish only canonical keys. No alias fallback here, because
    # filter_ratings_for_item already folds all old aliases into one value.
    critic = display_percent(first_rating(ratings, "rt_critic"))
    audience = display_percent(first_rating(ratings, "rt_audience"))
    critic_n = safe_int(critic); audience_n = safe_int(audience)
    values = {
        "IMDb_Rating": display_decimal(first_rating(ratings, "imdb")),
        "Top250": str((safe_int(record.get("imdb_top250_rank")) or "") if rating_enabled(record.get("type"), "top250", True) else ""),
        "TMDb_Rating": display_decimal(first_rating(ratings, "tmdb")),
        "RottenTomatoes_Rating": critic,
        "RottenTomatoes_UserMeter": audience,
        "MetaCritic_Rating": display_percent(first_rating(ratings, "metacritic")),
        "Trakt_Rating": display_decimal(first_rating(ratings, "trakt")),
        "MDBList_Rating": display_percent(first_rating(ratings, "mdblist")),
        "Letterboxd_Rating": display_decimal(first_rating(ratings, "letterboxd")),
        "RottenTomatoesIcon": "rtfresh.png" if critic_n is None or critic_n >= 60 else "rtrotten.png",
        "RottenTomatoesAudienceIcon": "popcorn.png" if audience_n is None or audience_n >= 60 else "popcorn_spilt.png",
        "Source": "script.library.ratings.scraper",
    }
    series = record.get("series") or {}
    if bool_setting("publish_tv_status", True) and record.get("type") in ("tvshow", "season", "episode") and isinstance(series, dict):
        status = str(series.get("status") or "").strip()
        status_date = str(series.get("status_date") or "").strip()
        status_date_display = str(series.get("status_date_display") or _date_display(status_date)).strip()
        first_air = str(series.get("first_air_date") or "").strip()
        last_air = str(series.get("last_air_date") or "").strip()
        next_air = str(series.get("next_episode_air_date") or "").strip()
        last_episode_air = str(series.get("last_episode_air_date") or "").strip()
        values.update({
            "Status": status,
            "StatusDate": status_date_display or _date_display(status_date),
            "StatusDateDisplay": status_date_display,
            "FirstAirDate": _date_display(first_air),
            "LastAirDate": _date_display(last_air),
            "NextAirDate": _date_display(next_air),
            "NextEpisodeAirDate": _date_display(next_air),
            "LastEpisodeAirDate": _date_display(last_episode_air),
            "First_Air_Date": _date_display(first_air),
            "Last_Air_Date": _date_display(last_air),
            "Next_Air_Date": _date_display(next_air),
        })
    return {key: str(value) for key, value in values.items() if value not in (None, "")}



def _window_home():
    import xbmcgui
    return xbmcgui.Window(10000)


def publish_af3_properties(values: Dict[str, str], item_identity: str = "", compatibility: bool = True) -> None:
    home = _window_home()
    published = dict(values)
    published["ItemKey"] = item_identity
    for name in AF3_PROPERTY_NAMES:
        value = str(published.get(name, "") or "")
        home.setProperty(AF3_PREFIX + "ListItem." + name, value)
        if compatibility:
            # Arctic Fuse 3 already reads the TMDbHelper.ListItem.* property
            # namespace. Publishing the cache there avoids a skin-file patch.
            home.setProperty(TMDBHELPER_PREFIX + "ListItem." + name, value)


def clear_af3_properties(compatibility: bool = True) -> None:
    publish_af3_properties({}, "", compatibility)


def _info_label(*names: str) -> str:
    for name in names:
        value = xbmc.getInfoLabel(name).strip()
        if value:
            return value
    return ""


def _home_property(*names: str) -> str:
    import xbmcgui
    home = xbmcgui.Window(10000)
    for name in names:
        value = home.getProperty(name).strip()
        if value:
            return value
    return ""


def _window_property(*names: str) -> str:
    """Read properties from the currently visible window.

    Arctic Fuse 3 often stores the item context for Hub/Spotlight on the
    current window, while the focused Kodi control can be a Play/More button.
    The old fallback only checked Window(Home), so it could miss the same item
    that the skin was already using for clearlogo/plot.
    """
    for name in names:
        try:
            value = xbmc.getInfoLabel("Window.Property({0})".format(name)).strip()
        except Exception:  # pylint: disable=broad-except
            value = ""
        if value:
            return value
    return ""


def _any_window_property(*names: str) -> str:
    return _window_property(*names) or _home_property(*names)


def _norm_imdb(value: Any) -> str:
    match = re.search(r"tt\d+", str(value or ""), re.I)
    return match.group(0).lower() if match else ""


def _norm_tmdb(value: Any) -> str:
    number = safe_int(value)
    return str(number) if number is not None else str(value or "").strip()


def _clean_dbtype(value: str) -> str:
    value = str(value or "").strip().lower()
    aliases = {"movies": "movie", "tv": "tvshow", "show": "tvshow", "series": "tvshow", "episodes": "episode"}
    return aliases.get(value, value)


def selected_library_item() -> Dict[str, Any]:
    return {
        "type": _clean_dbtype(_info_label("ListItem.DBTYPE", "ListItem.DBType")),
        "dbid": _info_label("ListItem.DBID"),
        "title": _info_label("ListItem.Title"),
        "year": _info_label("ListItem.Year"),
        "imdbnumber": _info_label("ListItem.IMDBNumber", "ListItem.UniqueID(imdb)", "ListItem.Property(imdb_id)"),
        "tmdb_id": _info_label("ListItem.UniqueID(tmdb)", "ListItem.Property(tmdb_id)", "ListItem.Property(tmdbid)"),
        "top250": _info_label("ListItem.Top250"),
    }


def lrs_active_item() -> Dict[str, Any]:
    """Optional skin bridge target.

    A tiny AF3 skin patch can set LRS.Active.* properties from the media item
    it is drawing, even when focus is on a hub button. This function is harmless
    without that patch and lets future skin-side bridges work without changing
    the display layout.
    """
    imdb = _any_window_property(
        "LRS.Active.IMDb_ID", "LRS.Active.IMDbID", "LRS.Active.IMDbNumber",
        "LRS.Active.IMDBNumber", "LRS.Active.imdb_id",
    )
    tmdb = _any_window_property("LRS.Active.TMDb_ID", "LRS.Active.TMDbID", "LRS.Active.tmdb_id")
    return {
        "type": _clean_dbtype(_any_window_property("LRS.Active.DBTYPE", "LRS.Active.DBType", "LRS.Active.Type")),
        "dbid": _any_window_property("LRS.Active.DBID", "LRS.Active.DBId", "LRS.Active.dbid"),
        "title": _any_window_property("LRS.Active.Title", "LRS.Active.title", "LRS.Active.Label"),
        "year": _any_window_property("LRS.Active.Year", "LRS.Active.year"),
        "imdbnumber": imdb,
        "tmdb_id": tmdb,
        "top250": _any_window_property("LRS.Active.Top250"),
    }


def tmdbhelper_item() -> Dict[str, Any]:
    """Fallback for Arctic Fuse 3 hub/spotlight windows.

    Hub/Spotlight can focus a Play/Options button, not the media list item.
    AF3/TMDbHelper can still expose identity on either the current window or
    Window(Home). Check both, then match our local cache by DBID, IMDb ID,
    TMDb ID, or title/year. Rating values still come from this add-on cache.
    """
    imdb = _any_window_property(
        "TMDbHelper.ListItem.IMDb_ID", "TMDbHelper.ListItem.IMDbID",
        "TMDbHelper.ListItem.IMDbNumber", "TMDbHelper.ListItem.IMDBNumber",
        "TMDbHelper.ListItem.imdb_id",
    )
    tmdb = _any_window_property("TMDbHelper.ListItem.TMDb_ID", "TMDbHelper.ListItem.TMDbID", "TMDbHelper.ListItem.tmdb_id")
    return {
        "type": _clean_dbtype(_any_window_property("TMDbHelper.ListItem.DBTYPE", "TMDbHelper.ListItem.DBType", "TMDbHelper.ListItem.Type", "TMDbHelper.ListItem.tmdb_type")),
        "dbid": _any_window_property("TMDbHelper.ListItem.DBID", "TMDbHelper.ListItem.DBId", "TMDbHelper.ListItem.dbid"),
        "title": _any_window_property("TMDbHelper.ListItem.Title", "TMDbHelper.ListItem.title", "TMDbHelper.ListItem.Label", "TMDbHelper.ListItem.TVShowTitle"),
        "year": _any_window_property("TMDbHelper.ListItem.Year", "TMDbHelper.ListItem.year", "TMDbHelper.ListItem.ReleaseYear"),
        "imdbnumber": imdb,
        "tmdb_id": tmdb,
        "top250": _any_window_property("TMDbHelper.ListItem.Top250"),
    }

def screensaver_item(offset: int = 0) -> Dict[str, Any]:
    def li(field: str) -> str:
        expression = "Container(1297).ListItem.{0}".format(field) if offset == 0 else "Container(1297).ListItem({0}).{1}".format(offset, field)
        return xbmc.getInfoLabel(expression).strip()
    return {
        "type": _clean_dbtype(li("DBTYPE") or li("DBType")),
        "dbid": li("DBID"), "title": li("Title"), "year": li("Year"),
        "imdbnumber": li("IMDBNumber") or li("UniqueID(imdb)") or li("Property(imdb_id)"),
        "tmdb_id": li("UniqueID(tmdb)") or li("Property(tmdb_id)") or li("Property(tmdbid)"),
        "top250": li("Top250"),
    }


def valid_library_item(item: Dict[str, Any]) -> bool:
    kind = str(item.get("type") or "")
    has_identity = (
        safe_int(item.get("dbid")) is not None
        or bool(str(item.get("title") or "").strip())
        or bool(_norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb")))
        or bool(_norm_tmdb(item.get("tmdb_id") or item.get("tmdb")))
    )
    # Empty kind is allowed for AF3 hub/spotlight fallbacks where the focused
    # control is a button but title/year/IMDb/TMDb ID are still available
    # through properties.
    return has_identity and (kind in ("", "movie", "tvshow", "episode"))


def resolvable_library_item(item: Dict[str, Any]) -> bool:
    return str(item.get("type") or "") in ("movie", "tvshow", "episode") and safe_int(item.get("dbid")) is not None


def enabled_rating_logicals(media_type: Any) -> set:
    media_type = media_setting_type(media_type)
    logicals = set()
    for logical in RATING_LOGICALS_BY_TYPE.get(media_type, set()):
        if logical == "top250":
            continue
        if rating_enabled(media_type, logical, True):
            logicals.add(logical)
    return logicals


def record_missing_logicals(media_type: Any, record: Dict[str, Any]) -> set:
    media_type = media_setting_type(media_type)
    wanted = enabled_rating_logicals(media_type)
    if not wanted:
        return set()
    ratings = filter_ratings_for_item(media_type, (record or {}).get("ratings") or {})
    present = set()
    for key, row in ratings.items():
        logical = logical_for_rating_source(key) or key
        if logical in wanted and isinstance(row, dict):
            if safe_float(row.get("score")) is not None or safe_float(row.get("value")) is not None:
                present.add(logical)
    return wanted - present


def record_missing_series_status(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if item.get("type") != "tvshow" or not bool_setting("scrape_tv_status", True):
        return False
    series = (record or {}).get("series") or {}
    if not isinstance(series, dict):
        return True
    return not bool(str(series.get("status") or "").strip())


def record_needs_update(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if not record:
        return True
    if not fresh(record):
        return True
    if record_missing_logicals(item.get("type"), record):
        return True
    if record_missing_series_status(item, record):
        return True
    return False


def stale_or_missing_items(cache: Dict[str, Any], include_missing: bool = True) -> List[Dict[str, Any]]:
    records = cache.get("items") or {}
    items = library_items()
    result: List[Dict[str, Any]] = []
    for item in items:
        row = records.get(item_key(item)) or {}
        if (include_missing and not row) or (row and record_needs_update(item, row)):
            result.append(item)
    return result

Library Ratings Scraper 1.5.42 - Screensaver lifetime playtime clock fix

Base: 1.5.41 diagnostics build.

- Keeps runtime/diagnostics/screensaver-clearlogo-report.txt in Export diagnostics.
- Keeps clearlogo-selection details out of kodi.log.
- Fixes source steam_playtime being caught by the generic Steam icon rule.
- Lifetime playtime now resolves to ends.png before the generic steam.png rule.
- Result: Library, Home, Hub, and Arctic Mirage screensaver all use the same clock icon.

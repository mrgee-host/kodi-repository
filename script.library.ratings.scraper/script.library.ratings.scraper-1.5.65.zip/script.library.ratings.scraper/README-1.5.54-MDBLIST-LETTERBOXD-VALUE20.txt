LRS 1.5.54 - MDBList Letterboxd score or value x20

- Accepts Letterboxd only from MDBList ratings[] source=letterboxd.
- Uses score first when score is a valid integer from 1 to 100.
- When score is absent, calculates round(value * 20) for value in the 0-5 range.
- Example: value=3.1 without score is stored and displayed as 62.
- Stores the final whole-number score in the Letterboxd database column.
- Does not migrate, rewrite, or reinterpret existing Letterboxd database rows.
- Scrape Missing can populate Letterboxd when it has not been scraped before.

Library Ratings Scraper 1.5.63
================================

Fixes a 1.5.62 auto-scan regression where every episode could be marked as an
identity change after a Kodi library scan.

Cause
-----
Episode library items carry two different ID groups:
- uniqueid / ids: IDs belonging to the episode
- show_ids: IDs belonging to the parent TV show

The identity helper merged show_ids after the episode unique IDs, overwriting
the episode IMDb/TMDb/TVDb values with parent-series IDs. Comparing that result
with ratings-cache.db made normal episodes look like reused DBIDs.

Fix
---
- Identity comparison uses only IDs belonging to the current item.
- Parent show_ids remain available for provider lookups, but never participate
  in episode cache identity.
- Real DBID reuse remains detected through episode IDs and show/season/episode.
- IMDb dataset flow, seven-day generation logic, no-votes design, and provider
  fallbacks from 1.5.62 remain unchanged.

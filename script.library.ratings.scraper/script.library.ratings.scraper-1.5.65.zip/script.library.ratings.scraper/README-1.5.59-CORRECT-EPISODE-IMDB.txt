Library Ratings Scraper 1.5.59
================================

WITHDRAWN / SUPERSEDED BY 1.5.60
--------------------------------
The direct imdb.com title-page fallback experiment in 1.5.59 is disabled and
removed from the active provider flow.

Use 1.5.60 or newer:
- Episode IMDb rating: OMDb only.
- Episode TMDb rating: TMDb.
- MDBList: movie and TV show only.
- DBID reuse identity guard remains active.

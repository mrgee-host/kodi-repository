Library Ratings Scraper 1.5.58 - WITHDRAWN

DO NOT USE THIS BUILD.

The 1.5.58 experiment incorrectly attempted an MDBList show endpoint for
episode IMDb recovery. MDBList must not be used as an episode provider.
Use 1.5.59 or newer. The DBID identity guard concept remains valid, but the
episode provider chain was corrected.

Library Ratings Scraper 1.5.55

- Adds Display > Rating 7.
- Rating 7 defaults to Letterboxd.
- Number of rating slots now supports 1 through 7.
- Publishes RatingSlot7_Source/Icon/IconFile/Label/Value in every supported context.
- No rating database migration or fallback was added.

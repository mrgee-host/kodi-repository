# -*- coding: utf-8 -*-
"""Fast local IMDb rating lookup using the official title.ratings dataset.

Only ``tconst`` and ``averageRating`` are imported. ``numVotes`` is deliberately
ignored: Library Ratings Scraper does not read, store, compare, publish, or
report vote counts from any provider.
"""
from __future__ import annotations

import csv
import gzip
import os
import re
import sqlite3
import time
from typing import Any, Callable, Dict, Iterable, List, Optional
from urllib.request import Request, urlopen

DATASET_URL = "https://datasets.imdbws.com/title.ratings.tsv.gz"
DB_NAME = "imdb-title-ratings.db"
LOCK_NAME = "imdb-title-ratings.lock"
SCHEMA_VERSION = 2
DEFAULT_MAX_AGE_DAYS = 7
DEFAULT_TIMEOUT = 45
_TCONST_RE = re.compile(r"^tt\d+$", re.I)
_LAST_ENSURE: Dict[str, Dict[str, Any]] = {}


def _now() -> int:
    return int(time.time())


def _log(callback: Optional[Callable[[str], None]], message: str) -> None:
    if callback:
        try:
            callback(message)
        except Exception:
            pass


def database_path(profile_dir: str) -> str:
    return os.path.join(profile_dir, DB_NAME)


def _metadata(db_path: str) -> Dict[str, Any]:
    if not os.path.isfile(db_path):
        return {}
    try:
        with sqlite3.connect(db_path) as conn:
            rows = conn.execute("SELECT key,value FROM metadata").fetchall()
        return {str(key): value for key, value in rows}
    except Exception:
        return {}


def _columns(db_path: str, table: str) -> List[str]:
    if not os.path.isfile(db_path):
        return []
    try:
        with sqlite3.connect(db_path) as conn:
            return [str(row[1]) for row in conn.execute("PRAGMA table_info(%s)" % table).fetchall()]
    except Exception:
        return []


def _schema_current(db_path: str) -> bool:
    columns = _columns(db_path, "ratings")
    return columns == ["tconst", "average_rating"]


def _is_fresh(db_path: str, max_age_days: int) -> bool:
    meta = _metadata(db_path)
    try:
        fetched_at = int(meta.get("fetched_at") or 0)
    except Exception:
        fetched_at = 0
    return bool(fetched_at and (_now() - fetched_at) < max(1, int(max_age_days)) * 86400)


def _migrate_legacy_schema(db_path: str) -> Dict[str, Any]:
    """Remove the legacy num_votes column without downloading the dataset again."""
    if not os.path.isfile(db_path) or _schema_current(db_path):
        return {"migrated": False, "db_path": db_path}
    columns = set(_columns(db_path, "ratings"))
    if not {"tconst", "average_rating"}.issubset(columns):
        return {"migrated": False, "db_path": db_path, "invalid": True}
    old_meta = _metadata(db_path)
    temp_db = db_path + ".novotes-%s" % os.getpid()
    try:
        if os.path.exists(temp_db):
            os.remove(temp_db)
        source = sqlite3.connect(db_path)
        target = sqlite3.connect(temp_db)
        try:
            target.execute("PRAGMA journal_mode=OFF")
            target.execute("PRAGMA synchronous=OFF")
            target.execute("CREATE TABLE ratings(tconst TEXT PRIMARY KEY, average_rating REAL NOT NULL)")
            target.execute("CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT)")
            cursor = source.execute("SELECT tconst,average_rating FROM ratings")
            while True:
                rows = cursor.fetchmany(20000)
                if not rows:
                    break
                target.executemany("INSERT OR REPLACE INTO ratings(tconst,average_rating) VALUES(?,?)", rows)
            old_meta["schema_version"] = str(SCHEMA_VERSION)
            old_meta["vote_data"] = "disabled"
            old_meta["migrated_no_votes_at"] = str(_now())
            target.executemany("INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)", old_meta.items())
            target.commit()
            count = int(target.execute("SELECT COUNT(*) FROM ratings").fetchone()[0] or 0)
            if count <= 0:
                raise RuntimeError("IMDb dataset no-votes migration produced no rows")
        finally:
            source.close()
            target.close()
        os.replace(temp_db, db_path)
        return {"migrated": True, "rows": count, "db_path": db_path}
    finally:
        try:
            if os.path.exists(temp_db):
                os.remove(temp_db)
        except OSError:
            pass


def import_gzip_file(gzip_path: str, db_path: str, fetched_at: Optional[int] = None) -> Dict[str, Any]:
    """Import tconst and averageRating only into an atomic SQLite database."""
    parent = os.path.dirname(db_path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    temp_db = db_path + ".building-%s" % os.getpid()
    try:
        if os.path.exists(temp_db):
            os.remove(temp_db)
        conn = sqlite3.connect(temp_db)
        try:
            conn.execute("PRAGMA journal_mode=OFF")
            conn.execute("PRAGMA synchronous=OFF")
            conn.execute("PRAGMA temp_store=MEMORY")
            conn.execute("CREATE TABLE ratings(tconst TEXT PRIMARY KEY, average_rating REAL NOT NULL)")
            conn.execute("CREATE TABLE metadata(key TEXT PRIMARY KEY, value TEXT)")
            batch = []
            imported = 0
            skipped = 0
            with gzip.open(gzip_path, "rt", encoding="utf-8", newline="") as handle:
                reader = csv.DictReader(handle, delimiter="\t")
                for row in reader:
                    tconst = str(row.get("tconst") or "").strip().lower()
                    if not _TCONST_RE.match(tconst):
                        skipped += 1
                        continue
                    try:
                        rating = float(row.get("averageRating") or "")
                    except (TypeError, ValueError):
                        skipped += 1
                        continue
                    if rating <= 0:
                        skipped += 1
                        continue
                    # numVotes is intentionally not accessed.
                    batch.append((tconst, rating))
                    if len(batch) >= 20000:
                        conn.executemany("INSERT OR REPLACE INTO ratings(tconst,average_rating) VALUES(?,?)", batch)
                        imported += len(batch)
                        batch = []
                if batch:
                    conn.executemany("INSERT OR REPLACE INTO ratings(tconst,average_rating) VALUES(?,?)", batch)
                    imported += len(batch)
            stamp = int(fetched_at or _now())
            metadata = {
                "schema_version": str(SCHEMA_VERSION),
                "fetched_at": str(stamp),
                "dataset": "title.ratings.tsv.gz",
                "rows": str(imported),
                "skipped": str(skipped),
                "vote_data": "disabled",
            }
            conn.executemany("INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)", metadata.items())
            conn.commit()
            check = int(conn.execute("SELECT COUNT(*) FROM ratings").fetchone()[0] or 0)
            if check != imported or imported <= 0:
                raise RuntimeError("IMDb dataset validation failed: rows=%s imported=%s" % (check, imported))
        finally:
            conn.close()
        os.replace(temp_db, db_path)
        return {"ok": True, "rows": imported, "skipped": skipped, "fetched_at": stamp, "db_path": db_path}
    finally:
        try:
            if os.path.exists(temp_db):
                os.remove(temp_db)
        except OSError:
            pass


def _download(url: str, target: str, timeout: int) -> int:
    request = Request(url, headers={
        "User-Agent": "Kodi-Library-Ratings-Scraper/1.5.62",
        "Accept": "application/gzip,application/octet-stream;q=0.9,*/*;q=0.1",
    })
    size = 0
    with urlopen(request, timeout=timeout) as response, open(target, "wb") as output:
        while True:
            chunk = response.read(1024 * 1024)
            if not chunk:
                break
            output.write(chunk)
            size += len(chunk)
    if size < 1024:
        raise RuntimeError("IMDb dataset download is unexpectedly small: %s bytes" % size)
    return size


def _acquire_lock(lock_path: str) -> bool:
    try:
        fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            handle.write("%s|%s\n" % (os.getpid(), _now()))
        return True
    except FileExistsError:
        try:
            if (_now() - int(os.path.getmtime(lock_path))) > 7200:
                os.remove(lock_path)
                return _acquire_lock(lock_path)
        except OSError:
            pass
        return False


def ensure_dataset(profile_dir: str, max_age_days: int = DEFAULT_MAX_AGE_DAYS,
                   timeout: int = DEFAULT_TIMEOUT, force: bool = False,
                   log_callback: Optional[Callable[[str], None]] = None) -> Dict[str, Any]:
    """Ensure a usable local dataset and retain stale data on refresh failure."""
    profile_dir = os.path.abspath(profile_dir)
    os.makedirs(profile_dir, exist_ok=True)
    db_path = database_path(profile_dir)

    migration = _migrate_legacy_schema(db_path)
    if migration.get("migrated"):
        _log(log_callback, "IMDb dataset: removed legacy vote-count column")
        _LAST_ENSURE.pop(profile_dir, None)

    cached = _LAST_ENSURE.get(profile_dir)
    if cached and not force:
        checked_at = int(cached.get("checked_at") or 0)
        if cached.get("usable") and _is_fresh(db_path, max_age_days):
            result = dict(cached)
            result["fresh"] = True
            result["refreshed"] = False
            result["checked_at"] = _now()
            result["metadata"] = _metadata(db_path)
            return result
        if checked_at and (_now() - checked_at) < 300:
            result = dict(cached)
            result["refreshed"] = False
            return result

    if not force and _is_fresh(db_path, max_age_days) and _schema_current(db_path):
        result = {
            "usable": True, "fresh": True, "refreshed": False,
            "db_path": db_path, "metadata": _metadata(db_path), "checked_at": _now(),
        }
        _LAST_ENSURE[profile_dir] = dict(result)
        return result

    lock_path = os.path.join(profile_dir, LOCK_NAME)
    owns_lock = _acquire_lock(lock_path)
    if not owns_lock:
        if not os.path.isfile(db_path):
            deadline = time.time() + 30
            while time.time() < deadline and not os.path.isfile(db_path):
                time.sleep(0.5)
        usable = os.path.isfile(db_path) and _schema_current(db_path)
        result = {
            "usable": usable,
            "fresh": _is_fresh(db_path, max_age_days) if usable else False,
            "refreshed": False, "locked": True, "db_path": db_path,
            "metadata": _metadata(db_path) if usable else {}, "checked_at": _now(),
            "error": "dataset refresh already running" if not usable else "",
        }
        _LAST_ENSURE[profile_dir] = dict(result)
        return result

    temp_gz = os.path.join(profile_dir, "title.ratings.tsv.gz.download-%s" % os.getpid())
    try:
        _log(log_callback, "IMDb dataset: downloading title.ratings.tsv.gz")
        size = _download(DATASET_URL, temp_gz, timeout)
        imported = import_gzip_file(temp_gz, db_path)
        result = {
            "usable": True, "fresh": True, "refreshed": True,
            "download_bytes": size, "db_path": db_path,
            "metadata": _metadata(db_path), "import": imported, "checked_at": _now(),
        }
        _log(log_callback, "IMDb dataset: imported %s rating rows" % imported.get("rows"))
    except Exception as exc:
        usable = os.path.isfile(db_path) and _schema_current(db_path)
        result = {
            "usable": usable, "fresh": False, "refreshed": False,
            "stale_fallback": usable, "db_path": db_path,
            "metadata": _metadata(db_path) if usable else {}, "checked_at": _now(),
            "error": str(exc),
        }
        _log(log_callback, "IMDb dataset refresh failed; stale=%s error=%s" % (usable, exc))
    finally:
        try:
            if os.path.exists(temp_gz):
                os.remove(temp_gz)
        except OSError:
            pass
        try:
            os.remove(lock_path)
        except OSError:
            pass
    _LAST_ENSURE[profile_dir] = dict(result)
    return dict(result)


def _normalize_ids(imdb_ids: Iterable[str]) -> List[str]:
    output: List[str] = []
    seen = set()
    for value in imdb_ids or []:
        tconst = str(value or "").strip().lower()
        if _TCONST_RE.match(tconst) and tconst not in seen:
            output.append(tconst)
            seen.add(tconst)
    return output


def lookup_many(profile_dir: str, imdb_ids: Iterable[str], max_age_days: int = DEFAULT_MAX_AGE_DAYS,
                timeout: int = DEFAULT_TIMEOUT, force_refresh: bool = False,
                log_callback: Optional[Callable[[str], None]] = None,
                ensured: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Look up many exact tconst values using one SQLite connection."""
    ids = _normalize_ids(imdb_ids)
    ensured_result = dict(ensured or ensure_dataset(
        profile_dir, max_age_days, timeout, force_refresh, log_callback
    ))
    results: Dict[str, Dict[str, Any]] = {}
    if not ensured_result.get("usable"):
        for tconst in ids:
            results[tconst] = {
                "status": "unavailable", "imdb_id": tconst, "temporary": True,
                "error": ensured_result.get("error") or "IMDb dataset unavailable",
            }
        return {"dataset": ensured_result, "results": results}
    try:
        with sqlite3.connect(ensured_result["db_path"]) as conn:
            for start in range(0, len(ids), 900):
                chunk = ids[start:start + 900]
                placeholders = ",".join("?" for _ in chunk)
                rows = conn.execute(
                    "SELECT tconst,average_rating FROM ratings WHERE tconst IN (%s)" % placeholders,
                    chunk,
                ).fetchall() if chunk else []
                found = {str(row[0]).lower(): float(row[1]) for row in rows}
                for tconst in chunk:
                    if tconst in found:
                        results[tconst] = {
                            "status": "found", "imdb_id": tconst,
                            "rating": found[tconst], "temporary": False,
                        }
                    else:
                        results[tconst] = {
                            "status": "not_found", "imdb_id": tconst,
                            "temporary": False,
                        }
    except Exception as exc:
        for tconst in ids:
            results[tconst] = {
                "status": "unavailable", "imdb_id": tconst,
                "temporary": True, "error": str(exc),
            }
    return {"dataset": ensured_result, "results": results}


def lookup(profile_dir: str, imdb_id: str, max_age_days: int = DEFAULT_MAX_AGE_DAYS,
           timeout: int = DEFAULT_TIMEOUT, force_refresh: bool = False,
           log_callback: Optional[Callable[[str], None]] = None) -> Dict[str, Any]:
    """Look up one exact IMDb tconst."""
    tconst = str(imdb_id or "").strip().lower()
    if not _TCONST_RE.match(tconst):
        return {"status": "invalid_id", "imdb_id": tconst, "temporary": False}
    batch = lookup_many(
        profile_dir, [tconst], max_age_days=max_age_days, timeout=timeout,
        force_refresh=force_refresh, log_callback=log_callback,
    )
    row = dict((batch.get("results") or {}).get(tconst) or {})
    row["dataset"] = batch.get("dataset") or {}
    return row

Library Ratings Scraper 1.5.49

- All status/result/report text uses Kodi DialogTextViewer and is scrollable.
- Main menu now groups Resolver cache and CropV2.
- Each group exposes only Rebuild and Fill missing.
- Removes the alpha-threshold repair and restores TMDbHelper-compatible normal bbox cropping.
- CropV2 input bytes are read only from Kodi Textures*.db / userdata/Thumbnails.
- No URL is opened and no network fallback is used.
- Destination filename hash remains md5(canonical ListItem.Art source URL).

Library Ratings Scraper 1.5.62
================================

IMDb dataset flow
-----------------
- Dataset resmi IMDb title.ratings.tsv.gz diunduh maksimal sekali per 7 hari.
- File diimpor ke imdb-title-ratings.db hanya dengan kolom tconst dan average_rating.
- numVotes tidak dibaca, disimpan, dibandingkan, diterbitkan, atau dimasukkan laporan.
- Semua lookup IMDb target dilakukan sekaligus memakai satu koneksi SQLite sebelum provider online.

Refresh All
-----------
- Semua movie, series, dan episode yang aktif dicocokkan ke dataset.
- Rating numerik dataset menimpa IMDb lama.
- Jika tt-ID tidak ditemukan atau dataset gagal, IMDb lama dipertahankan.
- Movie/series kemudian diproses melalui MDBList untuk rating non-IMDb.

Scrape Missing
--------------
- Jika generasi dataset masih sama: IMDb kosong saja yang dicari. IMDb N/A dan angka dilewati.
- Jika dataset baru berhasil diunduh atau belum pernah diterapkan ke library: seluruh IMDb item aktif dicocokkan ke dataset baru.
- Provider non-IMDb tetap hanya memproses item yang memang missing.
- Tidak ada job full-refresh otomatis terpisah.

Provider
--------
- Episode IMDb: dataset saja, tanpa OMDb.
- Movie/series IMDb: dataset lebih dulu; IMDb dari MDBList diabaikan.
- MDBList tetap menangani rating non-IMDb.
- Fallback OMDb dan direct TMDb tetap berjalan ketika MDBList menjawab item not found.
- Kodi local ratings tidak lagi diminta dari JSON-RPC dan tidak masuk resolver.

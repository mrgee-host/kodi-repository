Library Ratings Scraper 1.5.46
================================

Fixes clearlogo appearing only when Arctic Mirage starts from an addon page.

Kodi keeps the previous window active underneath a screensaver. The final LRS
context wrapper checked AF3 Home/Hub/MyPrograms/MyVideoNav before reaching the
older screensaver-first resolver.

From Home/Hub/Library:
- Hidden background-window item could be published.
- ClearLogoFinal identity did not match Container(1297).
- KPM's identity guard correctly hid the mismatched clearlogo.

From an addon page:
- The AF3 background-window resolvers did not intercept.
- Container(1297) was used and clearlogo appeared.

v1.5.46 checks System.ScreenSaverActive first and reads only offset 0 from
Container(1297) as the active slide.

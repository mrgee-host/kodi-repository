Library Ratings Scraper 1.5.60
================================

Episode provider rule
---------------------
- IMDb episode rating: OMDb only.
- TMDb episode rating: TMDb.
- MDBList: movie and TV show only.
- No imdb.com page request, HTML parsing, JSON-LD parsing, or direct IMDb fallback.
- OMDb N/A remains a completed result and is not reopened by Scrape Missing.

DBID reuse protection
---------------------
The identity guard from 1.5.59 remains active. A cached row is rejected when a
Kodi DBID is reused for a different movie, TV show, or episode identity.

Library Ratings Scraper 1.5.45
================================

Fixes the v1.5.44 hash bug.

v1.5.44 incorrectly produced:
1. md5(JSON-RPC image:// wrapper)
2. md5(str(decoded_list))

The second filename was based on text such as:
['https://image.tmdb.org/t/p/original/example.png']

v1.5.45 produces one canonical TMDbHelper-compatible filename:
cropped-<md5(decoded ListItem.Art URL)>.png

New menu:
Repair CropV2 hashes and remove 1.5.44 duplicates

Safety:
- Creates the canonical file first.
- Deletes only legacy alias files whose bytes are identical to the canonical.
- Does not delete unrelated CropV2 files.

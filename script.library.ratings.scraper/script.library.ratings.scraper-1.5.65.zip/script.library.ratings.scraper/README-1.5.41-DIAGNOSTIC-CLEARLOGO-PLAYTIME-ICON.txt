Library Ratings Scraper 1.5.41

- Removes active screensaver clearlogo-selection writes from kodi.log.
- Creates runtime/diagnostics/screensaver-clearlogo-report.txt in a human-readable format.
- Keeps up to 100 recent selections and clearly states CropV2, Kodi clearlogo, or title fallback.
- Export diagnostics always includes the report under runtime/diagnostics/.
- Maps steam_playtime to steam-playtime.png before the generic Steam icon rule.

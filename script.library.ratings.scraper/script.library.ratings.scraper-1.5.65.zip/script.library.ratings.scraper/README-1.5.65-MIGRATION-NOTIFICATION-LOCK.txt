Library Ratings Scraper 1.5.65

- AF3-safe progress: full lines up to 65 characters; longer lines use a word-safe 64-character target and Unicode ellipsis.
- Episode progress preserves the counter, SxxExx, series title where possible, and the final phase label.
- TMDb episode HTTP 404/status 34 becomes definitive N/A; 5xx, timeouts, auth errors, and rate limits stay retryable.
- Typed provider-ID safety prevents a TVDb imdbnumber from being relabeled as a TMDb show ID.
- Episode TMDb fallback trusts only the parent TMDb ID explicitly supplied by Kodi; it does not title-search or guess a show.
- MDBList logs identify which key index reached its daily limit, whether the request continued with the next key, and when all keys are exhausted. Key values are never logged.
- Shared LRS/LAC lock has active heartbeat updates, stale-owner cleanup, and unconditional release on finish, cancel, exception, or service exit.
- Ratings move from an old Kodi DBID to a replacement DBID before provider lookup when the logical movie/show/episode identity is unchanged.
- Migration supports path, filename, drive, and extension changes; it is not limited to MKV-to-STRM conversions.
- Ambiguous or conflicting identity pairs never migrate automatically and fall back to normal scraping.
- Complete migrated rows skip providers; partial rows continue in missing-only mode.
- Migrated and online-scraped counts are stored separately in the final summary.
- No IMDb title search, title.episode dataset, Flight 462 alias, or show-specific identity rule was added. IMDb identity still comes from Kodi.

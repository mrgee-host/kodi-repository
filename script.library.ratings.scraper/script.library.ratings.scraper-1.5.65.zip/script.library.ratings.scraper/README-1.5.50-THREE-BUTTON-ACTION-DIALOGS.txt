Library Ratings Scraper 1.5.50

- Resolver cache and CropV2 stay as single main-menu entries.
- Selecting either entry opens one AF3-style three-button dialog:
  Rebuild / Fill missing / Cancel.
- Removed the nested select menu and the second Start/Cancel confirmation.
- Rebuild is focused by default.
- Existing scrollable reports and cache-only clearlogo behavior are unchanged.

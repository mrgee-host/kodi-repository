LRS 1.5.51 - MDBList Letterboxd
================================

- Reads only the MDBList ratings[] row whose source normalizes to letterboxd.
- Uses ratings[].value as the displayed 0-5 Letterboxd value.
- Persists Letterboxd in ratings and external_ratings SQLite tables.
- Migrates existing databases without deleting other rating/award/status fields.
- Adds Letterboxd to all six Display rating slot selectors.
- Publishes Letterboxd_Rating and RatingSlot*_Source=letterboxd with letterboxd.png.
- Episodes remain IMDb/TMDb only.

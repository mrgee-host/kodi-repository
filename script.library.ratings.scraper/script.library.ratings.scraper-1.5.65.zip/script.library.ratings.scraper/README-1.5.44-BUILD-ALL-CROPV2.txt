Library Ratings Scraper 1.5.44
================================

Adds manual one-shot CropV2 cache generation for:
- Kodi movie clearlogos
- Kodi TV-show clearlogos
- Steam Library game clearlogos

Menu:
- Build missing CropV2 for all clearlogos
- Rebuild all CropV2 for all clearlogos
- View CropV2 batch report

The builder follows current TMDbHelper CropV2 behavior:
1. Filename: cropped-<md5(exact source)>.png
2. Convert to RGBa to identify non-transparent bounding box.
3. Crop to that bounding box.
4. Thumbnail to maximum 800 × 310.
5. Save PNG in TMDbHelper's configured image_location/crop_v2 directory.

Default destination:
special://profile/addon_data/plugin.video.themoviedb.helper/crop_v2

The job is manual only and never runs at Kodi startup.
Existing files are kept by Build Missing and replaced by Rebuild All.
The human-readable report is included automatically in Export diagnostics.

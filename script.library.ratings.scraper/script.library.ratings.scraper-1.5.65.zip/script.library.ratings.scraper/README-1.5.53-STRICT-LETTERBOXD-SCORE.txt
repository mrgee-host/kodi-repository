LRS 1.5.53 - Strict MDBList Letterboxd score

- Accepts Letterboxd only from MDBList ratings[] source=letterboxd.
- Uses only ratings[].score as an integer from 1 to 100.
- Ignores ratings[].value entirely.
- Does not convert old 0-5 values.
- Does not rewrite existing Letterboxd values during schema checks.
- Does not accept Kodi/alias providers for Letterboxd.
- Scrape missing detects an absent/invalid Letterboxd score and requests MDBList.

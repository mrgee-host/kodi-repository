LRS 1.5.52 - MDBList Letterboxd score
=======================================

- Reads ratings[].score for source=letterboxd.
- Example value=3.1, score=62 is displayed and stored as 62.
- Does not append a percent sign.
- Migrates v1.5.51 stored 0-5 values to 0-100 by multiplying by 20.
- Publishes Letterboxd_Rating and AF3/KPM slot label as a whole number.

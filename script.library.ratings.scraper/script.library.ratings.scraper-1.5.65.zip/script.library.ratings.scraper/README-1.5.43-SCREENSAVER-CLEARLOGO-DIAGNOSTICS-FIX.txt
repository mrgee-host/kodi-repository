LRS 1.5.43
==========

The active service loop now records the clearlogo resolver result directly
to runtime/diagnostics/screensaver-clearlogo-report.txt.

The report is included in Export diagnostics ZIP and contains title,
media type, selected result (CropV2/Kodi clearlogo/title), resolver source,
final path, CropV2 path and Kodi logo path.

Clearlogo selections are not written to kodi.log.

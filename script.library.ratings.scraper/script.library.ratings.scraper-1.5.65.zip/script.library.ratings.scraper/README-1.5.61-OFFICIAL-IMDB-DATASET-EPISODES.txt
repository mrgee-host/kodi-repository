LIBRARY RATINGS SCRAPER 1.5.61
==============================

ALUR RATING IMDb EPISODE
------------------------
1. OMDb tetap dicoba lebih dahulu dengan IMDb ID episode.
2. Bila OMDb memberi angka, hasil OMDb dipakai.
3. Bila OMDb memberi N/A/kosong, LRS mencari IMDb ID episode yang sama di
   salinan lokal dataset resmi IMDb title.ratings.tsv.gz.
4. Bila dataset berisi row tersebut, rating dan jumlah vote disimpan sebagai
   provider imdb_dataset dengan source imdb.
5. Bila dataset terbaru tidak berisi row tersebut, disimpan N/A definitif dari
   imdb_dataset.
6. Bila download/update dataset gagal, N/A OMDb tidak dianggap final agar dapat
   dicoba lagi pada Scrape Missing berikutnya.

YANG TIDAK DIGUNAKAN
--------------------
- Tidak membuka atau parsing halaman imdb.com/title/...
- Tidak memakai MDBList untuk episode.
- Tidak menyalin rating TMDb atau TVDB ke kolom IMDb.

DATABASE DAN REPORT
-------------------
- runtime database: imdb-title-ratings.db
- runtime report: runtime/reports/imdb-episode-dataset-report.csv
- report CSV ikut masuk Export diagnostics LRS.
- database dataset tidak dimasukkan ke ZIP diagnostics agar ukurannya tidak membengkak.

Dataset diperbarui maksimal sekali setiap 7 hari. Bila pembaruan gagal tetapi
salinan lama tersedia, LRS tetap memakai salinan lama dan menandainya sebagai
stale_fallback di report.

CARA MENJALANKAN
----------------
Setelah instalasi dan restart Kodi:
Library Ratings Scraper -> Scrape missing rating data

OMDb N/A lama dibuka kembali untuk pemeriksaan dataset resmi satu kali. Hasil
angka akan masuk ke ratings-cache.db melalui alur simpan normal LRS.

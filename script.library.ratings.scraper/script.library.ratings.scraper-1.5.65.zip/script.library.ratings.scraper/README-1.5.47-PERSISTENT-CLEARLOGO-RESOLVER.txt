Library Ratings Scraper 1.5.47
================================

- Adds runtime/state/clearlogo-resolver-cache.db.
- The database is built explicitly for every Kodi movie, Kodi TV show, and active Steam Library game.
- Build/update and rebuild modes are cache-only. They never download clearlogos or CropV2 files.
- Runtime uses RAM hot cache -> one SQLite row -> one file validation.
- Runtime never scans the crop_v2 directory and never uses network fallback.
- Arctic Mirage polling is 0.05 seconds only while the screensaver is active.
- A new slide immediately publishes a pending/blank logo state.
- Native/default clearlogo fallback is disabled in the LRS screensaver bridge.
- Missing/unbuilt/stale resolver rows fail closed so the previous left/right logo cannot cross panels.
- Completed no-source or missing-CropV2 rows can use the current title after identity verification.

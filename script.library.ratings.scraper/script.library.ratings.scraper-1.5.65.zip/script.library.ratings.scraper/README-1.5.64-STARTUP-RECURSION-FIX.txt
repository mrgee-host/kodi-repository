Library Ratings Scraper 1.5.64
================================

Perbaikan startup:
- Memperbaiki RecursionError pada wrapper migrasi schema v1.5.63.
- Wrapper v1.5.64 menyimpan referensi beku ke implementasi v1.5.62, sehingga tidak dapat memanggil dirinya sendiri.
- Perbaikan identity episode v1.5.63 tetap dipertahankan.
- Tidak mengubah flow dataset, provider, fallback, atau database rating.

Tidak perlu menghapus ratings-cache.db. Instal ZIP lalu restart Kodi penuh.

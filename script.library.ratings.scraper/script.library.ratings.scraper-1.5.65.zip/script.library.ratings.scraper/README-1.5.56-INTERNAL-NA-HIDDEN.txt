Library Ratings Scraper 1.5.56

- Keeps no_rating=1 / N/A as an internal database marker.
- Scrape Missing therefore does not repeatedly scrape items already confirmed unavailable.
- RatingSlot1..RatingSlot7 never publish N/A, NA, NO_RATING, NONE, or NULL.
- Empty providers simply produce no visible icon/label in AF3, KPM, Home, Hub, library, or screensaver.
- No rating database migration or rewrite is performed.

Library Ratings Scraper 1.5.57

GLOBAL RATING N/A CLOSEOUT

- Applies to IMDb, TMDb, RT Critics, RT Audience, Metacritic, Trakt, and Letterboxd.
- A definitive provider response with no rating stores N/A in SQLite and reports.
- HTTP 429, timeout, temporary connection failures, auth problems, and server errors remain blank so Scrape Missing can retry.
- N/A is treated as complete by Scrape Missing and is not requested repeatedly.
- Letterboxd N/A is no longer serialized as an empty string.
- MDBList lookup is considered definitive when a later identity succeeds even if an earlier identity/key attempt failed.
- MDBList item-not-found also closes Letterboxd as N/A.
- Episode-only unsupported fields (RT Critics, RT Audience, Metacritic, Trakt, Letterboxd) are stored as N/A without extra API requests.
- AF3/KPM continue to hide N/A slots. Database and reports show N/A.
- Existing blank movie/show rows are not blindly migrated. Run Scrape missing rating data so each blank is classified safely.

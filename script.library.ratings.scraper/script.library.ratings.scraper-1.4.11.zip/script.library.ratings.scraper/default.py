# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import xbmc
import xbmcgui
from resources.lib import core

TITLE = "Library Ratings Scraper"


def online_sources():
    keys = core.api_keys()
    online = []
    if keys.get("mdblist"):
        online.append("MDBList")
    if keys.get("tmdb"):
        online.append("TMDb")
    if keys.get("omdb"):
        online.append("OMDb")
    return online


def show_stats() -> None:
    stats = core.cache_stats(core.load_cache())
    sources = ", ".join("{0}: {1}".format(k, v) for k, v in sorted(stats.get("sources", {}).items())) or "none"
    xbmcgui.Dialog().textviewer(
        TITLE,
        "Total cache: {0}\nMovies: {1}\nTV shows: {2}\nEpisodes: {3}\nFresh cache: {4}\nItems with ratings: {5}\nIMDb Top 250: {6}\nIMDb Top 250 TV: {8}\n\nRating sources:\n{7}".format(
            stats["total"], stats["movie"], stats["tvshow"], stats["episode"], stats["fresh"], stats["with_ratings"], stats.get("imdb_top250", 0), sources, stats.get("imdb_top250_tv", 0)
        ),
    )


def queue_scrape(force: bool = False) -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if core.background_state_is_active(state):
        if dialog.yesno(TITLE, "Background job is already marked as running.\n\nCancel/reset the stuck state now?", nolabel="Back", yeslabel="Reset"):
            core.reset_background_job_state("Manual stuck-state reset")
            dialog.notification(TITLE, "Background state reset. Run the scrape again.", xbmcgui.NOTIFICATION_INFO, 5000, False)
        else:
            dialog.notification(TITLE, "Background scrape is already running", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return

    online = online_sources()
    if not online:
        if not dialog.yesno(
            TITLE,
            "No online API key was found.\n\nContinue only to copy local Kodi ratings into the cache?",
            nolabel="Cancel",
            yeslabel="Continue",
        ):
            return

    if force:
        if not dialog.yesno(
            TITLE,
            "WARNING: Refresh all data\n\nThis will re-scrape ALL selected movies, TV shows, and episodes.\nExisting cached ratings, status, awards, Top250, and RT badges may be overwritten.\nThis can take a long time and may hit API rate limits.\n\nContinue?",
            nolabel="Cancel",
            yeslabel="Refresh all",
        ):
            return
    else:
        if not dialog.yesno(
            TITLE,
            "Start scraping missing data?\n\nThis only processes missing/repairable cache data and then runs the normal awards, Top250, and RT badge phases.\n\nOnline sources: {0}".format(", ".join(online) or "none"),
            nolabel="Cancel",
            yeslabel="Start",
        ):
            return

    core.queue_background_job("scrape", force=force)
    dialog.notification(TITLE, "Background process queued", xbmcgui.NOTIFICATION_INFO, 5000, False)



def queue_awards_only() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if core.background_state_is_active(state):
        if dialog.yesno(TITLE, "Background job is already marked as running.\n\nCancel/reset the stuck state now?", nolabel="Back", yeslabel="Reset"):
            core.reset_background_job_state("Manual stuck-state reset")
            dialog.notification(TITLE, "Background state reset. Run awards scrape again.", xbmcgui.NOTIFICATION_INFO, 5000, False)
        else:
            dialog.notification(TITLE, "A background process is already running", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return
    online = online_sources()
    if not dialog.yesno(
        TITLE,
        "Start awards-only scrape?\n\nOscar/Emmy counts use OMDb. Oscar Best Picture is checked with MDBList only for Oscar-winning movies. Ratings/status/Top250 are not changed.\n\nOnline sources: {0}".format(", ".join(online) or "none"),
        nolabel="Cancel",
        yeslabel="Start",
    ):
        return
    core.queue_background_job("awards", force=False)
    dialog.notification(TITLE, "Awards-only process queued", xbmcgui.NOTIFICATION_INFO, 5000, False)



def queue_rt_badges(force: bool = False) -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if core.background_state_is_active(state):
        if dialog.yesno(TITLE, "Background job is already marked as running.\n\nCancel/reset the stuck state now?", nolabel="Back", yeslabel="Reset"):
            core.reset_background_job_state("Manual stuck-state reset")
            dialog.notification(TITLE, "Background state reset. Run RT badge scrape again.", xbmcgui.NOTIFICATION_INFO, 5000, False)
        else:
            dialog.notification(TITLE, "A background process is already running", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return
    if not dialog.yesno(TITLE, "Scrape missing Rotten Tomatoes badges only?\n\nThis does not refresh main ratings. Stable RT badge rows are skipped.", nolabel="Cancel", yeslabel="Start"):
        return
    core.queue_background_job("rtbadges", force=False)
    dialog.notification(TITLE, "RT badge scrape queued", xbmcgui.NOTIFICATION_INFO, 5000, False)


def queue_top250() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if core.background_state_is_active(state):
        if dialog.yesno(TITLE, "Background job is already marked as running.\n\nCancel/reset the stuck state now?", nolabel="Back", yeslabel="Reset"):
            core.reset_background_job_state("Manual stuck-state reset")
            dialog.notification(TITLE, "Background state reset. Run the sync again.", xbmcgui.NOTIFICATION_INFO, 5000, False)
        else:
            dialog.notification(TITLE, "A background process is already running", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return
    core.queue_background_job("top250", force=True)
    dialog.notification(TITLE, "IMDb Top 250 update queued", xbmcgui.NOTIFICATION_INFO, 5000, False)


def show_background_status() -> None:
    xbmcgui.Dialog().textviewer(TITLE, core.status_report_text_1470())


def cancel_background() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if not core.background_state_is_active(state):
        dialog.notification(TITLE, "No active background process", xbmcgui.NOTIFICATION_INFO, 4000, False)
        return
    choice = dialog.select(TITLE, [
        "Force stop running process",
        "Clear stuck background state",
        "Back",
    ])
    if choice == 0:
        core.request_background_force_stop()
        dialog.notification(TITLE, "Force stop request sent", xbmcgui.NOTIFICATION_WARNING, 5000, False)
    elif choice == 1:
        core.reset_background_job_state("Manual stuck-state reset")
        dialog.notification(TITLE, "Background state cleared", xbmcgui.NOTIFICATION_INFO, 5000, False)


def force_stop_background() -> None:
    dialog = xbmcgui.Dialog()
    if dialog.yesno(TITLE, "FORCE STOP the background process now?\n\nThis is stronger than normal cancel. The process will stop as soon as the service returns from its current request.", nolabel="No", yeslabel="Force stop"):
        core.request_background_force_stop()
        dialog.notification(TITLE, "Force stop request sent", xbmcgui.NOTIFICATION_WARNING, 5000, False)


def _enabled_media_text() -> str:
    parts = [
        "Movies={0}".format("ON" if core.bool_setting("include_movies", True) else "OFF"),
        "Series={0}".format("ON" if core.bool_setting("include_tvshows", True) else "OFF"),
        "Episodes={0}".format("ON" if core.bool_setting("include_episodes", True) else "OFF"),
    ]
    return ", ".join(parts)


def test_random_ratings() -> None:
    dialog = xbmcgui.Dialog()
    sample_size = max(1, min(25, core.int_setting("sample_check_size", 5)))
    enabled_media = _enabled_media_text()
    if not dialog.yesno(
        TITLE,
        "Check LIVE internet using the current settings?\n\nMedia: {0}\nSample: {1} item per enabled media type\n\nRatings follow the current Movies/TV shows/Episodes settings. Cache is not used as the result and is not saved.".format(enabled_media, sample_size),
        nolabel="Cancel",
        yeslabel="Start",
    ):
        return
    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Checking random ratings...")
    try:
        report = core.sample_rating_test(sample_size, progress)
    finally:
        try:
            progress.close()
        except Exception:  # pylint: disable=broad-except
            pass
    log_path = core.write_sample_rating_test_log(report)
    text = core.format_sample_rating_test_report(report)
    text += "\n\nDetailed log saved at:\n{0}".format(log_path)
    dialog.textviewer(TITLE + " - Check Random Live", text)


def export_only() -> None:
    path = core.export_csv(core.load_cache())
    xbmcgui.Dialog().ok(TITLE, "CSV report updated:\n{0}".format(path))



def export_diagnostics_zip() -> None:
    try:
        path = core.export_diagnostics_zip_1397()
        xbmcgui.Dialog().ok(TITLE, "Diagnostics ZIP created:\n{0}".format(path))
    except Exception as exc:  # pylint: disable=broad-except
        xbmcgui.Dialog().ok(TITLE, "Failed to create diagnostics ZIP:\n{0}".format(exc))


def clear_cache() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if core.background_state_is_active(state):
        dialog.ok(TITLE, "Background scrape is already running. Cancel/reset it before clearing the cache.")
        return
    if not dialog.yesno(
        TITLE,
        "Clear this rating scraper cache?\n\nTMDbHelper cache and the Kodi video database will not be touched.",
        nolabel="Cancel",
        yeslabel="Clear",
    ):
        return
    try:
        for path in (core.CACHE_FILE, getattr(core, "LEGACY_CACHE_FILE", ""), getattr(core, "LEGACY_IMDB_TOP250_CACHE_FILE", ""), core.REPORT_FILE, core.SUMMARY_FILE, core.BACKGROUND_STATE_FILE, core.BACKGROUND_REQUEST_FILE, core.BACKGROUND_CANCEL_FILE, core.BACKGROUND_FORCE_STOP_FILE):
            if os.path.exists(path):
                os.remove(path)
    except OSError as exc:
        dialog.ok(TITLE, "Failed to clear cache:\n{0}".format(exc))
        return
    dialog.ok(TITLE, "Scraper cache cleared.")


def toggle_debug_logging() -> None:
    enabled = not core.debug_enabled()
    core.set_debug_enabled(enabled)
    xbmcgui.Dialog().notification(TITLE, "Debug logging {0}".format("ON" if enabled else "OFF"), xbmcgui.NOTIFICATION_INFO, 4000, False)



def _show_dict_result(title: str, result: dict) -> None:
    lines = []
    for key, value in (result or {}).items():
        lines.append("{0}: {1}".format(key, value))
    xbmcgui.Dialog().textviewer(title, "\n".join(lines) if lines else "No result")


def maintenance_tools() -> None:
    dialog = xbmcgui.Dialog()
    actions = [
        ("Clean orphan ratings", lambda: _show_dict_result("Clean orphan ratings", core.clean_orphan_library_ratings_1460())),
        ("Clean expired external ratings", lambda: _show_dict_result("Clean expired external ratings", core.clean_expired_external_ratings_1470())),
        ("Vacuum database", lambda: _show_dict_result("Vacuum database", core.vacuum_database_1470())),
        ("Reset RT badge status", maintenance_reset_rt),
        ("Reset IMDb Top 250", maintenance_reset_top250),
        ("Repair Oscar Best Picture", maintenance_repair_oscar_bp),
        ("Reload LRS display properties", lambda: _show_dict_result("Reload LRS display properties", core.rebuild_display_properties_1470())),
        ("Provider health check", provider_health_check),
        ("Back", lambda: None),
    ]
    choice = dialog.select(TITLE + " - Maintenance tools", [label for label, _ in actions])
    if choice >= 0 and choice < len(actions):
        actions[choice][1]()


def maintenance_reset_rt() -> None:
    dialog = xbmcgui.Dialog()
    choice = dialog.select("Reset RT badge status", ["Reset repairable/error statuses only", "Reset all RT badge statuses", "Cancel"])
    if choice == 0:
        _show_dict_result("Reset RT badge status", core.reset_rt_badge_status_1470("repairable"))
    elif choice == 1:
        if dialog.yesno(TITLE, "Reset ALL RT badge status/slug rows?\n\nNext RT badge scrape will check them again.", nolabel="Cancel", yeslabel="Reset"):
            _show_dict_result("Reset RT badge status", core.reset_rt_badge_status_1470("all"))


def maintenance_reset_top250() -> None:
    if xbmcgui.Dialog().yesno(TITLE, "Reset IMDb Top 250 values in LRS cache?\n\nUse Update IMDb Top 250 only afterwards to rebuild.", nolabel="Cancel", yeslabel="Reset"):
        _show_dict_result("Reset IMDb Top 250", core.reset_imdb_top250_1470())


def maintenance_repair_oscar_bp() -> None:
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(TITLE, "Prepare Oscar Best Picture repair?\n\nOscar-winning movies with blank/non-winner BP will be marked for Scrape awards only. Movies with oscar_wins=N/A will get oscar_best_picture=N/A.", nolabel="Cancel", yeslabel="Prepare"):
        return
    result = core.repair_oscar_best_picture_1470()
    _show_dict_result("Repair Oscar Best Picture", result)
    if not result.get("error") and dialog.yesno(TITLE, "Run Scrape awards only now?", nolabel="No", yeslabel="Run"):
        queue_awards_only()


def provider_health_check() -> None:
    dialog = xbmcgui.Dialog()
    online = dialog.yesno(TITLE, "Run live provider health check?\n\nThis makes small test requests to configured providers.", nolabel="Config only", yeslabel="Live check")
    result = core.provider_health_check_1470(online=online)
    lines = []
    for row in result.get("providers") or []:
        lines.append("{0}: {1}{2}".format(row.get("provider"), row.get("status"), " - " + row.get("detail") if row.get("detail") else ""))
    if result.get("path"):
        lines.append("\nSaved: {0}".format(result.get("path")))
    dialog.textviewer(TITLE + " - Provider health", "\n".join(lines))



def af3_icon_folder_dialog() -> None:
    dialog = xbmcgui.Dialog()
    current = core.af3_icon_folder_1410() if hasattr(core, "af3_icon_folder_1410") else "LRS_AF3"
    value = dialog.input("AF3 icon folder name", current, type=xbmcgui.INPUT_ALPHANUM)
    if value is None or str(value).strip() == "":
        return
    folder = core.set_af3_icon_folder_1410(value) if hasattr(core, "set_af3_icon_folder_1410") else str(value).strip()
    result = core.af3_update_icon_folder_in_xml_1410(folder) if hasattr(core, "af3_update_icon_folder_in_xml_1410") else {"folder": folder}
    _result_dialog(
        TITLE + " - AF3 icon folder",
        [
            "AF3 icon folder updated.",
            "Folder: {0}".format(result.get("folder") or folder),
            "XML files updated: {0}".format(_format_count(result.get("files_updated", 0))),
            "Icon path references updated: {0}".format(_format_count(result.get("references_updated", 0))),
            "Root rating icon paths remaining: {0}".format(_format_count(result.get("root_references_remaining", 0))),
            "No icon folders were created and no icon files were copied.",
        ],
    )
    if dialog.yesno(TITLE, "AF3 icon folder updated. Reload skin now?", nolabel="Later", yeslabel="Reload Skin"):
        xbmc.executebuiltin("ReloadSkin()")


def af3_integration_menu() -> None:
    dialog = xbmcgui.Dialog()
    while True:
        folder = core.af3_icon_folder_1410() if hasattr(core, "af3_icon_folder_1410") else "LRS_AF3"
        actions = [
            "Apply AF3 integration patch",
            "Remove AF3 integration patch",
            "Check AF3 integration status",
            "Change AF3 icon folder ({0})".format(folder),
            "Back",
        ]
        choice = dialog.select(TITLE + " - AF3 integration", actions)
        if choice < 0 or choice == 4:
            return
        if choice == 0:
            if dialog.yesno(TITLE, "Apply AF3 integration patch?\n\nThis uses partial marker-based edits, creates XML backups, updates the selected icon folder, and does not overwrite the full XML files.", nolabel="Cancel", yeslabel="Apply"):
                result = core.run_af3_patch_tool_1470("apply")
                _result_dialog(TITLE + " - AF3 patch", [(result.get("output") or result.get("error") or "Patch completed.")])
                if result.get("ok") and dialog.yesno(TITLE, "AF3 patch completed. Reload skin now?", nolabel="Later", yeslabel="Reload Skin"):
                    xbmc.executebuiltin("ReloadSkin()")
        elif choice == 1:
            if dialog.yesno(TITLE, "Remove AF3 integration patch?\n\nThis removes the LRS patch through the bundled patch tool. XML backups remain available for emergency restore.", nolabel="Cancel", yeslabel="Remove"):
                result = core.run_af3_patch_tool_1470("remove")
                _result_dialog(TITLE + " - AF3 restore", [(result.get("output") or result.get("error") or "Restore completed.")])
                if result.get("ok") and dialog.yesno(TITLE, "AF3 integration removed. Reload skin now?", nolabel="Later", yeslabel="Reload Skin"):
                    xbmc.executebuiltin("ReloadSkin()")
        elif choice == 2:
            xbmcgui.Dialog().textviewer(TITLE + " - AF3 integration status", core.af3_integration_status_text_1470())
        elif choice == 3:
            af3_icon_folder_dialog()


def main() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    active = core.background_state_is_active(state)
    actions = [
        ("Refresh all data", lambda: queue_scrape(True)),
        ("Scrape missing data", lambda: queue_scrape(False)),
        ("Scrape missing RT badges only", lambda: queue_rt_badges(False)),
        ("Scrape awards only", queue_awards_only),
        ("Update IMDb Top 250 only", queue_top250),
        ("Maintenance tools", maintenance_tools),
        ("AF3 integration", af3_integration_menu),
    ]
    if active:
        actions.append(("Cancel/reset background process", cancel_background))
    actions.extend([
        ("View status", show_background_status),
        ("Export diagnostics ZIP", export_diagnostics_zip),
    ])
    choice = dialog.select(TITLE, [label for label, _ in actions])
    if choice >= 0:
        actions[choice][1]()


# -----------------------------------------------------------------------------
# v1.4.9 - UI wording / dialog polish RC
# -----------------------------------------------------------------------------

MAIN_MENU_TITLE = TITLE
PROVIDER_STATUS_TITLE = TITLE + " - Provider Status"


def _rel_diagnostics_path(path: str) -> str:
    try:
        text = str(path or "")
        base = str(getattr(core, "PROFILE", "") or "")
        if base and text.lower().startswith(base.lower()):
            rel = os.path.relpath(text, base).replace("\\", "\\")
            return rel
        return os.path.basename(text) or text
    except Exception:
        return str(path or "")


def _format_count(value) -> str:
    try:
        return "{:,}".format(int(value or 0))
    except Exception:
        return str(value or "0")


def _format_item_titles(value, limit: int = 8) -> str:
    items = value or []
    if isinstance(items, dict):
        items = list(items.values())
    if not isinstance(items, (list, tuple)):
        return str(items or "")
    names = []
    for item in items:
        if isinstance(item, dict):
            name = item.get("title") or item.get("label") or item.get("name") or item.get("item_key") or ""
        else:
            name = str(item or "")
        name = name.strip()
        if name:
            names.append(name)
        if len(names) >= limit:
            break
    if not names:
        return ""
    suffix = "" if len(items) <= limit else ", and {0} more".format(len(items)-limit)
    return ", ".join(names) + suffix


def _result_dialog(title: str, lines) -> None:
    text = "\n".join([str(x) for x in lines if str(x).strip()]) or "Done."
    xbmcgui.Dialog().ok(title, text)


def _show_dict_result(title: str, result: dict) -> None:
    result = result or {}
    pretty = []
    error = str(result.get("error") or "").strip()
    if error:
        _result_dialog(title, ["Status: Failed", "Error: {0}".format(error)])
        return
    lower = title.lower()
    if "orphan" in lower or "removed library" in lower:
        pretty = [
            "Removed items: {0}".format(_format_count(result.get("removed"))),
            "Items kept: {0}".format(_format_count(result.get("kept"))),
            "Items checked: {0}".format(_format_count(result.get("checked"))),
        ]
        current = result.get("current") or {}
        if isinstance(current, dict):
            pretty.extend(["", "Current library:", "Movies: {0}".format(_format_count(current.get("movie"))), "TV shows: {0}".format(_format_count(current.get("tvshow"))), "Episodes: {0}".format(_format_count(current.get("episode")))])
        titles = _format_item_titles(result.get("removed_items"))
        if titles:
            pretty.extend(["", "Removed:", titles])
    elif "expired external" in lower:
        pretty = [
            "Removed items: {0}".format(_format_count(result.get("removed"))),
            "Expiration window: {0} days".format(_format_count(result.get("ttl_days"))),
        ]
        titles = _format_item_titles(result.get("removed_items"))
        if titles:
            pretty.extend(["", "Removed:", titles])
    elif "database" in lower or "vacuum" in lower:
        before = int(result.get("before_bytes") or 0)
        after = int(result.get("after_bytes") or 0)
        saved = max(0, before-after)
        pretty = ["Database optimized successfully.", "Before: {0}".format(_human_size(before)), "After: {0}".format(_human_size(after)), "Freed: {0}".format(_human_size(saved))]
    elif "top 250" in lower:
        pretty = ["IMDb Top 250 data cleared.", "Updated items: {0}".format(_format_count(result.get("updated")))]
    elif "rt badge" in lower or "rotten tomatoes" in lower:
        pretty = ["Rotten Tomatoes badge status reset.", "Updated items: {0}".format(_format_count(result.get("updated"))), "Mode: {0}".format(result.get("mode") or "-")]
    elif "oscar" in lower:
        pretty = ["Oscar Best Picture data prepared for repair.", "Movies queued for Best Picture lookup: {0}".format(_format_count(result.get("bp_blank_for_lookup"))), "Movies marked not applicable: {0}".format(_format_count(result.get("bp_na_from_no_oscar")))]
    elif "display properties" in lower:
        pretty = ["Display properties refreshed.", "Focus an item again, or reload the skin, to republish the on-screen LRS values."]
    else:
        for key, value in result.items():
            if key.startswith("_") or value in (None, "", [], {}):
                continue
            label = str(key).replace("_", " ").strip().title()
            pretty.append("{0}: {1}".format(label, value))
    _result_dialog(title, pretty)


def _human_size(num: int) -> str:
    try:
        value = float(num or 0)
        for unit in ("B", "KB", "MB", "GB"):
            if value < 1024 or unit == "GB":
                if unit == "B":
                    return "{0} {1}".format(int(value), unit)
                return "{0:.1f} {1}".format(value, unit)
            value /= 1024.0
    except Exception:
        pass
    return str(num or 0)


def _active_job_warning(dialog, action_label: str) -> bool:
    state = core.background_job_state()
    if not core.background_state_is_active(state):
        return False
    if dialog.yesno(TITLE, "A background process is already marked as running.\n\nYou can reset the stuck state if the previous process was interrupted.", nolabel="Back", yeslabel="Reset state"):
        core.reset_background_job_state("Manual stuck-state reset")
        dialog.notification(TITLE, "Background state reset. Start {0} again.".format(action_label), xbmcgui.NOTIFICATION_INFO, 5000, False)
    else:
        dialog.notification(TITLE, "Background process is already running", xbmcgui.NOTIFICATION_INFO, 5000, False)
    return True


def queue_scrape(force: bool = False) -> None:
    dialog = xbmcgui.Dialog()
    if _active_job_warning(dialog, "Refresh all data" if force else "Scrape missing data"):
        return
    online = online_sources()
    if not online:
        if not dialog.yesno(TITLE, "No online API key was found.\n\nLRS can only copy local Kodi ratings into the cache. Continue?", nolabel="Cancel", yeslabel="Continue"):
            return
    if force:
        if not dialog.yesno(
            TITLE,
            "Refresh all library data?\n\nThis will re-scrape every selected movie, TV show, and episode. Existing ratings, awards, Top 250 data, and Rotten Tomatoes badge data may be overwritten.\n\nThis can take a long time and may use many API requests.",
            nolabel="Cancel",
            yeslabel="Refresh all",
        ):
            return
    else:
        if not dialog.yesno(
            TITLE,
            "Scrape missing library data?\n\nLRS will process missing or repairable ratings, awards, IMDb Top 250 data, and Rotten Tomatoes badges. Completed rows are skipped.\n\nOnline sources: {0}".format(", ".join(online) or "None"),
            nolabel="Cancel",
            yeslabel="Start",
        ):
            return
    core.queue_background_job("scrape", force=force)
    dialog.notification(TITLE, "Process queued", xbmcgui.NOTIFICATION_INFO, 3500, False)


def queue_awards_only() -> None:
    dialog = xbmcgui.Dialog()
    if _active_job_warning(dialog, "Scrape awards only"):
        return
    online = online_sources()
    if not dialog.yesno(
        TITLE,
        "Scrape awards only?\n\nOscar and Emmy counts are checked with OMDb. Oscar Best Picture is checked with MDBList for Oscar-winning movies only. Ratings and Top 250 data are not changed.\n\nOnline sources: {0}".format(", ".join(online) or "None"),
        nolabel="Cancel",
        yeslabel="Start",
    ):
        return
    core.queue_background_job("awards", force=False)
    dialog.notification(TITLE, "Awards process queued", xbmcgui.NOTIFICATION_INFO, 3500, False)


def queue_rt_badges(force: bool = False) -> None:
    dialog = xbmcgui.Dialog()
    if _active_job_warning(dialog, "Scrape missing Rotten Tomatoes badges"):
        return
    if not dialog.yesno(TITLE, "Scrape missing Rotten Tomatoes badges?\n\nOnly missing or repairable badge rows are processed. Main ratings are not refreshed.", nolabel="Cancel", yeslabel="Start"):
        return
    core.queue_background_job("rtbadges", force=False)
    dialog.notification(TITLE, "RT badge process queued", xbmcgui.NOTIFICATION_INFO, 3500, False)


def queue_top250() -> None:
    dialog = xbmcgui.Dialog()
    if _active_job_warning(dialog, "Update IMDb Top 250"):
        return
    if not dialog.yesno(
        TITLE,
        "Update IMDb Top 250?\n\nLRS will rebuild movie and TV show Top 250 ranks from the latest IMDb chart pages.\n\nExisting ranks are only replaced after both charts are downloaded and validated. Ratings and awards are not refreshed.",
        nolabel="Cancel",
        yeslabel="Update",
    ):
        return
    core.queue_background_job("top250", force=True)
    dialog.notification(TITLE, "IMDb Top 250 update queued", xbmcgui.NOTIFICATION_INFO, 3500, False)


def export_diagnostics_zip() -> None:
    try:
        path = core.export_diagnostics_zip_1397()
        _result_dialog("Export diagnostics", ["Diagnostics package created.", "Saved to:", _rel_diagnostics_path(path)])
    except Exception as exc:  # pylint: disable=broad-except
        _result_dialog("Export diagnostics", ["Status: Failed", "Error: {0}".format(exc)])


def maintenance_reset_rt() -> None:
    dialog = xbmcgui.Dialog()
    choice = dialog.select("Reset Rotten Tomatoes badge status", ["Reset repairable/error statuses only", "Reset all Rotten Tomatoes badge statuses", "Back"])
    if choice == 0:
        _show_dict_result("Reset Rotten Tomatoes badge status", core.reset_rt_badge_status_1470("repairable"))
    elif choice == 1:
        if dialog.yesno(TITLE, "Reset all Rotten Tomatoes badge statuses?\n\nEvery movie and TV show badge row will be checked again the next time RT badges are scraped.", nolabel="Cancel", yeslabel="Reset"):
            _show_dict_result("Reset Rotten Tomatoes badge status", core.reset_rt_badge_status_1470("all"))


def maintenance_reset_top250() -> None:
    if xbmcgui.Dialog().yesno(TITLE, "Clear IMDb Top 250 data?\n\nExisting Top 250 ranks will be removed from the LRS cache. Use Update IMDb Top 250 afterwards to rebuild them.", nolabel="Cancel", yeslabel="Clear"):
        _show_dict_result("Clear IMDb Top 250 data", core.reset_imdb_top250_1470())


def maintenance_repair_oscar_bp() -> None:
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(TITLE, "Repair Oscar Best Picture data?\n\nOscar-winning movies that need Best Picture verification will be prepared for the next awards scrape. Movies without Oscar wins will be marked not applicable.", nolabel="Cancel", yeslabel="Prepare"):
        return
    result = core.repair_oscar_best_picture_1470()
    _show_dict_result("Repair Oscar Best Picture data", result)
    if not result.get("error") and dialog.yesno(TITLE, "Run Scrape awards only now?", nolabel="No", yeslabel="Run"):
        queue_awards_only()


def provider_health_check() -> None:
    dialog = xbmcgui.Dialog()
    online = dialog.yesno(TITLE, "Check provider status?\n\nLive check makes small test requests to configured providers. Config-only only checks available settings and local sources.", nolabel="Config only", yeslabel="Live check")
    result = core.provider_health_check_1470(online=online)
    lines = []
    status_names = {"OK": "Available", "CONFIGURED": "Configured", "MISSING": "Missing", "LIMITED": "Limited", "ERROR": "Error", "UNKNOWN": "Unknown", "EMPTY": "Empty"}
    for row in result.get("providers") or []:
        provider = row.get("provider") or "Provider"
        status = status_names.get(str(row.get("status") or "").upper(), row.get("status") or "Unknown")
        detail = row.get("detail") or ""
        if provider == "TMDb" and detail and "shawk" in detail.lower():
            detail = ""
        if provider == "IMDb Top 250":
            detail = detail.replace("movie=", "Movies: ").replace(", tv=", ", TV Shows: ")
        lines.append("{0}: {1}{2}".format(provider, status, " ({0})".format(detail) if detail else ""))
    if result.get("path"):
        lines.extend(["", "Report saved to:", _rel_diagnostics_path(result.get("path"))])
    _result_dialog(PROVIDER_STATUS_TITLE, lines)


def maintenance_tools() -> None:
    dialog = xbmcgui.Dialog()
    while True:
        actions = [
            ("Clean removed library items", lambda: _show_dict_result("Clean removed library items", core.clean_orphan_library_ratings_1460())),
            ("Clean expired external cache", lambda: _show_dict_result("Clean expired external cache", core.clean_expired_external_ratings_1470())),
            ("Optimize database", lambda: _show_dict_result("Optimize database", core.vacuum_database_1470())),
            ("Reset Rotten Tomatoes badge status", maintenance_reset_rt),
            ("Repair Oscar Best Picture data", maintenance_repair_oscar_bp),
            ("Reload LRS display properties", lambda: _show_dict_result("Reload LRS display properties", core.rebuild_display_properties_1470())),
            ("Check provider status", provider_health_check),
            ("Back", None),
        ]
        choice = dialog.select(TITLE + " - Maintenance", [label for label, _ in actions])
        if choice < 0 or choice >= len(actions) or actions[choice][1] is None:
            return
        actions[choice][1]()


def af3_integration_menu() -> None:
    dialog = xbmcgui.Dialog()
    while True:
        actions = ["Apply AF3 integration patch", "Remove AF3 integration patch", "Check AF3 integration status", "Back"]
        choice = dialog.select(TITLE + " - AF3 integration", actions)
        if choice < 0 or choice == 3:
            return
        if choice == 0:
            if dialog.yesno(TITLE, "Apply AF3 integration patch?\n\nThis uses partial marker-based edits, creates XML backups, and does not overwrite the full XML files.", nolabel="Cancel", yeslabel="Apply"):
                result = core.run_af3_patch_tool_1470("apply")
                _result_dialog(TITLE + " - AF3 patch", [(result.get("output") or result.get("error") or "Patch completed.")])
                if result.get("ok") and dialog.yesno(TITLE, "AF3 patch completed. Reload skin now?", nolabel="Later", yeslabel="Reload Skin"):
                    xbmc.executebuiltin("ReloadSkin()")
        elif choice == 1:
            if dialog.yesno(TITLE, "Remove AF3 integration patch?\n\nThis removes the LRS patch through the bundled patch tool. XML backups remain available for emergency restore.", nolabel="Cancel", yeslabel="Remove"):
                result = core.run_af3_patch_tool_1470("remove")
                _result_dialog(TITLE + " - AF3 restore", [(result.get("output") or result.get("error") or "Restore completed.")])
                if result.get("ok") and dialog.yesno(TITLE, "AF3 integration removed. Reload skin now?", nolabel="Later", yeslabel="Reload Skin"):
                    xbmc.executebuiltin("ReloadSkin()")
        elif choice == 2:
            xbmcgui.Dialog().textviewer(TITLE + " - AF3 integration status", core.af3_integration_status_text_1470())


def main() -> None:
    dialog = xbmcgui.Dialog()
    while True:
        state = core.background_job_state()
        active = core.background_state_is_active(state)
        actions = [
            ("Refresh all data", lambda: queue_scrape(True)),
            ("Scrape missing data", lambda: queue_scrape(False)),
            ("Scrape missing Rotten Tomatoes badges", lambda: queue_rt_badges(False)),
            ("Scrape awards only", queue_awards_only),
            ("Update IMDb Top 250", queue_top250),
            ("Maintenance tools", maintenance_tools),
            ("AF3 integration", af3_integration_menu),
        ]
        if active:
            actions.append(("Cancel/reset background process", cancel_background))
        actions.extend([
            ("View status", show_background_status),
            ("Export diagnostics", export_diagnostics_zip),
        ])
        choice = dialog.select(MAIN_MENU_TITLE, [label for label, _ in actions])
        if choice < 0:
            return
        actions[choice][1]()
        # Long-running scrape actions only queue work; keep the addon flow clean and exit.
        if choice in (0, 1, 2, 3, 4) or (active and choice == 7):
            return



# -----------------------------------------------------------------------------
# v1.4.10 - final AF3 menu override with configurable icon folder
# -----------------------------------------------------------------------------

def af3_icon_folder_dialog() -> None:
    dialog = xbmcgui.Dialog()
    current = core.af3_icon_folder_1410() if hasattr(core, "af3_icon_folder_1410") else "LRS_AF3"
    value = dialog.input("AF3 icon folder name", current, type=xbmcgui.INPUT_ALPHANUM)
    if value is None or str(value).strip() == "":
        return
    folder = core.set_af3_icon_folder_1410(value) if hasattr(core, "set_af3_icon_folder_1410") else str(value).strip()
    result = core.af3_update_icon_folder_in_xml_1410(folder) if hasattr(core, "af3_update_icon_folder_in_xml_1410") else {"folder": folder}
    _result_dialog(
        TITLE + " - AF3 icon folder",
        [
            "AF3 icon folder updated.",
            "Folder: {0}".format(result.get("folder") or folder),
            "XML files updated: {0}".format(_format_count(result.get("files_updated", 0))),
            "Icon path references updated: {0}".format(_format_count(result.get("references_updated", 0))),
            "Root rating icon paths remaining: {0}".format(_format_count(result.get("root_references_remaining", 0))),
            "No icon folders were created and no icon files were copied.",
        ],
    )
    if dialog.yesno(TITLE, "AF3 icon folder updated. Reload skin now?", nolabel="Later", yeslabel="Reload Skin"):
        xbmc.executebuiltin("ReloadSkin()")


def af3_integration_menu() -> None:
    dialog = xbmcgui.Dialog()
    while True:
        folder = core.af3_icon_folder_1410() if hasattr(core, "af3_icon_folder_1410") else "LRS_AF3"
        actions = [
            "Apply AF3 integration patch",
            "Remove AF3 integration patch",
            "Check AF3 integration status",
            "Change AF3 icon folder ({0})".format(folder),
            "Back",
        ]
        choice = dialog.select(TITLE + " - AF3 integration", actions)
        if choice < 0 or choice == 4:
            return
        if choice == 0:
            if dialog.yesno(TITLE, "Apply AF3 integration patch?\n\nThis uses partial marker-based edits, creates XML backups, updates the selected icon folder, and does not overwrite the full XML files.", nolabel="Cancel", yeslabel="Apply"):
                result = core.run_af3_patch_tool_1470("apply")
                _result_dialog(TITLE + " - AF3 patch", [(result.get("output") or result.get("error") or "Patch completed.")])
                if result.get("ok") and dialog.yesno(TITLE, "AF3 patch completed. Reload skin now?", nolabel="Later", yeslabel="Reload Skin"):
                    xbmc.executebuiltin("ReloadSkin()")
        elif choice == 1:
            if dialog.yesno(TITLE, "Remove AF3 integration patch?\n\nThis removes the LRS patch through the bundled patch tool. XML backups remain available for emergency restore.", nolabel="Cancel", yeslabel="Remove"):
                result = core.run_af3_patch_tool_1470("remove")
                _result_dialog(TITLE + " - AF3 restore", [(result.get("output") or result.get("error") or "Restore completed.")])
                if result.get("ok") and dialog.yesno(TITLE, "AF3 integration removed. Reload skin now?", nolabel="Later", yeslabel="Reload Skin"):
                    xbmc.executebuiltin("ReloadSkin()")
        elif choice == 2:
            xbmcgui.Dialog().textviewer(TITLE + " - AF3 integration status", core.af3_integration_status_text_1470())
        elif choice == 3:
            af3_icon_folder_dialog()

if __name__ == "__main__":
    main()

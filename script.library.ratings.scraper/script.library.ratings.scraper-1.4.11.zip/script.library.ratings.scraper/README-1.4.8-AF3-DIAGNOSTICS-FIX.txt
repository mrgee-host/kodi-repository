Library Ratings Scraper 1.4.8 - AF3 diagnostics/status fix

- Fix AF3 integration status checker markers for Includes_Hubs and screensaver.
- Patch screensaver Oscar Best Picture using normal ratings icon path under ratings/LRS_AF3/.
- Prepare media/flags/<color>/ratings/LRS_AF3 folders and copy oscars.png/oscars_bp.png there when available.
- Offer Reload Skin after AF3 patch/remove from Kodi menu.
- Export AF3 XML files inside diagnostics ZIP.
- Improve upcoming/future external widget guard using release/status fields when available.
- Keep 1.4.7 maintenance/pre-1.5 behavior.

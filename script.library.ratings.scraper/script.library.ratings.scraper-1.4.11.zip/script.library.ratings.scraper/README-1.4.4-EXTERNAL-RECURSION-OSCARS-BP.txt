Library Ratings Scraper 1.4.4

Fixes:
- Fixes service RecursionError introduced by external_ratings focus cache in 1.4.3.
- Renames Best Picture icon property value from oscar_bp.png to oscars_bp.png.
- Keeps external_ratings schema matching ratings schema.
- Keeps OMDb awards count + MDBList Oscar Best Picture side-check policy.

AF3 XML note:
Existing r8 dynamic property patch remains functionally valid because the XML reads the property.
Use r9 patch/status pack for updated oscars_bp.png filename checks.

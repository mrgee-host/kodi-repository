# -*- coding: utf-8 -*-
from __future__ import annotations

import xbmc
import xbmcgui

from resources.lib import core

TITLE = "Library Ratings Scraper"


def _context_item():
    # Context menu normally exposes ListItem.* for the selected row/card.
    for getter in (core.selected_library_item, core.hub_focus_container_item, core.lrs_active_item, core.tmdbhelper_item):
        try:
            item = getter()
        except Exception:  # pylint: disable=broad-except
            item = {}
        if core.valid_library_item(item):
            return item
    return {}


def refresh_selected_item():
    dialog = xbmcgui.Dialog()
    item = _context_item()
    if not core.valid_library_item(item):
        dialog.notification(TITLE, "No movie / TV show / episode identity found", xbmcgui.NOTIFICATION_WARNING, 5000, False)
        return

    media_type = item.get("type") or "item"
    title = item.get("title") or item.get("showtitle") or "Selected item"
    if item.get("type") == "episode":
        title = "{0} S{1:02d}E{2:02d} - {3}".format(
            item.get("showtitle") or "Series",
            core.safe_int(item.get("season")) or 0,
            core.safe_int(item.get("episode")) or 0,
            item.get("title") or "Episode",
        )

    if not dialog.yesno(TITLE, "Refresh ratings data for selected item:\n\n\n{0}\n\nThis force-refreshes all LRS data for this selected item.".format(title), nolabel="Cancel", yeslabel="Refresh"):
        return

    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "0/1 ratings - {0}".format(title[:60]))
    try:
        cache = core.load_cache()
        existing = core.cache_record(cache, item) or {}
        progress.update(20, "1/1 ratings - {0}".format(title[:60]))
        refreshed = core.resolve_item(item, core.api_keys(), existing, missing_only=False, include_local=False, ratings_only=False)
        if core.media_setting_type(item.get("type")) in ("movie", "tvshow"):
            progress.update(45, "1/1 awards - {0}".format(title[:60]))
            refreshed = core.resolve_awards_only(item, core.api_keys(), refreshed)
            progress.update(65, "1/1 rt badges - {0}".format(title[:60]))
            refreshed = core.resolve_rt_badge_only(item, core.api_keys(), refreshed, force=True)
        key = core.item_key(refreshed)
        if not key or key.endswith("|"):
            key = core.item_key(item)
        cache.setdefault("items", {})[key] = refreshed
        progress.update(80, "Saving cache...")
        core.save_cache(cache)
        values = core.af3_values(refreshed)
        values["SourceContext"] = "context"
        core.publish_af3_properties(values, key, core.bool_setting("publish_af3_cache", True))
        progress.update(100, "Done")
        dialog.notification(TITLE, "Selected item ratings data refreshed", xbmcgui.NOTIFICATION_INFO, 5000, False)
    except core.ProviderLimitReached as exc:
        dialog.ok(TITLE, "API limit reached:\n{0}".format(exc))
    except Exception as exc:  # pylint: disable=broad-except
        core.log("Context refresh failed: {0}".format(exc), xbmc.LOGERROR)
        dialog.ok(TITLE, "Refresh failed:\n{0}".format(exc))
    finally:
        try:
            progress.close()
        except Exception:  # pylint: disable=broad-except
            pass


if __name__ == "__main__":
    refresh_selected_item()

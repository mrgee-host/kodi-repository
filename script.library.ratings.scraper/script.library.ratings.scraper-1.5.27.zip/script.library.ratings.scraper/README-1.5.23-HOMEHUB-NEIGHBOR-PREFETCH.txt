LRS 1.5.23 - Home/Hub neighbor prefetch

- Adds AF3 Home/Hub neighbor prefetch for the focused widget container.
- Reads current, previous, and next widget items from the active AF3 container.
- Prefetch is cache-only; it does not trigger online scraping while moving focus.
- Cached neighbor records are kept in memory so moving left/right can publish immediately.
- For AF3 cached hits, publish directly without first clearing the visible LRS row, reducing the blank/flicker gap.
- Keeps game Home/Hub behavior unchanged; games are still handled by MediaHub/Steam direct ListItem properties.
- Keeps POLL_SECONDS at 0.10.

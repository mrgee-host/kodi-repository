LRS 1.5.24 - AF3 Visual Fast Poll Fix

- Fixes Home/Hub neighbor prefetch delay by adding af3_visual to the fast 0.10s service wait path.
- 1.5.23 prefetch was reading neighbors and cache hits, but af3_visual could still fall through to POLL_MID_SECONDS = 1.00.
- Keeps POLL_SECONDS = 0.10.
- Keeps Home/Hub neighbor prefetch from 1.5.23.
- Keeps Ends-at as a fixed LRS property slot at the end of the row from 1.5.22.
- Does not change game passthrough behavior.

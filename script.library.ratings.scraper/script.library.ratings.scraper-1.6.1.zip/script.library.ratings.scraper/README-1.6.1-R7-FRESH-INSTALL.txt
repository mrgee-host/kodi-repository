Library Ratings Scraper 1.6.1 - R7 Fresh-Install Baseline

- Creates metadata, ratings, and external_ratings directly in the final schema.
- Rejects unsupported or extra-column schemas; no JSON import, schema rewrite,
  0-5 Letterboxd reinterpretation, title repair, or untyped numeric-ID guessing.
- Keeps exact scan DBID delta, DBID-reuse validation, active DBID handoff,
  current provider fallbacks, IMDb dataset batching, diagnostics, and atomic writes.
- Uses the new Library Ratings Scraper icon supplied for the MrGee family.

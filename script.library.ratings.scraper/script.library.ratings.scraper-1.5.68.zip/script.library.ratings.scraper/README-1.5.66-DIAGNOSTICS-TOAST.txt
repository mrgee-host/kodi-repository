Library Ratings Scraper 1.5.66

- Export diagnostics ZIP no longer opens a modal text viewer.
- A compact notification shows only the generated ZIP filename.
- ZIP contents and API-key redaction are unchanged.

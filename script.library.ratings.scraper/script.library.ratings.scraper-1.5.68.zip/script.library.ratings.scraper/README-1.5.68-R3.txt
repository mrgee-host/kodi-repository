LRS 1.5.68
- RT badge scraping is movie-only.
- Resolver/CropV2 UI is delegated to KPM; LRS remains the callable engine.
- Clearlogo resolver database/report live under KPM runtime.
- Notification maximum remains 58 characters.

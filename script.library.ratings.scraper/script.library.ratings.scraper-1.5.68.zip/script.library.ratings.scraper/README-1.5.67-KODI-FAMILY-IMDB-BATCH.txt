LRS 1.5.67
- IMDb dataset DB moved to cache/imdb/.
- Dataset generation state moved to runtime/state/.
- Definitive dataset misses and missing IMDb IDs become N/A in one local batch.
- No per-item technical reason is persisted.
- Missing-only no longer waits 1.1 seconds per closed IMDb row.
- Progress body is uppercase, episode-prefix-safe, and limited to 58 characters.
- Short reports use a normal dialog; long reports use a scrollable viewer.

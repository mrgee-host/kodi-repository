v1.5.26: Home/Hub DisplaySlot fixes.

- Freezes the unified HomeHub DisplaySlot when AF3 focus moves to menu/buttons/non-media controls, so the visible row is not partially overwritten.
- Rejects raw Kodi infolabel strings such as Container(...).ListItem.FinishTime from EndsAt labels.
- Adds a duration-based EndsAt fallback for library contexts when Kodi FinishTime/EndTimeResume is unavailable but duration is available.
- Hard-disables legacy direct game meta row objects in AF3 integration so game rows do not merge with stale movie DisplaySlot rows.
- Keeps 1.5.23 neighbor prefetch, 1.5.24 af3_visual fast poll, and 1.5.25 unified DisplaySlot behavior.

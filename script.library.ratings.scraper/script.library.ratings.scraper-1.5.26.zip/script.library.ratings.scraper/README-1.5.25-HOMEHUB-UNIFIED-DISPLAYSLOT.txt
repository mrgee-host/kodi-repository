LRS 1.5.25
- Adds Home/Hub unified DisplaySlot row for movie + game rating metadata.
- Home/Hub row is kept stable: no hard clear on movie <-> game transitions.
- Movie/TV and MediaHub/Steam game values mirror to LibraryRatings.HomeHub.DisplaySlotN_*.
- The AF3 integration patch adds DisplaySlot objects inside LRS_Info_Meta_Ratings and guards direct game metadata row to avoid duplicates.
- Existing neighbor prefetch and AF3 visual fast polling remain.

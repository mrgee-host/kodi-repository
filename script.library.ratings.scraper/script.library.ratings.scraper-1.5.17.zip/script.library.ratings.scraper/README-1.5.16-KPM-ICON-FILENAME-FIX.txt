v1.5.16 KPM icon filename compatibility fix

- Verified Hot now maps to verified.png, matching the KPM shared-icons set.
- Only verified.png is emitted as a texture filename.
- Only oscars.png and oscars_bp.png are emitted.
- AF3/LRS patch fallback no longer intentionally copies icons into skin media/flags ratings folders. KPM shared-icons remains the canonical icon location.

Library Ratings Scraper 1.3.69 - Top250 chart unavailable guard

Fixes 1.3.68 behavior where an empty/unavailable IMDb movie Top250 chart caused every movie to be marked N/A.

Movie Top250 behavior:
- Full IMDb movie Top250 chart available (>=200 ids): matched movies get rank; non-members get N/A.
- Chart unavailable/blocked/parse empty: existing values are preserved and NULL stays NULL so it can be retried later.
- Kodi's built-in movie top250 value is still preserved when present.
- TV Top250 behavior is unchanged (bundled local Top250 TV DB).
- Adds missing _ensure_cache_entry helper used by the dedicated Top250 sync path.
- Does not change rating provider flow.

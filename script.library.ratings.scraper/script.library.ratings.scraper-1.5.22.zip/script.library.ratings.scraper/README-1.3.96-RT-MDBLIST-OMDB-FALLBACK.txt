Library Ratings Scraper 1.3.96 - RT MDBList Null -> OMDb Fallback

Base: 1.3.95 RT Search / N-A Fix.

What changed:
- Movie/TV rating phase still uses MDBList as the primary ratings source.
- If MDBList returns tomatoes/RT critics as null or missing, LRS now calls OMDb once and merges only the Rotten Tomatoes critics rating.
- RT audience/popcorn remains MDBList-only because OMDb does not provide audience/popcorn.
- OMDb fallback does not overwrite MDBList IMDb, TMDb, Metacritic, Trakt, Letterboxd, or MDBList rows.
- RT 0% remains valid and must be stored as 0, not N/A. This is important for titles like Police Academy 4/5/6.
- Stable 1.3.95 RT badge behavior is unchanged: normal RT sync skips ok/badge_not_found/N/A, Refresh RT badges can force recheck, and badge search/slug repair remains media-type safe.

Expected effect:
- Moana / Moana 2 style MDBList tomatoes=null cases can recover RT critics from OMDb.
- Police Academy 0% cases can be written as 0 when OMDb exposes the Rotten Tomatoes rating.

Notes:
- If OMDb also has no Rotten Tomatoes critics entry, LRS will still mark RT critics as N/A.
- To repair existing N/A rows, clear the affected RT critics cells/rows or run a refresh path that treats those rows as missing.

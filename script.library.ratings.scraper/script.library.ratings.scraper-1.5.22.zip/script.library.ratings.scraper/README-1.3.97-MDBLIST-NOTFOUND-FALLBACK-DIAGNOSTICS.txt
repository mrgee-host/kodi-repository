Library Ratings Scraper 1.3.97 - MDBList Not Found Fallback + Diagnostics

Changes:
- Keeps 1.3.95 RT badge/search stable base.
- Fixes the 1.3.96 fallback placement by installing the provider recovery flow in the active resolve_item.
- MDBList remains primary for movie/show ratings.
- If MDBList returns tomatoes/null while the item exists, OMDb falls back for RT critics only.
- If MDBList returns Item not found, OMDb falls back for IMDb rating, Rotten Tomatoes critics, and Metacritic; TMDb falls back for TMDb rating.
- RT audience/popcorn and Trakt have no fallback; after a cacheable MDBList Item not found they are marked N/A.
- Provider limit/network/temporary failure leaves fields blank for retry; it does not mark N/A.
- RT 0% remains valid for rt_critic and rt_audience.
- IMDb/TMDb/Metacritic/Trakt zero is treated as N/A.
- Adds Export diagnostics ZIP menu item, collecting kodi.log/kodi.old.log plus profile DB/CSV/JSON/log reports.
- Background progress text is unified as: current/total phase - title.

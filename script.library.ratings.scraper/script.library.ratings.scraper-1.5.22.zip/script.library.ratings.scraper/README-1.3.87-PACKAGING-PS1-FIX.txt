Library Ratings Scraper 1.3.87

Fix from 1.3.86:
- addon.xml XML declaration fixed to version=1.0.
- addon version fixed to 1.3.87.
- PowerShell patcher Check-Status parser error fixed.
- AF3 true-spacing/screensaver/hub bridge logic preserved from 1.3.86.

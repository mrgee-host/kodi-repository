Library Ratings Scraper 1.3.81

- Settings cleaned: API keys, Media, Display, Debug only.
- Removed rating provider checkboxes, Awards/Extras settings, Legacy TMDbHelper publish setting.
- Scrape always gathers needed data: MDBList movie/series ratings+awards, TMDb series status, local Top 250, OMDb/TMDb episodes.
- Rating count is true numeric 1-6; Rating 1-6 comboboxes remain.
- Slot icons publish filename only; XML builds flags/$VAR path so icons render correctly.
- TMDbHelper legacy namespace publish is forced OFF.

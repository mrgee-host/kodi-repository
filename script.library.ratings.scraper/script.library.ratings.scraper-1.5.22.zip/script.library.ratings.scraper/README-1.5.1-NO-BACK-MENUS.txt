Library Ratings Scraper 1.5.1 - No Back Menu Cleanup

Base: 1.5.0 stable title-first progress + updated icon.

Changes:
- Removed separate "Back" items from run/select menus.
- Menus now close/return using Kodi's normal cancel/back navigation instead of an extra Back row.
- Replaced leftover yes/no "Back" negative labels with "Cancel".
- No scraping, provider, database, AF3, hub/widget, keep-last, or progress logic changes.

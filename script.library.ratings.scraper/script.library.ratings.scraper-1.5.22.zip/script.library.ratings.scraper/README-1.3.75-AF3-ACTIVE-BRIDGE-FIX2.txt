Library Ratings Scraper 1.3.75

Fixes based on AF3/LRS active bridge testing:
- AF3 screensaver context now wins over stale LRS.Active hub bridge.
- Hub/library LRS.Active still wins over focused Play/Options buttons.
- Strict episode matching: episode context never falls back to parent tvshow.
- Display record quality uses all cached ratings, independent from scrape checkboxes.
- Full cached movie/tvshow ratings are published when available.
- Short settings labels to avoid overlap.
- Legacy TMDbHelper publish moved to Debug/Advanced and remains OFF by default.

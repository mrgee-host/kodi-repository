Library Ratings Scraper 1.3.88

Awards-only relevant-key fix.

Fixes a legacy marker bug where movie rows with emmy_wins=N/A but oscar_wins empty were skipped forever, and TV show rows with oscar_wins=N/A but emmy_wins empty could be skipped incorrectly.

New logic:
- movie awards are considered complete only when oscar_wins is a number or N/A.
- tvshow awards are considered complete only when emmy_wins is a number or N/A.
- the irrelevant cross-field never marks the item complete.
- existing awards_text is parsed locally first if the relevant field is still missing.
- OMDb awards fallback is allowed when MDBList is limited, missing, disabled, or fails.

No DB reset is required. Run Scrape awards only again after installing this version.

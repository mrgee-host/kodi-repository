Library Ratings Scraper 1.4.7
Pre-1.5 final stabilization build.

Adds maintenance tools, provider health check, clearer status, compact diagnostics polish, external cache cleanup/seed behavior, award cleanup, Top250/RT reset tools, schema metadata, and AF3 integration actions from Kodi.

# Library Ratings Scraper 1.2.7

## Perubahan 1.2.4

- Scrape manual seluruh library tidak lagi membuka progress dialog modal.
- Setelah memilih mode scrape, pekerjaan diserahkan kepada service background lalu menu langsung ditutup.
- Progress tampil menggunakan notifikasi progress latar belakang Kodi (`DialogProgressBG`), sehingga Kodi tetap bisa dipakai untuk membuka menu, film, atau serial lain.
- Ditambahkan menu untuk melihat status dan membatalkan scrape background.
- Sinkronisasi IMDb Top 250 manual juga dijalankan di background.
- Cache 30 hari, auto-refresh, IMDb Top 250, publikasi cache ke Arctic Fuse 3, dan preload slide Arctic Mirage tetap dipertahankan.

## Cara update

1. Install `script.library.ratings.scraper-1.2.4.zip` melalui **Settings > Add-ons > Install from zip file**.
2. Restart Kodi agar service versi baru dimuat ulang.
3. Buka **Add-ons > Program add-ons > Library Ratings Scraper**.
4. Pilih **Scrape item baru / cache kedaluwarsa (background)** atau **Refresh paksa seluruh library (background)**.

XML Arctic Mirage tidak perlu disalin ulang bila sebelumnya sudah memakai XML modifikasi dari bundle 1.2.x.


## Perubahan 1.2.5

- Progress background tetap non-blocking.
- Pesan progress dipadatkan menjadi satu baris supaya tidak terpotong pada Arctic Fuse 3.
- Format progress: `5/5797  U:5 S:0 G:0  21 BRIDGES`.


## Perubahan 1.2.6

- Progress background dipersingkat lagi.
- Notifikasi hanya menampilkan posisi item dan judul: `5/5797  21 BRIDGES`.
- Counter `U`, `S`, dan `G` tidak lagi ditampilkan pada notifikasi.
- Detail update, skip, dan gagal tetap tersedia melalui menu **Lihat status scrape background** serta laporan CSV.
- Toast selesai dipersingkat menjadi `Scrape background selesai`.


## Perubahan 1.2.7

- Judul notifikasi background dikembalikan menjadi **Library Ratings Scraper**.


## Version 1.3.1

- Adds Arctic Fuse 3 hub fallback: when the focused control is Play/More Options instead of the media item, the service can identify the cache row through TMDbHelper basic item properties.
- Adds title/year cache fallback for hub and screensaver rows that do not expose a DBID for a moment.
- Prevents title-only hub fallbacks from starting online lookups; they only publish already-scraped cache values.
- Keeps screensaver cache publishing stricter so old ratings are cleared when the current slide is known but not cached.

## v1.3.94 RT Search Repair

Adds safe Rotten Tomatoes search repair for missing/no_slug, 404 and mismatch slugs. Movie candidates use `/m/` + `release-year`; TV candidates use `/tv/` + `start-year`/`end-year`. Normal RT sync skips stable `ok` and `badge_not_found`; the new Refresh RT badges menu rechecks everything.



## 1.5.0 Stable
- Stable cleanup release based on 1.4.13 bundled IMDb Top 250 database.
- Diagnostics ZIP now redacts API keys and common API-key query parameters from text files.
- Last-run summary now includes consistent processed/checked/phase statistics.
- Top250 local sync report now clarifies checked items versus changed rows.
- RT badge diagnostics report is rebuilt from cache when the latest per-run report only contains a header.
- Default auto-scrape, debug logging, and verbose diagnostics remain OFF for stable use.

## 1.4.13

IMDb Top 250 updates now use the bundled local Top250 database again. Live IMDb web syncing was removed from the active workflow.


## 1.5.1 No Back Menu Cleanup
- Removed separate Back rows from LRS run/select menus.
- Kodi cancel/back navigation still exits menus normally.
- No scraping/provider/display logic changed.

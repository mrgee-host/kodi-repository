Library Ratings Scraper v1.5.4

Auto scan progress polish:
- Auto-new-item data phases keep combined item counters such as 1/3 TITLE - RATINGS, 2/3 TITLE - AWARDS, 3/3 TITLE - RT BADGES.
- Auto scan saving/exporting remain visible but no longer reuse the final item counter or stale phase label.
- Saving/exporting now show as AUTO SCAN steps, e.g. SAVING CACHE - AUTO SCAN and EXPORTING REPORT - AUTO SCAN.
- Manual jobs are unchanged.

Library Ratings Scraper v1.3.93
RT detail-page badge sync

What changed:
- Adds menu: Sync Rotten Tomatoes badges.
- Adds only two ratings DB columns:
  - rottentomatoes_slug
  - rottentomatoes_status
- Uses saved RT slug when available.
- If slug is missing, uses OMDb tomatoURL once and saves the slug.
- Fetches Rotten Tomatoes detail page and parses media-scorecard-json / media-scorecard section.
- Updates only image columns:
  - rottentomatoes_image: certified / fresh / rotten
  - rottentomatoes_userimage: verifiedhot / upright / spilled
- Ratings are not changed.
- Scrape Missing / Refresh All now run phases:
  ratings/status/top250 -> OMDb awards -> RT badge detail sync.

Logs:
- rtbadge-simple.log      append, never deleted
- rtbadge-detail.log      append, never deleted
- rt-badge-sync-report.csv latest run report
- rt-badge-sync-last.json latest item debug

Important:
This version does not use RT browse-list title matching. It avoids the old risk of matching a TV show to a wrong season/reboot.

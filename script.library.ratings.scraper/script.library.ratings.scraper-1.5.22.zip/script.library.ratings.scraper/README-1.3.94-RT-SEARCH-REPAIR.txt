Library Ratings Scraper v1.3.94 - RT Search Repair
==================================================

Base: v1.3.93 RT detail badge sync.

Main changes
------------
1. Normal "Sync Rotten Tomatoes badges" is now a repair/missing sync:
   - skips rows whose rottentomatoes_status is ok
   - skips rows whose rottentomatoes_status is badge_not_found
   - processes missing/no_slug, fetch errors, 404, mismatch, manual_slug and empty statuses

2. New menu item: "Refresh Rotten Tomatoes badges"
   - force mode
   - rechecks all movie/tvshow rows, including ok and badge_not_found

3. Missing slug / no_slug handling:
   - tries Rotten Tomatoes search by title and media type
   - movie candidates must be /m/ and use release-year
   - TV candidates must be /tv/ and use start-year/end-year
   - no blind "All results first item" matching
   - movie-only OMDb tomatoURL remains as fallback if RT search has no acceptable result

4. fetch_error_404 handling:
   - old slug is treated as bad
   - addon searches RT again by title/type/year
   - if repaired, new slug is saved and badge is parsed
   - if not repaired, rottentomatoes_slug is cleared and status stores the old slug:
     fetch_error_404 (/m/old_slug)

5. slug_mismatch handling:
   - if a slug fetches HTTP 200 but the page title/media type does not match the Kodi item,
     the old slug is treated as mismatch
   - addon searches RT again by title/type/year
   - if not repaired, rottentomatoes_slug is cleared and status stores the old slug:
     slug_mismatch (/m/62)

6. badge_not_found handling:
   - if the page matches the Kodi item but RT has no usable critics/audience badge,
     slug is kept and status becomes badge_not_found
   - normal sync skips it later; Refresh RT badges rechecks it

Reports written to addon_data/script.library.ratings.scraper
------------------------------------------------------------
- rt-badge-sync-report.csv        main report for latest run
- no_slug.csv                     RT search could not find an acceptable slug
- bad_slug_404.csv                old slug was 404 and could not be repaired
- bad_slug_mismatch.csv           old slug opened but belonged to a different page/title/type
- badge_not_found.csv             page matched, but RT had no usable badge

Notes
-----
- Ratings values are not changed by RT badge sync.
- Only RT badge image fields, rottentomatoes_slug, rottentomatoes_status and timestamps are changed.
- Episodes are not included in RT badge sync.

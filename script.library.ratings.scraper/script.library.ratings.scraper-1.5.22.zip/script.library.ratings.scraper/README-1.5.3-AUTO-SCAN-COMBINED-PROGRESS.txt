Library Ratings Scraper v1.5.3

- Auto scrape new items after Kodi library scan now uses one combined progress counter.
- Movie/TV auto scan progress counts RATINGS + AWARDS + RT BADGES as one workflow, so a single new item no longer shows 100% multiple times.
- Episode auto scan remains RATINGS-only.
- Added a lightweight shared auto-scan lock file foundation so future Artwork Curator/LRS auto jobs can run politely instead of overlapping.
- Manual menu jobs are unchanged.
- No scraping/provider/AF3/hub/widget/keep-last logic changes.

Library Ratings Scraper 1.3.68

Fixes:
- Scrape missing now treats Top250 NULL/blank/0 as missing when Top250 is ON.
- Top250 N/A and positive ranks are treated as already checked.
- Dedicated Top250 sync stores N/A for non-members instead of 0.
- Awards/status no-result cases can store N/A markers to avoid endless retries.
- Rating preservation from 1.3.66 is unchanged.

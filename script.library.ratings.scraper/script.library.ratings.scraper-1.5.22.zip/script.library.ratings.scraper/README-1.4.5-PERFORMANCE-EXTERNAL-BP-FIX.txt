Library Ratings Scraper 1.4.5

Fixes:
- Scrape missing no-op comparison is stricter and avoids updated_at churn.
- External/non-library widgets prefer matching library records before external_ratings.
- External duplicate rows that already match library records are cleaned up.
- External focus debounce reduced to 0.25s.
- Oscar Best Picture lookup repairs old v1.4.3/v1.4.4 N/A rows once using a status table.
- Oscar icon filename for normal Oscar is oscars.png; Best Picture is oscars_bp.png.

Library Ratings Scraper 1.3.82

Fixes:
- Valid addon.xml declaration and addon version, so Kodi/repo import can detect addon.xml.
- Settings categories: API keys, Media, Display, Debug.
- Display > Extra badges toggles: Top 250, Awards, TV Status.
- Scrape still collects all needed data; display toggles only hide/show output.
- Rating slot icons publish filename only plus IconFile property.
- No-Python AF3 patcher: BAT runs PowerShell, not python.exe.

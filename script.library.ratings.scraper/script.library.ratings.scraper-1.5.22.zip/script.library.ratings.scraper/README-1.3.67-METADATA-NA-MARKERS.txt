Library Ratings Scraper 1.3.67

Fixes metadata missing markers:
- Top250/Oscar/Emmy checked-but-empty values are written as N/A, not 0.
- N/A is treated as already checked, so Scrape missing will not scrape the same Oscar/Emmy/Top250 metadata forever.
- Rating preservation from 1.3.66 remains unchanged: Scrape missing metadata does not wipe IMDb/TMDb/RT/Metacritic/Trakt ratings.

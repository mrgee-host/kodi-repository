Library Ratings Scraper v1.4.2

Fixes:
- Fix sqlite save_cache transaction error: cannot start a transaction within a transaction.
- Auto scrape after Kodi video library scan now starts immediately and targets only newly added items from that scan.
- Auto-new jobs keep awards/RT-badge phases scoped to those new items; no full-library skip loop.
- Auto-new jobs do not run full-library IMDb Top 250 sync at finish.
- Heavy focus/publish/RT trace is kept out of kodi.log; when verbose diagnostics is enabled it goes to diagnostics/lrs.log.

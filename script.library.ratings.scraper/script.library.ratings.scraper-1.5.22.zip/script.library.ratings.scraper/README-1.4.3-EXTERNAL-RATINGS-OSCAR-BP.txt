Library Ratings Scraper 1.4.3

- Adds external_ratings table with the same column order as ratings.
- Adds Oscar Best Picture flag after oscar_wins and before emmy_wins.
- Keeps OMDb as awards count source; uses MDBList only as a Best Picture side-check for Oscar-winning movies.
- Backfills Best Picture in Scrape awards only for movies that already have oscar_wins > 0.
- Adds external/non-library focus cache helpers for AF3 Popular/online widgets.

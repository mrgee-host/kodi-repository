Library Ratings Scraper 1.3.65

Fixes the savepoint reload bug that made DB rows appear as movie|1..10, movie|20, movie|30, movie|40, etc.

Cause:
- During a manual scrape, service.py saved ratings-cache.db every 10 items.
- The main loop then detected the DB mtime change from its own save and reloaded cache from disk.
- load_cache could also touch schema/meta, causing another mtime change.
- Unsaved items between savepoints were dropped from RAM before the next save.
- Result: only item 1..10 and savepoint items 20,30,40... survived in ratings table.

Fix:
- Do not reload cache from disk while a manual scrape is running.
- Use post-load DB mtime after load_cache.
- Keep cache_mtime synchronized after manual saves.

Provider flow unchanged:
- Movies/TV ratings: MDBList only.
- MDBList key 1 -> key 2 fallback remains.
- OMDb is not used for Movies/TV ratings.
- Episodes still use OMDb + TMDb when enabled.

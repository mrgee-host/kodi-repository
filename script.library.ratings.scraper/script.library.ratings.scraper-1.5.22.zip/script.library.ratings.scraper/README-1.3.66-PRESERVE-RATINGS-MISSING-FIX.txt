Library Ratings Scraper 1.3.66 - Preserve Ratings During Missing Scrape

Fix:
- Scrape missing / refresh runs with rating checkboxes OFF no longer delete cached rating columns.
- Existing IMDb/TMDb/RT/Metacritic/Trakt values are preserved in cache entries even when those checkboxes are disabled.
- Top250 / TV status / Oscar / Emmy can be scraped without wiping rating columns.
- Export report also keeps existing rating columns instead of filtering them out by the current rating checkboxes.

Rating flow is unchanged:
- Movie/TV ratings: MDBList only when rating checkboxes are ON.
- Episode ratings: OMDb/TMDb when Include Episodes is ON.
- OMDb for movie/TV only for Awards when Awards is ON.

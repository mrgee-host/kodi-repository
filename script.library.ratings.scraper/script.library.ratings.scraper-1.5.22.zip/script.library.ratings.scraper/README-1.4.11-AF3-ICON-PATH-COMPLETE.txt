Library Ratings Scraper 1.4.11 - AF3 Icon Path Complete Fix

- AF3 icon folder update now rewrites every rating icon path in Includes_Info.xml and screensaver-arctic-mirage.xml.
- Supports static icons and dynamic RatingSlot/RottenTomatoes variables.
- Does not create icon folders.
- Does not copy or overwrite icon files.
- AF3 status reports remaining root rating icon references so missed paths are visible.
- Icon folder result dialog now reports XML path references updated, not icon copy/create counts.

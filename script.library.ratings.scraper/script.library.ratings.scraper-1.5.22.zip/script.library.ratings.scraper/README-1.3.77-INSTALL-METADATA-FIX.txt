Library Ratings Scraper 1.3.77

Fixes 1.3.76 packaging metadata:
- addon.xml version is 1.3.77
- xbmc.python dependency is restored to 3.0.0
- XML declaration is 1.0

Keeps all 1.3.76 AF3 cleanup/display fixes.

Library Ratings Scraper 1.3.95 - RT Search / N-A Fix

Fixes over 1.3.94:
- RT 0% is preserved as a valid Rotten Tomatoes rating. It is no longer exported/stored as N/A.
- If either RT critics or RT audience rating is N/A/missing, RT badge search/detail lookup is skipped.
  The row is stored with rottentomatoes_slug = N/A and rottentomatoes_status = N/A.
- Normal Sync RT badges treats N/A as stable and skips it on later runs.
- Detail-page title validation strips RT year suffixes such as "Jumbo (2025)", "Lava (2015)", "Puppy (2013)".
- RT search candidates with exact title but missing/wrong search-row year are allowed through to detail validation.
  This avoids false no_slug for titles like Book of Dragons and exact TV candidates.
- Existing/imported slugs can be international-title aliases when the page year matches, avoiding false slug_mismatch such as Ayat-Ayat Cinta 2 / Verses of Love 2.
- Wrong pages still become slug_mismatch and have their old slug preserved in status, e.g. slug_mismatch (/m/old_slug).

AF3 r7 patch does not need changes.

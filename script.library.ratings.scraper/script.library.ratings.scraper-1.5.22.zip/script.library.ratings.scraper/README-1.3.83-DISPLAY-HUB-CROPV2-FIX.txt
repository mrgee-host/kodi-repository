Library Ratings Scraper 1.3.83

Fixes:
- Rating 6 settings label was blank because strings.po had no separator before #32237.
- Display > Extra badges toggles now bypass old forced-true overrides and really control Top 250, Awards, and TV Status display.
- Rating fallback order remains exactly the user's slot order: default IMDb -> RT Audience -> RT Critics -> Metacritic -> TMDb -> Trakt. No TMDb-before-IMDb hardcode.
- Arctic Mirage clearlogo can use LRS Screensaver CropV2Image. The service first checks TMDbHelper live CropV2 properties, then tries a local crop_v2 hash match from the current Kodi clearlogo URL.
- Screensaver rating row uses wider inline controls so percentage labels do not become 6... / 4...
- PowerShell patcher now includes Includes_Hubs.xml active bridge patch/restore/status. Patch all really patches Includes_Info, Includes_Hubs, and screensaver.

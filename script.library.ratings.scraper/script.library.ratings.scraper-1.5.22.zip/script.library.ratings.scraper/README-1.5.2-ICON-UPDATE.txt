Library Ratings Scraper 1.5.2

- Updated addon icon.
- No scraping/provider/database/progress/menu logic changes.

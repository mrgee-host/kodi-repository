Library Ratings Scraper 1.3.79

- Movie/series ratings: MDBList only. No OMDb/TMDb fallback for rating families.
- Movie/series normal awards: MDBList awards text from the same MDBList JSON response.
- Awards-only menu: MDBList first; if MDBList limit is reached, OMDb fallback is allowed for remaining awards only.
- Episodes: OMDb + TMDb rating flow unchanged.
- Series status: TMDb only.
- Top250: local DB only.
- DB schema adds awards_text after oscar_wins/emmy_wins; media_type is moved near the end before updated_at.
- Timestamps no longer include WIB suffix.
- rating-scale-trace.log is disabled/removed.
- Movie/series rating row uses user-selected combobox slots 1-5 plus rating count and fill-empty behavior.
- Arctic Mirage CropV2 image is still from TMDbHelper, but LRS validates it against the active screensaver item and logs cropv2/default_kodi/title mode.

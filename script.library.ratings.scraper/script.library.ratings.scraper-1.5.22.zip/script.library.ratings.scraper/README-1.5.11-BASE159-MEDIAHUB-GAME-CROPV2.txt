Library Ratings Scraper 1.5.11-base159

Base used:
- script.library.ratings.scraper v1.5.9 MediaHub game home/hub duplicate fix.
- This package intentionally does NOT include the v1.5.10 home/library achievement-only bridge.

Changed:
- addon.xml
- resources/lib/core.py

Not changed:
- service.py is kept from v1.5.9.

What this patch does:
- Keeps movie, tvshow, season and episode CropV2 flow unchanged.
- Keeps v1.5.9 game rating behavior: game RatingSlotN_* is mirrored to LibraryRatings.Screensaver only, while ListItem/Player/VideoPlayer are cleared for games to avoid duplicated Home/Hub rows.
- Adds a game-only wrapper around update_screensaver_clearlogo_properties().
- When the current screensaver item is a game, LRS now tries:
  1. Existing TMDbHelper CropImage/CropV2Image candidates when title matches.
  2. Direct game CropV2 properties if MediaHub/Steam item already publishes them.
  3. Existing TMDbHelper crop_v2 local hash lookup, using game clearlogo/clearlogo_url/logo candidates from Container(1297), ListItem, LRS.Active and item dict.
- Publishes the same Screensaver properties used by movies/series:
  LibraryRatings.Screensaver.CropV2Image
  LibraryRatings.Screensaver.CropV2Source
  LibraryRatings.Screensaver.CropV2Title
  LibraryRatings.Screensaver.DefaultClearLogo
  LibraryRatings.Screensaver.ClearLogoMode
  LibraryRatings.Screensaver.ClearLogoFinal
  LibraryRatings.Screensaver.ClearLogoFinalMode
  LibraryRatings.Screensaver.ClearLogoFinalSource
  LibraryRatings.Screensaver.ClearLogoFinalTitle
  LibraryRatings.Screensaver.ClearLogoFinalItemKey

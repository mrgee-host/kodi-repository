Library Ratings Scraper 1.5.19 - Home/Hub game guard

- Adds a direct AF3 Includes_Info.xml visible guard to the LRS Home/Hub metadata row.
- Hides LibraryRatings.ListItem movie/TV rating row immediately when the current ListItem is a game.
- Prevents a fast movie -> game focus transition from showing stale IMDb/RT/Popcorn beside Steam game metadata.
- Keeps Steam/Game metadata row unchanged.
- Keeps KPM shared-icons as the canonical icon path.

Library Ratings Scraper 1.5.5

Changes:
- Replace addon icon with the latest gold Library Ratings Scraper icon.
- Export diagnostics now finishes with a small Kodi notification instead of a modal result popup.
- Export diagnostics no longer returns to the run menu after completion.
- Main run menu exits after every selected action finishes or queues.
- Maintenance and AF3 submenus also exit after one selected action; they no longer loop back automatically.
- Scraping/provider/cache/AF3 display/hub/widget/keep-last logic unchanged.

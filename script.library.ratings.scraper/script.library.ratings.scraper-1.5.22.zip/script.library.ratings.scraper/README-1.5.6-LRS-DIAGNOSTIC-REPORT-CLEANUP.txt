Library Ratings Scraper 1.5.6 - LRS diagnostic/report cleanup

Changes:
- Regenerates ratings-report.csv after Clean Library removes stale cache rows.
- Writes a clean clean_library background state so diagnostics no longer show misleading scrape total=0 / updated>0 after cleanup.
- Adds diagnostics heartbeat/status for lrs.log so stale logs are obvious/fresh in exported diagnostics ZIP.
- Keeps scraping/provider/AF3/hub/widget/auto-scan behavior unchanged from v1.5.5.

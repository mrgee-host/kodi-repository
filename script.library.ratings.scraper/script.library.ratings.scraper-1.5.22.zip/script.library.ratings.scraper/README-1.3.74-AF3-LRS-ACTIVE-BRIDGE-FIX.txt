Library Ratings Scraper 1.3.74

Fixes based on the AF3/LRS display issue analysis:
- Stops publishing to TMDbHelper.* by default to prevent duplicate native AF3 status rows.
- Adds setting: Publish TMDbHelper compatibility (legacy), default OFF.
- Prioritizes LRS.Active.* from AF3 bridge for Hub/item display.
- Reduces service polling from 0.40s to 0.12s.
- Sticky publisher no longer clears ratings on button/dialog/incomplete identity.
- Publishes only changed property values.
- Adds display toggles separated from scrape settings.
- Publishes Rotten Tomatoes icon filenames from cached DB image keys.
- Bundles local imdb_top_250.db built from the uploaded JSON files.
- Keeps manual scrape/service behavior; no auto internet scrape on focus.

Use with AF3-LRS-display-integration-patcher-v3, which patches AF3 1080i Includes_Info.xml and AF3 1080i screensaver-arctic-mirage.xml.

Library Ratings Scraper 1.3.86

- Fixes AF3 spacing to match Arctic Fuse 3's native Info_Meta_Object logic:
  IMDb uses icon_w=52; all other rating/award/status icons use the native default icon_w=32.
- Screensaver rating row no longer uses fixed-width 150px groups. It uses AF3-style image/label/spacer controls with itemgap=12 and auto label width.
- Screensaver row reads LibraryRatings.Screensaver.* properties, not ListItem.* and not the cross-file LRS_Info_Meta_Ratings include, preventing missing rows after idle/slide changes.
- Screensaver publish is more tolerant: if a screensaver item misses in RAM cache, the service reloads ratings-cache.db once before clearing.
- CropV2 resolver is preserved; check kodi.log for mode=cropv2.
- Hub bridge patcher remains robust and only duplicates TMDbHelper.WidgetContainer into LRS.Active.ContainerID.

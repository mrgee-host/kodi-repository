Library Ratings Scraper 1.3.98 - RT N/A Closeout + Awards Normalize

Base: 1.3.97 MDBList not-found fallback + diagnostics.

Fixes:
- If RT badge phase applies rt_rating_na_skip and RT critics/audience numeric side is still blank, write a no-rating marker (N/A) into the rating cache for that side.
  This closes the 1.3.97 edge case where rt_critic was held for OMDb fallback but fallback produced no value, leaving The Billionaire / Talak 3 / Tampan Tailor blank instead of N/A.
- Normalize irrelevant award columns in the wide DB row:
  movie emmy_wins = N/A
  tvshow oscar_wins = N/A
- Keeps RT 0% valid and keeps IMDb/TMDb/Metacritic/Trakt zero as N/A per 1.3.97.
- Keeps diagnostics ZIP export and AF3 r7 compatibility.

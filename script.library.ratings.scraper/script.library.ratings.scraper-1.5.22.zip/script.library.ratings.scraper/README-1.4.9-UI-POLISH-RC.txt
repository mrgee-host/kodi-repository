Library Ratings Scraper 1.4.9 - UI Polish RC

Pre-1.5 UI polish build.

Highlights:
- All visible labels/dialogs/warnings/results use English wording.
- Progress notifications use a single compact formatter and avoid duplicate percent text.
- Maintenance dialogs use normal OK dialogs with professional summaries.
- Removed/updated item lists are compact comma-separated title lists when available.
- Back in submenus returns to the previous menu instead of closing the addon flow.
- Provider status dialog uses a final title and compact saved-report path.
- Main run confirmations and warnings were rewritten for clarity.

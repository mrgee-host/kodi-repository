Library Ratings Scraper v1.5.7

TMDb episode no-rating policy cleanup.

Changes:
- TMDb episode rating now writes N/A only when TMDb returns a valid episode detail payload and vote_average is empty or zero.
- TMDb transport/provider/search errors stay blank so Scrape missing data can retry later.
- Removed unconditional episode TMDb checked/no-value marker after any TMDb lookup attempt.
- Movie/show TMDb fallback no-rating marker now also ignores TMDb error payloads.

Unchanged:
- OMDb error/limit policy remains unchanged: temporary failures stay blank for retry.
- Provider order and scraping flow remain unchanged.
- AF3/hub/widget/keep-last logic unchanged.
- Auto-scan progress, diagnostics notification, icon, no-back menu behavior unchanged.

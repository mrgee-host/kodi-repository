Library Ratings Scraper 1.3.99

- Removes bundled resources/data/imdb_top_tv_shows.db. Top250 movies and TV now use the unified imdb_top_250.db only.
- Final run menu:
  Refresh all data
  Scrape missing data
  Scrape missing RT badges only
  Scrape awards only
  Update IMDb Top 250 only
  View status
  Export diagnostics ZIP
- Refresh all data shows a hard warning before starting.
- Generated diagnostics are compacted under addon_data/script.library.ratings.scraper/diagnostics/.
- RT special reports are merged into rt-badges-report.csv; RT logs are compacted into lrs.log.
- Adds Basic setting: Auto scrape new items after library update.
- Context menu label: Refresh ratings data for selected item; refresh is forced for that item.
- Keeps all 1.3.98 rating, RT, MDBList fallback, and awards normalization fixes.

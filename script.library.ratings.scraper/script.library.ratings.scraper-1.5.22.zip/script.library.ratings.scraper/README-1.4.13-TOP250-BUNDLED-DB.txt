Library Ratings Scraper 1.4.13 - Top250 Bundled DB Restore

- Removes live IMDb web syncing from the active Top250 workflow.
- Restores Update IMDb Top 250 to the bundled resources/data/imdb_top_250.db source.
- Keeps existing AF3 icon-folder complete path fix.
- Keeps Scrape missing fast: blank Top250 alone does not trigger item-by-item scraping.
- Removes old live Top250 fetch diagnostics from future diagnostics exports.
- Uses the new addon icon supplied by the user.

Library Ratings Scraper 1.4.0 - Performance / Verbose Cleanup

- Auto scrape after VideoLibrary scan now starts after a shorter 10s delay.
- Heavy focus/publish/clearlogo/RT parser logs are verbose-only.
- Added Expert setting: Verbose diagnostics logging.
- RT badge CSV remains; per-item lrs.log detail and last-json scratchpad are no longer written in normal mode.
- Diagnostics ZIP no longer includes rt-badge-sync-last.json.
- Background progress text truncates long titles with ... to avoid wrapping.
- SQLite save avoids rewriting unchanged rows and preserves updated_at/timestamp on no-change rows.
- Base behavior from 1.3.99 is retained.

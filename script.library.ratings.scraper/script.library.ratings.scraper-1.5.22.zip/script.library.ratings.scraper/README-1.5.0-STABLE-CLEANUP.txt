Library Ratings Scraper 1.5.0 - Stable Cleanup Release

Scope:
- Keep v1.4.13 bundled IMDb Top 250 database behavior.
- Do not change hub/widget/keep-last UI logic.
- Redact API keys in diagnostics ZIP text exports.
- Fix summary phase stats so processed/checked/matched/updated are consistent.
- Clarify Top250 local sync report with checked and changed_rows aliases.
- Rebuild RT badges report from cache when the report file is header-only.
- Keep auto scrape, debug logging, and verbose diagnostics OFF by default.
- Progress notification line 2 changed to title-first format: {processed}/{total} {TITLE} - {PHASE}.
- Episode progress uses: {EPISODE TITLE} - SxxExx - {SHOWTITLE} - {PHASE}.
- Progress text is no longer aggressively shortened; it is only trimmed when the notification body is very long.

Library Ratings Scraper 1.3.76

Fixes after 1.3.75 testing:
- Always publish RT/RT audience icon filenames, with rating-based fallback if DB image key is blank.
- Add RT image values to debug publish log.
- Do not publish TV status for episode records.
- Home Play/More Options focus no longer lets parent tvshow override the current episode row.
- Release ZIP is clean: no __pycache__ / pyc.

Use with AF3-LRS-active-bridge-display-patcher-v5.zip.

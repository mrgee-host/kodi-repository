Library Ratings Scraper 1.3.85

Fix focus:
- Runtime addon keeps the existing 1.3.78+ AF3 Home/Hub af3_visual resolver.
- New patcher rebuilds Includes_Hubs active bridge from AF3 TMDbHelper.WidgetContainer anchors, including Spotlight Button/List, Wall, Combined, and selector 601.
- Screensaver rating row uses the same AF3-like spacing measurements as the library row: itemgap 12, icon width 52, auto labels, no fixed 150px clipping.
- Awards icons remain oscars.png and emmys.png only. Golden Globe is intentionally not scraped/displayed.

Library Ratings Scraper 1.3.80

Fixes:
- Movie/Series rating count options now display 1-6, not Kodi localized labels like Videos.
- Adds Rating 6 and Trakt to rating slot comboboxes.
- Removes old visible-rating checkbox list from Display settings; use Rating 1-6 only.
- Simplifies addon menu labels. Debug logging is only in Settings.
- De-spams debug publish logging by logging only when source/item/slot signature changes.
- Extends AF3 XML patch to disable native TMDbHelper rating rows and use LRS only.
- Screensaver patch preserves/restores plot and uses LRS-validated CropV2 image with default Kodi clearlogo fallback.

Library Ratings Scraper 1.4.6

- Adds safe LRS cache cleanup after Kodi Clean Library: removed Kodi movie/tv/episode DBIDs are removed from ratings. external_ratings is left untouched.
- Removes/drops oscar_bp_status table; Oscar BP missing logic now uses the main oscar_best_picture column only.
- If oscar_wins is N/A, oscar_best_picture is automatically N/A.
- Progress notification text is shorter: 680/1037 RT BADGES - THE DARK KNIGHT - 65%.
- Auto scrape no longer shows a separate queued notification; it goes straight to real progress.
- Popular/non-library focused items are matched against the library first and do not get saved to external_ratings when already in the Kodi library.
- Service entrypoint moved to the true end so all v1.4.5/v1.4.6 runtime overrides are active.

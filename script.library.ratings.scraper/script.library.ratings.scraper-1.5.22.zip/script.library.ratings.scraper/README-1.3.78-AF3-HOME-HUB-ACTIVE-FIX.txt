Library Ratings Scraper 1.3.78

Fixes:
- AF3 Home/Hub visual container resolver: Home, Custom_1101_Hub and Custom_1102_Hub now read the item being drawn, not the button/tab focus.
- TMDbHelper fallback is blocked in AF3 button/tab context so stale Dumbo-style overrides cannot replace the visible Shawshank/spotlight item.
- Episode TMDb display is handled by the AF3 XML patch: episodes can show IMDb + TMDb even when the global TMDb display toggle is off for movies/series.
- Existing screensaver integration is preserved; the AF3 patcher skips it when already patched.

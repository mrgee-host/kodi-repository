Library Ratings Scraper 1.3.51

Base: 1.3.50.

Fixes:
- Fix crash during manual scrape: sqlite3.OperationalError: cannot start a transaction within a transaction.
- DB handling is now current-schema only. No legacy JSON import, no payload migration, no ratings_long_backup rebuild, no top250_movie cleanup.
- Existing ratings-cache.db is treated as already final/current.
- Manual-only service behavior from 1.3.50 is preserved.

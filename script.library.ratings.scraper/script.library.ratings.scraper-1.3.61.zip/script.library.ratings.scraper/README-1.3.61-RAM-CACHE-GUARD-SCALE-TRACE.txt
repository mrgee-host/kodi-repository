Library Ratings Scraper 1.3.61

Fix/diagnostic build:
- If ratings-cache.db is deleted while Kodi/service is still running, service clears old RAM cache instead of writing old values back.
- Manual scrape always reloads cache from disk before starting.
- Each manual scrape resets rating-scale-trace.log.
- Every item is logged before DB insert with raw normalized rating dict and final DB cells.

Trace file:
E:\Kodi\portable_data\userdata\addon_data\script.library.ratings.scraper\rating-scale-trace.log

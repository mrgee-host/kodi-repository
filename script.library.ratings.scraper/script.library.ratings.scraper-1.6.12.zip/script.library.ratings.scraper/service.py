# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import re
import time
import threading
import traceback
import xbmc
import xbmcgui
from resources.lib import core

# Service pacing. Normal item monitoring is back to 0.10s;
# empty/irrelevant states back off to 1s; disabled/deep-idle states back off
# to 5s. Do not use a zero-delay busy loop.
POLL_SECONDS = 0.10
POLL_SCREENSAVER_SECONDS = 0.05
POLL_MID_SECONDS = 1.00
POLL_DEEP_IDLE_SECONDS = 5.00
STATE_FILE = os.path.join(core.STATE_DIR, "service-state.json")
TITLE = "Library Ratings Scraper"


def load_state():
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as handle:
            row = json.load(handle)
        return row if isinstance(row, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(state):
    os.makedirs(core.STATE_DIR, exist_ok=True)
    temp = STATE_FILE + ".tmp"
    with open(temp, "w", encoding="utf-8") as handle:
        json.dump(state, handle, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(temp, STATE_FILE)


def current_context_item():
    if core.player_context_active():
        return "player", core.player_item()

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item
    item = core.lrs_active_item()
    if core.valid_library_item(item):
        return "lrs_active", item
    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity
    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}


def context_log(state, context, item_key, title, published, reason):
    # Heavy focus/publish trace. Keep it out of kodi.log unless verbose diagnostics is enabled.
    try:
        if not core.verbose_debug_enabled():
            return
    except Exception:
        return
    signature = "{0}|{1}|{2}|{3}".format(context, item_key, int(bool(published)), reason)
    if state.get("last_context_log") == signature:
        return
    state["last_context_log"] = signature
    clean_title = str(title or "").replace("\\n", " ")[:80]
    core.log(
        "context={0} item_key={1} title={2} published={3} reason={4}".format(
            context, item_key or "", clean_title, "yes" if published else "no", reason
        ),
        xbmc.LOGDEBUG,
    )


def _record_from_cache(cache, item, preload=None):
    preload = preload or {}
    identity = core.identity_key(item)
    cached = preload.get(identity)
    if isinstance(cached, dict):
        return cached
    return core.cache_record(cache, item)


def queue_item(queue, queued, item, front=False):
    # Background lookup requires a Kodi DBID. Title-only hub fallbacks can still
    # publish cached values, but should not be looked up online as a new item.
    if not core.resolvable_library_item(item):
        return
    key = core.item_key(item)
    if key in queued:
        return
    queued.add(key)
    if front:
        queue.insert(0, item)
    else:
        queue.append(item)




def homehub_neighbor_prefetch_1523(cache, item, context="", state=None, radius=1):
    """Return {identity_key: cached_record} for AF3 current/left/right items.

    Cache-only: no online lookup is queued here. This prepares Home/Hub moves
    without changing what is currently displayed.
    """
    state = state if isinstance(state, dict) else {}
    if str(context or "").lower() not in ("af3_visual", "hub", "hub_fallback", "listitem", "lrs_active"):
        return {}
    try:
        if not core.af3_hub_window_active():
            return {}
    except Exception:
        return {}
    get_items = getattr(core, "af3_neighbor_items_1523", None)
    if not callable(get_items):
        return {}
    out = {}
    try:
        for candidate in get_items(item, radius):
            if not core.valid_library_item(candidate):
                continue
            if core.is_lrs_game_item(candidate):
                continue
            key = core.identity_key(candidate)
            if not key or key in out:
                continue
            record = core.cache_record(cache, candidate)
            if record and core.context_matches_record(candidate, record):
                out[key] = record
                context_log(state, "homehub_prefetch", key, candidate.get("title"), True, "neighbor_cache_hit_1523")
            else:
                context_log(state, "homehub_prefetch", key, candidate.get("title"), False, "neighbor_cache_miss_1523")
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("Home/Hub neighbor prefetch failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass
    return out
def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}

    if not core.valid_library_item(item):
        core.clear_af3_properties(compatibility)
        context_log(state, context, "", item.get("title") if isinstance(item, dict) else "", False, "identity_missing")
        return ""

    active_key = core.identity_key(item)
    if active_key != previous_key:
        # Clear first on every context/key change. If cache lookup misses or waits
        # one cycle, AF3 sees blank properties instead of the previous item.
        core.publish_af3_properties({}, active_key, compatibility)

    record = _record_from_cache(cache, item, preload)
    if not record and context == "player":
        # Player/OSD must not stay blank just because the service loaded cache
        # before a manual scrape/rebuild finished. Reload DB once on player miss.
        try:
            fresh_cache = core.load_cache()
            record = _record_from_cache(fresh_cache, item, preload)
            if record:
                cache.clear(); cache.update(fresh_cache)
        except Exception:  # pylint: disable=broad-except
            record = None
    if not record:
        core.publish_af3_properties({}, active_key, compatibility)
        context_log(state, context, active_key, item.get("title"), False, "cache_miss")
        return active_key

    if not core.context_matches_record(item, record):
        core.publish_af3_properties({}, active_key, compatibility)
        context_log(state, context, active_key, item.get("title"), False, "stale_guard")
        return active_key

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    try:
        values.update(core.lrs_endsat_properties_1522(item, context))
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("LRS Ends-at slot publish failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass
    core.publish_af3_properties(values, publish_key, compatibility)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), True, "cache_hit")
    return active_key


def item_label(item):
    title = item.get("title") or "Untitled"
    if item.get("type") == "episode":
        # v1.5 notification polish: episode title first, then season/episode,
        # then show title. This keeps the changing part of episode progress
        # visible at the front of the notification body.
        return "{0} - S{1:02d}E{2:02d} - {3}".format(
            title,
            core.safe_int(item.get("season")) or 0,
            core.safe_int(item.get("episode")) or 0,
            item.get("showtitle") or "Series",
        )
    return title


def _family_notification_result_1690(message):
    """Normalize user-facing result text without changing diagnostics counters."""
    text = re.sub(r"\s+", " ", str(message or "").strip()).upper().rstrip()
    text = re.sub(r"\bHANDED OFF\b", "MIGRATED", text)
    text = re.sub(r"\bHANDOFF\b", "MIGRATED", text)
    parts = text.replace(" • ", " - ").split(" - ") if text else []
    if len(parts) > 1:
        parts = [parts[0]] + [part for part in parts[1:] if not re.match(r"^0(?:\s+|$)", part)]
        text = " - ".join(part for part in parts if part)
    elif text and re.match(r"^0(?:\s+|$)", text):
        return ""
    return text


def _family_compact_result_1569(message, limit=58):
    text = _family_notification_result_1690(message)
    if len(text) <= int(limit):
        return text
    parts = text.replace(" • ", " - ").split(" - ")
    protected = ("ERROR", "FAILED", "UPDATED", "ARTWORK", "ITEM", "CACHED", "MOVED", "MIGRATED", "SCRAPED", "N/A")
    if len(parts) > 1 and any(token in " - ".join(parts[1:]) for token in protected):
        suffix = " - " + " - ".join(parts[1:])
        budget = max(4, int(limit) - len(suffix))
        action = parts[0]
        if len(action) > budget:
            action = action[:max(1, budget - 3)].rstrip() + "..."
        return (action + suffix)[:int(limit)].rstrip()
    raw = text[:max(1, int(limit) - 3)].rstrip()
    return (raw.rsplit(" ", 1)[0] if " " in raw else raw) + "..."


def notify(message, icon=xbmcgui.NOTIFICATION_INFO, duration=5000):
    text = _family_compact_result_1569(message, 58)
    if text:
        xbmcgui.Dialog().notification(TITLE, text, icon, duration, False)



# v1.5.24: keep AF3 visual Home/Hub on 0.10s fast polling; 1.5.23 prefetch was cache-ready but wait policy could fall back to 1.0s.
def lrs_service_wait_seconds(context, item, manual_job=None, queue=None):
    """Return dynamic service wait without busy-looping Kodi."""
    try:
        if not core.bool_setting("publish_af3_cache", True):
            return POLL_DEEP_IDLE_SECONDS
    except Exception:
        pass
    if manual_job is not None or queue:
        return POLL_SECONDS
    try:
        if xbmc.getCondVisibility("System.ScreenSaverActive"):
            return POLL_SCREENSAVER_SECONDS
        if core.player_context_active():
            return POLL_SECONDS
    except Exception:
        pass
    if str(context or "").lower() == "screensaver":
        return POLL_SCREENSAVER_SECONDS
    if str(context or "").lower() in ("af3_visual", "hub", "listitem", "lrs_active", "tmdbhelper", "hub_fallback", "player"):
        return POLL_SECONDS
    return POLL_MID_SECONDS


def write_job_state(job, status=None):
    item_total = len(job.get("items") or [])
    raw_total = job.get("total")
    total = int(raw_total) if raw_total not in (None, "") and int(raw_total or 0) > 0 else item_total
    processed = int(job.get("processed") or job.get("index") or 0)
    if total and processed > total:
        processed = total
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    state = {
        "status": status or job.get("status") or "running",
        "action": job.get("action") or "scrape",
        "force": bool(job.get("force")),
        "requested_at": job.get("requested_at") or "",
        "started_at": job.get("started_at") or "",
        "finished_at": job.get("finished_at") or "",
        "total": total,
        "processed": processed,
        "percent": percent,
        "updated": int(job.get("updated") or 0),
        "matched": int(job.get("matched") or 0),
        "skipped": int(job.get("skipped") or 0),
        "failed": int(job.get("failed") or 0),
        "current": job.get("current") or "",
        "report": job.get("report") or "",
    }
    core.save_background_state(state)


def compact_text(value, limit=26):
    text = str(value or "Preparing...").replace("\n", " ").strip()
    return text if len(text) <= limit else text[: max(0, limit - 3)].rstrip() + "..."


def update_bg(job, message=None):
    progress = job.get("progress")
    if progress is None:
        return
    total = int(job.get("total") or len(job.get("items") or []))
    processed = int(job.get("processed") or job.get("index") or 0)
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    # Keep the background notification deliberately minimal. Arctic Fuse 3
    # only has room for one compact body line. Detailed counters remain
    # available from the add-on menu: "View background status".
    text = message or "{0}/{1}  {2}".format(
        processed,
        total,
        compact_text(job.get("current")),
    )
    progress.update(percent, TITLE, compact_text(text, 58))


def new_scrape_job(request):
    items = core.library_items()
    action = request.get("action") or "scrape"
    awards_only = action == "awards"
    if awards_only:
        items = [item for item in items if core.media_setting_type(item.get("type")) in ("movie", "tvshow")]
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, "0/0 STARTING - AWARDS" if awards_only else "0/0 STARTING - RATINGS")
    total = len(items)
    job = {
        "action": action,
        "awards_only": awards_only,
        "force": bool(request.get("force")),
        "requested_at": request.get("requested_at") or core.now_iso(),
        "started_at": core.now_iso(),
        "items": items,
        "keys": core.api_keys(),
        "index": 0,
        "updated": 0,
        "matched": 0,
        "processed": 0,
        "total": total,
        "skipped": 0,
        "failed": 0,
        "looked_up": 0,
        "current": "Preparing...",
        "next_at": 0.0,
        "progress": progress,
        "status": "running",
    }
    write_job_state(job)
    return job


def new_top250_job(request):
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, "0/0 STARTING - TOP250")
    job = {
        "action": "top250",
        "force": True,
        "requested_at": request.get("requested_at") or core.now_iso(),
        "started_at": core.now_iso(),
        "items": [],
        "index": 0,
        "updated": 0,
        "skipped": 0,
        "failed": 0,
        "matched": 0,
        "processed": 0,
        "total": 0,
        "current": "IMDb Top 250",
        "progress": progress,
        "status": "running",
    }
    write_job_state(job)
    notify("IMDb Top 250 update running in background", xbmcgui.NOTIFICATION_INFO, 5000)
    return job


def finish_job(job, cache, canceled=False, stopped_reason=""):
    job["status"] = "finishing"
    write_job_state(job, "finishing")
    update_bg(job, "Saving cache...")
    core.save_cache(cache)

    if job.get("action") == "scrape" and not canceled and not stopped_reason:
        job["phase"] = "top250"
        job["current"] = "Starting"
        update_bg(job)
        try:
            stats = core.sync_imdb_top250_to_library(False, None)
            job["matched"] = int(stats.get("matched") or 0)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("IMDb Top 250 sync failed after background scrape: {0}".format(exc), xbmc.LOGWARNING)
    elif job.get("action") == "top250" and not canceled:
        job["phase"] = "top250"
        job["current"] = "Starting"
        update_bg(job)
        try:
            stats = core.sync_imdb_top250_to_library(True, job.get("progress"))
            job["updated"] = int(stats.get("updated") or 0)
            job["matched"] = int(stats.get("matched") or 0)
            job["total"] = int(stats.get("total") or 0)
            job["processed"] = int(stats.get("processed") or stats.get("total") or 0)
            job["percent"] = 100
            cache = core.load_cache()
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] = 1
            core.log("Manual IMDb Top 250 sync failed: {0}".format(exc), xbmc.LOGWARNING)

    update_bg(job, "Exporting CSV report...")
    report = core.export_csv(core.load_cache())
    job["report"] = report

    summary = {
        "started_at": job.get("started_at"),
        "finished_at": core.now_iso(),
        "items_total": int(job.get("total") or len(job.get("items") or [])),
        "matched": int(job.get("matched") or 0),
        "updated": int(job.get("updated") or 0),
        "matched": int(job.get("matched") or 0),
        "skipped": int(job.get("skipped") or 0),
        "failed": int(job.get("failed") or 0),
        "online_lookups": int(job.get("looked_up") or 0),
        "report": report,
        "canceled": bool(canceled),
        "stopped_reason": stopped_reason or "",
        "action": job.get("action"),
    }
    core.save_summary(summary)
    job["finished_at"] = summary["finished_at"]
    if stopped_reason:
        job["status"] = "stopped"
        job["current"] = stopped_reason
    else:
        job["status"] = "canceled" if canceled else "completed"
        job["current"] = "Canceled" if canceled else "Finished"
    if job.get("progress") is not None:
        job["progress"].close()
    write_job_state(job, job["status"])
    if stopped_reason:
        notify(stopped_reason, xbmcgui.NOTIFICATION_WARNING, 8000)
    elif canceled:
        notify("Background scrape canceled", xbmcgui.NOTIFICATION_WARNING, 6000)
    else:
        notify("Background scrape completed", xbmcgui.NOTIFICATION_INFO, 6000)


def force_stop_job(job):
    if job and job.get("progress") is not None:
        try:
            job["progress"].close()
        except Exception:  # pylint: disable=broad-except
            pass
    state = {
        "status": "force_stopped",
        "action": (job or {}).get("action", "scrape"),
        "force": bool((job or {}).get("force")),
        "requested_at": (job or {}).get("requested_at", ""),
        "started_at": (job or {}).get("started_at", ""),
        "finished_at": core.now_iso(),
        "percent": int((job or {}).get("percent") or 0),
        "processed": int((job or {}).get("index") or 0),
        "total": len((job or {}).get("items") or []),
        "updated": int((job or {}).get("updated") or 0),
        "skipped": int((job or {}).get("skipped") or 0),
        "failed": int((job or {}).get("failed") or 0),
        "current": "Force stopped",
    }
    core.save_background_state(state)


def advance_scrape(job, cache):
    if time.time() < float(job.get("next_at") or 0):
        return False
    items = job.get("items") or []
    total = len(items)
    job["total"] = total
    job["processed"] = int(job.get("index") or 0)
    if job.get("index", 0) >= total:
        finish_job(job, cache, False)
        return True

    # Skip fresh rows quickly in one UI cycle. Stop after the first online/local
    # resolve so API pacing remains predictable and the service stays responsive.
    handled = 0
    while job.get("index", 0) < total and handled < 100:
        item = items[job["index"]]
        job["index"] += 1
        job["processed"] = int(job.get("index") or 0)
        handled += 1
        key = core.item_key(item)
        existing = (cache.get("items") or {}).get(key) or {}
        label = item_label(item)
        job["current"] = label
        if not job.get("force") and existing and not core.record_needs_update(item, existing):
            job["skipped"] += 1
            update_bg(job)
            continue
        try:
            if job.get("action") == "awards":
                if existing and not core.record_missing_awards(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                cache.setdefault("items", {})[key] = core.resolve_awards_only(item, job.get("keys") or core.api_keys(), existing)
            else:
                cache.setdefault("items", {})[key] = core.resolve_item(item, job.get("keys") or core.api_keys(), existing, missing_only=not job.get("force"), include_local=False)
            job["updated"] += 1
            job["looked_up"] += 1
        except core.ProviderLimitReached as exc:
            message = "Stopped: {0} API limit reached".format(exc.provider)
            detail = str(exc)
            job["failed"] += 1
            job["current"] = message
            job["stopped_reason"] = message
            core.log("{0}. {1}".format(message, detail), xbmc.LOGWARNING)
            core.save_cache(cache)
            finish_job(job, cache, False, message)
            return True
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] += 1
            core.log("Background full scrape failed for {0}: {1}".format(label, exc), xbmc.LOGWARNING)
        if job["index"] % max(1, core.int_setting("save_every", 10)) == 0:
            core.save_cache(cache)
        delay = max(0, core.int_setting("delay_ms", 1100)) / 1000.0
        job["next_at"] = time.time() + delay
        update_bg(job)
        write_job_state(job)
        return False

    job["processed"] = int(job.get("index") or 0)
    write_job_state(job)
    if job.get("index", 0) >= total:
        finish_job(job, cache, False)
        return True
    return False


def advance_job(job, cache):
    if core.consume_background_force_stop():
        force_stop_job(job)
        return True
    if core.consume_background_cancel():
        finish_job(job, cache, True)
        return True
    if job.get("action") == "top250":
        finish_job(job, cache, False)
        return True
    return advance_scrape(job, cache)


# -----------------------------------------------------------------------------
# v1.3.74 AF3/LRS active bridge + sticky publisher overrides (superseded by v1.3.75 below)
# -----------------------------------------------------------------------------
def current_context_item():
    # Player/OSD always wins.
    if core.player_context_active():
        return "player", core.player_item()

    # AF3 skin bridge is the highest priority for hub/library panels because
    # it represents the item currently being drawn, not the focused button.
    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus
    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item
    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity
    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}

    # Invalid focus/button/dialog should not clear the visible media row.
    if not core.valid_library_item(item):
        context_log(state, context, previous_key or "", item.get("title") if isinstance(item, dict) else "", False, "identity_missing_keep_last")
        return previous_key or ""

    active_key = core.identity_key(item)
    record = _record_from_cache(cache, item, preload)
    if not record and context == "player":
        try:
            fresh_cache = core.load_cache()
            record = _record_from_cache(fresh_cache, item, preload)
            if record:
                cache.clear(); cache.update(fresh_cache)
        except Exception:  # pylint: disable=broad-except
            record = None

    if not record:
        # If the incoming identity is incomplete/title-only, keep the previous
        # row rather than blanking. If it is a strong different media id, clear
        # to avoid showing stale values for a real new item.
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "cache_miss_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "cache_miss_keep_last")
        return previous_key or active_key

    if not core.context_matches_record(item, record):
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "stale_guard_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "stale_guard_keep_last")
        return previous_key or active_key

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    core.publish_af3_properties(values, publish_key, compatibility)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), True, "cache_hit_bridge")
    return active_key



# -----------------------------------------------------------------------------
# v1.3.75 AF3/LRS active bridge + strict episode sticky publisher
# -----------------------------------------------------------------------------
def current_context_item():
    # Player/OSD always wins.
    if core.player_context_active():
        return "player", core.player_item()

    # Screensaver must use the screensaver container. Do not let a stale hub
    # bridge override the active slide.
    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    # AF3 skin bridge wins for hub/library panels because it represents the
    # item being drawn, not the focused Play/Options button.
    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item
    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus
    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity
    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}

    if not core.valid_library_item(item):
        context_log(state, context, previous_key or "", item.get("title") if isinstance(item, dict) else "", False, "identity_missing_keep_last")
        return previous_key or ""

    active_key = core.identity_key(item)
    record = _record_from_cache(cache, item, preload)
    if not record and context == "player":
        try:
            fresh_cache = core.load_cache()
            record = _record_from_cache(fresh_cache, item, preload)
            if record:
                cache.clear(); cache.update(fresh_cache)
        except Exception:  # pylint: disable=broad-except
            record = None

    if not record:
        # Strong new media IDs should clear; weak/title-only button/dialog focus
        # keeps the last row to avoid flicker.
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "cache_miss_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "cache_miss_keep_last")
        return previous_key or active_key

    if not core.context_matches_record(item, record):
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "strict_guard_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "strict_guard_keep_last")
        return previous_key or active_key

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    try:
        core._lrs_log_publish_values(context, record, values)  # pylint: disable=protected-access
    except Exception:  # pylint: disable=broad-except
        pass
    core.publish_af3_properties(values, publish_key, compatibility)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), True, "cache_hit_strict")
    return active_key


# -----------------------------------------------------------------------------
# v1.3.76 context override: do not let AF3 Home buttons replace episode focus with parent tvshow
# -----------------------------------------------------------------------------
def current_context_item():
    if core.player_context_active():
        item = core.player_item()
        if core.valid_library_item(item):
            return "player", item

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus

    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        # When AF3 Home focus is on Play/More Options, TMDbHelper often exposes
        # the parent tvshow while the visible panel is an episode. Publishing that
        # parent causes exactly the wrong episode/series rating. Keep last valid
        # row until a strong visual/list/player identity is available.
        if core.af3_home_action_button_focused() and str(tmdb_identity.get("type") or "").lower() == "tvshow":
            return "identity_missing", {}
        return "tmdbhelper", tmdb_identity

    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}



# -----------------------------------------------------------------------------
# v1.3.78 context override: AF3 visual item wins; TMDbHelper cannot override
# Home/Hub buttons or category tabs with stale media.
# -----------------------------------------------------------------------------
def current_context_item():
    if core.player_context_active():
        item = core.player_item()
        if core.valid_library_item(item):
            return "player", item

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    # In AF3 Home/Hub the focused control can be a button/tab while the visual
    # item is drawn from a widget/spotlight container. Read that container first.
    if core.af3_hub_window_active():
        visual = core.af3_visual_item()
        if core.valid_library_item(visual):
            return "af3_visual", visual
        active = core.lrs_active_item()
        if core.valid_library_item(active):
            return "lrs_active", active
        hub_focus = core.hub_focus_container_item()
        if core.valid_library_item(hub_focus):
            return "hub", hub_focus
        # If focus is on a Home/Hub button or selector and the visual resolver is
        # empty, keep the previous published row. Do not let stale TMDbHelper or
        # stale ListItem values overwrite the current background/title.
        if core.af3_button_or_selector_focused():
            return "identity_missing", {}
        item = core.selected_library_item()
        if core.valid_library_item(item):
            return "listitem", item
        hub_item = core.hub_primary_item()
        if core.valid_library_item(hub_item):
            return "hub_fallback", hub_item
        return "identity_missing", {}

    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus

    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity

    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}

AUTO_LIBRARY_SCAN_FINISHED_AT = 0.0

class LRSAutoMonitor(xbmc.Monitor):
    def onScanFinished(self, library):  # pylint: disable=invalid-name
        global AUTO_LIBRARY_SCAN_FINISHED_AT
        try:
            if str(library or "").lower() in ("video", "") and core.bool_setting("auto_scrape_new_items_after_library_update", False):
                AUTO_LIBRARY_SCAN_FINISHED_AT = time.time() + 10.0
                core.log("Auto scrape scheduled after video library scan", xbmc.LOGINFO)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("Auto scrape schedule failed: {0}".format(exc), xbmc.LOGWARNING)

def main():
    global AUTO_LIBRARY_SCAN_FINISHED_AT
    monitor = LRSAutoMonitor()
    cache = core.load_cache()
    cache_mtime = core.cache_db_mtime()
    state = load_state()
    queue = []
    queued = set()
    previous_key = ""
    preloaded_key = ""
    preloaded_cache = {}
    next_lookup_at = 0.0
    manual_job = None
    compatibility = core.bool_setting("publish_af3_cache", True)
    core.clear_af3_properties(compatibility)
    core.reset_stale_background_on_service_start()
    core.log("Library Ratings Scraper service started", xbmc.LOGINFO)

    while not monitor.abortRequested():
        now = time.time()
        if core.consume_background_force_stop():
            queue = []
            queued = set()
            if manual_job is not None:
                force_stop_job(manual_job)
                manual_job = None
                cache = core.load_cache()
            notify("Force stop background", xbmcgui.NOTIFICATION_WARNING, 5000)
            previous_key = ""
            preloaded_key = ""
            preloaded_cache = {}

        latest_cache_mtime = core.cache_db_mtime()
        # v1.3.65: Do not reload the in-memory scrape cache from disk while a
        # manual scrape is running. The service itself writes ratings-cache.db
        # every save_every items. Older builds saw their own DB mtime change,
        # reloaded from disk before the next item, and discarded unsaved rows
        # between save points. That is why the DB contained movie|1..10 then
        # movie|20, movie|30, movie|40, etc.
        if manual_job is None:
            if latest_cache_mtime and latest_cache_mtime != cache_mtime:
                try:
                    cache = core.load_cache()
                    # load_cache may touch schema/meta and update file mtime;
                    # store the post-load mtime, not the stale value read before.
                    cache_mtime = core.cache_db_mtime()
                    previous_key = ""
                except Exception as exc:  # pylint: disable=broad-except
                    core.log("Cache reload after external update failed: {0}".format(exc), xbmc.LOGWARNING)
            elif not latest_cache_mtime and cache_mtime:
                # User deleted ratings-cache.db while Kodi/service was still running.
                # Do not keep the old in-memory cache and write it back again.
                cache = {"version": core.CACHE_VERSION, "updated_at": "", "backend": "sqlite-ratings-only", "items": {}}
                cache_mtime = 0.0
                previous_key = ""
                preloaded_cache = {}
                core.clear_af3_properties(compatibility)
                core.log("ratings-cache.db disappeared; cleared in-memory LRS cache", xbmc.LOGWARNING)

        context, item = current_context_item()
        try:
            if context != "screensaver":
                # v1.5.23: on AF3 Home/Hub, preload cached records for current, left,
                # and right widget items so a left/right focus move can publish from
                # memory without clearing the visible row first.
                preloaded_cache = homehub_neighbor_prefetch_1523(cache, item, context, state, radius=1)
                preloaded_key = core.identity_key(item) if preloaded_cache else ""
        except Exception as exc:  # pylint: disable=broad-except
            try:
                core.log("Home/Hub neighbor prefetch update failed: {0}".format(exc), xbmc.LOGWARNING)
            except Exception:
                pass
        if context == "screensaver":
            try:
                core.update_screensaver_clearlogo_properties(item)
            except Exception as exc:  # pylint: disable=broad-except
                core.log("Screensaver clearlogo mode update failed: {0}".format(exc), xbmc.LOGWARNING)
        else:
            try:
                core.clear_screensaver_clearlogo_properties()
            except Exception:
                pass
        previous_key = publish_current(cache, item, previous_key, context, state, preloaded_cache)

        request = core.consume_background_request()
        if request:
            if manual_job is not None:
                notify("Previous background process is still running", xbmcgui.NOTIFICATION_WARNING, 5000)
            elif request.get("action") == "top250":
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                manual_job = new_top250_job(request)
            else:
                # Always reload from disk when a manual scrape starts. If user has
                # deleted ratings-cache.db, this starts from an empty cache instead
                # of the old service RAM cache.
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                manual_job = new_scrape_job(request)

        # Optional auto scrape after Kodi video library scan completes.
        if manual_job is None and AUTO_LIBRARY_SCAN_FINISHED_AT and time.time() >= AUTO_LIBRARY_SCAN_FINISHED_AT:
            AUTO_LIBRARY_SCAN_FINISHED_AT = 0.0
            if core.bool_setting("auto_scrape_new_items_after_library_update", False):
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                auto_request = {"action": "scrape", "force": False, "requested_at": core.now_iso()}
                manual_job = new_scrape_job(auto_request)
                notify("Auto scrape missing data queued after library update", xbmcgui.NOTIFICATION_INFO, 5000)

        # Manual-only: focus changes never queue online scraping.

        # Screensaver one-item cache preload only. No online scrape is queued here.
        # This simply resolves current/next slide identity against the in-memory LRS
        # cache so the next publish can happen immediately after the slide changes.
        if xbmc.getCondVisibility("System.ScreenSaverActive"):
            upcoming = {}
            for offset in (1, 2, -1):
                candidate = core.screensaver_item(offset)
                if core.valid_library_item(candidate):
                    upcoming = candidate
                    break
            upcoming_key = core.identity_key(upcoming) if core.valid_library_item(upcoming) else ""
            if upcoming_key and upcoming_key != preloaded_key:
                preloaded_key = upcoming_key
                record = core.cache_record(cache, upcoming)
                preloaded_cache = {upcoming_key: record} if record else {}
                context_log(state, "screensaver", upcoming_key, upcoming.get("title"), bool(record), "preload_cache_hit" if record else "preload_cache_miss")
        else:
            preloaded_key = ""
            preloaded_cache = {}

        # Manual-only: no automatic refresh, no automatic Top 250 sync.

        # Manual library scrape has priority but executes inside this background
        # service. Kodi's UI remains usable and DialogProgressBG appears only in
        # the notification area.
        if manual_job is not None:
            if advance_job(manual_job, cache):
                manual_job = None
                cache_mtime = core.cache_db_mtime()
                previous_key = ""
            else:
                # save_cache may have run inside advance_scrape; keep this mtime
                # synchronized so the next non-manual loop does not treat our own
                # write as an external DB replacement.
                cache_mtime = core.cache_db_mtime() or cache_mtime
        # Strict manual-only mode: no focus/screensaver/idle item is ever
        # resolved online here. Online scraping only happens from explicit
        # menu actions that create manual_job.

        wait_seconds = lrs_service_wait_seconds(context, item, manual_job, queue)
        monitor.waitForAbort(wait_seconds)

    if manual_job is not None and manual_job.get("progress") is not None:
        manual_job["progress"].close()
    core.clear_af3_properties(core.bool_setting("publish_af3_cache", True))
    core.log("Library Ratings Scraper service stopped", xbmc.LOGINFO)


# __main__ call moved to end by v1.3.90
# -----------------------------------------------------------------------------
# v1.3.86 final screensaver publish guard
# -----------------------------------------------------------------------------
def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}

    if not core.valid_library_item(item):
        context_log(state, context, previous_key or "", item.get("title") if isinstance(item, dict) else "", False, "identity_missing_keep_last_1386")
        return previous_key or ""

    active_key = core.identity_key(item)
    record = _record_from_cache(cache, item, preload)

    # Screensaver can start before the service has noticed an external DB/cache
    # update. Reload once before deciding the slide really has no LRS record.
    if not record and context in ("player", "screensaver"):
        try:
            fresh_cache = core.load_cache()
            record = _record_from_cache(fresh_cache, item, preload)
            if record:
                cache.clear(); cache.update(fresh_cache)
        except Exception:  # pylint: disable=broad-except
            record = None

    if not record:
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            # Clear for a real new media item with no cached row so stale ratings do not
            # remain visible. XML now reads Screensaver.* values, so this no longer
            # blanks valid slides that publish a moment later.
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "cache_miss_clear_new_media_1386")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "cache_miss_keep_last_1386")
        return previous_key or active_key

    if not core.context_matches_record(item, record):
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "strict_guard_clear_new_media_1386")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "strict_guard_keep_last_1386")
        return previous_key or active_key

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    try:
        core._lrs_log_publish_values(context, record, values)  # pylint: disable=protected-access
    except Exception:  # pylint: disable=broad-except
        pass
    core.publish_af3_properties(values, publish_key, compatibility)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), True, "cache_hit_1386")
    return active_key


# v1.3.88 awards-only relevant-key fix lives in core.py; service flow unchanged.


# -----------------------------------------------------------------------------
# v1.3.90 manual job flow: ratings first, then OMDb-only awards pass.
# -----------------------------------------------------------------------------
_new_scrape_job_1390_base = new_scrape_job

def new_scrape_job(request):
    job = _new_scrape_job_1390_base(request)
    if job.get("action") == "scrape":
        job["phase"] = "ratings"
        job["awards_after_ratings"] = True
        job["ratings_total"] = int(job.get("total") or len(job.get("items") or []))
    elif job.get("action") == "awards":
        job["phase"] = "awards"
    return job


def _start_omdb_awards_phase_1390(job, cache):
    core.save_cache(cache)
    all_items = core.library_items()
    awards_items = [item for item in all_items if core.media_setting_type(item.get("type")) in ("movie", "tvshow")]
    job["phase"] = "awards"
    job["action"] = "scrape"  # keep final summary as scrape/refresh all
    job["items"] = awards_items
    job["index"] = 0
    job["processed"] = 0
    job["total"] = len(awards_items)
    job["current"] = "Starting"
    job["awards_phase_started_at"] = core.now_iso()
    update_bg(job, "Starting")
    write_job_state(job)


def advance_scrape(job, cache):
    if time.time() < float(job.get("next_at") or 0):
        return False
    items = job.get("items") or []
    total = len(items)
    job["total"] = total
    job["processed"] = int(job.get("index") or 0)
    phase = job.get("phase") or ("awards" if job.get("action") == "awards" else "ratings")

    if job.get("index", 0) >= total:
        if job.get("awards_after_ratings") and phase == "ratings" and core.bool_setting("scrape_awards_wins", True):
            _start_omdb_awards_phase_1390(job, cache)
            return False
        finish_job(job, cache, False)
        return True

    handled = 0
    while job.get("index", 0) < total and handled < 100:
        item = items[job["index"]]
        job["index"] += 1
        job["processed"] = int(job.get("index") or 0)
        handled += 1
        key = core.item_key(item)
        existing = (cache.get("items") or {}).get(key) or {}
        label = item_label(item)
        job["current"] = ("Awards: " if phase == "awards" else "Ratings: ") + label

        try:
            if phase == "awards" or job.get("action") == "awards":
                # Awards pass is OMDb only. Missing mode skips already checked rows;
                # force refresh all rechecks every movie/show awards row.
                if existing and not job.get("force") and not core.record_missing_awards(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                cache.setdefault("items", {})[key] = core.resolve_awards_only(item, job.get("keys") or core.api_keys(), existing)
            else:
                if not job.get("force") and existing and not core.record_needs_update(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                cache.setdefault("items", {})[key] = core.resolve_item(item, job.get("keys") or core.api_keys(), existing, missing_only=not job.get("force"), include_local=False)
            job["updated"] += 1
            job["looked_up"] += 1
        except core.ProviderLimitReached as exc:
            message = "Stopped: {0} API limit reached".format(exc.provider)
            detail = str(exc)
            job["failed"] += 1
            job["current"] = message
            job["stopped_reason"] = message
            core.log("{0}. {1}".format(message, detail), xbmc.LOGWARNING)
            core.save_cache(cache)
            finish_job(job, cache, False, message)
            return True
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] += 1
            core.log("Background scrape failed for {0}: {1}".format(label, exc), xbmc.LOGWARNING)
        if job["index"] % max(1, core.int_setting("save_every", 10)) == 0:
            core.save_cache(cache)
        delay = max(0, core.int_setting("delay_ms", 1100)) / 1000.0
        job["next_at"] = time.time() + delay
        update_bg(job)
        write_job_state(job)
        return False

    job["processed"] = int(job.get("index") or 0)
    write_job_state(job)
    if job.get("index", 0) >= total:
        if job.get("awards_after_ratings") and phase == "ratings" and core.bool_setting("scrape_awards_wins", True):
            _start_omdb_awards_phase_1390(job, cache)
            return False
        finish_job(job, cache, False)
        return True
    return False



# -----------------------------------------------------------------------------
# v1.3.93 manual job flow: ratings -> awards -> Rotten Tomatoes detail badges.
# -----------------------------------------------------------------------------
_new_scrape_job_1393_base = new_scrape_job


def _rtbadge_items_1393():
    # Global TV-show scores often represent a different RT season/page and the
    # Certified/Verified badge semantics are not reliable at show level.
    return [item for item in core.library_items() if core.media_setting_type(item.get("type")) == "movie"]


def new_scrape_job(request):
    action = request.get("action") or "scrape"
    if action == "rtbadges":
        items = _rtbadge_items_1393()
        progress = xbmcgui.DialogProgressBG()
        progress.create(TITLE, "0/0 STARTING - RT BADGES")
        try:
            core.start_rt_badge_report_1393("rtbadges")
        except Exception:  # pylint: disable=broad-except
            pass
        job = {
            "action": "rtbadges",
            "phase": "rtbadges",
            "force": bool(request.get("force")),
            "requested_at": request.get("requested_at") or core.now_iso(),
            "started_at": core.now_iso(),
            "items": items,
            "keys": core.api_keys(),
            "index": 0,
            "updated": 0,
            "matched": 0,
            "processed": 0,
            "total": len(items),
            "skipped": 0,
            "failed": 0,
            "looked_up": 0,
            "current": "Preparing RT badges...",
            "next_at": 0.0,
            "progress": progress,
            "status": "running",
            "report": getattr(core, "RT_BADGE_REPORT_FILE", ""),
        }
        write_job_state(job)
        notify("Rotten Tomatoes badge sync running", xbmcgui.NOTIFICATION_INFO, 5000)
        return job

    job = _new_scrape_job_1393_base(request)
    if job.get("action") == "scrape":
        job["rtbadges_after_previous"] = True
    return job


def _start_rt_badges_phase_1393(job, cache):
    core.save_cache(cache)
    items = _rtbadge_items_1393()
    try:
        core.start_rt_badge_report_1393("after_" + str(job.get("action") or "scrape"))
    except Exception:  # pylint: disable=broad-except
        pass
    job["phase"] = "rtbadges"
    job["action"] = "scrape" if job.get("action") != "rtbadges" else "rtbadges"
    job["items"] = items
    job["index"] = 0
    job["processed"] = 0
    job["total"] = len(items)
    job["current"] = "Starting"
    job["rtbadges_phase_started_at"] = core.now_iso()
    update_bg(job, "Starting")
    write_job_state(job)


def _finish_or_start_rtbadges_1393(job, cache, phase):
    if job.get("rtbadges_after_previous") and phase in ("ratings", "awards"):
        # If ratings finished, awards phase still has priority when enabled.
        if phase == "ratings" and job.get("awards_after_ratings") and core.bool_setting("scrape_awards_wins", True):
            _start_omdb_awards_phase_1390(job, cache)
            return False
        _start_rt_badges_phase_1393(job, cache)
        return False
    finish_job(job, cache, False)
    return True


def advance_scrape(job, cache):
    if time.time() < float(job.get("next_at") or 0):
        return False
    items = job.get("items") or []
    total = len(items)
    job["total"] = total
    job["processed"] = int(job.get("index") or 0)
    phase = job.get("phase") or ("awards" if job.get("action") == "awards" else ("rtbadges" if job.get("action") == "rtbadges" else "ratings"))

    if job.get("index", 0) >= total:
        return _finish_or_start_rtbadges_1393(job, cache, phase)

    handled = 0
    while job.get("index", 0) < total and handled < 100:
        item = items[job["index"]]
        job["index"] += 1
        job["processed"] = int(job.get("index") or 0)
        handled += 1
        key = core.item_key(item)
        existing = (cache.get("items") or {}).get(key) or {}
        label = item_label(item)
        prefix = "RT Badges: " if phase == "rtbadges" else ("Awards: " if phase == "awards" else "Ratings: ")
        job["current"] = prefix + label

        try:
            if phase == "rtbadges" or job.get("action") == "rtbadges":
                if existing and not bool(job.get("force")) and not core.record_missing_rt_badge(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                updated_entry = core.resolve_rt_badge_only(item, job.get("keys") or core.api_keys(), existing, force=bool(job.get("force")))
                cache.setdefault("items", {})[key] = updated_entry
            elif phase == "awards" or job.get("action") == "awards":
                if existing and not job.get("force") and not core.record_missing_awards(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                cache.setdefault("items", {})[key] = core.resolve_awards_only(item, job.get("keys") or core.api_keys(), existing)
            else:
                if not job.get("force") and existing and not core.record_needs_update(item, existing):
                    job["skipped"] += 1
                    update_bg(job)
                    continue
                cache.setdefault("items", {})[key] = core.resolve_item(item, job.get("keys") or core.api_keys(), existing, missing_only=not job.get("force"), include_local=False)
            job["updated"] += 1
            job["looked_up"] += 1
            if phase == "rtbadges":
                job["matched"] += 1
        except core.ProviderLimitReached as exc:
            message = "Stopped: {0} API limit reached".format(exc.provider)
            detail = str(exc)
            job["failed"] += 1
            job["current"] = message
            job["stopped_reason"] = message
            core.log("{0}. {1}".format(message, detail), xbmc.LOGWARNING)
            core.save_cache(cache)
            finish_job(job, cache, False, message)
            return True
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] += 1
            core.log("Background {0} failed for {1}: {2}".format(phase, label, exc), xbmc.LOGWARNING)
        if job["index"] % max(1, core.int_setting("save_every", 10)) == 0:
            core.save_cache(cache)
        delay = max(0, core.int_setting("delay_ms", 1100)) / 1000.0
        job["next_at"] = time.time() + delay
        update_bg(job)
        write_job_state(job)
        return False

    job["processed"] = int(job.get("index") or 0)
    write_job_state(job)
    if job.get("index", 0) >= total:
        return _finish_or_start_rtbadges_1393(job, cache, phase)
    return False

# __main__ call moved to true end by v1.3.99.

# -----------------------------------------------------------------------------
# v1.3.97 uniform progress text
# -----------------------------------------------------------------------------
def _phase_label_1397(job):
    phase = str((job or {}).get("phase") or "").strip().lower()
    action = str((job or {}).get("action") or "").strip().lower()
    if phase == "rtbadges" or action == "rtbadges":
        return "rt badges"
    if phase == "awards" or action == "awards":
        return "awards"
    if phase == "top250" or action == "top250":
        return "top250"
    return "ratings"


def _clean_current_1397(value):
    text = str(value or "Starting").replace("\n", " ").strip()
    for prefix in ("Ratings: ", "Awards: ", "RT Badges: ", "RT badges: ", "Top250: "):
        if text.startswith(prefix):
            return text[len(prefix):].strip() or "Starting"
    return text or "Starting"


def update_bg(job, message=None):
    progress = job.get("progress")
    if progress is None:
        return
    total = int(job.get("total") or len(job.get("items") or []))
    processed = int(job.get("processed") or job.get("index") or 0)
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    phase = _phase_label_1397(job)
    title = _clean_current_1397(message if message is not None else job.get("current"))
    # Keep the DialogProgressBG body to one short line. Long movie titles make
    # AF3/Kodi notifications wrap and feel heavy, so truncate only the title.
    title = compact_text(title, 28)
    text = "{0}/{1} {2} - {3}".format(processed, total, phase, title)
    progress.update(percent, TITLE, compact_text(text, 50))



# -----------------------------------------------------------------------------
# v1.4.2 - auto scrape only newly added library items, no fixed delay
# -----------------------------------------------------------------------------
AUTO_LIBRARY_SCAN_STARTED_KEYS = set()
AUTO_LIBRARY_SCAN_PENDING = None


def _library_key_snapshot_1420():
    try:
        return set(core.item_key(item) for item in core.library_items() if core.resolvable_library_item(item))
    except Exception as exc:  # pylint: disable=broad-except
        core.log("Auto scrape library snapshot failed: {0}".format(exc), xbmc.LOGDEBUG)
        return set()


def _auto_new_items_after_scan_1420(cache, before_keys):
    items = core.library_items()
    cache_keys = set((cache.get("items") or {}).keys())
    before_keys = set(before_keys or [])
    selected = []
    seen = set()
    for item in items:
        if not core.resolvable_library_item(item):
            continue
        key = core.item_key(item)
        if not key or key in seen:
            continue
        is_new_from_scan = bool(before_keys) and key not in before_keys
        if is_new_from_scan:
            selected.append(item)
            seen.add(key)
    return selected


def _new_scoped_scrape_job_1420(request, items):
    action = request.get("action") or "scrape"
    awards_only = action == "awards"
    items = list(items or [])
    if awards_only:
        items = [item for item in items if core.media_setting_type(item.get("type")) in ("movie", "tvshow")]
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, "0/0 STARTING - AWARDS" if awards_only else "0/0 STARTING - RATINGS")
    job = {
        "action": action,
        "phase": "awards" if awards_only else "ratings",
        "awards_only": awards_only,
        "awards_after_ratings": action == "scrape",
        "rtbadges_after_previous": action == "scrape",
        "force": bool(request.get("force")),
        "requested_at": request.get("requested_at") or core.now_iso(),
        "started_at": core.now_iso(),
        "items": items,
        "scope_items": list(items),
        "auto_new_only": bool(request.get("auto_new_only")),
        "keys": core.api_keys(),
        "index": 0,
        "updated": 0,
        "matched": 0,
        "processed": 0,
        "total": len(items),
        "skipped": 0,
        "failed": 0,
        "looked_up": 0,
        "current": "Preparing...",
        "next_at": 0.0,
        "progress": progress,
        "status": "running",
    }
    write_job_state(job)
    return job


_new_scrape_job_1420_base = new_scrape_job

def new_scrape_job(request):
    scoped_items = request.get("items") if isinstance(request, dict) else None
    if scoped_items is not None:
        return _new_scoped_scrape_job_1420(request, scoped_items)
    return _new_scrape_job_1420_base(request)


_start_omdb_awards_phase_1390_base_1420 = _start_omdb_awards_phase_1390

def _start_omdb_awards_phase_1390(job, cache):
    core.save_cache(cache)
    source_items = list(job.get("scope_items") or [])
    if not source_items:
        source_items = core.library_items()
    awards_items = [item for item in source_items if core.media_setting_type(item.get("type")) in ("movie", "tvshow")]
    job["phase"] = "awards"
    job["action"] = "scrape"
    job["items"] = awards_items
    job["index"] = 0
    job["processed"] = 0
    job["total"] = len(awards_items)
    job["current"] = "Starting"
    job["awards_phase_started_at"] = core.now_iso()
    update_bg(job, "Starting")
    write_job_state(job)


_start_rt_badges_phase_1393_base_1420 = _start_rt_badges_phase_1393

def _start_rt_badges_phase_1393(job, cache):
    core.save_cache(cache)
    source_items = list(job.get("scope_items") or [])
    if source_items:
        items = [item for item in source_items if core.media_setting_type(item.get("type")) == "movie"]
    else:
        items = _rtbadge_items_1393()
    try:
        core.start_rt_badge_report_1393("after_" + str(job.get("action") or "scrape"))
    except Exception:  # pylint: disable=broad-except
        pass
    job["phase"] = "rtbadges"
    job["action"] = "scrape" if job.get("action") != "rtbadges" else "rtbadges"
    job["items"] = items
    job["index"] = 0
    job["processed"] = 0
    job["total"] = len(items)
    job["current"] = "Starting"
    job["rtbadges_phase_started_at"] = core.now_iso()
    update_bg(job, "Starting")
    write_job_state(job)


_finish_job_1420_base = finish_job

def finish_job(job, cache, canceled=False, stopped_reason=""):
    # For auto-new-item jobs, never run the full-library Top250 sync at finish.
    # The job is intentionally scoped to only the newly added Kodi items.
    if not job.get("auto_new_only"):
        return _finish_job_1420_base(job, cache, canceled, stopped_reason)

    job["status"] = "finishing"
    write_job_state(job, "finishing")
    update_bg(job, "Saving cache...")
    core.save_cache(cache)
    update_bg(job, "Exporting CSV report...")
    report = core.export_csv(core.load_cache())
    job["report"] = report
    summary = {
        "started_at": job.get("started_at"),
        "finished_at": core.now_iso(),
        "items_total": int(job.get("total") or len(job.get("items") or [])),
        "matched": int(job.get("matched") or 0),
        "updated": int(job.get("updated") or 0),
        "skipped": int(job.get("skipped") or 0),
        "failed": int(job.get("failed") or 0),
        "online_lookups": int(job.get("looked_up") or 0),
        "report": report,
        "canceled": bool(canceled),
        "stopped_reason": stopped_reason or "",
        "action": "auto_scrape_new_items",
    }
    core.save_summary(summary)
    job["finished_at"] = summary["finished_at"]
    job["status"] = "canceled" if canceled else ("stopped" if stopped_reason else "completed")
    job["current"] = "Canceled" if canceled else (stopped_reason or "Finished")
    if job.get("progress") is not None:
        job["progress"].close()
    write_job_state(job, job["status"])
    if stopped_reason:
        notify(stopped_reason, xbmcgui.NOTIFICATION_WARNING, 8000)
    elif canceled:
        notify("Auto scrape canceled", xbmcgui.NOTIFICATION_WARNING, 6000)
    else:
        notify("Auto scrape new items completed", xbmcgui.NOTIFICATION_INFO, 5000)


# Replace the monitor/main pair so auto scrape starts immediately after Kodi scan
# and targets only scan-new items. If Kodi DB is locked/not ready, retry briefly.
class LRSAutoMonitor(xbmc.Monitor):
    def onScanStarted(self, library):  # pylint: disable=invalid-name
        global AUTO_LIBRARY_SCAN_STARTED_KEYS, AUTO_LIBRARY_SCAN_ADDED_CANDIDATES_1620, AUTO_LIBRARY_SCAN_LATE_ACTIVE_1620
        try:
            if str(library or "").lower() in ("video", "") and core.bool_setting("auto_scrape_new_items_after_library_update", False):
                if AUTO_LIBRARY_SCAN_LATE_ACTIVE_1620 and xbmc.getCondVisibility("Library.IsScanningVideo"):
                    core.log("Duplicate scan-start ignored after late-start snapshot", xbmc.LOGINFO)
                    return
                AUTO_LIBRARY_SCAN_LATE_ACTIVE_1620 = False
                AUTO_LIBRARY_SCAN_ADDED_CANDIDATES_1620 = set()
                AUTO_LIBRARY_SCAN_STARTED_KEYS = _library_key_snapshot_1420()
                core.log("Auto scrape snapshot before video library scan: {0} items".format(len(AUTO_LIBRARY_SCAN_STARTED_KEYS)), xbmc.LOGINFO)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("Auto scrape scan-start snapshot failed: {0}".format(exc), xbmc.LOGWARNING)
            AUTO_LIBRARY_SCAN_STARTED_KEYS = set()

    def onNotification(self, sender, method, data):  # pylint: disable=invalid-name
        global AUTO_LIBRARY_SCAN_ADDED_CANDIDATES_1620
        if method != "VideoLibrary.OnUpdate" or not core.bool_setting("auto_scrape_new_items_after_library_update", False):
            return
        try:
            payload = json.loads(data or "{}") if not isinstance(data, dict) else data
            item = payload.get("item") or {}
            if not bool(payload.get("added")):
                return
            media = core.media_setting_type(item.get("type"))
            dbid = core.safe_int(item.get("id"))
            if media in ("movie", "tvshow", "episode") and dbid is not None:
                key = "{0}|{1}".format(media, dbid)
                AUTO_LIBRARY_SCAN_ADDED_CANDIDATES_1620.add(key)
                core.log("Auto scrape journaled Kodi added candidate: {0}".format(key), xbmc.LOGINFO)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("Auto scrape added-candidate journal failed: {0}".format(exc), xbmc.LOGWARNING)

    def onScanFinished(self, library):  # pylint: disable=invalid-name
        global AUTO_LIBRARY_SCAN_PENDING, AUTO_LIBRARY_SCAN_ADDED_CANDIDATES_1620, AUTO_LIBRARY_SCAN_LATE_ACTIVE_1620
        try:
            if str(library or "").lower() in ("video", "") and core.bool_setting("auto_scrape_new_items_after_library_update", False):
                AUTO_LIBRARY_SCAN_PENDING = {
                    "before_keys": list(AUTO_LIBRARY_SCAN_STARTED_KEYS or []),
                    "snapshot_captured": bool(AUTO_LIBRARY_SCAN_SNAPSHOT_CAPTURED_1620),
                    "candidate_keys": sorted(AUTO_LIBRARY_SCAN_ADDED_CANDIDATES_1620),
                    "next_at": time.time(),
                    "attempts": 0,
                }
                AUTO_LIBRARY_SCAN_ADDED_CANDIDATES_1620 = set()
                AUTO_LIBRARY_SCAN_LATE_ACTIVE_1620 = False
                core.log("Auto scrape queued immediately after video library scan; mode={0}; candidates={1}".format(
                    "snapshot" if AUTO_LIBRARY_SCAN_PENDING.get("snapshot_captured") else "added-journal",
                    len(AUTO_LIBRARY_SCAN_PENDING.get("candidate_keys") or [])), xbmc.LOGINFO)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("Auto scrape schedule failed: {0}".format(exc), xbmc.LOGWARNING)


def _consume_auto_scan_job_1420(cache):
    global AUTO_LIBRARY_SCAN_PENDING
    pending = AUTO_LIBRARY_SCAN_PENDING
    if not pending:
        return None
    if time.time() < float(pending.get("next_at") or 0):
        return None
    pending["attempts"] = int(pending.get("attempts") or 0) + 1
    try:
        before_keys = pending.get("before_keys") or []
        snapshot_captured = bool(pending.get("snapshot_captured"))
        candidate_keys = pending.get("candidate_keys") or []
        if not snapshot_captured and not candidate_keys:
            AUTO_LIBRARY_SCAN_PENDING = None
            core.log("Auto scrape skipped: no scan snapshot and no Kodi added candidates", xbmc.LOGINFO)
            return None
        items = _auto_new_items_after_scan_1420(
            cache, before_keys, candidate_keys=candidate_keys,
            snapshot_captured=snapshot_captured)
    except Exception as exc:  # pylint: disable=broad-except
        text = str(exc).lower()
        if ("locked" in text or "busy" in text) and pending["attempts"] < 10:
            pending["next_at"] = time.time() + 2.0
            AUTO_LIBRARY_SCAN_PENDING = pending
            core.log("Auto scrape waiting for Kodi library DB: {0}".format(exc), xbmc.LOGINFO)
            return None
        AUTO_LIBRARY_SCAN_PENDING = None
        core.log("Auto scrape new-item detection failed: {0}".format(exc), xbmc.LOGWARNING)
        return None
    AUTO_LIBRARY_SCAN_PENDING = None
    if not items:
        core.log("Auto scrape skipped: no newly added video items found", xbmc.LOGINFO)
        return None
    return new_scrape_job({
        "action": "scrape",
        "force": False,
        "items": items,
        "auto_new_only": True,
        "requested_at": core.now_iso(),
    })


def main():
    monitor = LRSAutoMonitor()
    cache = core.load_cache()
    cache_mtime = core.cache_db_mtime()
    state = load_state()
    queue = []
    queued = set()
    previous_key = ""
    preloaded_key = ""
    preloaded_cache = {}
    manual_job = None
    compatibility = core.bool_setting("publish_af3_cache", True)
    core.clear_af3_properties(compatibility)
    core.reset_stale_background_on_service_start()
    core.log("Library Ratings Scraper service started", xbmc.LOGINFO)

    while not monitor.abortRequested():
        if core.consume_background_force_stop():
            queue = []
            queued = set()
            if manual_job is not None:
                force_stop_job(manual_job)
                manual_job = None
                cache = core.load_cache()
            notify("Force stop background", xbmcgui.NOTIFICATION_WARNING, 5000)
            previous_key = ""
            preloaded_key = ""
            preloaded_cache = {}

        latest_cache_mtime = core.cache_db_mtime()
        if manual_job is None:
            if latest_cache_mtime and latest_cache_mtime != cache_mtime:
                try:
                    cache = core.load_cache()
                    cache_mtime = core.cache_db_mtime()
                    previous_key = ""
                except Exception as exc:  # pylint: disable=broad-except
                    core.log("Cache reload after external update failed: {0}".format(exc), xbmc.LOGWARNING)
            elif not latest_cache_mtime and cache_mtime:
                cache = {"version": core.CACHE_VERSION, "updated_at": "", "backend": "sqlite-ratings-only", "items": {}}
                cache_mtime = 0.0
                previous_key = ""
                preloaded_cache = {}
                core.clear_af3_properties(compatibility)
                core.log("ratings-cache.db disappeared; cleared in-memory LRS cache", xbmc.LOGWARNING)

        context, item = current_context_item()
        try:
            if context != "screensaver":
                # v1.5.23: on AF3 Home/Hub, preload cached records for current, left,
                # and right widget items so a left/right focus move can publish from
                # memory without clearing the visible row first.
                preloaded_cache = homehub_neighbor_prefetch_1523(cache, item, context, state, radius=1)
                preloaded_key = core.identity_key(item) if preloaded_cache else ""
        except Exception as exc:  # pylint: disable=broad-except
            try:
                core.log("Home/Hub neighbor prefetch update failed: {0}".format(exc), xbmc.LOGWARNING)
            except Exception:
                pass
        if context == "screensaver":
            try:
                core.update_screensaver_clearlogo_properties(item)
            except Exception as exc:  # pylint: disable=broad-except
                core.log("Screensaver clearlogo mode update failed: {0}".format(exc), xbmc.LOGWARNING)
        else:
            try:
                core.clear_screensaver_clearlogo_properties()
            except Exception:
                pass
        previous_key = publish_current(cache, item, previous_key, context, state, preloaded_cache)

        request = core.consume_background_request()
        if request:
            if manual_job is not None:
                notify("Previous background process is still running", xbmcgui.NOTIFICATION_WARNING, 5000)
            elif request.get("action") == "top250":
                cache = core.load_cache(); cache_mtime = core.cache_db_mtime(); manual_job = new_top250_job(request)
            else:
                cache = core.load_cache(); cache_mtime = core.cache_db_mtime(); manual_job = new_scrape_job(request)

        if manual_job is None:
            auto_job = _consume_auto_scan_job_1420(cache)
            if auto_job is not None:
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                manual_job = auto_job

        if xbmc.getCondVisibility("System.ScreenSaverActive"):
            upcoming = {}
            for offset in (1, 2, -1):
                candidate = core.screensaver_item(offset)
                if core.valid_library_item(candidate):
                    upcoming = candidate
                    break
            upcoming_key = core.identity_key(upcoming) if core.valid_library_item(upcoming) else ""
            if upcoming_key and upcoming_key != preloaded_key:
                preloaded_key = upcoming_key
                record = core.cache_record(cache, upcoming)
                preloaded_cache = {upcoming_key: record} if record else {}
                context_log(state, "screensaver", upcoming_key, upcoming.get("title"), bool(record), "preload_cache_hit" if record else "preload_cache_miss")
        else:
            try:
                if not core.af3_hub_window_active():
                    preloaded_key = ""
                    preloaded_cache = {}
            except Exception:
                preloaded_key = ""
                preloaded_cache = {}

        if manual_job is not None:
            try:
                job_done = advance_job(manual_job, cache)
            except Exception as exc:  # pylint: disable=broad-except
                core.log("Background ratings job failed: {0}".format(exc), xbmc.LOGERROR)
                core.log(traceback.format_exc(), xbmc.LOGERROR)
                manual_job["failed"] = int(manual_job.get("failed") or 0) + 1
                manual_job["status"] = "error"
                manual_job["current"] = "ERROR"
                manual_job["finished_at"] = core.now_iso()
                progress = manual_job.get("progress")
                if progress is not None:
                    try:
                        progress.close()
                    except Exception:
                        pass
                write_job_state(manual_job, "error")
                notify("RATINGS FAILED - {0} ERROR".format(manual_job["failed"]), xbmcgui.NOTIFICATION_ERROR, 8000)
                manual_job = None
                try:
                    _release_auto_lock_1530()
                except Exception:
                    pass
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                previous_key = ""
            else:
                if job_done:
                    manual_job = None
                    cache_mtime = core.cache_db_mtime()
                    previous_key = ""
                else:
                    cache_mtime = core.cache_db_mtime() or cache_mtime

        wait_seconds = lrs_service_wait_seconds(context, item, manual_job, queue)
        monitor.waitForAbort(wait_seconds)

    if manual_job is not None and manual_job.get("progress") is not None:
        manual_job["progress"].close()
    core.clear_af3_properties(core.bool_setting("publish_af3_cache", True))
    core.log("Library Ratings Scraper service stopped", xbmc.LOGINFO)


# -----------------------------------------------------------------------------
# v1.4.3 - non-library external focus cache
# -----------------------------------------------------------------------------
EXTERNAL_FOCUS_PENDING = {}
EXTERNAL_FOCUS_LAST_KEY = ""
EXTERNAL_FOCUS_LAST_SEEN = 0.0
EXTERNAL_FOCUS_BUSY = False


def _external_focus_enabled_1430():
    # Keep this always available for AF3 Popular/non-library widgets. It only
    # fetches a single focused released item after debounce.
    return True


def _external_focus_key_1430(item):
    try:
        if not core.valid_library_item(item) or core.resolvable_library_item(item):
            return ""
        media = core.media_setting_type(item.get("type"))
        if media not in ("movie", "tvshow"):
            return ""
        return core.external_item_key_1430(item)
    except Exception:
        return ""


# Keep a real function-object reference to the original helper.  Do not wrap it
# by name, because the name is replaced below; wrapping by name causes recursion.
_record_from_cache_1430_base = _record_from_cache

# Replace helper used by publish_current: library cache first, then external cache.
def _record_from_cache(cache, item, preload=None):
    record = _record_from_cache_1430_base(cache, item, preload)
    if record:
        return record
    try:
        if _external_focus_key_1430(item):
            return core.load_external_record_1430(item)
    except Exception as exc:  # pylint: disable=broad-except
        core.log("External focus cache read failed: {0}".format(exc), xbmc.LOGWARNING)
    return {}


_publish_current_1430_base = publish_current

def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    global EXTERNAL_FOCUS_PENDING, EXTERNAL_FOCUS_LAST_KEY, EXTERNAL_FOCUS_LAST_SEEN
    result_key = _publish_current_1430_base(cache, item, previous_key, context, state, preload)
    try:
        key = _external_focus_key_1430(item)
        if not key or not _external_focus_enabled_1430():
            return result_key
        # If external item has no cached data yet, clear LRS row for this item
        # instead of keeping stale library ratings from previous focus.
        rec = core.load_external_record_1430(item)
        if not rec:
            core.publish_af3_properties({}, key, core.bool_setting("publish_af3_cache", True))
        now = time.time()
        if key != EXTERNAL_FOCUS_LAST_KEY:
            EXTERNAL_FOCUS_LAST_KEY = key
            EXTERNAL_FOCUS_LAST_SEEN = now
        # Debounce fast scroll: fetch only if focus remains stable.
        if not rec and now - EXTERNAL_FOCUS_LAST_SEEN >= 0.65 and core.external_item_released_1430(item):
            EXTERNAL_FOCUS_PENDING = {"key": key, "item": dict(item), "queued_at": now}
    except Exception as exc:  # pylint: disable=broad-except
        core.log("External focus queue failed: {0}".format(exc), xbmc.LOGWARNING)
    return result_key


def _process_external_focus_1430():
    global EXTERNAL_FOCUS_PENDING, EXTERNAL_FOCUS_BUSY
    if EXTERNAL_FOCUS_BUSY or not EXTERNAL_FOCUS_PENDING:
        return False
    pending = EXTERNAL_FOCUS_PENDING
    EXTERNAL_FOCUS_PENDING = {}
    item = pending.get("item") or {}
    key = pending.get("key") or ""
    if not key or not core.valid_library_item(item) or core.resolvable_library_item(item):
        return False
    try:
        EXTERNAL_FOCUS_BUSY = True
        if core.load_external_record_1430(item):
            return False
        record = core.resolve_external_item_1430(item, core.api_keys())
        if record:
            values = core.af3_values(record)
            values["SourceContext"] = "external_focus"
            core.publish_af3_properties(values, core.record_item_key(record) or key, core.bool_setting("publish_af3_cache", True))
            core.log("External ratings cached: {0}".format(str(item.get("title") or "")[:80]), xbmc.LOGINFO)
            return True
    except core.ProviderLimitReached as exc:
        core.log("External ratings stopped: {0}".format(exc), xbmc.LOGWARNING)
    except Exception as exc:  # pylint: disable=broad-except
        core.log("External ratings lookup failed for {0}: {1}".format(str(item.get("title") or "")[:80], exc), xbmc.LOGWARNING)
    finally:
        EXTERNAL_FOCUS_BUSY = False
    return False


_main_1430_base = main

def main():
    # Small wrapper around the 1.4.2 main loop is not enough because the loop is
    # internal. Reuse it by monkey-patching monitor waits would be fragile, so we
    # keep external lookup opportunistic: process just before normal wait through
    # publish_current side effects in the same service thread. The base main calls
    # publish_current each tick; this wrapper runs a lightweight worker from a
    # timer in a companion thread-free callback by replacing POLL_SECONDS effect.
    # Simpler and safe: call the base main; external pending is processed inside
    # the overridden publish_current on the next stable tick when no manual job is
    # active is not visible here, so process immediately after debounce.
    return _main_1430_base()

# Process external pending from publish_current itself on the next call, but never
# in screensaver/player. This tiny hook is used by the overridden publish_current.
_publish_current_1430_with_worker_base = publish_current

def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    key = _publish_current_1430_with_worker_base(cache, item, previous_key, context, state, preload)
    try:
        if context not in ("player", "screensaver"):
            _process_external_focus_1430()
    except Exception:
        pass
    return key

# -----------------------------------------------------------------------------
# v1.4.5 - prefer library cache over external duplicate + faster external debounce
# -----------------------------------------------------------------------------

def _record_from_cache(cache, item, preload=None):
    # First use the original library-cache resolver captured before the external
    # wrapper. This prevents Popular/plugin items that match an existing library
    # movie from showing/storing duplicate external rows.
    try:
        record = _record_from_cache_1430_base(cache, item, preload)
        if record:
            return record
    except Exception:
        pass
    try:
        if _external_focus_key_1430(item):
            library_record = core.find_library_record_for_external_1450(item)
            if library_record:
                return library_record
            return core.load_external_record_1430(item)
    except Exception as exc:  # pylint: disable=broad-except
        core.log("External/library cache read failed: {0}".format(exc), xbmc.LOGWARNING)
    return {}


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    global EXTERNAL_FOCUS_PENDING, EXTERNAL_FOCUS_LAST_KEY, EXTERNAL_FOCUS_LAST_SEEN
    # Use the pre-external base publisher; it will call the _record_from_cache
    # override above, so library-by-title/ID matches still publish correctly.
    result_key = _publish_current_1430_base(cache, item, previous_key, context, state, preload)
    try:
        key = _external_focus_key_1430(item)
        if not key or not _external_focus_enabled_1430() or context in ("player", "screensaver"):
            return result_key
        # If the non-library widget item actually matches a library row, never
        # queue/save an external duplicate.
        if core.find_library_record_for_external_1450(item):
            return result_key
        rec = core.load_external_record_1430(item)
        if not rec:
            core.publish_af3_properties({}, key, core.bool_setting("publish_af3_cache", True))
        now = time.time()
        if key != EXTERNAL_FOCUS_LAST_KEY:
            EXTERNAL_FOCUS_LAST_KEY = key
            EXTERNAL_FOCUS_LAST_SEEN = now
        # Faster but still debounced: 0.25s stable focus, not 0.65s.
        if not rec and now - EXTERNAL_FOCUS_LAST_SEEN >= 0.25 and core.external_item_released_1430(item):
            EXTERNAL_FOCUS_PENDING = {"key": key, "item": dict(item), "queued_at": now}
            _process_external_focus_1430()
    except Exception as exc:  # pylint: disable=broad-except
        core.log("External focus queue failed: {0}".format(exc), xbmc.LOGWARNING)
    return result_key

# -----------------------------------------------------------------------------
# v1.4.6 - short progress text, no auto queued notification, clean-library hook
# -----------------------------------------------------------------------------
LRS_CLEAN_LIBRARY_PENDING = None


def _phase_label_1460(job):
    phase = str((job or {}).get("phase") or "").strip().lower()
    action = str((job or {}).get("action") or "").strip().lower()
    if phase == "rtbadges" or action == "rtbadges":
        return "RT BADGES"
    if phase == "awards" or action == "awards":
        return "AWARDS"
    if phase == "top250" or action == "top250":
        return "TOP250"
    return "RATINGS"


def _clean_current_1460(value):
    text = str(value or "STARTING").replace("\n", " ").strip()
    for prefix in ("Ratings: ", "Awards: ", "RT Badges: ", "RT badges: ", "Top250: ", "top250 - "):
        if text.startswith(prefix):
            text = text[len(prefix):].strip()
            break
    return text or "STARTING"


def update_bg(job, message=None):
    progress = job.get("progress")
    if progress is None:
        return
    total = int(job.get("total") or len(job.get("items") or []))
    processed = int(job.get("processed") or job.get("index") or 0)
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    phase = _phase_label_1460(job)
    title = _clean_current_1460(message if message is not None else job.get("current"))
    title = compact_text(title.upper(), 24)
    body = "{0}/{1} {2} - {3} - {4}%".format(processed, total, phase, title, percent)
    progress.update(percent, TITLE, compact_text(body, 58))


_LRSAutoMonitor_1460_base = LRSAutoMonitor

class LRSAutoMonitor(_LRSAutoMonitor_1460_base):
    def onScanFinished(self, library):  # pylint: disable=invalid-name
        # Keep base auto-new behavior, but no user-visible queued notification.
        try:
            return super().onScanFinished(library)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("Auto scrape schedule failed: {0}".format(exc), xbmc.LOGWARNING)
            return None

    def onCleanFinished(self, library):  # pylint: disable=invalid-name
        global LRS_CLEAN_LIBRARY_PENDING
        try:
            if str(library or "").lower() in ("video", ""):
                LRS_CLEAN_LIBRARY_PENDING = {"next_at": time.time(), "attempts": 0}
                core.log("LRS clean-library cleanup scheduled", xbmc.LOGINFO)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("LRS clean-library schedule failed: {0}".format(exc), xbmc.LOGWARNING)


def _consume_clean_library_job_1460():
    global LRS_CLEAN_LIBRARY_PENDING
    pending = LRS_CLEAN_LIBRARY_PENDING
    if not pending:
        return None
    if time.time() < float(pending.get("next_at") or 0):
        return None
    pending["attempts"] = int(pending.get("attempts") or 0) + 1
    try:
        if not pending.get("salvage_done"):
            salvage = core.salvage_dbid_handoffs_before_clean_1620()
            pending["salvage_done"] = True
            pending["salvage"] = salvage
            LRS_CLEAN_LIBRARY_PENDING = pending
            if int((salvage or {}).get("handed_off") or 0):
                core.log("LRS clean-time handoff salvage moved {0} item(s)".format(salvage.get("handed_off")), xbmc.LOGINFO)
        stats = core.clean_orphan_library_ratings_1460()
        stats["salvage"] = dict(pending.get("salvage") or {})
    except Exception as exc:  # pylint: disable=broad-except
        text = str(exc).lower()
        if ("locked" in text or "busy" in text) and pending["attempts"] < 15:
            pending["next_at"] = time.time() + 2.0
            LRS_CLEAN_LIBRARY_PENDING = pending
            core.log("LRS clean-library waiting for Kodi DB: {0}".format(exc), xbmc.LOGINFO)
            return None
        LRS_CLEAN_LIBRARY_PENDING = None
        core.log("LRS clean-library failed: {0}".format(exc), xbmc.LOGWARNING)
        return None
    if stats.get("error") and pending["attempts"] < 15:
        pending["next_at"] = time.time() + 2.0
        LRS_CLEAN_LIBRARY_PENDING = pending
        core.log("LRS clean-library retry: {0}".format(stats.get("error")), xbmc.LOGINFO)
        return None
    LRS_CLEAN_LIBRARY_PENDING = None
    removed = int(stats.get("removed") or 0)
    core.save_summary({
        "action": "clean_library",
        "started_at": core.now_iso(),
        "finished_at": core.now_iso(),
        "removed": removed,
        "checked": int(stats.get("checked") or 0),
        "kept": int(stats.get("kept") or 0),
        "external_ratings": "unchanged",
        "handed_off": int(((stats.get("salvage") or {}).get("handed_off") or 0)),
        "status": "completed" if not stats.get("error") else "error",
        "error": stats.get("error", ""),
    })
    handed_off = int(((stats.get("salvage") or {}).get("handed_off") or 0))
    if removed > 0 or handed_off > 0:
        notify("RATINGS CLEAN FINISHED - {0} MOVED - {1} REMOVED".format(
            handed_off, removed), xbmcgui.NOTIFICATION_INFO, 5000)
    return stats


def main():
    monitor = LRSAutoMonitor()
    cache = core.load_cache()
    cache_mtime = core.cache_db_mtime()
    state = load_state()
    queue = []
    queued = set()
    previous_key = ""
    preloaded_key = ""
    preloaded_cache = {}
    manual_job = None
    last_clearlogo_signature = ""
    compatibility = core.bool_setting("publish_af3_cache", True)
    core.clear_af3_properties(compatibility)
    core.reset_stale_background_on_service_start()
    core.log("Library Ratings Scraper service started", xbmc.LOGINFO)

    while not monitor.abortRequested():
        if core.consume_background_force_stop():
            queue = []
            queued = set()
            if manual_job is not None:
                force_stop_job(manual_job)
                manual_job = None
                cache = core.load_cache()
            notify("Force stop background", xbmcgui.NOTIFICATION_WARNING, 5000)
            previous_key = ""
            preloaded_key = ""
            preloaded_cache = {}

        latest_cache_mtime = core.cache_db_mtime()
        if manual_job is None:
            if latest_cache_mtime and latest_cache_mtime != cache_mtime:
                try:
                    cache = core.load_cache()
                    cache_mtime = core.cache_db_mtime()
                    previous_key = ""
                except Exception as exc:  # pylint: disable=broad-except
                    core.log("Cache reload after external update failed: {0}".format(exc), xbmc.LOGWARNING)
            elif not latest_cache_mtime and cache_mtime:
                cache = {"version": core.CACHE_VERSION, "updated_at": "", "backend": "sqlite-ratings-only", "items": {}}
                cache_mtime = 0.0
                previous_key = ""
                preloaded_cache = {}
                core.clear_af3_properties(compatibility)
                core.log("ratings-cache.db disappeared; cleared in-memory LRS cache", xbmc.LOGWARNING)

        context, item = current_context_item()
        try:
            if context != "screensaver":
                # v1.5.23: on AF3 Home/Hub, preload cached records for current, left,
                # and right widget items so a left/right focus move can publish from
                # memory without clearing the visible row first.
                preloaded_cache = homehub_neighbor_prefetch_1523(cache, item, context, state, radius=1)
                preloaded_key = core.identity_key(item) if preloaded_cache else ""
        except Exception as exc:  # pylint: disable=broad-except
            try:
                core.log("Home/Hub neighbor prefetch update failed: {0}".format(exc), xbmc.LOGWARNING)
            except Exception:
                pass
        if context == "screensaver":
            try:
                clearlogo_props = core.update_screensaver_clearlogo_properties(item)
                clearlogo_signature = "|".join(
                    str(clearlogo_props.get(name) or "")
                    for name in (
                        "ClearLogoFinalItemKey",
                        "ClearLogoFinalMode",
                        "ClearLogoResolverStatus",
                        "ClearLogoFinal",
                    )
                )
                recorder = getattr(core, "record_screensaver_clearlogo_from_props_1543", None)
                if callable(recorder) and clearlogo_signature != last_clearlogo_signature:
                    recorder(item, clearlogo_props)
                    last_clearlogo_signature = clearlogo_signature
            except Exception as exc:  # pylint: disable=broad-except
                # Resolver failure remains a normal service warning. Clearlogo
                # selections themselves are never written to kodi.log.
                core.log("Screensaver clearlogo mode update failed: {0}".format(exc), xbmc.LOGWARNING)
        else:
            last_clearlogo_signature = ""
            try:
                core.clear_screensaver_clearlogo_properties()
            except Exception:
                pass
        previous_key = publish_current(cache, item, previous_key, context, state, preloaded_cache)

        request = core.consume_background_request()
        if request:
            if manual_job is not None:
                notify("Previous background process is still running", xbmcgui.NOTIFICATION_WARNING, 5000)
            elif request.get("action") == "top250":
                cache = core.load_cache(); cache_mtime = core.cache_db_mtime(); manual_job = new_top250_job(request)
            else:
                cache = core.load_cache(); cache_mtime = core.cache_db_mtime(); manual_job = new_scrape_job(request)

        if manual_job is None:
            _consume_clean_library_job_1460()
            latest_cache_mtime = core.cache_db_mtime()
            if latest_cache_mtime and latest_cache_mtime != cache_mtime:
                try:
                    cache = core.load_cache(); cache_mtime = core.cache_db_mtime(); previous_key = ""
                except Exception:
                    pass

        if manual_job is None:
            auto_job = _consume_auto_scan_job_1420(cache)
            if auto_job is not None:
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                manual_job = auto_job
                # No separate "queued" notification for auto scrape; the first real
                # progress update is the only notification.

        if xbmc.getCondVisibility("System.ScreenSaverActive"):
            upcoming = {}
            for offset in (1, 2, -1):
                candidate = core.screensaver_item(offset)
                if core.valid_library_item(candidate):
                    upcoming = candidate
                    break
            upcoming_key = core.identity_key(upcoming) if core.valid_library_item(upcoming) else ""
            if upcoming_key and upcoming_key != preloaded_key:
                preloaded_key = upcoming_key
                record = core.cache_record(cache, upcoming)
                preloaded_cache = {upcoming_key: record} if record else {}
                context_log(state, "screensaver", upcoming_key, upcoming.get("title"), bool(record), "preload_cache_hit" if record else "preload_cache_miss")
        else:
            try:
                if not core.af3_hub_window_active():
                    preloaded_key = ""
                    preloaded_cache = {}
            except Exception:
                preloaded_key = ""
                preloaded_cache = {}

        if manual_job is not None:
            if advance_job(manual_job, cache):
                manual_job = None
                cache_mtime = core.cache_db_mtime()
                previous_key = ""
            else:
                cache_mtime = core.cache_db_mtime() or cache_mtime

        wait_seconds = lrs_service_wait_seconds(context, item, manual_job, queue)
        monitor.waitForAbort(wait_seconds)

    if manual_job is not None and manual_job.get("progress") is not None:
        manual_job["progress"].close()
    core.clear_af3_properties(core.bool_setting("publish_af3_cache", True))
    core.log("Library Ratings Scraper service stopped", xbmc.LOGINFO)


# -----------------------------------------------------------------------------
# v1.4.9 / v1.5.0 - final compact progress formatter
# -----------------------------------------------------------------------------

def _progress_text_1500(value):
    text = str(value or "STARTING").replace("\n", " ").strip()
    for prefix in ("Ratings: ", "ratings - ", "Awards: ", "awards - ", "RT Badges: ", "RT badges: ", "rt badges - ", "Top250: ", "top250 - "):
        if text.startswith(prefix):
            text = text[len(prefix):].strip()
            break
    # Remove a trailing percent if an older caller already appended it; AF3's
    # progress skin adds the actual percent itself.
    text = re.sub(r"\s*-\s*\d{1,3}%\s*$", "", text).strip()
    text = re.sub(r"\s+", " ", text)
    return text.upper() or "STARTING"


def _progress_body_1500(processed, total, title, phase, limit=92):
    # User-facing final pattern: static phase at the end. Keep titles full
    # unless the whole body would become too long for Kodi/AF3 notification.
    title = _progress_text_1500(title)
    phase = str(phase or "RATINGS").upper()
    prefix = "{0}/{1} ".format(processed, total)
    suffix = " - {0}".format(phase)
    available = max(12, int(limit) - len(prefix) - len(suffix))
    if len(title) > available:
        title = compact_text(title, available)
    return "{0}{1}{2}".format(prefix, title, suffix)


def update_bg(job, message=None):
    progress = job.get("progress")
    if progress is None:
        return
    total = int(job.get("total") or len(job.get("items") or []))
    processed = int(job.get("processed") or job.get("index") or 0)
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    phase = _phase_label_1460(job)
    title = message if message is not None else job.get("current")
    # Do not append the percent to the message. Arctic Fuse's progress dialog
    # already displays the progress percentage, which previously caused double
    # percent text on screen.
    body = _progress_body_1500(processed, total, title, phase, 92)
    progress.update(percent, TITLE, body)


# v1.4.9 - keep the v1.4.7 external/upcoming and phase-summary fixes active.
# Earlier builds appended these after the service main() call, so they could be
# skipped in real Kodi service execution.
_publish_current_1490_base = publish_current

def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    try:
        key = _external_focus_key_1430(item)
        if key and context not in ("player", "screensaver") and not core.external_item_released_1430(item):
            core.publish_af3_properties({}, key, core.bool_setting("publish_af3_cache", True))
            return key
    except Exception:
        pass
    return _publish_current_1490_base(cache, item, previous_key, context, state, preload)

_finish_job_1490_base = finish_job

def finish_job(job, cache, canceled=False, stopped_reason=""):
    before = dict(job or {})
    result = _finish_job_1490_base(job, cache, canceled, stopped_reason)
    try:
        summary = core._load_json(core.SUMMARY_FILE) or {}
        phase_name = str(before.get("phase") or before.get("action") or "ratings")
        if phase_name == "rtbadges":
            phase_name = "rt badges"
        phase_stats = summary.get("phase_stats") if isinstance(summary.get("phase_stats"), dict) else {}
        phase_stats.setdefault(phase_name, {
            "processed": int(before.get("processed") or 0),
            "updated": int(before.get("updated") or 0),
            "skipped": int(before.get("skipped") or 0),
            "failed": int(before.get("failed") or 0),
        })
        summary["phase_stats"] = phase_stats
        core.save_summary(summary)
    except Exception:
        pass
    return result



# -----------------------------------------------------------------------------
# v1.4.10 - Top250-safe missing prefilter
# -----------------------------------------------------------------------------
_new_scrape_job_1410_base = new_scrape_job

def _prefilter_missing_items_1410(items, cache, action, force):
    if force:
        return list(items or [])
    filtered = []
    items = list(items or [])
    cache_items = (cache or {}).get("items") or {}
    for item in items:
        try:
            key = core.item_key(item)
            existing = cache_items.get(key) or {}
            if action == "awards":
                if (not existing) or core.record_missing_awards(item, existing):
                    filtered.append(item)
            elif action == "rtbadges":
                if (not existing) or core.record_missing_rt_badge(item, existing):
                    filtered.append(item)
            else:
                if (not existing) or core.record_needs_update(item, existing):
                    filtered.append(item)
        except Exception:
            filtered.append(item)
    return filtered


def new_scrape_job(request):
    job = _new_scrape_job_1410_base(request)
    try:
        action = str(job.get("action") or (request or {}).get("action") or "scrape")
        force = bool(job.get("force"))
        if not force and action in ("scrape", "awards", "rtbadges") and not job.get("auto_new_only"):
            cache = core.load_cache()
            old_total = len(job.get("items") or [])
            filtered = _prefilter_missing_items_1410(job.get("items") or [], cache, action, force)
            job["items"] = filtered
            job["index"] = 0
            job["processed"] = 0
            job["total"] = len(filtered)
            job["prefiltered_total"] = old_total
            job["current"] = "Preparing"
            # Keep scope_items in sync so awards/RT phases after ratings do not
            # expand back to the full library for missing-only jobs.
            if action == "scrape":
                job["scope_items"] = filtered
            update_bg(job, "Preparing")
            write_job_state(job)
    except Exception as exc:
        try:
            core.log("LRS prefilter failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass
    return job


# __main__ call moved to true end by v1.4.12.


# -----------------------------------------------------------------------------
# v1.4.7 - external upcoming hide + phase summary polish
# -----------------------------------------------------------------------------

def _external_focus_key_1430(item):
    try:
        if not core.valid_library_item(item) or core.resolvable_library_item(item):
            return ""
        media = core.media_setting_type(item.get("type"))
        if media not in ("movie", "tvshow"):
            return ""
        return core.external_item_key_1430(item)
    except Exception:
        return ""

_publish_current_1470_base = publish_current

def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    # For non-library upcoming/future widgets, never show old external ratings.
    try:
        key = _external_focus_key_1430(item)
        if key and context not in ("player", "screensaver") and not core.external_item_released_1430(item):
            core.publish_af3_properties({}, key, core.bool_setting("publish_af3_cache", True))
            return key
    except Exception:
        pass
    return _publish_current_1470_base(cache, item, previous_key, context, state, preload)

_finish_job_1470_base = finish_job

def finish_job(job, cache, canceled=False, stopped_reason=""):
    # Add a lightweight phase snapshot to summary/state after the normal finisher.
    before = dict(job or {})
    result = _finish_job_1470_base(job, cache, canceled, stopped_reason)
    try:
        summary = core._load_json(core.SUMMARY_FILE) or {}
        phase_name = str(before.get("phase") or before.get("action") or "ratings")
        if phase_name == "rtbadges": phase_name = "rt badges"
        phase_stats = summary.get("phase_stats") if isinstance(summary.get("phase_stats"), dict) else {}
        phase_stats.setdefault(phase_name, {
            "processed": int(before.get("processed") or 0),
            "updated": int(before.get("updated") or 0),
            "skipped": int(before.get("skipped") or 0),
            "failed": int(before.get("failed") or 0),
        })
        summary["phase_stats"] = phase_stats
        core.save_summary(summary)
    except Exception:
        pass
    return result



# -----------------------------------------------------------------------------
# v1.5.0 - final summary/phase-stats consistency cleanup
# -----------------------------------------------------------------------------
_finish_job_1500_base = finish_job

def _summary_phase_name_1500(job, summary):
    phase_name = str((job or {}).get("phase") or (summary or {}).get("action") or (job or {}).get("action") or "ratings").strip().lower()
    if phase_name == "rtbadges":
        return "rt badges"
    if phase_name == "top250":
        return "top250"
    if phase_name == "awards":
        return "awards"
    return "ratings"


def finish_job(job, cache, canceled=False, stopped_reason=""):
    result = _finish_job_1500_base(job, cache, canceled, stopped_reason)
    try:
        summary = core._load_json(core.SUMMARY_FILE) or {}
        phase_name = _summary_phase_name_1500(job, summary)
        processed = int(summary.get("items_total") or (job or {}).get("processed") or (job or {}).get("total") or len((job or {}).get("items") or []) or 0)
        matched = int(summary.get("matched") or (job or {}).get("matched") or 0)
        updated = int(summary.get("updated") or (job or {}).get("updated") or 0)
        skipped = int(summary.get("skipped") or (job or {}).get("skipped") or 0)
        failed = int(summary.get("failed") or (job or {}).get("failed") or 0)
        phase_stats = summary.get("phase_stats") if isinstance(summary.get("phase_stats"), dict) else {}
        phase_stats[phase_name] = {
            "processed": processed,
            "checked": processed,
            "matched": matched,
            "updated": updated,
            "changed_rows": updated,
            "skipped": skipped,
            "failed": failed,
        }
        summary["phase_stats"] = phase_stats
        summary["items_processed"] = processed
        summary["items_checked"] = processed
        summary["changed_rows"] = updated
        summary["reporting_note"] = "processed/checked means items examined; updated/changed_rows means cache rows whose stored values changed."
        core.save_summary(summary)
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("LRS v1.5 summary cleanup failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass
    return result




# -----------------------------------------------------------------------------
# v1.5.3 - auto-new scan unified progress + lightweight auto-scan lock
# -----------------------------------------------------------------------------
# Manual menu jobs keep their existing per-phase progress. Only auto scan after
# Kodi library update is shown as one combined workflow so 1 new movie does not
# show 100% repeatedly for RATINGS/AWARDS/RT BADGES.
AUTO_SCAN_LOCK_FILE_1530 = os.path.join(os.path.dirname(core.PROFILE.rstrip(os.sep)), ".kodi-auto-scan.lock")
AUTO_SCAN_LOCK_STALE_SECONDS_1530 = 60 * 60 * 3


def _auto_lock_payload_1530():
    return {
        "addon": "script.library.ratings.scraper",
        "title": TITLE,
        "created_at": core.now_iso(),
        "pid": os.getpid(),
    }


def _read_auto_lock_1530():
    try:
        with open(AUTO_SCAN_LOCK_FILE_1530, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _auto_lock_is_stale_1530():
    try:
        return (time.time() - os.path.getmtime(AUTO_SCAN_LOCK_FILE_1530)) > AUTO_SCAN_LOCK_STALE_SECONDS_1530
    except Exception:
        return True


def _acquire_auto_lock_1530():
    try:
        os.makedirs(os.path.dirname(AUTO_SCAN_LOCK_FILE_1530), exist_ok=True)
        if os.path.exists(AUTO_SCAN_LOCK_FILE_1530):
            lock = _read_auto_lock_1530()
            owner = str(lock.get("addon") or "")
            if owner == "script.library.ratings.scraper":
                return True
            if not _auto_lock_is_stale_1530():
                core.log("Auto scrape waiting for shared auto-scan lock owned by {0}".format(owner or "another addon"), xbmc.LOGINFO)
                return False
            try:
                os.remove(AUTO_SCAN_LOCK_FILE_1530)
            except Exception:
                return False
        temp = AUTO_SCAN_LOCK_FILE_1530 + ".tmp"
        with open(temp, "w", encoding="utf-8") as handle:
            json.dump(_auto_lock_payload_1530(), handle, ensure_ascii=False, indent=2, sort_keys=True)
        os.replace(temp, AUTO_SCAN_LOCK_FILE_1530)
        return True
    except Exception as exc:  # pylint: disable=broad-except
        core.log("Auto scrape shared lock acquire failed: {0}".format(exc), xbmc.LOGWARNING)
        # Do not break auto scrape if the lock file cannot be written.
        return True


def _release_auto_lock_1530():
    try:
        lock = _read_auto_lock_1530()
        if not lock or str(lock.get("addon") or "") == "script.library.ratings.scraper":
            if os.path.exists(AUTO_SCAN_LOCK_FILE_1530):
                os.remove(AUTO_SCAN_LOCK_FILE_1530)
    except Exception as exc:  # pylint: disable=broad-except
        core.log("Auto scrape shared lock release failed: {0}".format(exc), xbmc.LOGDEBUG)


def _auto_phase_items_1530(job, phase):
    source = list((job or {}).get("scope_items") or (job or {}).get("items") or [])
    if phase == "awards":
        return [item for item in source if core.media_setting_type(item.get("type")) in ("movie", "tvshow")]
    if phase == "rtbadges":
        return [item for item in source if core.media_setting_type(item.get("type")) == "movie"]
    return source


def _auto_combined_total_1530(job):
    source = list((job or {}).get("scope_items") or [])
    if not source:
        source = list((job or {}).get("items") or [])
    rating_count = len(source)
    media_count = len([item for item in source if core.media_setting_type(item.get("type")) in ("movie", "tvshow")])
    movie_count = len([item for item in source if core.media_setting_type(item.get("type")) == "movie"])
    awards_count = media_count if bool((job or {}).get("awards_after_ratings")) and core.bool_setting("scrape_awards_wins", True) else 0
    rt_count = movie_count if bool((job or {}).get("rtbadges_after_previous")) else 0
    total = rating_count + awards_count + rt_count
    return max(1, total)


def _auto_combined_offset_1530(job, phase):
    source = list((job or {}).get("scope_items") or [])
    if not source:
        source = list((job or {}).get("items") or [])
    rating_count = len(source)
    media_count = len([item for item in source if core.media_setting_type(item.get("type")) in ("movie", "tvshow")])
    awards_count = media_count if bool((job or {}).get("awards_after_ratings")) and core.bool_setting("scrape_awards_wins", True) else 0
    if phase == "awards":
        return rating_count
    if phase == "rtbadges":
        return rating_count + awards_count
    return 0


def _auto_combined_processed_1530(job, phase):
    return min(_auto_combined_total_1530(job), _auto_combined_offset_1530(job, phase) + int((job or {}).get("processed") or (job or {}).get("index") or 0))


_update_bg_1530_base = update_bg


def update_bg(job, message=None):
    if not (job or {}).get("auto_new_only"):
        return _update_bg_1530_base(job, message)
    progress = (job or {}).get("progress")
    if progress is None:
        return
    phase = str((job or {}).get("phase") or "ratings").lower()
    phase_label = _phase_label_1460(job)
    total = _auto_combined_total_1530(job)
    processed = _auto_combined_processed_1530(job, phase)
    percent = int(processed * 100 / max(1, total))
    title = message if message is not None else (job or {}).get("current")
    body = _progress_body_1500(processed, total, title, phase_label, 92)
    progress.update(percent, TITLE, body)


_consume_auto_scan_job_1530_base = _consume_auto_scan_job_1420


def _consume_auto_scan_job_1420(cache):
    global AUTO_LIBRARY_SCAN_PENDING
    if not AUTO_LIBRARY_SCAN_PENDING:
        return None
    if not _acquire_auto_lock_1530():
        pending = AUTO_LIBRARY_SCAN_PENDING or {}
        pending["next_at"] = time.time() + 5.0
        AUTO_LIBRARY_SCAN_PENDING = pending
        return None
    job = _consume_auto_scan_job_1530_base(cache)
    if job is None:
        # No new items, or detection deferred. Keep/release lock based on pending.
        if not AUTO_LIBRARY_SCAN_PENDING:
            _release_auto_lock_1530()
        return None
    job["shared_auto_scan_lock"] = True
    job["combined_auto_progress"] = True
    update_bg(job, "Preparing")
    write_job_state(job)
    return job


_finish_job_1530_base = finish_job


def finish_job(job, cache, canceled=False, stopped_reason=""):
    try:
        return _finish_job_1530_base(job, cache, canceled, stopped_reason)
    finally:
        if (job or {}).get("auto_new_only") or (job or {}).get("shared_auto_scan_lock"):
            _release_auto_lock_1530()


_force_stop_job_1530_base = force_stop_job


def force_stop_job(job):
    try:
        return _force_stop_job_1530_base(job)
    finally:
        if (job or {}).get("auto_new_only") or (job or {}).get("shared_auto_scan_lock"):
            _release_auto_lock_1530()




# -----------------------------------------------------------------------------
# v1.5.5 - auto-scan finishing progress labels
# -----------------------------------------------------------------------------
# Keep data phases as combined item counters (1/3 TITLE - RATINGS, etc.), but
# show auto-scan finishing work as clear workflow labels without reusing the
# final item counter or a stale phase label.
_update_bg_1540_base = update_bg


def _auto_finish_progress_body_1540(message, job=None):
    raw = str(message or "").replace("\n", " ").strip()
    lower = raw.lower()
    if "saving" in lower and "cache" in lower:
        return "SAVING CACHE - AUTO SCAN"
    if "export" in lower and ("csv" in lower or "report" in lower):
        return "EXPORTING REPORT - AUTO SCAN"
    if lower in ("starting", "preparing", "preparing..."):
        phase = _phase_label_1460(job or {})
        if phase and phase not in ("RATINGS",):
            return "STARTING {0} - AUTO SCAN".format(phase)
        return "PREPARING - AUTO SCAN"
    return ""


def update_bg(job, message=None):
    if not (job or {}).get("auto_new_only"):
        return _update_bg_1540_base(job, message)
    progress = (job or {}).get("progress")
    if progress is None:
        return
    special = _auto_finish_progress_body_1540(message, job)
    if special:
        # Keep the visual progress near complete during finishing, but do not
        # show misleading 3/3 counters once item phases have completed.
        progress.update(100, TITLE, special)
        return
    return _update_bg_1540_base(job, message)



# -----------------------------------------------------------------------------
# v1.5.6 - Clean-library state/report cleanup
# -----------------------------------------------------------------------------
_consume_clean_library_job_1560_base = _consume_clean_library_job_1460

def _consume_clean_library_job_1460():
    stats = _consume_clean_library_job_1560_base()
    if not stats:
        return stats
    try:
        removed = int((stats or {}).get("removed") or 0)
        checked = int((stats or {}).get("checked") or 0)
        report = (stats or {}).get("report") or ""
        summary = core._load_json(core.SUMMARY_FILE) or {}
        if summary.get("action") == "clean_library":
            if report:
                summary["report"] = report
                summary["report_refreshed"] = bool((stats or {}).get("report_refreshed"))
            if (stats or {}).get("report_error"):
                summary["report_error"] = (stats or {}).get("report_error")
            summary["items_checked"] = checked
            summary["items_processed"] = checked
            summary["changed_rows"] = removed
            summary["reporting_note"] = "clean_library removed means stale LRS cache rows deleted; ratings-report.csv is regenerated when rows are removed."
            core.save_summary(summary)
        core.save_background_state({
            "status": "completed" if not (stats or {}).get("error") else "error",
            "action": "clean_library",
            "requested_at": summary.get("started_at") or core.now_iso(),
            "started_at": summary.get("started_at") or "",
            "finished_at": summary.get("finished_at") or core.now_iso(),
            "total": checked,
            "processed": checked,
            "percent": 100 if checked or not (stats or {}).get("error") else 0,
            "updated": removed,
            "removed": removed,
            "matched": 0,
            "skipped": 0,
            "failed": 1 if (stats or {}).get("error") else 0,
            "current": "Clean library cleanup",
            "report": report,
            "checked": checked,
            "kept": int((stats or {}).get("kept") or 0),
            "error": (stats or {}).get("error") or "",
        })
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("LRS v1.5.6 clean-library state cleanup failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass
    return stats




# -----------------------------------------------------------------------------
# v1.5.8 - MediaHub Widget game rating passthrough
# -----------------------------------------------------------------------------
# Keep game focus completely outside the movie/tv cache/scraper path. MediaHub
# supplies RatingSlotN_* on the ListItem; LRS mirrors those values to the same
# LibraryRatings.* services used by normal cached video ratings.
_publish_current_1580_base = publish_current

def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}
    try:
        if core.is_lrs_game_item(item):
            active_key = core.identity_key(item)
            if active_key and active_key != previous_key:
                core.publish_af3_properties({}, active_key, compatibility)
            values = core.af3_values_for_game_item(item)
            values["SourceContext"] = context
            core.publish_af3_properties(values, active_key, compatibility)
            context_log(state, context, active_key, (item or {}).get("title"), True, "mediahub_game_passthrough_1580")
            return active_key
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("MediaHub game rating passthrough failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass
    return _publish_current_1580_base(cache, item, previous_key, context, state, preload)



# -----------------------------------------------------------------------------
# v1.5.9 - MediaHub game passthrough, screensaver-only publish
# -----------------------------------------------------------------------------
# Home/hub already has MediaHub's native game metadata row. Publishing game
# slots to LibraryRatings.ListItem.* makes AF3 draw the LRS row too, so games
# are mirrored only to LibraryRatings.Screensaver.* while the list/player
# services are explicitly cleared. Normal movie/TV/episode flow is untouched.
_publish_current_1590_base = publish_current

def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}
    try:
        if core.is_lrs_game_item(item):
            active_key = core.identity_key(item)
            # Always blank non-screensaver AF3 namespaces on game focus. This
            # prevents the home/hub duplicate rating strip and also removes any
            # stale movie/series ratings left by the previous item.
            clear_services = getattr(core, "clear_af3_services", None)
            publish_services = getattr(core, "publish_af3_properties_for_services", None)
            if callable(clear_services):
                clear_services(("ListItem", "Player", "VideoPlayer"), compatibility)
            elif active_key and active_key != previous_key:
                core.publish_af3_properties({}, "", compatibility)

            values = core.af3_values_for_game_item(item)
            values["SourceContext"] = context
            if callable(publish_services):
                # Screensaver keeps receiving the same RatingSlotN_* payload.
                publish_services(values, active_key, compatibility, ("Screensaver",))
            else:
                core.publish_af3_properties(values, active_key, compatibility)
            context_log(state, context, active_key, (item or {}).get("title"), True, "mediahub_game_passthrough_1590_screensaver_only")
            return active_key
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("MediaHub game screensaver-only passthrough failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass
    return _publish_current_1590_base(cache, item, previous_key, context, state, preload)


# -----------------------------------------------------------------------------
# v1.5.23 - Home/Hub prefetch publish path
# -----------------------------------------------------------------------------
# When the active AF3 item already exists in the neighbor prefetch map, publish
# immediately from that cached record and do not clear the row first. If there is
# no prefetch hit, fall back to the normal guarded path.
_publish_current_1523_base = publish_current

def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}
    preload = preload if isinstance(preload, dict) else {}
    try:
        if (
            str(context or "").lower() in ("af3_visual", "hub", "hub_fallback", "listitem", "lrs_active")
            and core.af3_hub_window_active()
            and core.valid_library_item(item)
            and not core.is_lrs_game_item(item)
        ):
            active_key = core.identity_key(item)
            record = preload.get(active_key)
            if record and core.context_matches_record(item, record):
                publish_key = core.record_item_key(record) or active_key
                values = core.af3_values(record)
                values["SourceContext"] = context
                try:
                    values.update(core.lrs_endsat_properties_1522(item, context))
                except Exception as exc:  # pylint: disable=broad-except
                    try:
                        core.log("LRS Ends-at slot publish failed: {0}".format(exc), xbmc.LOGWARNING)
                    except Exception:
                        pass
                core.publish_af3_properties(values, publish_key, compatibility)
                context_log(state, context, publish_key, (item or {}).get("title") or record.get("title"), True, "homehub_prefetch_publish_1523")
                return active_key
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("Home/Hub prefetch publish path failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass
    return _publish_current_1523_base(cache, item, previous_key, context, state, preload)

# -----------------------------------------------------------------------------
# v1.5.31 - AF3 lower-row owner: DisplaySlot for Home/Hub + Programs/Videos
# -----------------------------------------------------------------------------
# Clean replacement for the 1.5.25-1.5.29 experimental DisplaySlot chain.
# - Home/Hub uses keep-last DisplaySlot to avoid row blinking on focus changes.
# - MyPrograms/MyVideoNav uses strict-current DisplaySlot so library rows do not
#   depend on Steam direct XML rows and movie Ends-at is available there too.
# - Game is handled before video validity checks, so it is never blocked by the
#   old movie/tv-only guard.
_publish_current_1531_base = publish_current
_current_context_item_1531_base = current_context_item


def _af3_row_window_1531():
    try:
        fn = getattr(core, "af3_rating_row_window_active_1531", None)
        if callable(fn):
            return bool(fn())
        return bool(core.af3_hub_window_active())
    except Exception:  # pylint: disable=broad-except
        return False


def _af3_row_keep_last_1531():
    try:
        fn = getattr(core, "af3_rating_row_keep_last_window_1531", None)
        if callable(fn):
            return bool(fn())
        return bool(core.af3_hub_window_active())
    except Exception:  # pylint: disable=broad-except
        return False


def _af3_row_context_1531(context):
    try:
        return str(context or "").lower() in (
            "af3_visual", "hub", "hub_fallback", "listitem", "lrs_active",
            "tmdbhelper", "homehub_nonmedia", "identity_missing",
        ) and _af3_row_window_1531()
    except Exception:  # pylint: disable=broad-except
        return False


def _af3_row_valid_media_1531(item):
    try:
        return bool(core.is_lrs_game_item(item) or core.valid_library_item(item))
    except Exception:  # pylint: disable=broad-except
        return False


def _af3_row_has_strong_media_identity_1670(item):
    """A real media identity always outranks a menu-label deny word.

    Titles such as Home, Play, Games, Movies, or Discover are valid media
    titles. They are only navigation labels when Kodi exposes no strong DBID,
    media type, MediaHub item key, provider ID, or Steam AppID.
    """
    if not isinstance(item, dict):
        return False
    item_key = str(
        item.get("mediahub_item_key")
        or item.get("MediaHub.ItemKey")
        or item.get("item_key")
        or ""
    ).strip().lower()
    if re.match(r"^(?:movie|tvshow|episode)\|[0-9]+$", item_key):
        return True
    if item_key.startswith("game|steam|") and item_key.split("|")[-1].strip():
        return True

    media_type = str(
        item.get("type") or item.get("DBType") or item.get("DBTYPE")
        or item.get("dbtype") or item.get("MediaType") or item.get("mediatype")
        or ""
    ).strip().lower()
    dbid = core.safe_int(
        item.get("dbid") or item.get("DBID") or item.get("DBId")
    )
    if media_type in ("movie", "tvshow", "episode") and dbid is not None:
        return True
    if media_type == "game" and str(item.get("steam_appid") or "").strip():
        return True
    if media_type in ("movie", "tvshow", "episode"):
        imdb_id = str(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb") or "").strip().lower()
        tmdb_id = str(item.get("tmdb_id") or item.get("tmdb") or "").strip()
        if re.match(r"^tt[0-9]+$", imdb_id) or tmdb_id.isdigit():
            return True
    return False


def _af3_row_false_media_title_1531(item):
    if _af3_row_has_strong_media_identity_1670(item):
        return False
    title = str((item or {}).get("title") or (item or {}).get("label") or (item or {}).get("Title") or (item or {}).get("Label") or "").strip().lower()
    if not title:
        return False
    deny = {
        "library ratings scraper", "clean video library", "update video library", "reload skin",
        "my add-ons", "favourites", "settings", "skin settings", "movies", "tv shows", "games", "home",
        "play", "more options", "discover",
    }
    return title in deny or title.startswith("steam app ")


def _af3_row_no_rating_item_1531(item):
    """Items such as movie sets/collections/folders must hide the row immediately.

    Home/Hub keep-last is useful for movie→movie/game transitions, but it is
    wrong for collection/set pages because those screens have no rating row and
    the old movie row can be visible for a fraction of a second.
    """
    item = item or {}
    for key in ("type", "DBType", "dbtype", "DBTYPE", "MediaType", "mediatype", "lrs_item_type", "library_ratings_type"):
        value = str(item.get(key) or "").strip().lower()
        if value in ("set", "sets", "collection", "collections", "folder", "folders"):
            return True
    path = str(item.get("file") or item.get("path") or item.get("FileNameAndPath") or item.get("FolderPath") or "").strip().lower()
    if "videodb://movies/sets" in path:
        return True
    # Kodi/AF3 collection pages often expose no IDs but still have a title.
    # Do not guess from title alone here; XML guard handles current DBType/set
    # instantly, while service handles explicit type/path.
    return False


def current_context_item():
    # Arctic Mirage must outrank the window left active behind it.
    # Kodi keeps Home, Hub, MyPrograms, or MyVideoNav active underneath the
    # screensaver. Checking those first makes LRS publish the hidden item,
    # which then fails the screensaver identity guard.
    try:
        if xbmc.getCondVisibility("System.ScreenSaverActive"):
            return "screensaver", core.screensaver_item(0)
    except Exception:  # pylint: disable=broad-except
        return "screensaver", {}

    # AF3 Home/Hub visual panels can have focus on Play/More Options/tabs while
    # the displayed media is different. Only those windows get the visual-first
    # resolver. MyPrograms/MyVideoNav stay strict-current through the base
    # selected ListItem resolver.
    try:
        if core.af3_hub_window_active():
            for context, getter_name in (
                ("af3_visual", "af3_visual_item"),
                ("lrs_active", "lrs_active_item"),
                ("hub", "hub_focus_container_item"),
                ("listitem", "selected_library_item"),
                ("hub_fallback", "hub_primary_item"),
            ):
                getter = getattr(core, getter_name, None)
                if not callable(getter):
                    continue
                item = getter()
                if _af3_row_false_media_title_1531(item):
                    continue
                if _af3_row_valid_media_1531(item):
                    return context, item
            return "homehub_nonmedia", {}
    except Exception:  # pylint: disable=broad-except
        pass
    try:
        strict_fn = getattr(core, "af3_rating_row_strict_window_1531", None)
        if callable(strict_fn) and strict_fn():
            for context, getter_name in (
                ("listitem", "selected_library_item"),
                ("lrs_active", "lrs_active_item"),
                ("hub", "hub_focus_container_item"),
            ):
                getter = getattr(core, getter_name, None)
                if not callable(getter):
                    continue
                item = getter()
                if _af3_row_false_media_title_1531(item):
                    continue
                if _af3_row_valid_media_1531(item):
                    return context, item
            return "identity_missing", {}
    except Exception:  # pylint: disable=broad-except
        pass
    return _current_context_item_1531_base()


def _publish_af3_display_from_values_1531(values, item_key, source, compatibility, mode="keep-last"):
    try:
        publisher = getattr(core, "publish_homehub_display_1528", None)
        if callable(publisher):
            return bool(publisher(values, item_key, source, compatibility, mode=mode))
    except TypeError:
        try:
            publisher = getattr(core, "publish_homehub_display_1528", None)
            if callable(publisher):
                return bool(publisher(values, item_key, source, compatibility))
        except Exception:
            pass
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("AF3 DisplaySlot 1.5.31 publish failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass
    return False


def _set_af3_display_active_1531(active):
    try:
        active_fn = getattr(core, "publish_homehub_display_active_1528", None)
        if callable(active_fn):
            active_fn(bool(active))
    except Exception:
        pass


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}
    preload = preload if isinstance(preload, dict) else {}

    if not _af3_row_context_1531(context):
        _set_af3_display_active_1531(False)
        return _publish_current_1531_base(cache, item, previous_key, context, state, preload)

    keep_last = _af3_row_keep_last_1531()
    mode = "keep-last" if keep_last else "strict-current"

    # Non-media/menu focus: Home/Hub freezes the previous visual row; strict
    # library windows clear DisplayActive so stale rows do not follow focus.
    if not isinstance(item, dict) or not item or _af3_row_false_media_title_1531(item):
        if keep_last:
            context_log(state, context, previous_key or "", "", False, "af3_displayslot_keep_last_nonmedia_1531")
            return previous_key or ""
        _set_af3_display_active_1531(False)
        context_log(state, context, previous_key or "", "", False, "af3_displayslot_strict_nonmedia_clear_1531")
        return _publish_current_1531_base(cache, item if isinstance(item, dict) else {}, previous_key, context, state, preload)

    active_key = core.identity_key(item)

    if _af3_row_no_rating_item_1531(item):
        _set_af3_display_active_1531(False)
        context_log(state, context, active_key or previous_key or "", item.get("title"), False, "af3_displayslot_no_rating_item_clear_1531")
        return active_key or previous_key or ""

    # Game first. Do not call the old 1.5.9 game path because it clears
    # LibraryRatings.ListItem.* and only publishes to Screensaver.
    try:
        if core.is_lrs_game_item(item):
            values = core.af3_values_for_game_item(item)
            values["SourceContext"] = context
            values["DisplayMode"] = mode
            shown = _publish_af3_display_from_values_1531(values, active_key, "game", compatibility, mode=mode)
            publish_services = getattr(core, "publish_af3_properties_for_services", None)
            if callable(publish_services):
                publish_services(values, active_key, compatibility, ("Screensaver",))
            if not shown and not keep_last:
                _set_af3_display_active_1531(False)
            context_log(state, context, active_key, (item or {}).get("title"), shown, "af3_displayslot_game_publish_1531" if shown else "af3_displayslot_game_empty_1531")
            return active_key or previous_key or ""
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("AF3 DisplaySlot 1.5.31 game publish failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass
        if not keep_last:
            _set_af3_display_active_1531(False)
        context_log(state, context, previous_key or active_key, (item or {}).get("title"), False, "af3_displayslot_game_error_1531")
        return previous_key or active_key or ""

    if not core.valid_library_item(item):
        if keep_last:
            context_log(state, context, previous_key or active_key or "", item.get("title"), False, "af3_displayslot_keep_last_invalid_1531")
            return previous_key or active_key or ""
        _set_af3_display_active_1531(False)
        context_log(state, context, active_key or "", item.get("title"), False, "af3_displayslot_strict_invalid_clear_1531")
        return _publish_current_1531_base(cache, item, previous_key, context, state, preload)

    record = preload.get(active_key) if isinstance(preload, dict) else None
    if not record:
        record = _record_from_cache(cache, item, preload)
    if not record:
        if keep_last:
            context_log(state, context, previous_key or active_key, item.get("title"), False, "af3_displayslot_cache_miss_keep_last_1531")
            return previous_key or active_key
        _set_af3_display_active_1531(False)
        context_log(state, context, active_key, item.get("title"), False, "af3_displayslot_cache_miss_strict_fallback_1531")
        return _publish_current_1531_base(cache, item, previous_key, context, state, preload)
    if not core.context_matches_record(item, record):
        if keep_last:
            context_log(state, context, previous_key or active_key, item.get("title"), False, "af3_displayslot_stale_guard_keep_last_1531")
            return previous_key or active_key
        _set_af3_display_active_1531(False)
        context_log(state, context, active_key, item.get("title"), False, "af3_displayslot_stale_guard_strict_fallback_1531")
        return _publish_current_1531_base(cache, item, previous_key, context, state, preload)

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    values["DisplayMode"] = mode
    try:
        values.update(core.lrs_endsat_properties_1522(item, context))
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("LRS Ends-at DisplaySlot 1.5.31 publish failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass

    # Keep normal LRS namespaces updated for the current AF3 bridge; XML hides them
    # whenever DisplayActive=true to prevent double rows.
    core.publish_af3_properties(values, publish_key, compatibility)
    shown = _publish_af3_display_from_values_1531(values, publish_key, "video", compatibility, mode=mode)
    if not shown and not keep_last:
        _set_af3_display_active_1531(False)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), shown, "af3_displayslot_video_publish_1531" if shown else "af3_displayslot_video_empty_1531")
    return active_key


# -----------------------------------------------------------------------------
# v1.5.36 - explicit screensaver-only data bridge
# -----------------------------------------------------------------------------
# KPM owns the Arctic Mirage XML. LRS remains the data owner and guarantees that
# LibraryRatings.Screensaver.* is populated even if Home/Hub DisplaySlot logic is
# in keep-last mode or a compatibility wrapper changes the generic publisher.
_publish_current_1536_base = publish_current


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    result = _publish_current_1536_base(cache, item, previous_key, context, state, preload)
    if str(context or "").lower() != "screensaver":
        return result
    compatibility = core.bool_setting("publish_af3_cache", True)
    try:
        active_key = core.identity_key(item or {})
        values = None
        publish_key = active_key
        if core.is_lrs_game_item(item or {}):
            values = core.af3_values_for_game_item(item or {})
        elif core.valid_library_item(item or {}):
            record = _record_from_cache(cache, item or {}, preload)
            if not record:
                try:
                    fresh_cache = core.load_cache()
                    record = _record_from_cache(fresh_cache, item or {}, preload)
                    if record:
                        cache.clear(); cache.update(fresh_cache)
                except Exception:
                    record = None
            if record and core.context_matches_record(item or {}, record):
                values = core.af3_values(record)
                publish_key = core.record_item_key(record) or active_key
        if values:
            values["SourceContext"] = "screensaver_1536"
            publisher = getattr(core, "publish_af3_properties_for_services", None)
            if callable(publisher):
                publisher(values, publish_key, compatibility, ("Screensaver",))
            else:
                core.publish_af3_properties(values, publish_key, compatibility)
            context_log(state if isinstance(state, dict) else {}, "screensaver", publish_key, (item or {}).get("title"), True, "screensaver_data_bridge_1536")
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("LRS screensaver data bridge 1.5.36 failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass
    return result




# -----------------------------------------------------------------------------
# v1.5.58 - auto-scan must detect reused DBIDs, not only new type|DBID keys
# -----------------------------------------------------------------------------
_auto_new_items_after_scan_1558_base = _auto_new_items_after_scan_1420


def _auto_new_items_after_scan_1420(cache, before_keys):
    selected = list(_auto_new_items_after_scan_1558_base(cache, before_keys) or [])
    seen = set(core.item_key(item) for item in selected if isinstance(item, dict))
    cache_items = (cache or {}).get("items") or {}
    for item in core.library_items():
        if not core.resolvable_library_item(item):
            continue
        key = core.item_key(item)
        if not key or key in seen:
            continue
        existing = cache_items.get(key) or {}
        if existing and not core.cache_identity_matches_1558(item, existing):
            selected.append(item)
            seen.add(key)
            try:
                core.log("Auto scrape identity change detected for {0}".format(key), xbmc.LOGINFO)
            except Exception:
                pass
    return selected




# -----------------------------------------------------------------------------
# v1.5.62 - dataset batch pass before online provider processing
# -----------------------------------------------------------------------------
_new_scrape_job_1562_base = new_scrape_job


def new_scrape_job(request):
    manual_salvage = {}
    try:
        request_action = str((request or {}).get("action") or "scrape")
        if request_action == "scrape" and not bool((request or {}).get("force")) and not bool((request or {}).get("auto_new_only")):
            manual_salvage = core.salvage_dbid_handoffs_before_clean_1620("manual_scrape_missing_recovery") or {}
            migrated = int(manual_salvage.get("handed_off") or 0)
            if migrated:
                notify("RATINGS MIGRATED - {0} ITEMS".format(migrated), xbmcgui.NOTIFICATION_INFO, 5000)
    except Exception as exc:  # pylint: disable=broad-except
        core.log("Manual Scrape Missing migration recovery failed: {0}".format(exc), xbmc.LOGWARNING)
        manual_salvage = {"error": str(exc)}
    job = _new_scrape_job_1562_base(request)
    try:
        if int(manual_salvage.get("handed_off") or 0):
            job["handed_off"] = int(manual_salvage.get("handed_off") or 0)
            job["handoff_rows"] = list(manual_salvage.get("rows") or [])
        action = str(job.get("action") or (request or {}).get("action") or "scrape")
        if action == "scrape":
            job["imdb_dataset_prepass_pending_1562"] = True
            job["imdb_dataset_prepass_done_1562"] = False
            job["imdb_dataset_checked_1562"] = 0
            job["imdb_dataset_found_1562"] = 0
            job["imdb_dataset_changed_1562"] = 0
    except Exception:
        pass
    return job


def _lrs_dataset_targets_1562(job, ensured):
    force = bool((job or {}).get("force"))
    auto_new = bool((job or {}).get("auto_new_only"))
    generation = core.imdb_dataset_generation_1562(ensured)
    applied = core.imdb_dataset_applied_generation_1562()
    pending_generation = bool(
        generation
        and generation != applied
        and not bool((ensured or {}).get("stale_fallback"))
    )

    if force:
        # Refresh All: every enabled movie, series, and episode is audited.
        return list((job or {}).get("scope_items") or core.library_items()), "all", True
    if auto_new:
        # Auto scan remains scoped to the newly added/reused DBID items.
        return list((job or {}).get("scope_items") or (job or {}).get("items") or []), "blank_only", False
    if pending_generation:
        # Manual Scrape Missing: a newly downloaded/unapplied dataset generation
        # updates IMDb for every enabled item, while online providers remain
        # restricted to the original missing-only scope.
        return core.library_items(), "all", True
    return list((job or {}).get("scope_items") or (job or {}).get("items") or []), "blank_only", False


def _prepare_imdb_dataset_prepass_1562(job, cache):
    if not (job or {}).get("imdb_dataset_prepass_pending_1562"):
        return
    phase = str((job or {}).get("phase") or "ratings").lower()
    if phase not in ("", "ratings"):
        job["imdb_dataset_prepass_pending_1562"] = False
        job["imdb_dataset_prepass_done_1562"] = True
        return

    job["current"] = "IMDb dataset batch"
    update_bg(job, "IMDb dataset batch")
    ensured = core.ensure_imdb_dataset_1562(False)
    targets, mode, mark_generation = _lrs_dataset_targets_1562(job, ensured)
    result = core.apply_imdb_dataset_batch_1562(targets, cache, ensured=ensured, mode=mode)
    annotations = result.get("annotations") or {}

    # The provider queue may use different item dictionaries from the all-library
    # batch. Copy exact lookup results onto those queue items so resolve_item()
    # never opens the dataset once per item.
    for item in (job or {}).get("items") or []:
        if not isinstance(item, dict):
            continue
        annotation = annotations.get(core.item_key(item))
        if isinstance(annotation, dict):
            item["__lrs_imdb_dataset_1562"] = dict(annotation)

    job["imdb_dataset_mode_1562"] = mode
    job["imdb_dataset_checked_1562"] = int(result.get("checked") or 0)
    job["imdb_dataset_found_1562"] = int(result.get("found") or 0)
    job["imdb_dataset_changed_1562"] = int(result.get("changed") or 0)
    job["imdb_dataset_generation_1562"] = result.get("generation") or ""
    job["imdb_dataset_refreshed_1562"] = bool((ensured or {}).get("refreshed"))
    job["imdb_dataset_stale_fallback_1562"] = bool((ensured or {}).get("stale_fallback"))
    job["imdb_dataset_prepass_pending_1562"] = False
    job["imdb_dataset_prepass_done_1562"] = True

    generation = str(result.get("generation") or "")
    if mark_generation and generation and not bool((ensured or {}).get("stale_fallback")):
        core.mark_imdb_dataset_generation_applied_1562(
            generation,
            "refresh_all" if bool(job.get("force")) else "scrape_missing_new_dataset",
        )
    core.save_cache(cache)
    write_job_state(job)


_advance_scrape_1562_base = advance_scrape


def advance_scrape(job, cache):
    if (job or {}).get("imdb_dataset_prepass_pending_1562"):
        try:
            _prepare_imdb_dataset_prepass_1562(job, cache)
        except Exception as exc:  # pylint: disable=broad-except
            job["imdb_dataset_prepass_pending_1562"] = False
            job["imdb_dataset_prepass_done_1562"] = True
            job["imdb_dataset_error_1562"] = str(exc)
            core.log("IMDb dataset batch prepass failed: {0}".format(exc), xbmc.LOGWARNING)
    return _advance_scrape_1562_base(job, cache)



# -----------------------------------------------------------------------------
# AF3-safe progress, active DBID handoff, and resilient lock cleanup
# -----------------------------------------------------------------------------
AUTO_LIBRARY_SCAN_STARTED_ITEMS_1600 = []
AUTO_DBID_HANDOFF_STATS_1600 = {"handed_off": 0, "rows": []}
# Runtime-only recovery state. This is not a legacy migration: it records only
# DBIDs Kodi explicitly reports as added during the current video scan and lets
# a service that starts mid-scan take a safe late snapshot.
AUTO_LIBRARY_SCAN_SNAPSHOT_CAPTURED_1620 = False
AUTO_LIBRARY_SCAN_ADDED_CANDIDATES_1620 = set()
AUTO_LIBRARY_SCAN_LATE_ACTIVE_1620 = False
AUTO_SCAN_LOCK_STALE_SECONDS_1530 = 180


def _word_ellipsis_1565(value, limit):
    text = re.sub(r"\s+", " ", str(value or "").strip())
    limit = max(0, int(limit or 0))
    if len(text) <= limit:
        return text
    if limit <= 1:
        return "…"[:limit]
    raw = text[:limit - 1].rstrip()
    if " " in raw:
        candidate = raw.rsplit(" ", 1)[0].rstrip()
        if candidate:
            raw = candidate
    return raw + "…"


def _progress_body_1500(processed, total, title, phase, limit=64):
    title = _progress_text_1500(title)
    phase = str(phase or "RATINGS").upper()
    prefix = "{0}/{1} ".format(processed, total)
    suffix = " - {0}".format(phase)
    full = prefix + title + suffix
    if len(full) <= 65:
        return full
    target = 64
    match = re.match(r"^(.*?)\s+-\s+(S\d{2}E\d{2})\s+-\s+(.*)$", title, re.I)
    if match:
        episode_title, sxex, show = match.group(1).strip(), match.group(2).upper(), match.group(3).strip()
        fixed = prefix + " - " + sxex + " - " + show + suffix
        episode_budget = target - len(fixed)
        if episode_budget > 0:
            body = prefix + _word_ellipsis_1565(episode_title, episode_budget) + " - " + sxex + " - " + show + suffix
            if len(body) <= target:
                return body
        base = prefix + sxex + " - " + show + suffix
        if len(base) <= target:
            return base
        show_budget = target - len(prefix + sxex + " - " + suffix)
        show = _word_ellipsis_1565(show, show_budget)
        return prefix + sxex + " - " + show + suffix
    available = target - len(prefix) - len(suffix)
    return prefix + _word_ellipsis_1565(title, available) + suffix


def _library_key_snapshot_1420():
    global AUTO_LIBRARY_SCAN_STARTED_ITEMS_1600, AUTO_LIBRARY_SCAN_SNAPSHOT_CAPTURED_1620
    try:
        items = [dict(item) for item in core.library_items() if core.resolvable_library_item(item)]
        AUTO_LIBRARY_SCAN_STARTED_ITEMS_1600 = items
        AUTO_LIBRARY_SCAN_SNAPSHOT_CAPTURED_1620 = True
        return set(core.item_key(item) for item in items)
    except Exception as exc:
        AUTO_LIBRARY_SCAN_STARTED_ITEMS_1600 = []
        AUTO_LIBRARY_SCAN_SNAPSHOT_CAPTURED_1620 = False
        core.log("Auto scrape detailed snapshot failed: {0}".format(exc), xbmc.LOGWARNING)
        return set()


def _auto_new_items_after_scan_1420(cache, before_keys, candidate_keys=None, snapshot_captured=True):
    """Return verified post-scan additions and hand off matching replacements.

    Normal mode uses the exact before/after DBID delta. Recovery mode is used
    only when the service missed ScanStarted; it accepts DBIDs that Kodi itself
    reported with VideoLibrary.OnUpdate added=true during this scan. A generic
    cache miss is never enough to enter this queue.
    """
    global AUTO_DBID_HANDOFF_STATS_1600
    before_keys = set(before_keys or [])
    candidate_keys = set(candidate_keys or [])
    current_items = [dict(item) for item in core.library_items() if core.resolvable_library_item(item)]
    current_by_key = dict((core.item_key(item), item) for item in current_items if core.item_key(item))
    selected = []
    seen = set()
    cache_items = (cache or {}).get('items') or {}
    if snapshot_captured:
        wanted = set(current_by_key).difference(before_keys)
    else:
        wanted = set(current_by_key).intersection(candidate_keys)
    for key in sorted(wanted):
        item = current_by_key.get(key)
        if not item or key in seen:
            continue
        existing = cache_items.get(key) or {}
        # Existing matching rows are not new. A conflicting row is a DBID-reuse
        # candidate and must pass the normal identity guard/scrape path.
        if existing and core.cache_identity_matches_1558(item, existing):
            continue
        selected.append(item)
        seen.add(key)

    # A detailed scan snapshot is ideal. If it was missed, cache rows still
    # carry the old DBID, typed IDs, title, coordinates and source path needed
    # for a conservative one-to-one active handoff.
    old_items = list(AUTO_LIBRARY_SCAN_STARTED_ITEMS_1600 or [])
    if not old_items:
        old_items = []
        for old_key, row in cache_items.items():
            if old_key in current_by_key or not isinstance(row, dict):
                continue
            old = dict(row)
            if not old.get('type') or core.safe_int(old.get('dbid')) is None:
                try:
                    media, raw_dbid = str(old_key).split('|', 1)
                    old.setdefault('type', media)
                    old.setdefault('dbid', int(raw_dbid))
                except Exception:
                    continue
            old_items.append(old)
    rows, remaining, plans = [], [], []

    # Resolve all pairs before moving anything. One old DBID may map to only one
    # new DBID, and identity must be strong enough to describe the same media.
    for new_item in selected:
        new_key = core.item_key(new_item)
        candidates = []
        for old_item in old_items:
            old_key = core.item_key(old_item)
            if old_key == new_key or old_key not in cache_items:
                continue
            if not core.handoff_source_replaced_1600(old_item, new_item):
                continue
            if core.handoff_identity_matches_1600(old_item, new_item):
                candidates.append(old_item)
        if len(candidates) == 1:
            plans.append((new_item, candidates[0]))
        else:
            remaining.append(new_item)
            if len(candidates) > 1:
                core.log('Rating handoff skipped for {0}: ambiguous old DBID candidates {1}'.format(
                    new_key, [core.item_key(item) for item in candidates]), xbmc.LOGWARNING)

    old_counts = {}
    for _new_item, old_item in plans:
        old_key = core.item_key(old_item)
        old_counts[old_key] = old_counts.get(old_key, 0) + 1
    valid_plans = []
    for new_item, old_item in plans:
        old_key = core.item_key(old_item)
        if old_counts.get(old_key, 0) == 1:
            valid_plans.append((new_item, old_item))
        else:
            remaining.append(new_item)
            core.log('Rating handoff skipped: old key {0} matched multiple new items'.format(old_key), xbmc.LOGWARNING)

    progress = None
    if valid_plans:
        try:
            progress = xbmcgui.DialogProgressBG()
            progress.create(TITLE, 'MIGRATING RATINGS - {0} ITEMS'.format(len(valid_plans)))
        except Exception:
            progress = None
    try:
        for index, (new_item, old_item) in enumerate(valid_plans, 1):
            if progress is not None:
                try:
                    body = _progress_body_1500(index, len(valid_plans), item_label(new_item), 'MIGRATED')
                    progress.update(int(index * 100 / float(len(valid_plans) or 1)), TITLE, body)
                except Exception:
                    pass
            result = core.handoff_cache_record_1600(cache, old_item, new_item)
            if not result.get('handed_off'):
                remaining.append(new_item)
                continue
            new_key = core.item_key(new_item)
            rows.append({
                'old_key': result.get('old_key'), 'new_key': result.get('new_key'),
                'title': new_item.get('title') or '', 'showtitle': new_item.get('showtitle') or '',
                'season': new_item.get('season'), 'episode': new_item.get('episode'),
                'old_file': old_item.get('file') or '', 'new_file': new_item.get('file') or '',
            })
            handed_off_record = ((cache or {}).get('items') or {}).get(new_key) or {}
            if core.record_needs_update(new_item, handed_off_record):
                remaining.append(new_item)
    finally:
        if progress is not None:
            try:
                progress.close()
            except Exception:
                pass

    AUTO_DBID_HANDOFF_STATS_1600 = {'handed_off': len(rows), 'rows': rows}
    if rows:
        core.save_cache(cache)
        core.write_dbid_handoff_report_1600(rows)
        core.log('Auto rating handoff completed: {0} item(s) moved to new DBIDs'.format(len(rows)), xbmc.LOGINFO)
        try:
            notify('RATINGS MIGRATED - {0} ITEMS'.format(len(rows)), xbmcgui.NOTIFICATION_INFO, 5000)
        except Exception:
            pass
    return remaining


_consume_auto_scan_job_handoff_base_1600 = _consume_auto_scan_job_1420


def _consume_auto_scan_job_1420(cache):
    job = _consume_auto_scan_job_handoff_base_1600(cache)
    stats = dict(AUTO_DBID_HANDOFF_STATS_1600 or {})
    if job is not None:
        job["handed_off"] = int(stats.get("handed_off") or 0)
        job["handoff_rows"] = list(stats.get("rows") or [])
        if job.get("handed_off"):
            update_bg(job, "{0} RATINGS MIGRATED".format(job.get("handed_off")))
            write_job_state(job)
    return job


_finish_job_handoff_base_1600 = finish_job


def finish_job(job, cache, canceled=False, stopped_reason=""):
    result = _finish_job_handoff_base_1600(job, cache, canceled, stopped_reason)
    try:
        summary = core._load_json(core.SUMMARY_FILE) or {}
        summary["handed_off"] = int((job or {}).get("handed_off") or 0)
        summary["scraped_online"] = int((job or {}).get("looked_up") or 0)
        core.save_summary(summary)
    except Exception:
        pass
    return result


def _touch_auto_lock_1565():
    try:
        lock = _read_auto_lock_1530()
        if str(lock.get("addon") or "") == "script.library.ratings.scraper" and os.path.exists(AUTO_SCAN_LOCK_FILE_1530):
            os.utime(AUTO_SCAN_LOCK_FILE_1530, None)
    except Exception:
        pass


_update_bg_1565_base = update_bg


def update_bg(job, message=None):
    result = _update_bg_1565_base(job, message)
    if (job or {}).get("shared_auto_scan_lock") or (job or {}).get("auto_new_only"):
        _touch_auto_lock_1565()
    return result


_acquire_auto_lock_1565_base = _acquire_auto_lock_1530


def _acquire_auto_lock_1530():
    try:
        if os.path.exists(AUTO_SCAN_LOCK_FILE_1530):
            lock = _read_auto_lock_1530()
            if str(lock.get("addon") or "") == "script.library.ratings.scraper" and int(lock.get("pid") or 0) != os.getpid():
                os.remove(AUTO_SCAN_LOCK_FILE_1530)
                core.log("Removed stale LRS auto-scan lock from previous service instance", xbmc.LOGINFO)
    except Exception:
        pass
    return _acquire_auto_lock_1565_base()


def _capture_late_start_snapshot_1620():
    """Capture a safe baseline when the service starts during an active scan."""
    global AUTO_LIBRARY_SCAN_STARTED_KEYS, AUTO_LIBRARY_SCAN_ADDED_CANDIDATES_1620, AUTO_LIBRARY_SCAN_LATE_ACTIVE_1620
    try:
        if not core.bool_setting("auto_scrape_new_items_after_library_update", False):
            return False
        if not xbmc.getCondVisibility("Library.IsScanningVideo"):
            return False
        AUTO_LIBRARY_SCAN_ADDED_CANDIDATES_1620 = set()
        AUTO_LIBRARY_SCAN_STARTED_KEYS = _library_key_snapshot_1420()
        AUTO_LIBRARY_SCAN_LATE_ACTIVE_1620 = True
        core.log("Auto scrape late-start snapshot captured during active video scan: {0} items".format(
            len(AUTO_LIBRARY_SCAN_STARTED_KEYS or [])), xbmc.LOGINFO)
        return True
    except Exception as exc:  # pylint: disable=broad-except
        core.log("Auto scrape late-start snapshot failed: {0}".format(exc), xbmc.LOGWARNING)
        return False


_main_1620_base = main


def main():
    _capture_late_start_snapshot_1620()
    return _main_1620_base()


_main_1565_base = main


def main():
    try:
        lock = _read_auto_lock_1530()
        if str(lock.get("addon") or "") == "script.library.ratings.scraper" and int(lock.get("pid") or 0) != os.getpid():
            _release_auto_lock_1530()
    except Exception:
        pass
    try:
        return _main_1565_base()
    finally:
        _release_auto_lock_1530()



# -----------------------------------------------------------------------------
# v1.5.67 - family progress and zero-delay dataset closeout
# -----------------------------------------------------------------------------
def _strip_episode_prefix_1567(title, season=None, episode=None):
    value = re.sub(r"\s+", " ", str(title or "").strip())
    try:
        sx = "S{0:02d}E{1:02d}".format(int(season or 0), int(episode or 0))
        x = "{0}X{1:02d}".format(int(season or 0), int(episode or 0))
        patterns = [r"^" + re.escape(sx) + r"\s*[.:-]?\s*", r"^" + re.escape(x) + r"\s*[.:-]?\s*"]
        for pattern in patterns:
            cleaned = re.sub(pattern, "", value, flags=re.I).strip()
            if cleaned != value:
                return cleaned
    except Exception:
        pass
    return value


def _progress_body_1500(processed, total, title, phase, limit=58):
    text = _progress_text_1500(title)
    phase = str(phase or "RATINGS").upper().strip()
    match = re.match(r"^(.*?)\s+-\s+(S\d{2}E\d{2})\s+-\s+(.*)$", text, re.I)
    if match:
        ep, sxex, show = match.groups()
        sm = re.match(r"S(\d{2})E(\d{2})", sxex, re.I)
        ep = _strip_episode_prefix_1567(ep, int(sm.group(1)), int(sm.group(2))) if sm else ep
        text = "{0} - {1} - {2}".format(ep.upper(), sxex.upper(), show.upper())
    else:
        text = str(text or "").upper()
    prefix = "{0}/{1} ".format(processed, total)
    suffix = " - {0}".format(phase) if phase else ""
    full = prefix + text + suffix
    target = int(limit or 58)
    if len(full) <= target:
        return full.rstrip()
    if match:
        ep, sxex, show = text.rsplit(" - ", 2)
        fixed = prefix + " - " + sxex + " - " + show + suffix
        budget = target - len(fixed)
        if budget > 0:
            candidate = prefix + _word_ellipsis_1565(ep, budget) + " - " + sxex + " - " + show + suffix
            if len(candidate) <= target:
                return candidate.rstrip()
        show_budget = target - len(prefix + sxex + " - " + suffix)
        return (prefix + sxex + " - " + _word_ellipsis_1565(show, show_budget) + suffix).rstrip()
    return (prefix + _word_ellipsis_1565(text, target-len(prefix)-len(suffix)) + suffix).rstrip()


def _prepare_imdb_dataset_prepass_1562(job, cache):
    if not (job or {}).get("imdb_dataset_prepass_pending_1562"):
        return
    phase = str((job or {}).get("phase") or "ratings").lower()
    if phase not in ("", "ratings"):
        job["imdb_dataset_prepass_pending_1562"] = False
        job["imdb_dataset_prepass_done_1562"] = True
        return
    job["current"] = "IMDb dataset batch"
    update_bg(job, "IMDB DATASET")
    ensured = core.ensure_imdb_dataset_1562(False)
    targets, mode, mark_generation = _lrs_dataset_targets_1562(job, ensured)
    result = core.apply_imdb_dataset_batch_1562(targets, cache, ensured=ensured, mode=mode)
    annotations = result.get("annotations") or {}
    for item in (job or {}).get("items") or []:
        if isinstance(item, dict):
            annotation = annotations.get(core.item_key(item))
            if isinstance(annotation, dict):
                item["__lrs_imdb_dataset_1562"] = dict(annotation)
    job["imdb_dataset_mode_1562"] = mode
    job["imdb_dataset_checked_1562"] = int(result.get("checked") or 0)
    job["imdb_dataset_found_1562"] = int(result.get("found") or 0)
    job["imdb_dataset_na_1567"] = int(result.get("unavailable") or 0)
    job["imdb_dataset_changed_1562"] = int(result.get("changed") or 0)
    job["imdb_dataset_generation_1562"] = result.get("generation") or ""
    job["imdb_dataset_refreshed_1562"] = bool((ensured or {}).get("refreshed"))
    job["imdb_dataset_stale_fallback_1562"] = bool((ensured or {}).get("stale_fallback"))
    job["imdb_dataset_prepass_pending_1562"] = False
    job["imdb_dataset_prepass_done_1562"] = True
    # In missing-only jobs, remove rows fully closed by the local batch. This is
    # what prevents a 1.1-second online delay per definitive IMDb N/A.
    if not bool((job or {}).get("force")):
        remaining = []
        cache_items = (cache or {}).get("items") or {}
        for item in list((job or {}).get("items") or []):
            record = cache_items.get(core.item_key(item)) or {}
            if core.record_missing_logicals(item.get("type"), record):
                remaining.append(item)
        job["items"] = remaining
        job["total"] = len(remaining)
    generation = str(result.get("generation") or "")
    if mark_generation and generation and not bool((ensured or {}).get("stale_fallback")):
        core.mark_imdb_dataset_generation_applied_1562(
            generation, "refresh_all" if bool(job.get("force")) else "scrape_missing_new_dataset")
    core.save_cache(cache)
    write_job_state(job)


_finish_job_1567_base = finish_job

def finish_job(job, cache, canceled=False, stopped_reason=""):
    result = _finish_job_1567_base(job, cache, canceled, stopped_reason)
    try:
        summary = core._load_json(core.SUMMARY_FILE) or {}
        summary["imdb_dataset_checked"] = int((job or {}).get("imdb_dataset_checked_1562") or 0)
        summary["imdb_dataset_rated"] = int((job or {}).get("imdb_dataset_found_1562") or 0)
        summary["imdb_dataset_na"] = int((job or {}).get("imdb_dataset_na_1567") or 0)
        core.save_summary(summary)
    except Exception:
        pass
    return result


# -----------------------------------------------------------------------------
# v1.5.69 - stable external focus and strict upcoming clear
# -----------------------------------------------------------------------------
_publish_current_1569_base = publish_current


def _clear_external_display_1569(item, key, state, reason):
    compatibility = core.bool_setting("publish_af3_cache", True)
    try:
        core.publish_af3_properties({}, key, compatibility)
    except Exception:
        pass
    try:
        _set_af3_display_active_1531(False)
    except Exception:
        pass
    try:
        context_log(state if isinstance(state, dict) else {}, "listitem", key,
                    (item or {}).get("title"), False, reason)
    except Exception:
        pass


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    global EXTERNAL_FOCUS_PENDING, EXTERNAL_FOCUS_LAST_KEY, EXTERNAL_FOCUS_LAST_SEEN
    external_key = _external_focus_key_1430(item)
    if not external_key or str(context or "").lower() in ("player", "screensaver"):
        return _publish_current_1569_base(cache, item, previous_key, context, state, preload)

    # A future item must never inherit the row of the previously focused movie.
    if not core.external_item_released_1430(item):
        EXTERNAL_FOCUS_PENDING = {}
        EXTERNAL_FOCUS_LAST_KEY = external_key
        EXTERNAL_FOCUS_LAST_SEEN = time.time()
        _clear_external_display_1569(item, external_key, state, "external_upcoming_clear_1569")
        return external_key

    # Library matches and completed external cache rows use the normal publisher.
    try:
        if core.find_library_record_for_external_1450(item) or core.load_external_record_1430(item):
            return _publish_current_1569_base(cache, item, previous_key, context, state, preload)
    except Exception:
        pass

    # Released cache miss: clear stale values first, then debounce and resolve.
    _clear_external_display_1569(item, external_key, state, "external_cache_miss_clear_1569")
    now = time.time()
    if external_key != EXTERNAL_FOCUS_LAST_KEY:
        EXTERNAL_FOCUS_LAST_KEY = external_key
        EXTERNAL_FOCUS_LAST_SEEN = now
        EXTERNAL_FOCUS_PENDING = {}
        return external_key
    if now - EXTERNAL_FOCUS_LAST_SEEN >= 0.65:
        EXTERNAL_FOCUS_PENDING = {"key": external_key, "item": dict(item or {}), "queued_at": now}
        try:
            _process_external_focus_1430()
        except Exception as exc:
            core.log("External focus 1.5.69 failed: {0}".format(exc), xbmc.LOGWARNING)
    return external_key



# -----------------------------------------------------------------------------
# v1.6.3 - automatic local CropV2 resolver bootstrap
# -----------------------------------------------------------------------------
def _bootstrap_clearlogo_resolver_1630():
    try:
        path = str(getattr(core, "CLEARLOGO_RESOLVER_DB_FILE_1547", "") or "")
        needs_build = not path or not os.path.isfile(path) or os.path.getsize(path) <= 0
        if not needs_build:
            try:
                import sqlite3
                uri = "file:{0}?mode=ro".format(path.replace("\\", "/"))
                conn = sqlite3.connect(uri, uri=True, timeout=10)
                try:
                    count = int(conn.execute("SELECT COUNT(*) FROM resolver_items").fetchone()[0])
                    needs_build = count <= 0
                finally:
                    conn.close()
            except Exception:
                needs_build = True
        if needs_build:
            core.log("CropV2 resolver cache is absent; starting local bootstrap", xbmc.LOGINFO)
            result = core.build_clearlogo_resolver_cache_1547(False, None)
            core.log(
                "CropV2 resolver bootstrap completed resolved={0} missing={1} no_source={2}".format(
                    int(result.get("resolved") or 0), int(result.get("cropv2_missing") or 0), int(result.get("no_source") or 0)
                ), xbmc.LOGINFO,
            )
    except Exception as exc:
        core.log("CropV2 resolver bootstrap failed: {0}".format(exc), xbmc.LOGWARNING)


_main_1630_base = main

def main():
    worker = threading.Thread(target=_bootstrap_clearlogo_resolver_1630, name="LRS-CropV2-Bootstrap")
    worker.daemon = True
    worker.start()
    return _main_1630_base()


# -----------------------------------------------------------------------------
# v1.6.6 - atomic Arctic Mirage metadata bundle
# -----------------------------------------------------------------------------
# Plot, rating row and clearlogo/title are one visual unit. The XML reads one
# readiness flag, set only after the rating identity and clearlogo identity are
# both complete for the same active MediaHub slide.
_SCREENSAVER_BUNDLE_SIGNATURE_1660 = None
_publish_current_1660_base = publish_current


def _screensaver_home_property_1660(home, name):
    try:
        return str(home.getProperty("LibraryRatings.Screensaver." + name) or "").strip()
    except Exception:
        return ""


def _publish_screensaver_bundle_1660(item):
    global _SCREENSAVER_BUNDLE_SIGNATURE_1660
    try:
        home = xbmcgui.Window(10000)
        current_key = xbmc.getInfoLabel(
            "Container(1297).ListItem.Property(mediahub_item_key)"
        ).strip()
        if not current_key:
            try:
                current_key = core.identity_key(item or {})
            except Exception:
                current_key = ""

        rating_key = _screensaver_home_property_1660(home, "ItemKey")
        rating_ready = (
            _screensaver_home_property_1660(home, "HasData").lower() == "true"
            and bool(current_key)
            and rating_key == current_key
        )
        logo_key = _screensaver_home_property_1660(home, "ClearLogoFinalItemKey")
        logo_ready = (
            _screensaver_home_property_1660(home, "ClearLogoResolverReady").lower() == "true"
            and bool(current_key)
            and logo_key == current_key
        )
        ready = bool(current_key and rating_ready and logo_ready)
        signature = (current_key, rating_key, rating_ready, logo_key, logo_ready, ready)
        if signature == _SCREENSAVER_BUNDLE_SIGNATURE_1660:
            return

        # Publish diagnostics first and the gate last. Kodi may observe Window
        # properties between calls, but it cannot reveal a partial bundle because
        # BundleReady remains false until every component matches the same key.
        home.setProperty("LibraryRatings.Screensaver.BundleReady", "false")
        home.setProperty("LibraryRatings.Screensaver.BundleItemKey", current_key)
        home.setProperty(
            "LibraryRatings.Screensaver.BundleRatingReady",
            "true" if rating_ready else "false",
        )
        home.setProperty(
            "LibraryRatings.Screensaver.BundleLogoReady",
            "true" if logo_ready else "false",
        )
        if ready:
            home.setProperty("LibraryRatings.Screensaver.BundleReady", "true")
        _SCREENSAVER_BUNDLE_SIGNATURE_1660 = signature
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("Screensaver atomic bundle publish failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    result = _publish_current_1660_base(cache, item, previous_key, context, state, preload)
    if str(context or "").lower() == "screensaver":
        _publish_screensaver_bundle_1660(item or {})
    return result


# -----------------------------------------------------------------------------
# v1.6.7 - strong media identity + dual-slot screensaver snapshots
# -----------------------------------------------------------------------------
# The global live bridge still prepares one exact current item. Once that bundle
# is complete, copy it into the A or B snapshot selected by the current MWH
# ListItem. The other slot remains untouched during its 400 ms fade-out.
_SCREENSAVER_DUAL_LAST_1670 = {"A": None, "B": None}
_publish_current_1670_base = publish_current

_SCREENSAVER_DUAL_COPY_NAMES_1670 = tuple(
    [
        "HasData", "ItemKey", "DBType", "Oscar_Wins", "Emmy_Wins",
        "Series_StatusLabel", "ClearLogoFinal", "ClearLogoFinalMode",
        "ClearLogoFinalItemKey", "ClearLogoResolverReady",
        "BundleRatingReady", "BundleLogoReady",
    ]
    + [
        "RatingSlot{0}_{1}".format(idx, suffix)
        for idx in range(1, 8)
        for suffix in ("Source", "IconFile", "Label")
    ]
)


def _screensaver_bundle_slot_1670():
    try:
        slot = xbmc.getInfoLabel(
            "Container(1297).ListItem.Property(mediahub_bundle_slot)"
        ).strip().upper()
    except Exception:
        slot = ""
    return slot if slot in ("A", "B") else ""


def _publish_screensaver_dual_bundle_1670(item):
    try:
        home = xbmcgui.Window(10000)
        slot = _screensaver_bundle_slot_1670()
        current_key = xbmc.getInfoLabel(
            "Container(1297).ListItem.Property(mediahub_item_key)"
        ).strip()
        if not slot or not current_key:
            return

        prefix = "LibraryRatings.Screensaver.Bundle{0}.".format(slot)
        current_slot_key = str(home.getProperty(prefix + "ItemKey") or "").strip()
        if current_slot_key != current_key:
            # Fail closed before reusing this parity slot two slides later.
            home.setProperty(prefix + "Ready", "false")
            home.setProperty(prefix + "ItemKey", current_key)
            _SCREENSAVER_DUAL_LAST_1670[slot] = None

        global_ready = (
            str(home.getProperty("LibraryRatings.Screensaver.BundleReady") or "").lower() == "true"
            and str(home.getProperty("LibraryRatings.Screensaver.BundleItemKey") or "").strip() == current_key
        )
        if not global_ready:
            return

        snapshot = {}
        for name in _SCREENSAVER_DUAL_COPY_NAMES_1670:
            snapshot[name] = str(
                home.getProperty("LibraryRatings.Screensaver." + name) or ""
            )
        snapshot["Title"] = str(
            xbmc.getInfoLabel("Container(1297).ListItem.Title")
            or snapshot.get("Title") or (item or {}).get("title") or ""
        )
        snapshot["Plot"] = str(
            xbmc.getInfoLabel("Container(1297).ListItem.Plot") or ""
        )
        signature = tuple([current_key] + [snapshot.get(name, "") for name in sorted(snapshot)])
        if _SCREENSAVER_DUAL_LAST_1670.get(slot) == signature:
            return

        home.setProperty(prefix + "Ready", "false")
        for name, value in snapshot.items():
            home.setProperty(prefix + name, str(value or ""))
        home.setProperty(prefix + "ItemKey", current_key)
        home.setProperty(prefix + "Ready", "true")
        _SCREENSAVER_DUAL_LAST_1670[slot] = signature
    except Exception as exc:  # pylint: disable=broad-except
        try:
            core.log("Screensaver dual bundle publish failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    result = _publish_current_1670_base(cache, item, previous_key, context, state, preload)
    if str(context or "").lower() == "screensaver":
        _publish_screensaver_dual_bundle_1670(item or {})
    return result


# -----------------------------------------------------------------------------
# v1.6.12 - persistent movie-collection aggregate cache
# -----------------------------------------------------------------------------
from resources.lib import collection_aggregates as collection_aggregates_1612

_current_context_item_1612_base = current_context_item

def current_context_item():
    # Movie sets are not valid movie rows, but they now own a persistent
    # aggregate record and must be published instead of clearing the panel.
    for getter_name in ("selected_library_item", "lrs_active_item", "hub_focus_container_item"):
        getter = getattr(core, getter_name, None)
        if not callable(getter):
            continue
        try:
            item = getter() or {}
        except Exception:
            continue
        if collection_aggregates_1612.is_collection_item(item):
            return "collection", item
    return _current_context_item_1612_base()

_publish_current_1612_base = publish_current

def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    if str(context or "").lower() == "collection" or collection_aggregates_1612.is_collection_item(item or {}):
        shown = collection_aggregates_1612.publish_for_item(item or {})
        key = "set|{}".format(
            core.safe_int((item or {}).get("dbid") or (item or {}).get("DBID") or (item or {}).get("idSet")) or ""
        ).rstrip("|")
        context_log(state if isinstance(state, dict) else {}, "collection", key, (item or {}).get("title"), shown, "collection_aggregate_publish_1612" if shown else "collection_aggregate_missing_1612")
        return key or previous_key or ""
    collection_aggregates_1612.clear_properties()
    return _publish_current_1612_base(cache, item, previous_key, context, state, preload)

_main_1612_base = main

def main():
    worker = threading.Thread(target=collection_aggregates_1612.worker, name="LRS-Collection-Aggregates")
    worker.daemon = True
    worker.start()
    return _main_1612_base()

if __name__ == "__main__":
    main()

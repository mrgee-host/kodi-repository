Library Ratings Scraper 1.3.63

Fixes:
- Do not call OMDb for movie/tvshow ratings. Movie/tvshow rating flow remains MDBList-only.
- OMDb is called only for movie/tvshow awards when Awards is ON.
- Episodes still use OMDb + TMDb.
- API settings labels are explicit: MDBList API key 1/2 and OMDb API key 1/2.
- Guards against swapped API keys: long tokens are MDBList, 8-character keys are OMDb.
- Keeps 1.3.62 force-online/no-Kodi-local behavior.

Library Ratings Scraper 1.3.72

Adds AF3/LRS display integration support:
- Sticky publisher: ratings no longer disappear when focus moves to buttons/dialogs.
- Display settings separate from scrape settings.
- Publishes full rating namespace for AF3/screensaver.
- Publishes Rotten Tomatoes icon filenames based on cached DB image keys.
- Preserves current scrape/Top250 DB flow from 1.3.70.

Install the addon zip, then run the included AF3 patcher to inject skin/screensaver XML blocks.

Library Ratings Scraper 1.3.70

Fixes:
- Manual Sync local IMDb Top 250 now updates the ratings-only SQLite table directly.
- Removed broken _ensure_cache_entry path from Top250 sync.
- Top250 setting is unified into one checkbox: IMDb Top 250.
- Menu labels changed: Scrape missing enabled data / Refresh all enabled data / Sync local IMDb Top 250.
- Top250 still uses resources/data/imdb_top_250.db or profile override imdb_top_250.db only; no IMDb web scrape.

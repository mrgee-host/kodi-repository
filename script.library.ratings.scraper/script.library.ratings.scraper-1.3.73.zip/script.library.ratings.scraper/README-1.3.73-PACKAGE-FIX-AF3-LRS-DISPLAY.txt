Library Ratings Scraper 1.3.73

Fixes the 1.3.72 addon.xml package metadata:
- XML declaration is now version 1.0
- addon.xml version is now 1.3.73
- pycache files removed from release ZIP

Keeps the 1.3.72 AF3/LRS display integration work:
- sticky display publisher
- LRS display toggles
- Rotten icon key publishing
- local IMDb Top250 DB flow from 1.3.70

# -*- coding: utf-8 -*-
from __future__ import annotations

import xbmc
import xbmcgui

from resources.lib import core

TITLE = "Library Ratings Scraper"


def _context_item():
    # Context menu normally exposes ListItem.* for the selected row/card.
    for getter in (core.selected_library_item, core.hub_focus_container_item, core.lrs_active_item, core.tmdbhelper_item):
        try:
            item = getter()
        except Exception:  # pylint: disable=broad-except
            item = {}
        if core.valid_library_item(item):
            return item
    return {}


def refresh_selected_item():
    dialog = xbmcgui.Dialog()
    item = _context_item()
    if not core.valid_library_item(item):
        dialog.notification(TITLE, "No movie / TV show / episode identity found", xbmcgui.NOTIFICATION_WARNING, 5000, False)
        return

    media_type = item.get("type") or "item"
    title = item.get("title") or item.get("showtitle") or "Selected item"
    if item.get("type") == "episode":
        title = "{0} S{1:02d}E{2:02d} - {3}".format(
            item.get("showtitle") or "Series",
            core.safe_int(item.get("season")) or 0,
            core.safe_int(item.get("episode")) or 0,
            item.get("title") or "Episode",
        )

    if not dialog.yesno(TITLE, "Refresh ratings for:\n\n{0}\n\nThis ignores media include checkboxes, but follows enabled rating/provider settings.".format(title), nolabel="Cancel", yeslabel="Refresh"):
        return

    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Refreshing selected {0}...".format(media_type))
    try:
        cache = core.load_cache()
        existing = core.cache_record(cache, item) or {}
        progress.update(20, "Looking up ratings...")
        refreshed = core.resolve_item(item, core.api_keys(), existing, missing_only=False, include_local=False, ratings_only=True)
        # Ratings-only context refresh must not rewrite status/awards/top250.
        refreshed["series"] = existing.get("series") or refreshed.get("series") or {}
        refreshed["awards"] = existing.get("awards") or refreshed.get("awards") or {}
        refreshed["imdb_top250_rank"] = core.safe_int(existing.get("imdb_top250_rank")) or core.safe_int(refreshed.get("imdb_top250_rank")) or 0
        key = core.item_key(refreshed)
        if not key or key.endswith("|"):
            key = core.item_key(item)
        cache.setdefault("items", {})[key] = refreshed
        progress.update(80, "Saving cache...")
        core.save_cache(cache)
        values = core.af3_values(refreshed)
        values["SourceContext"] = "context"
        core.publish_af3_properties(values, key, core.bool_setting("publish_af3_cache", True))
        progress.update(100, "Done")
        dialog.notification(TITLE, "Selected item ratings refreshed", xbmcgui.NOTIFICATION_INFO, 5000, False)
    except core.ProviderLimitReached as exc:
        dialog.ok(TITLE, "API limit reached:\n{0}".format(exc))
    except Exception as exc:  # pylint: disable=broad-except
        core.log("Context refresh failed: {0}".format(exc), xbmc.LOGERROR)
        dialog.ok(TITLE, "Refresh failed:\n{0}".format(exc))
    finally:
        try:
            progress.close()
        except Exception:  # pylint: disable=broad-except
            pass


if __name__ == "__main__":
    refresh_selected_item()

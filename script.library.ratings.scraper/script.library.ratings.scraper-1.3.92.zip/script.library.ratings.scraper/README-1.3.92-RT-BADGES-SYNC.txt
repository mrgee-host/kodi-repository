Library Ratings Scraper 1.3.92 - Rotten Tomatoes badge sync

Adds menu: Sync Rotten Tomatoes badges.

Policy:
- Certified Fresh upgrades existing critic RT image token to certified.
- Verified Hot upgrades existing audience RT image token to verifiedhot.
- RT score fields are not changed.
- No downgrade when a title is not present in the current scraped RT browse pages.
- Logs: rt-badge-sync-last.json and rt-badge-sync-report.csv in addon_data/script.library.ratings.scraper.

Required skin icons:
- certified.png
- verifiedhot.png

AF3 r7 patch remains the stable skin patch base; no XML skin repatch is required if icons exist.

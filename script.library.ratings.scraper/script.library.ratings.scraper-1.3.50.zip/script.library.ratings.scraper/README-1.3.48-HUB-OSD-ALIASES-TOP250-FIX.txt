Library Ratings Scraper 1.3.48

Fixes:
- Top250 property now publishes plain number (2) instead of #2 to avoid AF3 showing ##2.
- Adds Top250_Rank/#2 legacy alias separately.
- Adds IMDb/TMDb aliases used by different AF3 windows: IMDb, IMDB, imdb, TMDb, TMDB, tmdb, *_rating variants.
- OSD should no longer miss TMDb when a different property alias is used.
- AF3 hub window 1102 now prefers Container(503).ListItem identity before secondary focused fixedlists like 601. This avoids the hero/detail rating row losing IMDb when focus moves to another list.
- Adds Debug logging setting to addon settings.

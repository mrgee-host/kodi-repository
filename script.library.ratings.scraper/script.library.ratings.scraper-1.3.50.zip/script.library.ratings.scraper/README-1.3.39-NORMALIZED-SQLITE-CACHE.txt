Library Ratings Scraper 1.3.39

Fixes the SQLite cache schema from v1.3.38.

Changes:
- Removed the JSON payload column from the main cache table.
- Cache is now normalized into real columns/tables:
  - items: IDs, title/showtitle, season/episode/year, status, awards, Top250, timestamps.
  - ratings: one row per item/rating logical with provider/source/value/score/votes/no_rating.
  - metadata and top250_movie stay as small helper tables.
- provider_meta, raw provider attempts, errors, byte counts, payload keys, and other noisy debug-only data are not stored in the DB cache.
- Existing v1.3.38 payload DB is migrated automatically by reading old payload rows, dropping the old table, and rewriting the normalized schema.

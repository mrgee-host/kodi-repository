Library Ratings Scraper 1.3.42

Changes:
- ratings table now uses TMDbHelper-style Rotten Tomatoes columns:
  rottentomatoes, rottentomatoes_image, rottentomatoes_user, rottentomatoes_userimage.
- rottentomatoes_image values are tokens: certified / fresh / rotten, not png filenames.
- rottentomatoes_userimage values are tokens: upright / spilled.
- Rating value format is scale-aware:
  IMDb/TMDb/Trakt/Letterboxd = one decimal on a 0-10 scale.
  Rotten Tomatoes/RT Audience/Metacritic/MDBList = whole integer on a 0-100 percent scale.
- 0 and 0.0 are still saved as NO_RATING.
- Older simple-wide DBs are migrated automatically to the new column names.

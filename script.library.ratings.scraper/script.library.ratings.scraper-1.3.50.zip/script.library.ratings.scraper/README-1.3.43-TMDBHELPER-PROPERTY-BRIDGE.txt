Library Ratings Scraper 1.3.43

Clarifies and strengthens the AF3/TMDbHelper bridge:
- Does not inject into TMDbHelper database.
- Publishes cached values to Window(Home).Property(TMDbHelper.ListItem.*) so Arctic Fuse 3 can read them using the same namespace it already expects.
- Also publishes lowercase TMDbHelper-style property aliases: rottentomatoes, rottentomatoes_image, rottentomatoes_user, rottentomatoes_userimage.
- Rotten image values are tokens compatible with TMDbHelper DB style: certified / fresh / rotten and upright / spilled.

Library Ratings Scraper 1.3.40

SQLite cache schema cleanup:
- Removed top250_movie table. Movie/TV Top 250 rank is stored on items.imdb_top250_rank; temporary movie chart cache is stored in metadata, not its own table.
- Changed ratings from long/pivot rows to a TMDbHelper-style wide table: one row per item_key with columns imdb, tmdb, rt_critic, rt_critic_image, rt_audience, rt_audience_image, metacritic, trakt, letterboxd, mdblist, provider/source/votes/no_rating columns.
- Dropped payload JSON and long ratings rows. Existing 1.3.38 payload DB and 1.3.39 long ratings DB migrate automatically.

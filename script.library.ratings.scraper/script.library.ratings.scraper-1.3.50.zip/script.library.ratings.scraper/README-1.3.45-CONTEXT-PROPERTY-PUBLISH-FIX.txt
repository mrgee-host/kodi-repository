Library Ratings Scraper 1.3.45

Focus: service/addon property publishing only. No AF3 XML patch.

Changes:
- Player/VideoOSD context now has first priority over Hub/ListItem focus.
- When Player/OSD is active, identity is read from VideoPlayer.* and not from the last focused Hub/VideoNav item.
- If VideoPlayer identity is not ready, LRS clears rating properties instead of leaving previous-item values visible.
- Context priority is now: player -> screensaver -> listitem -> LRS.Active -> TMDbHelper identity fallback.
- TMDbHelper is used only as last-resort identity fallback, never as rating source.
- Stale guard added: cache record must match the active identity before publishing.
- ItemKey is always published; SourceContext is published on cache hit.
- Episode matching includes show title, season, episode, IMDb and TMDb IDs to avoid series ratings on episode OSD.
- Screensaver refresh is faster and now preloads the next slide from existing cache only. No online scrape is triggered by focus/screensaver/OSD.
- Cache miss/identity missing clears rating properties immediately.
- Context debug log added when debug setting is ON:
  context=player|screensaver|listitem|tmdbhelper item_key=... title=... published=yes/no reason=cache_hit/cache_miss/identity_missing/stale_guard
- Publish aliases include lowercase TMDbHelper-style RT properties: rottentomatoes, rottentomatoes_image, rottentomatoes_user, rottentomatoes_userimage.
- RT values publish as percent strings, e.g. 93%.
- Top250 publishes as #212.

Library Ratings Scraper 1.3.41

DB cleanup:
- ratings table now contains only readable rating value columns.
- Removed provider/source/votes/cache_key/logical/score/no_rating columns from the DB schema.
- Values use one decimal place, e.g. 6.6, 71.0.
- NO_RATING is stored directly in the rating value column.
- 0.0 and negative ratings are stored as NO_RATING.
- RT image columns remain: rt_critic_image and rt_audience_image.

Final ratings table:
item_key, imdb, tmdb, rt_critic, rt_critic_image, rt_audience, rt_audience_image, metacritic, trakt, letterboxd, mdblist, updated_at

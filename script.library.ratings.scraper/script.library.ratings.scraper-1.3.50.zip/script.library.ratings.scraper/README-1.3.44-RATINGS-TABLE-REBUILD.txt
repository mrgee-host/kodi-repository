Library Ratings Scraper 1.3.44

Fixes empty ratings table after migration. Some 1.3.40/1.3.41 databases had items populated, ratings empty, and old values left in ratings_long_backup. This version rebuilds ratings from ratings_long_backup automatically, drops the backup table after success, and keeps the simple TMDbHelper-style ratings table.

Expected ratings table columns:
item_key, imdb, tmdb, rottentomatoes, rottentomatoes_image, rottentomatoes_user, rottentomatoes_userimage, metacritic, trakt, letterboxd, mdblist, updated_at

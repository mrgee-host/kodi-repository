Library Ratings Scraper 1.3.50

Base: 1.3.48. 1.3.49 context changes are intentionally not included.

Fixes:
- Strict manual-only service: focus, hub, screensaver and idle service loops never start online scraping.
- Removed the leftover idle auto-lookup execution branch.
- On service start, stale queued/running/finishing background states are cleared if no request file exists.
- Add-on menu can now reset a stuck background state instead of only saying already running.
- Cancel menu offers Force stop running process or Clear stuck background state.
- Added a visible menu toggle: Debug logging ON/OFF.
- Existing settings.xml Debug category remains, but the menu toggle works even if Kodi does not show the setting page.

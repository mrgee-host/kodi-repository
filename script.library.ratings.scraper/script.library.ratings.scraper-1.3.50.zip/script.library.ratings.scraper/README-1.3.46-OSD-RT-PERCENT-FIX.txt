Library Ratings Scraper 1.3.46

Fixes:
- Rotten Tomatoes properties publish numeric percent only (78), not text with percent sign (78%). This prevents AF3 labels from showing 78% %.
- VideoOSD/player context now uses Kodi JSON-RPC Player.GetItem as a fallback/override for VideoPlayer.* labels, so it can identify the actual playing movie/episode even when OSD focus is still on hub/list controls.
- On player cache miss, service reloads the SQLite cache once before clearing, helping OSD recover after manual scrape/rebuild without restarting service.
- No auto online scrape added; service still publishes cache only.

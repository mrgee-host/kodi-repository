Library Ratings Scraper 1.3.38

Changes:
- Ratings cache is now stored in userdata/addon_data/script.library.ratings.scraper/ratings-cache.db (SQLite). The old ratings-cache.json is used only for one-time migration if present.
- IMDb Top 250 movie cache is stored in the same SQLite DB instead of imdb-top250-cache.json.
- Bundled IMDb Top 250 TV chart is now resources/data/imdb_top_tv_shows.db instead of JSON.
- Publishes additional Rotten Tomatoes image property aliases compatible with TMDbHelper-style skins:
  RottenTomatoesImage, RottenTomatoes_Image, RottenTomatoes_CriticImage, RottenTomatoesCriticImage,
  RottenTomatoesAudienceImage, RottenTomatoesAudience_Image, RottenTomatoes_UserImage, RottenTomatoesUserImage.
- Existing LibraryRatings.* and TMDbHelper.* property publishing remains enabled.

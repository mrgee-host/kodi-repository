script.library.ratings.scraper 1.5.29

Clean AF3 lower row ownership patch.
- Replaces the experimental old experimental HomeHub row path with one final 1.5.29 implementation.
- Keeps 1.5.22 EndsAt behavior, 1.5.23 neighbor prefetch and 1.5.24 0.10s AF3 visual fast poll.
- Home/Hub uses LibraryRatings.HomeHub.DisplaySlotN_* keep-last mode.
- MyPrograms/MyVideoNav uses strict-current LibraryRatings.ListItem.RatingSlotN_* mode.
- Game lower row normalizes Steam/Metacritic/Achievement labels to display values: 94%, 89, 32/43.
- EndsAt is skipped when Kodi exposes raw infolabel tokens instead of a resolved time.
- AF3 XML row uses direct KPM shared icon paths: special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/<iconfile>.

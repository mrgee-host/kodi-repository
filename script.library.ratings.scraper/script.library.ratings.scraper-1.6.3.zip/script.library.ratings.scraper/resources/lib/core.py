# -*- coding: utf-8 -*-
from __future__ import annotations

import csv
import json
import os
import random
import re
import sqlite3
import time
from datetime import datetime, timedelta, timezone
from difflib import SequenceMatcher
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
DATA_DIR = os.path.join(ADDON_PATH, "resources", "data")
CACHE_DB_FILE = os.path.join(PROFILE, "ratings-cache.db")
CACHE_FILE = CACHE_DB_FILE
REPORT_FILE = os.path.join(PROFILE, "ratings-report.csv")
SUMMARY_FILE = os.path.join(PROFILE, "last-run-summary.json")
NETWORK_TIMEOUT = 10
CACHE_VERSION = 9
IMDB_TOP250_URL = ""  # v1.4.13: live IMDb bundled database syncing removed; bundled DB is used
IMDB_TOP250_CACHE_FILE = CACHE_DB_FILE
IMDB_TOP250_TV_DB_FILE = os.path.join(DATA_DIR, "imdb_top_tv_shows.db")
IMDB_TOP250_TV_FILE = IMDB_TOP250_TV_DB_FILE
BACKGROUND_REQUEST_FILE = os.path.join(PROFILE, "background-job-request.json")
BACKGROUND_CANCEL_FILE = os.path.join(PROFILE, "background-job-cancel.json")
BACKGROUND_STATE_FILE = os.path.join(PROFILE, "background-job-state.json")
BACKGROUND_FORCE_STOP_FILE = os.path.join(PROFILE, "background-job-force-stop.json")
SAMPLE_CHECK_LOG_FILE = os.path.join(PROFILE, "last-random-check-debug.txt")


def debug_enabled() -> bool:
    try:
        return ADDON.getSetting("debug_logging").lower() == "true"
    except Exception:  # pylint: disable=broad-except
        return False


def set_debug_enabled(enabled: bool) -> None:
    try:
        ADDON.setSetting("debug_logging", "true" if enabled else "false")
    except Exception:  # pylint: disable=broad-except
        pass


def log(message: str, level: int = xbmc.LOGDEBUG) -> None:
    if level != xbmc.LOGDEBUG or debug_enabled():
        xbmc.log("[{0}] {1}".format(ADDON_ID, message), level)


class ProviderLimitReached(Exception):
    """Raised when a provider explicitly reports that the API limit is exhausted."""

    def __init__(self, provider: str, message: str, retry_after: Any = "") -> None:
        self.provider = provider
        self.message = str(message or "API limit reached")
        self.retry_after = str(retry_after or "")
        suffix = " Retry-After: {0}".format(self.retry_after) if self.retry_after else ""
        super().__init__("{0}: {1}{2}".format(provider, self.message, suffix))


def _limit_text(*values: Any) -> str:
    return " ".join(str(value or "") for value in values if value not in (None, "")).lower()


def is_provider_limit_payload(provider: str, payload: Any, headers: Optional[Dict[str, str]] = None) -> bool:
    if not isinstance(payload, dict):
        return False
    headers = headers or {}
    status = safe_int(payload.get("__http_status"))
    if status == 429:
        return True
    text = _limit_text(payload.get("error"), payload.get("Error"), payload.get("message"), payload.get("detail"), payload.get("__error"), payload.get("__body"), headers.get("x-ratelimit-remaining"))
    if provider.lower() == "mdblist":
        return "daily api limit exceeded" in text or "api limit exceeded" in text or "rate limit" in text or "too many requests" in text
    if provider.lower() == "omdb":
        return "request limit reached" in text or "daily request limit" in text or "api limit" in text or "too many requests" in text
    return "limit" in text and ("reached" in text or "exceeded" in text)


def provider_limit_message(provider: str, payload: Any) -> str:
    if not isinstance(payload, dict):
        return "API limit reached"
    for key in ("error", "Error", "message", "detail", "__error", "__body"):
        value = str(payload.get(key) or "").strip()
        if value:
            return value[:240]
    status = payload.get("__http_status")
    return "HTTP {0}".format(status) if status else "API limit reached"


def _public_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """Return provider request params without exposing API keys."""
    public: Dict[str, Any] = {}
    for key, value in (params or {}).items():
        if str(key).lower() in ("apikey", "api_key", "key"):
            public[key] = "***"
        else:
            public[key] = value
    return public


def _compact_rating_sources(ratings: Any) -> List[str]:
    output: List[str] = []
    if not isinstance(ratings, list):
        return output
    for row in ratings:
        if not isinstance(row, dict):
            continue
        source = str(row.get("source") or row.get("Source") or "").strip()
        value = row.get("value") if "value" in row else row.get("Value")
        score = row.get("score") if "score" in row else ""
        if source:
            if value not in (None, ""):
                output.append("{0}={1}".format(source, value))
            elif score not in (None, ""):
                output.append("{0}={1}".format(source, score))
            else:
                output.append(source)
    return output


def safe_int(value: Any) -> Optional[int]:
    try:
        if value in (None, ""):
            return None
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None


def safe_float(value: Any) -> Optional[float]:
    try:
        if value in (None, "", "N/A"):
            return None
        match = re.search(r"-?\d+(?:[.,]\d+)?", str(value))
        return float(match.group(0).replace(",", ".")) if match else None
    except (TypeError, ValueError):
        return None


def bool_setting(name: str, default: bool = False) -> bool:
    try:
        value = ADDON.getSetting(name)
    except Exception:  # pylint: disable=broad-except
        return default
    return default if value == "" else value.lower() == "true"


def int_setting(name: str, default: int) -> int:
    try:
        value = ADDON.getSetting(name)
    except Exception:  # pylint: disable=broad-except
        return default
    return safe_int(value) or default


RATING_LOGICALS_BY_TYPE = {
    "movie": {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist", "top250"},
    "tvshow": {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist", "top250"},
    "episode": {"imdb", "tmdb"},
}

RATING_SOURCE_TO_LOGICAL = {
    # Canonical keys (v1.3.8 cache format)
    "imdb": "imdb",
    "tmdb": "tmdb",
    "rtcritic": "rt_critic",
    "rtaudience": "rt_audience",
    "metacritic": "metacritic",
    "trakt": "trakt",
    "letterboxd": "letterboxd",
    "mdblist": "mdblist",
    # Kodi / provider aliases observed in existing caches
    "internetmoviedatabase": "imdb",
    "themoviedb": "tmdb",
    "tomatoes": "rt_critic",
    "rottentomatoes": "rt_critic",
    "tomatometer": "rt_critic",
    "tomatometerallcritics": "rt_critic",
    "tomatometerallaudience": "rt_audience",
    "audience": "rt_audience",
    "rottentomatoesaudience": "rt_audience",
    "popcorn": "rt_audience",
    "metascore": "metacritic",
    "metacriticuser": "metacritic",
}

# One visible/cache key per rating family. Aliases such as tomatoes,
# rottentomatoes, popcorn, and rottentomatoesaudience are folded into these
# canonical keys so a single item cannot alternate between duplicate values.
RATING_LOGICAL_TO_CACHE_KEY = {
    "imdb": "imdb",
    "tmdb": "tmdb",
    "rt_critic": "rt_critic",
    "rt_audience": "rt_audience",
    "metacritic": "metacritic",
    "trakt": "trakt",
    "letterboxd": "letterboxd",
    "mdblist": "mdblist",
}

# Provider/source preference inside each rating family. The first available
# candidate wins and all aliases are discarded from the final cache row.
RATING_ALIAS_PRIORITY = {
    "imdb": ["imdb", "internetmoviedatabase"],
    "tmdb": ["tmdb", "themoviedb"],
    "rt_critic": ["tomatoes", "tomatometer", "tomatometerallcritics", "rottentomatoes", "rtcritic"],
    "rt_audience": ["popcorn", "audience", "rtaudience", "tomatometerallaudience", "rottentomatoesaudience"],
    "metacritic": ["metacritic", "metascore", "metacriticuser"],
    "trakt": ["trakt"],
    "letterboxd": ["letterboxd"],
    "mdblist": ["mdblist"],
}

# Provider preference per rating family. This prevents MDBList aggregator rows
# from replacing an original/source-specific row for the same displayed rating.
RATING_PROVIDER_PRIORITY = {
    "imdb": ["omdb", "kodi", "mdblist"],
    "tmdb": ["tmdb", "kodi", "mdblist"],
    "rt_critic": ["omdb", "mdblist", "kodi"],
    "rt_audience": ["mdblist", "kodi", "omdb"],
    "metacritic": ["omdb", "mdblist", "kodi"],
    "trakt": ["kodi", "mdblist"],
    "letterboxd": ["mdblist", "kodi"],
    "mdblist": ["mdblist"],
}

MDBLIST_LOGICALS = {"imdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist"}
OMDB_LOGICALS = {"imdb", "rt_critic", "metacritic"}
# MDBList is an aggregator provider. These are the rating families it can be
# used for when the corresponding checkbox is enabled. The separate
# `ratings_*_mdblist` checkbox controls only the visible MDBList score itself;
# it must not disable MDBList as a source for RT audience/popcorn, Trakt, etc.
MDBLIST_PROVIDER_LOGICALS = {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist"}
NO_RATING_PROVIDER = "unavailable"
NO_RATING_SOURCE = "no_rating"
NO_RATING_VALUE = "N/A"



def media_setting_type(media_type: Any) -> str:
    value = str(media_type or "").strip().lower()
    if value in ("tv", "show", "series", "season"):
        return "tvshow"
    if value in ("movies",):
        return "movie"
    if value in ("episodes",):
        return "episode"
    return value


def rating_setting_id(media_type: Any, logical: str) -> str:
    return "ratings_{0}_{1}".format(media_setting_type(media_type), logical)


def rating_enabled(media_type: Any, logical: str, default: bool = True) -> bool:
    media_type = media_setting_type(media_type)
    if logical not in RATING_LOGICALS_BY_TYPE.get(media_type, set()):
        return False
    # Episode intentionally stays simple: only IMDb and TMDb are scraped/published.
    if media_type == "episode" and logical not in ("imdb", "tmdb"):
        return False
    # v1.3.30 simplified settings: one global checkbox per rating family.
    if logical == "top250":
        if media_type == "movie":
            value = ADDON.getSetting("rating_top250_movies")
            return default if value == "" else value.lower() == "true"
        if media_type == "tvshow":
            value = ADDON.getSetting("rating_top250_tvshows")
            return default if value == "" else value.lower() == "true"
        return False
    value = ADDON.getSetting("rating_{0}".format(logical))
    return default if value == "" else value.lower() == "true"


def any_rating_enabled(media_type: Any, logicals: Iterable[str]) -> bool:
    return any(rating_enabled(media_type, logical, True) for logical in logicals)


def clean_rating_source(source: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(source or "").lower())


def logical_for_rating_source(source: Any) -> str:
    return RATING_SOURCE_TO_LOGICAL.get(clean_rating_source(source), "")


def _rating_alias_rank(logical: str, source: Any) -> int:
    clean = clean_rating_source(source)
    priority = RATING_ALIAS_PRIORITY.get(logical, [])
    return priority.index(clean) if clean in priority else len(priority) + 100


def _provider_rank(logical: str, provider: Any) -> int:
    clean = clean_rating_source(provider)
    priority = RATING_PROVIDER_PRIORITY.get(logical, [])
    return priority.index(clean) if clean in priority else len(priority) + 100


def _candidate_score_for_dedupe(logical: str, alias: str, rating: Dict[str, Any]) -> Tuple[int, int, int, float, int]:
    """Lower tuple wins.

    Pick one stable provider/source for each logical rating. Provider priority
    comes before alias priority so e.g. TMDb direct/Kodi TMDb is not replaced by
    MDBList's aggregate TMDb alias. Vote counts are never considered.
    """
    has_number = 0 if (safe_float(rating.get("score")) is not None or safe_float(rating.get("value")) is not None) else 1
    return (_provider_rank(logical, rating.get("provider")), _rating_alias_rank(logical, alias), has_number, 0, 0)


def _canonical_rating_row(logical: str, alias: str, rating: Any) -> Dict[str, Any]:
    row = dict(rating) if isinstance(rating, dict) else normalized_rating(alias, rating, None, None, "")
    row.setdefault("provider", "")
    row["source"] = clean_rating_source(row.get("source") or alias)
    row["logical"] = logical
    row["cache_key"] = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
    return row


def is_no_rating_marker(rating: Any) -> bool:
    return isinstance(rating, dict) and bool(rating.get("no_rating"))


def no_rating_row(logical: str, reason: str = "provider_returned_no_value") -> Dict[str, Any]:
    cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
    return {
        "source": cache_key,
        "logical": logical,
        "cache_key": cache_key,
        "provider": NO_RATING_PROVIDER,
        "value": NO_RATING_VALUE,
        "score": "",
        "votes": "",
        "no_rating": True,
        "no_rating_reason": reason,
        "updated_at": now_iso(),
    }


def mark_unavailable_ratings(target: Dict[str, Any], media_type: Any, logicals: Iterable[str], reason: str = "provider_returned_no_value") -> None:
    if not bool_setting("mark_unavailable_ratings", True):
        return
    media_type = media_setting_type(media_type)
    for logical in logicals:
        if not rating_enabled(media_type, logical, True):
            continue
        cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
        row = target.get(cache_key)
        if isinstance(row, dict) and (safe_float(row.get("score")) is not None or safe_float(row.get("value")) is not None or is_no_rating_marker(row)):
            continue
        target[cache_key] = no_rating_row(logical, reason)


def _attempt_has_temp_failure(attempt: Any) -> bool:
    if not isinstance(attempt, dict):
        return False
    status = safe_int(attempt.get("http_status"))
    error = str(attempt.get("error") or "").lower()
    if status in (401, 403, 408, 409, 425, 429) or (status is not None and status >= 500):
        return True
    temporary_words = ("limit", "quota", "unauthorized", "forbidden", "timeout", "timed out", "temporar", "connection", "ssl", "429", "401", "403")
    return any(word in error for word in temporary_words)


def mdblist_lookup_cacheable(meta: Dict[str, Any]) -> bool:
    attempts = (meta or {}).get("attempts") or []
    if not attempts:
        return False
    return not any(_attempt_has_temp_failure(attempt) for attempt in attempts)


def omdb_lookup_cacheable(meta: Dict[str, Any]) -> bool:
    attempts = (meta or {}).get("attempts") or []
    if not attempts:
        return False
    return not any(_attempt_has_temp_failure(attempt) for attempt in attempts)


def filter_ratings_for_item(media_type: Any, ratings: Dict[str, Any]) -> Dict[str, Any]:
    """Apply checkboxes and fold duplicate aliases into one canonical value.

    v1.3.8 cache rule: one key per displayed rating family only:
    imdb, tmdb, rt_critic, rt_audience, metacritic, trakt, letterboxd, mdblist.
    Old aliases from Kodi/MDBList/OMDb are read for compatibility, then dropped.
    """
    media_type = media_setting_type(media_type)
    if not isinstance(ratings, dict) or media_type not in RATING_LOGICALS_BY_TYPE:
        return {}

    grouped: Dict[str, List[Tuple[str, Dict[str, Any]]]] = {}
    for alias, rating in ratings.items():
        logical = logical_for_rating_source(alias)
        if not logical:
            # Do not keep unknown rating names in the final cache/publish map;
            # the user asked for no duplicate/alias rows.
            continue
        if not rating_enabled(media_type, logical, True):
            continue
        grouped.setdefault(logical, []).append((str(alias), _canonical_rating_row(logical, str(alias), rating)))

    output: Dict[str, Any] = {}
    for logical, rows in grouped.items():
        if not rows:
            continue
        rows.sort(key=lambda pair: _candidate_score_for_dedupe(logical, pair[0], pair[1]))
        cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
        output[cache_key] = rows[0][1]
    return output


def preserve_ratings_for_item(media_type: Any, ratings: Dict[str, Any]) -> Dict[str, Any]:
    """Canonicalize cached ratings without applying current rating checkboxes.

    Settings checkboxes decide what to scrape now. They must not delete rating
    columns that already exist in ratings-cache.db. This is critical for runs
    such as "Scrape missing" with IMDb/TMDb/RT/Metacritic/Trakt disabled while
    only Top250/Status/Awards are enabled.
    """
    media_type = media_setting_type(media_type)
    if not isinstance(ratings, dict) or media_type not in RATING_LOGICALS_BY_TYPE:
        return {}

    grouped: Dict[str, List[Tuple[str, Dict[str, Any]]]] = {}
    for alias, rating in ratings.items():
        logical = logical_for_rating_source(alias)
        if not logical:
            continue
        # Do not use rating_enabled() here. Disabled ratings must be preserved.
        if logical == "top250":
            continue
        if logical not in RATING_LOGICALS_BY_TYPE.get(media_type, set()):
            continue
        grouped.setdefault(logical, []).append((str(alias), _canonical_rating_row(logical, str(alias), rating)))

    output: Dict[str, Any] = {}
    for logical, rows in grouped.items():
        if not rows:
            continue
        rows.sort(key=lambda pair: _candidate_score_for_dedupe(logical, pair[0], pair[1]))
        cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
        output[cache_key] = rows[0][1]
    return output



def now_iso() -> str:
    # User-facing DB/report timestamp in WIB. The old ISO format used UTC with
    # T/Z (Zulu); DB Browser is easier to read with local time.
    return datetime.now(timezone(timedelta(hours=7))).replace(microsecond=0).strftime("%Y-%m-%d %H:%M:%S WIB")


def json_rpc(method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}}
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        if response.get("error"):
            log("JSON-RPC error {0}: {1}".format(method, response["error"]), xbmc.LOGWARNING)
            return {}
        result = response.get("result") or {}
        return result if isinstance(result, dict) else {}
    except Exception as exc:  # pylint: disable=broad-except
        log("JSON-RPC failure {0}: {1}".format(method, exc), xbmc.LOGWARNING)
        return {}


def _table_columns(conn: sqlite3.Connection, table: str) -> List[str]:
    try:
        return [str(row[1]) for row in conn.execute("PRAGMA table_info({0})".format(table)).fetchall()]
    except sqlite3.Error:
        return []


def _db_value(value: Any) -> str:
    return "" if value is None else str(value)


def _db_float(value: Any) -> Any:
    parsed = safe_float(value)
    return parsed if parsed is not None else None


def _db_int(value: Any) -> Any:
    parsed = safe_int(value)
    return int(parsed) if parsed is not None else None


def _restore_db_value(value: Any) -> Any:
    if value in (None, ""):
        return ""
    text = str(value)
    number = safe_float(text)
    if number is None:
        return text
    if re.fullmatch(r"-?\d+", text.strip()):
        return int(number)
    return float(number)




def _old_payload_rows(conn: sqlite3.Connection) -> List[Tuple[str, str]]:
    if "payload" not in _table_columns(conn, "items"):
        return []
    try:
        return [(str(row["item_key"]), str(row["payload"] or "")) for row in conn.execute("SELECT item_key, payload FROM items").fetchall()]
    except sqlite3.Error:
        return []




def _db_get_meta(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    row = conn.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone()
    return str(row["value"]) if row and row["value"] is not None else default


def _db_set_meta(conn: sqlite3.Connection, key: str, value: Any) -> None:
    conn.execute("INSERT OR REPLACE INTO metadata(key, value) VALUES(?, ?)", (key, str(value if value is not None else "")))


def _cache_entry_indexes(item_key: str, entry: Dict[str, Any]) -> Tuple[str, int, str, str, str, str, str, int]:
    ids = entry.get("ids") or {}
    dbid = safe_int(entry.get("dbid"))
    timestamp = safe_int(entry.get("timestamp")) or 0
    return (
        str(entry.get("type") or ""),
        int(dbid or 0),
        str(entry.get("title") or ""),
        str(entry.get("showtitle") or ""),
        str(ids.get("imdb") or entry.get("imdb") or ""),
        str(ids.get("tmdb") or entry.get("tmdb") or ""),
        str(entry.get("updated_at") or ""),
        int(timestamp),
    )


def _normal_item_values(entry: Dict[str, Any]) -> Tuple[Any, ...]:
    ids = entry.get("ids") or {}
    series = entry.get("series") or {}
    awards = entry.get("awards") or {}
    return (
        str(entry.get("type") or ""),
        _db_int(entry.get("dbid")) or 0,
        str(entry.get("title") or ""),
        str(entry.get("showtitle") or ""),
        _db_int(entry.get("season")),
        _db_int(entry.get("episode")),
        str(entry.get("year") or ""),
        str(ids.get("imdb") or entry.get("imdb") or ""),
        str(ids.get("tmdb") or entry.get("tmdb") or ""),
        str(ids.get("tvdb") or entry.get("tvdb") or ""),
        str(ids.get("show_tmdb") or entry.get("show_tmdb") or ""),
        _db_int(entry.get("imdb_top250_rank") or entry.get("imdb_top250_tv_rank") or entry.get("imdb_top250_movie_rank")) or 0,
        str(series.get("status") or ""),
        str(series.get("status_date") or ""),
        _db_int(awards.get("oscar_wins")),
        _db_int(awards.get("emmy_wins")),
        str(entry.get("updated_at") or ""),
        _db_int(entry.get("timestamp")) or 0,
    )


def _db_upsert_entry(conn: sqlite3.Connection, item_key: str, entry: Dict[str, Any]) -> None:
    if not isinstance(entry, dict):
        return
    conn.execute(
        """
        INSERT OR REPLACE INTO items(
            item_key, media_type, dbid, title, showtitle, season, episode, year,
            imdb, tmdb, tvdb, show_tmdb, imdb_top250_rank,
            series_status, series_status_date, oscar_wins, emmy_wins,
            updated_at, timestamp
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (str(item_key),) + _normal_item_values(entry),
    )
    conn.execute("DELETE FROM ratings WHERE item_key=?", (str(item_key),))
    for logical, rating in (entry.get("ratings") or {}).items():
        if not isinstance(rating, dict):
            continue
        conn.execute(
            """
            INSERT OR REPLACE INTO ratings(
                item_key, logical, cache_key, provider, source, value, score,
                votes, no_rating, no_rating_reason, updated_at
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?)
            """,
            (
                str(item_key),
                str(rating.get("logical") or logical),
                str(rating.get("cache_key") or logical),
                str(rating.get("provider") or ""),
                str(rating.get("source") or logical),
                _db_value(rating.get("value")),
                _db_float(rating.get("score")),
                _db_int(rating.get("votes")),
                1 if rating.get("no_rating") else 0,
                str(rating.get("no_rating_reason") or ""),
                str(rating.get("updated_at") or ""),
            ),
        )


def _db_row_to_entry(row: sqlite3.Row, ratings: Dict[str, Dict[str, Any]]) -> Dict[str, Any]:
    ids: Dict[str, str] = {}
    for key in ("imdb", "tmdb", "tvdb", "show_tmdb"):
        value = row[key] if key in row.keys() else ""
        if value not in (None, ""):
            ids[key] = str(value)
    entry: Dict[str, Any] = {
        "type": str(row["media_type"] or ""),
        "dbid": int(row["dbid"] or 0),
        "title": str(row["title"] or ""),
        "updated_at": str(row["updated_at"] or ""),
        "timestamp": int(row["timestamp"] or 0),
        "ids": ids,
        "ratings": ratings,
    }
    if row["showtitle"]:
        entry["showtitle"] = str(row["showtitle"])
    if row["season"] is not None:
        entry["season"] = int(row["season"])
    if row["episode"] is not None:
        entry["episode"] = int(row["episode"])
    if row["year"] not in (None, ""):
        entry["year"] = str(row["year"])
    rank = safe_int(row["imdb_top250_rank"]) or 0
    entry["imdb_top250_rank"] = rank
    series: Dict[str, Any] = {}
    if row["series_status"]:
        series["status"] = str(row["series_status"])
    if row["series_status_date"]:
        series["status_date"] = str(row["series_status_date"])
    if series:
        entry["series"] = series
    awards: Dict[str, Any] = {}
    if row["oscar_wins"] is not None:
        awards["oscar_wins"] = int(row["oscar_wins"])
    if row["emmy_wins"] is not None:
        awards["emmy_wins"] = int(row["emmy_wins"])
    if awards:
        entry["awards"] = awards
    # Keep these keys lightweight for older code paths that call .get(). They are
    # intentionally not stored as noisy JSON blobs anymore.
    entry["errors"] = []
    entry["provider_meta"] = {}
    return entry




def _atomic_write_json(path: str, payload: Dict[str, Any]) -> None:
    # Kept for small job-state/summary files only. Ratings cache is SQLite.
    os.makedirs(os.path.dirname(path) or PROFILE, exist_ok=True)
    last_error = None
    for attempt in range(12):
        temp = "{0}.tmp.{1}.{2}".format(path, os.getpid(), int(time.time() * 1000))
        try:
            with open(temp, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
                handle.flush()
                try:
                    os.fsync(handle.fileno())
                except OSError:
                    pass
            os.replace(temp, path)
            return
        except OSError as exc:
            last_error = exc
            try:
                if os.path.exists(temp):
                    os.remove(temp)
            except OSError:
                pass
            time.sleep(0.20 + (attempt * 0.05))
    raise last_error or OSError("Failed to write {0}".format(path))



def save_summary(summary: Dict[str, Any]) -> None:
    os.makedirs(PROFILE, exist_ok=True)
    with open(SUMMARY_FILE, "w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2, sort_keys=True)


def _atomic_json(path: str, payload: Dict[str, Any]) -> None:
    _atomic_write_json(path, payload)


def _load_json(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        return payload if isinstance(payload, dict) else {}
    except (OSError, ValueError):
        return {}


def clear_background_control_flags() -> None:
    """Remove stale cancel/force-stop flags before starting a new job.

    If the user used Force Stop previously, Kodi can leave the cancel/force
    marker files in addon_data until the service consumes them. Starting a new
    scrape while those files still exist makes the new job cancel immediately.
    """
    for path in (BACKGROUND_CANCEL_FILE, BACKGROUND_FORCE_STOP_FILE):
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass


def background_state_is_active(state: Dict[str, Any]) -> bool:
    return (state or {}).get("status") in ("queued", "running", "finishing", "force_stop_requested")


def background_request_exists() -> bool:
    return os.path.exists(BACKGROUND_REQUEST_FILE)


def reset_background_job_state(reason: str = "Manual reset") -> None:
    for path in (BACKGROUND_REQUEST_FILE, BACKGROUND_CANCEL_FILE, BACKGROUND_FORCE_STOP_FILE):
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass
    _atomic_json(BACKGROUND_STATE_FILE, {
        "status": "canceled",
        "action": "reset",
        "force": False,
        "requested_at": now_iso(),
        "finished_at": now_iso(),
        "percent": 0,
        "processed": 0,
        "total": 0,
        "current": reason,
    })


def reset_stale_background_on_service_start() -> None:
    state = background_job_state()
    if background_state_is_active(state) and not background_request_exists():
        reset_background_job_state("Stale background state cleared on service start")


def queue_background_job(action: str, force: bool = False) -> None:
    clear_background_control_flags()
    payload = {"action": action, "force": bool(force), "requested_at": now_iso(), "timestamp": int(time.time())}
    _atomic_json(BACKGROUND_REQUEST_FILE, payload)
    _atomic_json(BACKGROUND_STATE_FILE, {"status": "queued", "action": action, "force": bool(force), "requested_at": payload["requested_at"], "timestamp": payload["timestamp"], "percent": 0, "processed": 0, "total": 0})


def request_background_cancel() -> None:
    _atomic_json(BACKGROUND_CANCEL_FILE, {"cancel": True, "requested_at": now_iso(), "timestamp": int(time.time())})


def request_background_force_stop() -> None:
    """Request an immediate hard stop from the service loop.

    Normal cancel lets the service finish the current item and save a clean
    partial cache/report. Force stop is for stuck or unwanted long runs: it
    clears pending request files and tells the service to drop the running job
    as soon as the current HTTP/JSON-RPC call returns.
    """
    try:
        if os.path.exists(BACKGROUND_REQUEST_FILE):
            os.remove(BACKGROUND_REQUEST_FILE)
    except OSError:
        pass
    payload = {"force_stop": True, "requested_at": now_iso(), "timestamp": int(time.time())}
    _atomic_json(BACKGROUND_FORCE_STOP_FILE, payload)
    _atomic_json(BACKGROUND_CANCEL_FILE, {"cancel": True, "force_stop": True, "requested_at": payload["requested_at"], "timestamp": payload["timestamp"]})
    _atomic_json(BACKGROUND_STATE_FILE, {"status": "force_stop_requested", "action": "force_stop", "requested_at": payload["requested_at"], "percent": 0, "processed": 0, "total": 0, "current": "Force stop requested"})


def background_job_state() -> Dict[str, Any]:
    return _load_json(BACKGROUND_STATE_FILE)


def consume_background_request() -> Dict[str, Any]:
    payload = _load_json(BACKGROUND_REQUEST_FILE)
    if payload:
        try:
            os.remove(BACKGROUND_REQUEST_FILE)
        except OSError:
            pass
    return payload


def consume_background_cancel() -> bool:
    payload = _load_json(BACKGROUND_CANCEL_FILE)
    if payload:
        try:
            os.remove(BACKGROUND_CANCEL_FILE)
        except OSError:
            pass
    return bool(payload.get("cancel"))


def consume_background_force_stop() -> bool:
    payload = _load_json(BACKGROUND_FORCE_STOP_FILE)
    if payload:
        try:
            os.remove(BACKGROUND_FORCE_STOP_FILE)
        except OSError:
            pass
    return bool(payload.get("force_stop"))


def save_background_state(state: Dict[str, Any]) -> None:
    _atomic_json(BACKGROUND_STATE_FILE, state)


def item_key(item: Dict[str, Any]) -> str:
    return "{0}|{1}".format(item.get("type", "unknown"), item.get("dbid", ""))


def fresh(entry: Dict[str, Any]) -> bool:
    stamp = safe_float(entry.get("timestamp")) or 0
    return stamp > 0 and (time.time() - stamp) < max(1, int_setting("cache_days", 14)) * 86400


def get_setting_from(addon: xbmcaddon.Addon, candidates: Iterable[str]) -> str:
    for setting_id in candidates:
        try:
            value = addon.getSetting(setting_id)
        except Exception:  # pylint: disable=broad-except
            value = ""
        if value:
            return value.strip()
    return ""


def api_keys() -> Dict[str, Any]:
    def _local_key(setting_id: str) -> str:
        try:
            return ADDON.getSetting(setting_id).strip()
        except Exception:  # pylint: disable=broad-except
            return ""

    def _chain(*values: str) -> List[str]:
        out: List[str] = []
        for value in values:
            value = str(value or "").strip()
            if value and value not in out:
                out.append(value)
        return out

    mdblist_keys = _chain(_local_key("mdblist_apikey"), _local_key("mdblist_apikey_2"))
    omdb_keys = _chain(_local_key("omdb_apikey"), _local_key("omdb_apikey_2"))
    tmdb_key = _local_key("tmdb_apikey")

    if bool_setting("try_tmdbhelper_keys", True):
        try:
            helper = xbmcaddon.Addon("plugin.video.themoviedb.helper")
            if not mdblist_keys:
                mdblist_keys = _chain(get_setting_from(helper, ("mdblist_apikey", "mdblist_api_key", "mdblist_key")))
            if not tmdb_key:
                tmdb_key = get_setting_from(helper, ("tmdb_apikey", "tmdb_api_key", "tmdb_key", "tmdb_api"))
            if not omdb_keys:
                omdb_keys = _chain(get_setting_from(helper, ("omdb_apikey", "omdb_api_key", "omdb_key")))
        except Exception:  # pylint: disable=broad-except
            pass

    return {
        "mdblist": {"keys": mdblist_keys, "limited": {}},
        "mdblist_count": len(mdblist_keys),
        "tmdb": tmdb_key,
        "omdb": {"keys": omdb_keys, "limited": {}},
        "omdb_count": len(omdb_keys),
    }


def http_json(url: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    """Fetch JSON and preserve provider/network errors for debug output.

    Older builds returned an empty dict on HTTP/network/JSON failures. That made
    OMDb debug output look like `Response=True` with no Title/Ratings, and
    MDBList look like `ratings_count=0`, which is misleading. Return a small
    error payload instead so callers can show the real failure.
    """
    request = Request(url, headers={"User-Agent": "Kodi-Library-Ratings-Scraper/1.3.64", "Accept": "application/json"})
    try:
        with urlopen(request, timeout=NETWORK_TIMEOUT) as response:  # nosec B310 fixed HTTPS hosts only
            headers = {k.lower(): v for k, v in response.headers.items()}
            status = getattr(response, "status", None) or getattr(response, "code", None) or 200
            raw = response.read().decode("utf-8", "replace")
        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            if status and "__http_status" not in parsed:
                parsed["__http_status"] = status
            if raw and "__raw_len" not in parsed:
                parsed["__raw_len"] = len(raw)
            return parsed, headers
        return {"Response": "False", "__error": "JSON root is {0}".format(type(parsed).__name__), "__http_status": status, "__raw_len": len(raw)}, headers
    except HTTPError as exc:
        retry = exc.headers.get("Retry-After", "") if exc.headers else ""
        body = ""
        try:
            body = exc.read().decode("utf-8", "replace")[:500]
        except Exception:  # pylint: disable=broad-except
            body = ""
        log("HTTP {0} for {1}; retry-after={2}".format(exc.code, url.split("?")[0], retry), xbmc.LOGWARNING)
        return {"Response": "False", "__error": "HTTP {0}".format(exc.code), "__http_status": exc.code, "__retry_after": retry, "__body": body}, {k.lower(): v for k, v in exc.headers.items()} if exc.headers else {}
    except (URLError, OSError, ValueError, TimeoutError) as exc:
        log("Provider request failed: {0}".format(exc), xbmc.LOGWARNING)
        return {"Response": "False", "__error": str(exc)}, {}


def http_text(url: str) -> str:
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Kodi-Library-Ratings-Scraper/1.3.64",
        "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    })
    try:
        with urlopen(request, timeout=NETWORK_TIMEOUT) as response:  # nosec B310 fixed HTTPS host only
            return response.read().decode("utf-8", "replace")
    except HTTPError as exc:
        log("HTTP {0} for {1}".format(exc.code, url.split("?")[0]), xbmc.LOGWARNING)
    except (URLError, OSError, TimeoutError) as exc:
        log("Page request failed for {0}: {1}".format(url.split("?")[0], exc), xbmc.LOGWARNING)
    return ""


def _walk_top250_json(node: Any, ranks: Dict[str, int]) -> None:
    if isinstance(node, dict):
        imdb_id = ""
        for key in ("id", "titleId", "const", "tconst"):
            value = node.get(key)
            if isinstance(value, str) and re.fullmatch(r"tt\d+", value):
                imdb_id = value.lower()
                break
        rank = None
        for key in ("rank", "currentRank", "position"):
            value = safe_int(node.get(key))
            if value is not None and 1 <= value <= 250:
                rank = value
                break
        if imdb_id and rank is not None:
            ranks.setdefault(imdb_id, rank)
        for value in node.values():
            _walk_top250_json(value, ranks)
    elif isinstance(node, list):
        for value in node:
            _walk_top250_json(value, ranks)


def _parse_imdb_top250(html: str) -> Dict[str, int]:
    ranks: Dict[str, int] = {}
    for raw in re.findall(r'<script[^>]*type=["\\\']application/json["\\\'][^>]*>(.*?)</script>', html, flags=re.I | re.S):
        try:
            _walk_top250_json(json.loads(raw), ranks)
        except ValueError:
            continue
    if len(ranks) >= 200:
        return dict(sorted(ranks.items(), key=lambda pair: pair[1])[:250])
    ordered: List[str] = []
    seen = set()
    for imdb_id in re.findall(r'/title/(tt\d+)/', html, flags=re.I):
        imdb_id = imdb_id.lower()
        if imdb_id not in seen:
            seen.add(imdb_id)
            ordered.append(imdb_id)
    if len(ordered) >= 200:
        return {imdb_id: index for index, imdb_id in enumerate(ordered[:250], start=1)}
    return {}


def imdb_top250_ranks(force_refresh: bool = False) -> Dict[str, int]:
    cached = _load_top250_cache()
    cached_ranks = cached.get("ranks") or {}
    max_age_hours = 24
    stamp = safe_float(cached.get("timestamp")) or 0
    if not force_refresh and cached_ranks and time.time() - stamp < max_age_hours * 3600:
        return {str(key).lower(): int(value) for key, value in cached_ranks.items() if safe_int(value) is not None}
    parsed = _parse_imdb_top250(http_text(IMDB_TOP250_URL))
    if parsed:
        _save_top250_cache(parsed)
        return parsed
    return {str(key).lower(): int(value) for key, value in cached_ranks.items() if safe_int(value) is not None}


def imdb_top250_tv_ranks() -> Dict[str, int]:
    ranks: Dict[str, int] = {}
    try:
        conn = sqlite3.connect(IMDB_TOP250_TV_DB_FILE)
        try:
            for imdb, rank in conn.execute("SELECT imdb, rank FROM top250_tv ORDER BY rank"):
                imdb_id = str(imdb or "").strip().lower()
                if re.fullmatch(r"tt\d+", imdb_id):
                    ranks.setdefault(imdb_id, int(rank))
            return ranks
        finally:
            conn.close()
    except sqlite3.Error as exc:
        log("IMDb Top250 TV DB unavailable: {0} ({1})".format(IMDB_TOP250_TV_DB_FILE, exc), xbmc.LOGWARNING)
        return {}



def _entry_imdb_id(entry: Dict[str, Any]) -> str:
    ids = entry.get("ids") or {}
    imdb_id = str(ids.get("imdb") or entry.get("imdb") or "").strip().lower()
    return imdb_id if imdb_id.startswith("tt") else ""


def _set_entry_top250(entry: Dict[str, Any], media_type: str, rank: int) -> bool:
    rank = safe_int(rank) or 0
    if media_type == "movie":
        old = safe_int(entry.get("imdb_top250_movie_rank") or entry.get("imdb_top250_rank")) or 0
        entry["imdb_top250_movie_rank"] = rank
        entry["imdb_top250_rank"] = rank
        if "imdb_top250_tv_rank" in entry:
            entry["imdb_top250_tv_rank"] = 0
    elif media_type == "tvshow":
        old = safe_int(entry.get("imdb_top250_tv_rank") or entry.get("imdb_top250_rank")) or 0
        entry["imdb_top250_tv_rank"] = rank
        entry["imdb_top250_rank"] = rank
        if "imdb_top250_movie_rank" in entry:
            entry["imdb_top250_movie_rank"] = 0
    else:
        old = safe_int(entry.get("imdb_top250_rank")) or 0
        entry["imdb_top250_rank"] = rank
    entry["updated_at"] = now_iso()
    entry["timestamp"] = int(time.time())
    return rank != old


def sync_imdb_top250_to_library(force_chart_refresh: bool = False, progress: Any = None) -> Dict[str, int]:
    movie_enabled = rating_enabled("movie", "top250", True) and bool_setting("include_movies", True)
    tv_enabled = rating_enabled("tvshow", "top250", True) and bool_setting("include_tvshows", True)
    ratings_cache = load_cache()
    ratings_cache.setdefault("items", {})

    movie_ranks = imdb_top250_ranks(force_chart_refresh) if movie_enabled else {}
    tv_ranks = imdb_top250_tv_ranks() if tv_enabled else {}

    stats = {
        "movies": 0, "movie_matched": 0, "movie_updated": 0, "movie_missing_imdb": 0, "movie_chart_items": len(movie_ranks),
        "tvshows": 0, "tv_matched": 0, "tv_updated": 0, "tv_missing_imdb": 0, "tv_chart_items": len(tv_ranks),
        "updated": 0, "matched": 0,
    }

    if movie_enabled:
        movies = json_rpc("VideoLibrary.GetMovies", {"properties": ["title", "year", "imdbnumber", "uniqueid", "top250"]}).get("movies", []) or []
        stats["movies"] = len(movies)
        for movie in movies:
            if isinstance(movie, dict):
                _ensure_cache_entry(ratings_cache, "movie", movie.get("movieid"), movie)

        if movie_ranks:
            movie_entries = [entry for entry in (ratings_cache.get("items") or {}).values() if isinstance(entry, dict) and entry.get("type") == "movie"]
            for index, entry in enumerate(movie_entries, start=1):
                if progress is not None:
                    progress.update(int(index * 50 / max(1, len(movie_entries))), "Movies Top 250 [{0}/{1}] {2}".format(index, len(movie_entries), entry.get("title") or "Untitled"))
                    if progress.iscanceled():
                        break
                imdb_id = _entry_imdb_id(entry)
                if not imdb_id:
                    stats["movie_missing_imdb"] += 1
                    continue
                rank = safe_int(movie_ranks.get(imdb_id)) or 0
                if rank:
                    stats["movie_matched"] += 1
                if _set_entry_top250(entry, "movie", rank):
                    stats["movie_updated"] += 1

            # Kodi's built-in movie Top250 field is updated only when the online movie chart is available.
            for movie in movies:
                if not isinstance(movie, dict):
                    continue
                imdb_id = _movie_imdb_id(movie, ratings_cache)
                rank = safe_int(movie_ranks.get(imdb_id)) or 0
                old_rank = safe_int(movie.get("top250")) or 0
                if rank != old_rank and safe_int(movie.get("movieid")) is not None:
                    json_rpc("VideoLibrary.SetMovieDetails", {"movieid": int(movie["movieid"]), "top250": rank})

    if tv_enabled:
        shows = json_rpc("VideoLibrary.GetTVShows", {"properties": ["title", "year", "imdbnumber", "uniqueid"]}).get("tvshows", []) or []
        stats["tvshows"] = len(shows)
        for show in shows:
            if isinstance(show, dict):
                _ensure_cache_entry(ratings_cache, "tvshow", show.get("tvshowid"), show)

        if tv_ranks:
            tv_entries = [entry for entry in (ratings_cache.get("items") or {}).values() if isinstance(entry, dict) and entry.get("type") == "tvshow"]
            for index, entry in enumerate(tv_entries, start=1):
                if progress is not None:
                    progress.update(50 + int(index * 50 / max(1, len(tv_entries))), "TV Top 250 [{0}/{1}] {2}".format(index, len(tv_entries), entry.get("title") or "Untitled"))
                    if progress.iscanceled():
                        break
                imdb_id = _entry_imdb_id(entry)
                if not imdb_id:
                    stats["tv_missing_imdb"] += 1
                    continue
                rank = safe_int(tv_ranks.get(imdb_id)) or 0
                if rank:
                    stats["tv_matched"] += 1
                if _set_entry_top250(entry, "tvshow", rank):
                    stats["tv_updated"] += 1

    stats["updated"] = int(stats.get("movie_updated") or 0) + int(stats.get("tv_updated") or 0)
    stats["matched"] = int(stats.get("movie_matched") or 0) + int(stats.get("tv_matched") or 0)
    stats["total"] = int(stats.get("movies") or 0) + int(stats.get("tvshows") or 0)
    stats["processed"] = int(stats.get("total") or 0)
    save_cache(ratings_cache)
    log("IMDb Top250 sync: movies={0} tvshows={1} movie_chart={2} tv_chart={3} matched={4} updated={5} missing_imdb={6}".format(
        stats.get("movies"), stats.get("tvshows"), stats.get("movie_chart_items"), stats.get("tv_chart_items"), stats.get("matched"), stats.get("updated"), int(stats.get("movie_missing_imdb") or 0) + int(stats.get("tv_missing_imdb") or 0)
    ), xbmc.LOGINFO)
    return stats

def normalized_rating(source: str, value: Any = None, score: Any = None, votes: Any = None, provider: str = "") -> Dict[str, Any]:
    clean = re.sub(r"[^a-z0-9]", "", source.lower())
    number = safe_float(value)
    normalized = safe_float(score)

    # MDBList reports TMDb/Trakt in a 0-100 style value (for example 68),
    # while AF3/TMDbHelper rating fields expect decimal 0-10 (6.8). Store the
    # user-visible value as 0-10 but keep the normalized score as 0-100.
    if str(provider or "").lower() == "mdblist" and clean in ("tmdb", "trakt") and number is not None and number > 10:
        if normalized is None:
            normalized = number
        number = number / 10.0

    if normalized is None and number is not None:
        if clean in ("imdb", "tmdb", "trakt", "letterboxd", "metacriticuser") and number <= 10:
            normalized = number * 10
        else:
            normalized = number
    return {"source": clean, "value": number, "score": normalized, "votes": safe_int(votes), "provider": provider}


def merge_rating(target: Dict[str, Any], rating: Dict[str, Any], overwrite: bool = False) -> None:
    source = rating.get("source", "")
    if source and (overwrite or source not in target):
        target[source] = rating


def merge_provider_ratings(
    target: Dict[str, Any],
    found: Dict[str, Any],
    media_type: Any,
    allowed_logicals: Optional[Iterable[str]] = None,
    overwrite: bool = False,
) -> None:
    """Merge provider rows into canonical cache keys.

    v1.3.23 smart mode: missing-only decides whether an API needs to be hit.
    Once a provider has already been hit, all enabled fields returned by that
    same response may be updated because it costs no extra request.
    """
    media_type = media_setting_type(media_type)
    allowed = set(allowed_logicals or [])
    for rating in (found or {}).values():
        if not isinstance(rating, dict):
            continue
        logical = logical_for_rating_source(rating.get("source"))
        if not logical:
            continue
        if allowed and logical not in allowed:
            continue
        if not rating_enabled(media_type, logical, True):
            continue
        cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
        if cache_key and (overwrite or cache_key not in target):
            target[cache_key] = _canonical_rating_row(logical, rating.get("source") or cache_key, rating)


def local_ratings(row: Dict[str, Any]) -> Dict[str, Any]:
    output: Dict[str, Any] = {}
    ratings = row.get("ratings") or {}
    if not isinstance(ratings, dict):
        return output
    for source, payload in ratings.items():
        if isinstance(payload, dict):
            rating = normalized_rating(str(source), payload.get("rating"), None, None, "kodi")
        else:
            rating = normalized_rating(str(source), payload, None, None, "kodi")
        merge_rating(output, rating)
    return output


def extract_ids(row: Dict[str, Any]) -> Dict[str, str]:
    ids: Dict[str, str] = {}
    unique = row.get("uniqueid") or {}
    if isinstance(unique, dict):
        for key, value in unique.items():
            if value not in (None, ""):
                ids[str(key).lower()] = str(value).strip()
    number = str(row.get("imdbnumber") or "").strip()
    if number:
        if number.lower().startswith("tt"):
            ids.setdefault("imdb", number)
        elif number.isdigit():
            # Common TMDb scraper output observed in Kodi libraries.
            ids.setdefault("tmdb", number)
    return ids



def _values_lower(*values: Any) -> str:
    parts: List[str] = []
    for value in values:
        if value in (None, ""):
            continue
        if isinstance(value, (list, tuple, set)):
            for item in value:
                if item not in (None, ""):
                    parts.append(str(item).lower())
        elif isinstance(value, dict):
            for item in value.values():
                if item not in (None, ""):
                    parts.append(str(item).lower())
        else:
            parts.append(str(value).lower())
    return " ".join(parts)


def is_animation_short_movie(row: Dict[str, Any]) -> bool:
    """Best-effort detection for the user's Animation Short Films bucket.

    Kodi does not expose a dedicated "short film" media type, so we detect it
    from genre/tag/set text first and only use runtime as a conservative backup.
    This keeps normal animated feature films from being skipped.
    """
    text = _values_lower(
        row.get("title"), row.get("genre"), row.get("tag"), row.get("set"), row.get("sorttitle"), row.get("file")
    )
    compact = re.sub(r"[^a-z0-9]+", " ", text).strip()
    if not compact:
        return False

    explicit_markers = (
        "animation short",
        "animated short",
        "animation shorts",
        "animated shorts",
        "animation short films",
        "animated short films",
        "short animation",
        "short animations",
    )
    if any(marker in compact for marker in explicit_markers):
        return True

    # Kodi tags/genres may be split into separate values such as
    # ["Animation", "Short"] or a set named "Short Films".
    has_animation = "animation" in compact or "animated" in compact
    has_short = re.search(r"\bshort\b|\bshorts\b", compact) is not None
    has_film_bucket = "short film" in compact or "short films" in compact
    if has_animation and (has_short or has_film_bucket):
        return True

    # Conservative fallback: only skip very short animated entries when the
    # movie has an Animation genre/tag. Runtime is usually seconds in Kodi.
    runtime = safe_int(row.get("runtime")) or 0
    if has_animation and runtime and runtime <= 2700 and has_short:
        return True
    return False

def is_indonesian_collection_movie(row: Dict[str, Any]) -> bool:
    """Detect the user's Indonesian Movies Collection bucket."""
    text = _values_lower(row.get("title"), row.get("genre"), row.get("tag"), row.get("set"), row.get("sorttitle"), row.get("file"))
    compact = re.sub(r"[^a-z0-9]+", " ", text).strip()
    if not compact:
        return False
    markers = (
        "indonesian movies collection",
        "indonesian movie collection",
        "indonesian movies",
        "indonesian movie",
        "indonesia movies collection",
        "indonesia movie collection",
        "film indonesia",
        "indonesian collection",
    )
    return any(marker in compact for marker in markers)


def parent_show_map() -> Dict[int, Dict[str, Any]]:
    props = ["title", "year", "imdbnumber", "uniqueid"]
    shows = json_rpc("VideoLibrary.GetTVShows", {"properties": props}).get("tvshows", []) or []
    output: Dict[int, Dict[str, Any]] = {}
    for row in shows:
        if isinstance(row, dict) and safe_int(row.get("tvshowid")) is not None:
            output[int(row["tvshowid"])] = row
    return output


def library_items() -> List[Dict[str, Any]]:
    output: List[Dict[str, Any]] = []
    common = ["title", "year", "imdbnumber", "uniqueid"]
    if bool_setting("include_movies", True):
        movie_props = common + ["top250", "genre", "tag", "set", "runtime", "sorttitle", "file"]
        movies = json_rpc("VideoLibrary.GetMovies", {"properties": movie_props}).get("movies", []) or []
        include_animation_shorts = bool_setting("include_animation_shorts", True)
        include_indonesian_collection = bool_setting("include_indonesian_collection", True)
        for row in movies:
            if not isinstance(row, dict):
                continue
            if not include_animation_shorts and is_animation_short_movie(row):
                continue
            if not include_indonesian_collection and is_indonesian_collection_movie(row):
                continue
            item = dict(row); item["type"] = "movie"; item["dbid"] = row.get("movieid")
            output.append(item)
    shows_map: Dict[int, Dict[str, Any]] = {}
    if bool_setting("include_tvshows", True) or bool_setting("include_episodes", True):
        shows_map = parent_show_map()
    if bool_setting("include_tvshows", True):
        for row in shows_map.values():
            item = dict(row); item["type"] = "tvshow"; item["dbid"] = row.get("tvshowid")
            output.append(item)
    if bool_setting("include_episodes", True):
        episode_props = ["title", "showtitle", "season", "episode", "tvshowid", "firstaired", "uniqueid", "file"]
        episodes = json_rpc("VideoLibrary.GetEpisodes", {"properties": episode_props}).get("episodes", []) or []
        for row in episodes:
            if not isinstance(row, dict):
                continue
            item = dict(row); item["type"] = "episode"; item["dbid"] = row.get("episodeid")
            parent = shows_map.get(safe_int(row.get("tvshowid")) or -1, {})
            item["showtitle"] = row.get("showtitle") or parent.get("title") or ""
            item["show_year"] = parent.get("year") or ""
            item["show_ids"] = extract_ids(parent)
            output.append(item)
    return output


def mdblist_lookup(ids: Dict[str, str], media_type: str, key: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    if not key or media_type not in ("movie", "show"):
        return {}, {}

    # v1.3.14: do not rely on one MDBList identity only. Movies often work
    # via IMDb, but TV shows can return a different/partial rating set depending
    # on whether the lookup uses TMDb or IMDb. Try all available stable IDs and
    # merge the first value for each source so series can get popcorn/tomatoes
    # when the primary IMDb show lookup only returns IMDb or nothing.
    candidates: List[Tuple[str, str]] = []

    def add_candidate(provider: str, media_id: Any) -> None:
        media_id = str(media_id or "").strip()
        if not media_id:
            return
        if provider == "imdb" and not media_id.lower().startswith("tt"):
            return
        pair = (provider, media_id)
        if pair not in candidates:
            candidates.append(pair)

    if media_type == "show":
        # TMDb IDs are type-scoped and usually more reliable for show-specific
        # ratings. Keep IMDb as fallback because many libraries only have tt ids.
        add_candidate("tmdb", ids.get("tmdb") or ids.get("show_tmdb"))
        add_candidate("imdb", ids.get("imdb"))
        add_candidate("trakt", ids.get("trakt"))
        add_candidate("mdblist", ids.get("mdblist"))
    else:
        add_candidate("imdb", ids.get("imdb"))
        add_candidate("tmdb", ids.get("tmdb"))
        add_candidate("trakt", ids.get("trakt"))
        add_candidate("mdblist", ids.get("mdblist"))

    output: Dict[str, Any] = {}
    meta: Dict[str, Any] = {"ids": {}, "rate_limit_remaining": "", "attempts": []}
    for provider, media_id in candidates:
        url = "https://api.mdblist.com/{0}/{1}/{2}?{3}".format(provider, media_type, quote(media_id, safe=""), urlencode({"apikey": key, "format": "json"}))
        try:
            payload, headers = http_json(url)
        except Exception as exc:  # pylint: disable=broad-except
            meta["attempts"].append({"provider": provider, "id": media_id, "error": str(exc)})
            continue
        payload_error = ""
        if isinstance(payload, dict):
            payload_error = str(payload.get("error") or payload.get("message") or payload.get("detail") or payload.get("__error") or payload.get("__body") or "")
        rows = payload.get("ratings") if isinstance(payload, dict) else []
        if rows is None:
            rows = []
        count = len(rows) if isinstance(rows, list) else 0
        meta["attempts"].append({
            "provider": provider,
            "media_type": media_type,
            "id": media_id,
            "ratings": count,
            "sources": _compact_rating_sources(rows),
            "error": payload_error,
            "http_status": payload.get("__http_status") if isinstance(payload, dict) else "",
            "raw_len": payload.get("__raw_len") if isinstance(payload, dict) else "",
            "payload_keys": sorted([str(k) for k in payload.keys() if not str(k).startswith("__body")])[:20] if isinstance(payload, dict) else [],
        })
        if is_provider_limit_payload("mdblist", payload, headers):
            message = provider_limit_message("mdblist", payload)
            retry_after = payload.get("__retry_after") if isinstance(payload, dict) else ""
            meta["limited"] = True
            meta["limit_provider"] = "MDBList"
            meta["limit_message"] = message
            meta["retry_after"] = retry_after or ""
            log("MDBList API limit reached: {0}".format(message), xbmc.LOGWARNING)
            return output, meta
        if payload_error:
            continue
        useful_rows = False
        if isinstance(rows, list):
            for row in rows:
                if isinstance(row, dict):
                    rating = normalized_rating(str(row.get("source", "")), row.get("value"), row.get("score"), None, "mdblist")
                    if safe_float(rating.get("score")) is not None or safe_float(rating.get("value")) is not None:
                        useful_rows = True
                    # Preserve the first result for a source. Candidate order is
                    # deliberate; later IDs are only fallback when the primary
                    # lookup returns no useful numeric ratings at all.
                    merge_rating(output, rating, overwrite=False)
        awards_text = str(payload.get("awards") or "").strip() if isinstance(payload, dict) else ""
        if awards_text and not str(meta.get("awards_text") or "").strip():
            meta["awards_text"] = awards_text
        for id_key, id_value in (payload.get("ids") or {}).items():
            if id_value not in (None, ""):
                meta["ids"].setdefault(str(id_key), str(id_value))
        if headers.get("x-ratelimit-remaining") not in (None, ""):
            meta["rate_limit_remaining"] = headers.get("x-ratelimit-remaining", "")
        # v1.3.23: normal movie/series rating scrape should cost one MDBList
        # request. Only try alternate IDs if the primary response is empty or
        # unusable.
        if useful_rows:
            break
    return output, meta


def tmdb_get(path: str, key: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not key:
        return {}
    query = {"api_key": key, "language": "en-US"}
    if params:
        query.update(params)
    payload, _ = http_json("https://api.themoviedb.org/3/{0}?{1}".format(path.lstrip("/"), urlencode(query)))
    return payload


def tmdb_search(item: Dict[str, Any], key: str, show: bool = False) -> str:
    title = str(item.get("showtitle") if show else item.get("title") or "").strip()
    if not title:
        return ""
    params: Dict[str, Any] = {"query": title}
    year = safe_int(item.get("show_year") if show else item.get("year"))
    if year:
        params["first_air_date_year" if show else "year"] = year
    payload = tmdb_get("search/tv" if show else "search/movie", key, params)
    rows = payload.get("results") or []
    if isinstance(rows, list) and rows:
        candidate = rows[0] if isinstance(rows[0], dict) else {}
        return str(candidate.get("id") or "")
    return ""


def tmdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    if not key:
        return {}, ids
    output: Dict[str, Any] = {}
    updated_ids = dict(ids)
    media_type = item.get("type")
    payload: Dict[str, Any] = {}
    if media_type == "movie":
        tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, False)
        if tmdb_id:
            updated_ids.setdefault("tmdb", str(tmdb_id))
            payload = tmdb_get("movie/{0}".format(tmdb_id), key)
    elif media_type == "tvshow":
        tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, True)
        if tmdb_id:
            updated_ids.setdefault("tmdb", str(tmdb_id))
            payload = tmdb_get("tv/{0}".format(tmdb_id), key)
    elif media_type == "episode":
        show_ids = dict(item.get("show_ids") or {})
        show_tmdb = show_ids.get("tmdb") or tmdb_search(item, key, True)
        season, episode = safe_int(item.get("season")), safe_int(item.get("episode"))
        if show_tmdb and season is not None and episode is not None:
            payload = tmdb_get("tv/{0}/season/{1}/episode/{2}".format(show_tmdb, season, episode), key)
            updated_ids.setdefault("show_tmdb", str(show_tmdb))
            if payload.get("id") not in (None, ""):
                updated_ids.setdefault("tmdb", str(payload["id"]))
    vote = payload.get("vote_average")
    if vote not in (None, ""):
        merge_rating(output, normalized_rating("tmdb", vote, safe_float(vote) * 10 if safe_float(vote) is not None else None, None, "tmdb"), overwrite=True)
    return output, updated_ids



def _date_display(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    match = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", text)
    if match:
        return "{0}/{1}/{2}".format(match.group(3), match.group(2), match.group(1))
    return text


def _normalize_tmdb_status(value: Any) -> str:
    """Match the AF3/TMDbHelper-facing spelling without touching cached rows.

    TMDb returns `Canceled`. AF3/TMDbHelper commonly displays `Cancelled`.
    Only newly fetched empty status fields use this normalized value; existing
    cache fields are never rewritten by the missing-only status merge.
    """
    text = str(value or "").strip()
    if text.lower() == "canceled":
        return "Cancelled"
    return text


def _series_meta_needs_fill(series: Dict[str, Any]) -> bool:
    if not isinstance(series, dict):
        return True
    # Missing-only means any important blank metadata field can be filled, while
    # values that already exist are preserved exactly.
    for key in (
        "status",
        "status_date",
        "status_date_display",
        "first_air_date",
        "last_air_date",
        "next_episode_air_date",
        "last_episode_air_date",
    ):
        if not str(series.get(key) or "").strip():
            return True
    return False


def _merge_missing_series_meta(existing: Dict[str, Any], found: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(existing or {})
    for key, value in (found or {}).items():
        if value in (None, ""):
            continue
        if not str(merged.get(key) or "").strip():
            merged[key] = value
    return merged


def _award_count(pattern: str, text: Any) -> int:
    raw = str(text or "")
    match = re.search(pattern, raw, flags=re.I)
    return safe_int(match.group(1)) or 0 if match else 0


def parse_awards_wins(awards_text: Any) -> Dict[str, Any]:
    """Parse wins only from OMDb Awards text.

    TMDbHelper exposes Oscar_Wins and Emmy_Wins; nominations are deliberately
    ignored per user request. Keep this conservative: only explicit `Won N ...`
    phrases count, while `Nominated for N ...` remains blank/zero.
    """
    text = str(awards_text or "").strip()
    if not text or text.upper() == "N/A":
        return {}
    oscar_wins = _award_count(r"\bWon\s+(\d+)\s+Oscars?\b", text)
    emmy_wins = _award_count(r"\bWon\s+(\d+)\s+(?:Primetime\s+|Daytime\s+)?Emmys?\b", text)
    output: Dict[str, Any] = {"source": "omdb", "awards_text": text, "updated_at": now_iso()}
    if oscar_wins > 0:
        output["oscar_wins"] = oscar_wins
    if emmy_wins > 0:
        output["emmy_wins"] = emmy_wins
    return output


def _awards_needs_fill(awards: Dict[str, Any], media_type: Any) -> bool:
    if media_setting_type(media_type) not in ("movie", "tvshow"):
        return False
    if not bool_setting("scrape_awards_wins", True):
        return False
    if not isinstance(awards, dict):
        return True
    # Movies mostly need Oscar_Wins; TV shows mostly need Emmy_Wins. We still
    # allow either family on either media type, but do not force an OMDb lookup
    # forever after a source text is already cached.
    if str(awards.get("awards_text") or "").strip():
        return False
    return True


def _merge_missing_awards(existing: Dict[str, Any], found: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(existing or {})
    for key, value in (found or {}).items():
        if value in (None, ""):
            continue
        if key in ("oscar_wins", "emmy_wins"):
            if safe_int(merged.get(key)) is None:
                merged[key] = value
        elif not str(merged.get(key) or "").strip():
            merged[key] = value
    return merged


def _episode_air_date(payload: Any) -> str:
    if isinstance(payload, dict):
        return str(payload.get("air_date") or "").strip()
    return ""


def _series_status_date(payload: Dict[str, Any]) -> Tuple[str, str]:
    next_date = _episode_air_date(payload.get("next_episode_to_air"))
    last_date = _episode_air_date(payload.get("last_episode_to_air")) or str(payload.get("last_air_date") or "").strip()
    first_date = str(payload.get("first_air_date") or "").strip()
    status = str(payload.get("status") or "").strip()
    status_l = status.lower()
    if next_date and status_l in ("returning series", "in production", "planned", "pilot"):
        return next_date, "next_episode_air_date"
    if last_date and status_l in ("ended", "canceled", "cancelled"):
        return last_date, "last_episode_air_date"
    if last_date:
        return last_date, "last_episode_air_date"
    return first_date, "first_air_date"


def tmdb_tv_status_lookup(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    """Fetch TV show status/date metadata from TMDb.

    Stored separately from ratings so there is still only one visible value per
    rating family. Used for AF3's existing TMDbHelper.ListItem.Status display.
    """
    if not key or item.get("type") != "tvshow":
        return {}, ids
    updated_ids = dict(ids)
    tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, True)
    if not tmdb_id:
        return {}, ids
    updated_ids.setdefault("tmdb", str(tmdb_id))
    payload = tmdb_get("tv/{0}".format(tmdb_id), key)
    if not payload:
        return {}, updated_ids
    status = _normalize_tmdb_status(payload.get("status"))
    date_value, date_kind = _series_status_date(payload)
    meta = {
        "status": status,
        "first_air_date": str(payload.get("first_air_date") or "").strip(),
        "last_air_date": str(payload.get("last_air_date") or "").strip(),
        "next_episode_air_date": _episode_air_date(payload.get("next_episode_to_air")),
        "last_episode_air_date": _episode_air_date(payload.get("last_episode_to_air")),
        "status_date": date_value,
        "status_date_kind": date_kind,
        "status_date_display": _date_display(date_value),
        "source": "tmdb",
        "updated_at": now_iso(),
    }
    return {key: value for key, value in meta.items() if value not in (None, "")}, updated_ids



def _omdb_payload_has_data(payload: Any) -> bool:
    """Return True when an OMDb response contains actual title/rating data.

    Some Kodi/Python/SSL combinations can produce an empty response object, which
    older builds logged as Response=True because OMDb defaults were assumed. For
    episode checks we need to know whether the request really returned useful
    fields before deciding not to try the fallback URL scheme.
    """
    if not isinstance(payload, dict):
        return False
    if str(payload.get("Response", "True")).lower() == "false":
        return False
    if payload.get("Title") or payload.get("imdbID"):
        return True
    if payload.get("imdbRating") not in (None, "", "N/A"):
        return True
    if payload.get("Metascore") not in (None, "", "N/A"):
        return True
    ratings = payload.get("Ratings")
    return isinstance(ratings, list) and bool(ratings)

def omdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str], Dict[str, Any]]:
    meta: Dict[str, Any] = {"attempts": []}
    if not key:
        return {}, ids, meta

    def parse_payload(payload: Dict[str, Any], output: Dict[str, Any], updated_ids: Dict[str, str]) -> None:
        if not payload or payload.get("__error") or str(payload.get("Response", "True")).lower() == "false":
            return
        if str(payload.get("imdbID") or "").lower().startswith("tt"):
            updated_ids.setdefault("imdb", str(payload["imdbID"]))
        if payload.get("imdbRating") not in (None, "", "N/A"):
            merge_rating(output, normalized_rating("imdb", payload.get("imdbRating"), None, None, "omdb"), overwrite=False)
        if payload.get("Metascore") not in (None, "", "N/A"):
            merge_rating(output, normalized_rating("metacritic", payload.get("Metascore"), None, None, "omdb"), overwrite=False)
        for row in payload.get("Ratings") or []:
            if not isinstance(row, dict):
                continue
            source, value = str(row.get("Source", "")).lower(), row.get("Value")
            if "rotten tomatoes" in source:
                merge_rating(output, normalized_rating("tomatoes", value, None, None, "omdb"), overwrite=False)
            elif "internet movie database" in source:
                merge_rating(output, normalized_rating("imdb", value, None, None, "omdb"), overwrite=False)
            elif "metacritic" in source:
                merge_rating(output, normalized_rating("metacritic", value, None, None, "omdb"), overwrite=False)
        awards = parse_awards_wins(payload.get("Awards"))
        if awards:
            output["__awards"] = awards

    base: Dict[str, Any] = {"apikey": key, "r": "json", "tomatoes": "true"}
    attempts: List[Dict[str, Any]] = []
    imdb_id = ids.get("imdb", "")
    if imdb_id.lower().startswith("tt"):
        params = dict(base); params["i"] = imdb_id
        attempts.append(params)

    if item.get("type") == "episode":
        if item.get("showtitle") and safe_int(item.get("season")) is not None and safe_int(item.get("episode")) is not None:
            params = dict(base)
            params["t"] = str(item["showtitle"])
            params["Season"] = int(item["season"])
            params["Episode"] = int(item["episode"])
            attempts.append(params)
    elif not attempts:
        title = str(item.get("title") or "").strip()
        if not title:
            return {}, ids, meta
        params = dict(base)
        params["t"] = title
        year = safe_int(item.get("year"))
        if year:
            params["y"] = year
        params["type"] = "series" if item.get("type") == "tvshow" else "movie"
        attempts.append(params)

    output: Dict[str, Any] = {}
    updated_ids = dict(ids)
    seen_urls = set()
    for params in attempts:
        query = urlencode(params)
        # v1.3.18: OMDb episode lookups are retried through the plain HTTP
        # endpoint because the public OMDb examples and some Kodi/Python builds
        # are more reliable there than through HTTPS. This is a read-only API
        # request; the API key is still redacted in logs.
        url_candidates = [
            "http://www.omdbapi.com/?" + query,
            "https://www.omdbapi.com/?" + query,
        ]
        for url in url_candidates:
            if url in seen_urls:
                continue
            seen_urls.add(url)
            attempt_meta: Dict[str, Any] = {"params": _public_params(params), "scheme": url.split(":", 1)[0]}
            payload: Dict[str, Any] = {}
            try:
                payload, _ = http_json(url)
                response = str(payload.get("Response", "True")) if isinstance(payload, dict) else ""
                attempt_meta.update({
                    "response": response,
                    "http_status": payload.get("__http_status") if isinstance(payload, dict) else "",
                    "raw_len": payload.get("__raw_len") if isinstance(payload, dict) else "",
                    "title": payload.get("Title") if isinstance(payload, dict) else "",
                    "type": payload.get("Type") if isinstance(payload, dict) else "",
                    "year": payload.get("Year") if isinstance(payload, dict) else "",
                    "imdbID": payload.get("imdbID") if isinstance(payload, dict) else "",
                    "error": (payload.get("Error") or payload.get("__error") or payload.get("__body") or "") if isinstance(payload, dict) else "",
                    "ratings": _compact_rating_sources(payload.get("Ratings") if isinstance(payload, dict) else []),
                    "imdbRating": payload.get("imdbRating") if isinstance(payload, dict) else "",
                    "Metascore": payload.get("Metascore") if isinstance(payload, dict) else "",
                    "Awards": payload.get("Awards") if isinstance(payload, dict) else "",
                })
                if is_provider_limit_payload("omdb", payload):
                    message = provider_limit_message("omdb", payload)
                    log("OMDb API limit reached; stopping scrape: {0}".format(message), xbmc.LOGWARNING)
                    meta["attempts"].append(attempt_meta)
                    raise ProviderLimitReached("OMDb", message, payload.get("__retry_after") if isinstance(payload, dict) else "")
                parse_payload(payload, output, updated_ids)
                # If an explicit IMDb ID lookup succeeds, stop immediately.
                # Do not burn another OMDb request with title/season/episode.
                if params.get("i") and str(payload.get("Response", "True")).lower() == "true" and _omdb_payload_has_data(payload):
                    meta["attempts"].append(attempt_meta)
                    meta["found_sources"] = [str(k) for k in output.keys()]
                    return output, updated_ids, compact_provider_meta({"omdb": meta}).get("omdb", meta)
            except ProviderLimitReached:
                raise
            except Exception as exc:  # pylint: disable=broad-except
                attempt_meta["error"] = str(exc)
            meta["attempts"].append(attempt_meta)
            # Stop trying the alternate scheme once the current response actually
            # contains OMDb data or an explicit provider error. Empty/network-like
            # responses fall through to the alternate scheme.
            if _omdb_payload_has_data(payload) or (isinstance(payload, dict) and str(payload.get("Response", "True")).lower() == "false" and payload.get("Error")):
                break
    meta["found_sources"] = [str(k) for k in output.keys()]
    return output, updated_ids, meta


def _omdb_attempt_via(attempt: Dict[str, Any]) -> str:
    params = attempt.get("params") or {}
    if params.get("i"):
        return "i={0}".format(params.get("i"))
    if params.get("t"):
        via = "t={0}".format(params.get("t"))
        if params.get("Season") not in (None, ""):
            via += " S{0}E{1}".format(params.get("Season"), params.get("Episode"))
        elif params.get("type"):
            via += " type={0}".format(params.get("type"))
        return via
    return str(params)


def compact_provider_meta(provider_meta: Dict[str, Any]) -> Dict[str, Any]:
    """Keep cache/debug metadata small.

    Ratings, ids, series status and awards are the real cache payload. Provider
    attempts are only for debugging, so keep a compact human-readable summary and
    drop noisy HTTP byte counts, payload keys, schemes, duplicate internals, etc.
    """
    if not isinstance(provider_meta, dict):
        return {}
    output: Dict[str, Any] = {}

    mdblist = provider_meta.get("mdblist") or {}
    if isinstance(mdblist, dict):
        row: Dict[str, Any] = {}
        if mdblist.get("limited"):
            row["limited"] = True
            if mdblist.get("limit_message"):
                row["limit_message"] = mdblist.get("limit_message")
        attempts: List[Dict[str, Any]] = []
        for attempt in mdblist.get("attempts") or []:
            if not isinstance(attempt, dict):
                continue
            compact_attempt: Dict[str, Any] = {
                "via": "{0}/{1}/{2}".format(attempt.get("provider") or "", attempt.get("media_type") or "", attempt.get("id") or "").strip("/"),
            }
            if attempt.get("ratings") not in (None, ""):
                compact_attempt["ratings"] = attempt.get("ratings")
            if attempt.get("sources"):
                compact_attempt["sources"] = attempt.get("sources")
            if attempt.get("error"):
                compact_attempt["error"] = attempt.get("error")
            status = safe_int(attempt.get("http_status"))
            if status and status != 200:
                compact_attempt["http_status"] = status
            attempts.append(compact_attempt)
        if attempts:
            row["attempts"] = attempts
        if row:
            output["mdblist"] = row

    omdb = provider_meta.get("omdb") or {}
    if isinstance(omdb, dict):
        row: Dict[str, Any] = {}
        attempts: List[Dict[str, Any]] = []
        for attempt in omdb.get("attempts") or []:
            if not isinstance(attempt, dict):
                continue
            compact_attempt: Dict[str, Any] = {"via": _omdb_attempt_via(attempt)}
            for key in ("response", "title", "imdbRating", "Metascore", "error"):
                value = attempt.get(key)
                if value not in (None, "", "N/A"):
                    compact_attempt[key] = value
            if attempt.get("ratings"):
                compact_attempt["ratings"] = attempt.get("ratings")
            status = safe_int(attempt.get("http_status"))
            if status and status != 200:
                compact_attempt["http_status"] = status
            attempts.append(compact_attempt)
        if attempts:
            row["attempts"] = attempts
        if omdb.get("found_sources"):
            row["found_sources"] = omdb.get("found_sources")
        if row:
            output["omdb"] = row
    return output


def _resolve_top250_rank_for_item(item: Dict[str, Any], ids: Dict[str, str], existing: Dict[str, Any]) -> int:
    media_type = media_setting_type(item.get("type"))
    if media_type == "movie":
        return safe_int(existing.get("imdb_top250_movie_rank") or existing.get("imdb_top250_rank")) or safe_int(item.get("top250")) or 0
    if media_type == "tvshow":
        old = safe_int(existing.get("imdb_top250_tv_rank") or existing.get("imdb_top250_rank")) or 0
        imdb_id = str((ids or {}).get("imdb") or "").lower()
        rank = safe_int(imdb_top250_tv_ranks().get(imdb_id)) or 0
        return rank or old
    return 0


def resolve_item(item: Dict[str, Any], keys: Dict[str, str], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True, include_local: bool = True, ratings_only: bool = False) -> Dict[str, Any]:
    media_type = media_setting_type(item.get("type"))
    existing = existing if isinstance(existing, dict) else {}

    # Missing-only decides whether we need to hit an API. Once an API is hit,
    # v1.3.23 uses all enabled values returned by that same response because it
    # costs no extra request.
    ratings = preserve_ratings_for_item(media_type, existing.get("ratings") or {}) if missing_only and existing else {}
    ids = dict(existing.get("ids") or {}) if missing_only and existing else {}
    provider_meta: Dict[str, Any] = dict(existing.get("provider_meta") or {}) if missing_only and existing else {}
    series_meta: Dict[str, Any] = dict(existing.get("series") or {}) if missing_only and existing else {}
    awards_meta: Dict[str, Any] = dict(existing.get("awards") or {}) if missing_only and existing else {}

    if include_local:
        local = filter_ratings_for_item(media_type, local_ratings(item))
        for key, row in local.items():
            if key not in ratings:
                ratings[key] = row

    item_ids = extract_ids(item)
    for key, value in item_ids.items():
        if value not in (None, ""):
            ids.setdefault(str(key), str(value))

    errors: List[str] = []
    item_type = item.get("type")
    is_movie_or_show = item_type in ("movie", "tvshow")
    # v1.3.64: these must respect the toggles immediately.  Previous builds
    # calculated awards_missing even when Awards was OFF, so an MDBList limit was
    # incorrectly treated as "fallback allowed" and the job continued without
    # writing real rating rows.
    status_missing = False if ratings_only else (item_type == "tvshow" and bool_setting("scrape_tv_status", True) and _series_meta_needs_fill(series_meta))
    awards_missing = False if ratings_only else (bool_setting("scrape_awards_wins", True) and _awards_needs_fill(awards_meta, item_type))

    def current_missing() -> set:
        return record_missing_logicals(media_type, {"ratings": ratings})

    checked_no_value_logicals: set = set()
    mdblist_final_for_ratings = False

    missing = current_missing()

    # TMDb is still needed for series status/date and sometimes to discover the
    # TMDb id when the library only has a title. For movie/series ratings, MDBList
    # is the primary aggregator and can also return TMDb rating.
    need_tmdb_id_for_mdblist = is_movie_or_show and bool(missing & MDBLIST_PROVIDER_LOGICALS) and not (ids.get("imdb") or ids.get("tmdb"))
    need_tmdb_episode_rating = item_type == "episode" and "tmdb" in missing
    need_tmdb_direct_movie_show = is_movie_or_show and "tmdb" in missing and not (bool_setting("use_mdblist", True) and keys.get("mdblist"))
    if bool_setting("use_tmdb", True) and keys.get("tmdb") and (need_tmdb_id_for_mdblist or need_tmdb_episode_rating or need_tmdb_direct_movie_show):
        try:
            found, ids = tmdb_lookup(item, ids, keys["tmdb"])
            # Episode TMDb is a dedicated TMDb API hit; direct movie/show TMDb is
            # only fallback when MDBList cannot be used. Do not rewrite existing
            # fields unless force refresh is active.
            merge_provider_ratings(ratings, found, media_type, allowed_logicals={"tmdb"}, overwrite=not missing_only)
            if need_tmdb_episode_rating or need_tmdb_direct_movie_show:
                checked_no_value_logicals.add("tmdb")
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("tmdb: {0}".format(exc))

    if bool_setting("use_tmdb", True) and keys.get("tmdb") and status_missing:
        try:
            found_series, ids = tmdb_tv_status_lookup(item, ids, keys["tmdb"])
            if found_series:
                # Status metadata remains strict missing-only: never overwrite
                # status/date fields the cache already has.
                series_meta = _merge_missing_series_meta(series_meta, found_series)
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("tmdb_status: {0}".format(exc))

    # Movie/series: MDBList first. One usable MDBList response can fill/update
    # IMDb, TMDb, RT critics, RT audience, Metacritic, Trakt, Letterboxd, MDBList.
    missing = current_missing()
    mdblist_needed = is_movie_or_show and bool(missing & MDBLIST_PROVIDER_LOGICALS)
    if mdblist_needed:
        if keys.get("__mdblist_limited"):
            if not awards_missing and not status_missing:
                raise ProviderLimitReached("MDBList", "All MDBList API keys are limited; awards/status are OFF so no fallback is needed")
            errors.append("mdblist: skipped after API limit; awards/status fallback only")
        elif not bool_setting("use_mdblist", True):
            errors.append("mdblist: provider disabled")
        elif not keys.get("mdblist"):
            errors.append("mdblist: api key missing")
        else:
            try:
                mdblist_missing_before = set(missing & MDBLIST_PROVIDER_LOGICALS)
                found, meta = mdblist_lookup(ids, "movie" if item_type == "movie" else "show", keys["mdblist"])
                provider_meta["mdblist"] = meta
                if meta.get("limited"):
                    keys["__mdblist_limited"] = "true"
                    if not awards_missing and not status_missing:
                        raise ProviderLimitReached("MDBList", meta.get("limit_message") or "All MDBList API keys are limited; awards/status are OFF so no fallback is needed", meta.get("retry_after") or "")
                    errors.append("mdblist: API limit reached; awards/status fallback only")
                else:
                    # Smart update: because we already spent this MDBList request to
                    # fill a missing enabled field, use every enabled rating family
                    # present in the same response, including fields that already had
                    # an older value.
                    merge_provider_ratings(ratings, found, media_type, allowed_logicals=MDBLIST_PROVIDER_LOGICALS, overwrite=True)
                    for key, value in (meta.get("ids") or {}).items():
                        if value not in (None, ""):
                            ids.setdefault(str(key), str(value))
                    if mdblist_lookup_cacheable(meta):
                        checked_no_value_logicals.update(mdblist_missing_before)
                        mdblist_final_for_ratings = True
            except ProviderLimitReached:
                # MDBList limit is fatal for movie/tv rating-only flow when awards/status are OFF.
                keys["__mdblist_limited"] = "true"
                if not awards_missing and not status_missing:
                    raise ProviderLimitReached("MDBList", "All MDBList API keys are limited; awards/status are OFF so no fallback is needed")
                errors.append("mdblist: API limit reached; awards/status fallback only")
            except Exception as exc:  # pylint: disable=broad-except
                errors.append("mdblist: {0}".format(exc))

    # Fallbacks after MDBList. For episodes, OMDb is the primary IMDb episode
    # provider. For movie/series v1.3.96 allows a narrow RT-critics fallback:
    # if MDBList was successfully queried but returned tomatoes=null/missing,
    # call OMDb once and merge only the Rotten Tomatoes critics score.  RT
    # audience/popcorn stays MDBList-only because OMDb does not provide it.
    missing = current_missing()
    omdb_needed = bool(missing & OMDB_LOGICALS)
    omdb_allowed_logicals = set(OMDB_LOGICALS)
    if is_movie_or_show:
        mdblist_meta_for_rt = provider_meta.get("mdblist") if isinstance(provider_meta.get("mdblist"), dict) else {}
        mdblist_had_usable_response = bool(mdblist_meta_for_rt) and not mdblist_meta_for_rt.get("limited") and mdblist_lookup_cacheable(mdblist_meta_for_rt)
        rt_critic_needs_omdb_fallback = "rt_critic" in missing and "rt_critic" in MDBLIST_PROVIDER_LOGICALS and mdblist_had_usable_response
        omdb_needed = bool(rt_critic_needs_omdb_fallback)
        omdb_allowed_logicals = {"rt_critic"}
        if rt_critic_needs_omdb_fallback:
            errors.append("rt_critic: MDBList tomatoes missing/null; trying OMDb fallback")
    omdb_awards_needed = bool_setting("scrape_awards_wins", True) and awards_missing and item_type in ("movie", "tvshow")
    if bool_setting("use_omdb", True) and keys.get("omdb") and (omdb_needed or omdb_awards_needed):
        try:
            omdb_missing_before = set(missing & omdb_allowed_logicals)
            found, ids, omdb_meta = omdb_lookup(item, ids, keys["omdb"])
            provider_meta["omdb"] = omdb_meta
            found_awards = found.pop("__awards", {}) if isinstance(found, dict) else {}
            if found_awards:
                awards_meta = _merge_missing_awards(awards_meta, found_awards)
            # One OMDb response can include IMDb, Metacritic and sometimes RT.
            # In movie/show RT fallback mode, merge only RT critics so OMDb never
            # replaces MDBList IMDb/Metacritic/TMDb/Trakt rows.
            if omdb_needed:
                merge_provider_ratings(ratings, found, media_type, allowed_logicals=omdb_allowed_logicals, overwrite=True)
                if omdb_lookup_cacheable(omdb_meta):
                    checked_no_value_logicals.update(omdb_missing_before)
        except ProviderLimitReached:
            raise
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("omdb: {0}".format(exc))

    # Final fallback for TMDb rating if MDBList did not provide it and direct
    # TMDb was not already attempted above.
    missing = current_missing()
    if bool_setting("use_tmdb", True) and keys.get("tmdb") and "tmdb" in missing and not mdblist_final_for_ratings and not (is_movie_or_show and keys.get("__mdblist_limited")) and not need_tmdb_episode_rating and not need_tmdb_direct_movie_show:
        try:
            found, ids = tmdb_lookup(item, ids, keys["tmdb"])
            merge_provider_ratings(ratings, found, media_type, allowed_logicals={"tmdb"}, overwrite=False)
            checked_no_value_logicals.add("tmdb")
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("tmdb_fallback: {0}".format(exc))

    remaining_missing = current_missing()
    if checked_no_value_logicals:
        mark_unavailable_ratings(ratings, media_type, remaining_missing & checked_no_value_logicals)

    return {
        "type": item.get("type"), "dbid": item.get("dbid"), "title": item.get("title") or "",
        "year": item.get("year") or "", "showtitle": item.get("showtitle") or "",
        "season": item.get("season") if item.get("type") == "episode" else None,
        "episode": item.get("episode") if item.get("type") == "episode" else None,
        "ids": ids, "ratings": preserve_ratings_for_item(media_type, ratings), "provider_meta": compact_provider_meta(provider_meta),
        "series": series_meta, "awards": awards_meta,
        "imdb_top250_rank": (safe_int(existing.get("imdb_top250_rank")) or 0) if ratings_only else (_resolve_top250_rank_for_item(item, ids, existing) if rating_enabled(media_type, "top250", True) else 0),
        "errors": errors, "timestamp": int(time.time()), "updated_at": now_iso(),
    }

def _csv_imdb_id(value: Any) -> str:
    value = str(value or "").strip()
    return value if value.lower().startswith("tt") else ""

def _csv_tmdb_id(value: Any) -> str:
    value = str(value or "").strip()
    return value if value.isdigit() else ""

def csv_top250_rank(entry: Dict[str, Any]) -> Any:
    media_type = media_setting_type(entry.get("type"))
    if media_type == "movie":
        return safe_int(entry.get("imdb_top250_movie_rank") or entry.get("imdb_top250_rank")) or ""
    if media_type == "tvshow":
        return safe_int(entry.get("imdb_top250_tv_rank") or entry.get("imdb_top250_rank")) or ""
    return safe_int(entry.get("imdb_top250_rank")) or ""


def export_csv(cache: Dict[str, Any]) -> str:
    os.makedirs(PROFILE, exist_ok=True)
    entries = list((cache.get("items") or {}).values())
    canonical_entries = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        row = dict(entry)
        row["ratings"] = preserve_ratings_for_item(row.get("type"), row.get("ratings") or {})
        canonical_entries.append(row)

    # Keep ID columns and rating columns explicitly separate. Older reports used
    # duplicated headers such as `imdb` and `tmdb` for both IDs and ratings,
    # which made spreadsheet apps collapse/overwrite the second value.
    sources = sorted({source for entry in canonical_entries for source in (entry.get("ratings") or {}).keys()})
    fixed = [
        "type", "dbid", "title", "showtitle", "season", "episode", "year",
        "tmdb_id", "imdb_id", "imdb_top250_rank",
        "oscar_wins", "emmy_wins", "series_status", "series_status_date", "updated_at",
    ]
    rating_columns = ["rating_{0}".format(source) for source in sources]
    columns = fixed + rating_columns

    with open(REPORT_FILE, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for entry in sorted(canonical_entries, key=lambda row: (str(row.get("type")), str(row.get("showtitle")), str(row.get("title")), safe_int(row.get("season")) or -1, safe_int(row.get("episode")) or -1)):
            row = {key: entry.get(key, "") for key in fixed}
            ids = entry.get("ids") or {}
            row["tmdb_id"] = _csv_tmdb_id(ids.get("tmdb"))
            row["imdb_id"] = _csv_imdb_id(ids.get("imdb"))
            row["imdb_top250_rank"] = csv_top250_rank(entry)
            awards = entry.get("awards") or {}
            row["oscar_wins"] = awards.get("oscar_wins", "")
            row["emmy_wins"] = awards.get("emmy_wins", "")
            series = entry.get("series") or {}
            row["series_status"] = series.get("status", "")
            row["series_status_date"] = series.get("status_date", "")
            for source in sources:
                rating = (entry.get("ratings") or {}).get(source) or {}
                if is_no_rating_marker(rating):
                    row["rating_{0}".format(source)] = NO_RATING_VALUE
                else:
                    value = rating.get("value")
                    row["rating_{0}".format(source)] = "" if value in (None, "") else value
            writer.writerow(row)
    return REPORT_FILE


def cache_stats(cache: Dict[str, Any]) -> Dict[str, Any]:
    entries = list((cache.get("items") or {}).values())
    stats: Dict[str, Any] = {"total": len(entries), "movie": 0, "tvshow": 0, "episode": 0, "fresh": 0, "with_ratings": 0, "sources": {}, "imdb_top250": 0, "imdb_top250_tv": 0}
    for entry in entries:
        kind = str(entry.get("type") or "")
        if kind in stats:
            stats[kind] += 1
        if fresh(entry): stats["fresh"] += 1
        ratings = entry.get("ratings") or {}
        if ratings: stats["with_ratings"] += 1
        if entry.get("type") == "movie" and (safe_int(entry.get("imdb_top250_movie_rank") or entry.get("imdb_top250_rank")) or 0) > 0:
            stats["imdb_top250"] += 1
        if entry.get("type") == "tvshow" and (safe_int(entry.get("imdb_top250_tv_rank") or entry.get("imdb_top250_rank")) or 0) > 0:
            stats["imdb_top250_tv"] += 1
        for source in ratings:
            stats["sources"][source] = stats["sources"].get(source, 0) + 1
    return stats



def _rating_display_for_report(logical: str, rating: Dict[str, Any]) -> str:
    if not isinstance(rating, dict):
        return ""
    if is_no_rating_marker(rating):
        return NO_RATING_VALUE
    if logical in ("imdb", "tmdb", "trakt", "letterboxd"):
        return display_decimal(rating)
    if logical in ("rt_critic", "rt_audience", "metacritic", "mdblist"):
        value = display_percent(rating)
        return value + "%" if value else ""
    return str(rating.get("value") or rating.get("score") or "")


def _rating_label(logical: str) -> str:
    labels = {
        "imdb": "IMDb",
        "tmdb": "TMDb",
        "rt_critic": "RT critics",
        "rt_audience": "RT audience",
        "metacritic": "Metacritic",
        "trakt": "Trakt",
        "letterboxd": "Letterboxd",
        "mdblist": "MDBList",
        "top250": "IMDb Top 250",
    }
    return labels.get(logical, logical)


def _sample_item_title(item: Dict[str, Any]) -> str:
    if item.get("type") == "episode":
        return "{0} S{1:02d}E{2:02d} - {3}".format(
            item.get("showtitle") or "Series",
            safe_int(item.get("season")) or 0,
            safe_int(item.get("episode")) or 0,
            item.get("title") or "Untitled",
        )
    return str(item.get("title") or "Untitled")


def sample_rating_test(sample_size: int = 5, progress: Any = None) -> Dict[str, Any]:
    """Live-test random items without writing cache.

    Samples up to `sample_size` movies, TV shows, and episodes. For each item it
    resolves only the rating families currently enabled in settings and returns
    a human-readable result so the user can verify whether the selected sources
    actually produce values.

    v1.3.16: this is a true live provider check. Existing cache is used only for
    IDs (imdb/tmdb) so the provider can be queried accurately. Cached ratings and
    local Kodi ratings are ignored; if the internet/provider is unavailable the
    result must be MISS.
    """
    keys = api_keys()
    all_items = library_items()
    by_type = {"movie": [], "tvshow": [], "episode": []}
    for item in all_items:
        kind = str(item.get("type") or "")
        if kind in by_type:
            by_type[kind].append(item)

    selected: List[Dict[str, Any]] = []
    for kind in ("movie", "tvshow", "episode"):
        rows = by_type.get(kind) or []
        if not rows:
            continue
        random.shuffle(rows)
        selected.extend(rows[:max(1, int(sample_size))])

    cache = load_cache()
    total = len(selected)
    results: List[Dict[str, Any]] = []
    canceled = False
    for index, item in enumerate(selected, start=1):
        if progress is not None:
            try:
                if progress.iscanceled():
                    canceled = True
                    break
                progress.update(int((index - 1) * 100 / max(1, total)), "{0}/{1}  {2}".format(index, total, _sample_item_title(item)))
            except Exception:  # pylint: disable=broad-except
                pass
        cached_existing = (cache.get("items") or {}).get(item_key(item)) or {}
        existing = {"ids": dict((cached_existing.get("ids") or {}))}
        try:
            # TRUE LIVE CHECK:
            # Use cached IDs only. Do NOT use cached rating rows. Do NOT use
            # local Kodi ratings. This proves whether enabled online providers
            # can return values right now.
            resolved = resolve_item(item, keys, existing, missing_only=True, include_local=False)
        except Exception as exc:  # pylint: disable=broad-except
            resolved = {"type": item.get("type"), "title": item.get("title"), "errors": [str(exc)], "ratings": {}}
        media_type = media_setting_type(item.get("type"))
        wanted = sorted(enabled_rating_logicals(media_type))
        ratings = filter_ratings_for_item(media_type, resolved.get("ratings") or {})
        rows = []
        for logical in wanted:
            cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
            rating = ratings.get(cache_key)
            if isinstance(rating, dict) and (safe_float(rating.get("score")) is not None or safe_float(rating.get("value")) is not None):
                rows.append({
                    "logical": logical,
                    "label": _rating_label(logical),
                    "value": _rating_display_for_report(logical, rating),
                    "provider": str(rating.get("provider") or ""),
                    "source": str(rating.get("source") or ""),
                    "ok": True,
                })
            else:
                rows.append({"logical": logical, "label": _rating_label(logical), "value": "", "provider": "", "source": "", "ok": False})
        results.append({
            "type": item.get("type"),
            "dbid": item.get("dbid"),
            "title": _sample_item_title(item),
            "ids": resolved.get("ids") or {},
            "ratings": rows,
            "series": resolved.get("series") or {},
            "awards": resolved.get("awards") or {},
            "errors": resolved.get("errors") or [],
            "provider_meta": resolved.get("provider_meta") or {},
            "wanted": wanted,
        })
        delay = max(0, int_setting("delay_ms", 1100)) / 1000.0
        if delay:
            time.sleep(delay)

    if progress is not None:
        try:
            progress.update(100, "Finished")
        except Exception:  # pylint: disable=broad-except
            pass
    return {
        "canceled": canceled,
        "total": total,
        "sample_size": max(1, int(sample_size)),
        "include": {
            "movie": bool_setting("include_movies", True),
            "tvshow": bool_setting("include_tvshows", True),
            "episode": bool_setting("include_episodes", True),
        },
        "results": results,
        "keys": {k: bool(v) for k, v in keys.items()},
    }


def _format_provider_attempts(provider_meta: Dict[str, Any]) -> List[str]:
    lines: List[str] = []
    omdb = provider_meta.get("omdb") or {}
    if omdb.get("attempts"):
        lines.append("  OMDb attempts:")
        for attempt in omdb.get("attempts") or []:
            via = attempt.get("via") or _omdb_attempt_via(attempt)
            ratings = ", ".join(attempt.get("ratings") or []) or "no ratings"
            bits = []
            if attempt.get("response") not in (None, ""):
                bits.append("response={0}".format(attempt.get("response")))
            if attempt.get("title"):
                bits.append("title={0}".format(attempt.get("title")))
            if attempt.get("imdbRating") not in (None, ""):
                bits.append("imdb={0}".format(attempt.get("imdbRating")))
            if attempt.get("Metascore") not in (None, ""):
                bits.append("metascore={0}".format(attempt.get("Metascore")))
            if ratings != "no ratings":
                bits.append("ratings=[{0}]".format(ratings))
            if attempt.get("error"):
                bits.append("error={0}".format(attempt.get("error")))
            if attempt.get("http_status") not in (None, ""):
                bits.append("http={0}".format(attempt.get("http_status")))
            lines.append("    - {0} -> {1}".format(via, " ".join(bits) or "no data"))
    mdblist = provider_meta.get("mdblist") or {}
    if mdblist.get("attempts"):
        lines.append("  MDBList attempts:")
        for attempt in mdblist.get("attempts") or []:
            sources = ", ".join(attempt.get("sources") or []) or "no sources"
            via = attempt.get("via") or "{0}/{1}/{2}".format(attempt.get("provider") or "", attempt.get("media_type") or "", attempt.get("id") or "").strip("/")
            bits = ["ratings_count={0}".format(attempt.get("ratings") or 0)]
            if sources != "no sources":
                bits.append("sources=[{0}]".format(sources))
            if attempt.get("error"):
                bits.append("error={0}".format(attempt.get("error")))
            if attempt.get("http_status") not in (None, ""):
                bits.append("http={0}".format(attempt.get("http_status")))
            lines.append("    - {0} -> {1}".format(via, " ".join(bits)))
        remaining = mdblist.get("rate_limit_remaining")
        if remaining not in (None, ""):
            lines.append("    rate_limit_remaining={0}".format(remaining))
    return lines


def write_sample_rating_test_log(report: Dict[str, Any]) -> str:
    os.makedirs(PROFILE, exist_ok=True)
    text = format_sample_rating_test_report(report)
    try:
        with open(SAMPLE_CHECK_LOG_FILE, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.write("\n\n===== RAW JSON =====\n")
            handle.write(json.dumps(report, indent=2, ensure_ascii=False, sort_keys=True))
    except Exception as exc:  # pylint: disable=broad-except
        log("Failed to write sample check log: {0}".format(exc), xbmc.LOGWARNING)
    return SAMPLE_CHECK_LOG_FILE


def _format_sample_status_awards(row: Dict[str, Any]) -> List[str]:
    lines: List[str] = []
    kind = media_setting_type(row.get("type"))

    if kind == "tvshow" and bool_setting("scrape_tv_status", True):
        series = row.get("series") or {}
        status = str(series.get("status") or "").strip()
        status_date = str(series.get("status_date_display") or series.get("status_date") or "").strip()
        if status:
            value = _lrs_series_status_label_1537(status)
            lines.append("  [OK]   Status: {0}  (tmdb/status)".format(value))
        else:
            lines.append("  [MISS] Status")

    if kind in ("movie", "tvshow") and bool_setting("scrape_awards_wins", True):
        awards = row.get("awards") or {}
        oscar_wins = safe_int(awards.get("oscar_wins")) or 0
        emmy_wins = safe_int(awards.get("emmy_wins")) or 0
        if kind == "movie":
            if oscar_wins > 0:
                lines.append("  [OK]   Oscar wins: {0}  (omdb/awards)".format(oscar_wins))
            else:
                lines.append("  [MISS] Oscar wins")
        elif kind == "tvshow":
            if emmy_wins > 0:
                lines.append("  [OK]   Emmy wins: {0}  (omdb/awards)".format(emmy_wins))
            else:
                lines.append("  [MISS] Emmy wins")
    return lines


def format_sample_rating_test_report(report: Dict[str, Any]) -> str:
    lines = []
    keys = report.get("keys") or {}
    lines.append("Active API keys: MDBList={0}, TMDb={1}, OMDb={2}".format("ON" if keys.get("mdblist") else "OFF", "ON" if keys.get("tmdb") else "OFF", "ON" if keys.get("omdb") else "OFF"))
    inc = report.get("include") or {}
    lines.append("Enabled media: Movies={0}, Series={1}, Episodes={2}".format("ON" if inc.get("movie") else "OFF", "ON" if inc.get("tvshow") else "OFF", "ON" if inc.get("episode") else "OFF"))
    lines.append("Sample per enabled media type: {0}".format(report.get("sample_size") or 5))
    if report.get("canceled"):
        lines.append("Status: canceled")
    lines.append("")
    current_type = None
    type_labels = {"movie": "MOVIES", "tvshow": "SERIES", "episode": "EPISODES"}
    for row in report.get("results") or []:
        kind = str(row.get("type") or "")
        if kind != current_type:
            current_type = kind
            lines.append("===== {0} =====".format(type_labels.get(kind, kind.upper() or "UNKNOWN")))
        ids = row.get("ids") or {}
        id_text = ""
        if ids.get("imdb") or ids.get("tmdb"):
            id_text = "  [imdb={0} tmdb={1}]".format(ids.get("imdb", "-"), ids.get("tmdb", "-"))
        lines.append("\n{0}{1}".format(row.get("title") or "Untitled", id_text))
        for rating in row.get("ratings") or []:
            if rating.get("ok"):
                source = rating.get("source") or ""
                provider = rating.get("provider") or ""
                detail = "{0}/{1}".format(provider, source).strip("/")
                lines.append("  [OK]   {0}: {1}{2}".format(rating.get("label"), rating.get("value"), "  ({0})".format(detail) if detail else ""))
            else:
                lines.append("  [MISS] {0}".format(rating.get("label")))
        lines.extend(_format_sample_status_awards(row))
        errors = [str(e) for e in (row.get("errors") or []) if str(e).strip()]
        if errors:
            lines.append("  errors: {0}".format(" | ".join(errors[:3])))
        provider_lines = _format_provider_attempts(row.get("provider_meta") or {})
        if provider_lines:
            lines.extend(provider_lines)
    if not (report.get("results") or []):
        lines.append("No sample items were processed.")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Arctic Fuse 3 cache publisher and automatic-maintenance helpers (v1.2.0)
# ---------------------------------------------------------------------------
AF3_PREFIX = "LibraryRatings."
TMDBHELPER_PREFIX = "TMDbHelper."
AF3_PROPERTY_NAMES = (
    "IMDb_Rating", "IMDB_Rating", "IMDb", "IMDB", "imdb", "imdb_rating",
    "Top250", "Top250_Rank", "top250", "top250_rank",
    "TMDb_Rating", "TMDB_Rating", "TMDb", "TMDB", "tmdb", "tmdb_rating",
    "RottenTomatoes_Rating",
    "RottenTomatoes", "RottenTomatoes_UserMeter", "RottenTomatoes_User",
    "MetaCritic_Rating", "Trakt_Rating", "MDBList_Rating", "Letterboxd_Rating",
    "RottenTomatoesIcon", "RottenTomatoesImage", "RottenTomatoes_Image",
    "RottenTomatoes_CriticImage", "RottenTomatoesCriticImage",
    "RottenTomatoesAudienceIcon", "RottenTomatoesAudienceImage",
    "RottenTomatoesAudience_Image", "RottenTomatoes_UserImage",
    "RottenTomatoesUserImage",
    # lowercase TMDbHelper-style aliases used by some skin conditions
    "rottentomatoes", "rottentomatoes_image",
    "rottentomatoes_user", "rottentomatoes_userimage",
    "Source", "Status", "StatusDate", "StatusDateDisplay",
    "FirstAirDate", "LastAirDate", "NextAirDate", "NextEpisodeAirDate",
    "LastEpisodeAirDate", "First_Air_Date", "Last_Air_Date", "Next_Air_Date",
    "Oscar_Wins", "Emmy_Wins", "OscarWins", "EmmyWins", "ItemKey", "SourceContext",
)


def _norm_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def _record_rating_quality(media_type: Any, record: Dict[str, Any]) -> int:
    if not isinstance(record, dict) or not record:
        return -1
    score = 0
    ratings = filter_ratings_for_item(media_type, record.get("ratings") or {})
    for logical in enabled_rating_logicals(media_type):
        row = ratings.get(logical)
        if not isinstance(row, dict):
            continue
        if is_no_rating_marker(row):
            score += 1
        elif safe_float(row.get("value")) is not None or safe_float(row.get("score")) is not None:
            score += 3
    return score


def _same_episode_identity(item: Dict[str, Any], row: Dict[str, Any]) -> bool:
    if str(row.get("type") or "").lower() != "episode":
        return False
    item_imdb = _norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb"))
    item_tmdb = _norm_tmdb(item.get("tmdb_id") or item.get("tmdb"))
    ids = row.get("ids") or {}
    if item_imdb and _norm_imdb(ids.get("imdb")) == item_imdb:
        return True
    if item_tmdb and _norm_tmdb(ids.get("tmdb")) == item_tmdb:
        return True
    season = safe_int(item.get("season"))
    episode = safe_int(item.get("episode"))
    if season is not None and safe_int(row.get("season")) != season:
        return False
    if episode is not None and safe_int(row.get("episode")) != episode:
        return False
    show = _norm_text(item.get("showtitle"))
    if show and _norm_text(row.get("showtitle")) != show:
        return False
    title = _norm_text(item.get("title"))
    if title and _norm_text(row.get("title")) != title:
        return False
    return bool(show or title) and season is not None and episode is not None


def _choose_best_record(media_type: Any, candidates: List[Dict[str, Any]], exact: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    clean = [row for row in candidates if isinstance(row, dict) and row]
    if not clean:
        return exact if isinstance(exact, dict) else {}
    best = max(clean, key=lambda row: (_record_rating_quality(media_type, row), 1 if exact is row else 0, safe_int(row.get("dbid")) or -1))
    if isinstance(exact, dict) and exact:
        # Keep exact DBID unless another duplicate has strictly richer enabled ratings.
        if _record_rating_quality(media_type, best) <= _record_rating_quality(media_type, exact):
            return exact
    return best


def cache_record(cache: Dict[str, Any], item: Dict[str, Any]) -> Dict[str, Any]:
    """Find the cached record for the current skin/player item.

    v1.3.53: the DB is already cleaned, so exact type+DBID is trusted.
    Duplicate-row richer fallback is removed. Fallback matching is only for
    widgets/OSD cases where Kodi does not expose a DBID.
    """
    records = cache.get("items") or {}
    exact = records.get(item_key(item)) if safe_int(item.get("dbid")) is not None else None
    if isinstance(exact, dict) and exact:
        return exact

    kind = str(item.get("type") or "").lower()
    media_type = media_setting_type(kind)
    candidates: List[Dict[str, Any]] = []

    imdb_id = _norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb"))
    tmdb_id = _norm_tmdb(item.get("tmdb_id") or item.get("tmdb"))
    if imdb_id or tmdb_id:
        for row in records.values():
            if not isinstance(row, dict):
                continue
            row_kind = str(row.get("type") or "").lower()
            if kind and row_kind != kind:
                continue
            ids = row.get("ids") or {}
            if imdb_id and _norm_imdb(ids.get("imdb")) == imdb_id:
                if row not in candidates:
                    candidates.append(row)
            elif tmdb_id and _norm_tmdb(ids.get("tmdb")) == tmdb_id:
                if row not in candidates:
                    candidates.append(row)

    if kind == "episode":
        for row in records.values():
            if _same_episode_identity(item, row) and row not in candidates:
                candidates.append(row)

    title = _norm_text(item.get("title"))
    if title:
        year = safe_int(item.get("year"))
        showtitle = _norm_text(item.get("showtitle"))
        season = safe_int(item.get("season"))
        episode = safe_int(item.get("episode"))
        for row in records.values():
            if not isinstance(row, dict):
                continue
            row_kind = str(row.get("type") or "").lower()
            if kind and row_kind != kind:
                continue
            if _norm_text(row.get("title")) != title:
                continue
            if row_kind == "episode":
                if showtitle and _norm_text(row.get("showtitle")) != showtitle:
                    continue
                if season is not None and safe_int(row.get("season")) != season:
                    continue
                if episode is not None and safe_int(row.get("episode")) != episode:
                    continue
            elif year is not None and safe_int(row.get("year")) not in (None, year):
                continue
            if row not in candidates:
                candidates.append(row)

    return _choose_best_record(media_type, candidates, None) if candidates else {}


def _rating_number(rating: Dict[str, Any]) -> Optional[float]:
    if not isinstance(rating, dict) or is_no_rating_marker(rating):
        return None
    for field in ("value", "score"):
        number = safe_float(rating.get(field))
        if number is not None:
            return number
    return None


def display_decimal(rating: Dict[str, Any]) -> str:
    number = _rating_number(rating)
    if number is None or number <= 0:
        return ""
    return "{0:.1f}".format(number)


def display_percent(rating: Dict[str, Any]) -> str:
    number = _rating_number(rating)
    if number is None or number <= 0:
        return ""
    return str(int(round(number)))


def display_rt_percent(rating: Dict[str, Any]) -> str:
    # AF3 adds the percent symbol in XML. Publish number only to avoid "78% %".
    return display_percent(rating)


def first_rating(ratings: Dict[str, Any], *names: str) -> Dict[str, Any]:
    for name in names:
        row = ratings.get(name)
        if isinstance(row, dict): return row
    return {}


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    ratings = record.get("ratings") or {}
    if not isinstance(ratings, dict): ratings = {}
    ratings = filter_ratings_for_item(record.get("type"), ratings)
    # v1.3.8: publish only canonical keys. No alias fallback here, because
    # filter_ratings_for_item already folds all old aliases into one value.
    critic = display_percent(first_rating(ratings, "rt_critic"))
    audience = display_percent(first_rating(ratings, "rt_audience"))
    critic_n = safe_int(critic); audience_n = safe_int(audience)
    rt_image = rt_critic_image_token(critic_n)
    rt_audience_image = rt_audience_image_token(audience_n)
    top250_rank = safe_int(record.get("imdb_top250_rank"))
    # Publish Top250 as plain number because AF3 already adds '#'.
    # Keep Top250_Rank as a compatibility display alias with '#'.
    top250_display = str(top250_rank) if top250_rank and rating_enabled(record.get("type"), "top250", True) else ""
    top250_hash_display = "#{0}".format(top250_rank) if top250_display else ""
    critic_display = display_rt_percent(first_rating(ratings, "rt_critic"))
    audience_display = display_rt_percent(first_rating(ratings, "rt_audience"))
    imdb_display = display_decimal(first_rating(ratings, "imdb"))
    tmdb_display = display_decimal(first_rating(ratings, "tmdb"))
    values = {
        "IMDb_Rating": imdb_display,
        "IMDB_Rating": imdb_display,
        "IMDb": imdb_display,
        "IMDB": imdb_display,
        "imdb": imdb_display,
        "imdb_rating": imdb_display,
        "Top250": top250_display,
        "Top250_Rank": top250_hash_display,
        "top250": top250_display,
        "top250_rank": top250_hash_display,
        "TMDb_Rating": tmdb_display,
        "TMDB_Rating": tmdb_display,
        "TMDb": tmdb_display,
        "TMDB": tmdb_display,
        "tmdb": tmdb_display,
        "tmdb_rating": tmdb_display,
        "RottenTomatoes_Rating": critic_display,
        "RottenTomatoes": critic_display,
        "RottenTomatoes_UserMeter": audience_display,
        "RottenTomatoes_User": audience_display,
        "rottentomatoes": critic_display,
        "rottentomatoes_user": audience_display,
        "MetaCritic_Rating": display_percent(first_rating(ratings, "metacritic")),
        "Trakt_Rating": display_decimal(first_rating(ratings, "trakt")),
        "MDBList_Rating": display_percent(first_rating(ratings, "mdblist")),
        "Letterboxd_Rating": display_decimal(first_rating(ratings, "letterboxd")),
        "RottenTomatoesIcon": rt_image,
        "RottenTomatoesImage": rt_image,
        "RottenTomatoes_Image": rt_image,
        "RottenTomatoes_CriticImage": rt_image,
        "RottenTomatoesCriticImage": rt_image,
        "RottenTomatoesAudienceIcon": rt_audience_image,
        "RottenTomatoesAudienceImage": rt_audience_image,
        "RottenTomatoesAudience_Image": rt_audience_image,
        "RottenTomatoes_UserImage": rt_audience_image,
        "RottenTomatoesUserImage": rt_audience_image,
        "rottentomatoes_image": rt_image,
        "rottentomatoes_userimage": rt_audience_image,
        "Source": "script.library.ratings.scraper",
    }
    awards = record.get("awards") or {}
    if bool_setting("publish_awards_wins", True) and isinstance(awards, dict):
        oscar_wins = safe_int(awards.get("oscar_wins"))
        emmy_wins = safe_int(awards.get("emmy_wins"))
        if oscar_wins and oscar_wins > 0:
            values["Oscar_Wins"] = str(oscar_wins)
            values["OscarWins"] = str(oscar_wins)
        if emmy_wins and emmy_wins > 0:
            values["Emmy_Wins"] = str(emmy_wins)
            values["EmmyWins"] = str(emmy_wins)

    series = record.get("series") or {}
    if bool_setting("publish_tv_status", True) and record.get("type") in ("tvshow", "season", "episode") and isinstance(series, dict):
        status = str(series.get("status") or "").strip()
        status_date = str(series.get("status_date") or "").strip()
        status_date_display = str(series.get("status_date_display") or _date_display(status_date)).strip()
        first_air = str(series.get("first_air_date") or "").strip()
        last_air = str(series.get("last_air_date") or "").strip()
        next_air = str(series.get("next_episode_air_date") or "").strip()
        last_episode_air = str(series.get("last_episode_air_date") or "").strip()
        values.update({
            "Status": status,
            "StatusDate": status_date_display or _date_display(status_date),
            "StatusDateDisplay": status_date_display,
            "FirstAirDate": _date_display(first_air),
            "LastAirDate": _date_display(last_air),
            "NextAirDate": _date_display(next_air),
            "NextEpisodeAirDate": _date_display(next_air),
            "LastEpisodeAirDate": _date_display(last_episode_air),
            "First_Air_Date": _date_display(first_air),
            "Last_Air_Date": _date_display(last_air),
            "Next_Air_Date": _date_display(next_air),
        })
    return {key: str(value) for key, value in values.items() if value not in (None, "")}



def _window_home():
    import xbmcgui
    return xbmcgui.Window(10000)


def _publish_windows():
    """Publish to Home plus the active main window only.

    getCurrentWindowDialogId() can return dialog ids that are not backed by an
    xbmcgui.Window object on Kodi 22 alpha, which logs noisy "Window id does not
    exist" exceptions even when caught. Home is the canonical AF3/TMDbHelper
    property location; the active main window is added only when it is safe.
    """
    import xbmcgui
    windows = []
    seen = set()
    try:
        windows.append(xbmcgui.Window(10000)); seen.add(10000)
    except Exception:  # pylint: disable=broad-except
        pass
    getter = getattr(xbmcgui, "getCurrentWindowId", None)
    if getter:
        try:
            wid = int(getter())
        except Exception:  # pylint: disable=broad-except
            wid = 0
        if wid and wid not in seen:
            try:
                windows.append(xbmcgui.Window(wid)); seen.add(wid)
            except Exception:  # pylint: disable=broad-except
                pass
    return windows


def publish_af3_properties(values: Dict[str, str], item_identity: str = "", compatibility: bool = True) -> None:
    published = dict(values)
    published["ItemKey"] = item_identity
    # AF3 Info_Meta_Ratings uses a service parameter. Hub/video info uses
    # service=ListItem, while OSD/player panels can use service=Player or
    # service=VideoPlayer. Publish the same cache row to all of them.
    services = ("ListItem", "Player", "VideoPlayer")
    for window in _publish_windows():
        for service in services:
            for name in AF3_PROPERTY_NAMES:
                value = str(published.get(name, "") or "")
                try:
                    window.setProperty(AF3_PREFIX + service + "." + name, value)
                    if compatibility:
                        window.setProperty(TMDBHELPER_PREFIX + service + "." + name, value)
                except Exception:  # pylint: disable=broad-except
                    pass


def clear_af3_properties(compatibility: bool = True) -> None:
    publish_af3_properties({}, "", compatibility)


def _info_label(*names: str) -> str:
    for name in names:
        value = xbmc.getInfoLabel(name).strip()
        if value:
            return value
    return ""


def _home_property(*names: str) -> str:
    import xbmcgui
    home = xbmcgui.Window(10000)
    for name in names:
        value = home.getProperty(name).strip()
        if value:
            return value
    return ""


def _window_property(*names: str) -> str:
    """Read properties from the currently visible window.

    Arctic Fuse 3 often stores the item context for Hub/Spotlight on the
    current window, while the focused Kodi control can be a Play/More button.
    The old fallback only checked Window(Home), so it could miss the same item
    that the skin was already using for clearlogo/plot.
    """
    for name in names:
        try:
            value = xbmc.getInfoLabel("Window.Property({0})".format(name)).strip()
        except Exception:  # pylint: disable=broad-except
            value = ""
        if value:
            return value
    return ""


def _any_window_property(*names: str) -> str:
    return _window_property(*names) or _home_property(*names)


def _norm_imdb(value: Any) -> str:
    match = re.search(r"tt\d+", str(value or ""), re.I)
    return match.group(0).lower() if match else ""


def _norm_tmdb(value: Any) -> str:
    number = safe_int(value)
    return str(number) if number is not None else str(value or "").strip()


def _clean_dbtype(value: str) -> str:
    value = str(value or "").strip().lower()
    aliases = {
        "movies": "movie", "movieid": "movie",
        "tv": "tvshow", "show": "tvshow", "series": "tvshow", "tvshows": "tvshow", "tvshowid": "tvshow",
        "episodes": "episode", "episodeid": "episode",
        "unknown": "", "video": "", "file": "",
    }
    return aliases.get(value, value)


def _infer_video_type(raw_type: Any, title: Any = "", showtitle: Any = "", season: Any = "", episode: Any = "") -> str:
    kind = _clean_dbtype(str(raw_type or ""))
    if kind:
        return kind
    if str(showtitle or "").strip() or safe_int(season) is not None or safe_int(episode) is not None:
        return "episode"
    if str(title or "").strip():
        return "movie"
    return ""


def player_context_active() -> bool:
    checks = (
        "Player.HasVideo", "Window.IsVisible(VideoOSD)", "Window.IsActive(VideoOSD)",
        "Window.IsVisible(FullscreenVideo)", "Window.IsActive(FullscreenVideo)",
    )
    for condition in checks:
        try:
            if xbmc.getCondVisibility(condition):
                return True
        except Exception:  # pylint: disable=broad-except
            pass
    return False


def focused_control_id() -> Optional[int]:
    for label in ("System.CurrentControlID", "System.CurrentControl", "Control.GetLabel(0)"):
        try:
            value = xbmc.getInfoLabel(label).strip()
        except Exception:  # pylint: disable=broad-except
            value = ""
        number = safe_int(value)
        if number is not None:
            return number
    return None


def hub_focus_container_item() -> Dict[str, Any]:
    if not xbmc.getCondVisibility("Window.IsActive(1102)"):
        return {}
    focused = focused_control_id()
    if focused in (500, 501, 502, 503, 504, 505, 600, 601, 602, 603, 604, 605):
        item = container_item(int(focused), 0)
        if valid_library_item(item):
            item["_focused_container"] = str(focused)
            return item
    return {}


def _jsonrpc(method: str, params: Dict[str, Any]) -> Dict[str, Any]:
    try:
        payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params}
        row = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        return row if isinstance(row, dict) else {}
    except Exception:  # pylint: disable=broad-except
        return {}


def _parse_videodb_identity(value: Any) -> Dict[str, Any]:
    text = str(value or "")
    if not text.startswith("videodb://"):
        return {}
    movie = re.search(r"videodb://movies/titles/(\d+)", text, re.I)
    if movie:
        return {"type": "movie", "dbid": movie.group(1)}
    episode = re.search(r"videodb://tvshows/titles/(\d+)/(\d+)/(\d+)", text, re.I)
    if episode:
        return {"type": "episode", "tvshowid": episode.group(1), "season": episode.group(2), "dbid": episode.group(3)}
    tvshow = re.search(r"videodb://tvshows/titles/(\d+)(?:/)?(?:\?|$)", text, re.I)
    if tvshow:
        return {"type": "tvshow", "dbid": tvshow.group(1)}
    movie_set = re.search(r"videodb://movies/sets/(\d+)", text, re.I)
    if movie_set:
        return {"type": "set", "dbid": movie_set.group(1)}
    if re.search(r"videodb://movies/sets(?:/|\?|$)", text, re.I):
        return {"type": "set"}
    return {}


def _player_jsonrpc_item() -> Dict[str, Any]:
    """Read the currently playing library item directly from Kodi Player.GetItem.

    VideoPlayer.* labels can be empty for a short time while VideoOSD opens or
    when AF3 focus remains on a hub/list control. JSON-RPC gives us the actual
    playing item and prevents OSD from falling back to the previously focused
    item or publishing blank properties.
    """
    player_id = None
    active = _jsonrpc("Player.GetActivePlayers", {})
    for player in active.get("result") or []:
        if isinstance(player, dict) and str(player.get("type") or "").lower() == "video":
            player_id = safe_int(player.get("playerid"))
            break
    if player_id is None:
        return {}
    result = _jsonrpc("Player.GetItem", {
        "playerid": player_id,
        "properties": [
            "title", "showtitle", "season", "episode", "year",
            "imdbnumber", "uniqueid", "file"
        ]
    }).get("result") or {}
    item = result.get("item") or {}
    if not isinstance(item, dict):
        return {}
    uniqueid = item.get("uniqueid") or {}
    if not isinstance(uniqueid, dict):
        uniqueid = {}
    kind = _clean_dbtype(item.get("type") or item.get("dbtype") or "")
    return {
        "type": kind,
        "dbid": str(item.get("id") if item.get("id") not in (None, -1) and kind in ("movie", "tvshow", "episode") else ""),
        "title": str(item.get("title") or ""),
        "showtitle": str(item.get("showtitle") or ""),
        "season": item.get("season") if item.get("season") is not None else "",
        "episode": item.get("episode") if item.get("episode") is not None else "",
        "year": item.get("year") if item.get("year") is not None else "",
        "imdbnumber": item.get("imdbnumber") or uniqueid.get("imdb") or "",
        "tmdb_id": uniqueid.get("tmdb") or uniqueid.get("tmdb_id") or "",
        "file": str(item.get("file") or ""),
    }


def _merge_player_identity(labels: Dict[str, Any], rpc: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(labels or {})
    # Prefer JSON-RPC DBID/type because it is the actual playing library item.
    for key in ("type", "dbid", "showtitle", "season", "episode", "year", "imdbnumber", "tmdb_id"):
        if rpc.get(key) not in (None, ""):
            merged[key] = rpc.get(key)
    # Title label can be prettier in OSD, but if it is empty use Player.GetItem.
    if not str(merged.get("title") or "").strip() and rpc.get("title"):
        merged["title"] = rpc.get("title")
    # If DBTYPE is still missing, infer only from strong episode fields here.
    if not str(merged.get("type") or "").strip():
        merged["type"] = _infer_video_type("", merged.get("title"), merged.get("showtitle"), merged.get("season"), merged.get("episode"))
    return merged


def player_item() -> Dict[str, Any]:
    showtitle = _info_label("VideoPlayer.TVShowTitle", "VideoPlayer.ShowTitle", "VideoPlayer.Property(tvshowtitle)")
    season = _info_label("VideoPlayer.Season", "VideoPlayer.Property(season)")
    episode = _info_label("VideoPlayer.Episode", "VideoPlayer.Property(episode)")
    file_path = _info_label("VideoPlayer.FilenameAndPath", "VideoPlayer.FileNameAndPath", "VideoPlayer.FileName")
    title = _info_label("VideoPlayer.Title", "VideoPlayer.OriginalTitle") or file_path
    label_kind = _clean_dbtype(_info_label("VideoPlayer.DBTYPE", "VideoPlayer.DBType"))
    labels = {
        "type": label_kind,
        "dbid": _info_label("VideoPlayer.DBID", "VideoPlayer.DBId"),
        "title": title,
        "showtitle": showtitle,
        "season": season,
        "episode": episode,
        "year": _info_label("VideoPlayer.Year"),
        "imdbnumber": _info_label("VideoPlayer.IMDBNumber", "VideoPlayer.UniqueID(imdb)", "VideoPlayer.Property(imdb_id)"),
        "tmdb_id": _info_label("VideoPlayer.UniqueID(tmdb)", "VideoPlayer.Property(tmdb_id)", "VideoPlayer.Property(tmdbid)"),
        "top250": _info_label("VideoPlayer.Top250"),
        "file": file_path,
    }
    parsed = _parse_videodb_identity(file_path)
    if parsed:
        labels.update({k: v for k, v in parsed.items() if v not in (None, "")})
    return _merge_player_identity(labels, _player_jsonrpc_item())


def identity_key(item: Dict[str, Any]) -> str:
    kind = str(item.get("type") or "unknown").lower()
    dbid = safe_int(item.get("dbid"))
    if kind in ("movie", "tvshow", "episode") and dbid is not None:
        return "{0}|{1}".format(kind, dbid)
    imdb = _norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb"))
    tmdb = _norm_tmdb(item.get("tmdb_id") or item.get("tmdb"))
    if kind == "episode":
        return "episode|identity|{0}|s{1}|e{2}|{3}|{4}|{5}".format(
            _norm_text(item.get("showtitle")), safe_int(item.get("season")) or "",
            safe_int(item.get("episode")) or "", _norm_text(item.get("title")), imdb, tmdb
        )
    return "{0}|identity|{1}|{2}|{3}|{4}".format(kind or "unknown", _norm_text(item.get("title")), safe_int(item.get("year")) or "", imdb, tmdb)


def record_item_key(record: Dict[str, Any]) -> str:
    if not isinstance(record, dict) or not record:
        return ""
    return item_key(record) if safe_int(record.get("dbid")) is not None else identity_key(record)


def context_matches_record(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if not isinstance(item, dict) or not isinstance(record, dict) or not record:
        return False
    item_kind = str(item.get("type") or "").lower()
    row_kind = str(record.get("type") or "").lower()
    if item_kind and row_kind and item_kind != row_kind:
        return False
    dbid = safe_int(item.get("dbid"))
    if dbid is not None and item_kind in ("movie", "tvshow", "episode"):
        return row_kind == item_kind and safe_int(record.get("dbid")) == dbid
    item_imdb = _norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb"))
    item_tmdb = _norm_tmdb(item.get("tmdb_id") or item.get("tmdb"))
    ids = record.get("ids") or {}
    if item_imdb:
        return _norm_imdb(ids.get("imdb")) == item_imdb
    if item_tmdb:
        return _norm_tmdb(ids.get("tmdb")) == item_tmdb
    if item_kind == "episode" or row_kind == "episode":
        if safe_int(item.get("season")) is not None and safe_int(record.get("season")) != safe_int(item.get("season")):
            return False
        if safe_int(item.get("episode")) is not None and safe_int(record.get("episode")) != safe_int(item.get("episode")):
            return False
        show = _norm_text(item.get("showtitle"))
        if show and _norm_text(record.get("showtitle")) != show:
            return False
    title = _norm_text(item.get("title"))
    if title and _norm_text(record.get("title")) != title:
        return False
    year = safe_int(item.get("year"))
    if year is not None and safe_int(record.get("year")) not in (None, year):
        return False
    return bool(title or item_imdb or item_tmdb or dbid is not None)


def selected_library_item() -> Dict[str, Any]:
    raw_type = _info_label("ListItem.DBTYPE", "ListItem.DBType", "ListItem.Property(DBType)", "ListItem.Property(dbtype)", "ListItem.Property(type)")
    title = _info_label("ListItem.Title", "ListItem.Label", "ListItem.Property(title)")
    showtitle = _info_label("ListItem.TVShowTitle", "ListItem.ShowTitle", "ListItem.Property(tvshowtitle)", "ListItem.Property(showtitle)")
    season = _info_label("ListItem.Season", "ListItem.Property(season)")
    episode = _info_label("ListItem.Episode", "ListItem.Property(episode)")
    file_path = _info_label("ListItem.FilenameAndPath", "ListItem.FileNameAndPath", "ListItem.FileName", "ListItem.Path", "ListItem.FolderPath")
    parsed = _parse_videodb_identity(file_path)
    item = {
        "type": _infer_video_type(raw_type, title, showtitle, season, episode),
        "dbid": _info_label("ListItem.DBID", "ListItem.DBId", "ListItem.Property(dbid)", "ListItem.Property(DBID)"),
        "title": title,
        "showtitle": showtitle,
        "season": season,
        "episode": episode,
        "year": _info_label("ListItem.Year", "ListItem.Property(year)"),
        "imdbnumber": _info_label("ListItem.IMDBNumber", "ListItem.UniqueID(imdb)", "ListItem.Property(imdb_id)", "ListItem.Property(imdb)"),
        "tmdb_id": _info_label("ListItem.UniqueID(tmdb)", "ListItem.Property(tmdb_id)", "ListItem.Property(tmdbid)", "ListItem.Property(tmdb)"),
        "top250": _info_label("ListItem.Top250"),
        "file": file_path,
    }
    if parsed:
        item.update({k: v for k, v in parsed.items() if v not in (None, "")})
    return item


def lrs_active_item() -> Dict[str, Any]:
    """Optional skin bridge target.

    A tiny AF3 skin patch can set LRS.Active.* properties from the media item
    it is drawing, even when focus is on a hub button. This function is harmless
    without that patch and lets future skin-side bridges work without changing
    the display layout.
    """
    imdb = _any_window_property(
        "LRS.Active.IMDb_ID", "LRS.Active.IMDbID", "LRS.Active.IMDbNumber",
        "LRS.Active.IMDBNumber", "LRS.Active.imdb_id",
    )
    tmdb = _any_window_property("LRS.Active.TMDb_ID", "LRS.Active.TMDbID", "LRS.Active.tmdb_id")
    return {
        "type": _clean_dbtype(_any_window_property("LRS.Active.DBTYPE", "LRS.Active.DBType", "LRS.Active.Type")),
        "dbid": _any_window_property("LRS.Active.DBID", "LRS.Active.DBId", "LRS.Active.dbid"),
        "title": _any_window_property("LRS.Active.Title", "LRS.Active.title", "LRS.Active.Label"),
        "showtitle": _any_window_property("LRS.Active.TVShowTitle", "LRS.Active.ShowTitle", "LRS.Active.tvshowtitle"),
        "season": _any_window_property("LRS.Active.Season", "LRS.Active.season"),
        "episode": _any_window_property("LRS.Active.Episode", "LRS.Active.episode"),
        "year": _any_window_property("LRS.Active.Year", "LRS.Active.year"),
        "imdbnumber": imdb,
        "tmdb_id": tmdb,
        "top250": _any_window_property("LRS.Active.Top250"),
    }


def tmdbhelper_item() -> Dict[str, Any]:
    """Fallback for Arctic Fuse 3 hub/spotlight windows.

    Hub/Spotlight can focus a Play/Options button, not the media list item.
    AF3/TMDbHelper can still expose identity on either the current window or
    Window(Home). Check both, then match our local cache by DBID, IMDb ID,
    TMDb ID, or title/year. Rating values still come from this add-on cache.
    """
    imdb = _any_window_property(
        "TMDbHelper.ListItem.IMDb_ID", "TMDbHelper.ListItem.IMDbID",
        "TMDbHelper.ListItem.IMDbNumber", "TMDbHelper.ListItem.IMDBNumber",
        "TMDbHelper.ListItem.imdb_id",
    )
    tmdb = _any_window_property("TMDbHelper.ListItem.TMDb_ID", "TMDbHelper.ListItem.TMDbID", "TMDbHelper.ListItem.tmdb_id")
    return {
        "type": _clean_dbtype(_any_window_property("TMDbHelper.ListItem.DBTYPE", "TMDbHelper.ListItem.DBType", "TMDbHelper.ListItem.Type", "TMDbHelper.ListItem.tmdb_type")),
        "dbid": _any_window_property("TMDbHelper.ListItem.DBID", "TMDbHelper.ListItem.DBId", "TMDbHelper.ListItem.dbid"),
        "title": _any_window_property("TMDbHelper.ListItem.Title", "TMDbHelper.ListItem.title", "TMDbHelper.ListItem.Label"),
        "showtitle": _any_window_property("TMDbHelper.ListItem.TVShowTitle", "TMDbHelper.ListItem.ShowTitle", "TMDbHelper.ListItem.tvshowtitle"),
        "season": _any_window_property("TMDbHelper.ListItem.Season", "TMDbHelper.ListItem.season"),
        "episode": _any_window_property("TMDbHelper.ListItem.Episode", "TMDbHelper.ListItem.episode"),
        "year": _any_window_property("TMDbHelper.ListItem.Year", "TMDbHelper.ListItem.year", "TMDbHelper.ListItem.ReleaseYear"),
        "imdbnumber": imdb,
        "tmdb_id": tmdb,
        "top250": _any_window_property("TMDbHelper.ListItem.Top250"),
    }

def container_item(container_id: int, offset: int = 0) -> Dict[str, Any]:
    def li(field: str) -> str:
        expression = "Container({0}).ListItem.{1}".format(container_id, field) if offset == 0 else "Container({0}).ListItem({1}).{2}".format(container_id, offset, field)
        try:
            return xbmc.getInfoLabel(expression).strip()
        except Exception:  # pylint: disable=broad-except
            return ""

    raw_type = li("DBTYPE") or li("DBType") or li("Property(DBType)") or li("Property(dbtype)") or li("Property(type)")
    title = li("Title") or li("Label") or li("Property(title)")
    showtitle = li("TVShowTitle") or li("ShowTitle") or li("Property(tvshowtitle)") or li("Property(showtitle)") or li("Property(tv_show_title)")
    season = li("Season") or li("Property(season)") or li("Property(tvshow.season)")
    episode = li("Episode") or li("Property(episode)") or li("Property(tvshow.episode)")
    file_path = li("FilenameAndPath") or li("FileNameAndPath") or li("FileName") or li("Path") or li("FolderPath")
    parsed = _parse_videodb_identity(file_path)
    item = {
        "type": _infer_video_type(raw_type, title, showtitle, season, episode),
        "dbid": li("DBID") or li("DBId") or li("Property(dbid)") or li("Property(DBID)"),
        "title": title,
        "showtitle": showtitle,
        "season": season,
        "episode": episode,
        "year": li("Year") or li("Property(year)"),
        "imdbnumber": li("IMDBNumber") or li("IMDbNumber") or li("UniqueID(imdb)") or li("Property(imdb_id)") or li("Property(imdb)"),
        "tmdb_id": li("UniqueID(tmdb)") or li("Property(tmdb_id)") or li("Property(tmdbid)") or li("Property(tmdb)"),
        "top250": li("Top250"),
        "file": file_path,
    }
    if parsed:
        item.update({k: v for k, v in parsed.items() if v not in (None, "")})
    return item


def hub_primary_item() -> Dict[str, Any]:
    if not xbmc.getCondVisibility("Window.IsActive(1102)"):
        return {}
    for container_id in (503, 504, 502, 601, 602, 603, 500):
        item = container_item(container_id, 0)
        if valid_library_item(item):
            item["_fallback_container"] = str(container_id)
            return item
    return {}


def screensaver_item(offset: int = 0) -> Dict[str, Any]:
    return container_item(1297, offset)


def valid_library_item(item: Dict[str, Any]) -> bool:
    kind = str(item.get("type") or "")
    has_identity = (
        safe_int(item.get("dbid")) is not None
        or bool(str(item.get("title") or "").strip())
        or bool(_norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb")))
        or bool(_norm_tmdb(item.get("tmdb_id") or item.get("tmdb")))
    )
    # Empty kind is allowed for AF3 hub/spotlight fallbacks where the focused
    # control is a button but title/year/IMDb/TMDb ID are still available
    # through properties.
    return has_identity and (kind in ("", "movie", "tvshow", "episode"))


def resolvable_library_item(item: Dict[str, Any]) -> bool:
    return str(item.get("type") or "") in ("movie", "tvshow", "episode") and safe_int(item.get("dbid")) is not None


def enabled_rating_logicals(media_type: Any) -> set:
    media_type = media_setting_type(media_type)
    logicals = set()
    for logical in RATING_LOGICALS_BY_TYPE.get(media_type, set()):
        if logical == "top250":
            continue
        if rating_enabled(media_type, logical, True):
            logicals.add(logical)
    return logicals


def record_missing_logicals(media_type: Any, record: Dict[str, Any]) -> set:
    media_type = media_setting_type(media_type)
    wanted = enabled_rating_logicals(media_type)
    if not wanted:
        return set()
    ratings = filter_ratings_for_item(media_type, (record or {}).get("ratings") or {})
    present = set()
    for key, row in ratings.items():
        logical = logical_for_rating_source(key) or key
        if logical in wanted and isinstance(row, dict):
            if is_no_rating_marker(row):
                present.add(logical)
            elif safe_float(row.get("score")) is not None or safe_float(row.get("value")) is not None:
                present.add(logical)
    return wanted - present


def record_missing_series_status(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if item.get("type") != "tvshow" or not bool_setting("scrape_tv_status", True):
        return False
    series = (record or {}).get("series") or {}
    if not isinstance(series, dict):
        return True
    return not bool(str(series.get("status") or "").strip())


def record_missing_awards(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    return _awards_needs_fill((record or {}).get("awards") or {}, item.get("type"))


def record_needs_update(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if not record:
        return True
    # Manual-only mode: missing-only checks missing fields, not cache age.
    if bool_setting("refresh_expired_cache", False) and not fresh(record):
        return True
    if record_missing_logicals(item.get("type"), record):
        return True
    if record_missing_series_status(item, record):
        return True
    if record_missing_awards(item, record):
        return True
    return False


def stale_or_missing_items(cache: Dict[str, Any], include_missing: bool = True) -> List[Dict[str, Any]]:
    records = cache.get("items") or {}
    items = library_items()
    result: List[Dict[str, Any]] = []
    for item in items:
        row = records.get(item_key(item)) or {}
        if (include_missing and not row) or (row and record_needs_update(item, row)):
            result.append(item)
    return result


# -----------------------------------------------------------------------------
# v1.3.40 SQLite cache schema override
# -----------------------------------------------------------------------------
# Older 1.3.39 used a long `ratings(item_key, logical, value...)` table and a
# separate `top250_movie` table. The user wants a compact TMDbHelper-style DB:
# one item row, one wide ratings row, and Top 250 rank stored on the item itself
# / metadata only (no extra top250_movie table).

RATING_WIDE_COLUMNS = {
    "imdb": "imdb",
    "tmdb": "tmdb",
    "rt_critic": "rt_critic",
    "rt_audience": "rt_audience",
    "metacritic": "metacritic",
    "trakt": "trakt",
    "letterboxd": "letterboxd",
    "mdblist": "mdblist",
}


def _rating_image(logical: str, value: Any) -> str:
    number = safe_int(value)
    if logical == "rt_critic":
        return "rtfresh.png" if number is None or number >= 60 else "rtrotten.png"
    if logical == "rt_audience":
        return "popcorn.png" if number is None or number >= 60 else "popcorn_spilt.png"
    return ""






def _item_row_to_entry_base(row: sqlite3.Row) -> Dict[str, Any]:
    ids: Dict[str, str] = {}
    for key in ("imdb", "tmdb", "tvdb", "show_tmdb"):
        try:
            value = row[key]
        except Exception:
            value = ""
        if value not in (None, ""):
            ids[key] = str(value)
    entry: Dict[str, Any] = {
        "type": str(row["media_type"] or ""),
        "dbid": int(row["dbid"] or 0),
        "title": str(row["title"] or ""),
        "updated_at": str(row["updated_at"] or ""),
        "timestamp": int(row["timestamp"] or 0),
        "ids": ids,
        "ratings": {},
        "errors": [],
        "provider_meta": {},
    }
    if row["showtitle"]:
        entry["showtitle"] = str(row["showtitle"])
    if row["season"] is not None:
        entry["season"] = int(row["season"])
    if row["episode"] is not None:
        entry["episode"] = int(row["episode"])
    if row["year"] not in (None, ""):
        entry["year"] = str(row["year"])
    entry["imdb_top250_rank"] = safe_int(row["imdb_top250_rank"]) or 0
    series: Dict[str, Any] = {}
    if row["series_status"]:
        series["status"] = str(row["series_status"])
    if row["series_status_date"]:
        series["status_date"] = str(row["series_status_date"])
    if series:
        entry["series"] = series
    awards: Dict[str, Any] = {}
    if row["oscar_wins"] is not None:
        awards["oscar_wins"] = int(row["oscar_wins"])
    if row["emmy_wins"] is not None:
        awards["emmy_wins"] = int(row["emmy_wins"])
    if awards:
        entry["awards"] = awards
    return entry


def _rating_from_wide(row: sqlite3.Row, logical: str) -> Dict[str, Any]:
    prefix = RATING_WIDE_COLUMNS.get(logical, logical)
    keys = row.keys()
    if prefix not in keys:
        return {}
    no_rating = bool(row["{0}_no_rating".format(prefix)] if "{0}_no_rating".format(prefix) in keys else 0)
    value = row[prefix]
    if not no_rating and value in (None, ""):
        return {}
    score_key = "{0}_score".format(prefix)
    score_value = row[score_key] if score_key in keys else None
    restored_value = _restore_db_value(value)
    restored_score = "" if score_value in (None, "") else _restore_db_value(score_value)
    if restored_score == "" and not no_rating:
        number = safe_float(restored_value)
        if number is not None:
            if logical in ("imdb", "tmdb", "trakt", "letterboxd") and number <= 10:
                restored_score = number * 10
            else:
                restored_score = number
    rating: Dict[str, Any] = {
        "cache_key": logical,
        "logical": logical,
        "provider": str(row["{0}_provider".format(prefix)] or "") if "{0}_provider".format(prefix) in keys else "",
        "source": str(row["{0}_source".format(prefix)] or logical) if "{0}_source".format(prefix) in keys else logical,
        "value": NO_RATING_VALUE if no_rating else restored_value,
        "score": "" if no_rating else restored_score,
        "votes": "" if "{0}_votes".format(prefix) not in keys or row["{0}_votes".format(prefix)] is None else int(row["{0}_votes".format(prefix)]),
    }
    if no_rating:
        rating["no_rating"] = True
    return rating


def _wide_row_to_ratings(row: Optional[sqlite3.Row]) -> Dict[str, Dict[str, Any]]:
    if row is None:
        return {}
    ratings: Dict[str, Dict[str, Any]] = {}
    for logical in RATING_WIDE_COLUMNS:
        rating = _rating_from_wide(row, logical)
        if rating:
            ratings[logical] = rating
    return ratings


def _rating_value_for_db(rating: Dict[str, Any]) -> str:
    if not isinstance(rating, dict):
        return ""
    if rating.get("no_rating"):
        return NO_RATING_VALUE
    value = rating.get("value")
    if value in (None, ""):
        value = rating.get("score")
    return _db_value(value)


def _db_rating_row_values(item_key: str, ratings: Dict[str, Any], updated_at: str) -> Tuple[Any, ...]:
    values: List[Any] = [str(item_key)]
    for logical in ("imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist"):
        rating = ratings.get(logical) or {}
        if not isinstance(rating, dict):
            rating = {}
        prefix = RATING_WIDE_COLUMNS[logical]
        value = _rating_value_for_db(rating)
        no_rating = 1 if rating.get("no_rating") else 0
        values.extend([
            value,
            _db_float(rating.get("score")),
            str(rating.get("provider") or ""),
            str(rating.get("source") or logical),
            _db_int(rating.get("votes")),
            no_rating,
        ])
        if logical == "rt_critic":
            image = _rating_image(logical, value)
            values.extend([image, image])
        elif logical == "rt_audience":
            image = _rating_image(logical, value)
            values.extend([image, image])
    values.append(str(updated_at or ""))
    return tuple(values)


def _db_upsert_entry(conn: sqlite3.Connection, item_key: str, entry: Dict[str, Any]) -> None:
    if not isinstance(entry, dict):
        return
    conn.execute(
        """
        INSERT OR REPLACE INTO items(
            item_key, media_type, dbid, title, showtitle, season, episode, year,
            imdb, tmdb, tvdb, show_tmdb, imdb_top250_rank,
            series_status, series_status_date, oscar_wins, emmy_wins,
            updated_at, timestamp
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (str(item_key),) + _normal_item_values(entry),
    )
    ratings = filter_ratings_for_item(entry.get("type"), entry.get("ratings") or {})
    columns = [
        "item_key",
        "imdb", "imdb_score", "imdb_provider", "imdb_source", "imdb_votes", "imdb_no_rating",
        "tmdb", "tmdb_score", "tmdb_provider", "tmdb_source", "tmdb_votes", "tmdb_no_rating",
        "rt_critic", "rt_critic_score", "rt_critic_provider", "rt_critic_source", "rt_critic_votes", "rt_critic_no_rating", "rt_critic_image", "rotten_tomatoes_image",
        "rt_audience", "rt_audience_score", "rt_audience_provider", "rt_audience_source", "rt_audience_votes", "rt_audience_no_rating", "rt_audience_image", "rotten_tomatoes_audience_image",
        "metacritic", "metacritic_score", "metacritic_provider", "metacritic_source", "metacritic_votes", "metacritic_no_rating",
        "trakt", "trakt_score", "trakt_provider", "trakt_source", "trakt_votes", "trakt_no_rating",
        "letterboxd", "letterboxd_score", "letterboxd_provider", "letterboxd_source", "letterboxd_votes", "letterboxd_no_rating",
        "mdblist", "mdblist_score", "mdblist_provider", "mdblist_source", "mdblist_votes", "mdblist_no_rating",
        "updated_at",
    ]
    placeholders = ",".join("?" for _ in columns)
    sql = "INSERT OR REPLACE INTO ratings({0}) VALUES({1})".format(",".join(columns), placeholders)
    conn.execute(sql, _db_rating_row_values(str(item_key), ratings, str(entry.get("updated_at") or now_iso())))







# -----------------------------------------------------------------------------
# v1.3.42 TMDbHelper-style simple wide ratings SQLite schema override
# -----------------------------------------------------------------------------
# User-facing cache DB should be readable: one item row + one ratings row, only
# values and TMDbHelper-style RT image tokens. No provider/source/votes/cache_key/logical/score/
# no_rating columns. Internal cache objects are reconstructed on load.

SIMPLE_RATING_LOGICALS = ("imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist")
SIMPLE_RATING_COLUMNS = ["item_key", "imdb", "tmdb", "rottentomatoes", "rottentomatoes_image", "rottentomatoes_user", "rottentomatoes_userimage", "metacritic", "trakt", "letterboxd", "mdblist", "updated_at"]
OLD_SIMPLE_RATING_COLUMNS = ["item_key", "imdb", "tmdb", "rt_critic", "rt_critic_image", "rt_audience", "rt_audience_image", "metacritic", "trakt", "letterboxd", "mdblist", "updated_at"]


def _one_decimal(value: Any) -> str:
    number = safe_float(value)
    if number is None:
        return ""
    return "{0:.1f}".format(number)


def _whole_percent(value: Any) -> str:
    number = safe_float(value)
    if number is None:
        return ""
    return str(int(round(number)))


def _rating_display_number(logical: str, rating: Dict[str, Any]) -> Any:
    if not isinstance(rating, dict):
        return None
    if rating.get("no_rating"):
        return NO_RATING_VALUE
    value = safe_float(rating.get("value"))
    score = safe_float(rating.get("score"))
    # Prefer visible provider value. If only normalized score exists, convert
    # back to the correct display scale per rating family.
    if value is not None:
        number = value
    elif score is not None:
        number = score / 10.0 if logical in ("imdb", "tmdb", "trakt", "letterboxd") and score > 10 else score
    else:
        return ""
    if number <= 0:
        return NO_RATING_VALUE
    return number


def _rating_cell_for_db(logical: str, rating: Dict[str, Any]) -> str:
    number = _rating_display_number(logical, rating)
    if number == NO_RATING_VALUE:
        return NO_RATING_VALUE
    if logical in ("rt_critic", "rt_audience", "metacritic", "mdblist"):
        formatted = _whole_percent(number)
    else:
        formatted = _one_decimal(number)
    return NO_RATING_VALUE if formatted in ("0", "0.0", "-0", "-0.0") else formatted


def rt_critic_image_token(value: Any) -> str:
    number = safe_float(value)
    if number is None or number <= 0:
        return ""
    if number >= 75:
        return "certified"
    if number >= 60:
        return "fresh"
    return "rotten"


def rt_audience_image_token(value: Any) -> str:
    number = safe_float(value)
    if number is None or number <= 0:
        return ""
    return "upright" if number >= 60 else "spilled"


def _simple_rating_image(logical: str, cell: str) -> str:
    if logical == "rt_critic":
        return rt_critic_image_token(cell)
    if logical == "rt_audience":
        return rt_audience_image_token(cell)
    return ""


def _simple_rating_schema_sql() -> str:
    return """
        CREATE TABLE IF NOT EXISTS ratings (
            item_key TEXT PRIMARY KEY,
            media_type TEXT,
            title TEXT,
            showtitle TEXT,
            season INTEGER,
            episode INTEGER,
            year TEXT,
            imdb_id TEXT,
            tmdb_id TEXT,
            imdb TEXT,
            tmdb TEXT,
            rottentomatoes TEXT,
            rottentomatoes_image TEXT,
            rottentomatoes_user TEXT,
            rottentomatoes_userimage TEXT,
            metacritic TEXT,
            trakt TEXT,
            letterboxd TEXT,
            mdblist TEXT,
            updated_at TEXT
        )
    """


def _sqlite_table_exists(conn: sqlite3.Connection, table: str) -> bool:
    try:
        row = conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
        return row is not None
    except sqlite3.Error:
        return False


def _sqlite_table_count(conn: sqlite3.Connection, table: str) -> int:
    try:
        if not _sqlite_table_exists(conn, table):
            return 0
        return int(conn.execute("SELECT COUNT(*) FROM {0}".format(table)).fetchone()[0] or 0)
    except sqlite3.Error:
        return 0






def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    ratings = entry.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    metadata = (
        str(item_key),
        str(entry.get("type") or ""),
        str(entry.get("title") or ""),
        str(entry.get("showtitle") or ""),
        safe_int(entry.get("season")),
        safe_int(entry.get("episode")),
        str(entry.get("year") or ""),
        str(entry.get("imdb") or entry.get("imdbnumber") or ""),
        str(entry.get("tmdb") or entry.get("tmdb_id") or ""),
    )
    return metadata + (
        _simple_rating_cell(ratings.get("imdb") or ratings.get("imdb_score")),
        _simple_rating_cell(ratings.get("tmdb") or ratings.get("tmdb_score")),
        _simple_rating_cell(ratings.get("rt_critic") or ratings.get("rottentomatoes")),
        _simple_rating_image("rt_critic", _simple_rating_cell(ratings.get("rt_critic") or ratings.get("rottentomatoes"))),
        _simple_rating_cell(ratings.get("rt_audience") or ratings.get("rottentomatoes_user")),
        _simple_rating_image("rt_audience", _simple_rating_cell(ratings.get("rt_audience") or ratings.get("rottentomatoes_user"))),
        _simple_rating_cell(ratings.get("metacritic")),
        _simple_rating_cell(ratings.get("trakt")),
        _simple_rating_cell(ratings.get("letterboxd")),
        _simple_rating_cell(ratings.get("mdblist")),
        str(entry.get("updated_at") or now_iso()),
    )


def _db_upsert_entry(conn: sqlite3.Connection, item_key: str, entry: Dict[str, Any]) -> None:
    if not isinstance(entry, dict):
        return
    conn.execute(
        """
        INSERT OR REPLACE INTO items(
            item_key, media_type, dbid, title, showtitle, season, episode, year,
            imdb, tmdb, tvdb, show_tmdb, imdb_top250_rank,
            series_status, series_status_date, oscar_wins, emmy_wins,
            updated_at, timestamp
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (str(item_key),) + _normal_item_values(entry),
    )
    conn.execute(
        """
        INSERT OR REPLACE INTO ratings(
            item_key, media_type, title, showtitle, season, episode, year, imdb_id, tmdb_id,
            imdb, tmdb, rottentomatoes, rottentomatoes_image,
            rottentomatoes_user, rottentomatoes_userimage, metacritic,
            trakt, letterboxd, mdblist, updated_at
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        _simple_db_rating_values(entry, str(item_key)),
    )


def _simple_rating_from_cell(logical: str, cell: Any) -> Dict[str, Any]:
    text = str(cell or "").strip()
    if not text:
        return {}
    if text.upper() == NO_RATING_VALUE:
        return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
    number = safe_float(text.replace("%", ""))
    if number is None or number <= 0:
        return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
    score = number * 10 if logical in ("imdb", "tmdb", "trakt", "letterboxd") and number <= 10 else number
    return {"cache_key": logical, "logical": logical, "provider": logical, "source": logical, "value": number, "score": score, "votes": ""}


def _row_value(row: sqlite3.Row, *cols: str) -> Any:
    keys = set(row.keys())
    for col in cols:
        if col in keys:
            return row[col]
    return ""


def _simple_row_to_ratings(row: Optional[sqlite3.Row]) -> Dict[str, Dict[str, Any]]:
    if row is None:
        return {}
    column_map = {
        "imdb": ("imdb",),
        "tmdb": ("tmdb",),
        "rt_critic": ("rottentomatoes", "rt_critic"),
        "rt_audience": ("rottentomatoes_user", "rt_audience"),
        "metacritic": ("metacritic",),
        "trakt": ("trakt",),
        "letterboxd": ("letterboxd",),
        "mdblist": ("mdblist",),
    }
    ratings: Dict[str, Dict[str, Any]] = {}
    for logical, cols in column_map.items():
        rating = _simple_rating_from_cell(logical, _row_value(row, *cols))
        if rating:
            ratings[logical] = rating
    return ratings



def cache_db_mtime() -> float:
    try:
        return os.path.getmtime(CACHE_DB_FILE)
    except OSError:
        return 0.0



def _sqlite_connect() -> sqlite3.Connection:
    os.makedirs(PROFILE, exist_ok=True)
    conn = sqlite3.connect(CACHE_DB_FILE, timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=30000")
    except sqlite3.Error:
        pass
    _ensure_current_cache_schema(conn)
    # CREATE/PRAGMA can leave the connection inside an implicit transaction on
    # some SQLite builds. Commit before save_cache starts its explicit write.
    try:
        conn.commit()
    except sqlite3.Error:
        pass
    return conn




# -----------------------------------------------------------------------------
# v1.3.56 final overrides: clean ratings table, WIB, key rotation
# -----------------------------------------------------------------------------
# Remove user-hidden/unused rating families from normal scrape/cache decisions.
RATING_LOGICALS_BY_TYPE["movie"] = {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "top250"}
RATING_LOGICALS_BY_TYPE["tvshow"] = {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "top250"}
RATING_LOGICALS_BY_TYPE["episode"] = {"imdb", "tmdb"}
MDBLIST_PROVIDER_LOGICALS = {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt"}
MDBLIST_LOGICALS = {"imdb", "rt_critic", "rt_audience", "metacritic", "trakt"}

FINAL_RATINGS_COLUMNS = [
    "item_key", "title", "imdb", "tmdb", "rottentomatoes", "rottentomatoes_image",
    "rottentomatoes_user", "rottentomatoes_userimage", "metacritic", "trakt", "top250",
    "media_type", "showtitle", "season", "episode", "year", "series_status", "series_status_date",
    "oscar_wins", "emmy_wins", "imdb_id", "tmdb_id", "dbid", "updated_at", "timestamp",
]
SIMPLE_RATING_COLUMNS = FINAL_RATINGS_COLUMNS
SIMPLE_RATING_LOGICALS = ("imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt")


def _provider_key_list(provider_value: Any) -> List[str]:
    if isinstance(provider_value, dict):
        raw = provider_value.get("keys") or []
    elif isinstance(provider_value, (list, tuple)):
        raw = provider_value
    else:
        raw = [provider_value]
    out: List[str] = []
    for value in raw:
        value = str(value or "").strip()
        if value and value not in out:
            out.append(value)
    return out


def _provider_key_is_limited(provider_value: Any, index: int) -> bool:
    return isinstance(provider_value, dict) and bool((provider_value.get("limited") or {}).get(str(index)))


def _provider_mark_limited(provider_value: Any, index: int) -> None:
    if isinstance(provider_value, dict):
        provider_value.setdefault("limited", {})[str(index)] = True


_mdblist_lookup_single_1356 = mdblist_lookup


def mdblist_lookup(ids: Dict[str, str], media_type: str, key: Any) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    keys = _provider_key_list(key)
    if not keys:
        return {}, {}
    all_attempts: List[Dict[str, Any]] = []
    limit_messages: List[str] = []
    for index, current_key in enumerate(keys):
        if _provider_key_is_limited(key, index):
            continue
        found, meta = _mdblist_lookup_single_1356(ids, media_type, current_key)
        meta = dict(meta or {})
        meta["key_index"] = index + 1
        attempts = meta.get("attempts") or []
        for attempt in attempts:
            if isinstance(attempt, dict):
                attempt.setdefault("key_index", index + 1)
        all_attempts.extend(attempts)
        if meta.get("limited"):
            _provider_mark_limited(key, index)
            if meta.get("limit_message"):
                limit_messages.append(str(meta.get("limit_message")))
            continue
        meta["attempts"] = all_attempts or attempts
        return found, meta
    return {}, {
        "limited": True,
        "all_keys_limited": True,
        "limit_provider": "MDBList",
        "limit_message": "; ".join(limit_messages) or "All MDBList API keys reached limit",
        "attempts": all_attempts,
    }


_omdb_lookup_single_1356 = omdb_lookup


def omdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: Any) -> Tuple[Dict[str, Any], Dict[str, str], Dict[str, Any]]:
    keys = _provider_key_list(key)
    if not keys:
        return {}, ids, {"attempts": []}
    all_attempts: List[Dict[str, Any]] = []
    limit_messages: List[str] = []
    updated_ids = dict(ids)
    for index, current_key in enumerate(keys):
        if _provider_key_is_limited(key, index):
            continue
        try:
            found, updated_ids, meta = _omdb_lookup_single_1356(item, updated_ids, current_key)
            meta = dict(meta or {})
            meta["key_index"] = index + 1
            attempts = meta.get("attempts") or []
            for attempt in attempts:
                if isinstance(attempt, dict):
                    attempt.setdefault("key_index", index + 1)
            meta["attempts"] = all_attempts + attempts
            return found, updated_ids, meta
        except ProviderLimitReached as exc:
            _provider_mark_limited(key, index)
            limit_messages.append(str(exc))
            all_attempts.append({"key_index": index + 1, "error": str(exc), "limited": True})
            continue
    raise ProviderLimitReached("OMDb", "; ".join(limit_messages) or "All OMDb API keys reached limit")


def _display_number_for_db(logical: str, rating: Any) -> str:
    if not isinstance(rating, dict):
        return ""
    number = _rating_display_number(logical, rating)
    if number == NO_RATING_VALUE:
        return NO_RATING_VALUE
    if logical in ("rt_critic", "rt_audience", "metacritic"):
        formatted = _whole_percent(number)
    else:
        formatted = _one_decimal(number)
    return NO_RATING_VALUE if formatted in ("0", "0.0", "-0", "-0.0") else formatted


def _simple_rating_schema_sql() -> str:
    return """
        CREATE TABLE IF NOT EXISTS ratings (
            item_key TEXT PRIMARY KEY,
            title TEXT,
            imdb TEXT,
            tmdb TEXT,
            rottentomatoes TEXT,
            rottentomatoes_image TEXT,
            rottentomatoes_user TEXT,
            rottentomatoes_userimage TEXT,
            metacritic TEXT,
            trakt TEXT,
            top250 INTEGER,
            media_type TEXT,
            showtitle TEXT,
            season INTEGER,
            episode INTEGER,
            year TEXT,
            series_status TEXT,
            series_status_date TEXT,
            oscar_wins INTEGER,
            emmy_wins INTEGER,
            imdb_id TEXT,
            tmdb_id TEXT,
            dbid INTEGER,
            updated_at TEXT,
            timestamp INTEGER
        )
    """


def _table_columns_order(conn: sqlite3.Connection, table: str) -> List[str]:
    try:
        return [str(row[1]) for row in conn.execute("PRAGMA table_info({0})".format(table)).fetchall()]
    except sqlite3.Error:
        return []


def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    ratings = entry.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ids = entry.get("ids") or {}
    series = entry.get("series") or {}
    awards = entry.get("awards") or {}
    rt_critic_cell = _display_number_for_db("rt_critic", ratings.get("rt_critic") or ratings.get("rottentomatoes") or {})
    rt_audience_cell = _display_number_for_db("rt_audience", ratings.get("rt_audience") or ratings.get("rottentomatoes_user") or {})
    return (
        str(item_key),
        str(entry.get("title") or ""),
        _display_number_for_db("imdb", ratings.get("imdb") or {}),
        _display_number_for_db("tmdb", ratings.get("tmdb") or {}),
        rt_critic_cell,
        _simple_rating_image("rt_critic", rt_critic_cell),
        rt_audience_cell,
        _simple_rating_image("rt_audience", rt_audience_cell),
        _display_number_for_db("metacritic", ratings.get("metacritic") or {}),
        _display_number_for_db("trakt", ratings.get("trakt") or {}),
        safe_int(entry.get("imdb_top250_rank")) or 0,
        str(entry.get("type") or ""),
        str(entry.get("showtitle") or ""),
        safe_int(entry.get("season")),
        safe_int(entry.get("episode")),
        str(entry.get("year") or ""),
        str(series.get("status") or entry.get("series_status") or ""),
        str(series.get("status_date") or entry.get("series_status_date") or ""),
        safe_int(awards.get("oscar_wins") or entry.get("oscar_wins")) or 0,
        safe_int(awards.get("emmy_wins") or entry.get("emmy_wins")) or 0,
        str(ids.get("imdb") or entry.get("imdb") or entry.get("imdbnumber") or ""),
        str(ids.get("tmdb") or entry.get("tmdb") or entry.get("tmdb_id") or ""),
        safe_int(entry.get("dbid")),
        str(entry.get("updated_at") or now_iso()),
        safe_int(entry.get("timestamp")) or int(time.time()),
    )


def _db_upsert_entry(conn: sqlite3.Connection, item_key: str, entry: Dict[str, Any]) -> None:
    if not isinstance(entry, dict):
        return
    conn.execute(
        """
        INSERT OR REPLACE INTO items(
            item_key, media_type, dbid, title, showtitle, season, episode, year,
            imdb, tmdb, tvdb, show_tmdb, imdb_top250_rank,
            series_status, series_status_date, oscar_wins, emmy_wins,
            updated_at, timestamp
        ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
        """,
        (str(item_key),) + _normal_item_values(entry),
    )
    conn.execute("INSERT OR REPLACE INTO ratings({0}) VALUES({1})".format(
        ",".join(FINAL_RATINGS_COLUMNS), ",".join(["?"] * len(FINAL_RATINGS_COLUMNS))
    ), _simple_db_rating_values(entry, str(item_key)))


def _simple_row_to_ratings(row: Optional[sqlite3.Row]) -> Dict[str, Dict[str, Any]]:
    if row is None:
        return {}
    column_map = {
        "imdb": ("imdb",),
        "tmdb": ("tmdb",),
        "rt_critic": ("rottentomatoes", "rt_critic"),
        "rt_audience": ("rottentomatoes_user", "rt_audience"),
        "metacritic": ("metacritic",),
        "trakt": ("trakt",),
    }
    ratings: Dict[str, Dict[str, Any]] = {}
    for logical, cols in column_map.items():
        rating = _simple_rating_from_cell(logical, _row_value(row, *cols))
        if rating:
            ratings[logical] = rating
    return ratings



# -----------------------------------------------------------------------------
# v1.3.57 final overrides: ratings-only cache DB
# -----------------------------------------------------------------------------
# The ratings table now contains all user-facing identity columns, so the old
# items table is no longer needed. Internal cache objects are reconstructed from
# ratings only.

def _ratings_only_row_to_entry(row: sqlite3.Row) -> Dict[str, Any]:
    ids: Dict[str, str] = {}
    imdb_id = str(_row_value(row, "imdb_id") or "").strip()
    tmdb_id = str(_row_value(row, "tmdb_id") or "").strip()
    if imdb_id:
        ids["imdb"] = imdb_id
    if tmdb_id:
        ids["tmdb"] = tmdb_id
    entry: Dict[str, Any] = {
        "type": str(_row_value(row, "media_type") or ""),
        "dbid": safe_int(_row_value(row, "dbid")) or 0,
        "title": str(_row_value(row, "title") or ""),
        "updated_at": str(_row_value(row, "updated_at") or ""),
        "timestamp": safe_int(_row_value(row, "timestamp")) or 0,
        "ids": ids,
        "ratings": _simple_row_to_ratings(row),
        "imdb_top250_rank": safe_int(_row_value(row, "top250")) or 0,
    }
    showtitle = str(_row_value(row, "showtitle") or "")
    if showtitle:
        entry["showtitle"] = showtitle
    season = safe_int(_row_value(row, "season"))
    episode = safe_int(_row_value(row, "episode"))
    if season is not None:
        entry["season"] = season
    if episode is not None:
        entry["episode"] = episode
    year = str(_row_value(row, "year") or "")
    if year:
        entry["year"] = year
    series: Dict[str, Any] = {}
    status = str(_row_value(row, "series_status") or "")
    status_date = str(_row_value(row, "series_status_date") or "")
    if status:
        series["status"] = status
    if status_date:
        series["status_date"] = status_date
    if series:
        entry["series"] = series
    awards: Dict[str, Any] = {}
    oscar = safe_int(_row_value(row, "oscar_wins"))
    emmy = safe_int(_row_value(row, "emmy_wins"))
    if oscar is not None:
        awards["oscar_wins"] = oscar
    if emmy is not None:
        awards["emmy_wins"] = emmy
    if awards:
        entry["awards"] = awards
    return entry



def _db_upsert_entry(conn: sqlite3.Connection, item_key: str, entry: Dict[str, Any]) -> None:
    if not isinstance(entry, dict):
        return
    conn.execute("INSERT OR REPLACE INTO ratings({0}) VALUES({1})".format(
        ",".join(FINAL_RATINGS_COLUMNS), ",".join(["?"] * len(FINAL_RATINGS_COLUMNS))
    ), _simple_db_rating_values(entry, str(item_key)))


def load_cache() -> Dict[str, Any]:
    try:
        conn = _sqlite_connect()
        try:
            rows = conn.execute("SELECT * FROM ratings ORDER BY media_type, dbid, item_key").fetchall()
            items: Dict[str, Any] = {}
            for row in rows:
                key = str(_row_value(row, "item_key") or "")
                if not key:
                    continue
                items[key] = _ratings_only_row_to_entry(row)
            return {
                "version": safe_int(_db_get_meta(conn, "version")) or CACHE_VERSION,
                "updated_at": _db_get_meta(conn, "updated_at"),
                "backend": "sqlite-ratings-only",
                "items": items,
            }
        finally:
            conn.close()
    except sqlite3.Error as exc:
        log("SQLite cache load failed: {0}".format(exc), xbmc.LOGWARNING)
        return {"version": CACHE_VERSION, "updated_at": "", "backend": "sqlite-ratings-only", "items": {}}



# -----------------------------------------------------------------------------
# v1.3.58 final overrides: rating scale, N/A, episode fallback, key rotation
# -----------------------------------------------------------------------------
NO_RATING_VALUE = "N/A"
RATING_LOGICALS_BY_TYPE["movie"] = {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "top250"}
RATING_LOGICALS_BY_TYPE["tvshow"] = {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "top250"}
RATING_LOGICALS_BY_TYPE["episode"] = {"imdb", "tmdb"}
MDBLIST_PROVIDER_LOGICALS = {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt"}
MDBLIST_LOGICALS = {"imdb", "rt_critic", "rt_audience", "metacritic", "trakt"}


def normalized_rating(source: str, value: Any = None, score: Any = None, votes: Any = None, provider: str = "") -> Dict[str, Any]:
    clean = re.sub(r"[^a-z0-9]", "", str(source or "").lower())
    number = safe_float(value)
    normalized = safe_float(score)
    provider_clean = str(provider or "").lower()

    # MDBList mapping must use ratings[].value as the DB/display value:
    # imdb 6.6 -> 6.6; tmdb 64 -> 6.4; tomatoes/popcorn/metacritic/trakt stay 0-100.
    if provider_clean == "mdblist":
        if clean == "tmdb" and number is not None and number > 10:
            if normalized is None:
                normalized = number
            number = number / 10.0
        elif clean in ("imdb",):
            if normalized is None and number is not None:
                normalized = number * 10 if number <= 10 else number
        elif clean in ("tomatoes", "popcorn", "metacritic", "trakt"):
            if normalized is None and number is not None:
                normalized = number
        elif clean in ("metacriticuser", "letterboxd", "rogerebert", "myanimelist", "mdblist"):
            if normalized is None and number is not None:
                normalized = number * 10 if number <= 10 else number
    else:
        if normalized is None and number is not None:
            if clean in ("imdb", "tmdb", "letterboxd", "metacriticuser") and number <= 10:
                normalized = number * 10
            else:
                normalized = number
    return {"source": clean, "value": number, "score": normalized, "votes": safe_int(votes), "provider": provider}


def _rating_display_number(logical: str, rating: Dict[str, Any]) -> Any:
    if not isinstance(rating, dict):
        return None
    if rating.get("no_rating") or str(rating.get("value") or "").strip().upper() in ("N/A", "NO_RATING"):
        return NO_RATING_VALUE
    value = safe_float(rating.get("value"))
    score = safe_float(rating.get("score"))
    if value is not None:
        number = value
    elif score is not None:
        # Only IMDb/TMDb are 0-10 display fields. RT/Metacritic/Trakt stay 0-100.
        number = score / 10.0 if logical in ("imdb", "tmdb") and score > 10 else score
    else:
        return ""
    if number <= 0:
        return NO_RATING_VALUE
    return number


def _display_number_for_db(logical: str, rating: Any) -> str:
    if not isinstance(rating, dict):
        return ""
    number = _rating_display_number(logical, rating)
    if number == NO_RATING_VALUE:
        return NO_RATING_VALUE
    if logical in ("rt_critic", "rt_audience", "metacritic", "trakt"):
        formatted = _whole_percent(number)
    else:
        formatted = _one_decimal(number)
    return NO_RATING_VALUE if formatted in ("0", "0.0", "-0", "-0.0") else formatted


def rt_critic_image_token(value: Any) -> str:
    number = safe_float(value)
    if number is None or number <= 0:
        return ""
    # Do not invent certified-fresh without an explicit certified flag.
    return "fresh" if number >= 60 else "rotten"


def rt_audience_image_token(value: Any) -> str:
    number = safe_float(value)
    if number is None or number <= 0:
        return ""
    return "upright" if number >= 60 else "spilled"


def _simple_rating_from_cell(logical: str, cell: Any) -> Dict[str, Any]:
    text = str(cell or "").strip()
    if not text:
        return {}
    if text.upper() in ("N/A", "NO_RATING"):
        return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
    number = safe_float(text.replace("%", ""))
    if number is None or number <= 0:
        return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
    score = number * 10 if logical in ("imdb", "tmdb") and number <= 10 else number
    return {"cache_key": logical, "logical": logical, "provider": logical, "source": logical, "value": number, "score": score, "votes": ""}


def _simple_row_to_ratings(row: Optional[sqlite3.Row]) -> Dict[str, Dict[str, Any]]:
    if row is None:
        return {}
    column_map = {
        "imdb": ("imdb",),
        "tmdb": ("tmdb",),
        "rt_critic": ("rottentomatoes", "rt_critic"),
        "rt_audience": ("rottentomatoes_user", "rt_audience"),
        "metacritic": ("metacritic",),
        "trakt": ("trakt",),
    }
    ratings: Dict[str, Dict[str, Any]] = {}
    for logical, cols in column_map.items():
        rating = _simple_rating_from_cell(logical, _row_value(row, *cols))
        if rating:
            ratings[logical] = rating
    return ratings


def _rating_display_for_report(logical: str, rating: Dict[str, Any]) -> str:
    if not isinstance(rating, dict):
        return ""
    if is_no_rating_marker(rating):
        return NO_RATING_VALUE
    if logical in ("imdb", "tmdb"):
        return display_decimal(rating)
    if logical in ("rt_critic", "rt_audience", "metacritic", "trakt"):
        return display_percent(rating)
    return str(rating.get("value") or rating.get("score") or "")


def _all_attempts_key_unavailable(attempts: List[Dict[str, Any]]) -> bool:
    if not attempts:
        return False
    for attempt in attempts:
        status = safe_int(attempt.get("http_status"))
        error = str(attempt.get("error") or "").lower()
        if status in (401, 403) or "invalid api key" in error or "apikey" in error or "unauthorized" in error or "forbidden" in error:
            return True
    return False


def mdblist_lookup(ids: Dict[str, str], media_type: str, key: Any) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    keys = _provider_key_list(key)
    if not keys:
        return {}, {}
    all_attempts: List[Dict[str, Any]] = []
    limit_messages: List[str] = []
    for index, current_key in enumerate(keys):
        if _provider_key_is_limited(key, index):
            continue
        found, meta = _mdblist_lookup_single_1356(ids, media_type, current_key)
        meta = dict(meta or {})
        meta["key_index"] = index + 1
        attempts = meta.get("attempts") or []
        for attempt in attempts:
            if isinstance(attempt, dict):
                attempt.setdefault("key_index", index + 1)
        all_attempts.extend(attempts)
        if meta.get("limited") or _all_attempts_key_unavailable(attempts):
            _provider_mark_limited(key, index)
            if meta.get("limit_message"):
                limit_messages.append(str(meta.get("limit_message")))
            elif _all_attempts_key_unavailable(attempts):
                limit_messages.append("MDBList key {0} unavailable".format(index + 1))
            continue
        meta["attempts"] = all_attempts or attempts
        return found, meta
    return {}, {"limited": True, "all_keys_limited": True, "limit_provider": "MDBList", "limit_message": "; ".join(limit_messages) or "All MDBList API keys reached limit", "attempts": all_attempts}


def _omdb_parse_payload_1358(payload: Dict[str, Any], output: Dict[str, Any], updated_ids: Dict[str, str], include_awards: bool = True) -> None:
    if not payload or payload.get("__error") or str(payload.get("Response", "True")).lower() == "false":
        return
    if str(payload.get("imdbID") or "").lower().startswith("tt"):
        updated_ids.setdefault("imdb", str(payload["imdbID"]))
    if payload.get("imdbRating") not in (None, "", "N/A"):
        merge_rating(output, normalized_rating("imdb", payload.get("imdbRating"), None, None, "omdb"), overwrite=False)
    if payload.get("Metascore") not in (None, "", "N/A"):
        merge_rating(output, normalized_rating("metacritic", payload.get("Metascore"), None, None, "omdb"), overwrite=False)
    for row in payload.get("Ratings") or []:
        if not isinstance(row, dict):
            continue
        source, value = str(row.get("Source", "")).lower(), row.get("Value")
        if "rotten tomatoes" in source:
            merge_rating(output, normalized_rating("tomatoes", value, None, None, "omdb"), overwrite=False)
        elif "internet movie database" in source:
            merge_rating(output, normalized_rating("imdb", value, None, None, "omdb"), overwrite=False)
        elif "metacritic" in source:
            merge_rating(output, normalized_rating("metacritic", value, None, None, "omdb"), overwrite=False)
    if include_awards:
        awards = parse_awards_wins(payload.get("Awards"))
        if awards:
            output["__awards"] = awards


def _omdb_single_lookup_1358(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str], Dict[str, Any]]:
    meta: Dict[str, Any] = {"attempts": []}
    if not key:
        return {}, ids, meta
    base: Dict[str, Any] = {"apikey": key, "r": "json", "tomatoes": "true"}
    attempts: List[Dict[str, Any]] = []
    item_type = item.get("type")
    season = safe_int(item.get("season"))
    episode = safe_int(item.get("episode"))
    imdb_id = str(ids.get("imdb") or "").strip()
    show_ids = dict(item.get("show_ids") or {})
    series_imdb = str(show_ids.get("imdb") or item.get("series_imdb") or "").strip()

    if item_type == "episode":
        if imdb_id.lower().startswith("tt"):
            params = dict(base); params["i"] = imdb_id; attempts.append(params)
        if series_imdb.lower().startswith("tt") and season is not None and episode is not None:
            params = dict(base); params["i"] = series_imdb; params["Season"] = int(season); params["Episode"] = int(episode); attempts.append(params)
        if item.get("showtitle") and season is not None and episode is not None:
            params = dict(base); params["t"] = str(item["showtitle"]); params["Season"] = int(season); params["Episode"] = int(episode); attempts.append(params)
    else:
        if imdb_id.lower().startswith("tt"):
            params = dict(base); params["i"] = imdb_id; attempts.append(params)
        if not attempts:
            title = str(item.get("title") or "").strip()
            if not title:
                return {}, ids, meta
            params = dict(base); params["t"] = title
            year = safe_int(item.get("year"))
            if year:
                params["y"] = year
            params["type"] = "series" if item_type == "tvshow" else "movie"
            attempts.append(params)

    output: Dict[str, Any] = {}
    updated_ids = dict(ids)
    seen_urls = set()
    for params in attempts:
        for scheme in ("http", "https"):
            query = urlencode(params)
            url = "{0}://www.omdbapi.com/?{1}".format(scheme, query)
            if url in seen_urls:
                continue
            seen_urls.add(url)
            attempt_meta: Dict[str, Any] = {"params": _public_params(params), "scheme": scheme}
            payload: Dict[str, Any] = {}
            try:
                payload, _ = http_json(url)
                response = str(payload.get("Response", "True")) if isinstance(payload, dict) else ""
                attempt_meta.update({
                    "response": response,
                    "http_status": payload.get("__http_status") if isinstance(payload, dict) else "",
                    "raw_len": payload.get("__raw_len") if isinstance(payload, dict) else "",
                    "title": payload.get("Title") if isinstance(payload, dict) else "",
                    "type": payload.get("Type") if isinstance(payload, dict) else "",
                    "year": payload.get("Year") if isinstance(payload, dict) else "",
                    "imdbID": payload.get("imdbID") if isinstance(payload, dict) else "",
                    "error": (payload.get("Error") or payload.get("__error") or payload.get("__body") or "") if isinstance(payload, dict) else "",
                    "ratings": _compact_rating_sources(payload.get("Ratings") if isinstance(payload, dict) else []),
                    "imdbRating": payload.get("imdbRating") if isinstance(payload, dict) else "",
                    "Metascore": payload.get("Metascore") if isinstance(payload, dict) else "",
                    "Awards": payload.get("Awards") if isinstance(payload, dict) else "",
                })
                if is_provider_limit_payload("omdb", payload) or safe_int(payload.get("__http_status")) in (401, 403):
                    message = provider_limit_message("omdb", payload)
                    meta["attempts"].append(attempt_meta)
                    raise ProviderLimitReached("OMDb", message, payload.get("__retry_after") if isinstance(payload, dict) else "")
                _omdb_parse_payload_1358(payload, output, updated_ids)
                if _omdb_payload_has_data(payload):
                    meta["attempts"].append(attempt_meta)
                    meta["found_sources"] = [str(k) for k in output.keys()]
                    return output, updated_ids, compact_provider_meta({"omdb": meta}).get("omdb", meta)
            except ProviderLimitReached:
                raise
            except Exception as exc:  # pylint: disable=broad-except
                attempt_meta["error"] = str(exc)
            meta["attempts"].append(attempt_meta)
            # For episodes, keep falling through to series IMDb / title fallback if no data.
            if item_type != "episode" and (_omdb_payload_has_data(payload) or (isinstance(payload, dict) and str(payload.get("Response", "True")).lower() == "false" and payload.get("Error"))):
                break
    meta["found_sources"] = [str(k) for k in output.keys()]
    return output, updated_ids, meta


def omdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: Any) -> Tuple[Dict[str, Any], Dict[str, str], Dict[str, Any]]:
    keys = _provider_key_list(key)
    if not keys:
        return {}, ids, {"attempts": []}
    all_attempts: List[Dict[str, Any]] = []
    limit_messages: List[str] = []
    updated_ids = dict(ids)
    for index, current_key in enumerate(keys):
        if _provider_key_is_limited(key, index):
            continue
        try:
            found, updated_ids, meta = _omdb_single_lookup_1358(item, updated_ids, current_key)
            meta = dict(meta or {})
            meta["key_index"] = index + 1
            attempts = meta.get("attempts") or []
            for attempt in attempts:
                if isinstance(attempt, dict):
                    attempt.setdefault("key_index", index + 1)
            if _all_attempts_key_unavailable(attempts):
                _provider_mark_limited(key, index)
                limit_messages.append("OMDb key {0} unavailable".format(index + 1))
                all_attempts.extend(attempts)
                continue
            meta["attempts"] = all_attempts + attempts
            return found, updated_ids, meta
        except ProviderLimitReached as exc:
            _provider_mark_limited(key, index)
            limit_messages.append(str(exc))
            all_attempts.append({"key_index": index + 1, "error": str(exc), "limited": True})
            continue
    raise ProviderLimitReached("OMDb", "; ".join(limit_messages) or "All OMDb API keys reached limit")


def _tmdb_payload_has_error_157(payload: Any) -> bool:
    """True when a TMDb payload is a provider/transport error, not valid no-rating data."""
    if not isinstance(payload, dict) or not payload:
        return True
    status = safe_int(payload.get("__http_status"))
    if status is not None and status != 200:
        return True
    if payload.get("__error"):
        return True
    if payload.get("success") is False:
        return True
    if str(payload.get("Response", "")).lower() == "false":
        return True
    for key in ("status_message", "error", "Error", "message", "detail"):
        if str(payload.get(key) or "").strip():
            return True
    return False


def _tmdb_episode_payload_valid_157(payload: Any) -> bool:
    """Accept only a real TMDb episode detail payload as cacheable no-rating data."""
    if _tmdb_payload_has_error_157(payload):
        return False
    if payload.get("id") in (None, ""):
        return False
    # The episode detail endpoint always has episode-ish fields.  Requiring at
    # least one of these prevents an arbitrary/error dict from becoming N/A.
    return any(key in payload for key in ("name", "air_date", "episode_number", "season_number", "vote_average"))


def _tmdb_title_payload_valid_157(payload: Any) -> bool:
    """Accept only a real TMDb movie/show detail payload as cacheable no-rating data."""
    if _tmdb_payload_has_error_157(payload):
        return False
    if payload.get("id") in (None, ""):
        return False
    return any(key in payload for key in ("title", "name", "release_date", "first_air_date", "vote_average"))


def tmdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    if not key:
        return {}, ids
    output: Dict[str, Any] = {}
    updated_ids = dict(ids)
    media_type = item.get("type")
    payload: Dict[str, Any] = {}
    if media_type == "movie":
        tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, False)
        if tmdb_id:
            updated_ids.setdefault("tmdb", str(tmdb_id))
            payload = tmdb_get("movie/{0}".format(tmdb_id), key)
    elif media_type == "tvshow":
        tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, True)
        if tmdb_id:
            updated_ids.setdefault("tmdb", str(tmdb_id))
            payload = tmdb_get("tv/{0}".format(tmdb_id), key)
    elif media_type == "episode":
        show_ids = dict(item.get("show_ids") or {})
        show_tmdb = show_ids.get("tmdb") or updated_ids.get("show_tmdb") or tmdb_search({"type": "tvshow", "title": item.get("showtitle") or item.get("title")}, key, True)
        season, episode = safe_int(item.get("season")), safe_int(item.get("episode"))
        if show_tmdb and season is not None and episode is not None:
            payload = tmdb_get("tv/{0}/season/{1}/episode/{2}".format(show_tmdb, season, episode), key)
            if _tmdb_episode_payload_valid_157(payload):
                updated_ids.setdefault("show_tmdb", str(show_tmdb))
                if payload.get("id") not in (None, ""):
                    updated_ids.setdefault("tmdb", str(payload["id"]))
    if _tmdb_payload_has_error_157(payload):
        return output, updated_ids
    vote = payload.get("vote_average") if isinstance(payload, dict) else None
    vote_num = safe_float(vote)
    if vote_num is None or vote_num <= 0:
        if media_type == "episode" and _tmdb_episode_payload_valid_157(payload):
            output["tmdb"] = no_rating_row("tmdb", "tmdb_episode_vote_empty")
    else:
        merge_rating(output, normalized_rating("tmdb", vote_num, vote_num * 10, None, "tmdb"), overwrite=True)
    return output, updated_ids


# -----------------------------------------------------------------------------
# v1.3.60 final override: DB scale source of truth
# -----------------------------------------------------------------------------
# MDBList already returns tomatoes/popcorn/metacritic/trakt as 0-100 in both
# value and score. The bug in previous builds was that DB-writing preferred
# `value` blindly, so any earlier/old in-memory normalized value like 4/5/6 won
# over the correct 40/50/60 score. For 0-100 families, use score first.
PERCENT_100_LOGICALS = {"rt_critic", "rt_audience", "metacritic", "trakt"}
DECIMAL_10_LOGICALS = {"imdb", "tmdb"}


def _rating_display_number(logical: str, rating: Dict[str, Any]) -> Any:
    if not isinstance(rating, dict):
        return None
    if rating.get("no_rating") or str(rating.get("value") or "").strip().upper() in ("N/A", "NO_RATING"):
        return NO_RATING_VALUE
    value = safe_float(rating.get("value"))
    score = safe_float(rating.get("score"))

    if logical in PERCENT_100_LOGICALS:
        # RT/Metacritic/Trakt are stored/displayed 0-100. Score is the safest
        # provider-normalized 0-100 field; value is fallback only.
        if score is not None and score > 0:
            number = score
        elif value is not None:
            number = value
        else:
            return ""
    elif logical in DECIMAL_10_LOGICALS:
        # IMDb/TMDb are stored/displayed 0-10.
        if value is not None:
            number = value / 10.0 if value > 10 else value
        elif score is not None:
            number = score / 10.0 if score > 10 else score
        else:
            return ""
    else:
        number = value if value is not None else score
        if number is None:
            return ""

    if safe_float(number) is None or float(number) <= 0:
        return NO_RATING_VALUE
    return number


def _display_number_for_db(logical: str, rating: Any) -> str:
    if not isinstance(rating, dict):
        return ""
    number = _rating_display_number(logical, rating)
    if number == NO_RATING_VALUE:
        return NO_RATING_VALUE
    if logical in PERCENT_100_LOGICALS:
        formatted = _whole_percent(number)
    elif logical in DECIMAL_10_LOGICALS:
        formatted = _one_decimal(number)
    else:
        formatted = _one_decimal(number)
    return NO_RATING_VALUE if formatted in ("0", "0.0", "-0", "-0.0") else formatted


def display_decimal(rating: Dict[str, Any]) -> str:
    # Only used by IMDb/TMDb display aliases. Prefer canonical 0-10 value.
    if not isinstance(rating, dict):
        return ""
    logical = str(rating.get("logical") or rating.get("cache_key") or rating.get("source") or "")
    logical = logical_for_rating_source(logical) or logical
    number = _rating_display_number(logical if logical in DECIMAL_10_LOGICALS else "imdb", rating)
    if number in (None, "", NO_RATING_VALUE):
        return ""
    return _one_decimal(number)


def display_percent(rating: Dict[str, Any]) -> str:
    if not isinstance(rating, dict):
        return ""
    logical = str(rating.get("logical") or rating.get("cache_key") or rating.get("source") or "")
    logical = logical_for_rating_source(logical) or logical
    if logical not in PERCENT_100_LOGICALS:
        logical = "rt_critic"
    number = _rating_display_number(logical, rating)
    if number in (None, "", NO_RATING_VALUE):
        return ""
    return _whole_percent(number)


def display_rt_percent(rating: Dict[str, Any]) -> str:
    return display_percent(rating)


def _simple_rating_from_cell(logical: str, cell: Any) -> Dict[str, Any]:
    text = str(cell or "").strip()
    if not text:
        return {}
    if text.upper() in ("N/A", "NO_RATING"):
        return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
    number = safe_float(text.replace("%", ""))
    if number is None or number <= 0:
        return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
    if logical in PERCENT_100_LOGICALS:
        score = number
        value = number
    elif logical in DECIMAL_10_LOGICALS:
        value = number / 10.0 if number > 10 else number
        score = value * 10
    else:
        value = number
        score = number
    return {"cache_key": logical, "logical": logical, "provider": logical, "source": logical, "value": value, "score": score, "votes": ""}


def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    ratings = entry.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ids = entry.get("ids") or {}
    series = entry.get("series") or {}
    awards = entry.get("awards") or {}

    rt_critic_cell = _display_number_for_db("rt_critic", ratings.get("rt_critic") or ratings.get("rottentomatoes") or {})
    rt_audience_cell = _display_number_for_db("rt_audience", ratings.get("rt_audience") or ratings.get("rottentomatoes_user") or {})
    metacritic_cell = _display_number_for_db("metacritic", ratings.get("metacritic") or {})
    trakt_cell = _display_number_for_db("trakt", ratings.get("trakt") or {})
    return (
        str(item_key),
        str(entry.get("title") or ""),
        _display_number_for_db("imdb", ratings.get("imdb") or {}),
        _display_number_for_db("tmdb", ratings.get("tmdb") or {}),
        rt_critic_cell,
        _simple_rating_image("rt_critic", rt_critic_cell),
        rt_audience_cell,
        _simple_rating_image("rt_audience", rt_audience_cell),
        metacritic_cell,
        trakt_cell,
        safe_int(entry.get("imdb_top250_rank")) or 0,
        str(entry.get("type") or ""),
        str(entry.get("showtitle") or ""),
        safe_int(entry.get("season")),
        safe_int(entry.get("episode")),
        str(entry.get("year") or ""),
        str(series.get("status") or entry.get("series_status") or ""),
        str(series.get("status_date") or entry.get("series_status_date") or ""),
        safe_int(awards.get("oscar_wins") or entry.get("oscar_wins")) or 0,
        safe_int(awards.get("emmy_wins") or entry.get("emmy_wins")) or 0,
        str(ids.get("imdb") or entry.get("imdb") or entry.get("imdbnumber") or ""),
        str(ids.get("tmdb") or entry.get("tmdb") or entry.get("tmdb_id") or ""),
        safe_int(entry.get("dbid")),
        str(entry.get("updated_at") or now_iso()),
        safe_int(entry.get("timestamp")) or int(time.time()),
    )


# -----------------------------------------------------------------------------
# v1.3.61 final override: trace every rating before DB insert
# -----------------------------------------------------------------------------
SCALE_TRACE_FILE = os.path.join(PROFILE, "rating-scale-trace.log")


def reset_scale_trace_log() -> None:
    os.makedirs(PROFILE, exist_ok=True)
    try:
        with open(SCALE_TRACE_FILE, "w", encoding="utf-8") as fh:
            fh.write("Library Ratings Scraper rating-scale trace\n")
            fh.write("Started: {0}\n".format(now_iso()))
            fh.write("Addon: {0}\n\n".format(ADDON.getAddonInfo("version") or ""))
    except Exception as exc:  # pylint: disable=broad-except
        log("Unable to reset scale trace log: {0}".format(exc), xbmc.LOGWARNING)


def scale_trace(message: str) -> None:
    os.makedirs(PROFILE, exist_ok=True)
    try:
        with open(SCALE_TRACE_FILE, "a", encoding="utf-8") as fh:
            fh.write(str(message).rstrip() + "\n")
    except Exception as exc:  # pylint: disable=broad-except
        log("Unable to write scale trace log: {0}".format(exc), xbmc.LOGWARNING)


def _trace_rating_row_before_db(item_key: str, entry: Dict[str, Any], row: Dict[str, Any]) -> None:
    try:
        ratings = entry.get("ratings") or {}
        provider_meta = entry.get("provider_meta") or {}
        title = entry.get("title") or ""
        year = entry.get("year") or ""
        media_type = entry.get("type") or ""
        scale_trace("=" * 96)
        scale_trace("WRITE BEFORE DB | {0} | {1} | {2} ({3})".format(item_key, media_type, title, year))
        scale_trace("DB CELLS | imdb={imdb} tmdb={tmdb} rt={rottentomatoes} rt_user={rottentomatoes_user} meta={metacritic} trakt={trakt} top250={top250}".format(**row))
        for logical in ("imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt"):
            rating = ratings.get(logical) or ratings.get({"rt_critic":"rottentomatoes", "rt_audience":"rottentomatoes_user"}.get(logical, logical)) or {}
            if not isinstance(rating, dict) or not rating:
                scale_trace("RATING {0}: <empty>".format(logical))
                continue
            scale_trace("RATING {0}: provider={1} source={2} value={3} score={4} votes={5} no_rating={6}".format(
                logical,
                rating.get("provider"),
                rating.get("source"),
                rating.get("value"),
                rating.get("score"),
                rating.get("votes"),
                bool(rating.get("no_rating")),
            ))
        mdblist_meta = provider_meta.get("mdblist") if isinstance(provider_meta, dict) else None
        if isinstance(mdblist_meta, dict):
            attempts = mdblist_meta.get("attempts") or []
            for attempt in attempts[:8]:
                if isinstance(attempt, dict):
                    scale_trace("MDBLIST ATTEMPT key={0} provider={1} id={2} ratings={3} sources={4} error={5} http={6}".format(
                        attempt.get("key_index", ""), attempt.get("provider", ""), attempt.get("id", ""),
                        attempt.get("ratings", ""), attempt.get("sources", ""), attempt.get("error", ""), attempt.get("http_status", "")))
        scale_trace("")
    except Exception as exc:  # pylint: disable=broad-except
        log("Unable to trace rating row before DB insert: {0}".format(exc), xbmc.LOGWARNING)


def _db_upsert_entry(conn: sqlite3.Connection, item_key: str, entry: Dict[str, Any]) -> None:
    if not isinstance(entry, dict):
        return
    values = _simple_db_rating_values(entry, str(item_key))
    row = dict(zip(FINAL_RATINGS_COLUMNS, values))
    _trace_rating_row_before_db(str(item_key), entry, row)
    conn.execute("INSERT OR REPLACE INTO ratings({0}) VALUES({1})".format(
        ",".join(FINAL_RATINGS_COLUMNS), ",".join(["?"] * len(FINAL_RATINGS_COLUMNS))
    ), values)


# -----------------------------------------------------------------------------
# v1.3.62 final overrides: do not trust Kodi-local ratings for manual scrape
# -----------------------------------------------------------------------------
# Kodi stores RT/Metacritic/Trakt ratings on a 0-10 display scale. The LRS DB
# needs those families as 0-100. Manual scrape/refresh should use online providers
# only; service.py now calls resolve_item(..., include_local=False). This local
# normalizer is kept only as a defensive fallback for non-manual callers.


def _normalize_kodi_local_rating(source: str, value: Any, votes: Any = None) -> Dict[str, Any]:
    logical = logical_for_rating_source(source) or clean_rating_source(source)
    number = safe_float(value)
    if number is None:
        return normalized_rating(str(source), value, None, votes, "kodi")
    if logical in PERCENT_100_LOGICALS and number <= 10:
        return normalized_rating(str(source), number * 10.0, number * 10.0, votes, "kodi")
    if logical in DECIMAL_10_LOGICALS:
        return normalized_rating(str(source), number, number * 10.0 if number <= 10 else number, votes, "kodi")
    return normalized_rating(str(source), number, number, votes, "kodi")


def local_ratings(row: Dict[str, Any]) -> Dict[str, Any]:
    output: Dict[str, Any] = {}
    ratings = row.get("ratings") or {}
    if not isinstance(ratings, dict):
        return output
    for source, payload in ratings.items():
        if isinstance(payload, dict):
            rating = _normalize_kodi_local_rating(str(source), payload.get("rating"), None)
        else:
            rating = _normalize_kodi_local_rating(str(source), payload, None)
        merge_rating(output, rating)
    return output


def _attempt_has_key_auth_error(attempt: Dict[str, Any]) -> bool:
    # HTTP 401 by itself is not enough to mark an MDBList API key as globally
    # dead/limited. The user verified the same keys still work in a browser.
    # Only disable a key when provider text explicitly says the key is invalid.
    error = str(attempt.get("error") or "").lower()
    return "invalid api key" in error or "invalid apikey" in error or "apikey invalid" in error or "api key invalid" in error


def _all_attempts_key_unavailable(attempts: List[Dict[str, Any]]) -> bool:
    if not attempts:
        return False
    return any(_attempt_has_key_auth_error(attempt) for attempt in attempts if isinstance(attempt, dict))


def mdblist_lookup(ids: Dict[str, str], media_type: str, key: Any) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    keys = _provider_key_list(key)
    if not keys:
        return {}, {}
    all_attempts: List[Dict[str, Any]] = []
    limit_messages: List[str] = []
    auth_messages: List[str] = []
    for index, current_key in enumerate(keys):
        if _provider_key_is_limited(key, index):
            continue
        found, meta = _mdblist_lookup_single_1356(ids, media_type, current_key)
        meta = dict(meta or {})
        meta["key_index"] = index + 1
        attempts = meta.get("attempts") or []
        for attempt in attempts:
            if isinstance(attempt, dict):
                attempt.setdefault("key_index", index + 1)
        all_attempts.extend(attempts)
        if meta.get("limited"):
            _provider_mark_limited(key, index)
            if meta.get("limit_message"):
                limit_messages.append(str(meta.get("limit_message")))
            continue
        if _all_attempts_key_unavailable(attempts):
            _provider_mark_limited(key, index)
            auth_messages.append("MDBList key {0} invalid".format(index + 1))
            continue
        # HTTP 401/403 for one title/endpoint is treated as item/provider failure,
        # not as global daily limit. If found is empty, caller may continue to next
        # item without stopping the whole refresh.
        meta["attempts"] = all_attempts or attempts
        return found, meta
    if limit_messages:
        return {}, {
            "limited": True,
            "all_keys_limited": True,
            "limit_provider": "MDBList",
            "limit_message": "; ".join(limit_messages) or "All MDBList API keys reached limit",
            "attempts": all_attempts,
        }
    return {}, {
        "limited": False,
        "all_keys_auth_failed": bool(auth_messages),
        "limit_provider": "MDBList",
        "limit_message": "; ".join(auth_messages),
        "attempts": all_attempts,
    }


# -----------------------------------------------------------------------------
# v1.3.63 final overrides: strict provider flow + API key slot sanity
# -----------------------------------------------------------------------------
def _looks_like_omdb_key(value: str) -> bool:
    value = str(value or "").strip()
    return bool(re.match(r"^[A-Za-z0-9]{8}$", value))


def _looks_like_mdblist_key(value: str) -> bool:
    value = str(value or "").strip()
    return bool(re.match(r"^[A-Za-z0-9]{16,}$", value))


def api_keys() -> Dict[str, Any]:
    def _local_key(setting_id: str) -> str:
        try:
            return ADDON.getSetting(setting_id).strip()
        except Exception:  # pylint: disable=broad-except
            return ""

    def _chain(*values: str) -> List[str]:
        out: List[str] = []
        for value in values:
            value = str(value or "").strip()
            if value and value not in out:
                out.append(value)
        return out

    mdblist_keys = _chain(_local_key("mdblist_apikey"), _local_key("mdblist_apikey_2"))
    omdb_keys = _chain(_local_key("omdb_apikey"), _local_key("omdb_apikey_2"))
    tmdb_key = _local_key("tmdb_apikey")

    # Common user-error guard: OMDb keys are short 8-char keys, MDBList keys are
    # long tokens. If the settings look swapped, fix them in memory for this run
    # and log it without printing the actual keys.
    if mdblist_keys and omdb_keys:
        mdblist_looks_omdb = all(_looks_like_omdb_key(k) for k in mdblist_keys)
        omdb_looks_mdblist = all(_looks_like_mdblist_key(k) for k in omdb_keys)
        if mdblist_looks_omdb and omdb_looks_mdblist:
            log("API key slots look swapped; using long OMDb-field keys as MDBList and short MDBList-field keys as OMDb for this run", xbmc.LOGWARNING)
            mdblist_keys, omdb_keys = omdb_keys, mdblist_keys

    # Drop keys that are obviously placed in the wrong slot if there is no full swap.
    filtered_mdblist = [k for k in mdblist_keys if _looks_like_mdblist_key(k)]
    filtered_omdb = [k for k in omdb_keys if _looks_like_omdb_key(k)]
    if mdblist_keys and not filtered_mdblist:
        log("MDBList API key field does not contain a long MDBList key; MDBList will be skipped unless TMDbHelper supplies one", xbmc.LOGWARNING)
    if omdb_keys and not filtered_omdb:
        log("OMDb API key field does not contain an 8-character OMDb key; OMDb will be skipped", xbmc.LOGWARNING)
    mdblist_keys = filtered_mdblist
    omdb_keys = filtered_omdb

    if bool_setting("try_tmdbhelper_keys", True):
        try:
            helper = xbmcaddon.Addon("plugin.video.themoviedb.helper")
            if not mdblist_keys:
                mdblist_keys = _chain(get_setting_from(helper, ("mdblist_apikey", "mdblist_api_key", "mdblist_key")))
                mdblist_keys = [k for k in mdblist_keys if _looks_like_mdblist_key(k)]
            if not tmdb_key:
                tmdb_key = get_setting_from(helper, ("tmdb_apikey", "tmdb_api_key", "tmdb_key", "tmdb_api"))
            if not omdb_keys:
                omdb_keys = _chain(get_setting_from(helper, ("omdb_apikey", "omdb_api_key", "omdb_key")))
                omdb_keys = [k for k in omdb_keys if _looks_like_omdb_key(k)]
        except Exception:  # pylint: disable=broad-except
            pass

    return {
        "mdblist": {"keys": mdblist_keys, "limited": {}},
        "mdblist_count": len(mdblist_keys),
        "tmdb": tmdb_key,
        "omdb": {"keys": omdb_keys, "limited": {}},
        "omdb_count": len(omdb_keys),
    }


# -----------------------------------------------------------------------------
# v1.3.67 final overrides: no-repeat markers for Top250/Oscar/Emmy
# -----------------------------------------------------------------------------
# User requirement: when Top250/Oscar/Emmy has already been checked and there is
# no value, store a visible marker (N/A) instead of 0. 0 made the next
# "Scrape missing" treat the metadata as empty and scrape it again forever.
METADATA_NA_VALUE = "N/A"


def _is_metadata_na(value: Any) -> bool:
    return str(value if value is not None else "").strip().upper() in ("N/A", "NA", "NO_RATING", "UNAVAILABLE")


def _metadata_int_or_na(value: Any) -> Any:
    if _is_metadata_na(value):
        return METADATA_NA_VALUE
    parsed = safe_int(value)
    if parsed is None:
        return None
    return int(parsed) if int(parsed) > 0 else METADATA_NA_VALUE


def _top250_existing_value(existing: Dict[str, Any]) -> Any:
    for key in ("imdb_top250_movie_rank", "imdb_top250_tv_rank", "imdb_top250_rank", "top250"):
        value = (existing or {}).get(key)
        if _is_metadata_na(value):
            return METADATA_NA_VALUE
        parsed = safe_int(value)
        if parsed and parsed > 0:
            return int(parsed)
    return None


def parse_awards_wins(awards_text: Any) -> Dict[str, Any]:
    """Parse wins from OMDb and mark checked-but-none as N/A.

    The old behavior returned only awards_text when no wins were found. Because
    the compact DB stores only oscar_wins/emmy_wins, that became 0/blank after
    save/load and caused every missing-only run to hit OMDb again.  This version
    writes N/A for missing Oscar/Emmy wins once OMDb has been checked.
    """
    text = str(awards_text if awards_text is not None else "").strip()
    if not text:
        text = METADATA_NA_VALUE
    output: Dict[str, Any] = {"source": "omdb", "awards_text": text, "updated_at": now_iso()}
    if text.upper() == METADATA_NA_VALUE:
        output["oscar_wins"] = METADATA_NA_VALUE
        output["emmy_wins"] = METADATA_NA_VALUE
        return output
    oscar_wins = _award_count(r"\bWon\s+(\d+)\s+Oscars?\b", text)
    emmy_wins = _award_count(r"\bWon\s+(\d+)\s+(?:Primetime\s+|Daytime\s+)?Emmys?\b", text)
    output["oscar_wins"] = oscar_wins if oscar_wins > 0 else METADATA_NA_VALUE
    output["emmy_wins"] = emmy_wins if emmy_wins > 0 else METADATA_NA_VALUE
    return output


def _awards_needs_fill(awards: Dict[str, Any], media_type: Any) -> bool:
    if media_setting_type(media_type) not in ("movie", "tvshow"):
        return False
    if not bool_setting("scrape_awards_wins", True):
        return False
    if not isinstance(awards, dict) or not awards:
        return True
    if str(awards.get("awards_text") or "").strip():
        return False
    # A positive number or N/A marker means OMDb was already checked.
    for key in ("oscar_wins", "emmy_wins"):
        value = awards.get(key)
        if _is_metadata_na(value) or (safe_int(value) is not None and safe_int(value) >= 0):
            return False
    return True


def _merge_missing_awards(existing: Dict[str, Any], found: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(existing or {})
    found = dict(found or {})
    if found and "oscar_wins" not in found:
        found["oscar_wins"] = METADATA_NA_VALUE
    if found and "emmy_wins" not in found:
        found["emmy_wins"] = METADATA_NA_VALUE
    for key, value in found.items():
        if value in (None, ""):
            continue
        if key in ("oscar_wins", "emmy_wins"):
            current = merged.get(key)
            if current in (None, "", 0, "0"):
                merged[key] = _metadata_int_or_na(value)
        elif not str(merged.get(key) or "").strip():
            merged[key] = value
    return merged


def _resolve_top250_rank_for_item(item: Dict[str, Any], ids: Dict[str, str], existing: Dict[str, Any]) -> Any:
    media_type = media_setting_type(item.get("type"))
    old = _top250_existing_value(existing or {})
    if old is not None:
        return old
    if media_type == "movie":
        imdb_id = str((ids or {}).get("imdb") or item.get("imdbnumber") or "").lower()
        rank = 0
        if imdb_id.startswith("tt"):
            try:
                rank = safe_int(imdb_top250_ranks(False).get(imdb_id)) or 0
            except Exception as exc:  # pylint: disable=broad-except
                log("Top250 movie lookup failed: {0}".format(exc), xbmc.LOGWARNING)
        if not rank:
            rank = safe_int(item.get("top250")) or 0
        return int(rank) if rank > 0 else METADATA_NA_VALUE
    if media_type == "tvshow":
        imdb_id = str((ids or {}).get("imdb") or "").lower()
        rank = 0
        if imdb_id.startswith("tt"):
            try:
                rank = safe_int(imdb_top250_tv_ranks().get(imdb_id)) or 0
            except Exception as exc:  # pylint: disable=broad-except
                log("Top250 TV lookup failed: {0}".format(exc), xbmc.LOGWARNING)
        return int(rank) if rank > 0 else METADATA_NA_VALUE
    return None


def csv_top250_rank(entry: Dict[str, Any]) -> Any:
    value = _top250_existing_value(entry or {})
    if value == METADATA_NA_VALUE:
        return METADATA_NA_VALUE
    return value or ""


def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    ratings = entry.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ids = entry.get("ids") or {}
    series = entry.get("series") or {}
    awards = entry.get("awards") or {}

    rt_critic_cell = _display_number_for_db("rt_critic", ratings.get("rt_critic") or ratings.get("rottentomatoes") or {})
    rt_audience_cell = _display_number_for_db("rt_audience", ratings.get("rt_audience") or ratings.get("rottentomatoes_user") or {})
    metacritic_cell = _display_number_for_db("metacritic", ratings.get("metacritic") or {})
    trakt_cell = _display_number_for_db("trakt", ratings.get("trakt") or {})
    top250_value = _metadata_int_or_na(entry.get("imdb_top250_rank") if "imdb_top250_rank" in entry else entry.get("top250"))
    oscar_value = _metadata_int_or_na(awards.get("oscar_wins") if isinstance(awards, dict) and "oscar_wins" in awards else entry.get("oscar_wins"))
    emmy_value = _metadata_int_or_na(awards.get("emmy_wins") if isinstance(awards, dict) and "emmy_wins" in awards else entry.get("emmy_wins"))
    return (
        str(item_key),
        str(entry.get("title") or ""),
        _display_number_for_db("imdb", ratings.get("imdb") or {}),
        _display_number_for_db("tmdb", ratings.get("tmdb") or {}),
        rt_critic_cell,
        _simple_rating_image("rt_critic", rt_critic_cell),
        rt_audience_cell,
        _simple_rating_image("rt_audience", rt_audience_cell),
        metacritic_cell,
        trakt_cell,
        top250_value,
        str(entry.get("type") or ""),
        str(entry.get("showtitle") or ""),
        safe_int(entry.get("season")),
        safe_int(entry.get("episode")),
        str(entry.get("year") or ""),
        str(series.get("status") or entry.get("series_status") or ""),
        str(series.get("status_date") or entry.get("series_status_date") or ""),
        oscar_value,
        emmy_value,
        str(ids.get("imdb") or entry.get("imdb") or entry.get("imdbnumber") or ""),
        str(ids.get("tmdb") or entry.get("tmdb") or entry.get("tmdb_id") or ""),
        safe_int(entry.get("dbid")),
        str(entry.get("updated_at") or now_iso()),
        safe_int(entry.get("timestamp")) or int(time.time()),
    )


def _ratings_only_row_to_entry(row: sqlite3.Row) -> Dict[str, Any]:
    ids: Dict[str, str] = {}
    imdb_id = str(_row_value(row, "imdb_id") or "").strip()
    tmdb_id = str(_row_value(row, "tmdb_id") or "").strip()
    if imdb_id:
        ids["imdb"] = imdb_id
    if tmdb_id:
        ids["tmdb"] = tmdb_id
    top250_raw = _row_value(row, "top250")
    top250_rank = METADATA_NA_VALUE if _is_metadata_na(top250_raw) else (safe_int(top250_raw) or None)
    entry: Dict[str, Any] = {
        "type": str(_row_value(row, "media_type") or ""),
        "dbid": safe_int(_row_value(row, "dbid")) or 0,
        "title": str(_row_value(row, "title") or ""),
        "updated_at": str(_row_value(row, "updated_at") or ""),
        "timestamp": safe_int(_row_value(row, "timestamp")) or 0,
        "ids": ids,
        "ratings": _simple_row_to_ratings(row),
        "imdb_top250_rank": top250_rank,
    }
    showtitle = str(_row_value(row, "showtitle") or "")
    if showtitle:
        entry["showtitle"] = showtitle
    season = safe_int(_row_value(row, "season"))
    episode = safe_int(_row_value(row, "episode"))
    if season is not None:
        entry["season"] = season
    if episode is not None:
        entry["episode"] = episode
    year = str(_row_value(row, "year") or "")
    if year:
        entry["year"] = year
    series: Dict[str, Any] = {}
    status = str(_row_value(row, "series_status") or "")
    status_date = str(_row_value(row, "series_status_date") or "")
    if status:
        series["status"] = status
    if status_date:
        series["status_date"] = status_date
    if series:
        entry["series"] = series
    awards: Dict[str, Any] = {}
    for col, key in (("oscar_wins", "oscar_wins"), ("emmy_wins", "emmy_wins")):
        raw = _row_value(row, col)
        if _is_metadata_na(raw):
            awards[key] = METADATA_NA_VALUE
        else:
            parsed = safe_int(raw)
            if parsed is not None:
                awards[key] = int(parsed) if parsed > 0 else METADATA_NA_VALUE
    if awards:
        entry["awards"] = awards
    return entry


# Patch resolve_item return behavior for disabled Top250: preserve old marker/rank
# instead of writing 0 when the Top250 checkbox is off.  The main resolve_item
# above calls _resolve_top250_rank_for_item when Top250 is enabled; this wrapper
# only protects the disabled case without touching rating/provider flow.
_resolve_item_1366 = resolve_item

def resolve_item(item: Dict[str, Any], keys: Dict[str, str], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True, include_local: bool = True, ratings_only: bool = False) -> Dict[str, Any]:
    result = _resolve_item_1366(item, keys, existing, missing_only=missing_only, include_local=include_local, ratings_only=ratings_only)
    media_type = media_setting_type(item.get("type"))
    if ratings_only:
        old = _top250_existing_value(existing or {})
        if old is not None:
            result["imdb_top250_rank"] = old
    elif not rating_enabled(media_type, "top250", True):
        old = _top250_existing_value(existing or {})
        if old is not None:
            result["imdb_top250_rank"] = old
        elif "imdb_top250_rank" in result and not safe_int(result.get("imdb_top250_rank")):
            result["imdb_top250_rank"] = None
    return result


# -----------------------------------------------------------------------------
# v1.3.68 final overrides: Top250 NULL participates in Scrape missing
# -----------------------------------------------------------------------------
# Bug fixed: record_needs_update() did not consider Top250 at all. If rating
# checkboxes were OFF and awards/status were already marked N/A, rows with
# top250=NULL were skipped forever. Scrape missing now treats Top250 NULL/blank/0
# as missing, but treats N/A and a positive rank as already checked.

def record_missing_top250(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    media_type = media_setting_type((item or {}).get("type") or (record or {}).get("type"))
    if media_type not in ("movie", "tvshow"):
        return False
    if not rating_enabled(media_type, "top250", True):
        return False
    return _top250_existing_value(record or {}) is None

_record_needs_update_1367 = record_needs_update

def record_needs_update(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if _record_needs_update_1367(item, record):
        return True
    if record_missing_top250(item, record):
        return True
    return False


def _set_entry_top250(entry: Dict[str, Any], media_type: str, rank: int) -> bool:
    """Store Top250 rank or N/A marker.

    Dedicated Top250 sync should also mark non-members as N/A so the next
    missing-only run does not try them again. Positive ranks can still replace
    N/A later when the online Top250 list changes or is refreshed.
    """
    rank = safe_int(rank) or 0
    old = _top250_existing_value(entry or {})
    new_value: Any = int(rank) if rank > 0 else METADATA_NA_VALUE
    if media_type == "movie":
        entry["imdb_top250_movie_rank"] = new_value
        entry["imdb_top250_rank"] = new_value
        if "imdb_top250_tv_rank" in entry:
            entry["imdb_top250_tv_rank"] = METADATA_NA_VALUE
    elif media_type == "tvshow":
        entry["imdb_top250_tv_rank"] = new_value
        entry["imdb_top250_rank"] = new_value
        if "imdb_top250_movie_rank" in entry:
            entry["imdb_top250_movie_rank"] = METADATA_NA_VALUE
    else:
        entry["imdb_top250_rank"] = new_value
    entry["updated_at"] = now_iso()
    entry["timestamp"] = int(time.time())
    return old != new_value


_series_meta_needs_fill_1367 = _series_meta_needs_fill

def _series_meta_needs_fill(series: Dict[str, Any]) -> bool:
    # N/A means the status source was already checked and no useful status was found.
    if isinstance(series, dict) and _is_metadata_na(series.get("status")):
        return False
    return _series_meta_needs_fill_1367(series)


_resolve_item_1367 = resolve_item

def resolve_item(item: Dict[str, Any], keys: Dict[str, str], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True, include_local: bool = True, ratings_only: bool = False) -> Dict[str, Any]:
    media_type = media_setting_type((item or {}).get("type"))
    awards_was_missing = (not ratings_only) and bool_setting("scrape_awards_wins", True) and _awards_needs_fill((existing or {}).get("awards") or {}, media_type)
    status_was_missing = (not ratings_only) and media_type == "tvshow" and bool_setting("scrape_tv_status", True) and _series_meta_needs_fill((existing or {}).get("series") or {})
    result = _resolve_item_1367(item, keys, existing, missing_only=missing_only, include_local=include_local, ratings_only=ratings_only)

    # If OMDb was requested for awards but returned a valid "not found"/no-awards
    # result, keep a no-repeat marker instead of NULL. Do not hide actual OMDb
    # runtime/API errors; those should remain retryable.
    if awards_was_missing and media_type in ("movie", "tvshow"):
        errors = [str(e).lower() for e in (result.get("errors") or [])]
        if not any(e.startswith("omdb:") for e in errors):
            awards = dict(result.get("awards") or {})
            awards.setdefault("oscar_wins", METADATA_NA_VALUE)
            awards.setdefault("emmy_wins", METADATA_NA_VALUE)
            if not str(awards.get("awards_text") or "").strip():
                awards["awards_text"] = METADATA_NA_VALUE
            result["awards"] = awards

    # If TV status lookup was requested and completed without a TMDb error but no
    # status was found, mark it as N/A. That prevents endless status retries.
    if status_was_missing and media_type == "tvshow":
        errors = [str(e).lower() for e in (result.get("errors") or [])]
        if not any(e.startswith("tmdb_status:") for e in errors):
            series = dict(result.get("series") or {})
            if not str(series.get("status") or "").strip():
                series["status"] = METADATA_NA_VALUE
            if not str(series.get("status_date") or "").strip():
                series["status_date"] = METADATA_NA_VALUE
            result["series"] = series

    return result

# -----------------------------------------------------------------------------
# v1.3.74 AF3/LRS display bridge final overrides
# -----------------------------------------------------------------------------
# Goals from AF3 bug report:
# - LibraryRatings only by default. Do not write TMDbHelper.* unless compatibility
#   compatibility is explicitly enabled because that can trigger native AF3
#   TMDbHelper status rows and duplicate series status.
# - Display settings are separate from scrape settings.
# - Publish RT image filenames from DB image keys.
# - Local IMDb Top250 DB only.
# - Publish only changed values to reduce flicker.

IMDB_TOP250_LOCAL_DB_FILE = os.path.join(DATA_DIR, "imdb_top_250.db")
_LAST_AF3_PUBLISHED: Dict[str, str] = {}

LRS_DISPLAY_SETTINGS = (
    ("IMDb", "display_imdb"),
    ("TMDb", "display_tmdb"),
    ("RottenTomatoes", "display_rt_critic"),
    ("RottenTomatoesUser", "display_rt_audience"),
    ("MetaCritic", "display_metacritic"),
    ("Trakt", "display_trakt"),
    ("Top250", "display_top250"),
    ("Awards", "display_awards"),
    ("TVStatus", "display_tv_status"),
)

LRS_EXTRA_PROPERTY_NAMES = (
    "HasData", "DBType", "Title", "Year", "ItemKey", "SourceContext",
    "RottenTomatoes_ImageKey", "RottenTomatoes_UserImageKey",
    "Series_Status", "Series_StatusDate", "SeriesStatus", "SeriesStatusDate",
    "Display_IMDb", "Display_TMDb", "Display_RottenTomatoes", "Display_RottenTomatoesUser",
    "Display_MetaCritic", "Display_Trakt", "Display_Top250", "Display_Awards", "Display_TVStatus",
)

_rating_enabled_1374_base = rating_enabled

def rating_enabled(media_type: Any, logical: str, default: bool = True) -> bool:
    media_type = media_setting_type(media_type)
    if logical == "top250" and media_type in ("movie", "tvshow"):
        value = ADDON.getSetting("rating_top250")
        if value != "":
            return value.lower() == "true"
        old_id = "rating_top250_movies" if media_type == "movie" else "rating_top250_tvshows"
        old_value = ADDON.getSetting(old_id)
        return default if old_value == "" else old_value.lower() == "true"
    return _rating_enabled_1374_base(media_type, logical, default)


def lrs_display_enabled(name: str) -> bool:
    lookup = {label.lower(): setting for label, setting in LRS_DISPLAY_SETTINGS}
    return bool_setting(lookup.get(str(name or "").lower(), str(name or "")), True)


def lrs_display_flags() -> Dict[str, str]:
    return {"Display_" + label: "true" if bool_setting(setting, True) else "false" for label, setting in LRS_DISPLAY_SETTINGS}


def tmdbhelper_compat_enabled() -> bool:
    return bool_setting("publish_tmdbhelper_compat", False)


def _local_top250_db_candidates() -> List[str]:
    return [os.path.join(PROFILE, "imdb_top_250.db"), IMDB_TOP250_LOCAL_DB_FILE]


def _local_top250_db_path() -> str:
    for path in _local_top250_db_candidates():
        try:
            if path and os.path.exists(path):
                return path
        except OSError:
            continue
    return IMDB_TOP250_LOCAL_DB_FILE


def _load_local_top250_ranks(media_type: str) -> Dict[str, int]:
    media_type = media_setting_type(media_type)
    if media_type not in ("movie", "tvshow"):
        return {}
    ranks: Dict[str, int] = {}
    db_path = _local_top250_db_path()
    try:
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            for row in conn.execute("SELECT imdb, rank FROM top250 WHERE media_type=? ORDER BY rank", (media_type,)):
                imdb_id = _norm_imdb(row["imdb"])
                rank = safe_int(row["rank"])
                if imdb_id and rank and 1 <= rank <= 250:
                    ranks[imdb_id] = int(rank)
        finally:
            conn.close()
    except Exception as exc:  # pylint: disable=broad-except
        log("Local IMDb Top250 DB unavailable: {0} ({1})".format(db_path, exc), xbmc.LOGWARNING)
    return ranks


def imdb_top250_ranks(force_refresh: bool = False) -> Dict[str, int]:
    return _load_local_top250_ranks("movie")


def imdb_top250_tv_ranks() -> Dict[str, int]:
    return _load_local_top250_ranks("tvshow")


def _top250_db_value(media_type: str, imdb_id: str) -> Any:
    imdb_id = _norm_imdb(imdb_id)
    if not imdb_id:
        return METADATA_NA_VALUE
    ranks = imdb_top250_ranks(False) if media_setting_type(media_type) == "movie" else imdb_top250_tv_ranks()
    rank = safe_int(ranks.get(imdb_id)) or 0
    return int(rank) if rank > 0 else METADATA_NA_VALUE


def _json_uniqueids(item: Dict[str, Any]) -> Dict[str, str]:
    ids: Dict[str, str] = {}
    uniqueid = item.get("uniqueid") if isinstance(item, dict) else {}
    if isinstance(uniqueid, dict):
        for key, value in uniqueid.items():
            if value not in (None, ""):
                ids[str(key).lower()] = str(value)
    imdbnumber = str((item or {}).get("imdbnumber") or "").strip()
    if _norm_imdb(imdbnumber):
        ids.setdefault("imdb", _norm_imdb(imdbnumber))
    return ids


def _json_item_imdb_id(item: Dict[str, Any]) -> str:
    ids = _json_uniqueids(item)
    return _norm_imdb(ids.get("imdb") or (item or {}).get("imdbnumber"))


def _json_item_tmdb_id(item: Dict[str, Any]) -> str:
    ids = _json_uniqueids(item)
    return _norm_tmdb(ids.get("tmdb") or ids.get("themoviedb") or ids.get("tmdb_id"))


def _simple_top250_norm(value: Any) -> Any:
    if _is_metadata_na(value):
        return METADATA_NA_VALUE
    parsed = safe_int(value)
    if parsed is not None and parsed > 0:
        return int(parsed)
    return None


def _upsert_top250_row(conn: sqlite3.Connection, media_type: str, dbid: Any, item: Dict[str, Any], top250_value: Any) -> bool:
    dbid_int = safe_int(dbid)
    if dbid_int is None:
        return False
    media_type = media_setting_type(media_type)
    item_key_value = "{0}|{1}".format(media_type, dbid_int)
    title = str((item or {}).get("title") or "")
    year = str((item or {}).get("year") or "")
    imdb_id = _json_item_imdb_id(item or {})
    tmdb_id = _json_item_tmdb_id(item or {})
    now = now_iso()
    ts = int(time.time())
    existing = conn.execute("SELECT top250 FROM ratings WHERE item_key=?", (item_key_value,)).fetchone()
    old_value = _simple_top250_norm(existing[0]) if existing else None
    new_value = top250_value if top250_value == METADATA_NA_VALUE else int(top250_value)
    changed = old_value != new_value
    if existing:
        conn.execute(
            """
            UPDATE ratings
               SET top250=?,
                   title=CASE WHEN COALESCE(title,'')='' THEN ? ELSE title END,
                   media_type=CASE WHEN COALESCE(media_type,'')='' THEN ? ELSE media_type END,
                   year=CASE WHEN COALESCE(year,'')='' THEN ? ELSE year END,
                   imdb_id=CASE WHEN COALESCE(imdb_id,'')='' THEN ? ELSE imdb_id END,
                   tmdb_id=CASE WHEN COALESCE(tmdb_id,'')='' THEN ? ELSE tmdb_id END,
                   dbid=COALESCE(dbid, ?), updated_at=?, timestamp=?
             WHERE item_key=?
            """,
            (new_value, title, media_type, year, imdb_id, tmdb_id, dbid_int, now, ts, item_key_value),
        )
    else:
        conn.execute(
            """
            INSERT INTO ratings (
                item_key,title,imdb,tmdb,rottentomatoes,rottentomatoes_image,
                rottentomatoes_user,rottentomatoes_userimage,metacritic,trakt,top250,
                media_type,showtitle,season,episode,year,series_status,series_status_date,
                oscar_wins,emmy_wins,imdb_id,tmdb_id,dbid,updated_at,timestamp
            ) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
            """,
            (item_key_value, title, "", "", "", "", "", "", "", "", new_value, media_type, "", None, None, year, "", "", METADATA_NA_VALUE, METADATA_NA_VALUE, imdb_id, tmdb_id, dbid_int, now, ts),
        )
        changed = True
    return changed


def sync_imdb_top250_to_library(force_chart_refresh: bool = False, progress: Any = None) -> Dict[str, int]:
    movie_enabled = rating_enabled("movie", "top250", True) and bool_setting("include_movies", True)
    tv_enabled = rating_enabled("tvshow", "top250", True) and bool_setting("include_tvshows", True)
    movie_ranks = imdb_top250_ranks(False) if movie_enabled else {}
    tv_ranks = imdb_top250_tv_ranks() if tv_enabled else {}
    stats = {"movies": 0, "movie_matched": 0, "movie_updated": 0, "movie_missing_imdb": 0, "movie_chart_items": len(movie_ranks), "tvshows": 0, "tv_matched": 0, "tv_updated": 0, "tv_missing_imdb": 0, "tv_chart_items": len(tv_ranks), "updated": 0, "matched": 0, "total": 0, "processed": 0, "source": "local_db"}
    with _sqlite_connect() as conn:
        if movie_enabled:
            movies = json_rpc("VideoLibrary.GetMovies", {"properties": ["title", "year", "imdbnumber", "uniqueid", "top250"]}).get("movies", []) or []
            stats["movies"] = len(movies)
            for index, movie in enumerate(movies, start=1):
                if progress is not None:
                    progress.update(int(index * 50 / max(1, len(movies))), "Movies local Top250 [{0}/{1}] {2}".format(index, len(movies), (movie or {}).get("title") or "Untitled"))
                    if progress.iscanceled():
                        break
                if not isinstance(movie, dict):
                    continue
                imdb_id = _json_item_imdb_id(movie)
                value = _top250_db_value("movie", imdb_id)
                if not imdb_id:
                    stats["movie_missing_imdb"] += 1
                elif value != METADATA_NA_VALUE:
                    stats["movie_matched"] += 1
                if _upsert_top250_row(conn, "movie", movie.get("movieid"), movie, value):
                    stats["movie_updated"] += 1
        if tv_enabled:
            shows = json_rpc("VideoLibrary.GetTVShows", {"properties": ["title", "year", "imdbnumber", "uniqueid"]}).get("tvshows", []) or []
            stats["tvshows"] = len(shows)
            for index, show in enumerate(shows, start=1):
                if progress is not None:
                    progress.update(50 + int(index * 50 / max(1, len(shows))), "TV local Top250 [{0}/{1}] {2}".format(index, len(shows), (show or {}).get("title") or "Untitled"))
                    if progress.iscanceled():
                        break
                if not isinstance(show, dict):
                    continue
                imdb_id = _json_item_imdb_id(show)
                value = _top250_db_value("tvshow", imdb_id)
                if not imdb_id:
                    stats["tv_missing_imdb"] += 1
                elif value != METADATA_NA_VALUE:
                    stats["tv_matched"] += 1
                if _upsert_top250_row(conn, "tvshow", show.get("tvshowid"), show, value):
                    stats["tv_updated"] += 1
        _db_set_meta(conn, "top250_source", _local_top250_db_path())
        _db_set_meta(conn, "top250_local_sync_at", now_iso())
        conn.commit()
    stats["updated"] = int(stats.get("movie_updated") or 0) + int(stats.get("tv_updated") or 0)
    stats["matched"] = int(stats.get("movie_matched") or 0) + int(stats.get("tv_matched") or 0)
    stats["total"] = int(stats.get("movies") or 0) + int(stats.get("tvshows") or 0)
    stats["processed"] = int(stats.get("total") or 0)
    return stats


_ratings_only_row_to_entry_1374_base = _ratings_only_row_to_entry

def _ratings_only_row_to_entry(row: sqlite3.Row) -> Dict[str, Any]:
    entry = _ratings_only_row_to_entry_1374_base(row)
    rt_image = str(_row_value(row, "rottentomatoes_image") or "").strip()
    rt_user_image = str(_row_value(row, "rottentomatoes_userimage") or "").strip()
    if rt_image or rt_user_image:
        entry["rt_images"] = {"critic": rt_image, "audience": rt_user_image}
    return entry


def _lrs_rt_file(token: Any, rating_value: Any = None) -> str:
    text = str(token or "").strip().lower().replace(" ", "_").replace("-", "_")
    if text in ("certified", "certified_fresh", "rtcertified", "certifiedfresh"):
        return "certified.png"
    if text in ("fresh", "rtfresh"):
        return "rtfresh.png"
    if text in ("rotten", "rtrotten"):
        return "rtrotten.png"
    number = safe_float(rating_value)
    if number is None or number <= 0:
        return ""
    return "rtfresh.png" if number >= 60 else "rtrotten.png"


def _lrs_audience_file(token: Any, rating_value: Any = None) -> str:
    text = str(token or "").strip().lower().replace(" ", "_").replace("-", "_")
    if text in ("upright", "popcorn", "popcorn_upright"):
        return "popcorn.png"
    if text in ("spilled", "spilt", "popcorn_spilt", "popcorn_spilled"):
        return "popcorn_spilt.png"
    number = safe_float(rating_value)
    if number is None or number <= 0:
        return ""
    return "popcorn.png" if number >= 60 else "popcorn_spilt.png"


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    ratings = record.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ratings = preserve_ratings_for_item(record.get("type"), ratings)
    critic_rating = first_rating(ratings, "rt_critic")
    audience_rating = first_rating(ratings, "rt_audience")
    critic_display = display_rt_percent(critic_rating)
    audience_display = display_rt_percent(audience_rating)
    imdb_display = display_decimal(first_rating(ratings, "imdb"))
    tmdb_display = display_decimal(first_rating(ratings, "tmdb"))
    metacritic_display = display_percent(first_rating(ratings, "metacritic"))
    trakt_display = display_percent(first_rating(ratings, "trakt"))
    rt_images = record.get("rt_images") if isinstance(record.get("rt_images"), dict) else {}
    rt_image_key = str(rt_images.get("critic") or "").strip()
    rt_user_image_key = str(rt_images.get("audience") or "").strip()
    rt_image = _lrs_rt_file(rt_image_key, critic_display)
    rt_audience_image = _lrs_audience_file(rt_user_image_key, audience_display)
    top250_rank = safe_int(record.get("imdb_top250_rank"))
    top250_display = str(top250_rank) if top250_rank and top250_rank > 0 else ""
    top250_hash_display = "#{0}".format(top250_rank) if top250_display else ""
    values = {
        "HasData": "true", "DBType": str(record.get("type") or ""), "Title": str(record.get("title") or ""), "Year": str(record.get("year") or ""),
        "IMDb_Rating": imdb_display, "IMDB_Rating": imdb_display, "IMDb": imdb_display, "IMDB": imdb_display, "imdb": imdb_display, "imdb_rating": imdb_display,
        "Top250": top250_display, "Top250_Rank": top250_hash_display, "top250": top250_display, "top250_rank": top250_hash_display,
        "TMDb_Rating": tmdb_display, "TMDB_Rating": tmdb_display, "TMDb": tmdb_display, "TMDB": tmdb_display, "tmdb": tmdb_display, "tmdb_rating": tmdb_display,
        "RottenTomatoes_Rating": critic_display, "RottenTomatoes": critic_display, "RottenTomatoes_UserMeter": audience_display, "RottenTomatoes_User": audience_display,
        "rottentomatoes": critic_display, "rottentomatoes_user": audience_display, "MetaCritic_Rating": metacritic_display, "Trakt_Rating": trakt_display,
        "RottenTomatoesIcon": rt_image, "RottenTomatoesImage": rt_image, "RottenTomatoes_Image": rt_image, "RottenTomatoes_ImageKey": rt_image_key,
        "RottenTomatoesAudienceIcon": rt_audience_image, "RottenTomatoesAudienceImage": rt_audience_image, "RottenTomatoes_UserImage": rt_audience_image, "RottenTomatoes_UserImageKey": rt_user_image_key,
        "Source": "script.library.ratings.scraper",
    }
    awards = record.get("awards") or {}
    if isinstance(awards, dict):
        oscar_wins = safe_int(awards.get("oscar_wins")); emmy_wins = safe_int(awards.get("emmy_wins"))
        if oscar_wins and oscar_wins > 0:
            values["Oscar_Wins"] = str(oscar_wins); values["OscarWins"] = str(oscar_wins)
        if emmy_wins and emmy_wins > 0:
            values["Emmy_Wins"] = str(emmy_wins); values["EmmyWins"] = str(emmy_wins)
    series = record.get("series") or {}
    if record.get("type") in ("tvshow", "season", "episode") and isinstance(series, dict):
        status = str(series.get("status") or "").strip()
        status_date = str(series.get("status_date") or "").strip()
        status_date_display = str(series.get("status_date_display") or _date_display(status_date)).strip()
        if status and not _is_metadata_na(status):
            label = _lrs_series_status_label_1537(status)
            values.update({"Status": status, "StatusDate": status_date_display, "Series_Status": status, "Series_StatusDate": status_date_display, "SeriesStatus": status, "SeriesStatusDate": status_date_display, "Series_StatusLabel": label, "SeriesStatusLabel": label})
    values.update(lrs_display_flags())
    return {key: str(value) for key, value in values.items() if value not in (None, "")}


def _publish_property(window: Any, name: str, value: str) -> None:
    try:
        current = window.getProperty(name)
    except Exception:  # pylint: disable=broad-except
        current = None
    if current == value:
        return
    try:
        window.setProperty(name, value)
    except Exception:  # pylint: disable=broad-except
        pass


def publish_af3_properties(values: Dict[str, str], item_identity: str = "", compatibility: bool = True) -> None:
    published = dict(values or {})
    published["ItemKey"] = item_identity
    display_flags = lrs_display_flags()
    published.update(display_flags)
    services = ("ListItem", "Player", "VideoPlayer", "Screensaver")
    property_names = tuple(dict.fromkeys(tuple(AF3_PROPERTY_NAMES) + tuple(LRS_EXTRA_PROPERTY_NAMES) + tuple(display_flags.keys())))
    compat = bool(compatibility and tmdbhelper_compat_enabled())
    for window in _publish_windows():
        for name, value in display_flags.items():
            _publish_property(window, AF3_PREFIX + "Display." + name.replace("Display_", ""), str(value))
        for service in services:
            for name in property_names:
                value = str(published.get(name, "") or "")
                _publish_property(window, AF3_PREFIX + service + "." + name, value)
                if compat:
                    _publish_property(window, TMDBHELPER_PREFIX + service + "." + name, value)


def clear_af3_properties(compatibility: bool = True) -> None:
    # Clear LibraryRatings values but leave display flags available. TMDbHelper
    # is not touched by default to avoid native AF3 duplicate status rows.
    publish_af3_properties({}, "", compatibility)


# -----------------------------------------------------------------------------
# v1.3.75 AF3 bridge fixes: strict episode identity + full display cache
# -----------------------------------------------------------------------------
def _lrs_display_rating_quality(media_type: Any, record: Dict[str, Any]) -> int:
    """Quality used only for choosing display rows.

    This intentionally ignores scrape checkboxes. A cached RT/Metacritic/Trakt
    value must remain usable in the skin even if the user later disables that
    provider for new scraping.
    """
    if not isinstance(record, dict) or not record:
        return -1
    media_type = media_setting_type(record.get("type") or media_type)
    ratings = preserve_ratings_for_item(media_type, record.get("ratings") or {})
    score = 0
    for logical, weight in (("imdb", 4), ("tmdb", 4), ("rt_critic", 3), ("rt_audience", 3), ("metacritic", 3), ("trakt", 2), ("letterboxd", 1), ("mdblist", 1)):
        row = ratings.get(logical)
        if not isinstance(row, dict):
            continue
        if is_no_rating_marker(row):
            score += 1
        elif safe_float(row.get("value")) is not None or safe_float(row.get("score")) is not None:
            score += weight
    top250 = safe_int(record.get("imdb_top250_rank"))
    if top250 and top250 > 0:
        score += 2
    awards = record.get("awards") or {}
    if isinstance(awards, dict):
        if safe_int(awards.get("oscar_wins")) and safe_int(awards.get("oscar_wins")) > 0:
            score += 1
        if safe_int(awards.get("emmy_wins")) and safe_int(awards.get("emmy_wins")) > 0:
            score += 1
    series = record.get("series") or {}
    if isinstance(series, dict) and str(series.get("status") or "").strip() and not _is_metadata_na(series.get("status")):
        score += 1
    return score


def _choose_best_record(media_type: Any, candidates: List[Dict[str, Any]], exact: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    clean = [row for row in candidates if isinstance(row, dict) and row]
    if isinstance(exact, dict) and exact and exact not in clean:
        clean.append(exact)
    if not clean:
        return exact if isinstance(exact, dict) else {}
    return max(clean, key=lambda row: (
        _lrs_display_rating_quality(media_type, row),
        1 if isinstance(exact, dict) and exact is row else 0,
        safe_int(row.get("dbid")) or -1,
        str(row.get("updated_at") or ""),
    ))


def _item_has_strong_id(item: Dict[str, Any]) -> bool:
    if not isinstance(item, dict):
        return False
    kind = str(item.get("type") or "").lower()
    if kind in ("movie", "tvshow", "episode") and safe_int(item.get("dbid")) is not None:
        return True
    if _norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb")):
        return True
    if _norm_tmdb(item.get("tmdb_id") or item.get("tmdb")):
        return True
    return False


def _same_episode_identity(item: Dict[str, Any], row: Dict[str, Any]) -> bool:
    if str(row.get("type") or "").lower() != "episode":
        return False
    item_imdb = _norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb"))
    item_tmdb = _norm_tmdb(item.get("tmdb_id") or item.get("tmdb"))
    ids = row.get("ids") or {}
    if item_imdb:
        return _norm_imdb(ids.get("imdb")) == item_imdb
    if item_tmdb:
        return _norm_tmdb(ids.get("tmdb")) == item_tmdb
    season = safe_int(item.get("season"))
    episode = safe_int(item.get("episode"))
    if season is None or episode is None:
        return False
    if safe_int(row.get("season")) != season or safe_int(row.get("episode")) != episode:
        return False
    show = _norm_text(item.get("showtitle"))
    if show and _norm_text(row.get("showtitle")) != show:
        return False
    # Episode title can differ in AF3/scraper capitalization; use it only when
    # no show title exists.
    if not show:
        title = _norm_text(item.get("title"))
        if title and _norm_text(row.get("title")) != title:
            return False
    return True


def cache_record(cache: Dict[str, Any], item: Dict[str, Any]) -> Dict[str, Any]:
    """Find best cached record for current AF3 context.

    v1.3.75: do not trust exact DBID blindly if richer duplicates exist, and
    never let an episode context fall back to the parent tvshow. Display matching
    uses all cached values, independent from scrape checkboxes.
    """
    records = cache.get("items") or {}
    kind = str(item.get("type") or "").lower()
    media_type = media_setting_type(kind)
    exact = records.get(item_key(item)) if safe_int(item.get("dbid")) is not None else None
    candidates: List[Dict[str, Any]] = []
    if isinstance(exact, dict) and exact:
        candidates.append(exact)

    imdb_id = _norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb"))
    tmdb_id = _norm_tmdb(item.get("tmdb_id") or item.get("tmdb"))

    for row in records.values():
        if not isinstance(row, dict) or not row:
            continue
        row_kind = str(row.get("type") or "").lower()
        if kind:
            if row_kind != kind:
                continue
        elif row_kind not in ("movie", "tvshow", "episode"):
            continue
        if kind == "episode" and not _same_episode_identity(item, row):
            # Strong episode guard. Do not match parent tvshow or sibling episode.
            # Strong IMDb/TMDb matches are accepted by _same_episode_identity().
            continue
        ids = row.get("ids") or {}
        matched = False
        if imdb_id and _norm_imdb(ids.get("imdb")) == imdb_id:
            matched = True
        if tmdb_id and _norm_tmdb(ids.get("tmdb")) == tmdb_id:
            matched = True
        if kind == "episode" and _same_episode_identity(item, row):
            matched = True
        if not matched:
            title = _norm_text(item.get("title"))
            if title and _norm_text(row.get("title")) == title:
                if row_kind == "episode":
                    if _same_episode_identity(item, row):
                        matched = True
                else:
                    year = safe_int(item.get("year"))
                    matched = year is None or safe_int(row.get("year")) in (None, year)
        if matched and row not in candidates:
            candidates.append(row)

    return _choose_best_record(media_type, candidates, exact) if candidates else {}


def context_matches_record(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if not isinstance(item, dict) or not isinstance(record, dict) or not record:
        return False
    item_kind = str(item.get("type") or "").lower()
    row_kind = str(record.get("type") or "").lower()
    if item_kind and row_kind and item_kind != row_kind:
        return False
    if item_kind == "episode" or row_kind == "episode":
        return _same_episode_identity(item, record)
    dbid = safe_int(item.get("dbid"))
    if dbid is not None and item_kind in ("movie", "tvshow"):
        return row_kind == item_kind and safe_int(record.get("dbid")) == dbid
    item_imdb = _norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb"))
    item_tmdb = _norm_tmdb(item.get("tmdb_id") or item.get("tmdb"))
    ids = record.get("ids") or {}
    if item_imdb:
        return _norm_imdb(ids.get("imdb")) == item_imdb
    if item_tmdb:
        return _norm_tmdb(ids.get("tmdb")) == item_tmdb
    title = _norm_text(item.get("title"))
    if title and _norm_text(record.get("title")) != title:
        return False
    year = safe_int(item.get("year"))
    if year is not None and safe_int(record.get("year")) not in (None, year):
        return False
    return bool(title or dbid is not None)


def _lrs_log_publish_values(context: str, record: Dict[str, Any], values: Dict[str, str]) -> None:
    if not bool_setting("debug_logging", False):
        return
    try:
        log("LRS PUBLISH {0} {1}|{2} title={3} imdb={4} tmdb={5} rt={6} rt_user={7} meta={8} trakt={9} top250={10}".format(
            context,
            record.get("type") or "",
            record.get("dbid") or "",
            str(record.get("title") or "")[:80],
            values.get("IMDb_Rating", ""),
            values.get("TMDb_Rating", ""),
            values.get("RottenTomatoes_Rating", ""),
            values.get("RottenTomatoes_UserMeter", ""),
            values.get("MetaCritic_Rating", ""),
            values.get("Trakt_Rating", ""),
            values.get("Top250", ""),
        ), xbmc.LOGINFO)
    except Exception:  # pylint: disable=broad-except
        pass


# -----------------------------------------------------------------------------
# v1.3.76 AF3 display fixes: RT image aliases + no episode status + Home button guard
# -----------------------------------------------------------------------------
def af3_home_action_button_focused() -> bool:
    """AF3 Home/Hub Play/More Options buttons can steal focus from the visual item."""
    try:
        if not xbmc.getCondVisibility("Window.IsActive(home)"):
            return False
    except Exception:  # pylint: disable=broad-except
        return False
    return focused_control_id() in (311, 312, 4001, 6001)


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    ratings = record.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ratings = preserve_ratings_for_item(record.get("type"), ratings)
    critic_rating = first_rating(ratings, "rt_critic")
    audience_rating = first_rating(ratings, "rt_audience")
    critic_display = display_rt_percent(critic_rating)
    audience_display = display_rt_percent(audience_rating)
    imdb_display = display_decimal(first_rating(ratings, "imdb"))
    tmdb_display = display_decimal(first_rating(ratings, "tmdb"))
    metacritic_display = display_percent(first_rating(ratings, "metacritic"))
    trakt_display = display_percent(first_rating(ratings, "trakt"))
    rt_images = record.get("rt_images") if isinstance(record.get("rt_images"), dict) else {}
    rt_image_key = str(rt_images.get("critic") or "").strip()
    rt_user_image_key = str(rt_images.get("audience") or "").strip()
    # Always compute an AF3 icon filename from the rating when the DB key is blank.
    # v1.3.75 already published RT values; this guarantees XML visible conditions
    # can never hide RT only because the icon property was missing.
    rt_image = _lrs_rt_file(rt_image_key, critic_display)
    rt_audience_image = _lrs_audience_file(rt_user_image_key, audience_display)
    top250_rank = safe_int(record.get("imdb_top250_rank"))
    top250_display = str(top250_rank) if top250_rank and top250_rank > 0 else ""
    top250_hash_display = "#{0}".format(top250_rank) if top250_display else ""
    values = {
        "HasData": "true", "DBType": str(record.get("type") or ""), "Title": str(record.get("title") or ""), "Year": str(record.get("year") or ""),
        "IMDb_Rating": imdb_display, "IMDB_Rating": imdb_display, "IMDb": imdb_display, "IMDB": imdb_display, "imdb": imdb_display, "imdb_rating": imdb_display,
        "Top250": top250_display, "Top250_Rank": top250_hash_display, "top250": top250_display, "top250_rank": top250_hash_display,
        "TMDb_Rating": tmdb_display, "TMDB_Rating": tmdb_display, "TMDb": tmdb_display, "TMDB": tmdb_display, "tmdb": tmdb_display, "tmdb_rating": tmdb_display,
        "RottenTomatoes_Rating": critic_display, "RottenTomatoes": critic_display, "RottenTomatoes_UserMeter": audience_display, "RottenTomatoes_User": audience_display,
        "rottentomatoes": critic_display, "rottentomatoes_user": audience_display, "MetaCritic_Rating": metacritic_display, "Trakt_Rating": trakt_display,
        "RottenTomatoesIcon": rt_image, "RottenTomatoesImage": rt_image, "RottenTomatoes_Image": rt_image, "RottenTomatoes_ImageKey": rt_image_key,
        "RottenTomatoes_CriticImage": rt_image, "RottenTomatoesCriticImage": rt_image, "rottentomatoes_image": rt_image,
        "RottenTomatoesAudienceIcon": rt_audience_image, "RottenTomatoesAudienceImage": rt_audience_image, "RottenTomatoesAudience_Image": rt_audience_image,
        "RottenTomatoes_UserImage": rt_audience_image, "RottenTomatoes_UserImageKey": rt_user_image_key, "RottenTomatoesUserImage": rt_audience_image,
        "rottentomatoes_userimage": rt_audience_image,
        "Source": "script.library.ratings.scraper",
    }
    awards = record.get("awards") or {}
    if isinstance(awards, dict):
        oscar_wins = safe_int(awards.get("oscar_wins")); emmy_wins = safe_int(awards.get("emmy_wins"))
        if oscar_wins and oscar_wins > 0:
            values["Oscar_Wins"] = str(oscar_wins); values["OscarWins"] = str(oscar_wins)
        if emmy_wins and emmy_wins > 0:
            values["Emmy_Wins"] = str(emmy_wins); values["EmmyWins"] = str(emmy_wins)
    # Status is a show/season-level fact. Do not publish it for episodes; AF3's
    # native status row was showing it behind EndTime in episode/OSD views.
    series = record.get("series") or {}
    if record.get("type") in ("tvshow", "season") and isinstance(series, dict):
        status = str(series.get("status") or "").strip()
        status_date = str(series.get("status_date") or "").strip()
        status_date_display = str(series.get("status_date_display") or _date_display(status_date)).strip()
        if status and not _is_metadata_na(status):
            label = _lrs_series_status_label_1537(status)
            values.update({"Status": status, "StatusDate": status_date_display, "Series_Status": status, "Series_StatusDate": status_date_display, "SeriesStatus": status, "SeriesStatusDate": status_date_display, "Series_StatusLabel": label, "SeriesStatusLabel": label})
    values.update(lrs_display_flags())
    return {key: str(value) for key, value in values.items() if value not in (None, "")}


def _lrs_log_publish_values(context: str, record: Dict[str, Any], values: Dict[str, str]) -> None:
    if not bool_setting("debug_logging", False):
        return
    try:
        log("LRS PUBLISH {0} {1}|{2} title={3} imdb={4} tmdb={5} rt={6} rt_img={7} rt_user={8} rt_user_img={9} meta={10} trakt={11} top250={12} status={13}".format(
            context,
            record.get("type") or "",
            record.get("dbid") or "",
            str(record.get("title") or "")[:80],
            values.get("IMDb_Rating", ""), values.get("TMDb_Rating", ""),
            values.get("RottenTomatoes_Rating", ""), values.get("RottenTomatoes_Image", ""),
            values.get("RottenTomatoes_UserMeter", ""), values.get("RottenTomatoes_UserImage", ""),
            values.get("MetaCritic_Rating", ""), values.get("Trakt_Rating", ""),
            values.get("Top250", ""), values.get("Series_StatusLabel", ""),
        ), xbmc.LOGINFO)
    except Exception:  # pylint: disable=broad-except
        pass

# -----------------------------------------------------------------------------
# v1.3.78 AF3 Home/Hub visual container resolver
# -----------------------------------------------------------------------------
def _lrs_safe_cond(condition: str) -> bool:
    try:
        return bool(xbmc.getCondVisibility(condition))
    except Exception:  # pylint: disable=broad-except
        return False


def af3_hub_window_active() -> bool:
    """True for AF3 windows where the visible media can differ from focused control."""
    return any(_lrs_safe_cond(cond) for cond in (
        "Window.IsActive(home)",
        "Window.IsActive(1101)",
        "Window.IsActive(1102)",
        "Window.IsActive(1103)",
        "Window.IsActive(1104)",
    ))


def _lrs_get_window_property_by_id(window_id: int, *names: str) -> str:
    try:
        import xbmcgui  # pylint: disable=import-outside-toplevel
        window = xbmcgui.Window(window_id)
    except Exception:  # pylint: disable=broad-except
        return ""
    for name in names:
        try:
            value = window.getProperty(name).strip()
        except Exception:  # pylint: disable=broad-except
            value = ""
        if value:
            return value
    return ""


def _lrs_active_af3_window_ids() -> List[int]:
    """Return only concrete Kodi windows that are safe to instantiate.

    AF3 hub XML names are Custom_110x, but Kodi 22 reports the real window ids
    as 11101-11104. Older 1.5.34 also tried hard-coded 1101-1104; those ids
    can be invalid and Kodi logs noisy "Window id does not exist" exceptions
    even when Python catches them. KPM is now the visual owner, so LRS only
    needs safe property lookup for compatibility/screensaver paths.
    """
    ids: List[int] = []
    if _lrs_safe_cond("Window.IsActive(home)"):
        ids.append(10000)
    try:
        import xbmcgui  # pylint: disable=import-outside-toplevel
        current = int(xbmcgui.getCurrentWindowId())
    except Exception:  # pylint: disable=broad-except
        current = 0
    if current in (10000, 10001, 10025, 11101, 11102, 11103, 11104) and current not in ids:
        ids.append(current)
    return ids


def _lrs_any_af3_property(*names: str) -> str:
    value = _window_property(*names) or _home_property(*names)
    if value:
        return value
    for wid in _lrs_active_af3_window_ids():
        value = _lrs_get_window_property_by_id(wid, *names)
        if value:
            return value
    return ""


def _lrs_container_id_from_widget_selector() -> Optional[int]:
    # AF3 category selector item stores the real widget container in widget_id.
    for expression in (
        "Container(601).ListItem.Property(widget_id)",
        "Container(601).ListItem.Property(widgetid)",
        "Container(601).ListItem.Property(id)",
    ):
        try:
            value = xbmc.getInfoLabel(expression).strip()
        except Exception:  # pylint: disable=broad-except
            value = ""
        number = safe_int(value)
        if number is not None and number > 0:
            return int(number)
    return None


def af3_active_container_id() -> Optional[int]:
    """Return the AF3 visual media container id for Home/Hub.

    Focus can be on Play/More Options (311/312), the hub tab selector (601), or
    top menu (300). The visible title/plot/background belongs to the widget
    container tracked by AF3, not necessarily the focused control.
    """
    if not af3_hub_window_active():
        return None
    focused = focused_control_id()

    # Real media containers win immediately.
    if focused in (301, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510):
        return int(focused)

    # The category selector points to the active widget row.
    if focused in (601, 602, 603, 604, 605, 600):
        selector_id = _lrs_container_id_from_widget_selector()
        if selector_id:
            return selector_id

    prop = _lrs_any_af3_property(
        "LRS.Active.ContainerID", "LRS.Active.ContainerId", "LRS.Active.WidgetContainer",
        "TMDbHelper.WidgetContainer", "TMDBHelper.WidgetContainer",
    )
    prop_id = safe_int(prop)
    if prop_id is not None and prop_id > 0:
        return int(prop_id)

    selector_id = _lrs_container_id_from_widget_selector()
    if selector_id:
        return selector_id

    # Spotlight is the visual item behind Play / More Options.
    if _lrs_safe_cond("Control.IsVisible(301)") or focused in (300, 311, 312):
        return 301
    return None


def af3_button_or_selector_focused() -> bool:
    if not af3_hub_window_active():
        return False
    focused = focused_control_id()
    return focused in (300, 309, 310, 311, 312, 400, 500, 600, 601, 602, 603, 604, 605, 4001, 6001)


def af3_visual_item() -> Dict[str, Any]:
    """Best-effort media item currently drawn by AF3 Home/Hub."""
    if not af3_hub_window_active():
        return {}
    container_id = af3_active_container_id()
    candidates: List[int] = []
    if container_id is not None:
        candidates.append(int(container_id))
    # Fallbacks only after the tracked container. 301 is the spotlight and the
    # 501-510 range covers wall/combined widgets.
    for cid in (301, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510):
        if cid not in candidates:
            candidates.append(cid)
    for cid in candidates:
        item = container_item(cid, 0)
        if valid_library_item(item):
            item["_af3_container"] = str(cid)
            return item
    return {}


# Override old 1102-only helpers so the service can use Home, 1101 and 1102.
def hub_focus_container_item() -> Dict[str, Any]:
    if not af3_hub_window_active():
        return {}
    focused = focused_control_id()
    if focused == 601:
        selector_id = _lrs_container_id_from_widget_selector()
        if selector_id:
            item = container_item(selector_id, 0)
            if valid_library_item(item):
                item["_focused_container"] = str(selector_id)
                return item
    if focused in (301, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 600, 602, 603, 604, 605):
        item = container_item(int(focused), 0)
        if valid_library_item(item):
            item["_focused_container"] = str(focused)
            return item
    return {}


def hub_primary_item() -> Dict[str, Any]:
    if not af3_hub_window_active():
        return {}
    visual = af3_visual_item()
    if valid_library_item(visual):
        return visual
    for container_id in (301, 504, 503, 502, 501, 505, 506, 507, 508, 509, 510):
        item = container_item(container_id, 0)
        if valid_library_item(item):
            item["_fallback_container"] = str(container_id)
            return item
    return {}


def af3_home_action_button_focused() -> bool:
    """Backwards-compatible name, now covers AF3 Home + movie/TV hubs."""
    return af3_button_or_selector_focused()



# -----------------------------------------------------------------------------
# v1.3.79 final overrides: MDBList-only movie/series ratings+awards, slots,
# no WIB, no rating-scale trace, LRS-validated CropV2 screensaver helper.
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 10)

# Disable old rating-scale trace file completely.
def reset_scale_trace_log() -> None:
    try:
        old_path = os.path.join(PROFILE, "rating-scale-trace.log")
        if os.path.exists(old_path):
            os.remove(old_path)
    except Exception:
        pass

def scale_trace(message: str) -> None:
    return None

def _trace_rating_row_before_db(item_key: str, entry: Dict[str, Any], row: Dict[str, Any]) -> None:
    return None

# User-facing DB/report time without WIB suffix.
def now_iso() -> str:
    return datetime.now(timezone(timedelta(hours=7))).replace(microsecond=0).strftime("%Y-%m-%d %H:%M:%S")

# MDBList is the only rating source for movie/series. Episodes remain OMDb+TMDb.
RATING_PROVIDER_PRIORITY = {
    "imdb": ["mdblist", "kodi", "omdb"],
    "tmdb": ["mdblist", "tmdb", "kodi"],
    "rt_critic": ["mdblist", "kodi", "omdb"],
    "rt_audience": ["mdblist", "kodi", "omdb"],
    "metacritic": ["mdblist", "kodi", "omdb"],
    "trakt": ["mdblist", "kodi"],
    "letterboxd": ["mdblist", "kodi"],
    "mdblist": ["mdblist"],
}

FINAL_RATINGS_COLUMNS = [
    "item_key", "title", "imdb", "tmdb", "rottentomatoes", "rottentomatoes_image",
    "rottentomatoes_user", "rottentomatoes_userimage", "metacritic", "trakt", "top250",
    "showtitle", "season", "episode", "year", "series_status", "series_status_date",
    "oscar_wins", "emmy_wins", "awards_text", "imdb_id", "tmdb_id", "dbid", "media_type", "updated_at", "timestamp",
]
SIMPLE_RATING_COLUMNS = FINAL_RATINGS_COLUMNS


def _simple_rating_schema_sql() -> str:
    return """
        CREATE TABLE IF NOT EXISTS ratings (
            item_key TEXT PRIMARY KEY,
            title TEXT,
            imdb TEXT,
            tmdb TEXT,
            rottentomatoes TEXT,
            rottentomatoes_image TEXT,
            rottentomatoes_user TEXT,
            rottentomatoes_userimage TEXT,
            metacritic TEXT,
            trakt TEXT,
            top250 INTEGER,
            showtitle TEXT,
            season INTEGER,
            episode INTEGER,
            year TEXT,
            series_status TEXT,
            series_status_date TEXT,
            oscar_wins INTEGER,
            emmy_wins INTEGER,
            awards_text TEXT,
            imdb_id TEXT,
            tmdb_id TEXT,
            dbid INTEGER,
            media_type TEXT,
            updated_at TEXT,
            timestamp INTEGER
        )
    """


def parse_mdblist_awards_wins(awards_text: Any) -> Dict[str, Any]:
    text = str(awards_text if awards_text is not None else "").strip()
    if not text:
        return {"awards_text": METADATA_NA_VALUE, "oscar_wins": METADATA_NA_VALUE, "emmy_wins": METADATA_NA_VALUE, "updated_at": now_iso()}
    lower = text.lower()
    oscar = 0
    emmy = 0
    # MDBList style: "Won: Best Picture (Oscars, 1973). Plus 1 more Oscar..."
    oscar += len(re.findall(r"\(\s*oscars?\s*,", text, flags=re.I))
    emmy += len(re.findall(r"\(\s*(?:primetime\s+|daytime\s+)?emmys?\s*,", text, flags=re.I))
    for m in re.finditer(r"plus\s+(\d+)\s+more\s+oscars?", lower, flags=re.I):
        oscar += safe_int(m.group(1)) or 0
    for m in re.finditer(r"plus\s+(\d+)\s+more\s+(?:primetime\s+|daytime\s+)?emmys?", lower, flags=re.I):
        emmy += safe_int(m.group(1)) or 0
    # OMDb style fallback if an awards-only fallback uses the same parser.
    oscar += _award_count(r"\bWon\s+(\d+)\s+Oscars?\b", text)
    emmy += _award_count(r"\bWon\s+(\d+)\s+(?:Primetime\s+|Daytime\s+)?Emmys?\b", text)
    return {
        "awards_text": text,
        "oscar_wins": oscar if oscar > 0 else METADATA_NA_VALUE,
        "emmy_wins": emmy if emmy > 0 else METADATA_NA_VALUE,
        "updated_at": now_iso(),
    }


def parse_awards_wins(awards_text: Any) -> Dict[str, Any]:
    # Generic parser now keeps awards_text and supports both OMDb and MDBList text.
    return parse_mdblist_awards_wins(awards_text)


def _awards_needs_fill(awards: Dict[str, Any], media_type: Any) -> bool:
    if media_setting_type(media_type) not in ("movie", "tvshow"):
        return False
    if not bool_setting("scrape_awards_wins", True):
        return False
    if not isinstance(awards, dict) or not awards:
        return True
    if str(awards.get("awards_text") or "").strip():
        return False
    for key in ("oscar_wins", "emmy_wins"):
        value = awards.get(key)
        if _is_metadata_na(value) or (safe_int(value) is not None and safe_int(value) >= 0):
            return False
    return True


def _merge_missing_awards(existing: Dict[str, Any], found: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(existing or {})
    found = dict(found or {})
    if found and "oscar_wins" not in found:
        found["oscar_wins"] = METADATA_NA_VALUE
    if found and "emmy_wins" not in found:
        found["emmy_wins"] = METADATA_NA_VALUE
    for key, value in found.items():
        if value in (None, ""):
            continue
        if key in ("oscar_wins", "emmy_wins"):
            current = merged.get(key)
            if current in (None, "", 0, "0"):
                merged[key] = _metadata_int_or_na(value)
        elif key == "awards_text":
            if not str(merged.get(key) or "").strip():
                merged[key] = str(value)
        elif not str(merged.get(key) or "").strip():
            merged[key] = value
    return merged


def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    ratings = entry.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ids = entry.get("ids") or {}
    series = entry.get("series") or {}
    awards = entry.get("awards") or {}

    rt_critic_cell = _display_number_for_db("rt_critic", ratings.get("rt_critic") or ratings.get("rottentomatoes") or {})
    rt_audience_cell = _display_number_for_db("rt_audience", ratings.get("rt_audience") or ratings.get("rottentomatoes_user") or {})
    metacritic_cell = _display_number_for_db("metacritic", ratings.get("metacritic") or {})
    trakt_cell = _display_number_for_db("trakt", ratings.get("trakt") or {})
    top250_value = _metadata_int_or_na(entry.get("imdb_top250_rank") if "imdb_top250_rank" in entry else entry.get("top250"))
    oscar_value = _metadata_int_or_na(awards.get("oscar_wins") if isinstance(awards, dict) and "oscar_wins" in awards else entry.get("oscar_wins"))
    emmy_value = _metadata_int_or_na(awards.get("emmy_wins") if isinstance(awards, dict) and "emmy_wins" in awards else entry.get("emmy_wins"))
    awards_text = str((awards or {}).get("awards_text") or entry.get("awards_text") or "")
    return (
        str(item_key),
        str(entry.get("title") or ""),
        _display_number_for_db("imdb", ratings.get("imdb") or {}),
        _display_number_for_db("tmdb", ratings.get("tmdb") or {}),
        rt_critic_cell,
        _simple_rating_image("rt_critic", rt_critic_cell),
        rt_audience_cell,
        _simple_rating_image("rt_audience", rt_audience_cell),
        metacritic_cell,
        trakt_cell,
        top250_value,
        str(entry.get("showtitle") or ""),
        safe_int(entry.get("season")),
        safe_int(entry.get("episode")),
        str(entry.get("year") or ""),
        str(series.get("status") or entry.get("series_status") or ""),
        str(series.get("status_date") or entry.get("series_status_date") or ""),
        oscar_value,
        emmy_value,
        awards_text,
        str(ids.get("imdb") or entry.get("imdb") or entry.get("imdbnumber") or ""),
        str(ids.get("tmdb") or entry.get("tmdb") or entry.get("tmdb_id") or ""),
        safe_int(entry.get("dbid")),
        str(entry.get("type") or ""),
        str(entry.get("updated_at") or now_iso()).replace(" WIB", ""),
        safe_int(entry.get("timestamp")) or int(time.time()),
    )


def _ratings_only_row_to_entry(row: sqlite3.Row) -> Dict[str, Any]:
    ids: Dict[str, str] = {}
    imdb_id = str(_row_value(row, "imdb_id") or "").strip()
    tmdb_id = str(_row_value(row, "tmdb_id") or "").strip()
    if imdb_id:
        ids["imdb"] = imdb_id
    if tmdb_id:
        ids["tmdb"] = tmdb_id
    top250_raw = _row_value(row, "top250")
    top250_rank = METADATA_NA_VALUE if _is_metadata_na(top250_raw) else (safe_int(top250_raw) or None)
    entry: Dict[str, Any] = {
        "type": str(_row_value(row, "media_type") or ""),
        "dbid": safe_int(_row_value(row, "dbid")) or 0,
        "title": str(_row_value(row, "title") or ""),
        "updated_at": str(_row_value(row, "updated_at") or "").replace(" WIB", ""),
        "timestamp": safe_int(_row_value(row, "timestamp")) or 0,
        "ids": ids,
        "ratings": _simple_row_to_ratings(row),
        "imdb_top250_rank": top250_rank,
    }
    showtitle = str(_row_value(row, "showtitle") or "")
    if showtitle:
        entry["showtitle"] = showtitle
    season = safe_int(_row_value(row, "season"))
    episode = safe_int(_row_value(row, "episode"))
    if season is not None:
        entry["season"] = season
    if episode is not None:
        entry["episode"] = episode
    year = str(_row_value(row, "year") or "")
    if year:
        entry["year"] = year
    series: Dict[str, Any] = {}
    status = str(_row_value(row, "series_status") or "")
    status_date = str(_row_value(row, "series_status_date") or "")
    if status:
        series["status"] = status
    if status_date:
        series["status_date"] = status_date
    if series:
        entry["series"] = series
    awards: Dict[str, Any] = {}
    for col, key in (("oscar_wins", "oscar_wins"), ("emmy_wins", "emmy_wins")):
        raw = _row_value(row, col)
        if _is_metadata_na(raw):
            awards[key] = METADATA_NA_VALUE
        else:
            parsed = safe_int(raw)
            if parsed is not None:
                awards[key] = int(parsed) if parsed > 0 else METADATA_NA_VALUE
    awards_text = str(_row_value(row, "awards_text") or "").strip()
    if awards_text:
        awards["awards_text"] = awards_text
    if awards:
        entry["awards"] = awards
    return entry


def resolve_item(item: Dict[str, Any], keys: Dict[str, str], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True, include_local: bool = True, ratings_only: bool = False) -> Dict[str, Any]:
    """Strict provider flow v1.3.79.

    Movies/series: MDBList only for rating families and normal awards. OMDb is
    not a fallback here. TMDb is only used for missing identity/status, not as a
    movie/series rating fallback. Episodes remain OMDb + TMDb.
    """
    media_type = media_setting_type(item.get("type"))
    existing = existing if isinstance(existing, dict) else {}
    ratings = preserve_ratings_for_item(media_type, existing.get("ratings") or {}) if missing_only and existing else {}
    ids = dict(existing.get("ids") or {}) if missing_only and existing else {}
    provider_meta: Dict[str, Any] = dict(existing.get("provider_meta") or {}) if missing_only and existing else {}
    series_meta: Dict[str, Any] = dict(existing.get("series") or {}) if missing_only and existing else {}
    awards_meta: Dict[str, Any] = dict(existing.get("awards") or {}) if missing_only and existing else {}

    if include_local:
        local = filter_ratings_for_item(media_type, local_ratings(item))
        for key, row in local.items():
            if key not in ratings:
                ratings[key] = row

    item_ids = extract_ids(item)
    for key, value in item_ids.items():
        if value not in (None, ""):
            ids.setdefault(str(key), str(value))

    errors: List[str] = []
    item_type = item.get("type")
    is_movie_or_show = item_type in ("movie", "tvshow")
    status_missing = False if ratings_only else (item_type == "tvshow" and bool_setting("scrape_tv_status", True) and _series_meta_needs_fill(series_meta))
    awards_missing = False if ratings_only else (bool_setting("scrape_awards_wins", True) and _awards_needs_fill(awards_meta, item_type))

    def current_missing() -> set:
        return record_missing_logicals(media_type, {"ratings": ratings})

    checked_no_value_logicals: set = set()
    missing = current_missing()

    # TMDb identity for MDBList and episode TMDb rating/status only.
    need_tmdb_id_for_mdblist = is_movie_or_show and bool((missing & MDBLIST_PROVIDER_LOGICALS) or awards_missing) and not (ids.get("imdb") or ids.get("tmdb"))
    need_tmdb_episode_rating = item_type == "episode" and "tmdb" in missing
    if bool_setting("use_tmdb", True) and keys.get("tmdb") and (need_tmdb_id_for_mdblist or need_tmdb_episode_rating):
        try:
            found, ids = tmdb_lookup(item, ids, keys["tmdb"])
            if item_type == "episode":
                merge_provider_ratings(ratings, found, media_type, allowed_logicals={"tmdb"}, overwrite=not missing_only)
                # v1.5.7: do not mark episode TMDb as N/A merely because the
                # lookup was attempted. tmdb_lookup() now returns a no-rating
                # row only for a valid TMDb episode payload with empty/zero vote.
                # Transport/provider/search failures stay blank so they can retry.
        except Exception as exc:
            errors.append("tmdb: {0}".format(exc))

    if bool_setting("use_tmdb", True) and keys.get("tmdb") and status_missing:
        try:
            found_series, ids = tmdb_tv_status_lookup(item, ids, keys["tmdb"])
            if found_series:
                series_meta = _merge_missing_series_meta(series_meta, found_series)
        except Exception as exc:
            errors.append("tmdb_status: {0}".format(exc))

    # Movies/series normal scrape: one MDBList hit fills ratings + awards.
    missing = current_missing()
    mdblist_needed = is_movie_or_show and bool((missing & MDBLIST_PROVIDER_LOGICALS) or awards_missing)
    mdblist_ratings_checked = False
    if mdblist_needed:
        if keys.get("__mdblist_limited"):
            raise ProviderLimitReached("MDBList", "All MDBList API keys are limited")
        if not bool_setting("use_mdblist", True):
            errors.append("mdblist: provider disabled")
        elif not keys.get("mdblist"):
            errors.append("mdblist: api key missing")
        else:
            try:
                mdblist_missing_before = set(missing & MDBLIST_PROVIDER_LOGICALS)
                found, meta = mdblist_lookup(ids, "movie" if item_type == "movie" else "show", keys["mdblist"])
                provider_meta["mdblist"] = meta
                if meta.get("limited"):
                    keys["__mdblist_limited"] = "true"
                    raise ProviderLimitReached("MDBList", meta.get("limit_message") or "All MDBList API keys are limited", meta.get("retry_after") or "")
                merge_provider_ratings(ratings, found, media_type, allowed_logicals=MDBLIST_PROVIDER_LOGICALS, overwrite=True)
                mdblist_ratings_checked = mdblist_lookup_cacheable(meta)
                for key, value in (meta.get("ids") or {}).items():
                    if value not in (None, ""):
                        ids.setdefault(str(key), str(value))
                if str(meta.get("awards_text") or "").strip():
                    awards_meta = _merge_missing_awards(awards_meta, parse_mdblist_awards_wins(meta.get("awards_text")))
                elif awards_missing and mdblist_lookup_cacheable(meta):
                    awards_meta = _merge_missing_awards(awards_meta, parse_mdblist_awards_wins(""))
                if mdblist_ratings_checked:
                    checked_no_value_logicals.update(mdblist_missing_before)
            except ProviderLimitReached:
                keys["__mdblist_limited"] = "true"
                raise
            except Exception as exc:
                errors.append("mdblist: {0}".format(exc))

    # Episodes: OMDb IMDb + TMDb episode rating. Movie/series do not use OMDb.
    missing = current_missing()
    omdb_needed = (item_type == "episode") and bool(missing & OMDB_LOGICALS)
    if bool_setting("use_omdb", True) and keys.get("omdb") and omdb_needed:
        try:
            omdb_missing_before = set(missing & OMDB_LOGICALS)
            found, ids, omdb_meta = omdb_lookup(item, ids, keys["omdb"])
            provider_meta["omdb"] = omdb_meta
            found.pop("__awards", None)
            merge_provider_ratings(ratings, found, media_type, allowed_logicals=OMDB_LOGICALS, overwrite=True)
            if omdb_lookup_cacheable(omdb_meta):
                checked_no_value_logicals.update(omdb_missing_before)
        except ProviderLimitReached:
            raise
        except Exception as exc:
            errors.append("omdb: {0}".format(exc))

    remaining_missing = current_missing()
    if checked_no_value_logicals:
        mark_unavailable_ratings(ratings, media_type, remaining_missing & checked_no_value_logicals)

    top250_value = _resolve_top250_rank_for_item(item, ids, existing) if (not ratings_only and rating_enabled(media_type, "top250", True)) else _top250_existing_value(existing or {})
    result = {
        "type": item.get("type"), "dbid": item.get("dbid"), "title": item.get("title") or "",
        "year": item.get("year") or "", "showtitle": item.get("showtitle") or "",
        "season": item.get("season") if item.get("type") == "episode" else None,
        "episode": item.get("episode") if item.get("type") == "episode" else None,
        "ids": ids, "ratings": preserve_ratings_for_item(media_type, ratings), "provider_meta": compact_provider_meta(provider_meta),
        "series": series_meta, "awards": awards_meta,
        "imdb_top250_rank": top250_value if top250_value is not None else 0,
        "errors": errors, "timestamp": int(time.time()), "updated_at": now_iso(),
    }
    # no-repeat markers for normal scrape metadata when provider completed.
    if awards_missing and is_movie_or_show and not str((result.get("awards") or {}).get("awards_text") or "").strip() and not any(str(e).lower().startswith("mdblist:") for e in errors):
        awards = dict(result.get("awards") or {})
        awards.setdefault("awards_text", METADATA_NA_VALUE)
        awards.setdefault("oscar_wins", METADATA_NA_VALUE)
        awards.setdefault("emmy_wins", METADATA_NA_VALUE)
        result["awards"] = awards
    if status_missing and media_type == "tvshow" and not any(str(e).lower().startswith("tmdb_status:") for e in errors):
        series = dict(result.get("series") or {})
        if not str(series.get("status") or "").strip():
            series["status"] = METADATA_NA_VALUE
        if not str(series.get("status_date") or "").strip():
            series["status_date"] = METADATA_NA_VALUE
        result["series"] = series
    return result


def resolve_awards_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    media_type = media_setting_type((item or {}).get("type"))
    existing = dict(existing or {})
    if media_type not in ("movie", "tvshow"):
        return existing
    if not _awards_needs_fill(existing.get("awards") or {}, media_type):
        return existing
    ids = dict(existing.get("ids") or {})
    for key, value in extract_ids(item).items():
        if value not in (None, ""):
            ids.setdefault(str(key), str(value))
    awards = dict(existing.get("awards") or {})
    provider_meta = dict(existing.get("provider_meta") or {})
    errors: List[str] = []
    mdblist_limited = bool(keys.get("__mdblist_limited"))
    if not mdblist_limited and bool_setting("use_mdblist", True) and keys.get("mdblist"):
        try:
            _found, meta = mdblist_lookup(ids, "movie" if media_type == "movie" else "show", keys["mdblist"])
            provider_meta["mdblist"] = meta
            if meta.get("limited"):
                keys["__mdblist_limited"] = "true"
                mdblist_limited = True
                errors.append("mdblist: API limit reached; awards-only OMDb fallback allowed")
            elif str(meta.get("awards_text") or "").strip():
                awards = _merge_missing_awards(awards, parse_mdblist_awards_wins(meta.get("awards_text")))
            elif mdblist_lookup_cacheable(meta):
                awards = _merge_missing_awards(awards, parse_mdblist_awards_wins(""))
            for key, value in (meta.get("ids") or {}).items():
                if value not in (None, ""):
                    ids.setdefault(str(key), str(value))
        except ProviderLimitReached:
            keys["__mdblist_limited"] = "true"
            mdblist_limited = True
        except Exception as exc:
            errors.append("mdblist: {0}".format(exc))
    if _awards_needs_fill(awards, media_type) and mdblist_limited and bool_setting("use_omdb", True) and keys.get("omdb"):
        try:
            found, ids, omdb_meta = omdb_lookup(item, ids, keys["omdb"])
            provider_meta["omdb"] = omdb_meta
            found_awards = found.pop("__awards", {}) if isinstance(found, dict) else {}
            if found_awards:
                awards = _merge_missing_awards(awards, found_awards)
        except ProviderLimitReached:
            raise
        except Exception as exc:
            errors.append("omdb: {0}".format(exc))
    if _awards_needs_fill(awards, media_type) and (provider_meta.get("mdblist") or provider_meta.get("omdb")):
        awards = _merge_missing_awards(awards, parse_mdblist_awards_wins(""))
    entry = dict(existing or {})
    entry.setdefault("type", item.get("type"))
    entry.setdefault("dbid", item.get("dbid"))
    entry.setdefault("title", item.get("title") or "")
    entry.setdefault("year", item.get("year") or "")
    entry["ids"] = ids
    entry["awards"] = awards
    entry["provider_meta"] = provider_meta
    entry["errors"] = errors
    entry["updated_at"] = now_iso()
    entry["timestamp"] = int(time.time())
    return entry


def _rating_setting_choice(name: str, default: str) -> str:
    try:
        value = ADDON.getSetting(name).strip().lower()
    except Exception:
        value = ""
    return value or default


def _rating_slot_order() -> List[str]:
    defaults = ["imdb", "rt_audience", "rt_critic", "metacritic", "tmdb"]
    out: List[str] = []
    for idx, default in enumerate(defaults, start=1):
        value = _rating_setting_choice("display_rating_slot_{0}".format(idx), default)
        if value in ("none", ""):
            continue
        if value not in ("imdb", "rt_audience", "rt_critic", "metacritic", "tmdb"):
            value = default
        if value not in out:
            out.append(value)
    return out


def _slot_source_value(record: Dict[str, Any], logical: str, ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> Optional[Dict[str, str]]:
    if logical == "imdb":
        value = display_decimal(first_rating(ratings, "imdb"))
        if not value:
            return None
        label = value + (" #{0}".format(top250_display) if top250_display else "")
        return {"Source": "imdb", "Icon": "flags/$VAR[Color_Directory]/ratings/imdb.png", "Label": label, "Value": value}
    if logical == "tmdb":
        value = display_decimal(first_rating(ratings, "tmdb"))
        if not value:
            return None
        return {"Source": "tmdb", "Icon": "flags/$VAR[Color_Directory]/ratings/tmdb.png", "Label": value, "Value": value}
    if logical == "rt_audience":
        value = display_rt_percent(first_rating(ratings, "rt_audience"))
        if not value:
            return None
        icon = icons.get("audience") or "popcorn.png"
        return {"Source": "rt_audience", "Icon": "flags/$VAR[Color_Directory]/ratings/{0}".format(icon), "Label": "{0}%".format(value), "Value": value}
    if logical == "rt_critic":
        value = display_rt_percent(first_rating(ratings, "rt_critic"))
        if not value:
            return None
        icon = icons.get("critic") or "rtfresh.png"
        return {"Source": "rt_critic", "Icon": "flags/$VAR[Color_Directory]/ratings/{0}".format(icon), "Label": "{0}%".format(value), "Value": value}
    if logical == "metacritic":
        value = display_percent(first_rating(ratings, "metacritic"))
        if not value:
            return None
        return {"Source": "metacritic", "Icon": "flags/$VAR[Color_Directory]/ratings/metacritic.png", "Label": value, "Value": value}
    return None


def _slot_values_for_record(record: Dict[str, Any], ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> List[Dict[str, str]]:
    media_type = media_setting_type(record.get("type"))
    if media_type == "episode":
        out = []
        for logical in ("imdb", "tmdb"):
            row = _slot_source_value(record, logical, ratings, icons, top250_display)
            if row:
                out.append(row)
        return out[:2]
    order = _rating_slot_order()
    count = max(1, min(5, int_setting("display_rating_slot_count", 7)))
    fill_empty = bool_setting("display_fill_empty_slots", True)
    if fill_empty:
        candidates = order
    else:
        candidates = order[:count]
    out: List[Dict[str, str]] = []
    for logical in candidates:
        row = _slot_source_value(record, logical, ratings, icons, top250_display)
        if row:
            out.append(row)
        if len(out) >= count:
            break
    return out


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    ratings = record.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ratings = preserve_ratings_for_item(record.get("type"), ratings)
    critic_rating = first_rating(ratings, "rt_critic")
    audience_rating = first_rating(ratings, "rt_audience")
    critic_display = display_rt_percent(critic_rating)
    audience_display = display_rt_percent(audience_rating)
    imdb_display = display_decimal(first_rating(ratings, "imdb"))
    tmdb_display = display_decimal(first_rating(ratings, "tmdb"))
    metacritic_display = display_percent(first_rating(ratings, "metacritic"))
    trakt_display = display_percent(first_rating(ratings, "trakt"))
    rt_images = record.get("rt_images") if isinstance(record.get("rt_images"), dict) else {}
    rt_image_key = str(rt_images.get("critic") or "").strip()
    rt_user_image_key = str(rt_images.get("audience") or "").strip()
    rt_image = _lrs_rt_file(rt_image_key, critic_display)
    rt_audience_image = _lrs_audience_file(rt_user_image_key, audience_display)
    top250_rank = safe_int(record.get("imdb_top250_rank"))
    top250_display = str(top250_rank) if top250_rank and top250_rank > 0 else ""
    top250_hash_display = "#{0}".format(top250_rank) if top250_display else ""
    values = {
        "HasData": "true", "DBType": str(record.get("type") or ""), "Title": str(record.get("title") or ""), "Year": str(record.get("year") or ""),
        "IMDb_Rating": imdb_display, "IMDB_Rating": imdb_display, "IMDb": imdb_display, "IMDB": imdb_display, "imdb": imdb_display, "imdb_rating": imdb_display,
        "Top250": top250_display, "Top250_Rank": top250_hash_display, "top250": top250_display, "top250_rank": top250_hash_display,
        "TMDb_Rating": tmdb_display, "TMDB_Rating": tmdb_display, "TMDb": tmdb_display, "TMDB": tmdb_display, "tmdb": tmdb_display, "tmdb_rating": tmdb_display,
        "RottenTomatoes_Rating": critic_display, "RottenTomatoes": critic_display, "RottenTomatoes_UserMeter": audience_display, "RottenTomatoes_User": audience_display,
        "rottentomatoes": critic_display, "rottentomatoes_user": audience_display, "MetaCritic_Rating": metacritic_display, "Trakt_Rating": trakt_display,
        "RottenTomatoesIcon": rt_image, "RottenTomatoesImage": rt_image, "RottenTomatoes_Image": rt_image, "RottenTomatoes_ImageKey": rt_image_key,
        "RottenTomatoesAudienceIcon": rt_audience_image, "RottenTomatoesAudienceImage": rt_audience_image, "RottenTomatoes_UserImage": rt_audience_image, "RottenTomatoes_UserImageKey": rt_user_image_key,
        "Source": "script.library.ratings.scraper",
    }
    slots = _slot_values_for_record(record, ratings, {"critic": rt_image, "audience": rt_audience_image}, top250_display)
    for idx in range(1, 6):
        if idx <= len(slots):
            row = slots[idx - 1]
            values["RatingSlot{0}_Source".format(idx)] = row.get("Source", "")
            values["RatingSlot{0}_Icon".format(idx)] = row.get("Icon", "")
            values["RatingSlot{0}_Label".format(idx)] = row.get("Label", "")
            values["RatingSlot{0}_Value".format(idx)] = row.get("Value", "")
    awards = record.get("awards") or {}
    if isinstance(awards, dict):
        oscar_wins = safe_int(awards.get("oscar_wins")); emmy_wins = safe_int(awards.get("emmy_wins"))
        if oscar_wins and oscar_wins > 0:
            values["Oscar_Wins"] = str(oscar_wins); values["OscarWins"] = str(oscar_wins)
        if emmy_wins and emmy_wins > 0:
            values["Emmy_Wins"] = str(emmy_wins); values["EmmyWins"] = str(emmy_wins)
    series = record.get("series") or {}
    if record.get("type") in ("tvshow", "season") and isinstance(series, dict):
        status = str(series.get("status") or "").strip()
        status_date = str(series.get("status_date") or "").strip()
        status_date_display = str(series.get("status_date_display") or _date_display(status_date)).strip()
        if status and not _is_metadata_na(status):
            label = _lrs_series_status_label_1537(status)
            values.update({"Status": status, "StatusDate": status_date_display, "Series_Status": status, "Series_StatusDate": status_date_display, "SeriesStatus": status, "SeriesStatusDate": status_date_display, "Series_StatusLabel": label, "SeriesStatusLabel": label})
    values.update(lrs_display_flags())
    values["Display_RatingSlots"] = "true"
    return {key: str(value) for key, value in values.items() if value not in (None, "")}

# Ensure new slot and screensaver properties are cleared/published.
_slot_names = []
for _idx in range(1, 6):
    for _suffix in ("Source", "Icon", "Label", "Value"):
        _slot_names.append("RatingSlot{0}_{1}".format(_idx, _suffix))
LRS_EXTRA_PROPERTY_NAMES = tuple(dict.fromkeys(tuple(LRS_EXTRA_PROPERTY_NAMES) + tuple(_slot_names) + (
    "Display_RatingSlots", "CropV2Image", "ClearLogoMode", "CropV2Source", "CropV2Title", "DefaultClearLogo",
)))

_LAST_SCREENSAVER_CLEARLOGO_LOG = ""

def _tmdbhelper_crop_candidates() -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    pairs = (
        ("TMDbHelper.ListITem", "Window(Home).Property(TMDbHelper.ListITem.CropImage)", "Window(Home).Property(TMDbHelper.ListITem.Title)"),
        ("TMDbHelper.ListItem", "Window(Home).Property(TMDbHelper.ListItem.CropImage)", "Window(Home).Property(TMDbHelper.ListItem.Title)"),
        ("TMDbHelper.ListItem.Current", "Window(Home).Property(TMDbHelper.ListItem.Current.CropImage)", "Window(Home).Property(TMDbHelper.ListItem.Current.Title)"),
    )
    for source, img_label, title_label in pairs:
        try:
            image = xbmc.getInfoLabel(img_label).strip()
            title = xbmc.getInfoLabel(title_label).strip()
        except Exception:
            image, title = "", ""
        if image:
            out.append({"source": source, "image": image, "title": title})
    return out


def update_screensaver_clearlogo_properties(item: Dict[str, Any]) -> Dict[str, str]:
    """Publish LRS-validated CropV2 image selection for Arctic Mirage.

    Detection uses the current screensaver item identity/title. The actual image
    is still TMDbHelper CropV2 when it matches; otherwise XML falls back to Kodi
    Container(1297).ListItem.Art(clearlogo).
    """
    try:
        import xbmcgui  # pylint: disable=import-outside-toplevel
        home = xbmcgui.Window(10000)
    except Exception:
        return {}
    try:
        item_title = str((item or {}).get("title") or xbmc.getInfoLabel("Container(1297).ListItem.Title") or "").strip()
        default_logo = xbmc.getInfoLabel("Container(1297).ListItem.Art(clearlogo)").strip()
    except Exception:
        item_title, default_logo = str((item or {}).get("title") or ""), ""
    chosen = {"image": "", "source": "", "title": ""}
    item_norm = _norm_text(item_title)
    for cand in _tmdbhelper_crop_candidates():
        cand_title = str(cand.get("title") or "").strip()
        if cand.get("image") and item_norm and _norm_text(cand_title) == item_norm:
            chosen = cand
            break
    mode = "cropv2" if chosen.get("image") else ("default_kodi" if default_logo else "title")
    props = {
        "CropV2Image": str(chosen.get("image") or ""),
        "CropV2Source": str(chosen.get("source") or ""),
        "CropV2Title": str(chosen.get("title") or ""),
        "DefaultClearLogo": default_logo,
        "ClearLogoMode": mode,
    }
    for key, value in props.items():
        _publish_property(home, AF3_PREFIX + "Screensaver." + key, str(value or ""))
    global _LAST_SCREENSAVER_CLEARLOGO_LOG
    sig = "{0}|{1}|{2}|{3}".format(mode, item_title, chosen.get("image") or "", default_logo)
    if sig != _LAST_SCREENSAVER_CLEARLOGO_LOG:
        _LAST_SCREENSAVER_CLEARLOGO_LOG = sig
        log("LRS SCREENSAVER CLEARLOGO mode={0} title={1} crop_source={2} crop_title={3} has_default={4}".format(
            mode, item_title[:80], chosen.get("source") or "", str(chosen.get("title") or "")[:80], "yes" if default_logo else "no"
        ), xbmc.LOGINFO)
    return props


def clear_screensaver_clearlogo_properties() -> None:
    try:
        import xbmcgui  # pylint: disable=import-outside-toplevel
        home = xbmcgui.Window(10000)
        for key in ("CropV2Image", "CropV2Source", "CropV2Title", "DefaultClearLogo", "ClearLogoMode"):
            _publish_property(home, AF3_PREFIX + "Screensaver." + key, "")
    except Exception:
        pass


# -----------------------------------------------------------------------------
# v1.3.80 final overrides: slot 6, Trakt slot, display-only settings cleanup,
# publish log de-spam, stronger CropV2 candidate detection.
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 11)

# Keep old display flags for backward XML compatibility. Removed settings default
# to true except awards/status, which still exist in settings.
def lrs_display_flags() -> Dict[str, str]:
    flags = {}
    for label, setting in LRS_DISPLAY_SETTINGS:
        default = True
        flags["Display_" + label] = "true" if bool_setting(setting, default) else "false"
    return flags


def _rating_slot_order() -> List[str]:
    defaults = ["imdb", "rt_audience", "rt_critic", "metacritic", "tmdb", "trakt", "letterboxd"]
    allowed = set(defaults + ["none"])
    out: List[str] = []
    for idx, default in enumerate(defaults, start=1):
        value = _rating_setting_choice("display_rating_slot_{0}".format(idx), default)
        if value not in allowed:
            value = default
        if value in ("none", ""):
            continue
        # Do not show the same logical source twice.
        if value not in out:
            out.append(value)
    return out


def _slot_source_value(record: Dict[str, Any], logical: str, ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> Optional[Dict[str, str]]:
    if logical == "imdb":
        value = display_decimal(first_rating(ratings, "imdb"))
        if not value:
            return None
        label = value + (" #{0}".format(top250_display) if top250_display else "")
        return {"Source": "imdb", "Icon": "flags/$VAR[Color_Directory]/ratings/imdb.png", "Label": label, "Value": value}
    if logical == "tmdb":
        value = display_decimal(first_rating(ratings, "tmdb"))
        if not value:
            return None
        return {"Source": "tmdb", "Icon": "flags/$VAR[Color_Directory]/ratings/tmdb.png", "Label": value, "Value": value}
    if logical == "rt_audience":
        value = display_rt_percent(first_rating(ratings, "rt_audience"))
        if not value:
            return None
        icon = icons.get("audience") or "popcorn.png"
        return {"Source": "rt_audience", "Icon": "flags/$VAR[Color_Directory]/ratings/{0}".format(icon), "Label": "{0}%".format(value), "Value": value}
    if logical == "rt_critic":
        value = display_rt_percent(first_rating(ratings, "rt_critic"))
        if not value:
            return None
        icon = icons.get("critic") or "rtfresh.png"
        return {"Source": "rt_critic", "Icon": "flags/$VAR[Color_Directory]/ratings/{0}".format(icon), "Label": "{0}%".format(value), "Value": value}
    if logical == "metacritic":
        value = display_percent(first_rating(ratings, "metacritic"))
        if not value:
            return None
        return {"Source": "metacritic", "Icon": "flags/$VAR[Color_Directory]/ratings/metacritic.png", "Label": value, "Value": value}
    if logical == "trakt":
        value = display_percent(first_rating(ratings, "trakt"))
        if not value:
            return None
        return {"Source": "trakt", "Icon": "flags/$VAR[Color_Directory]/ratings/trakt.png", "Label": value, "Value": value}
    return None


def _slot_values_for_record(record: Dict[str, Any], ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> List[Dict[str, str]]:
    media_type = media_setting_type(record.get("type"))
    if media_type == "episode":
        out = []
        for logical in ("imdb", "tmdb"):
            row = _slot_source_value(record, logical, ratings, icons, top250_display)
            if row:
                out.append(row)
        return out[:2]
    order = _rating_slot_order()
    count = max(1, min(7, int_setting("display_rating_slot_count", 7)))
    fill_empty = bool_setting("display_fill_empty_slots", True)
    candidates = order if fill_empty else order[:count]
    out: List[Dict[str, str]] = []
    for logical in candidates:
        row = _slot_source_value(record, logical, ratings, icons, top250_display)
        if row:
            out.append(row)
        if len(out) >= count:
            break
    return out


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    ratings = record.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ratings = preserve_ratings_for_item(record.get("type"), ratings)
    critic_rating = first_rating(ratings, "rt_critic")
    audience_rating = first_rating(ratings, "rt_audience")
    critic_display = display_rt_percent(critic_rating)
    audience_display = display_rt_percent(audience_rating)
    imdb_display = display_decimal(first_rating(ratings, "imdb"))
    tmdb_display = display_decimal(first_rating(ratings, "tmdb"))
    metacritic_display = display_percent(first_rating(ratings, "metacritic"))
    trakt_display = display_percent(first_rating(ratings, "trakt"))
    rt_images = record.get("rt_images") if isinstance(record.get("rt_images"), dict) else {}
    rt_image_key = str(rt_images.get("critic") or "").strip()
    rt_user_image_key = str(rt_images.get("audience") or "").strip()
    rt_image = _lrs_rt_file(rt_image_key, critic_display)
    rt_audience_image = _lrs_audience_file(rt_user_image_key, audience_display)
    top250_rank = safe_int(record.get("imdb_top250_rank"))
    top250_display = str(top250_rank) if top250_rank and top250_rank > 0 else ""
    top250_hash_display = "#{0}".format(top250_rank) if top250_display else ""
    values = {
        "HasData": "true", "DBType": str(record.get("type") or ""), "Title": str(record.get("title") or ""), "Year": str(record.get("year") or ""),
        "IMDb_Rating": imdb_display, "IMDB_Rating": imdb_display, "IMDb": imdb_display, "IMDB": imdb_display, "imdb": imdb_display, "imdb_rating": imdb_display,
        "Top250": top250_display, "Top250_Rank": top250_hash_display, "top250": top250_display, "top250_rank": top250_hash_display,
        "TMDb_Rating": tmdb_display, "TMDB_Rating": tmdb_display, "TMDb": tmdb_display, "TMDB": tmdb_display, "tmdb": tmdb_display, "tmdb_rating": tmdb_display,
        "RottenTomatoes_Rating": critic_display, "RottenTomatoes": critic_display, "RottenTomatoes_UserMeter": audience_display, "RottenTomatoes_User": audience_display,
        "rottentomatoes": critic_display, "rottentomatoes_user": audience_display, "MetaCritic_Rating": metacritic_display, "Trakt_Rating": trakt_display,
        "RottenTomatoesIcon": rt_image, "RottenTomatoesImage": rt_image, "RottenTomatoes_Image": rt_image, "RottenTomatoes_ImageKey": rt_image_key,
        "RottenTomatoes_CriticImage": rt_image, "RottenTomatoesCriticImage": rt_image, "rottentomatoes_image": rt_image,
        "RottenTomatoesAudienceIcon": rt_audience_image, "RottenTomatoesAudienceImage": rt_audience_image, "RottenTomatoesAudience_Image": rt_audience_image,
        "RottenTomatoes_UserImage": rt_audience_image, "RottenTomatoes_UserImageKey": rt_user_image_key, "RottenTomatoesUserImage": rt_audience_image,
        "rottentomatoes_userimage": rt_audience_image,
        "Source": "script.library.ratings.scraper",
    }
    slots = _slot_values_for_record(record, ratings, {"critic": rt_image, "audience": rt_audience_image}, top250_display)
    for idx in range(1, 8):
        if idx <= len(slots):
            row = slots[idx - 1]
            values["RatingSlot{0}_Source".format(idx)] = row.get("Source", "")
            values["RatingSlot{0}_Icon".format(idx)] = row.get("Icon", "")
            values["RatingSlot{0}_Label".format(idx)] = row.get("Label", "")
            values["RatingSlot{0}_Value".format(idx)] = row.get("Value", "")
    awards = record.get("awards") or {}
    if isinstance(awards, dict):
        oscar_wins = safe_int(awards.get("oscar_wins")); emmy_wins = safe_int(awards.get("emmy_wins"))
        if oscar_wins and oscar_wins > 0:
            values["Oscar_Wins"] = str(oscar_wins); values["OscarWins"] = str(oscar_wins)
        if emmy_wins and emmy_wins > 0:
            values["Emmy_Wins"] = str(emmy_wins); values["EmmyWins"] = str(emmy_wins)
    series = record.get("series") or {}
    if record.get("type") in ("tvshow", "season") and isinstance(series, dict):
        status = str(series.get("status") or "").strip()
        status_date = str(series.get("status_date") or "").strip()
        status_date_display = str(series.get("status_date_display") or _date_display(status_date)).strip()
        if status and not _is_metadata_na(status):
            label = _lrs_series_status_label_1537(status)
            values.update({"Status": status, "StatusDate": status_date_display, "Series_Status": status, "Series_StatusDate": status_date_display, "SeriesStatus": status, "SeriesStatusDate": status_date_display, "Series_StatusLabel": label, "SeriesStatusLabel": label})
    values.update(lrs_display_flags())
    values["Display_RatingSlots"] = "true"
    return {key: str(value) for key, value in values.items() if value not in (None, "")}

# Extend clear/publish property list for slot 6.
_slot_names_1380 = []
for _idx in range(1, 8):
    for _suffix in ("Source", "Icon", "Label", "Value"):
        _slot_names_1380.append("RatingSlot{0}_{1}".format(_idx, _suffix))
LRS_EXTRA_PROPERTY_NAMES = tuple(dict.fromkeys(tuple(LRS_EXTRA_PROPERTY_NAMES) + tuple(_slot_names_1380)))

_LAST_LRS_PUBLISH_LOG_SIG = ""
def _lrs_log_publish_values(context: str, record: Dict[str, Any], values: Dict[str, str]) -> None:
    if not bool_setting("debug_logging", False):
        return
    global _LAST_LRS_PUBLISH_LOG_SIG
    try:
        sig = "{0}|{1}|{2}|{3}|{4}|{5}|{6}|{7}|{8}|{9}".format(
            context, record.get("type") or "", record.get("dbid") or "", record.get("title") or "",
            values.get("RatingSlot1_Label", ""), values.get("RatingSlot2_Label", ""), values.get("RatingSlot3_Label", ""),
            values.get("RatingSlot4_Label", ""), values.get("RatingSlot5_Label", ""), values.get("RatingSlot6_Label", ""),
            values.get("RatingSlot7_Label", ""),
        )
        if sig == _LAST_LRS_PUBLISH_LOG_SIG:
            return
        _LAST_LRS_PUBLISH_LOG_SIG = sig
        log("LRS PUBLISH {0} {1}|{2} title={3} slots=[{4}, {5}, {6}, {7}, {8}, {9}, {10}] status={11}".format(
            context, record.get("type") or "", record.get("dbid") or "", str(record.get("title") or "")[:80],
            values.get("RatingSlot1_Label", ""), values.get("RatingSlot2_Label", ""), values.get("RatingSlot3_Label", ""),
            values.get("RatingSlot4_Label", ""), values.get("RatingSlot5_Label", ""), values.get("RatingSlot6_Label", ""),
            values.get("RatingSlot7_Label", ""), values.get("Series_StatusLabel", ""),
        ), xbmc.LOGINFO)
    except Exception:  # pylint: disable=broad-except
        pass


def _tmdbhelper_crop_candidates() -> List[Dict[str, str]]:
    out: List[Dict[str, str]] = []
    prefixes = (
        "TMDbHelper.ListITem", "TMDbHelper.ListItem", "TMDbHelper.ListITem.Current", "TMDbHelper.ListItem.Current",
        "TMDbHelper.Player", "TMDbHelper.VideoPlayer",
    )
    for prefix in prefixes:
        for image_key in ("CropImage", "CropImage.CropV2", "CropV2Image"):
            try:
                image = xbmc.getInfoLabel("Window(Home).Property({0}.{1})".format(prefix, image_key)).strip()
                title = xbmc.getInfoLabel("Window(Home).Property({0}.Title)".format(prefix)).strip()
            except Exception:
                image, title = "", ""
            if image:
                out.append({"source": prefix + "." + image_key, "image": image, "title": title})
    return out


def update_screensaver_clearlogo_properties(item: Dict[str, Any]) -> Dict[str, str]:
    try:
        import xbmcgui  # pylint: disable=import-outside-toplevel
        home = xbmcgui.Window(10000)
    except Exception:
        return {}
    try:
        item_title = str((item or {}).get("title") or xbmc.getInfoLabel("Container(1297).ListItem.Title") or "").strip()
        default_logo = xbmc.getInfoLabel("Container(1297).ListItem.Art(clearlogo)").strip()
    except Exception:
        item_title, default_logo = str((item or {}).get("title") or ""), ""
    chosen = {"image": "", "source": "", "title": ""}
    item_norm = _norm_text(item_title)
    candidates = _tmdbhelper_crop_candidates()
    for cand in candidates:
        cand_title = str(cand.get("title") or "").strip()
        if cand.get("image") and item_norm and cand_title and _norm_text(cand_title) == item_norm:
            chosen = cand
            break
    # Fallback: some TMDbHelper builds publish CropImage without Title. Use it
    # only when there is exactly one candidate and the screensaver has an item.
    if not chosen.get("image") and item_norm and len(candidates) == 1 and not str(candidates[0].get("title") or "").strip():
        chosen = candidates[0]
    mode = "cropv2" if chosen.get("image") else ("default_kodi" if default_logo else "title")
    props = {
        "CropV2Image": str(chosen.get("image") or ""),
        "CropV2Source": str(chosen.get("source") or ""),
        "CropV2Title": str(chosen.get("title") or ""),
        "DefaultClearLogo": default_logo,
        "ClearLogoMode": mode,
    }
    for key, value in props.items():
        _publish_property(home, AF3_PREFIX + "Screensaver." + key, str(value or ""))
    global _LAST_SCREENSAVER_CLEARLOGO_LOG
    sig = "{0}|{1}|{2}|{3}".format(mode, item_title, chosen.get("image") or "", default_logo)
    if sig != _LAST_SCREENSAVER_CLEARLOGO_LOG:
        _LAST_SCREENSAVER_CLEARLOGO_LOG = sig
        log("LRS SCREENSAVER CLEARLOGO mode={0} title={1} crop_source={2} crop_title={3} has_default={4}".format(
            mode, item_title[:80], chosen.get("source") or "", str(chosen.get("title") or "")[:80], "yes" if default_logo else "no"
        ), xbmc.LOGINFO)
    return props


# -----------------------------------------------------------------------------
# v1.3.81 final overrides: clean settings, always scrape needed data, icon files.
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 12)

# Settings removed from the UI must not keep old false values from userdata.
_bool_setting_1381_base = bool_setting
_FORCE_TRUE_SETTINGS_1381 = {
    "use_mdblist", "use_tmdb", "use_omdb",
    "rating_imdb", "rating_tmdb", "rating_rt_critic", "rating_rt_audience", "rating_metacritic", "rating_trakt", "rating_top250",
    "scrape_tv_status", "scrape_awards_wins",
    "display_awards", "display_tv_status",
    "display_imdb", "display_tmdb", "display_rt_critic", "display_rt_audience", "display_metacritic", "display_trakt", "display_top250",
    "publish_af3_cache",
}
_FORCE_FALSE_SETTINGS_1381 = {"publish_tmdbhelper_compat"}

def bool_setting(name: str, default: bool = False) -> bool:
    if name in _FORCE_TRUE_SETTINGS_1381:
        return True
    if name in _FORCE_FALSE_SETTINGS_1381:
        return False
    return _bool_setting_1381_base(name, default)


def rating_enabled(media_type: Any, logical: str, default: bool = True) -> bool:
    # Rating/source checkboxes no longer exist. Scrape all needed cached data.
    return True


def lrs_display_flags() -> Dict[str, str]:
    # Display toggles for awards/status were removed. If data exists, XML may show it.
    return {"Display_" + label: "true" for label, _setting in LRS_DISPLAY_SETTINGS}


def tmdbhelper_compat_enabled() -> bool:
    # Never publish LRS values back into TMDbHelper namespace by default. Native AF3
    # TMDbHelper rows must stay separate and are disabled by the XML patcher.
    return False


def _awards_needs_fill(awards: Dict[str, Any], media_type: Any) -> bool:
    if media_setting_type(media_type) not in ("movie", "tvshow"):
        return False
    if not isinstance(awards, dict) or not awards:
        return True
    if str(awards.get("awards_text") or "").strip() and not _is_metadata_na(awards.get("awards_text")):
        return False
    for key in ("oscar_wins", "emmy_wins"):
        value = awards.get(key)
        if _is_metadata_na(value) or (safe_int(value) is not None and safe_int(value) >= 0):
            return False
    return True


def _rating_slot_order() -> List[str]:
    defaults = ["imdb", "rt_audience", "rt_critic", "metacritic", "tmdb", "trakt", "letterboxd"]
    allowed = set(defaults + ["none"])
    out: List[str] = []
    for idx, default in enumerate(defaults, start=1):
        value = _rating_setting_choice("display_rating_slot_{0}".format(idx), default)
        if value not in allowed:
            value = default
        if value in ("none", ""):
            continue
        if value not in out:
            out.append(value)
    return out


def _slot_source_value(record: Dict[str, Any], logical: str, ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> Optional[Dict[str, str]]:
    # IconFile is only the filename. XML builds flags/$VAR[Color_Directory]/ratings/<file>
    # itself so Kodi expands $VAR correctly. Do not publish paths containing $VAR.
    if logical == "imdb":
        value = display_decimal(first_rating(ratings, "imdb"))
        if not value:
            return None
        label = value + (" #{0}".format(top250_display) if top250_display else "")
        return {"Source": "imdb", "IconFile": "imdb.png", "Icon": "imdb.png", "Label": label, "Value": value}
    if logical == "tmdb":
        value = display_decimal(first_rating(ratings, "tmdb"))
        if not value:
            return None
        return {"Source": "tmdb", "IconFile": "tmdb.png", "Icon": "tmdb.png", "Label": value, "Value": value}
    if logical == "rt_audience":
        value = display_rt_percent(first_rating(ratings, "rt_audience"))
        if not value:
            return None
        icon = icons.get("audience") or "popcorn.png"
        return {"Source": "rt_audience", "IconFile": icon, "Icon": icon, "Label": "{0}%".format(value), "Value": value}
    if logical == "rt_critic":
        value = display_rt_percent(first_rating(ratings, "rt_critic"))
        if not value:
            return None
        icon = icons.get("critic") or "rtfresh.png"
        return {"Source": "rt_critic", "IconFile": icon, "Icon": icon, "Label": "{0}%".format(value), "Value": value}
    if logical == "metacritic":
        value = display_percent(first_rating(ratings, "metacritic"))
        if not value:
            return None
        return {"Source": "metacritic", "IconFile": "metacritic.png", "Icon": "metacritic.png", "Label": value, "Value": value}
    if logical == "trakt":
        value = display_percent(first_rating(ratings, "trakt"))
        if not value:
            return None
        return {"Source": "trakt", "IconFile": "trakt.png", "Icon": "trakt.png", "Label": value, "Value": value}
    return None


def _slot_values_for_record(record: Dict[str, Any], ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> List[Dict[str, str]]:
    media_type = media_setting_type(record.get("type"))
    if media_type == "episode":
        out: List[Dict[str, str]] = []
        for logical in ("imdb", "tmdb"):
            row = _slot_source_value(record, logical, ratings, icons, top250_display)
            if row:
                out.append(row)
        return out[:2]
    order = _rating_slot_order()
    count = max(1, min(7, int_setting("display_rating_slot_count", 7)))
    fill_empty = bool_setting("display_fill_empty_slots", True)
    candidates = order if fill_empty else order[:count]
    out: List[Dict[str, str]] = []
    for logical in candidates:
        row = _slot_source_value(record, logical, ratings, icons, top250_display)
        if row:
            out.append(row)
        if len(out) >= count:
            break
    return out


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    ratings = record.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ratings = preserve_ratings_for_item(record.get("type"), ratings)
    critic_rating = first_rating(ratings, "rt_critic")
    audience_rating = first_rating(ratings, "rt_audience")
    critic_display = display_rt_percent(critic_rating)
    audience_display = display_rt_percent(audience_rating)
    imdb_display = display_decimal(first_rating(ratings, "imdb"))
    tmdb_display = display_decimal(first_rating(ratings, "tmdb"))
    metacritic_display = display_percent(first_rating(ratings, "metacritic"))
    trakt_display = display_percent(first_rating(ratings, "trakt"))
    rt_images = record.get("rt_images") if isinstance(record.get("rt_images"), dict) else {}
    rt_image_key = str(rt_images.get("critic") or "").strip()
    rt_user_image_key = str(rt_images.get("audience") or "").strip()
    rt_image = _lrs_rt_file(rt_image_key, critic_display)
    rt_audience_image = _lrs_audience_file(rt_user_image_key, audience_display)
    top250_rank = safe_int(record.get("imdb_top250_rank"))
    top250_display = str(top250_rank) if top250_rank and top250_rank > 0 else ""
    top250_hash_display = "#{0}".format(top250_rank) if top250_display else ""
    values = {
        "HasData": "true", "DBType": str(record.get("type") or ""), "Title": str(record.get("title") or ""), "Year": str(record.get("year") or ""),
        "IMDb_Rating": imdb_display, "IMDB_Rating": imdb_display, "IMDb": imdb_display, "IMDB": imdb_display, "imdb": imdb_display, "imdb_rating": imdb_display,
        "Top250": top250_display, "Top250_Rank": top250_hash_display, "top250": top250_display, "top250_rank": top250_hash_display,
        "TMDb_Rating": tmdb_display, "TMDB_Rating": tmdb_display, "TMDb": tmdb_display, "TMDB": tmdb_display, "tmdb": tmdb_display, "tmdb_rating": tmdb_display,
        "RottenTomatoes_Rating": critic_display, "RottenTomatoes": critic_display, "RottenTomatoes_UserMeter": audience_display, "RottenTomatoes_User": audience_display,
        "rottentomatoes": critic_display, "rottentomatoes_user": audience_display, "MetaCritic_Rating": metacritic_display, "Trakt_Rating": trakt_display,
        "RottenTomatoesIcon": rt_image, "RottenTomatoesImage": rt_image, "RottenTomatoes_Image": rt_image, "RottenTomatoes_ImageKey": rt_image_key,
        "RottenTomatoes_CriticImage": rt_image, "RottenTomatoesCriticImage": rt_image, "rottentomatoes_image": rt_image,
        "RottenTomatoesAudienceIcon": rt_audience_image, "RottenTomatoesAudienceImage": rt_audience_image, "RottenTomatoesAudience_Image": rt_audience_image,
        "RottenTomatoes_UserImage": rt_audience_image, "RottenTomatoes_UserImageKey": rt_user_image_key, "RottenTomatoesUserImage": rt_audience_image,
        "rottentomatoes_userimage": rt_audience_image,
        "Source": "script.library.ratings.scraper",
    }
    slots = _slot_values_for_record(record, ratings, {"critic": rt_image, "audience": rt_audience_image}, top250_display)
    for idx in range(1, 8):
        if idx <= len(slots):
            row = slots[idx - 1]
            values["RatingSlot{0}_Source".format(idx)] = row.get("Source", "")
            values["RatingSlot{0}_Icon".format(idx)] = row.get("Icon", "")
            values["RatingSlot{0}_IconFile".format(idx)] = row.get("IconFile", "")
            values["RatingSlot{0}_Label".format(idx)] = row.get("Label", "")
            values["RatingSlot{0}_Value".format(idx)] = row.get("Value", "")
    awards = record.get("awards") or {}
    if isinstance(awards, dict):
        oscar_wins = safe_int(awards.get("oscar_wins")); emmy_wins = safe_int(awards.get("emmy_wins"))
        if oscar_wins and oscar_wins > 0:
            values["Oscar_Wins"] = str(oscar_wins); values["OscarWins"] = str(oscar_wins)
        if emmy_wins and emmy_wins > 0:
            values["Emmy_Wins"] = str(emmy_wins); values["EmmyWins"] = str(emmy_wins)
    series = record.get("series") or {}
    if record.get("type") in ("tvshow", "season") and isinstance(series, dict):
        status = str(series.get("status") or "").strip()
        status_date = str(series.get("status_date") or "").strip()
        status_date_display = str(series.get("status_date_display") or _date_display(status_date)).strip()
        if status and not _is_metadata_na(status):
            label = _lrs_series_status_label_1537(status)
            values.update({"Status": status, "StatusDate": status_date_display, "Series_Status": status, "Series_StatusDate": status_date_display, "SeriesStatus": status, "SeriesStatusDate": status_date_display, "Series_StatusLabel": label, "SeriesStatusLabel": label})
    values.update(lrs_display_flags())
    values["Display_RatingSlots"] = "true"
    return {key: str(value) for key, value in values.items() if value not in (None, "")}

_slot_names_1381 = []
for _idx in range(1, 8):
    for _suffix in ("Source", "Icon", "IconFile", "Label", "Value"):
        _slot_names_1381.append("RatingSlot{0}_{1}".format(_idx, _suffix))
LRS_EXTRA_PROPERTY_NAMES = tuple(dict.fromkeys(tuple(LRS_EXTRA_PROPERTY_NAMES) + tuple(_slot_names_1381)))

# -----------------------------------------------------------------------------
# v1.3.82 final overrides: valid addon package, display extras toggles, icon filename fix.
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 13)

_FORCE_TRUE_SETTINGS_1382 = {
    "use_mdblist", "use_tmdb", "use_omdb",
    "rating_imdb", "rating_tmdb", "rating_rt_critic", "rating_rt_audience", "rating_metacritic", "rating_trakt", "rating_top250",
    "scrape_tv_status", "scrape_awards_wins",
    "display_imdb", "display_tmdb", "display_rt_critic", "display_rt_audience", "display_metacritic", "display_trakt",
    "publish_af3_cache",
}
_FORCE_FALSE_SETTINGS_1382 = {"publish_tmdbhelper_compat"}
_bool_setting_1382_base = bool_setting

def bool_setting(name: str, default: bool = False) -> bool:
    # Scrape/provider switches removed from UI are always enabled so old userdata false values cannot block data.
    # Display extras are intentionally NOT forced; the user controls them from Display > Extra badges.
    if name in _FORCE_TRUE_SETTINGS_1382:
        return True
    if name in _FORCE_FALSE_SETTINGS_1382:
        return False
    return _bool_setting_1382_base(name, default)


def rating_enabled(media_type: Any, logical: str, default: bool = True) -> bool:
    # Ratings/source checkboxes no longer exist. Scrape all needed cached data.
    return True


def lrs_display_flags() -> Dict[str, str]:
    flags = {}
    for label, setting in LRS_DISPLAY_SETTINGS:
        if setting in ("display_top250", "display_awards", "display_tv_status"):
            flags["Display_" + label] = "true" if bool_setting(setting, True) else "false"
        else:
            flags["Display_" + label] = "true"
    return flags


def tmdbhelper_compat_enabled() -> bool:
    return False


def _rating_slot_order() -> List[str]:
    defaults = ["imdb", "rt_audience", "rt_critic", "metacritic", "tmdb", "trakt", "letterboxd"]
    allowed = set(defaults + ["none"])
    out: List[str] = []
    for idx, default in enumerate(defaults, start=1):
        value = _rating_setting_choice("display_rating_slot_{0}".format(idx), default)
        if value not in allowed:
            value = default
        if value in ("none", ""):
            continue
        if value not in out:
            out.append(value)
    return out


def _slot_source_value(record: Dict[str, Any], logical: str, ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> Optional[Dict[str, str]]:
    if logical == "imdb":
        value = display_decimal(first_rating(ratings, "imdb"))
        if not value:
            return None
        label = value + (" #{0}".format(top250_display) if top250_display else "")
        return {"Source": "imdb", "Icon": "imdb.png", "IconFile": "imdb.png", "Label": label, "Value": value}
    if logical == "tmdb":
        value = display_decimal(first_rating(ratings, "tmdb"))
        if not value:
            return None
        return {"Source": "tmdb", "Icon": "tmdb.png", "IconFile": "tmdb.png", "Label": value, "Value": value}
    if logical == "rt_audience":
        value = display_rt_percent(first_rating(ratings, "rt_audience"))
        if not value:
            return None
        icon = icons.get("audience") or "popcorn.png"
        return {"Source": "rt_audience", "Icon": icon, "IconFile": icon, "Label": "{0}%".format(value), "Value": value}
    if logical == "rt_critic":
        value = display_rt_percent(first_rating(ratings, "rt_critic"))
        if not value:
            return None
        icon = icons.get("critic") or "rtfresh.png"
        return {"Source": "rt_critic", "Icon": icon, "IconFile": icon, "Label": "{0}%".format(value), "Value": value}
    if logical == "metacritic":
        value = display_percent(first_rating(ratings, "metacritic"))
        if not value:
            return None
        return {"Source": "metacritic", "Icon": "metacritic.png", "IconFile": "metacritic.png", "Label": value, "Value": value}
    if logical == "trakt":
        value = display_percent(first_rating(ratings, "trakt"))
        if not value:
            return None
        return {"Source": "trakt", "Icon": "trakt.png", "IconFile": "trakt.png", "Label": value, "Value": value}
    return None


def _slot_values_for_record(record: Dict[str, Any], ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> List[Dict[str, str]]:
    media_type = media_setting_type(record.get("type"))
    if media_type == "episode":
        out = []
        for logical in ("imdb", "tmdb"):
            row = _slot_source_value(record, logical, ratings, icons, "")
            if row:
                out.append(row)
        return out[:2]
    order = _rating_slot_order()
    count = max(1, min(7, int_setting("display_rating_slot_count", 7)))
    fill_empty = bool_setting("display_fill_empty_slots", True)
    candidates = order if fill_empty else order[:count]
    out: List[Dict[str, str]] = []
    for logical in candidates:
        row = _slot_source_value(record, logical, ratings, icons, top250_display)
        if row:
            out.append(row)
        if len(out) >= count:
            break
    return out


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    ratings = record.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ratings = preserve_ratings_for_item(record.get("type"), ratings)
    critic_rating = first_rating(ratings, "rt_critic")
    audience_rating = first_rating(ratings, "rt_audience")
    critic_display = display_rt_percent(critic_rating)
    audience_display = display_rt_percent(audience_rating)
    imdb_display = display_decimal(first_rating(ratings, "imdb"))
    tmdb_display = display_decimal(first_rating(ratings, "tmdb"))
    metacritic_display = display_percent(first_rating(ratings, "metacritic"))
    trakt_display = display_percent(first_rating(ratings, "trakt"))
    rt_images = record.get("rt_images") if isinstance(record.get("rt_images"), dict) else {}
    rt_image_key = str(rt_images.get("critic") or "").strip()
    rt_user_image_key = str(rt_images.get("audience") or "").strip()
    rt_image = _lrs_rt_file(rt_image_key, critic_display)
    rt_audience_image = _lrs_audience_file(rt_user_image_key, audience_display)
    top250_rank = safe_int(record.get("imdb_top250_rank"))
    show_top250 = bool_setting("display_top250", True)
    top250_display = str(top250_rank) if show_top250 and top250_rank and top250_rank > 0 else ""
    top250_hash_display = "#{0}".format(top250_rank) if top250_display else ""
    values = {
        "HasData": "true", "DBType": str(record.get("type") or ""), "Title": str(record.get("title") or ""), "Year": str(record.get("year") or ""),
        "IMDb_Rating": imdb_display, "IMDB_Rating": imdb_display, "IMDb": imdb_display, "IMDB": imdb_display, "imdb": imdb_display, "imdb_rating": imdb_display,
        "Top250": top250_display, "Top250_Rank": top250_hash_display, "top250": top250_display, "top250_rank": top250_hash_display,
        "TMDb_Rating": tmdb_display, "TMDB_Rating": tmdb_display, "TMDb": tmdb_display, "TMDB": tmdb_display, "tmdb": tmdb_display, "tmdb_rating": tmdb_display,
        "RottenTomatoes_Rating": critic_display, "RottenTomatoes": critic_display, "RottenTomatoes_UserMeter": audience_display, "RottenTomatoes_User": audience_display,
        "rottentomatoes": critic_display, "rottentomatoes_user": audience_display, "MetaCritic_Rating": metacritic_display, "Trakt_Rating": trakt_display,
        "RottenTomatoesIcon": rt_image, "RottenTomatoesImage": rt_image, "RottenTomatoes_Image": rt_image, "RottenTomatoes_ImageKey": rt_image_key,
        "RottenTomatoes_CriticImage": rt_image, "RottenTomatoesCriticImage": rt_image, "rottentomatoes_image": rt_image,
        "RottenTomatoesAudienceIcon": rt_audience_image, "RottenTomatoesAudienceImage": rt_audience_image, "RottenTomatoesAudience_Image": rt_audience_image,
        "RottenTomatoes_UserImage": rt_audience_image, "RottenTomatoes_UserImageKey": rt_user_image_key, "RottenTomatoesUserImage": rt_audience_image,
        "rottentomatoes_userimage": rt_audience_image,
        "Source": "script.library.ratings.scraper",
    }
    slots = _slot_values_for_record(record, ratings, {"critic": rt_image, "audience": rt_audience_image}, top250_display)
    for idx in range(1, 8):
        if idx <= len(slots):
            row = slots[idx - 1]
            values["RatingSlot{0}_Source".format(idx)] = row.get("Source", "")
            values["RatingSlot{0}_Icon".format(idx)] = row.get("Icon", "")
            values["RatingSlot{0}_IconFile".format(idx)] = row.get("IconFile", row.get("Icon", ""))
            values["RatingSlot{0}_Label".format(idx)] = row.get("Label", "")
            values["RatingSlot{0}_Value".format(idx)] = row.get("Value", "")
    if bool_setting("display_awards", True):
        awards = record.get("awards") or {}
        if isinstance(awards, dict):
            oscar_wins = safe_int(awards.get("oscar_wins")); emmy_wins = safe_int(awards.get("emmy_wins"))
            if oscar_wins and oscar_wins > 0:
                values["Oscar_Wins"] = str(oscar_wins); values["OscarWins"] = str(oscar_wins)
            if emmy_wins and emmy_wins > 0:
                values["Emmy_Wins"] = str(emmy_wins); values["EmmyWins"] = str(emmy_wins)
    if bool_setting("display_tv_status", True):
        series = record.get("series") or {}
        if record.get("type") in ("tvshow", "season") and isinstance(series, dict):
            status = str(series.get("status") or "").strip()
            status_date = str(series.get("status_date") or "").strip()
            status_date_display = str(series.get("status_date_display") or _date_display(status_date)).strip()
            if status and not _is_metadata_na(status):
                label = _lrs_series_status_label_1537(status)
                values.update({"Status": status, "StatusDate": status_date_display, "Series_Status": status, "Series_StatusDate": status_date_display, "SeriesStatus": status, "SeriesStatusDate": status_date_display, "Series_StatusLabel": label, "SeriesStatusLabel": label})
    values.update(lrs_display_flags())
    values["Display_RatingSlots"] = "true"
    return {key: str(value) for key, value in values.items() if value not in (None, "")}

# Extend clear/publish property list for slot 6 and icon filenames.
_slot_names_1382 = []
for _idx in range(1, 8):
    for _suffix in ("Source", "Icon", "IconFile", "Label", "Value"):
        _slot_names_1382.append("RatingSlot{0}_{1}".format(_idx, _suffix))
LRS_EXTRA_PROPERTY_NAMES = tuple(dict.fromkeys(tuple(LRS_EXTRA_PROPERTY_NAMES) + tuple(_slot_names_1382) + (
    "Display_RatingSlots", "Display_Top250", "Display_Awards", "Display_TVStatus",
)))



# -----------------------------------------------------------------------------
# v1.3.83 final overrides: display toggles, stable slot fallback, CropV2 resolver.
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 14)

_FORCE_TRUE_SETTINGS_1383 = {
    "use_mdblist", "use_tmdb", "use_omdb",
    "rating_imdb", "rating_tmdb", "rating_rt_critic", "rating_rt_audience", "rating_metacritic", "rating_trakt", "rating_top250",
    "scrape_tv_status", "scrape_awards_wins",
    "display_imdb", "display_tmdb", "display_rt_critic", "display_rt_audience", "display_metacritic", "display_trakt",
    "publish_af3_cache",
}
_FORCE_FALSE_SETTINGS_1383 = {"publish_tmdbhelper_compat"}
_RAW_DISPLAY_BOOL_SETTINGS_1383 = {"display_top250", "display_awards", "display_tv_status", "display_fill_empty_slots", "debug_logging"}


def _raw_bool_setting_1383(name: str, default: bool = False) -> bool:
    try:
        value = ADDON.getSetting(name)
    except Exception:  # pylint: disable=broad-except
        return default
    return default if value == "" else str(value).lower() == "true"


def bool_setting(name: str, default: bool = False) -> bool:
    # Do not fall through older v1.3.81 forced-true wrappers for display extras.
    # These are user-facing Display toggles and must obey the current setting.
    if name in _RAW_DISPLAY_BOOL_SETTINGS_1383:
        return _raw_bool_setting_1383(name, default)
    if name in _FORCE_TRUE_SETTINGS_1383:
        return True
    if name in _FORCE_FALSE_SETTINGS_1383:
        return False
    return _raw_bool_setting_1383(name, default)


def rating_enabled(media_type: Any, logical: str, default: bool = True) -> bool:
    # Ratings/source checkboxes no longer exist. Scrape all needed cached data.
    return True


def lrs_display_flags() -> Dict[str, str]:
    flags = {}
    for label, setting in LRS_DISPLAY_SETTINGS:
        if setting in ("display_top250", "display_awards", "display_tv_status"):
            flags["Display_" + label] = "true" if bool_setting(setting, True) else "false"
        else:
            flags["Display_" + label] = "true"
    return flags


def tmdbhelper_compat_enabled() -> bool:
    return False


def _rating_slot_order() -> List[str]:
    # This remains a plain user-defined order. There is deliberately no
    # TMDb-before-IMDb special case. Default fallback order is IMDb -> ... -> TMDb.
    defaults = ["imdb", "rt_audience", "rt_critic", "metacritic", "tmdb", "trakt", "letterboxd"]
    allowed = set(defaults + ["none"])
    out: List[str] = []
    for idx, default in enumerate(defaults, start=1):
        value = _rating_setting_choice("display_rating_slot_{0}".format(idx), default)
        if value not in allowed:
            value = default
        if value in ("none", ""):
            continue
        if value not in out:
            out.append(value)
    return out


def _slot_source_value(record: Dict[str, Any], logical: str, ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> Optional[Dict[str, str]]:
    if logical == "imdb":
        value = display_decimal(first_rating(ratings, "imdb"))
        if not value:
            return None
        label = value + (" #{0}".format(top250_display) if top250_display else "")
        return {"Source": "imdb", "Icon": "imdb.png", "IconFile": "imdb.png", "Label": label, "Value": value}
    if logical == "tmdb":
        value = display_decimal(first_rating(ratings, "tmdb"))
        if not value:
            return None
        return {"Source": "tmdb", "Icon": "tmdb.png", "IconFile": "tmdb.png", "Label": value, "Value": value}
    if logical == "rt_audience":
        value = display_rt_percent(first_rating(ratings, "rt_audience"))
        if not value:
            return None
        icon = icons.get("audience") or "popcorn.png"
        return {"Source": "rt_audience", "Icon": icon, "IconFile": icon, "Label": "{0}%".format(value), "Value": value}
    if logical == "rt_critic":
        value = display_rt_percent(first_rating(ratings, "rt_critic"))
        if not value:
            return None
        icon = icons.get("critic") or "rtfresh.png"
        return {"Source": "rt_critic", "Icon": icon, "IconFile": icon, "Label": "{0}%".format(value), "Value": value}
    if logical == "metacritic":
        value = display_percent(first_rating(ratings, "metacritic"))
        if not value:
            return None
        return {"Source": "metacritic", "Icon": "metacritic.png", "IconFile": "metacritic.png", "Label": value, "Value": value}
    if logical == "trakt":
        value = display_percent(first_rating(ratings, "trakt"))
        if not value:
            return None
        return {"Source": "trakt", "Icon": "trakt.png", "IconFile": "trakt.png", "Label": value, "Value": value}
    return None


def _slot_values_for_record(record: Dict[str, Any], ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> List[Dict[str, str]]:
    media_type = media_setting_type(record.get("type"))
    if media_type == "episode":
        out: List[Dict[str, str]] = []
        for logical in ("imdb", "tmdb"):
            row = _slot_source_value(record, logical, ratings, icons, "")
            if row:
                out.append(row)
        return out[:2]
    order = _rating_slot_order()
    count = max(1, min(7, int_setting("display_rating_slot_count", 7)))
    fill_empty = bool_setting("display_fill_empty_slots", True)
    candidates = order if fill_empty else order[:count]
    out: List[Dict[str, str]] = []
    for logical in candidates:
        row = _slot_source_value(record, logical, ratings, icons, top250_display)
        if row:
            out.append(row)
        if len(out) >= count:
            break
    return out


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    ratings = record.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ratings = preserve_ratings_for_item(record.get("type"), ratings)
    critic_rating = first_rating(ratings, "rt_critic")
    audience_rating = first_rating(ratings, "rt_audience")
    critic_display = display_rt_percent(critic_rating)
    audience_display = display_rt_percent(audience_rating)
    imdb_display = display_decimal(first_rating(ratings, "imdb"))
    tmdb_display = display_decimal(first_rating(ratings, "tmdb"))
    metacritic_display = display_percent(first_rating(ratings, "metacritic"))
    trakt_display = display_percent(first_rating(ratings, "trakt"))
    rt_images = record.get("rt_images") if isinstance(record.get("rt_images"), dict) else {}
    rt_image_key = str(rt_images.get("critic") or "").strip()
    rt_user_image_key = str(rt_images.get("audience") or "").strip()
    rt_image = _lrs_rt_file(rt_image_key, critic_display)
    rt_audience_image = _lrs_audience_file(rt_user_image_key, audience_display)
    top250_rank = safe_int(record.get("imdb_top250_rank"))
    show_top250 = bool_setting("display_top250", True)
    top250_display = str(top250_rank) if show_top250 and top250_rank and top250_rank > 0 else ""
    top250_hash_display = "#{0}".format(top250_rank) if top250_display else ""
    values = {
        "HasData": "true", "DBType": str(record.get("type") or ""), "Title": str(record.get("title") or ""), "Year": str(record.get("year") or ""),
        "IMDb_Rating": imdb_display, "IMDB_Rating": imdb_display, "IMDb": imdb_display, "IMDB": imdb_display, "imdb": imdb_display, "imdb_rating": imdb_display,
        "Top250": top250_display, "Top250_Rank": top250_hash_display, "top250": top250_display, "top250_rank": top250_hash_display,
        "TMDb_Rating": tmdb_display, "TMDB_Rating": tmdb_display, "TMDb": tmdb_display, "TMDB": tmdb_display, "tmdb": tmdb_display, "tmdb_rating": tmdb_display,
        "RottenTomatoes_Rating": critic_display, "RottenTomatoes": critic_display, "RottenTomatoes_UserMeter": audience_display, "RottenTomatoes_User": audience_display,
        "rottentomatoes": critic_display, "rottentomatoes_user": audience_display, "MetaCritic_Rating": metacritic_display, "Trakt_Rating": trakt_display,
        "RottenTomatoesIcon": rt_image, "RottenTomatoesImage": rt_image, "RottenTomatoes_Image": rt_image, "RottenTomatoes_ImageKey": rt_image_key,
        "RottenTomatoes_CriticImage": rt_image, "RottenTomatoesCriticImage": rt_image, "rottentomatoes_image": rt_image,
        "RottenTomatoesAudienceIcon": rt_audience_image, "RottenTomatoesAudienceImage": rt_audience_image, "RottenTomatoesAudience_Image": rt_audience_image,
        "RottenTomatoes_UserImage": rt_audience_image, "RottenTomatoes_UserImageKey": rt_user_image_key, "RottenTomatoesUserImage": rt_audience_image,
        "rottentomatoes_userimage": rt_audience_image,
        "Source": "script.library.ratings.scraper",
    }
    slots = _slot_values_for_record(record, ratings, {"critic": rt_image, "audience": rt_audience_image}, top250_display)
    for idx in range(1, 8):
        if idx <= len(slots):
            row = slots[idx - 1]
            values["RatingSlot{0}_Source".format(idx)] = row.get("Source", "")
            values["RatingSlot{0}_Icon".format(idx)] = row.get("Icon", "")
            values["RatingSlot{0}_IconFile".format(idx)] = row.get("IconFile", row.get("Icon", ""))
            values["RatingSlot{0}_Label".format(idx)] = row.get("Label", "")
            values["RatingSlot{0}_Value".format(idx)] = row.get("Value", "")
    if bool_setting("display_awards", True):
        awards = record.get("awards") or {}
        if isinstance(awards, dict):
            oscar_wins = safe_int(awards.get("oscar_wins")); emmy_wins = safe_int(awards.get("emmy_wins"))
            if oscar_wins and oscar_wins > 0:
                values["Oscar_Wins"] = str(oscar_wins); values["OscarWins"] = str(oscar_wins)
            if emmy_wins and emmy_wins > 0:
                values["Emmy_Wins"] = str(emmy_wins); values["EmmyWins"] = str(emmy_wins)
    if bool_setting("display_tv_status", True):
        series = record.get("series") or {}
        if record.get("type") in ("tvshow", "season") and isinstance(series, dict):
            status = str(series.get("status") or "").strip()
            status_date = str(series.get("status_date") or "").strip()
            status_date_display = str(series.get("status_date_display") or _date_display(status_date)).strip()
            if status and not _is_metadata_na(status):
                label = _lrs_series_status_label_1537(status)
                values.update({"Status": status, "StatusDate": status_date_display, "Series_Status": status, "Series_StatusDate": status_date_display, "SeriesStatus": status, "SeriesStatusDate": status_date_display, "Series_StatusLabel": label, "SeriesStatusLabel": label})
    values.update(lrs_display_flags())
    values["Display_RatingSlots"] = "true"
    return {key: str(value) for key, value in values.items() if value not in (None, "")}


def _decode_kodi_image_path_1383(value: Any) -> List[str]:
    try:
        from urllib.parse import unquote  # pylint: disable=import-outside-toplevel
    except Exception:  # pylint: disable=broad-except
        unquote = None
    raw = str(value or "").strip()
    if not raw:
        return []
    variants: List[str] = []
    def add(v: str) -> None:
        v = str(v or "").strip()
        if not v:
            return
        # Kodi image:// paths often end with a trailing slash after the encoded URL.
        if v.startswith("image://"):
            inner = v[8:]
            if inner.endswith("/"):
                inner = inner[:-1]
            variants.append(v)
            variants.append(inner)
        else:
            variants.append(v)
    add(raw)
    if unquote is not None:
        cur = raw
        for _ in range(3):
            nxt = unquote(cur)
            if nxt == cur:
                break
            add(nxt)
            cur = nxt
    clean: List[str] = []
    for v in variants:
        v = v.strip()
        if v.startswith("image://"):
            v = v[8:]
        if v.endswith("/"):
            v = v[:-1]
        if unquote is not None:
            v = unquote(v)
            if v.endswith("/"):
                v = v[:-1]
        if v and v not in clean:
            clean.append(v)
    return clean


def _candidate_crop_hashes_1383(value: Any) -> List[str]:
    import hashlib  # pylint: disable=import-outside-toplevel
    hashes: List[str] = []
    for candidate in _decode_kodi_image_path_1383(value):
        for text in (candidate, candidate.lower()):
            for algo in (hashlib.md5, hashlib.sha1, hashlib.sha256):
                try:
                    h = algo(text.encode("utf-8")).hexdigest()
                except Exception:  # pylint: disable=broad-except
                    continue
                if h not in hashes:
                    hashes.append(h)
    return hashes


def _tmdbhelper_cropv2_base_1544() -> str:
    """Return the same CropV2 location used by current TMDbHelper."""
    custom = ""
    tmdb_addon = None
    try:
        tmdb_addon = xbmcaddon.Addon("plugin.video.themoviedb.helper")
        custom = str(tmdb_addon.getSetting("image_location") or "").strip()
    except Exception:
        custom = ""
    finally:
        if tmdb_addon is not None:
            del tmdb_addon

    base = custom or (
        "special://profile/addon_data/plugin.video.themoviedb.helper"
    )
    crop_dir = os.path.join(base.rstrip("/\\"), "crop_v2")
    try:
        xbmcvfs.mkdirs(crop_dir)
    except Exception:
        pass
    try:
        return xbmcvfs.translatePath(crop_dir)
    except Exception:
        return crop_dir


def _find_local_cropv2_by_logo_1383(default_logo: str) -> Dict[str, str]:
    if not default_logo:
        return {"image": "", "source": "", "title": ""}
    try:
        crop_dir = _tmdbhelper_cropv2_base_1544()
    except Exception:  # pylint: disable=broad-except
        crop_dir = os.path.join(
            os.path.dirname(PROFILE.rstrip(os.sep)),
            "plugin.video.themoviedb.helper",
            "crop_v2",
        )
    if not crop_dir or not os.path.isdir(crop_dir):
        return {"image": "", "source": "", "title": ""}
    stems = _candidate_crop_hashes_1383(default_logo)
    if not stems:
        return {"image": "", "source": "", "title": ""}
    try:
        names = os.listdir(crop_dir)
    except OSError:
        return {"image": "", "source": "", "title": ""}
    lower_to_name = {name.lower(): name for name in names}
    prefixes = []
    for h in stems:
        prefixes.extend(["cropped-" + h, h])
    for pref in prefixes:
        for ext in (".png", ".webp", ".jpg", ".jpeg"):
            key = (pref + ext).lower()
            if key in lower_to_name:
                path = os.path.join(crop_dir, lower_to_name[key])
                return {"image": path, "source": "crop_v2_hash", "title": ""}
    # Some builds shorten the hash in the filename. Only accept unique prefix match.
    matches = []
    for name in names:
        low = name.lower()
        if not (low.startswith("cropped-") and low.rsplit(".", 1)[-1] in ("png", "webp", "jpg", "jpeg")):
            continue
        for h in stems:
            if low.startswith(("cropped-" + h[:16]).lower()):
                matches.append(name)
                break
    if len(matches) == 1:
        return {"image": os.path.join(crop_dir, matches[0]), "source": "crop_v2_hash_prefix", "title": ""}
    return {"image": "", "source": "", "title": ""}


def update_screensaver_clearlogo_properties(item: Dict[str, Any]) -> Dict[str, str]:
    try:
        import xbmcgui  # pylint: disable=import-outside-toplevel
        home = xbmcgui.Window(10000)
    except Exception:
        return {}
    try:
        item_title = str((item or {}).get("title") or xbmc.getInfoLabel("Container(1297).ListItem.Title") or "").strip()
        default_logo = xbmc.getInfoLabel("Container(1297).ListItem.Art(clearlogo)").strip()
    except Exception:
        item_title, default_logo = str((item or {}).get("title") or ""), ""
    chosen = {"image": "", "source": "", "title": ""}
    item_norm = _norm_text(item_title)
    candidates = _tmdbhelper_crop_candidates()
    for cand in candidates:
        cand_title = str(cand.get("title") or "").strip()
        if cand.get("image") and item_norm and cand_title and _norm_text(cand_title) == item_norm:
            chosen = cand
            break
    if not chosen.get("image") and item_norm and len(candidates) == 1 and not str(candidates[0].get("title") or "").strip():
        chosen = candidates[0]
    if not chosen.get("image"):
        local = _find_local_cropv2_by_logo_1383(default_logo)
        if local.get("image"):
            chosen = local
    mode = "cropv2" if chosen.get("image") else ("default_kodi" if default_logo else "title")
    props = {
        "CropV2Image": str(chosen.get("image") or ""),
        "CropV2Source": str(chosen.get("source") or ""),
        "CropV2Title": str(chosen.get("title") or ""),
        "DefaultClearLogo": default_logo,
        "ClearLogoMode": mode,
    }
    for key, value in props.items():
        _publish_property(home, AF3_PREFIX + "Screensaver." + key, str(value or ""))
    global _LAST_SCREENSAVER_CLEARLOGO_LOG
    sig = "{0}|{1}|{2}|{3}".format(mode, item_title, chosen.get("image") or "", default_logo)
    if sig != _LAST_SCREENSAVER_CLEARLOGO_LOG:
        _LAST_SCREENSAVER_CLEARLOGO_LOG = sig
        log("LRS SCREENSAVER CLEARLOGO mode={0} title={1} crop_source={2} crop_title={3} has_default={4}".format(
            mode, item_title[:80], chosen.get("source") or "", str(chosen.get("title") or "")[:80], "yes" if default_logo else "no"
        ), xbmc.LOGINFO)
    return props


_slot_names_1383 = []
for _idx in range(1, 8):
    for _suffix in ("Source", "Icon", "IconFile", "Label", "Value"):
        _slot_names_1383.append("RatingSlot{0}_{1}".format(_idx, _suffix))
LRS_EXTRA_PROPERTY_NAMES = tuple(dict.fromkeys(tuple(LRS_EXTRA_PROPERTY_NAMES) + tuple(_slot_names_1383) + (
    "Display_RatingSlots", "Display_Top250", "Display_Awards", "Display_TVStatus",
    "Screensaver.CropV2Image", "Screensaver.CropV2Source", "Screensaver.CropV2Title", "Screensaver.DefaultClearLogo", "Screensaver.ClearLogoMode",
)))


# -----------------------------------------------------------------------------
# v1.3.84 final overrides: truthful display flags, TMDb fallback placement,
# slots 1-6 for library + screensaver, robust CropV2 property list.
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 15)
_RAW_DISPLAY_BOOL_SETTINGS_1384 = {
    "display_top250", "display_awards", "display_tv_status", "display_fill_empty_slots",
    "display_tmdb_after_imdb_fallback", "debug_logging",
}
_FORCE_TRUE_SETTINGS_1384 = {
    "use_mdblist", "use_tmdb", "use_omdb",
    "rating_imdb", "rating_tmdb", "rating_rt_critic", "rating_rt_audience", "rating_metacritic", "rating_trakt", "rating_top250",
    "scrape_tv_status", "scrape_awards_wins",
    "display_imdb", "display_tmdb", "display_rt_critic", "display_rt_audience", "display_metacritic", "display_trakt",
    "publish_af3_cache",
}
_FORCE_FALSE_SETTINGS_1384 = {"publish_tmdbhelper_compat"}

def _raw_bool_setting_1384(name: str, default: bool = False) -> bool:
    try:
        value = ADDON.getSetting(name)
    except Exception:  # pylint: disable=broad-except
        return default
    return default if value == "" else str(value).lower() == "true"

def bool_setting(name: str, default: bool = False) -> bool:
    # Display toggles must obey the user's current Display settings. Scrape/provider
    # switches removed from the UI stay forced on so all needed cache data is collected.
    if name in _RAW_DISPLAY_BOOL_SETTINGS_1384:
        return _raw_bool_setting_1384(name, default)
    if name in _FORCE_TRUE_SETTINGS_1384:
        return True
    if name in _FORCE_FALSE_SETTINGS_1384:
        return False
    return _raw_bool_setting_1384(name, default)

def rating_enabled(media_type: Any, logical: str, default: bool = True) -> bool:
    return True

def lrs_display_flags() -> Dict[str, str]:
    flags: Dict[str, str] = {}
    for label, setting in LRS_DISPLAY_SETTINGS:
        if setting in ("display_top250", "display_awards", "display_tv_status"):
            flags["Display_" + label] = "true" if bool_setting(setting, True) else "false"
        else:
            flags["Display_" + label] = "true"
    return flags

def tmdbhelper_compat_enabled() -> bool:
    return False

def _rating_slot_order() -> List[str]:
    defaults = ["imdb", "rt_audience", "rt_critic", "metacritic", "tmdb", "trakt", "letterboxd"]
    allowed = set(defaults + ["none"])
    out: List[str] = []
    for idx, default in enumerate(defaults, start=1):
        value = _rating_setting_choice("display_rating_slot_{0}".format(idx), default)
        if value not in allowed:
            value = default
        if value in ("none", ""):
            continue
        if value not in out:
            out.append(value)
    return out

def _slot_source_value(record: Dict[str, Any], logical: str, ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> Optional[Dict[str, str]]:
    if logical == "imdb":
        value = display_decimal(first_rating(ratings, "imdb"))
        if not value:
            return None
        label = value + (" #{0}".format(top250_display) if top250_display else "")
        return {"Source": "imdb", "Icon": "imdb.png", "IconFile": "imdb.png", "Label": label, "Value": value}
    if logical == "tmdb":
        value = display_decimal(first_rating(ratings, "tmdb"))
        if not value:
            return None
        return {"Source": "tmdb", "Icon": "tmdb.png", "IconFile": "tmdb.png", "Label": value, "Value": value}
    if logical == "rt_audience":
        value = display_rt_percent(first_rating(ratings, "rt_audience"))
        if not value:
            return None
        icon = icons.get("audience") or "popcorn.png"
        return {"Source": "rt_audience", "Icon": icon, "IconFile": icon, "Label": "{0}%".format(value), "Value": value}
    if logical == "rt_critic":
        value = display_rt_percent(first_rating(ratings, "rt_critic"))
        if not value:
            return None
        icon = icons.get("critic") or "rtfresh.png"
        return {"Source": "rt_critic", "Icon": icon, "IconFile": icon, "Label": "{0}%".format(value), "Value": value}
    if logical == "metacritic":
        value = display_percent(first_rating(ratings, "metacritic"))
        if not value:
            return None
        return {"Source": "metacritic", "Icon": "metacritic.png", "IconFile": "metacritic.png", "Label": value, "Value": value}
    if logical == "trakt":
        value = display_percent(first_rating(ratings, "trakt"))
        if not value:
            return None
        return {"Source": "trakt", "Icon": "trakt.png", "IconFile": "trakt.png", "Label": value, "Value": value}
    return None

def _place_tmdb_after_imdb_if_fallback(out: List[Dict[str, str]], selected_sources: List[str], fill_empty: bool) -> List[Dict[str, str]]:
    if not fill_empty or not bool_setting("display_tmdb_after_imdb_fallback", True):
        return out
    sources = [row.get("Source", "") for row in out]
    # Only treat TMDb as a fallback when it is not one of the configured visible
    # slots but appears because an earlier selected source was empty.
    if "imdb" not in sources or "tmdb" not in sources or "tmdb" in selected_sources:
        return out
    imdb_idx = sources.index("imdb")
    tmdb_idx = sources.index("tmdb")
    if tmdb_idx == imdb_idx + 1:
        return out
    row = out.pop(tmdb_idx)
    if tmdb_idx < imdb_idx:
        imdb_idx -= 1
    out.insert(imdb_idx + 1, row)
    return out

def _slot_values_for_record(record: Dict[str, Any], ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> List[Dict[str, str]]:
    media_type = media_setting_type(record.get("type"))
    if media_type == "episode":
        out: List[Dict[str, str]] = []
        for logical in ("imdb", "tmdb"):
            row = _slot_source_value(record, logical, ratings, icons, "")
            if row:
                out.append(row)
        return out[:2]
    order = _rating_slot_order()
    count = max(1, min(7, int_setting("display_rating_slot_count", 7)))
    fill_empty = bool_setting("display_fill_empty_slots", True)
    selected_sources = order[:count]
    candidates = order if fill_empty else selected_sources
    out: List[Dict[str, str]] = []
    for logical in candidates:
        row = _slot_source_value(record, logical, ratings, icons, top250_display)
        if row:
            out.append(row)
        if len(out) >= count:
            break
    return _place_tmdb_after_imdb_if_fallback(out, selected_sources, fill_empty)

def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    ratings = record.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ratings = preserve_ratings_for_item(record.get("type"), ratings)
    critic_rating = first_rating(ratings, "rt_critic")
    audience_rating = first_rating(ratings, "rt_audience")
    critic_display = display_rt_percent(critic_rating)
    audience_display = display_rt_percent(audience_rating)
    imdb_display = display_decimal(first_rating(ratings, "imdb"))
    tmdb_display = display_decimal(first_rating(ratings, "tmdb"))
    metacritic_display = display_percent(first_rating(ratings, "metacritic"))
    trakt_display = display_percent(first_rating(ratings, "trakt"))
    rt_images = record.get("rt_images") if isinstance(record.get("rt_images"), dict) else {}
    rt_image_key = str(rt_images.get("critic") or "").strip()
    rt_user_image_key = str(rt_images.get("audience") or "").strip()
    rt_image = _lrs_rt_file(rt_image_key, critic_display)
    rt_audience_image = _lrs_audience_file(rt_user_image_key, audience_display)
    top250_rank = safe_int(record.get("imdb_top250_rank"))
    show_top250 = bool_setting("display_top250", True)
    top250_display = str(top250_rank) if show_top250 and top250_rank and top250_rank > 0 else ""
    top250_hash_display = "#{0}".format(top250_rank) if top250_display else ""
    values = {
        "HasData": "true", "DBType": str(record.get("type") or ""), "Title": str(record.get("title") or ""), "Year": str(record.get("year") or ""),
        "IMDb_Rating": imdb_display, "IMDB_Rating": imdb_display, "IMDb": imdb_display, "IMDB": imdb_display, "imdb": imdb_display, "imdb_rating": imdb_display,
        "Top250": top250_display, "Top250_Rank": top250_hash_display, "top250": top250_display, "top250_rank": top250_hash_display,
        "TMDb_Rating": tmdb_display, "TMDB_Rating": tmdb_display, "TMDb": tmdb_display, "TMDB": tmdb_display, "tmdb": tmdb_display, "tmdb_rating": tmdb_display,
        "RottenTomatoes_Rating": critic_display, "RottenTomatoes": critic_display, "RottenTomatoes_UserMeter": audience_display, "RottenTomatoes_User": audience_display,
        "rottentomatoes": critic_display, "rottentomatoes_user": audience_display, "MetaCritic_Rating": metacritic_display, "Trakt_Rating": trakt_display,
        "RottenTomatoesIcon": rt_image, "RottenTomatoesImage": rt_image, "RottenTomatoes_Image": rt_image, "RottenTomatoes_ImageKey": rt_image_key,
        "RottenTomatoes_CriticImage": rt_image, "RottenTomatoesCriticImage": rt_image, "rottentomatoes_image": rt_image,
        "RottenTomatoesAudienceIcon": rt_audience_image, "RottenTomatoesAudienceImage": rt_audience_image, "RottenTomatoesAudience_Image": rt_audience_image,
        "RottenTomatoes_UserImage": rt_audience_image, "RottenTomatoes_UserImageKey": rt_user_image_key, "RottenTomatoesUserImage": rt_audience_image,
        "rottentomatoes_userimage": rt_audience_image,
        "Source": "script.library.ratings.scraper",
    }
    slots = _slot_values_for_record(record, ratings, {"critic": rt_image, "audience": rt_audience_image}, top250_display)
    for idx in range(1, 8):
        if idx <= len(slots):
            row = slots[idx - 1]
            values["RatingSlot{0}_Source".format(idx)] = row.get("Source", "")
            values["RatingSlot{0}_Icon".format(idx)] = row.get("Icon", "")
            values["RatingSlot{0}_IconFile".format(idx)] = row.get("IconFile", row.get("Icon", ""))
            values["RatingSlot{0}_Label".format(idx)] = row.get("Label", "")
            values["RatingSlot{0}_Value".format(idx)] = row.get("Value", "")
    if bool_setting("display_awards", True):
        awards = record.get("awards") or {}
        if isinstance(awards, dict):
            oscar_wins = safe_int(awards.get("oscar_wins")); emmy_wins = safe_int(awards.get("emmy_wins"))
            if oscar_wins and oscar_wins > 0:
                values["Oscar_Wins"] = str(oscar_wins); values["OscarWins"] = str(oscar_wins)
            if emmy_wins and emmy_wins > 0:
                values["Emmy_Wins"] = str(emmy_wins); values["EmmyWins"] = str(emmy_wins)
    if bool_setting("display_tv_status", True):
        series = record.get("series") or {}
        if record.get("type") in ("tvshow", "season") and isinstance(series, dict):
            status = str(series.get("status") or "").strip()
            status_date = str(series.get("status_date") or "").strip()
            status_date_display = str(series.get("status_date_display") or _date_display(status_date)).strip()
            if status and not _is_metadata_na(status):
                label = _lrs_series_status_label_1537(status)
                values.update({"Status": status, "StatusDate": status_date_display, "Series_Status": status, "Series_StatusDate": status_date_display, "SeriesStatus": status, "SeriesStatusDate": status_date_display, "Series_StatusLabel": label, "SeriesStatusLabel": label})
    values.update(lrs_display_flags())
    values["Display_RatingSlots"] = "true"
    return {key: str(value) for key, value in values.items() if value not in (None, "")}

_slot_names_1384 = []
for _idx in range(1, 8):
    for _suffix in ("Source", "Icon", "IconFile", "Label", "Value"):
        _slot_names_1384.append("RatingSlot{0}_{1}".format(_idx, _suffix))
LRS_EXTRA_PROPERTY_NAMES = tuple(dict.fromkeys(tuple(LRS_EXTRA_PROPERTY_NAMES) + tuple(_slot_names_1384) + (
    "Display_RatingSlots", "Display_Top250", "Display_Awards", "Display_TVStatus",
    "Screensaver.CropV2Image", "Screensaver.CropV2Source", "Screensaver.CropV2Title", "Screensaver.DefaultClearLogo", "Screensaver.ClearLogoMode",
)))


# -----------------------------------------------------------------------------
# v1.3.85 packaging marker: AF3 hub bridge patcher rebuilt; runtime hub resolver
# remains the v1.3.78+ af3_visual/lrs_active resolver already present above.
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 16)


# -----------------------------------------------------------------------------
# v1.3.86 marker: AF3 native spacing + screensaver property-row fix.
# Runtime CropV2 resolver and 1-6 slot values are preserved from 1.3.84/1.3.85.
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 17)


# -----------------------------------------------------------------------------
# v1.3.88 awards-only relevant-key fix
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 18)


def _award_relevant_key_1388(media_type: Any) -> str:
    media_type = media_setting_type(media_type)
    if media_type == "movie":
        return "oscar_wins"
    if media_type == "tvshow":
        return "emmy_wins"
    return ""


def _award_key_complete_1388(value: Any) -> bool:
    if _is_metadata_na(value):
        return True
    parsed = safe_int(value)
    return parsed is not None and parsed >= 0


def _awards_text_has_real_text_1388(awards: Dict[str, Any]) -> bool:
    text = str((awards or {}).get("awards_text") or "").strip()
    return bool(text) and not _is_metadata_na(text)


def _awards_needs_fill(awards: Dict[str, Any], media_type: Any) -> bool:
    """Return True only when the relevant awards field is missing.

    Only the awards field relevant to the current media type determines
    completeness. Cross-type N/A markers must not suppress a required lookup.
    """
    media_type = media_setting_type(media_type)
    key = _award_relevant_key_1388(media_type)
    if not key:
        return False
    if not bool_setting("scrape_awards_wins", True):
        return False
    if not isinstance(awards, dict) or not awards:
        return True
    return not _award_key_complete_1388(awards.get(key))


def record_missing_awards(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    return _awards_needs_fill((record or {}).get("awards") or {}, (item or {}).get("type"))


def _merge_missing_awards(existing: Dict[str, Any], found: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(existing or {})
    found = dict(found or {})
    # Keep both final schema fields explicit, but do not let cross-field N/A
    # decide whether an item is complete; _awards_needs_fill handles that.
    if found and "oscar_wins" not in found:
        found["oscar_wins"] = METADATA_NA_VALUE
    if found and "emmy_wins" not in found:
        found["emmy_wins"] = METADATA_NA_VALUE
    for key, value in found.items():
        if value in (None, ""):
            continue
        if key in ("oscar_wins", "emmy_wins"):
            current = merged.get(key)
            if current in (None, "", 0, "0"):
                merged[key] = _metadata_int_or_na(value)
        elif key == "awards_text":
            current_text = str(merged.get(key) or "").strip()
            if not current_text or _is_metadata_na(current_text):
                merged[key] = str(value)
        elif not str(merged.get(key) or "").strip():
            merged[key] = value
    return merged


def resolve_awards_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    media_type = media_setting_type((item or {}).get("type"))
    existing = dict(existing or {})
    if media_type not in ("movie", "tvshow"):
        return existing

    ids = dict(existing.get("ids") or {})
    for key, value in extract_ids(item).items():
        if value not in (None, ""):
            ids.setdefault(str(key), str(value))
    awards = dict(existing.get("awards") or {})
    provider_meta = dict(existing.get("provider_meta") or {})
    errors: List[str] = []

    # Repair path: if an older row has awards_text but the relevant field is
    # still missing, parse the text locally before any network lookup.
    if _awards_needs_fill(awards, media_type) and _awards_text_has_real_text_1388(awards):
        awards = _merge_missing_awards(awards, parse_mdblist_awards_wins(awards.get("awards_text")))

    if not _awards_needs_fill(awards, media_type):
        entry = dict(existing or {})
        entry.setdefault("type", item.get("type"))
        entry.setdefault("dbid", item.get("dbid"))
        entry.setdefault("title", item.get("title") or "")
        entry.setdefault("year", item.get("year") or "")
        entry["ids"] = ids
        entry["awards"] = awards
        entry["provider_meta"] = provider_meta
        entry["updated_at"] = now_iso()
        entry["timestamp"] = int(time.time())
        entry["errors"] = errors
        return entry

    mdblist_attempted = False
    mdblist_limited = bool(keys.get("__mdblist_limited"))
    mdblist_available = bool_setting("use_mdblist", True) and bool(keys.get("mdblist")) and not mdblist_limited

    if mdblist_available:
        mdblist_attempted = True
        try:
            _found, meta = mdblist_lookup(ids, "movie" if media_type == "movie" else "show", keys["mdblist"])
            provider_meta["mdblist"] = meta
            if meta.get("limited"):
                keys["__mdblist_limited"] = "true"
                mdblist_limited = True
                errors.append("mdblist: API limit reached; OMDb awards fallback allowed")
            elif str(meta.get("awards_text") or "").strip():
                awards = _merge_missing_awards(awards, parse_mdblist_awards_wins(meta.get("awards_text")))
            elif mdblist_lookup_cacheable(meta):
                awards = _merge_missing_awards(awards, parse_mdblist_awards_wins(""))
            for key, value in (meta.get("ids") or {}).items():
                if value not in (None, ""):
                    ids.setdefault(str(key), str(value))
        except ProviderLimitReached:
            keys["__mdblist_limited"] = "true"
            mdblist_limited = True
            errors.append("mdblist: API limit reached; OMDb awards fallback allowed")
        except Exception as exc:
            errors.append("mdblist: {0}".format(exc))

    # OMDb fallback is allowed when MDBList cannot be used or could not complete
    # the relevant award field. It still runs only while the relevant field is
    # missing, so cacheable MDBList no-awards markers do not cause extra calls.
    omdb_fallback_allowed = (
        mdblist_limited or
        not mdblist_available or
        (mdblist_attempted and _awards_needs_fill(awards, media_type))
    )
    if _awards_needs_fill(awards, media_type) and omdb_fallback_allowed and bool_setting("use_omdb", True) and keys.get("omdb"):
        try:
            found, ids, omdb_meta = omdb_lookup(item, ids, keys["omdb"])
            provider_meta["omdb"] = omdb_meta
            found_awards = found.pop("__awards", {}) if isinstance(found, dict) else {}
            if found_awards:
                awards = _merge_missing_awards(awards, found_awards)
        except ProviderLimitReached:
            raise
        except Exception as exc:
            errors.append("omdb: {0}".format(exc))

    # If a provider completed but no relevant win was found, mark the relevant
    # field N/A so the same item will not be scraped repeatedly. This does not
    # let the irrelevant cross-field mark future rows complete.
    if _awards_needs_fill(awards, media_type) and (provider_meta.get("mdblist") or provider_meta.get("omdb")):
        key = _award_relevant_key_1388(media_type)
        if key and awards.get(key) in (None, ""):
            awards[key] = METADATA_NA_VALUE
        if not str(awards.get("awards_text") or "").strip():
            awards["awards_text"] = METADATA_NA_VALUE

    entry = dict(existing or {})
    entry.setdefault("type", item.get("type"))
    entry.setdefault("dbid", item.get("dbid"))
    entry.setdefault("title", item.get("title") or "")
    entry.setdefault("year", item.get("year") or "")
    entry["ids"] = ids
    entry["awards"] = awards
    entry["provider_meta"] = provider_meta
    entry["errors"] = errors
    entry["updated_at"] = now_iso()
    entry["timestamp"] = int(time.time())
    return entry


def awards_missing_debug_counts(cache: Optional[Dict[str, Any]] = None) -> Dict[str, int]:
    """Small helper for manual debugging/status if needed."""
    cache = cache if isinstance(cache, dict) else load_cache()
    items = cache.get("items") or {}
    out = {"movie_missing_oscar": 0, "tvshow_missing_emmy": 0, "movie_checked": 0, "tvshow_checked": 0}
    for row in items.values():
        media_type = media_setting_type((row or {}).get("type"))
        if media_type not in ("movie", "tvshow"):
            continue
        awards = (row or {}).get("awards") or {}
        if _awards_needs_fill(awards, media_type):
            if media_type == "movie":
                out["movie_missing_oscar"] += 1
            else:
                out["tvshow_missing_emmy"] += 1
        else:
            if media_type == "movie":
                out["movie_checked"] += 1
            else:
                out["tvshow_checked"] += 1
    return out


# -----------------------------------------------------------------------------
# v1.3.89 awards parser fix: count WINS only, never nominated rows.
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 19)


def _awards_real_text_1389(value: Any) -> str:
    text = str(value if value is not None else "").strip()
    if not text or _is_metadata_na(text):
        return ""
    return text


def _awards_won_sections_1389(text: str) -> List[str]:
    """Return only MDBList/award text sections that are explicitly Won.

    MDBList can return list text like:
        Won: Best Picture (Oscars, 2002). Plus 1 more Oscars.
        Nominated: Best Director (Oscars, 2002).

    Older code counted every '(Oscars, YYYY)' and '(Emmys, YYYY)' occurrence,
    so Nominated rows became wins. This helper isolates only Won sections.
    """
    text = _awards_real_text_1389(text)
    if not text:
        return []
    sections: List[str] = []
    pattern = re.compile(r"(?is)\bWon\s*:\s*(.*?)(?=\b(?:Nominated|Nominee|Nomination|Nominations)\s*:|\bNominated\s+for\b|$)")
    for match in pattern.finditer(text):
        segment = str(match.group(1) or "").strip()
        if segment:
            sections.append(segment)
    # OMDb compact text usually does not use 'Won:' sections. Keep the full text
    # for the strict 'Won N Oscars/Emmys' regex, but never for '(Oscars, YYYY)'
    # occurrence counting.
    return sections


def _count_mdblist_award_wins_1389(text: str, award: str) -> int:
    text = _awards_real_text_1389(text)
    if not text:
        return 0
    sections = _awards_won_sections_1389(text)
    if not sections:
        return 0
    total = 0
    if award == "oscar":
        occurrence_re = re.compile(r"\(\s*Oscars?\s*,", re.I)
        plus_re = re.compile(r"\bplus\s+(\d+)\s+more\s+Oscars?\b", re.I)
    else:
        occurrence_re = re.compile(r"\(\s*(?:Primetime\s+|Daytime\s+|International\s+)?Emmys?\s*,", re.I)
        plus_re = re.compile(r"\bplus\s+(\d+)\s+more\s+(?:Primetime\s+|Daytime\s+|International\s+)?Emmys?\b", re.I)
    for segment in sections:
        total += len(occurrence_re.findall(segment))
        for m in plus_re.finditer(segment):
            total += safe_int(m.group(1)) or 0
    return total


def parse_mdblist_awards_wins(awards_text: Any) -> Dict[str, Any]:
    """Parse awards using win-only logic for MDBList and OMDb text.

    Important rules:
      * 'Nominated:' / 'Nominated for' never counts as a win.
      * '(Oscars, 2020)' and '(Emmys, 2020)' count only inside a 'Won:' section.
      * 'Plus N more Oscars/Emmys' counts only inside a 'Won:' section.
      * OMDb compact 'Won N Oscars/Primetime Emmys' still counts.
    """
    text = str(awards_text if awards_text is not None else "").strip()
    if not text:
        text = METADATA_NA_VALUE
    output: Dict[str, Any] = {"awards_text": text, "updated_at": now_iso(), "source": "awards"}
    if _is_metadata_na(text):
        output["oscar_wins"] = METADATA_NA_VALUE
        output["emmy_wins"] = METADATA_NA_VALUE
        return output

    oscar = 0
    emmy = 0
    # MDBList list-style, Won section only.
    oscar += _count_mdblist_award_wins_1389(text, "oscar")
    emmy += _count_mdblist_award_wins_1389(text, "emmy")
    # OMDb compact fallback. These regexes are intentionally strict: they only
    # match sentences beginning with Won N, not Nominated for N.
    oscar += _award_count(r"\bWon\s+(\d+)\s+Oscars?\b", text)
    emmy += _award_count(r"\bWon\s+(\d+)\s+(?:Primetime\s+|Daytime\s+|International\s+)?Emmys?\b", text)

    output["oscar_wins"] = oscar if oscar > 0 else METADATA_NA_VALUE
    output["emmy_wins"] = emmy if emmy > 0 else METADATA_NA_VALUE
    return output


def parse_awards_wins(awards_text: Any) -> Dict[str, Any]:
    return parse_mdblist_awards_wins(awards_text)


def _award_value_norm_1389(value: Any) -> str:
    if _is_metadata_na(value):
        return METADATA_NA_VALUE
    parsed = safe_int(value)
    if parsed is None or parsed <= 0:
        return METADATA_NA_VALUE
    return str(int(parsed))


def _force_reparsed_awards_1389(awards: Dict[str, Any], media_type: Any) -> Tuple[Dict[str, Any], bool]:
    """Reparse existing awards_text and overwrite old nominated-as-win values."""
    media_type = media_setting_type(media_type)
    merged = dict(awards or {})
    text = _awards_real_text_1389(merged.get("awards_text"))
    if media_type not in ("movie", "tvshow") or not text:
        return merged, False
    parsed = parse_mdblist_awards_wins(text)
    changed = False
    # Store both fields as parsed N/A/positive. Cross-field N/A is safe because
    # completion is decided by relevant key only.
    for key in ("oscar_wins", "emmy_wins"):
        new_value = parsed.get(key, METADATA_NA_VALUE)
        if _award_value_norm_1389(merged.get(key)) != _award_value_norm_1389(new_value):
            changed = True
        merged[key] = new_value
    if str(merged.get("awards_text") or "").strip() != str(parsed.get("awards_text") or "").strip():
        merged["awards_text"] = parsed.get("awards_text") or text
        changed = True
    return merged, changed


def _entry_with_awards_1389(item: Dict[str, Any], existing: Dict[str, Any], ids: Dict[str, str], awards: Dict[str, Any], provider_meta: Dict[str, Any], errors: Optional[List[str]] = None) -> Dict[str, Any]:
    entry = dict(existing or {})
    entry.setdefault("type", (item or {}).get("type"))
    entry.setdefault("dbid", (item or {}).get("dbid"))
    entry.setdefault("title", (item or {}).get("title") or "")
    entry.setdefault("year", (item or {}).get("year") or "")
    entry["ids"] = ids
    entry["awards"] = awards
    entry["provider_meta"] = provider_meta
    entry["errors"] = errors or []
    entry["updated_at"] = now_iso()
    entry["timestamp"] = int(time.time())
    return entry


_resolve_awards_only_1389_base = resolve_awards_only


def record_missing_awards(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    media_type = media_setting_type((item or {}).get("type"))
    awards = (record or {}).get("awards") or {}
    # Force awards-only to touch rows with old awards_text once, because 1.3.88
    # may have stored Nominated rows as positive wins.
    reparsed, changed = _force_reparsed_awards_1389(awards, media_type)
    if changed:
        return True
    return _awards_needs_fill(awards, media_type)


def resolve_awards_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    media_type = media_setting_type((item or {}).get("type"))
    existing = dict(existing or {})
    if media_type not in ("movie", "tvshow"):
        return existing

    ids = dict(existing.get("ids") or {})
    for key, value in extract_ids(item).items():
        if value not in (None, ""):
            ids.setdefault(str(key), str(value))
    awards = dict(existing.get("awards") or {})
    provider_meta = dict(existing.get("provider_meta") or {})

    reparsed, changed = _force_reparsed_awards_1389(awards, media_type)
    if changed:
        reparsed["updated_at"] = now_iso()
        return _entry_with_awards_1389(item, existing, ids, reparsed, provider_meta, ["awards_text reparsed win-only"])

    return _resolve_awards_only_1389_base(item, keys, existing)


# -----------------------------------------------------------------------------
# v1.3.90 awards policy fix: OMDb-only awards + no awards during rating pass.
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 20)

_LRS_SKIP_AWARDS_IN_NORMAL_RESOLVE_1390 = False


def _omdb_awards_text_1390(value: Any) -> str:
    text = str(value if value is not None else "").strip()
    if not text or _is_metadata_na(text):
        return ""
    return text


def parse_awards_wins(awards_text: Any) -> Dict[str, Any]:
    """Parse awards from OMDb only.

    Policy v1.3.90:
      * MDBList awards are never parsed or stored.
      * Only explicit OMDb phrases "Won N Oscars/Emmys" count.
      * "Nominated for N ..." never counts.
    """
    text = _omdb_awards_text_1390(awards_text)
    if not text:
        return {}
    oscar_wins = _award_count(r"\bWon\s+(\d+)\s+Oscars?\b", text)
    emmy_wins = _award_count(r"\bWon\s+(\d+)\s+(?:Primetime\s+|Daytime\s+|International\s+)?Emmys?\b", text)
    output: Dict[str, Any] = {"source": "omdb", "awards_text": text, "updated_at": now_iso()}
    if oscar_wins > 0:
        output["oscar_wins"] = int(oscar_wins)
    if emmy_wins > 0:
        output["emmy_wins"] = int(emmy_wins)
    return output


_mdblist_lookup_1390_base = mdblist_lookup

def mdblist_lookup(ids: Dict[str, str], media_type: str, key: Any) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    """MDBList is ratings-only in 1.3.90; awards_text is ignored completely."""
    found, meta = _mdblist_lookup_1390_base(ids, media_type, key)
    if isinstance(meta, dict):
        meta.pop("awards_text", None)
        meta["awards_policy"] = "ratings_only_awards_ignored_1390"
    return found, meta


def _award_relevant_key_1390(media_type: Any) -> str:
    media = media_setting_type(media_type)
    if media == "movie":
        return "oscar_wins"
    if media == "tvshow":
        return "emmy_wins"
    return ""


def _award_field_complete_1390(value: Any) -> bool:
    if _is_metadata_na(value):
        return True
    parsed = safe_int(value)
    return parsed is not None and parsed > 0


def _awards_needs_fill(awards: Dict[str, Any], media_type: Any) -> bool:
    if _LRS_SKIP_AWARDS_IN_NORMAL_RESOLVE_1390:
        return False
    media = media_setting_type(media_type)
    if media not in ("movie", "tvshow"):
        return False
    if not bool_setting("scrape_awards_wins", True):
        return False
    awards = awards if isinstance(awards, dict) else {}
    key = _award_relevant_key_1390(media)
    if not key:
        return False
    return not _award_field_complete_1390(awards.get(key))


def _merge_missing_awards(existing: Dict[str, Any], found: Dict[str, Any]) -> Dict[str, Any]:
    """Merge OMDb awards only. Do not preserve/merge MDBList award source."""
    merged = dict(existing or {})
    found = found or {}
    if str(found.get("source") or "").lower() and str(found.get("source") or "").lower() != "omdb":
        return merged
    for key in ("awards_text", "source", "updated_at"):
        if found.get(key) not in (None, ""):
            merged[key] = found[key]
    for key in ("oscar_wins", "emmy_wins"):
        if found.get(key) not in (None, ""):
            merged[key] = found[key]
    return merged


_resolve_item_1390_base = resolve_item

def resolve_item(item: Dict[str, Any], keys: Dict[str, str], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True, include_local: bool = True, ratings_only: bool = False) -> Dict[str, Any]:
    """Normal scrape/refresh is ratings/status/top250 only; awards run later."""
    global _LRS_SKIP_AWARDS_IN_NORMAL_RESOLVE_1390
    old = _LRS_SKIP_AWARDS_IN_NORMAL_RESOLVE_1390
    _LRS_SKIP_AWARDS_IN_NORMAL_RESOLVE_1390 = True
    try:
        return _resolve_item_1390_base(item, keys, existing, missing_only=missing_only, include_local=include_local, ratings_only=ratings_only)
    finally:
        _LRS_SKIP_AWARDS_IN_NORMAL_RESOLVE_1390 = old


def record_missing_awards(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    media = media_setting_type((item or {}).get("type"))
    return _awards_needs_fill((record or {}).get("awards") or {}, media)


def _entry_with_awards_1390(item: Dict[str, Any], existing: Dict[str, Any], ids: Dict[str, str], awards: Dict[str, Any], provider_meta: Dict[str, Any], errors: Optional[List[str]] = None) -> Dict[str, Any]:
    entry = dict(existing or {})
    entry.setdefault("type", (item or {}).get("type"))
    entry.setdefault("dbid", (item or {}).get("dbid"))
    entry.setdefault("title", (item or {}).get("title") or "")
    entry.setdefault("year", (item or {}).get("year") or "")
    entry["ids"] = ids
    entry["awards"] = awards
    entry["provider_meta"] = compact_provider_meta(provider_meta)
    entry["errors"] = errors or []
    entry["updated_at"] = now_iso()
    entry["timestamp"] = int(time.time())
    return entry


def _omdb_awards_missing_marker_1390(media_type: Any, awards: Dict[str, Any]) -> Dict[str, Any]:
    media = media_setting_type(media_type)
    awards = dict(awards or {})
    awards["source"] = "omdb"
    awards.setdefault("awards_text", METADATA_NA_VALUE)
    if media == "movie":
        awards["oscar_wins"] = METADATA_NA_VALUE
        awards["emmy_wins"] = METADATA_NA_VALUE
    elif media == "tvshow":
        awards["oscar_wins"] = METADATA_NA_VALUE
        awards["emmy_wins"] = METADATA_NA_VALUE
    awards["updated_at"] = now_iso()
    return awards


def resolve_awards_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """Awards-only pass uses OMDb only. MDBList is not called here."""
    media = media_setting_type((item or {}).get("type"))
    existing = dict(existing or {})
    if media not in ("movie", "tvshow"):
        return existing

    ids = dict(existing.get("ids") or {})
    for key, value in extract_ids(item).items():
        if value not in (None, ""):
            ids.setdefault(str(key), str(value))

    awards = dict(existing.get("awards") or {})
    provider_meta = dict(existing.get("provider_meta") or {})
    errors: List[str] = []

    if not bool_setting("use_omdb", True) or not keys.get("omdb"):
        errors.append("omdb: api key missing or provider disabled")
        return _entry_with_awards_1390(item, existing, ids, awards, provider_meta, errors)

    try:
        found, ids, omdb_meta = omdb_lookup(item, ids, keys["omdb"])
        provider_meta["omdb"] = omdb_meta
        found_awards = found.pop("__awards", {}) if isinstance(found, dict) else {}
        if found_awards:
            awards = _merge_missing_awards(awards, found_awards)
        # If OMDb responded but has no explicit Won N Oscars/Emmys, mark checked
        # so awards-only does not loop forever. Nominations remain ignored.
        if _awards_needs_fill(awards, media):
            awards = _omdb_awards_missing_marker_1390(media, awards)
    except ProviderLimitReached:
        raise
    except Exception as exc:  # pylint: disable=broad-except
        errors.append("omdb: {0}".format(exc))
    return _entry_with_awards_1390(item, existing, ids, awards, provider_meta, errors)


# -----------------------------------------------------------------------------
# v1.3.91 screensaver final clearlogo property fix
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 18)
_LAST_SCREENSAVER_CLEARLOGO_FINAL_LOG = ""


def update_screensaver_clearlogo_properties(item: Dict[str, Any]) -> Dict[str, str]:
    """Publish one final clearlogo path for Arctic Mirage.

    Older XML had two image controls (CropV2 + Container default clearlogo).
    During slide transitions Container(1297) can update before the LRS CropV2
    property, so the default logo can flash before CropV2. This function makes
    the addon choose the final image once, and XML renders only that one path.
    """
    try:
        import xbmcgui  # pylint: disable=import-outside-toplevel
        home = xbmcgui.Window(10000)
    except Exception:
        return {}
    try:
        item_title = str((item or {}).get("title") or xbmc.getInfoLabel("Container(1297).ListItem.Title") or "").strip()
        default_logo = xbmc.getInfoLabel("Container(1297).ListItem.Art(clearlogo)").strip()
    except Exception:
        item_title, default_logo = str((item or {}).get("title") or ""), ""

    chosen = {"image": "", "source": "", "title": ""}
    item_norm = _norm_text(item_title)
    candidates = _tmdbhelper_crop_candidates()
    for cand in candidates:
        cand_title = str(cand.get("title") or "").strip()
        if cand.get("image") and item_norm and cand_title and _norm_text(cand_title) == item_norm:
            chosen = cand
            break
    if not chosen.get("image") and item_norm and len(candidates) == 1 and not str(candidates[0].get("title") or "").strip():
        chosen = candidates[0]
    if not chosen.get("image"):
        local = _find_local_cropv2_by_logo_1383(default_logo)
        if local.get("image"):
            chosen = local

    if chosen.get("image"):
        mode = "cropv2"
        final_image = str(chosen.get("image") or "")
        final_source = str(chosen.get("source") or "cropv2")
    elif default_logo:
        mode = "default_kodi"
        final_image = default_logo
        final_source = "default_kodi"
    else:
        mode = "title"
        final_image = ""
        final_source = "title"

    try:
        item_key = identity_key(item or {})
    except Exception:
        item_key = ""
    props = {
        "CropV2Image": str(chosen.get("image") or ""),
        "CropV2Source": str(chosen.get("source") or ""),
        "CropV2Title": str(chosen.get("title") or ""),
        "DefaultClearLogo": default_logo,
        "ClearLogoMode": mode,
        "ClearLogoFinal": final_image,
        "ClearLogoFinalMode": mode,
        "ClearLogoFinalSource": final_source,
        "ClearLogoFinalTitle": item_title,
        "ClearLogoFinalItemKey": item_key,
    }
    for key, value in props.items():
        _publish_property(home, AF3_PREFIX + "Screensaver." + key, str(value or ""))

    global _LAST_SCREENSAVER_CLEARLOGO_LOG, _LAST_SCREENSAVER_CLEARLOGO_FINAL_LOG
    sig = "{0}|{1}|{2}|{3}|{4}".format(mode, item_title, final_image, chosen.get("image") or "", default_logo)
    if sig != _LAST_SCREENSAVER_CLEARLOGO_FINAL_LOG:
        _LAST_SCREENSAVER_CLEARLOGO_FINAL_LOG = sig
        _LAST_SCREENSAVER_CLEARLOGO_LOG = sig
        try:
            _record_screensaver_clearlogo_selection_1541({
                "title": item_title,
                "media_type": str((item or {}).get("type") or (item or {}).get("DBTYPE") or "video"),
                "item_key": item_key,
                "selected": mode,
                "source": final_source,
                "final_path": final_image,
                "cropv2_path": str(chosen.get("image") or ""),
                "default_path": default_logo,
                "candidate_count": len(candidates),
            })
        except Exception:
            pass
    return props


def clear_screensaver_clearlogo_properties() -> None:
    try:
        import xbmcgui  # pylint: disable=import-outside-toplevel
        home = xbmcgui.Window(10000)
    except Exception:
        return
    keys = (
        "CropV2Image", "CropV2Source", "CropV2Title", "DefaultClearLogo", "ClearLogoMode",
        "ClearLogoFinal", "ClearLogoFinalMode", "ClearLogoFinalSource", "ClearLogoFinalTitle", "ClearLogoFinalItemKey",
    )
    for key in keys:
        try:
            _publish_property(home, AF3_PREFIX + "Screensaver." + key, "")
        except Exception:
            pass

LRS_EXTRA_PROPERTY_NAMES = tuple(dict.fromkeys(tuple(LRS_EXTRA_PROPERTY_NAMES) + (
    "Screensaver.CropV2Image", "Screensaver.CropV2Source", "Screensaver.CropV2Title",
    "Screensaver.DefaultClearLogo", "Screensaver.ClearLogoMode",
    "Screensaver.ClearLogoFinal", "Screensaver.ClearLogoFinalMode", "Screensaver.ClearLogoFinalSource",
    "Screensaver.ClearLogoFinalTitle", "Screensaver.ClearLogoFinalItemKey",
)))


# -----------------------------------------------------------------------------
# v1.3.93 Rotten Tomatoes detail-page badge sync
# -----------------------------------------------------------------------------
# Policy:
#   * No more browse-list title matching for Certified Fresh / Verified Hot.
#   * Store only two new DB columns: rottentomatoes_slug, rottentomatoes_status.
#   * If slug is missing, use OMDb tomatoURL once to discover it.
#   * If slug exists, fetch Rotten Tomatoes detail page directly and parse the
#     media-scorecard JSON/HTML for the current title.
#   * RT Critics image values: certified / fresh / rotten.
#   * RT Audience image values: verifiedhot / upright / spilled.
CACHE_VERSION = max(CACHE_VERSION, 21)
RT_BASE_URL_1393 = "https://www.rottentomatoes.com"
RT_BADGE_SIMPLE_LOG_FILE = os.path.join(PROFILE, "rtbadge-simple.log")
RT_BADGE_DETAIL_LOG_FILE = os.path.join(PROFILE, "rtbadge-detail.log")
RT_BADGE_REPORT_FILE = os.path.join(PROFILE, "rt-badge-sync-report.csv")
RT_BADGE_NO_SLUG_REPORT_FILE = os.path.join(PROFILE, "no_slug.csv")
RT_BADGE_BAD_SLUG_404_REPORT_FILE = os.path.join(PROFILE, "bad_slug_404.csv")
RT_BADGE_BAD_SLUG_MISMATCH_REPORT_FILE = os.path.join(PROFILE, "bad_slug_mismatch.csv")
RT_BADGE_NOT_FOUND_REPORT_FILE = os.path.join(PROFILE, "badge_not_found.csv")
RT_BADGE_LAST_JSON_FILE = os.path.join(PROFILE, "rt-badge-sync-last.json")

# Keep these two columns near the end as requested, before updated_at/timestamp.
FINAL_RATINGS_COLUMNS = [
    "item_key", "title", "imdb", "tmdb", "rottentomatoes", "rottentomatoes_image",
    "rottentomatoes_user", "rottentomatoes_userimage", "metacritic", "trakt", "top250",
    "showtitle", "season", "episode", "year", "series_status", "series_status_date",
    "oscar_wins", "emmy_wins", "awards_text", "imdb_id", "tmdb_id", "dbid", "media_type",
    "rottentomatoes_slug", "rottentomatoes_status", "updated_at", "timestamp",
]
SIMPLE_RATING_COLUMNS = FINAL_RATINGS_COLUMNS


def _simple_rating_schema_sql() -> str:
    return """
        CREATE TABLE IF NOT EXISTS ratings (
            item_key TEXT PRIMARY KEY,
            title TEXT,
            imdb TEXT,
            tmdb TEXT,
            rottentomatoes TEXT,
            rottentomatoes_image TEXT,
            rottentomatoes_user TEXT,
            rottentomatoes_userimage TEXT,
            metacritic TEXT,
            trakt TEXT,
            top250 INTEGER,
            showtitle TEXT,
            season INTEGER,
            episode INTEGER,
            year TEXT,
            series_status TEXT,
            series_status_date TEXT,
            oscar_wins INTEGER,
            emmy_wins INTEGER,
            awards_text TEXT,
            imdb_id TEXT,
            tmdb_id TEXT,
            dbid INTEGER,
            media_type TEXT,
            rottentomatoes_slug TEXT,
            rottentomatoes_status TEXT,
            updated_at TEXT,
            timestamp INTEGER
        )
    """


def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    ratings = entry.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ids = entry.get("ids") or {}
    series = entry.get("series") or {}
    awards = entry.get("awards") or {}
    rt_images = entry.get("rt_images") if isinstance(entry.get("rt_images"), dict) else {}
    rt_badge = entry.get("rt_badge") if isinstance(entry.get("rt_badge"), dict) else {}

    rt_critic_cell = _display_number_for_db("rt_critic", ratings.get("rt_critic") or ratings.get("rottentomatoes") or {})
    rt_audience_cell = _display_number_for_db("rt_audience", ratings.get("rt_audience") or ratings.get("rottentomatoes_user") or {})
    metacritic_cell = _display_number_for_db("metacritic", ratings.get("metacritic") or {})
    trakt_cell = _display_number_for_db("trakt", ratings.get("trakt") or {})
    top250_value = _metadata_int_or_na(entry.get("imdb_top250_rank") if "imdb_top250_rank" in entry else entry.get("top250"))
    oscar_value = _metadata_int_or_na(awards.get("oscar_wins") if isinstance(awards, dict) and "oscar_wins" in awards else entry.get("oscar_wins"))
    emmy_value = _metadata_int_or_na(awards.get("emmy_wins") if isinstance(awards, dict) and "emmy_wins" in awards else entry.get("emmy_wins"))
    awards_text = str((awards or {}).get("awards_text") or entry.get("awards_text") or "")
    critic_image = str(rt_images.get("critic") or entry.get("rottentomatoes_image") or "").strip().lower()
    audience_image = str(rt_images.get("audience") or entry.get("rottentomatoes_userimage") or "").strip().lower()
    if critic_image not in ("certified", "fresh", "rotten"):
        critic_image = _simple_rating_image("rt_critic", rt_critic_cell)
    if audience_image not in ("verifiedhot", "upright", "spilled"):
        audience_image = _simple_rating_image("rt_audience", rt_audience_cell)
    slug = _normalize_rt_slug_1393(rt_badge.get("slug") or entry.get("rottentomatoes_slug") or "")
    status = str(rt_badge.get("status") or entry.get("rottentomatoes_status") or "")[:240]
    return (
        str(item_key),
        str(entry.get("title") or ""),
        _display_number_for_db("imdb", ratings.get("imdb") or {}),
        _display_number_for_db("tmdb", ratings.get("tmdb") or {}),
        rt_critic_cell,
        critic_image,
        rt_audience_cell,
        audience_image,
        metacritic_cell,
        trakt_cell,
        top250_value,
        str(entry.get("showtitle") or ""),
        safe_int(entry.get("season")),
        safe_int(entry.get("episode")),
        str(entry.get("year") or ""),
        str(series.get("status") or entry.get("series_status") or ""),
        str(series.get("status_date") or entry.get("series_status_date") or ""),
        oscar_value,
        emmy_value,
        awards_text,
        str(ids.get("imdb") or entry.get("imdb") or entry.get("imdbnumber") or ""),
        str(ids.get("tmdb") or entry.get("tmdb") or entry.get("tmdb_id") or ""),
        safe_int(entry.get("dbid")),
        str(entry.get("type") or ""),
        slug,
        status,
        str(entry.get("updated_at") or now_iso()).replace(" WIB", ""),
        safe_int(entry.get("timestamp")) or int(time.time()),
    )


_ratings_only_row_to_entry_1393_base = _ratings_only_row_to_entry

def _ratings_only_row_to_entry(row: sqlite3.Row) -> Dict[str, Any]:
    entry = _ratings_only_row_to_entry_1393_base(row)
    rt_image = str(_row_value(row, "rottentomatoes_image") or "").strip().lower()
    rt_user_image = str(_row_value(row, "rottentomatoes_userimage") or "").strip().lower()
    if rt_image or rt_user_image:
        entry["rt_images"] = {"critic": rt_image, "audience": rt_user_image}
    slug = _normalize_rt_slug_1393(_row_value(row, "rottentomatoes_slug"))
    status = str(_row_value(row, "rottentomatoes_status") or "").strip()
    if slug or status:
        entry["rt_badge"] = {"slug": slug, "status": status}
        entry["rottentomatoes_slug"] = slug
        entry["rottentomatoes_status"] = status
    return entry


# Icon file mapping extension for Verified Hot.
_lrs_audience_file_1393_base = _lrs_audience_file

def _lrs_audience_file(token: Any, rating_value: Any = None) -> str:
    text = str(token or "").strip().lower().replace(" ", "_").replace("-", "_")
    if text in ("verifiedhot", "verified_hot", "verified", "hot"):
        return "verified.png"
    return _lrs_audience_file_1393_base(token, rating_value)


def _rt_log_1393(message: str, level: int = xbmc.LOGINFO) -> None:
    log("RTBADGE {0}".format(message), level)


def _append_text_1393(path: str, text: str) -> None:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "a", encoding="utf-8") as fh:
            fh.write(str(text).rstrip() + "\n")
    except Exception as exc:  # pylint: disable=broad-except
        log("RTBADGE unable to write {0}: {1}".format(path, exc), xbmc.LOGWARNING)


def _write_json_1393(path: str, data: Dict[str, Any]) -> None:
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, "w", encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, ensure_ascii=False, sort_keys=True)
    except Exception as exc:  # pylint: disable=broad-except
        log("RTBADGE unable to write json {0}: {1}".format(path, exc), xbmc.LOGWARNING)


def _normalize_rt_slug_1393(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    if text.startswith("view-source:"):
        text = text[len("view-source:"):]
    text = text.split("#", 1)[0].split("?", 1)[0].strip()
    text = re.sub(r"^https?://(?:www\.)?rottentomatoes\.com", "", text, flags=re.I).strip()
    if not text.startswith("/"):
        text = "/" + text.lstrip("/")
    text = re.sub(r"/+$", "", text)
    if re.match(r"^/(?:m|tv)/[^\s]+$", text, re.I):
        return text
    return ""


def _rt_url_from_slug_1393(slug: Any) -> str:
    slug = _normalize_rt_slug_1393(slug)
    return (RT_BASE_URL_1393 + slug) if slug else ""


def _attr_value_1393(attrs: str, name: str) -> Optional[str]:
    if not attrs:
        return None
    m = re.search(r"(?:^|\s)%s\s*=\s*(['\"])(.*?)\1" % re.escape(name), attrs, re.I | re.S)
    if m:
        try:
            import html as _html1393  # pylint: disable=import-outside-toplevel
            return _html1393.unescape(m.group(2)).strip()
        except Exception:
            return m.group(2).strip()
    m = re.search(r"(?:^|\s)%s\s*=\s*([^\s>]+)" % re.escape(name), attrs, re.I | re.S)
    if m:
        return m.group(1).strip().strip("'\"")
    if re.search(r"(?:^|\s)%s(?:\s|$)" % re.escape(name), attrs, re.I):
        return "true"
    return None


def _bool_value_1393(value: Any) -> Optional[bool]:
    if isinstance(value, bool):
        return value
    if value is None:
        return None
    text = str(value).strip().lower()
    if text in ("true", "1", "yes", "certified"):
        return True
    if text in ("false", "0", "no", "none", ""):
        return False
    return None


def rt_badge_map_critic_1393(certified: Any, sentiment: Any) -> str:
    cert = _bool_value_1393(certified)
    sent = str(sentiment or "").strip().upper()
    if cert is True:
        return "certified"
    if sent == "POSITIVE":
        return "fresh"
    if sent == "NEGATIVE":
        return "rotten"
    return ""


def rt_badge_map_audience_1393(certified: Any, sentiment: Any) -> str:
    cert = _bool_value_1393(certified)
    sent = str(sentiment or "").strip().upper()
    if cert is True:
        return "verifiedhot"
    if sent == "POSITIVE":
        return "upright"
    if sent == "NEGATIVE":
        return "spilled"
    return ""


def _extract_script_json_1393(html_text: str, script_id: str) -> Tuple[Optional[Dict[str, Any]], str]:
    m = re.search(r'<script[^>]*id=["\']%s["\'][^>]*>(.*?)</script>' % re.escape(script_id), html_text or "", re.I | re.S)
    if not m:
        return None, "not_found"
    raw = m.group(1).strip()
    try:
        import html as _html1393  # pylint: disable=import-outside-toplevel
        raw = _html1393.unescape(raw)
    except Exception:
        pass
    try:
        parsed = json.loads(raw)
        return parsed if isinstance(parsed, dict) else None, "ok"
    except Exception as exc:  # pylint: disable=broad-except
        return None, "json_error:{0}".format(exc)


def _extract_media_scorecard_block_1393(html_text: str) -> str:
    html_text = html_text or ""
    idx = html_text.find('data-qa="section:media-scorecard"')
    if idx < 0:
        idx = html_text.find("data-qa='section:media-scorecard'")
    if idx < 0:
        idx = html_text.find("media-scorecard no-border")
    if idx < 0:
        return ""
    start = html_text.rfind("<div", 0, idx)
    if start < 0:
        start = idx
    candidates = []
    for token in ("<media-scorecard-manager", "</media-scorecard>", "<section", "<aside"):
        j = html_text.find(token, idx)
        if j > idx:
            candidates.append(j + (len("</media-scorecard>") if token == "</media-scorecard>" else 0))
    end = min(candidates) if candidates else min(len(html_text), start + 30000)
    return html_text[start:end]


def _find_icon_in_block_1393(block: str, kind: str) -> Dict[str, Any]:
    tag_name = "score-icon-critics" if kind == "critics" else "score-icon-audience"
    slot_name = "critics-score-icon" if kind == "critics" else "audience-score-icon"
    slot_idx = block.find('slot="%s"' % slot_name)
    if slot_idx < 0:
        slot_idx = block.find("slot='%s'" % slot_name)
    search_area = block[slot_idx:slot_idx + 2500] if slot_idx >= 0 else block
    m = re.search(r'<%s\b([^>]*)>' % re.escape(tag_name), search_area, re.I | re.S)
    if not m and search_area is not block:
        m = re.search(r'<%s\b([^>]*)>' % re.escape(tag_name), block, re.I | re.S)
    if not m:
        return {"found": False, "tag": "", "attrs": {}, "image": "", "method": "html_scorecard"}
    attrs_text = m.group(1) or ""
    attrs = {
        "certified": _attr_value_1393(attrs_text, "certified"),
        "sentiment": _attr_value_1393(attrs_text, "sentiment"),
        "size": _attr_value_1393(attrs_text, "size"),
        "slot": _attr_value_1393(attrs_text, "slot"),
    }
    attrs = {k: v for k, v in attrs.items() if v is not None}
    image = rt_badge_map_critic_1393(attrs.get("certified"), attrs.get("sentiment")) if kind == "critics" else rt_badge_map_audience_1393(attrs.get("certified"), attrs.get("sentiment"))
    return {"found": True, "tag": m.group(0), "attrs": attrs, "image": image, "method": "html_scorecard"}


def _extract_score_text_1393(block: str, kind: str) -> Dict[str, str]:
    prefix = "critics" if kind == "critics" else "audience"
    out = {"score": "", "reviews": ""}
    m = re.search(r'<rt-text\b[^>]*slot=["\']%s-score["\'][^>]*>(.*?)</rt-text>' % prefix, block or "", re.I | re.S)
    if m:
        try:
            import html as _html1393  # pylint: disable=import-outside-toplevel
            out["score"] = re.sub(r"\s+", " ", _html1393.unescape(re.sub(r"<.*?>", "", m.group(1)))).strip()
        except Exception:
            out["score"] = re.sub(r"\s+", " ", re.sub(r"<.*?>", "", m.group(1))).strip()
    m = re.search(r'<rt-link\b[^>]*slot=["\']%s-reviews["\'][^>]*>(.*?)</rt-link>' % prefix, block or "", re.I | re.S)
    if m:
        try:
            import html as _html1393  # pylint: disable=import-outside-toplevel
            out["reviews"] = re.sub(r"\s+", " ", _html1393.unescape(re.sub(r"<.*?>", "", m.group(1)))).strip()
        except Exception:
            out["reviews"] = re.sub(r"\s+", " ", re.sub(r"<.*?>", "", m.group(1))).strip()
    return out


def parse_rt_badges_detail_1393(html_text: str, url: str = "") -> Dict[str, Any]:
    scorecard_json, json_status = _extract_script_json_1393(html_text, "media-scorecard-json")
    block = _extract_media_scorecard_block_1393(html_text)
    critics_html = _find_icon_in_block_1393(block, "critics") if block else {"found": False, "image": "", "attrs": {}, "tag": "", "method": "html_scorecard"}
    audience_html = _find_icon_in_block_1393(block, "audience") if block else {"found": False, "image": "", "attrs": {}, "tag": "", "method": "html_scorecard"}
    critics_text = _extract_score_text_1393(block, "critics") if block else {"score": "", "reviews": ""}
    audience_text = _extract_score_text_1393(block, "audience") if block else {"score": "", "reviews": ""}
    critics_json = {"found": False, "image": "", "attrs": {}, "score": "", "reviews": "", "method": "media-scorecard-json"}
    audience_json = {"found": False, "image": "", "attrs": {}, "score": "", "reviews": "", "method": "media-scorecard-json"}
    if isinstance(scorecard_json, dict):
        cs = scorecard_json.get("criticsScore") or {}
        aus = scorecard_json.get("audienceScore") or {}
        if isinstance(cs, dict) and cs:
            critics_json.update({
                "found": True,
                "attrs": {"certified": cs.get("certified"), "sentiment": cs.get("sentiment")},
                "score": cs.get("scorePercent") or ((str(cs.get("score")) + "%") if cs.get("score") not in (None, "") else ""),
                "reviews": str(cs.get("reviewCount") or cs.get("ratingCount") or ""),
                "image": rt_badge_map_critic_1393(cs.get("certified"), cs.get("sentiment")),
                "raw": cs,
            })
        if isinstance(aus, dict) and aus:
            audience_json.update({
                "found": True,
                "attrs": {"certified": aus.get("certified"), "sentiment": aus.get("sentiment"), "scoreType": aus.get("scoreType")},
                "score": aus.get("scorePercent") or ((str(aus.get("score")) + "%") if aus.get("score") not in (None, "") else ""),
                "reviews": str(aus.get("bandedRatingCount") or aus.get("reviewCount") or ""),
                "image": rt_badge_map_audience_1393(aus.get("certified"), aus.get("sentiment")),
                "raw": aus,
            })
    critics_selected = critics_json if critics_json.get("found") and critics_json.get("image") else critics_html
    audience_selected = audience_json if audience_json.get("found") and audience_json.get("image") else audience_html
    if not critics_selected.get("score"):
        critics_selected["score"] = critics_text.get("score", "")
    if not critics_selected.get("reviews"):
        critics_selected["reviews"] = critics_text.get("reviews", "")
    if not audience_selected.get("score"):
        audience_selected["score"] = audience_text.get("score", "")
    if not audience_selected.get("reviews"):
        audience_selected["reviews"] = audience_text.get("reviews", "")
    return {
        "url": url,
        "scope": {"media_scorecard_found": bool(block), "media_scorecard_length": len(block), "media_scorecard_json_status": json_status, "ignored_global_score_icons": True},
        "critics": {"selected": critics_selected, "json": critics_json, "html": critics_html},
        "audience": {"selected": audience_selected, "json": audience_json, "html": audience_html},
        "result": {"rt_crit": critics_selected.get("image", ""), "rt_aud": audience_selected.get("image", ""), "critic_score": critics_selected.get("score", ""), "audience_score": audience_selected.get("score", "")},
    }


def _fetch_rt_detail_html_1393(slug: str) -> Dict[str, Any]:
    url = _rt_url_from_slug_1393(slug)
    result = {"url": url, "final_url": url, "ok": False, "status": 0, "bytes": 0, "content_type": "", "html": "", "error": ""}
    if not url:
        result["error"] = "missing_slug"
        return result
    try:
        req = Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        })
        with urlopen(req, timeout=max(15, NETWORK_TIMEOUT)) as response:  # nosec B310 RT URL only
            raw = response.read()
            result.update({
                "status": getattr(response, "status", 200) or 200,
                "final_url": getattr(response, "url", url) or url,
                "content_type": response.headers.get("Content-Type", "") if getattr(response, "headers", None) else "",
                "bytes": len(raw),
                "html": raw.decode("utf-8", "replace"),
            })
            result["ok"] = 200 <= int(result["status"]) < 400
    except HTTPError as exc:
        result["status"] = getattr(exc, "code", 0) or 0
        result["error"] = "HTTPError:{0}".format(exc)
        try:
            raw = exc.read()
            result["html"] = raw.decode("utf-8", "replace") if raw else ""
            result["bytes"] = len(raw) if raw else 0
        except Exception:
            pass
    except Exception as exc:  # pylint: disable=broad-except
        result["error"] = "{0}:{1}".format(exc.__class__.__name__, exc)
    return result


def _discover_rt_slug_from_omdb_1393(item: Dict[str, Any], ids: Dict[str, str], key: Any) -> Tuple[str, Dict[str, Any]]:
    meta: Dict[str, Any] = {"attempts": [], "source": "omdb_tomatoURL"}
    keys = _provider_key_list(key)
    if not keys:
        meta["error"] = "omdb_api_key_missing"
        return "", meta
    base_common = {"r": "json", "tomatoes": "true"}
    attempts: List[Dict[str, Any]] = []
    imdb_id = str(ids.get("imdb") or "").strip()
    if imdb_id.lower().startswith("tt"):
        attempts.append({"i": imdb_id})
    title = str(item.get("title") or "").strip()
    if title:
        params = {"t": title, "type": "series" if item.get("type") == "tvshow" else "movie"}
        year = safe_int(item.get("year"))
        if year:
            params["y"] = year
        attempts.append(params)
    seen = set()
    for key_index, current_key in enumerate(keys, start=1):
        if _provider_key_is_limited(key, key_index - 1):
            continue
        for base_attempt in attempts:
            params = dict(base_common)
            params.update(base_attempt)
            params["apikey"] = current_key
            query = urlencode(params)
            for scheme in ("http", "https"):
                url = "{0}://www.omdbapi.com/?{1}".format(scheme, query)
                if url in seen:
                    continue
                seen.add(url)
                public_params = _public_params(params)
                attempt_meta = {"key_index": key_index, "scheme": scheme, "params": public_params}
                payload: Dict[str, Any] = {}
                try:
                    payload, _headers = http_json(url)
                    attempt_meta.update({
                        "response": payload.get("Response") if isinstance(payload, dict) else "",
                        "http_status": payload.get("__http_status") if isinstance(payload, dict) else "",
                        "title": payload.get("Title") if isinstance(payload, dict) else "",
                        "year": payload.get("Year") if isinstance(payload, dict) else "",
                        "imdbID": payload.get("imdbID") if isinstance(payload, dict) else "",
                        "tomatoURL": payload.get("tomatoURL") if isinstance(payload, dict) else "",
                        "error": (payload.get("Error") or payload.get("__error") or "") if isinstance(payload, dict) else "",
                    })
                    if is_provider_limit_payload("omdb", payload):
                        _provider_mark_limited(key, key_index - 1)
                        attempt_meta["limited"] = True
                        meta["attempts"].append(attempt_meta)
                        break
                    slug = _normalize_rt_slug_1393(payload.get("tomatoURL") if isinstance(payload, dict) else "")
                    meta["attempts"].append(attempt_meta)
                    if slug:
                        meta["slug"] = slug
                        return slug, meta
                    if isinstance(payload, dict) and (_omdb_payload_has_data(payload) or str(payload.get("Response", "True")).lower() == "false"):
                        break
                except Exception as exc:  # pylint: disable=broad-except
                    attempt_meta["error"] = str(exc)
                    meta["attempts"].append(attempt_meta)
    meta["error"] = "tomatoURL_not_found"
    return "", meta



# -----------------------------------------------------------------------------
# v1.3.94 RT search repair helpers
# -----------------------------------------------------------------------------
# New policy:
#   * Normal "Sync Rotten Tomatoes badges" skips stable ok/badge_not_found rows.
#   * "Refresh all" re-checks every movie/tvshow.
#   * Missing slug, 404 slug, and slug mismatch are repaired through RT search.
#   * RT search never picks the first "All" result blindly:
#       movie  => /m/ rows + release-year
#       tvshow => /tv/ rows + start-year/end-year
#   * Bad old slugs are removed from rottentomatoes_slug, but preserved inside
#     rottentomatoes_status as e.g. "slug_mismatch (/m/62)".


def _rt_report_fieldnames_1394() -> List[str]:
    return [
        "checked_at", "media_type", "title", "year", "imdb_id", "tmdb_id", "slug", "url", "status", "http_status", "bytes",
        "final_url", "page_title", "old_slug", "new_slug", "search_query", "search_url", "search_status", "candidate_count", "best_candidate", "match_score", "mismatch_reason",
        "critic_score", "critic_certified", "critic_sentiment", "rt_crit", "old_critic", "new_critic",
        "audience_score", "audience_certified", "audience_sentiment", "rt_aud", "old_audience", "new_audience",
        "updated", "note",
    ]


def _rt_base_status_1394(status: Any) -> str:
    text = str(status or "").strip()
    if not text:
        return ""
    text = text.split(";", 1)[0].strip()
    text = re.sub(r"\s*\([^)]*\)\s*$", "", text).strip()
    return text.lower()


def _rt_status_is_stable_1394(status: Any) -> bool:
    return _rt_base_status_1394(status) in ("ok", "badge_not_found")


def _rt_status_with_old_slug_1394(status: str, old_slug: Any, source: str = "rt_search") -> str:
    old_slug = _normalize_rt_slug_1393(old_slug)
    base = str(status or "unknown")
    if old_slug:
        base += " ({0})".format(old_slug)
    return rt_badge_status_string_1393(base, source=source)


def _html_text_1394(value: Any) -> str:
    text = str(value or "")
    try:
        import html as _html1394  # pylint: disable=import-outside-toplevel
        text = _html1394.unescape(text)
    except Exception:
        pass
    text = re.sub(r"<script\b.*?</script>", " ", text, flags=re.I | re.S)
    text = re.sub(r"<style\b.*?</style>", " ", text, flags=re.I | re.S)
    text = re.sub(r"<[^>]+>", " ", text)
    return re.sub(r"\s+", " ", text).strip()


def _norm_title_1394(value: Any) -> str:
    text = _html_text_1394(value).lower()
    text = text.replace("&", " and ")
    text = re.sub(r"\b(rotten tomatoes|official site)\b", " ", text)
    text = re.sub(r"['’`´]", "", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _strip_leading_article_1394(text: str) -> str:
    return re.sub(r"^(?:the|a|an)\s+", "", str(text or "").strip())


def _title_score_1394(expected: Any, candidate: Any) -> int:
    exp = _norm_title_1394(expected)
    cand = _norm_title_1394(candidate)
    if not exp or not cand:
        return 0
    if exp == cand:
        return 100
    if _strip_leading_article_1394(exp) == _strip_leading_article_1394(cand):
        return 98
    ratio = int(round(SequenceMatcher(None, exp, cand).ratio() * 100))
    exp_tokens = set(exp.split())
    cand_tokens = set(cand.split())
    jaccard = int(round((len(exp_tokens & cand_tokens) / float(len(exp_tokens | cand_tokens) or 1)) * 100))
    # Containment can help titles with or without a leading article, but should not
    # accidentally accept subtitle spin-offs like "El Camino: A Breaking Bad Movie".
    contain = 0
    if len(exp) >= 6 and (" " + exp + " ") in (" " + cand + " "):
        contain = 82
    if len(cand) >= 6 and (" " + cand + " ") in (" " + exp + " "):
        contain = 88
    return max(ratio, jaccard, contain)


def _candidate_media_from_slug_1394(slug: Any) -> str:
    slug = _normalize_rt_slug_1393(slug)
    if slug.startswith("/m/"):
        return "movie"
    if slug.startswith("/tv/"):
        return "tvshow"
    return ""


def _year_score_1394(expected_year: Any, candidate: Dict[str, Any], media: str) -> int:
    expected = safe_int(expected_year)
    if not expected:
        return 45
    if media == "movie":
        release = safe_int(candidate.get("release_year"))
        if not release:
            return 35
        diff = abs(release - expected)
        if diff == 0:
            return 100
        if diff == 1:
            return 75
        return 0
    if media == "tvshow":
        start = safe_int(candidate.get("start_year"))
        end = safe_int(candidate.get("end_year"))
        if not start:
            return 35
        if expected == start:
            return 100
        if end and start <= expected <= end:
            return 75
        if not end and expected >= start:
            return 65
        if abs(expected - start) == 1:
            return 70
        return 0
    return 0


def _rt_candidate_score_1394(item: Dict[str, Any], candidate: Dict[str, Any]) -> Dict[str, Any]:
    media = media_setting_type((item or {}).get("type"))
    candidate_media = candidate.get("media_type") or _candidate_media_from_slug_1394(candidate.get("slug"))
    if media not in ("movie", "tvshow") or media != candidate_media:
        out = dict(candidate)
        out.update({"title_score": 0, "year_score": 0, "match_score": 0, "reject_reason": "media_type_mismatch"})
        return out
    title_score = _title_score_1394((item or {}).get("title"), candidate.get("title"))
    year_score = _year_score_1394((item or {}).get("year"), candidate, media)
    # Position is intentionally tiny. RT All often lists movie results before TV.
    pos_bonus = max(0, 10 - min(10, safe_int(candidate.get("position")) or 0))
    score = int(round((title_score * 0.65) + (year_score * 0.30) + (pos_bonus * 0.05)))
    reject_reason = ""
    if title_score < 84:
        reject_reason = "title_score_low"
    elif year_score <= 0:
        reject_reason = "year_mismatch"
    elif score < 84:
        reject_reason = "match_score_low"
    out = dict(candidate)
    out.update({"title_score": title_score, "year_score": year_score, "match_score": score, "reject_reason": reject_reason})
    return out


def _fetch_rt_search_html_1394(query: str) -> Dict[str, Any]:
    q = str(query or "").strip()
    url = RT_BASE_URL_1393 + "/search?search=" + quote(q)
    result = {"query": q, "url": url, "ok": False, "status": 0, "bytes": 0, "html": "", "error": ""}
    if not q:
        result["error"] = "missing_query"
        return result
    try:
        req = Request(url, headers={
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:152.0) Gecko/20100101 Firefox/152.0",
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Language": "en-US,en;q=0.9",
            "Cache-Control": "no-cache",
            "Pragma": "no-cache",
        })
        with urlopen(req, timeout=max(15, NETWORK_TIMEOUT)) as response:  # nosec B310 RT URL only
            raw = response.read()
            result.update({
                "status": getattr(response, "status", 200) or 200,
                "bytes": len(raw),
                "html": raw.decode("utf-8", "replace"),
            })
            result["ok"] = 200 <= int(result["status"] or 0) < 400
    except HTTPError as exc:
        result["status"] = getattr(exc, "code", 0) or 0
        result["error"] = "HTTPError:{0}".format(exc)
        try:
            raw = exc.read()
            result["html"] = raw.decode("utf-8", "replace") if raw else ""
            result["bytes"] = len(raw) if raw else 0
        except Exception:
            pass
    except Exception as exc:  # pylint: disable=broad-except
        result["error"] = "{0}:{1}".format(exc.__class__.__name__, exc)
    return result


def _parse_rt_search_rows_1394(html_text: str) -> List[Dict[str, Any]]:
    rows: List[Dict[str, Any]] = []
    text = html_text or ""
    for idx, match in enumerate(re.finditer(r"<search-page-media-row\b([^>]*)>(.*?)</search-page-media-row>", text, re.I | re.S), start=1):
        attrs_text = match.group(1) or ""
        block = match.group(2) or ""
        title = ""
        href = ""
        # Prefer the info-name link. Fallback to the image alt/title link.
        m = re.search(r"<a\b([^>]*data-qa=[\"']info-name[\"'][^>]*)>(.*?)</a>", block, re.I | re.S)
        if m:
            href = _attr_value_1393(m.group(1), "href") or ""
            title = _html_text_1394(m.group(2))
        if not href:
            m = re.search(r"<a\b([^>]*href=[\"'][^\"']*rottentomatoes\.com/(?:m|tv)/[^\"']+[\"'][^>]*)>", block, re.I | re.S)
            if m:
                href = _attr_value_1393(m.group(1), "href") or ""
        if not title:
            img = re.search(r"<img\b([^>]*)>", block, re.I | re.S)
            if img:
                title = _attr_value_1393(img.group(1), "alt") or ""
        slug = _normalize_rt_slug_1393(href)
        media = _candidate_media_from_slug_1394(slug)
        if not slug or media not in ("movie", "tvshow"):
            continue
        rows.append({
            "position": idx,
            "title": title,
            "slug": slug,
            "url": _rt_url_from_slug_1393(slug),
            "media_type": media,
            "release_year": safe_int(_attr_value_1393(attrs_text, "release-year")) or None,
            "start_year": safe_int(_attr_value_1393(attrs_text, "start-year")) or None,
            "end_year": safe_int(_attr_value_1393(attrs_text, "end-year")) or None,
            "tomatometer_score": _attr_value_1393(attrs_text, "tomatometer-score") or "",
            "tomatometer_certified": _attr_value_1393(attrs_text, "tomatometer-is-certified") or "",
            "tomatometer_sentiment": _attr_value_1393(attrs_text, "tomatometer-sentiment") or "",
        })
    return rows


def _rt_search_queries_1394(item: Dict[str, Any]) -> List[str]:
    title = str((item or {}).get("title") or "").strip()
    year = safe_int((item or {}).get("year"))
    queries: List[str] = []
    if title:
        queries.append(title)
        if year:
            queries.append("{0} {1}".format(title, year))
        # Light fallback for titles with subtitle punctuation; keep it conservative.
        short = re.split(r"\s*[:–—-]\s*", title, 1)[0].strip()
        if short and short.lower() != title.lower() and len(short) >= 4:
            queries.append(short)
    out: List[str] = []
    seen = set()
    for q in queries:
        key = _norm_title_1394(q)
        if key and key not in seen:
            seen.add(key)
            out.append(q)
    return out


def _discover_rt_slug_from_search_1394(item: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
    media = media_setting_type((item or {}).get("type"))
    meta: Dict[str, Any] = {"source": "rt_search", "attempts": [], "candidates": []}
    if media not in ("movie", "tvshow"):
        meta["error"] = "unsupported_media_type"
        return "", meta
    best: Dict[str, Any] = {}
    for query in _rt_search_queries_1394(item):
        fetch = _fetch_rt_search_html_1394(query)
        rows = _parse_rt_search_rows_1394(fetch.get("html") or "") if fetch.get("html") else []
        scored = [_rt_candidate_score_1394(item, row) for row in rows]
        scored.sort(key=lambda row: (safe_int(row.get("match_score")) or 0, -(safe_int(row.get("position")) or 9999)), reverse=True)
        attempt = {
            "query": query,
            "url": fetch.get("url"),
            "http_status": fetch.get("status") or 0,
            "bytes": fetch.get("bytes") or 0,
            "error": fetch.get("error") or "",
            "candidate_count": len(rows),
            "best": scored[0] if scored else {},
        }
        meta["attempts"].append(attempt)
        meta["candidates"].extend(scored[:10])
        if scored and (not best or (safe_int(scored[0].get("match_score")) or 0) > (safe_int(best.get("match_score")) or 0)):
            best = dict(scored[0])
        if scored:
            top = scored[0]
            if not top.get("reject_reason") and (safe_int(top.get("match_score")) or 0) >= 84:
                meta["slug"] = top.get("slug") or ""
                meta["best"] = top
                meta["query"] = query
                meta["url"] = fetch.get("url") or ""
                return str(top.get("slug") or ""), meta
    meta["best"] = best
    if best:
        meta["error"] = best.get("reject_reason") or "no_acceptable_candidate"
    else:
        meta["error"] = "no_candidates"
    return "", meta


def _extract_rt_page_title_1394(html_text: str) -> str:
    text = html_text or ""
    patterns = [
        r"<meta\b[^>]*(?:property|name)=[\"']og:title[\"'][^>]*content=[\"'](.*?)[\"'][^>]*>",
        r"<meta\b[^>]*content=[\"'](.*?)[\"'][^>]*(?:property|name)=[\"']og:title[\"'][^>]*>",
        r"<title[^>]*>(.*?)</title>",
        r"<h1[^>]*>(.*?)</h1>",
    ]
    for pat in patterns:
        m = re.search(pat, text, re.I | re.S)
        if m:
            title = _html_text_1394(m.group(1))
            title = re.sub(r"\s*[-|]\s*Rotten Tomatoes\s*$", "", title, flags=re.I).strip()
            title = re.sub(r"\s*Pictures and Photo Gallery\s*$", "", title, flags=re.I).strip()
            if title:
                return title
    return ""


def _validate_rt_detail_match_1394(item: Dict[str, Any], slug: str, html_text: str, final_url: str = "") -> Dict[str, Any]:
    media = media_setting_type((item or {}).get("type"))
    slug = _normalize_rt_slug_1393(slug)
    page_title = _extract_rt_page_title_1394(html_text)
    slug_media = _candidate_media_from_slug_1394(slug)
    final_slug = _normalize_rt_slug_1393(final_url or "")
    final_media = _candidate_media_from_slug_1394(final_slug) if final_slug else slug_media
    score = _title_score_1394((item or {}).get("title"), page_title)
    reason = ""
    if media not in ("movie", "tvshow"):
        reason = "unsupported_media_type"
    elif slug_media and slug_media != media:
        reason = "slug_media_type_mismatch"
    elif final_media and final_media != media:
        reason = "final_url_media_type_mismatch"
    elif page_title and score < 74:
        # If the visible page title is very different, treat it as a bad slug.
        reason = "title_mismatch:{0}".format(score)
    return {"ok": not bool(reason), "page_title": page_title, "title_score": score, "reason": reason, "final_slug": final_slug}


def _write_rt_special_report_1394(path: str, result: Dict[str, Any]) -> None:
    try:
        os.makedirs(PROFILE, exist_ok=True)
        new_file = not os.path.exists(path) or os.path.getsize(path) == 0
        fieldnames = _rt_report_fieldnames_1394()
        with open(path, "a", encoding="utf-8-sig", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            if new_file:
                writer.writeheader()
            writer.writerow({name: result.get(name, "") for name in fieldnames})
    except Exception as exc:  # pylint: disable=broad-except
        log("RTBADGE unable to write special CSV {0}: {1}".format(path, exc), xbmc.LOGWARNING)


def _write_rt_status_report_1394(result: Dict[str, Any]) -> None:
    status = _rt_base_status_1394(result.get("status"))
    if status == "no_slug":
        _write_rt_special_report_1394(RT_BADGE_NO_SLUG_REPORT_FILE, result)
    elif status == "fetch_error_404":
        _write_rt_special_report_1394(RT_BADGE_BAD_SLUG_404_REPORT_FILE, result)
    elif status == "slug_mismatch":
        _write_rt_special_report_1394(RT_BADGE_BAD_SLUG_MISMATCH_REPORT_FILE, result)
    elif status == "badge_not_found":
        _write_rt_special_report_1394(RT_BADGE_NOT_FOUND_REPORT_FILE, result)


def _rt_search_summary_to_result_1394(result: Dict[str, Any], meta: Dict[str, Any]) -> None:
    if not isinstance(meta, dict):
        return
    result["search_query"] = meta.get("query") or ""
    result["search_url"] = meta.get("url") or ""
    result["search_status"] = meta.get("error") or ("ok" if meta.get("slug") else "")
    best = meta.get("best") if isinstance(meta.get("best"), dict) else {}
    result["candidate_count"] = sum(safe_int((a or {}).get("candidate_count")) or 0 for a in (meta.get("attempts") or []) if isinstance(a, dict))
    result["best_candidate"] = (best.get("slug") or "") if best else ""
    result["match_score"] = best.get("match_score", "") if best else ""


def rt_badge_status_string_1393(status: str, rt_crit: str = "", rt_aud: str = "", source: str = "") -> str:
    parts = [str(status or "unknown")]
    if rt_crit:
        parts.append("crit=" + str(rt_crit))
    if rt_aud:
        parts.append("aud=" + str(rt_aud))
    if source:
        parts.append("src=" + str(source))
    parts.append(now_iso())
    return ";".join(parts)[:240]


def _rt_badge_simple_line_1393(result: Dict[str, Any]) -> str:
    return (
        "{time} | {title} | {media_type} | status={status} http={http_status} bytes={bytes} | "
        "slug={slug} | rt_crit={rt_crit} score={critic_score} cert={c_cert} sent={c_sent} src={c_src} old={old_crit} new={new_crit} | "
        "rt_aud={rt_aud} score={audience_score} cert={a_cert} sent={a_sent} src={a_src} old={old_aud} new={new_aud} | updated={updated} note={note}"
    ).format(
        time=result.get("checked_at") or now_iso(),
        title=result.get("title", ""),
        media_type=result.get("media_type", ""),
        status=result.get("status", ""),
        http_status=result.get("http_status", ""),
        bytes=result.get("bytes", ""),
        slug=result.get("slug", ""),
        rt_crit=result.get("rt_crit", ""),
        critic_score=result.get("critic_score", ""),
        c_cert=result.get("critic_certified", ""),
        c_sent=result.get("critic_sentiment", ""),
        c_src=result.get("critic_source", ""),
        old_crit=result.get("old_critic", ""),
        new_crit=result.get("new_critic", ""),
        rt_aud=result.get("rt_aud", ""),
        audience_score=result.get("audience_score", ""),
        a_cert=result.get("audience_certified", ""),
        a_sent=result.get("audience_sentiment", ""),
        a_src=result.get("audience_source", ""),
        old_aud=result.get("old_audience", ""),
        new_aud=result.get("new_audience", ""),
        updated="yes" if result.get("updated") else "no",
        note=result.get("note", ""),
    )


def _rt_badge_write_result_1393(result: Dict[str, Any]) -> None:
    simple = _rt_badge_simple_line_1393(result)
    _append_text_1393(RT_BADGE_SIMPLE_LOG_FILE, simple)
    detail = ["=" * 88, "RTBADGE DETAIL", simple]
    for key in ("url", "final_url", "page_title", "mismatch_reason", "scope", "omdb_meta", "search_query", "search_url", "search_status", "best_candidate", "match_score", "fetch_error", "parser"):
        if key in result:
            try:
                detail.append("{0}: {1}".format(key, json.dumps(result.get(key), ensure_ascii=False, sort_keys=True)[:4000]))
            except Exception:
                detail.append("{0}: {1}".format(key, result.get(key)))
    _append_text_1393(RT_BADGE_DETAIL_LOG_FILE, "\n".join(detail))
    _write_json_1393(RT_BADGE_LAST_JSON_FILE, result)
    # CSV report for the latest run is reset by start_rt_badge_report_1393().
    try:
        new_file = not os.path.exists(RT_BADGE_REPORT_FILE) or os.path.getsize(RT_BADGE_REPORT_FILE) == 0
        fieldnames = _rt_report_fieldnames_1394()
        with open(RT_BADGE_REPORT_FILE, "a", encoding="utf-8-sig", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            if new_file:
                writer.writeheader()
            writer.writerow({name: result.get(name, "") for name in fieldnames})
    except Exception as exc:  # pylint: disable=broad-except
        log("RTBADGE unable to write CSV: {0}".format(exc), xbmc.LOGWARNING)
    _write_rt_status_report_1394(result)


def start_rt_badge_report_1393(action: str = "rtbadges") -> str:
    try:
        os.makedirs(PROFILE, exist_ok=True)
        with open(RT_BADGE_REPORT_FILE, "w", encoding="utf-8-sig", newline="") as fh:
            fieldnames = _rt_report_fieldnames_1394()
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            writer.writeheader()
        for _rt_path in (RT_BADGE_NO_SLUG_REPORT_FILE, RT_BADGE_BAD_SLUG_404_REPORT_FILE, RT_BADGE_BAD_SLUG_MISMATCH_REPORT_FILE, RT_BADGE_NOT_FOUND_REPORT_FILE):
            try:
                with open(_rt_path, "w", encoding="utf-8-sig", newline="") as _fh:
                    csv.DictWriter(_fh, fieldnames=_rt_report_fieldnames_1394()).writeheader()
            except Exception:
                pass
        _append_text_1393(RT_BADGE_SIMPLE_LOG_FILE, "---- {0} {1} action={2} ----".format("RTBADGE", now_iso(), action))
        _append_text_1393(RT_BADGE_DETAIL_LOG_FILE, "\n" + "#" * 88 + "\nRTBADGE RUN START {0} action={1}".format(now_iso(), action))
    except Exception as exc:  # pylint: disable=broad-except
        log("RTBADGE unable to start report: {0}".format(exc), xbmc.LOGWARNING)
    return RT_BADGE_REPORT_FILE


def record_missing_rt_badge(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    media = media_setting_type((item or {}).get("type"))
    if media not in ("movie", "tvshow"):
        return False
    badge = (record or {}).get("rt_badge") if isinstance((record or {}).get("rt_badge"), dict) else {}
    status = badge.get("status") or (record or {}).get("rottentomatoes_status") or ""
    # Normal RT badge sync is now missing/repair-only. Stable rows are skipped;
    # Refresh all bypasses this function from service.py.
    if _rt_status_is_stable_1394(status):
        return False
    ids = (record or {}).get("ids") or extract_ids(item or {})
    return bool(ids.get("imdb") or (item or {}).get("title"))


def _rt_apply_final_badge_1394(entry: Dict[str, Any], badge: Dict[str, Any], rt_images: Dict[str, Any], slug: str, status_string: str, checked_at: str) -> Dict[str, Any]:
    badge.update({"slug": _normalize_rt_slug_1393(slug), "status": status_string})
    entry["rt_badge"] = badge
    entry["rt_images"] = rt_images
    entry["rottentomatoes_slug"] = _normalize_rt_slug_1393(slug)
    entry["rottentomatoes_status"] = status_string
    entry["updated_at"] = checked_at
    entry["timestamp"] = int(time.time())
    return entry


def _rt_attempt_search_repair_1394(item: Dict[str, Any], result: Dict[str, Any], reason: str) -> Tuple[str, Dict[str, Any]]:
    search_slug, search_meta = _discover_rt_slug_from_search_1394(item or {})
    _rt_search_summary_to_result_1394(result, search_meta)
    if search_slug:
        result["new_slug"] = search_slug
        result["note"] = (str(result.get("note") or "") + ";" if result.get("note") else "") + "search_repair:{0}".format(reason)
    else:
        result["note"] = (str(result.get("note") or "") + ";" if result.get("note") else "") + "search_failed:{0}:{1}".format(reason, (search_meta or {}).get("error") or "")
    return search_slug, search_meta


def resolve_rt_badge_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None, force: bool = False) -> Dict[str, Any]:
    media = media_setting_type((item or {}).get("type"))
    existing = dict(existing or {})
    entry = dict(existing or {})
    entry.setdefault("type", (item or {}).get("type"))
    entry.setdefault("dbid", (item or {}).get("dbid"))
    entry.setdefault("title", (item or {}).get("title") or "")
    entry.setdefault("year", (item or {}).get("year") or "")
    entry.setdefault("showtitle", (item or {}).get("showtitle") or "")
    entry.setdefault("ratings", (existing or {}).get("ratings") or {})
    entry.setdefault("awards", (existing or {}).get("awards") or {})
    entry.setdefault("series", (existing or {}).get("series") or {})
    ids = dict((existing or {}).get("ids") or {})
    for k, v in extract_ids(item or {}).items():
        if v not in (None, ""):
            ids.setdefault(str(k), str(v))
    entry["ids"] = ids

    rt_images = dict((existing or {}).get("rt_images") or {})
    if not rt_images:
        rt_images = {
            "critic": str((existing or {}).get("rottentomatoes_image") or "").strip().lower(),
            "audience": str((existing or {}).get("rottentomatoes_userimage") or "").strip().lower(),
        }
    old_critic = str(rt_images.get("critic") or "").strip().lower()
    old_audience = str(rt_images.get("audience") or "").strip().lower()

    badge = dict((existing or {}).get("rt_badge") or {})
    slug = _normalize_rt_slug_1393(badge.get("slug") or (existing or {}).get("rottentomatoes_slug") or "")
    checked_at = now_iso()
    result: Dict[str, Any] = {
        "checked_at": checked_at,
        "media_type": media,
        "title": entry.get("title") or "",
        "year": entry.get("year") or "",
        "imdb_id": ids.get("imdb", ""),
        "tmdb_id": ids.get("tmdb", ""),
        "slug": slug,
        "old_slug": slug,
        "url": _rt_url_from_slug_1393(slug),
        "status": "started",
        "old_critic": old_critic,
        "new_critic": old_critic,
        "old_audience": old_audience,
        "new_audience": old_audience,
        "updated": False,
    }
    if media not in ("movie", "tvshow"):
        result["status"] = "skipped_media_type"
        result["note"] = "not_movie_or_tvshow"
        _rt_badge_write_result_1393(result)
        return entry

    # Slug discovery policy:
    # 1) Existing/manual slug is trusted only after detail validation.
    # 2) Missing slug uses RT search first, not OMDb. This fixes TV show cases.
    # 3) Movie-only OMDb tomatoURL remains a fallback when RT search has no acceptable candidate.
    if not slug:
        search_slug, search_meta = _rt_attempt_search_repair_1394(item or entry, result, "missing_slug")
        if search_slug:
            slug = search_slug
        elif media == "movie":
            omdb_slug, omdb_meta = _discover_rt_slug_from_omdb_1393(item or entry, ids, (keys or {}).get("omdb"))
            result["omdb_meta"] = omdb_meta
            if omdb_slug:
                slug = omdb_slug
                result["note"] = (str(result.get("note") or "") + ";" if result.get("note") else "") + "omdb_fallback_slug"
        result["slug"] = slug
        result["url"] = _rt_url_from_slug_1393(slug)

    if not slug:
        status = "no_slug"
        status_string = rt_badge_status_string_1393(status, source="rt_search")
        badge.update({"slug": "", "status": status_string})
        entry["rt_badge"] = badge
        entry["rottentomatoes_slug"] = ""
        entry["rottentomatoes_status"] = status_string
        entry["updated_at"] = checked_at
        entry["timestamp"] = int(time.time())
        result.update({"status": status, "note": result.get("note") or "rt_search_no_match"})
        _rt_badge_write_result_1393(result)
        return entry

    def _process_slug(current_slug: str, repair_reason: str = "") -> Tuple[Optional[Dict[str, Any]], Dict[str, Any], str]:
        fetch = _fetch_rt_detail_html_1393(current_slug)
        html_text = fetch.pop("html", "")
        local_result = {
            "slug": current_slug,
            "url": fetch.get("url") or _rt_url_from_slug_1393(current_slug),
            "final_url": fetch.get("final_url") or "",
            "http_status": fetch.get("status") or 0,
            "bytes": fetch.get("bytes") or 0,
            "fetch_error": fetch.get("error") or "",
        }
        if not fetch.get("ok") or not html_text:
            local_result["status"] = "fetch_error_{0}".format(fetch.get("status") or "network")
            local_result["note"] = fetch.get("error") or "no_html"
            return None, local_result, html_text
        validation = _validate_rt_detail_match_1394(item or entry, current_slug, html_text, fetch.get("final_url") or fetch.get("url") or "")
        local_result.update({
            "page_title": validation.get("page_title") or "",
            "mismatch_reason": validation.get("reason") or "",
        })
        if not validation.get("ok"):
            local_result["status"] = "slug_mismatch"
            local_result["note"] = validation.get("reason") or "detail_identity_mismatch"
            return None, local_result, html_text
        parsed = parse_rt_badges_detail_1393(html_text, fetch.get("final_url") or fetch.get("url") or "")
        local_result["parser"] = parsed
        return parsed, local_result, html_text

    parsed, detail_result, _html_text = _process_slug(slug)
    result.update(detail_result)

    # 404/mismatch repair: search by title/type/year. If a new valid slug is found,
    # process it immediately. If not, clear the bad slug but preserve it in status.
    base_status = _rt_base_status_1394(result.get("status"))
    if base_status in ("fetch_error_404", "slug_mismatch"):
        old_slug = slug
        repair_slug, _repair_meta = _rt_attempt_search_repair_1394(item or entry, result, base_status)
        if repair_slug and repair_slug != old_slug:
            parsed2, detail2, _html2 = _process_slug(repair_slug, base_status)
            result.update(detail2)
            result["old_slug"] = old_slug
            result["new_slug"] = repair_slug
            slug = repair_slug
            parsed = parsed2
            base_status = _rt_base_status_1394(result.get("status"))
        if base_status in ("fetch_error_404", "slug_mismatch"):
            status = base_status
            status_string = _rt_status_with_old_slug_1394(status, old_slug, source="rt_search")
            badge.update({"slug": "", "status": status_string})
            entry["rt_badge"] = badge
            entry["rottentomatoes_slug"] = ""
            entry["rottentomatoes_status"] = status_string
            entry["updated_at"] = checked_at
            entry["timestamp"] = int(time.time())
            result.update({"status": status, "slug": "", "old_slug": old_slug, "new_slug": "", "updated": False})
            _rt_badge_write_result_1393(result)
            return entry

    if not parsed:
        # Non-404 transient fetch errors keep the existing slug so a later retry can succeed.
        status = _rt_base_status_1394(result.get("status")) or "fetch_error_network"
        status_string = rt_badge_status_string_1393(status, source="rt_detail")
        badge.update({"slug": slug, "status": status_string})
        entry["rt_badge"] = badge
        entry["rottentomatoes_slug"] = slug
        entry["rottentomatoes_status"] = status_string
        entry["updated_at"] = checked_at
        entry["timestamp"] = int(time.time())
        result.update({"status": status, "updated": False})
        _rt_badge_write_result_1393(result)
        return entry

    scope = parsed.get("scope") or {}
    critic = ((parsed.get("critics") or {}).get("selected") or {})
    audience = ((parsed.get("audience") or {}).get("selected") or {})
    rt_crit = str((parsed.get("result") or {}).get("rt_crit") or "").strip().lower()
    rt_aud = str((parsed.get("result") or {}).get("rt_aud") or "").strip().lower()
    result.update({
        "rt_crit": rt_crit,
        "critic_score": (parsed.get("result") or {}).get("critic_score") or "",
        "critic_certified": (critic.get("attrs") or {}).get("certified", ""),
        "critic_sentiment": (critic.get("attrs") or {}).get("sentiment", ""),
        "critic_source": critic.get("method", ""),
        "rt_aud": rt_aud,
        "audience_score": (parsed.get("result") or {}).get("audience_score") or "",
        "audience_certified": (audience.get("attrs") or {}).get("certified", ""),
        "audience_sentiment": (audience.get("attrs") or {}).get("sentiment", ""),
        "audience_source": audience.get("method", ""),
        "scope": scope,
    })
    changed = False
    if rt_crit in ("certified", "fresh", "rotten") and old_critic != rt_crit:
        rt_images["critic"] = rt_crit
        result["new_critic"] = rt_crit
        changed = True
    if rt_aud in ("verifiedhot", "upright", "spilled") and old_audience != rt_aud:
        rt_images["audience"] = rt_aud
        result["new_audience"] = rt_aud
        changed = True
    if not rt_crit and not rt_aud:
        status = "scorecard_not_found" if not scope.get("media_scorecard_found") else "badge_not_found"
    else:
        status = "ok"
    status_string = rt_badge_status_string_1393(status, rt_crit, rt_aud, (critic.get("method") or audience.get("method") or "rt_detail"))
    _rt_apply_final_badge_1394(entry, badge, rt_images, slug, status_string, checked_at)
    result.update({"status": status, "slug": slug, "updated": changed, "note": "" if changed else "no_image_change"})
    _rt_badge_write_result_1393(result)
    _rt_log_1393("{0} | {1}".format(result.get("title", ""), _rt_badge_simple_line_1393(result)), xbmc.LOGINFO)
    return entry


# Add RT badge metadata to the standard CSV export.
def export_csv(cache: Dict[str, Any]) -> str:
    os.makedirs(PROFILE, exist_ok=True)
    entries = list((cache.get("items") or {}).values())
    canonical_entries = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        row = dict(entry)
        row["ratings"] = preserve_ratings_for_item(row.get("type"), row.get("ratings") or {})
        canonical_entries.append(row)
    sources = sorted({source for entry in canonical_entries for source in (entry.get("ratings") or {}).keys()})
    fixed = [
        "type", "dbid", "title", "showtitle", "season", "episode", "year",
        "tmdb_id", "imdb_id", "imdb_top250_rank",
        "oscar_wins", "emmy_wins", "series_status", "series_status_date",
        "rottentomatoes_slug", "rottentomatoes_status", "updated_at",
    ]
    rating_columns = ["rating_{0}".format(source) for source in sources]
    columns = fixed + rating_columns
    with open(REPORT_FILE, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for entry in sorted(canonical_entries, key=lambda row: (str(row.get("type")), str(row.get("showtitle")), str(row.get("title")), safe_int(row.get("season")) or -1, safe_int(row.get("episode")) or -1)):
            row = {key: entry.get(key, "") for key in fixed}
            ids = entry.get("ids") or {}
            row["tmdb_id"] = _csv_tmdb_id(ids.get("tmdb"))
            row["imdb_id"] = _csv_imdb_id(ids.get("imdb"))
            row["imdb_top250_rank"] = csv_top250_rank(entry)
            awards = entry.get("awards") or {}
            row["oscar_wins"] = awards.get("oscar_wins", "")
            row["emmy_wins"] = awards.get("emmy_wins", "")
            series = entry.get("series") or {}
            row["series_status"] = series.get("status", "")
            row["series_status_date"] = series.get("status_date", "")
            rt_badge = entry.get("rt_badge") if isinstance(entry.get("rt_badge"), dict) else {}
            row["rottentomatoes_slug"] = rt_badge.get("slug") or entry.get("rottentomatoes_slug") or ""
            row["rottentomatoes_status"] = rt_badge.get("status") or entry.get("rottentomatoes_status") or ""
            for source in sources:
                rating = (entry.get("ratings") or {}).get(source) or {}
                if is_no_rating_marker(rating):
                    row["rating_{0}".format(source)] = NO_RATING_VALUE
                else:
                    value = rating.get("value")
                    row["rating_{0}".format(source)] = "" if value in (None, "") else value
            writer.writerow(row)
    return REPORT_FILE


# -----------------------------------------------------------------------------
# v1.3.95 RT search/identity/rating-N/A fix
# -----------------------------------------------------------------------------
# Fixes from real 1.3.94 reports:
#   * RT 0% is a valid Rotten Tomatoes rating, not N/A.
#   * If either RT critics or RT audience rating is N/A/missing, skip RT badge
#     detail/search and persist slug/status as literal N/A.
#   * Search candidates with exact title but weak/missing search-row year are
#     allowed through to detail-page validation instead of becoming no_slug.
#   * Detail-page title validation strips RT year suffixes such as "Jumbo (2025)".
#   * Old/imported slugs may be international-title aliases when the year matches;
#     do not falsely mark those as slug_mismatch.
CACHE_VERSION = max(CACHE_VERSION, 22)


def _is_text_na_1395(value: Any) -> bool:
    text = str(value if value is not None else "").strip()
    return not text or text.upper() in ("N/A", "NA", "NO_RATING", "NONE", "NULL", "-")


def _rt_number_or_none_1395(value: Any) -> Optional[float]:
    if value is None:
        return None
    text = str(value).strip()
    if _is_text_na_1395(text):
        return None
    return safe_float(text.replace("%", ""))


def _rt_side_is_na_1395(entry: Dict[str, Any], logical: str, cell_key: str) -> bool:
    ratings = (entry or {}).get("ratings") or {}
    rating = ratings.get(logical)
    if not rating and logical == "rt_critic":
        rating = ratings.get("rottentomatoes")
    if not rating and logical == "rt_audience":
        rating = ratings.get("rottentomatoes_user")
    if isinstance(rating, dict):
        if is_no_rating_marker(rating) or rating.get("no_rating"):
            return True
        for key in ("score", "value"):
            number = _rt_number_or_none_1395(rating.get(key))
            if number is not None:
                return False  # 0 is valid for RT.
        # Explicit rating dict but no numeric value means N/A.
        return True
    cell = (entry or {}).get(cell_key)
    number = _rt_number_or_none_1395(cell)
    if number is not None:
        return False
    return True


def _rt_has_incomplete_rating_1395(entry: Dict[str, Any]) -> bool:
    return _rt_side_is_na_1395(entry, "rt_critic", "rottentomatoes") or _rt_side_is_na_1395(entry, "rt_audience", "rottentomatoes_user")


def _rt_status_is_stable_1394(status: Any) -> bool:
    return _rt_base_status_1394(status) in ("ok", "badge_not_found", "n/a")


def _rt_url_from_slug_1393(slug: Any) -> str:
    if str(slug if slug is not None else "").strip().upper() == "N/A":
        return ""
    slug = _normalize_rt_slug_1393(slug)
    return (RT_BASE_URL_1393 + slug) if slug else ""


def _rating_display_number(logical: str, rating: Dict[str, Any]) -> Any:
    if not isinstance(rating, dict):
        return None
    if rating.get("no_rating") or str(rating.get("value") or "").strip().upper() in ("N/A", "NO_RATING"):
        return NO_RATING_VALUE
    value = safe_float(rating.get("value"))
    score = safe_float(rating.get("score"))
    if logical in PERCENT_100_LOGICALS:
        # For RT/Meta/Trakt, 0 is a valid percentage. Prefer normalized score
        # when present, including 0. Police Academy 5 style 0% must remain 0.
        if score is not None:
            return score
        if value is not None:
            return value
        return ""
    if logical in DECIMAL_10_LOGICALS:
        if value is not None:
            number = value / 10.0 if value > 10 else value
        elif score is not None:
            number = score / 10.0 if score > 10 else score
        else:
            return ""
        if number <= 0:
            return NO_RATING_VALUE
        return number
    number = value if value is not None else score
    if number is None:
        return ""
    return NO_RATING_VALUE if number <= 0 else number


def _display_number_for_db(logical: str, rating: Any) -> str:
    if not isinstance(rating, dict):
        return ""
    number = _rating_display_number(logical, rating)
    if number == NO_RATING_VALUE:
        return NO_RATING_VALUE
    if logical in PERCENT_100_LOGICALS:
        # Keep 0 for RT/metacritic/trakt instead of converting it to N/A.
        return _whole_percent(number)
    if logical in DECIMAL_10_LOGICALS:
        formatted = _one_decimal(number)
        return NO_RATING_VALUE if formatted in ("0", "0.0", "-0", "-0.0") else formatted
    formatted = _one_decimal(number)
    return NO_RATING_VALUE if formatted in ("0", "0.0", "-0", "-0.0") else formatted


def _simple_rating_from_cell(logical: str, cell: Any) -> Dict[str, Any]:
    text = str(cell if cell is not None else "").strip()
    if not text:
        return {}
    if text.upper() in ("N/A", "NO_RATING", "NA"):
        return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
    number = safe_float(text.replace("%", ""))
    if number is None:
        return {}
    if logical in PERCENT_100_LOGICALS:
        # 0% is valid for RT, Metacritic, Trakt percentage families.
        score = number
        value = number
    elif logical in DECIMAL_10_LOGICALS:
        if number <= 0:
            return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
        value = number / 10.0 if number > 10 else number
        score = value * 10
    else:
        if number <= 0:
            return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
        value = number
        score = number
    return {"cache_key": logical, "logical": logical, "provider": logical, "source": logical, "value": value, "score": score, "votes": ""}


def rt_critic_image_token(value: Any) -> str:
    number = safe_float(str(value if value is not None else "").replace("%", ""))
    if number is None:
        return ""
    # Do not guess Certified Fresh from the number. Normal fallback is fresh/rotten.
    return "fresh" if number >= 60 else "rotten"


def rt_audience_image_token(value: Any) -> str:
    number = safe_float(str(value if value is not None else "").replace("%", ""))
    if number is None:
        return ""
    return "upright" if number >= 60 else "spilled"


def _simple_rating_image(logical: str, cell: str) -> str:
    if logical == "rt_critic":
        return rt_critic_image_token(cell)
    if logical == "rt_audience":
        return rt_audience_image_token(cell)
    return ""


def _strip_rt_year_suffix_1395(value: Any) -> str:
    text = _html_text_1394(value)
    text = re.sub(r"\s*\((?:19|20)\d{2}(?:\s*[–-]\s*(?:19|20)\d{2})?\)\s*$", "", text).strip()
    text = re.sub(r"\s*[-|]\s*Rotten Tomatoes\s*$", "", text, flags=re.I).strip()
    text = re.sub(r"\s*:\s*Season\s+\d+\s*$", "", text, flags=re.I).strip()
    return text


def _norm_title_1394(value: Any) -> str:
    text = _strip_rt_year_suffix_1395(value).lower()
    text = text.replace("&", " and ")
    text = re.sub(r"\b(rotten tomatoes|official site)\b", " ", text)
    text = re.sub(r"['’`´]", "", text)
    text = re.sub(r"[^a-z0-9]+", " ", text)
    text = re.sub(r"\s+", " ", text).strip()
    return text


def _title_score_1394(expected: Any, candidate: Any) -> int:
    exp = _norm_title_1394(expected)
    cand = _norm_title_1394(candidate)
    if not exp or not cand:
        return 0
    if exp == cand:
        return 100
    if _strip_leading_article_1394(exp) == _strip_leading_article_1394(cand):
        return 98
    ratio = int(round(SequenceMatcher(None, exp, cand).ratio() * 100))
    try:
        from collections import Counter  # pylint: disable=import-outside-toplevel
        exp_counter = Counter(exp.split())
        cand_counter = Counter(cand.split())
        keys = set(exp_counter) | set(cand_counter)
        inter = sum(min(exp_counter[k], cand_counter[k]) for k in keys)
        union = sum(max(exp_counter[k], cand_counter[k]) for k in keys)
        token_score = int(round((inter / float(union or 1)) * 100))
    except Exception:
        token_score = 0
    contain = 0
    if len(exp) >= 6 and (" " + exp + " ") in (" " + cand + " "):
        contain = 80
    if len(cand) >= 6 and (" " + cand + " ") in (" " + exp + " "):
        # Do not over-accept duplicate-token collapses like Jack-Jack Attack -> Jack Attack.
        if len(exp.split()) == len(cand.split()) or set(exp.split()) != set(cand.split()):
            contain = max(contain, 86)
    return max(ratio, token_score, contain)


def _extract_rt_page_years_1395(html_text: str, page_title: str = "") -> Tuple[Optional[int], Optional[int]]:
    text = html_text or ""
    title = page_title or _extract_rt_page_title_1394(text)
    years: List[int] = []
    m = re.search(r"\(((?:19|20)\d{2})(?:\s*[–-]\s*((?:19|20)\d{2}))?\)\s*$", title or "")
    if m:
        years.append(safe_int(m.group(1)) or 0)
        if m.group(2):
            years.append(safe_int(m.group(2)) or 0)
    # Light metadata fallback. This is intentionally broad because RT page
    # templates differ; it is only used as a tie-breaker/guard.
    for pat in (
        r'"(?:startYear|releaseYear|year)"\s*:\s*"?((?:19|20)\d{2})"?',
        r'\b(?:Release Date|Original Release|First aired|Premiere)[^\n<]{0,120}?((?:19|20)\d{2})',
    ):
        for found in re.findall(pat, text, flags=re.I | re.S):
            val = safe_int(found[0] if isinstance(found, tuple) else found)
            if val:
                years.append(val)
    years = [y for y in years if y]
    if not years:
        return None, None
    return min(years), max(years)


def _year_matches_detail_1395(expected_year: Any, media: str, html_text: str, page_title: str = "") -> bool:
    expected = safe_int(expected_year)
    if not expected:
        return True
    start, end = _extract_rt_page_years_1395(html_text, page_title)
    if not start:
        # No reliable year on page. Do not punish otherwise strong title matches.
        return True
    if media == "movie":
        return abs(start - expected) <= 1
    if media == "tvshow":
        if expected == start:
            return True
        if end and start <= expected <= end:
            return True
        if not end and expected >= start:
            return True
        return abs(start - expected) <= 1
    return True


def _validate_rt_detail_match_1394(item: Dict[str, Any], slug: str, html_text: str, final_url: str = "", trust_alias: bool = False) -> Dict[str, Any]:
    media = media_setting_type((item or {}).get("type"))
    slug = _normalize_rt_slug_1393(slug)
    raw_page_title = _extract_rt_page_title_1394(html_text)
    page_title = _strip_rt_year_suffix_1395(raw_page_title)
    slug_media = _candidate_media_from_slug_1394(slug)
    final_slug = _normalize_rt_slug_1393(final_url or "")
    final_media = _candidate_media_from_slug_1394(final_slug) if final_slug else slug_media
    score = _title_score_1394((item or {}).get("title"), page_title or raw_page_title)
    year_ok = _year_matches_detail_1395((item or {}).get("year"), media, html_text or "", raw_page_title)
    reason = ""
    if media not in ("movie", "tvshow"):
        reason = "unsupported_media_type"
    elif slug_media and slug_media != media:
        reason = "slug_media_type_mismatch"
    elif final_media and final_media != media:
        reason = "final_url_media_type_mismatch"
    elif not year_ok:
        reason = "year_mismatch"
    elif page_title and score < 86:
        # Imported/manual/OMDb slugs may be international-title aliases. If the
        # year matches, keep them as valid pages instead of false mismatch.
        if trust_alias and score >= 20 and year_ok:
            reason = ""
        else:
            reason = "title_mismatch:{0}".format(score)
    return {"ok": not bool(reason), "page_title": raw_page_title or page_title, "title_score": score, "reason": reason, "final_slug": final_slug}


def _rt_candidate_score_1394(item: Dict[str, Any], candidate: Dict[str, Any]) -> Dict[str, Any]:
    media = media_setting_type((item or {}).get("type"))
    candidate_media = candidate.get("media_type") or _candidate_media_from_slug_1394(candidate.get("slug"))
    if media not in ("movie", "tvshow") or media != candidate_media:
        out = dict(candidate)
        out.update({"title_score": 0, "year_score": 0, "match_score": 0, "reject_reason": "media_type_mismatch"})
        return out
    title_score = _title_score_1394((item or {}).get("title"), candidate.get("title"))
    year_score = _year_score_1394((item or {}).get("year"), candidate, media)
    pos_bonus = max(0, 10 - min(10, safe_int(candidate.get("position")) or 0))
    score = int(round((title_score * 0.70) + (year_score * 0.25) + (pos_bonus * 0.05)))
    reject_reason = ""
    if title_score < 86:
        reject_reason = "title_score_low"
    elif year_score <= 0:
        # Keep exact/near-exact titles alive for detail-page validation. Search
        # row years are often blank/wrong, especially short movies and TV rows.
        reject_reason = "needs_detail_year_validation" if title_score >= 96 else "year_mismatch"
    elif score < 82:
        reject_reason = "needs_detail_score_validation" if title_score >= 96 else "match_score_low"
    out = dict(candidate)
    out.update({"title_score": title_score, "year_score": year_score, "match_score": score, "reject_reason": reject_reason})
    return out


def _discover_rt_slug_from_search_1394(item: Dict[str, Any]) -> Tuple[str, Dict[str, Any]]:
    media = media_setting_type((item or {}).get("type"))
    meta: Dict[str, Any] = {"source": "rt_search", "attempts": [], "candidates": []}
    if media not in ("movie", "tvshow"):
        meta["error"] = "unsupported_media_type"
        return "", meta
    best: Dict[str, Any] = {}
    for query in _rt_search_queries_1394(item):
        fetch = _fetch_rt_search_html_1394(query)
        rows = _parse_rt_search_rows_1394(fetch.get("html") or "") if fetch.get("html") else []
        scored = [_rt_candidate_score_1394(item, row) for row in rows]
        scored.sort(key=lambda row: (safe_int(row.get("match_score")) or 0, -(safe_int(row.get("position")) or 9999)), reverse=True)
        attempt = {
            "query": query,
            "url": fetch.get("url"),
            "http_status": fetch.get("status") or 0,
            "bytes": fetch.get("bytes") or 0,
            "error": fetch.get("error") or "",
            "candidate_count": len(rows),
            "best": scored[0] if scored else {},
        }
        meta["attempts"].append(attempt)
        meta["candidates"].extend(scored[:10])
        if scored and (not best or (safe_int(scored[0].get("match_score")) or 0) > (safe_int(best.get("match_score")) or 0)):
            best = dict(scored[0])
        if scored:
            top = scored[0]
            title_score = safe_int(top.get("title_score")) or 0
            year_score = safe_int(top.get("year_score")) or 0
            match_score = safe_int(top.get("match_score")) or 0
            # Accept strong candidates even when search-row year is blank/wrong;
            # resolve_rt_badge_only will fetch and validate the detail page before
            # saving the slug. This fixes Book of Dragons / TV exact-title cases.
            if (not top.get("reject_reason") and match_score >= 82) or title_score >= 96 or (title_score >= 90 and year_score >= 35):
                meta["slug"] = top.get("slug") or ""
                meta["best"] = top
                meta["query"] = query
                meta["url"] = fetch.get("url") or ""
                if top.get("reject_reason"):
                    meta["detail_validation_required"] = top.get("reject_reason")
                return str(top.get("slug") or ""), meta
    meta["best"] = best
    if best:
        meta["error"] = best.get("reject_reason") or "no_acceptable_candidate"
    else:
        meta["error"] = "no_candidates"
    return "", meta


def record_missing_rt_badge(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    media = media_setting_type((item or {}).get("type"))
    if media not in ("movie", "tvshow"):
        return False
    badge = (record or {}).get("rt_badge") if isinstance((record or {}).get("rt_badge"), dict) else {}
    status = badge.get("status") or (record or {}).get("rottentomatoes_status") or ""
    if _rt_has_incomplete_rating_1395(record or {}) and _rt_base_status_1394(status) != "n/a":
        return True
    if _rt_status_is_stable_1394(status):
        return False
    ids = (record or {}).get("ids") or extract_ids(item or {})
    return bool(ids.get("imdb") or (item or {}).get("title"))


def _rt_apply_na_badge_1395(entry: Dict[str, Any], badge: Dict[str, Any], rt_images: Dict[str, Any], checked_at: str, result: Dict[str, Any]) -> Dict[str, Any]:
    ratings = entry.get("ratings") if isinstance(entry.get("ratings"), dict) else {}
    rt_critic_cell = _display_number_for_db("rt_critic", ratings.get("rt_critic") or ratings.get("rottentomatoes") or {})
    rt_audience_cell = _display_number_for_db("rt_audience", ratings.get("rt_audience") or ratings.get("rottentomatoes_user") or {})
    rt_images["critic"] = _simple_rating_image("rt_critic", rt_critic_cell)
    rt_images["audience"] = _simple_rating_image("rt_audience", rt_audience_cell)
    badge.update({"slug": "N/A", "status": "N/A"})
    entry["rt_badge"] = badge
    entry["rt_images"] = rt_images
    entry["rottentomatoes_slug"] = "N/A"
    entry["rottentomatoes_status"] = "N/A"
    entry["updated_at"] = checked_at
    entry["timestamp"] = int(time.time())
    result.update({"status": "N/A", "slug": "N/A", "url": "", "updated": False, "note": "rt_rating_na_skip"})
    _rt_badge_write_result_1393(result)
    return entry


def resolve_rt_badge_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None, force: bool = False) -> Dict[str, Any]:
    media = media_setting_type((item or {}).get("type"))
    existing = dict(existing or {})
    entry = dict(existing or {})
    entry.setdefault("type", (item or {}).get("type"))
    entry.setdefault("dbid", (item or {}).get("dbid"))
    entry.setdefault("title", (item or {}).get("title") or "")
    entry.setdefault("year", (item or {}).get("year") or "")
    entry.setdefault("showtitle", (item or {}).get("showtitle") or "")
    entry.setdefault("ratings", (existing or {}).get("ratings") or {})
    entry.setdefault("awards", (existing or {}).get("awards") or {})
    entry.setdefault("series", (existing or {}).get("series") or {})
    ids = dict((existing or {}).get("ids") or {})
    for k, v in extract_ids(item or {}).items():
        if v not in (None, ""):
            ids.setdefault(str(k), str(v))
    entry["ids"] = ids

    rt_images = dict((existing or {}).get("rt_images") or {})
    if not rt_images:
        rt_images = {
            "critic": str((existing or {}).get("rottentomatoes_image") or "").strip().lower(),
            "audience": str((existing or {}).get("rottentomatoes_userimage") or "").strip().lower(),
        }
    old_critic = str(rt_images.get("critic") or "").strip().lower()
    old_audience = str(rt_images.get("audience") or "").strip().lower()

    badge = dict((existing or {}).get("rt_badge") or {})
    raw_slug = badge.get("slug") or (existing or {}).get("rottentomatoes_slug") or ""
    slug = "" if str(raw_slug).strip().upper() == "N/A" else _normalize_rt_slug_1393(raw_slug)
    original_slug = slug
    checked_at = now_iso()
    result: Dict[str, Any] = {
        "checked_at": checked_at,
        "media_type": media,
        "title": entry.get("title") or "",
        "year": entry.get("year") or "",
        "imdb_id": ids.get("imdb", ""),
        "tmdb_id": ids.get("tmdb", ""),
        "slug": slug,
        "old_slug": slug,
        "url": _rt_url_from_slug_1393(slug),
        "status": "started",
        "old_critic": old_critic,
        "new_critic": old_critic,
        "old_audience": old_audience,
        "new_audience": old_audience,
        "updated": False,
    }
    if media not in ("movie", "tvshow"):
        result["status"] = "skipped_media_type"
        result["note"] = "not_movie_or_tvshow"
        _rt_badge_write_result_1393(result)
        return entry

    if _rt_has_incomplete_rating_1395(entry):
        return _rt_apply_na_badge_1395(entry, badge, rt_images, checked_at, result)

    if not slug:
        search_slug, search_meta = _rt_attempt_search_repair_1394(item or entry, result, "missing_slug")
        if search_slug:
            slug = search_slug
        elif media == "movie":
            omdb_slug, omdb_meta = _discover_rt_slug_from_omdb_1393(item or entry, ids, (keys or {}).get("omdb"))
            result["omdb_meta"] = omdb_meta
            if omdb_slug:
                slug = omdb_slug
                original_slug = slug
                result["note"] = (str(result.get("note") or "") + ";" if result.get("note") else "") + "omdb_fallback_slug"
        result["slug"] = slug
        result["url"] = _rt_url_from_slug_1393(slug)

    if not slug:
        status = "no_slug"
        status_string = rt_badge_status_string_1393(status, source="rt_search")
        badge.update({"slug": "", "status": status_string})
        entry["rt_badge"] = badge
        entry["rottentomatoes_slug"] = ""
        entry["rottentomatoes_status"] = status_string
        entry["updated_at"] = checked_at
        entry["timestamp"] = int(time.time())
        result.update({"status": status, "note": result.get("note") or "rt_search_no_match"})
        _rt_badge_write_result_1393(result)
        return entry

    def _process_slug(current_slug: str, repair_reason: str = "") -> Tuple[Optional[Dict[str, Any]], Dict[str, Any], str]:
        fetch = _fetch_rt_detail_html_1393(current_slug)
        html_text = fetch.pop("html", "")
        local_result = {
            "slug": current_slug,
            "url": fetch.get("url") or _rt_url_from_slug_1393(current_slug),
            "final_url": fetch.get("final_url") or "",
            "http_status": fetch.get("status") or 0,
            "bytes": fetch.get("bytes") or 0,
            "fetch_error": fetch.get("error") or "",
        }
        if not fetch.get("ok") or not html_text:
            local_result["status"] = "fetch_error_{0}".format(fetch.get("status") or "network")
            local_result["note"] = fetch.get("error") or "no_html"
            return None, local_result, html_text
        trust_alias = bool(original_slug and current_slug == original_slug and not repair_reason)
        validation = _validate_rt_detail_match_1394(item or entry, current_slug, html_text, fetch.get("final_url") or fetch.get("url") or "", trust_alias=trust_alias)
        local_result.update({
            "page_title": validation.get("page_title") or "",
            "mismatch_reason": validation.get("reason") or "",
        })
        if not validation.get("ok"):
            local_result["status"] = "slug_mismatch"
            local_result["note"] = validation.get("reason") or "detail_identity_mismatch"
            return None, local_result, html_text
        parsed = parse_rt_badges_detail_1393(html_text, fetch.get("final_url") or fetch.get("url") or "")
        local_result["parser"] = parsed
        return parsed, local_result, html_text

    parsed, detail_result, _html_text = _process_slug(slug)
    result.update(detail_result)

    base_status = _rt_base_status_1394(result.get("status"))
    if base_status in ("fetch_error_404", "slug_mismatch"):
        old_slug = slug
        repair_slug, _repair_meta = _rt_attempt_search_repair_1394(item or entry, result, base_status)
        if repair_slug and repair_slug != old_slug:
            parsed2, detail2, _html2 = _process_slug(repair_slug, base_status)
            result.update(detail2)
            result["old_slug"] = old_slug
            result["new_slug"] = repair_slug
            slug = repair_slug
            parsed = parsed2
            base_status = _rt_base_status_1394(result.get("status"))
        if base_status in ("fetch_error_404", "slug_mismatch"):
            status = base_status
            status_string = _rt_status_with_old_slug_1394(status, old_slug, source="rt_search")
            badge.update({"slug": "", "status": status_string})
            entry["rt_badge"] = badge
            entry["rottentomatoes_slug"] = ""
            entry["rottentomatoes_status"] = status_string
            entry["updated_at"] = checked_at
            entry["timestamp"] = int(time.time())
            result.update({"status": status, "slug": "", "old_slug": old_slug, "new_slug": "", "updated": False})
            _rt_badge_write_result_1393(result)
            return entry

    if not parsed:
        status = _rt_base_status_1394(result.get("status")) or "fetch_error_network"
        status_string = rt_badge_status_string_1393(status, source="rt_detail")
        badge.update({"slug": slug, "status": status_string})
        entry["rt_badge"] = badge
        entry["rottentomatoes_slug"] = slug
        entry["rottentomatoes_status"] = status_string
        entry["updated_at"] = checked_at
        entry["timestamp"] = int(time.time())
        result.update({"status": status, "updated": False})
        _rt_badge_write_result_1393(result)
        return entry

    scope = parsed.get("scope") or {}
    critic = ((parsed.get("critics") or {}).get("selected") or {})
    audience = ((parsed.get("audience") or {}).get("selected") or {})
    rt_crit = str((parsed.get("result") or {}).get("rt_crit") or "").strip().lower()
    rt_aud = str((parsed.get("result") or {}).get("rt_aud") or "").strip().lower()
    result.update({
        "rt_crit": rt_crit,
        "critic_score": (parsed.get("result") or {}).get("critic_score") if (parsed.get("result") or {}).get("critic_score") not in (None, "") else "",
        "critic_certified": (critic.get("attrs") or {}).get("certified", ""),
        "critic_sentiment": (critic.get("attrs") or {}).get("sentiment", ""),
        "critic_source": critic.get("method", ""),
        "rt_aud": rt_aud,
        "audience_score": (parsed.get("result") or {}).get("audience_score") if (parsed.get("result") or {}).get("audience_score") not in (None, "") else "",
        "audience_certified": (audience.get("attrs") or {}).get("certified", ""),
        "audience_sentiment": (audience.get("attrs") or {}).get("sentiment", ""),
        "audience_source": audience.get("method", ""),
        "scope": scope,
    })
    changed = False
    if rt_crit in ("certified", "fresh", "rotten") and old_critic != rt_crit:
        rt_images["critic"] = rt_crit
        result["new_critic"] = rt_crit
        changed = True
    if rt_aud in ("verifiedhot", "upright", "spilled") and old_audience != rt_aud:
        rt_images["audience"] = rt_aud
        result["new_audience"] = rt_aud
        changed = True
    if not rt_crit and not rt_aud:
        status = "scorecard_not_found" if not scope.get("media_scorecard_found") else "badge_not_found"
    else:
        status = "ok"
    status_string = rt_badge_status_string_1393(status, rt_crit, rt_aud, (critic.get("method") or audience.get("method") or "rt_detail"))
    _rt_apply_final_badge_1394(entry, badge, rt_images, slug, status_string, checked_at)
    result.update({"status": status, "slug": slug, "updated": changed, "note": "" if changed else "no_image_change"})
    _rt_badge_write_result_1393(result)
    _rt_log_1393("{0} | {1}".format(result.get("title", ""), _rt_badge_simple_line_1393(result)), xbmc.LOGINFO)
    return entry


def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    ratings = entry.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ids = entry.get("ids") or {}
    series = entry.get("series") or {}
    awards = entry.get("awards") or {}
    rt_images = entry.get("rt_images") if isinstance(entry.get("rt_images"), dict) else {}
    rt_badge = entry.get("rt_badge") if isinstance(entry.get("rt_badge"), dict) else {}

    rt_critic_cell = _display_number_for_db("rt_critic", ratings.get("rt_critic") or ratings.get("rottentomatoes") or {})
    rt_audience_cell = _display_number_for_db("rt_audience", ratings.get("rt_audience") or ratings.get("rottentomatoes_user") or {})
    metacritic_cell = _display_number_for_db("metacritic", ratings.get("metacritic") or {})
    trakt_cell = _display_number_for_db("trakt", ratings.get("trakt") or {})
    top250_value = _metadata_int_or_na(entry.get("imdb_top250_rank") if "imdb_top250_rank" in entry else entry.get("top250"))
    oscar_value = _metadata_int_or_na(awards.get("oscar_wins") if isinstance(awards, dict) and "oscar_wins" in awards else entry.get("oscar_wins"))
    emmy_value = _metadata_int_or_na(awards.get("emmy_wins") if isinstance(awards, dict) and "emmy_wins" in awards else entry.get("emmy_wins"))
    awards_text = str((awards or {}).get("awards_text") or entry.get("awards_text") or "")
    critic_image = str(rt_images.get("critic") or entry.get("rottentomatoes_image") or "").strip().lower()
    audience_image = str(rt_images.get("audience") or entry.get("rottentomatoes_userimage") or "").strip().lower()
    if critic_image not in ("certified", "fresh", "rotten"):
        critic_image = _simple_rating_image("rt_critic", rt_critic_cell)
    if audience_image not in ("verifiedhot", "upright", "spilled"):
        audience_image = _simple_rating_image("rt_audience", rt_audience_cell)
    raw_slug = str(rt_badge.get("slug") or entry.get("rottentomatoes_slug") or "").strip()
    status = str(rt_badge.get("status") or entry.get("rottentomatoes_status") or "")[:240]
    slug = "N/A" if raw_slug.upper() == "N/A" or status.strip().upper() == "N/A" else _normalize_rt_slug_1393(raw_slug)
    return (
        str(item_key),
        str(entry.get("title") or ""),
        _display_number_for_db("imdb", ratings.get("imdb") or {}),
        _display_number_for_db("tmdb", ratings.get("tmdb") or {}),
        rt_critic_cell,
        critic_image,
        rt_audience_cell,
        audience_image,
        metacritic_cell,
        trakt_cell,
        top250_value,
        str(entry.get("showtitle") or ""),
        safe_int(entry.get("season")),
        safe_int(entry.get("episode")),
        str(entry.get("year") or ""),
        str(series.get("status") or entry.get("series_status") or ""),
        str(series.get("status_date") or entry.get("series_status_date") or ""),
        oscar_value,
        emmy_value,
        awards_text,
        str(ids.get("imdb") or entry.get("imdb") or entry.get("imdbnumber") or ""),
        str(ids.get("tmdb") or entry.get("tmdb") or entry.get("tmdb_id") or ""),
        safe_int(entry.get("dbid")),
        str(entry.get("type") or ""),
        slug,
        status,
        str(entry.get("updated_at") or now_iso()).replace(" WIB", ""),
        safe_int(entry.get("timestamp")) or int(time.time()),
    )


_ratings_only_row_to_entry_1395_base = _ratings_only_row_to_entry

def _ratings_only_row_to_entry(row: sqlite3.Row) -> Dict[str, Any]:
    entry = _ratings_only_row_to_entry_1395_base(row)
    raw_slug = str(_row_value(row, "rottentomatoes_slug") or "").strip()
    status = str(_row_value(row, "rottentomatoes_status") or "").strip()
    slug = "N/A" if raw_slug.upper() == "N/A" or status.upper() == "N/A" else _normalize_rt_slug_1393(raw_slug)
    if slug or status:
        entry["rt_badge"] = {"slug": slug, "status": status}
        entry["rottentomatoes_slug"] = slug
        entry["rottentomatoes_status"] = status
    return entry


# -----------------------------------------------------------------------------
# v1.3.97 MDBList item-not-found fallback + diagnostics + final zero policy
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 23)
RT_ZERO_VALID_LOGICALS_1397 = {"rt_critic", "rt_audience"}
ZERO_IS_NA_LOGICALS_1397 = {"imdb", "tmdb", "metacritic", "trakt"}


def _json_error_body_1397(body: str) -> Dict[str, Any]:
    try:
        parsed = json.loads(body or "")
        if isinstance(parsed, dict):
            return parsed
    except Exception:
        pass
    return {}


_http_json_1397_base = http_json

def http_json(url: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    """Final HTTP JSON helper.

    v1.3.97 keeps query strings redacted in logs but parses JSON error bodies.
    This lets MDBList 404 {"error":"Item not found"} be treated as a
    cacheable provider answer instead of a generic transport failure.
    """
    request = Request(url, headers={"User-Agent": "Kodi-Library-Ratings-Scraper/1.3.98", "Accept": "application/json"})
    try:
        with urlopen(request, timeout=NETWORK_TIMEOUT) as response:  # nosec B310 fixed HTTPS hosts only
            headers = {k.lower(): v for k, v in response.headers.items()}
            status = getattr(response, "status", None) or getattr(response, "code", None) or 200
            raw = response.read().decode("utf-8", "replace")
        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            if status and "__http_status" not in parsed:
                parsed["__http_status"] = status
            if raw and "__raw_len" not in parsed:
                parsed["__raw_len"] = len(raw)
            return parsed, headers
        return {"Response": "False", "__error": "JSON root is {0}".format(type(parsed).__name__), "__http_status": status, "__raw_len": len(raw)}, headers
    except HTTPError as exc:
        retry = exc.headers.get("Retry-After", "") if exc.headers else ""
        body = ""
        try:
            body = exc.read().decode("utf-8", "replace")[:2000]
        except Exception:  # pylint: disable=broad-except
            body = ""
        log("HTTP {0} for {1}; retry-after={2}".format(exc.code, url.split("?")[0], retry), xbmc.LOGWARNING)
        payload = _json_error_body_1397(body)
        if not isinstance(payload, dict):
            payload = {}
        if not payload:
            payload = {"Response": "False", "__error": "HTTP {0}".format(exc.code)}
        else:
            payload.setdefault("Response", "False")
            # Preserve provider error text (e.g. MDBList Item not found) while
            # still exposing the HTTP status for debug/reporting.
        payload["__http_status"] = exc.code
        payload["__retry_after"] = retry
        payload["__raw_len"] = len(body or "")
        if body and "__body" not in payload:
            payload["__body"] = body[:500]
        return payload, {k.lower(): v for k, v in exc.headers.items()} if exc.headers else {}
    except (URLError, OSError, ValueError, TimeoutError) as exc:
        log("Provider request failed: {0}".format(exc), xbmc.LOGWARNING)
        return {"Response": "False", "__error": str(exc)}, {}


def _mdblist_attempt_text_1397(attempt: Any) -> str:
    if not isinstance(attempt, dict):
        return ""
    parts = []
    for key in ("error", "message", "detail", "body", "__body"):
        value = attempt.get(key)
        if value not in (None, ""):
            parts.append(str(value))
    return " ".join(parts).lower()


def mdblist_item_not_found_1397(meta: Dict[str, Any]) -> bool:
    attempts = (meta or {}).get("attempts") or []
    if not attempts:
        return False
    saw_not_found = False
    for attempt in attempts:
        if not isinstance(attempt, dict):
            continue
        text = _mdblist_attempt_text_1397(attempt)
        status = safe_int(attempt.get("http_status"))
        if "item not found" in text or "not found" in text and status == 404:
            saw_not_found = True
        elif _attempt_has_temp_failure(attempt):
            return False
    return saw_not_found


def _rating_display_number(logical: str, rating: Dict[str, Any]) -> Any:
    if not isinstance(rating, dict):
        return None
    if rating.get("no_rating") or str(rating.get("value") or "").strip().upper() in ("N/A", "NO_RATING"):
        return NO_RATING_VALUE
    value = safe_float(rating.get("value"))
    score = safe_float(rating.get("score"))
    if logical in RT_ZERO_VALID_LOGICALS_1397:
        if score is not None:
            return score
        if value is not None:
            return value
        return ""
    if logical in DECIMAL_10_LOGICALS:
        if value is not None:
            number = value / 10.0 if value > 10 else value
        elif score is not None:
            number = score / 10.0 if score > 10 else score
        else:
            return ""
        return NO_RATING_VALUE if number <= 0 else number
    if logical in ZERO_IS_NA_LOGICALS_1397:
        # Metacritic/Trakt 0 is an unavailable marker, unlike RT 0%.
        number = score if score is not None else value
        if number is None:
            return ""
        return NO_RATING_VALUE if number <= 0 else number
    number = value if value is not None else score
    if number is None:
        return ""
    return NO_RATING_VALUE if number <= 0 else number


def _display_number_for_db(logical: str, rating: Any) -> str:
    if not isinstance(rating, dict):
        return ""
    number = _rating_display_number(logical, rating)
    if number == NO_RATING_VALUE:
        return NO_RATING_VALUE
    if logical in RT_ZERO_VALID_LOGICALS_1397 or logical in ("metacritic", "trakt"):
        return _whole_percent(number)
    if logical in DECIMAL_10_LOGICALS:
        formatted = _one_decimal(number)
        return NO_RATING_VALUE if formatted in ("0", "0.0", "-0", "-0.0") else formatted
    formatted = _one_decimal(number)
    return NO_RATING_VALUE if formatted in ("0", "0.0", "-0", "-0.0") else formatted


def _simple_rating_from_cell(logical: str, cell: Any) -> Dict[str, Any]:
    text = str(cell if cell is not None else "").strip()
    if not text:
        return {}
    if text.upper() in ("N/A", "NO_RATING", "NA"):
        return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
    number = safe_float(text.replace("%", ""))
    if number is None:
        return {}
    if logical in RT_ZERO_VALID_LOGICALS_1397:
        score = number
        value = number
    elif logical in DECIMAL_10_LOGICALS:
        if number <= 0:
            return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
        value = number / 10.0 if number > 10 else number
        score = value * 10
    elif logical in ZERO_IS_NA_LOGICALS_1397:
        if number <= 0:
            return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
        value = number
        score = number
    else:
        if number <= 0:
            return {"cache_key": logical, "logical": logical, "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
        value = number
        score = number
    return {"cache_key": logical, "logical": logical, "provider": logical, "source": logical, "value": value, "score": score, "votes": ""}


def tmdb_rating_lookup_1397(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str], Dict[str, Any]]:
    meta: Dict[str, Any] = {"attempts": []}
    if not key:
        return {}, ids, meta
    output: Dict[str, Any] = {}
    updated_ids = dict(ids or {})
    media_type = item.get("type")
    path = ""
    payload: Dict[str, Any] = {}
    try:
        if media_type == "movie":
            tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, False)
            if tmdb_id:
                updated_ids.setdefault("tmdb", str(tmdb_id))
                path = "movie/{0}".format(tmdb_id)
                payload = tmdb_get(path, key)
        elif media_type == "tvshow":
            tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, True)
            if tmdb_id:
                updated_ids.setdefault("tmdb", str(tmdb_id))
                path = "tv/{0}".format(tmdb_id)
                payload = tmdb_get(path, key)
        if path:
            meta["attempts"].append({"path": path, "http_status": payload.get("__http_status") if isinstance(payload, dict) else "", "error": (payload.get("status_message") or payload.get("__error") or "") if isinstance(payload, dict) else ""})
        elif media_type in ("movie", "tvshow"):
            meta["attempts"].append({"path": "search", "error": "no_tmdb_id_or_search_result"})
        status = safe_int(payload.get("__http_status") if isinstance(payload, dict) else None)
        if status and status != 200:
            return output, updated_ids, meta
        if _tmdb_payload_has_error_157(payload):
            return output, updated_ids, meta
        vote = payload.get("vote_average") if isinstance(payload, dict) else None
        vote_num = safe_float(vote)
        if vote_num is None or vote_num <= 0:
            if _tmdb_title_payload_valid_157(payload):
                output["tmdb"] = no_rating_row("tmdb", "tmdb_vote_empty")
        else:
            merge_rating(output, normalized_rating("tmdb", vote_num, vote_num * 10, None, "tmdb"), overwrite=True)
    except Exception as exc:  # pylint: disable=broad-except
        meta["attempts"].append({"path": path or "", "error": str(exc)})
    return output, updated_ids, meta


def tmdb_lookup_cacheable_1397(meta: Dict[str, Any]) -> bool:
    attempts = (meta or {}).get("attempts") or []
    if not attempts:
        return False
    return not any(_attempt_has_temp_failure(attempt) or (safe_int(attempt.get("http_status")) == 404) for attempt in attempts if isinstance(attempt, dict))


def _merge_ids_1397(ids: Dict[str, str], meta: Dict[str, Any]) -> None:
    for key, value in (meta.get("ids") or {}).items():
        if value not in (None, ""):
            ids.setdefault(str(key), str(value))


def resolve_item(item: Dict[str, Any], keys: Dict[str, str], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True, include_local: bool = True, ratings_only: bool = False) -> Dict[str, Any]:
    """v1.3.97 final active provider flow.

    MDBList remains primary.  Extra fallbacks are limited and explicit:
      * MDBList tomatoes null/missing -> OMDb fallback for RT critics only.
      * MDBList {"error":"Item not found"} -> OMDb for IMDb/RT critics/Metacritic and TMDb for TMDb rating.
      * RT 0% is valid; IMDb/TMDb/Metacritic/Trakt zero is N/A.
      * Provider limit/error/temporary failure leaves fields blank for retry.
      * TMDb episode N/A is written only for a valid episode payload with no vote.
    """
    media_type = media_setting_type(item.get("type"))
    existing = existing if isinstance(existing, dict) else {}
    ratings = preserve_ratings_for_item(media_type, existing.get("ratings") or {}) if missing_only and existing else {}
    ids = dict(existing.get("ids") or {}) if missing_only and existing else {}
    provider_meta: Dict[str, Any] = dict(existing.get("provider_meta") or {}) if missing_only and existing else {}
    series_meta: Dict[str, Any] = dict(existing.get("series") or {}) if missing_only and existing else {}
    awards_meta: Dict[str, Any] = dict(existing.get("awards") or {}) if missing_only and existing else {}

    if include_local:
        local = filter_ratings_for_item(media_type, local_ratings(item))
        for key, row in local.items():
            if key not in ratings:
                ratings[key] = row

    item_ids = extract_ids(item)
    for key, value in item_ids.items():
        if value not in (None, ""):
            ids.setdefault(str(key), str(value))

    errors: List[str] = []
    item_type = item.get("type")
    is_movie_or_show = item_type in ("movie", "tvshow")
    status_missing = False if ratings_only else (item_type == "tvshow" and bool_setting("scrape_tv_status", True) and _series_meta_needs_fill(series_meta))
    awards_missing = False  # v1.3.90+: awards run in a separate OMDb-only phase.

    def current_missing() -> set:
        return record_missing_logicals(media_type, {"ratings": ratings})

    checked_no_value_logicals: set = set()
    missing = current_missing()

    need_tmdb_id_for_mdblist = is_movie_or_show and bool(missing & MDBLIST_PROVIDER_LOGICALS) and not (ids.get("imdb") or ids.get("tmdb"))
    need_tmdb_episode_rating = item_type == "episode" and "tmdb" in missing
    if bool_setting("use_tmdb", True) and keys.get("tmdb") and (need_tmdb_id_for_mdblist or need_tmdb_episode_rating):
        try:
            found, ids = tmdb_lookup(item, ids, keys["tmdb"])
            if item_type == "episode":
                merge_provider_ratings(ratings, found, media_type, allowed_logicals={"tmdb"}, overwrite=not missing_only)
                # v1.5.7: do not mark episode TMDb as N/A merely because the
                # lookup was attempted. tmdb_lookup() now returns a no-rating
                # row only for a valid TMDb episode payload with empty/zero vote.
                # Transport/provider/search failures stay blank so they can retry.
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("tmdb: {0}".format(exc))

    if bool_setting("use_tmdb", True) and keys.get("tmdb") and status_missing:
        try:
            found_series, ids = tmdb_tv_status_lookup(item, ids, keys["tmdb"])
            if found_series:
                series_meta = _merge_missing_series_meta(series_meta, found_series)
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("tmdb_status: {0}".format(exc))

    missing = current_missing()
    mdblist_needed = is_movie_or_show and bool(missing & MDBLIST_PROVIDER_LOGICALS)
    mdblist_not_found = False
    mdblist_cacheable = False
    mdblist_missing_before: set = set()
    if mdblist_needed:
        if keys.get("__mdblist_limited"):
            raise ProviderLimitReached("MDBList", "All MDBList API keys are limited")
        if not bool_setting("use_mdblist", True):
            errors.append("mdblist: provider disabled")
        elif not keys.get("mdblist"):
            errors.append("mdblist: api key missing")
        else:
            try:
                mdblist_missing_before = set(missing & MDBLIST_PROVIDER_LOGICALS)
                found, meta = mdblist_lookup(ids, "movie" if item_type == "movie" else "show", keys["mdblist"])
                provider_meta["mdblist"] = meta
                if meta.get("limited"):
                    keys["__mdblist_limited"] = "true"
                    raise ProviderLimitReached("MDBList", meta.get("limit_message") or "All MDBList API keys are limited", meta.get("retry_after") or "")
                merge_provider_ratings(ratings, found, media_type, allowed_logicals=MDBLIST_PROVIDER_LOGICALS, overwrite=True)
                mdblist_cacheable = mdblist_lookup_cacheable(meta)
                mdblist_not_found = (not found) and mdblist_item_not_found_1397(meta)
                _merge_ids_1397(ids, meta)
                if mdblist_not_found:
                    errors.append("mdblist: item not found; trying OMDb/TMDb fallbacks")
                elif mdblist_cacheable:
                    # Normal valid MDBList response.  Do not mark rt_critic N/A yet
                    # when OMDb RT fallback is available; fallback may fill it.
                    checked = set(mdblist_missing_before)
                    if "rt_critic" in checked and bool_setting("use_omdb", True) and keys.get("omdb"):
                        checked.discard("rt_critic")
                    checked_no_value_logicals.update(checked)
            except ProviderLimitReached:
                keys["__mdblist_limited"] = "true"
                raise
            except Exception as exc:  # pylint: disable=broad-except
                errors.append("mdblist: {0}".format(exc))

    # Movie/show fallbacks.  They run only after a valid MDBList no-item answer,
    # except the narrow RT-critics fallback for MDBList tomatoes=null/missing.
    if is_movie_or_show:
        missing = current_missing()
        omdb_allowed: set = set()
        if mdblist_not_found:
            omdb_allowed = set(missing & {"imdb", "rt_critic", "metacritic"})
        elif mdblist_cacheable and "rt_critic" in missing and "rt_critic" in mdblist_missing_before:
            omdb_allowed = {"rt_critic"}
        if omdb_allowed:
            if bool_setting("use_omdb", True) and keys.get("omdb"):
                try:
                    omdb_missing_before = set(current_missing() & omdb_allowed)
                    found, ids, omdb_meta = omdb_lookup(item, ids, keys["omdb"])
                    provider_meta["omdb"] = omdb_meta
                    found.pop("__awards", None)
                    merge_provider_ratings(ratings, found, media_type, allowed_logicals=omdb_allowed, overwrite=True)
                    if omdb_lookup_cacheable(omdb_meta):
                        checked_no_value_logicals.update(omdb_missing_before)
                except ProviderLimitReached as exc:
                    errors.append("omdb_fallback: API limit reached; fields left blank for retry: {0}".format(exc))
                except Exception as exc:  # pylint: disable=broad-except
                    errors.append("omdb_fallback: {0}".format(exc))
            else:
                errors.append("omdb_fallback: skipped; provider disabled or api key missing")

        if mdblist_not_found and "tmdb" in current_missing():
            if bool_setting("use_tmdb", True) and keys.get("tmdb"):
                try:
                    tmdb_missing_before = {"tmdb"}
                    found_tmdb, ids, tmdb_meta = tmdb_rating_lookup_1397(item, ids, keys["tmdb"])
                    provider_meta["tmdb_rating_fallback"] = tmdb_meta
                    merge_provider_ratings(ratings, found_tmdb, media_type, allowed_logicals={"tmdb"}, overwrite=True)
                    if tmdb_lookup_cacheable_1397(tmdb_meta):
                        checked_no_value_logicals.update(tmdb_missing_before)
                except Exception as exc:  # pylint: disable=broad-except
                    errors.append("tmdb_fallback: {0}".format(exc))
            else:
                errors.append("tmdb_fallback: skipped; provider disabled or api key missing")

        # MDBList item-not-found is a final checked answer for MDBList-only
        # families that have no fallback provider.
        if mdblist_not_found:
            checked_no_value_logicals.update(current_missing() & {"rt_audience", "trakt", "letterboxd"})

    # Episodes: OMDb IMDb + TMDb episode rating as before.
    missing = current_missing()
    omdb_needed = (item_type == "episode") and bool(missing & OMDB_LOGICALS)
    if bool_setting("use_omdb", True) and keys.get("omdb") and omdb_needed:
        try:
            omdb_missing_before = set(missing & OMDB_LOGICALS)
            found, ids, omdb_meta = omdb_lookup(item, ids, keys["omdb"])
            provider_meta["omdb"] = omdb_meta
            found.pop("__awards", None)
            merge_provider_ratings(ratings, found, media_type, allowed_logicals=OMDB_LOGICALS, overwrite=True)
            if omdb_lookup_cacheable(omdb_meta):
                checked_no_value_logicals.update(omdb_missing_before)
        except ProviderLimitReached:
            raise
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("omdb: {0}".format(exc))

    remaining_missing = current_missing()
    if checked_no_value_logicals:
        mark_unavailable_ratings(ratings, media_type, remaining_missing & checked_no_value_logicals)

    top250_value = _resolve_top250_rank_for_item(item, ids, existing) if (not ratings_only and rating_enabled(media_type, "top250", True)) else _top250_existing_value(existing or {})
    result = {
        "type": item.get("type"), "dbid": item.get("dbid"), "title": item.get("title") or "",
        "year": item.get("year") or "", "showtitle": item.get("showtitle") or "",
        "season": item.get("season") if item.get("type") == "episode" else None,
        "episode": item.get("episode") if item.get("type") == "episode" else None,
        "ids": ids, "ratings": preserve_ratings_for_item(media_type, ratings), "provider_meta": compact_provider_meta(provider_meta),
        "series": series_meta, "awards": awards_meta,
        "imdb_top250_rank": top250_value if top250_value is not None else 0,
        "errors": errors, "timestamp": int(time.time()), "updated_at": now_iso(),
    }
    if status_missing and media_type == "tvshow" and not any(str(e).lower().startswith("tmdb_status:") for e in errors):
        series = dict(result.get("series") or {})
        if not str(series.get("status") or "").strip():
            series["status"] = METADATA_NA_VALUE
        if not str(series.get("status_date") or "").strip():
            series["status_date"] = METADATA_NA_VALUE
        result["series"] = series
    return result


def _diagnostic_candidates_1397() -> List[str]:
    paths: List[str] = []
    def add(path: Any) -> None:
        text = str(path or "").strip()
        if text and os.path.exists(text) and text not in paths:
            paths.append(text)
    # Add-on profile files: reports, DB, JSON states, RT logs, random-test logs.
    for name in os.listdir(PROFILE) if os.path.isdir(PROFILE) else []:
        lower = name.lower()
        if lower.endswith((".log", ".csv", ".json", ".db", ".xml", ".txt")):
            add(os.path.join(PROFILE, name))
    for explicit in (CACHE_DB_FILE, REPORT_FILE, SUMMARY_FILE, BACKGROUND_STATE_FILE, BACKGROUND_REQUEST_FILE, BACKGROUND_CANCEL_FILE, BACKGROUND_FORCE_STOP_FILE, SAMPLE_CHECK_LOG_FILE):
        add(explicit)
    # Kodi logs.
    for special in ("special://logpath", "special://home"):
        try:
            base = xbmcvfs.translatePath(special)
        except Exception:
            base = ""
        for filename in ("kodi.log", "kodi.old.log"):
            add(os.path.join(base, filename))
    return paths


def export_diagnostics_zip_1397() -> str:
    import zipfile  # pylint: disable=import-outside-toplevel
    os.makedirs(PROFILE, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    zip_path = os.path.join(PROFILE, "lrs-diagnostics-{0}.zip".format(stamp))
    base_profile = os.path.abspath(PROFILE)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        manifest = {"created_at": now_iso(), "addon_version": ADDON.getAddonInfo("version"), "files": []}
        for path in _diagnostic_candidates_1397():
            try:
                apath = os.path.abspath(path)
                if apath == os.path.abspath(zip_path):
                    continue
                if apath.startswith(base_profile):
                    arc = "profile/" + os.path.relpath(apath, base_profile).replace("\\", "/")
                else:
                    arc = "kodi/" + os.path.basename(apath)
                zf.write(apath, arc)
                manifest["files"].append({"source": apath, "archive": arc, "size": os.path.getsize(apath)})
            except Exception as exc:  # pylint: disable=broad-except
                manifest.setdefault("errors", []).append({"file": str(path), "error": str(exc)})
        zf.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True))
    return zip_path

# v1.3.97 compact TMDb fallback metadata for diagnostics.
_compact_provider_meta_1397_base = compact_provider_meta

def compact_provider_meta(provider_meta: Dict[str, Any]) -> Dict[str, Any]:
    output = _compact_provider_meta_1397_base(provider_meta)
    tmdb = (provider_meta or {}).get("tmdb_rating_fallback") or {}
    if isinstance(tmdb, dict):
        row: Dict[str, Any] = {}
        attempts: List[Dict[str, Any]] = []
        for attempt in tmdb.get("attempts") or []:
            if not isinstance(attempt, dict):
                continue
            compact_attempt = {"path": attempt.get("path") or ""}
            status = safe_int(attempt.get("http_status"))
            if status and status != 200:
                compact_attempt["http_status"] = status
            if attempt.get("error"):
                compact_attempt["error"] = attempt.get("error")
            attempts.append(compact_attempt)
        if attempts:
            row["attempts"] = attempts
        if row:
            output["tmdb_rating_fallback"] = row
    return output


# -----------------------------------------------------------------------------
# v1.3.98 - RT critic N/A closeout + irrelevant award-column normalization
# -----------------------------------------------------------------------------
# Fixes two narrow leftover cases from 1.3.97:
#   1) rt_critic was held back from N/A marking while OMDb fallback was attempted.
#      If fallback produced no cacheable RT critic value, three rows could remain
#      blank even though the RT badge phase then marked slug/status as N/A.
#      When RT badge N/A-skip is applied, close blank RT numeric sides to N/A too.
#   2) Movie rows can have Oscar wins but blank Emmy wins. For AF3/LRS cache this
#      irrelevant award column should be visibly N/A. Symmetrically, TV show Oscar
#      wins are irrelevant and should be N/A when saving the wide DB row.

_rt_apply_na_badge_1398_base = _rt_apply_na_badge_1395

def _lrs_rating_cell_is_blank_1398(logical: str, ratings: Dict[str, Any], *aliases: str) -> bool:
    for key in (logical,) + tuple(aliases or ()):  # type: ignore[operator]
        row = ratings.get(key)
        if isinstance(row, dict):
            cell = _display_number_for_db(logical, row)
            if str(cell if cell is not None else "").strip():
                return False
    return True


def _rt_apply_na_badge_1395(entry: Dict[str, Any], badge: Dict[str, Any], rt_images: Dict[str, Any], checked_at: str, result: Dict[str, Any]) -> Dict[str, Any]:
    ratings = entry.get("ratings") if isinstance(entry.get("ratings"), dict) else {}
    ratings = dict(ratings or {})
    if _lrs_rating_cell_is_blank_1398("rt_critic", ratings, "rottentomatoes"):
        ratings["rt_critic"] = no_rating_row("rt_critic", "rt_rating_na_skip")
    if _lrs_rating_cell_is_blank_1398("rt_audience", ratings, "rottentomatoes_user"):
        ratings["rt_audience"] = no_rating_row("rt_audience", "rt_rating_na_skip")
    entry["ratings"] = ratings
    return _rt_apply_na_badge_1398_base(entry, badge, rt_images, checked_at, result)


_simple_db_rating_values_1398_base = _simple_db_rating_values

def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    values = list(_simple_db_rating_values_1398_base(entry, item_key))
    try:
        media = media_setting_type(entry.get("type") or entry.get("media_type"))
        if media == "movie":
            idx = FINAL_RATINGS_COLUMNS.index("emmy_wins")
            values[idx] = METADATA_NA_VALUE
        elif media == "tvshow":
            idx = FINAL_RATINGS_COLUMNS.index("oscar_wins")
            values[idx] = METADATA_NA_VALUE
    except Exception:  # pylint: disable=broad-except
        pass
    return tuple(values)


# -----------------------------------------------------------------------------
# v1.3.99 - clean menu/diagnostics + bundled Top250 source cleanup
# -----------------------------------------------------------------------------
# New output layout: keep DB/settings in addon_data root; put generated logs,
# CSV reports, state JSON and diagnostic ZIPs under one compact diagnostics/ dir.
DIAGNOSTICS_DIR = os.path.join(PROFILE, "diagnostics")
try:
    os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
except Exception:
    pass
REPORT_FILE = os.path.join(DIAGNOSTICS_DIR, "ratings-report.csv")
SUMMARY_FILE = os.path.join(DIAGNOSTICS_DIR, "last-run-summary.json")
BACKGROUND_REQUEST_FILE = os.path.join(DIAGNOSTICS_DIR, "background-job-request.json")
BACKGROUND_CANCEL_FILE = os.path.join(DIAGNOSTICS_DIR, "background-job-cancel.json")
BACKGROUND_STATE_FILE = os.path.join(DIAGNOSTICS_DIR, "background-job-state.json")
BACKGROUND_FORCE_STOP_FILE = os.path.join(DIAGNOSTICS_DIR, "background-job-force-stop.json")
SAMPLE_CHECK_LOG_FILE = os.path.join(DIAGNOSTICS_DIR, "last-random-check-debug.txt")
RT_BADGE_SIMPLE_LOG_FILE = os.path.join(DIAGNOSTICS_DIR, "lrs.log")
RT_BADGE_DETAIL_LOG_FILE = os.path.join(DIAGNOSTICS_DIR, "lrs.log")
RT_BADGE_REPORT_FILE = os.path.join(DIAGNOSTICS_DIR, "rt-badges-report.csv")
RT_BADGE_LAST_JSON_FILE = os.path.join(DIAGNOSTICS_DIR, "rt-badge-sync-last.json")
# Special RT reports were merged into rt-badges-report.csv. Keep constants for
# compatibility, but the writer below is no-op.
RT_BADGE_NO_SLUG_REPORT_FILE = RT_BADGE_REPORT_FILE
RT_BADGE_BAD_SLUG_404_REPORT_FILE = RT_BADGE_REPORT_FILE
RT_BADGE_BAD_SLUG_MISMATCH_REPORT_FILE = RT_BADGE_REPORT_FILE
RT_BADGE_NOT_FOUND_REPORT_FILE = RT_BADGE_REPORT_FILE

# The old resources/data/imdb_top_tv_shows.db file is no longer shipped. Both
# movie and TV Top250 ranks come from the unified resources/data/imdb_top_250.db.
IMDB_TOP250_TV_DB_FILE = ""
IMDB_TOP250_TV_FILE = ""

def _write_rt_status_report_1394(result: Dict[str, Any]) -> None:
    # v1.3.99: special one-status CSV files removed; every row is already in
    # diagnostics/rt-badges-report.csv with status/reason columns.
    return None

_start_rt_badge_report_1393_base_1399 = start_rt_badge_report_1393

def start_rt_badge_report_1393(action: str = "rtbadges") -> str:
    try:
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        with open(RT_BADGE_REPORT_FILE, "w", encoding="utf-8-sig", newline="") as fh:
            fieldnames = _rt_report_fieldnames_1394()
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            writer.writeheader()
        _append_text_1393(RT_BADGE_SIMPLE_LOG_FILE, "---- RTBADGE {0} action={1} ----".format(now_iso(), action))
    except Exception as exc:  # pylint: disable=broad-except
        log("RTBADGE unable to start compact report: {0}".format(exc), xbmc.LOGWARNING)
    return RT_BADGE_REPORT_FILE

_sync_imdb_top250_to_library_1399_base = sync_imdb_top250_to_library

def sync_imdb_top250_to_library(force_chart_refresh: bool = False, progress: Any = None) -> Dict[str, int]:
    # Same logic as the v1.3.74 local DB sync, but progress text is standardized.
    movie_enabled = rating_enabled("movie", "top250", True) and bool_setting("include_movies", True)
    tv_enabled = rating_enabled("tvshow", "top250", True) and bool_setting("include_tvshows", True)
    movie_ranks = imdb_top250_ranks(False) if movie_enabled else {}
    tv_ranks = imdb_top250_tv_ranks() if tv_enabled else {}
    stats = {"movies": 0, "movie_matched": 0, "movie_updated": 0, "movie_missing_imdb": 0, "movie_chart_items": len(movie_ranks), "tvshows": 0, "tv_matched": 0, "tv_updated": 0, "tv_missing_imdb": 0, "tv_chart_items": len(tv_ranks), "updated": 0, "matched": 0, "total": 0, "processed": 0, "source": "local_db"}
    movies = json_rpc("VideoLibrary.GetMovies", {"properties": ["title", "year", "imdbnumber", "uniqueid", "top250"]}).get("movies", []) or [] if movie_enabled else []
    shows = json_rpc("VideoLibrary.GetTVShows", {"properties": ["title", "year", "imdbnumber", "uniqueid"]}).get("tvshows", []) or [] if tv_enabled else []
    total = len(movies) + len(shows)
    processed = 0
    with _sqlite_connect() as conn:
        if movie_enabled:
            stats["movies"] = len(movies)
            for movie in movies:
                processed += 1
                if progress is not None:
                    progress.update(int(processed * 100 / max(1, total)), "{0}/{1} {2} - TOP250".format(processed, total, (movie or {}).get("title") or "Untitled"))
                    if progress.iscanceled():
                        break
                if not isinstance(movie, dict):
                    continue
                imdb_id = _json_item_imdb_id(movie)
                value = _top250_db_value("movie", imdb_id)
                if not imdb_id:
                    stats["movie_missing_imdb"] += 1
                elif value != METADATA_NA_VALUE:
                    stats["movie_matched"] += 1
                if _upsert_top250_row(conn, "movie", movie.get("movieid"), movie, value):
                    stats["movie_updated"] += 1
        if tv_enabled:
            stats["tvshows"] = len(shows)
            for show in shows:
                processed += 1
                if progress is not None:
                    progress.update(int(processed * 100 / max(1, total)), "{0}/{1} {2} - TOP250".format(processed, total, (show or {}).get("title") or "Untitled"))
                    if progress.iscanceled():
                        break
                if not isinstance(show, dict):
                    continue
                imdb_id = _json_item_imdb_id(show)
                value = _top250_db_value("tvshow", imdb_id)
                if not imdb_id:
                    stats["tv_missing_imdb"] += 1
                elif value != METADATA_NA_VALUE:
                    stats["tv_matched"] += 1
                if _upsert_top250_row(conn, "tvshow", show.get("tvshowid"), show, value):
                    stats["tv_updated"] += 1
        _db_set_meta(conn, "top250_source", _local_top250_db_path())
        _db_set_meta(conn, "top250_local_sync_at", now_iso())
        conn.commit()
    stats["updated"] = int(stats.get("movie_updated") or 0) + int(stats.get("tv_updated") or 0)
    stats["matched"] = int(stats.get("movie_matched") or 0) + int(stats.get("tv_matched") or 0)
    stats["total"] = total
    stats["processed"] = processed or total
    return stats

def _diagnostic_candidates_1397() -> List[str]:
    paths: List[str] = []
    def add(path: Any) -> None:
        text = str(path or "").strip()
        if text and os.path.exists(text) and text not in paths:
            paths.append(text)
    # Include current root DB/settings plus compact diagnostics dir.
    for explicit in (CACHE_DB_FILE, os.path.join(PROFILE, "settings.xml"), REPORT_FILE, SUMMARY_FILE, BACKGROUND_STATE_FILE, BACKGROUND_REQUEST_FILE, BACKGROUND_CANCEL_FILE, BACKGROUND_FORCE_STOP_FILE, SAMPLE_CHECK_LOG_FILE, RT_BADGE_REPORT_FILE, RT_BADGE_SIMPLE_LOG_FILE, RT_BADGE_LAST_JSON_FILE):
        add(explicit)
    if os.path.isdir(DIAGNOSTICS_DIR):
        for name in os.listdir(DIAGNOSTICS_DIR):
            if name.lower().endswith((".log", ".csv", ".json", ".db", ".xml", ".txt")):
                add(os.path.join(DIAGNOSTICS_DIR, name))
    for special in ("special://logpath", "special://home"):
        try:
            base = xbmcvfs.translatePath(special)
        except Exception:
            base = ""
        for filename in ("kodi.log", "kodi.old.log"):
            add(os.path.join(base, filename))
    return paths

def export_diagnostics_zip_1397() -> str:
    import zipfile  # pylint: disable=import-outside-toplevel
    os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    zip_path = os.path.join(DIAGNOSTICS_DIR, "lrs-diagnostics-{0}.zip".format(stamp))
    base_profile = os.path.abspath(PROFILE)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        manifest = {"created_at": now_iso(), "addon_version": ADDON.getAddonInfo("version"), "files": []}
        for path in _diagnostic_candidates_1397():
            try:
                apath = os.path.abspath(path)
                if apath == os.path.abspath(zip_path):
                    continue
                if apath.startswith(base_profile):
                    arc = "profile/" + os.path.relpath(apath, base_profile).replace("\\", "/")
                else:
                    arc = "kodi/" + os.path.basename(apath)
                zf.write(apath, arc)
                manifest["files"].append({"source": apath, "archive": arc, "size": os.path.getsize(apath)})
            except Exception as exc:  # pylint: disable=broad-except
                manifest.setdefault("errors", []).append({"file": str(path), "error": str(exc)})
        zf.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True))
    return zip_path


# -----------------------------------------------------------------------------
# v1.4.0 - performance cleanup, verbose-only heavy logs, compact diagnostics
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 26)


def verbose_debug_enabled() -> bool:
    try:
        return ADDON.getSetting("verbose_debug_logging").lower() == "true"
    except Exception:  # pylint: disable=broad-except
        return False


# Redefine log at the end so every previously-defined function uses the quieter
# policy at runtime. Heavy publish/screen/RT traces only go to kodi.log when
# verbose diagnostics is explicitly enabled.
def log(message: str, level: int = xbmc.LOGDEBUG) -> None:
    text = str(message or "")
    heavy = text.startswith((
        "LRS PUBLISH",
        "LRS SCREENSAVER CLEARLOGO",
        "RTBADGE ",
        "context=",
    ))
    if heavy and not verbose_debug_enabled():
        return
    if level != xbmc.LOGDEBUG or debug_enabled():
        xbmc.log("[{0}] {1}".format(ADDON_ID, text), level)


def _rotate_text_file_1400(path: str, max_bytes: int = 524288) -> None:
    try:
        if path and os.path.exists(path) and os.path.getsize(path) > max_bytes:
            backup = path + ".old"
            try:
                if os.path.exists(backup):
                    os.remove(backup)
            except Exception:
                pass
            os.replace(path, backup)
    except Exception:  # pylint: disable=broad-except
        pass


_append_text_1393_base_1400 = _append_text_1393

def _append_text_1393(path: str, text: str) -> None:
    # lrs.log is intentionally compact. Full RT detail/parser traces are verbose-only.
    if os.path.abspath(str(path or "")) == os.path.abspath(str(RT_BADGE_SIMPLE_LOG_FILE or "")) and not verbose_debug_enabled():
        return
    _rotate_text_file_1400(path)
    _append_text_1393_base_1400(path, text)


_rt_badge_write_result_1393_base_1400 = _rt_badge_write_result_1393

def _rt_badge_write_result_1393(result: Dict[str, Any]) -> None:
    # Always keep the CSV report. Avoid duplicate per-item lrs.log and last-json
    # writes unless verbose diagnostics is enabled.
    try:
        new_file = not os.path.exists(RT_BADGE_REPORT_FILE) or os.path.getsize(RT_BADGE_REPORT_FILE) == 0
        fieldnames = _rt_report_fieldnames_1394()
        os.makedirs(os.path.dirname(RT_BADGE_REPORT_FILE), exist_ok=True)
        with open(RT_BADGE_REPORT_FILE, "a", encoding="utf-8-sig", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=fieldnames)
            if new_file:
                writer.writeheader()
            writer.writerow({name: result.get(name, "") for name in fieldnames})
    except Exception as exc:  # pylint: disable=broad-except
        log("RTBADGE unable to write CSV: {0}".format(exc), xbmc.LOGWARNING)
    if verbose_debug_enabled():
        simple = _rt_badge_simple_line_1393(result)
        _append_text_1393(RT_BADGE_SIMPLE_LOG_FILE, simple)
        detail = ["=" * 88, "RTBADGE DETAIL", simple]
        for key in ("url", "final_url", "page_title", "mismatch_reason", "scope", "omdb_meta", "search_query", "search_url", "search_status", "best_candidate", "match_score", "fetch_error", "parser"):
            if key in result:
                try:
                    detail.append("{0}: {1}".format(key, json.dumps(result.get(key), ensure_ascii=False, sort_keys=True)[:4000]))
                except Exception:
                    detail.append("{0}: {1}".format(key, result.get(key)))
        _append_text_1393(RT_BADGE_DETAIL_LOG_FILE, "\n".join(detail))
    _write_rt_status_report_1394(result)


_start_rt_badge_report_1393_base_1400 = start_rt_badge_report_1393

def start_rt_badge_report_1393(action: str = "rtbadges") -> str:
    try:
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        with open(RT_BADGE_REPORT_FILE, "w", encoding="utf-8-sig", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=_rt_report_fieldnames_1394())
            writer.writeheader()
        # Remove stale one-item debug JSON from older builds.
        try:
            if RT_BADGE_LAST_JSON_FILE and os.path.exists(RT_BADGE_LAST_JSON_FILE):
                os.remove(RT_BADGE_LAST_JSON_FILE)
        except Exception:
            pass
        if verbose_debug_enabled():
            _append_text_1393(RT_BADGE_SIMPLE_LOG_FILE, "---- RTBADGE {0} action={1} ----".format(now_iso(), action))
    except Exception as exc:  # pylint: disable=broad-except
        log("RTBADGE unable to start compact report: {0}".format(exc), xbmc.LOGWARNING)
    return RT_BADGE_REPORT_FILE


# Diagnostics ZIP no longer includes rt-badge-sync-last.json. It was a noisy
# per-item scratchpad and every important field already exists in rt-badges-report.csv.
def _diagnostic_candidates_1397() -> List[str]:
    paths: List[str] = []
    def add(path: Any) -> None:
        text = str(path or "").strip()
        if text and os.path.exists(text) and text not in paths:
            paths.append(text)
    for explicit in (CACHE_DB_FILE, os.path.join(PROFILE, "settings.xml"), REPORT_FILE, SUMMARY_FILE, BACKGROUND_STATE_FILE, BACKGROUND_REQUEST_FILE, BACKGROUND_CANCEL_FILE, BACKGROUND_FORCE_STOP_FILE, SAMPLE_CHECK_LOG_FILE, RT_BADGE_REPORT_FILE, RT_BADGE_SIMPLE_LOG_FILE):
        add(explicit)
    if os.path.isdir(DIAGNOSTICS_DIR):
        for name in os.listdir(DIAGNOSTICS_DIR):
            low = name.lower()
            if low == "rt-badge-sync-last.json":
                continue
            if low.endswith((".log", ".csv", ".json", ".db", ".xml", ".txt")):
                add(os.path.join(DIAGNOSTICS_DIR, name))
    for special in ("special://logpath", "special://home"):
        try:
            base = xbmcvfs.translatePath(special)
        except Exception:
            base = ""
        for filename in ("kodi.log", "kodi.old.log"):
            add(os.path.join(base, filename))
    return paths


# Avoid rewriting the whole SQLite ratings table on every save. This keeps Kodi
# responsive after scans and prevents updated_at churn on unchanged rows.
def _db_existing_value_map_1400(conn: sqlite3.Connection) -> Dict[str, Tuple[Any, ...]]:
    try:
        rows = conn.execute("SELECT {0} FROM ratings".format(",".join(FINAL_RATINGS_COLUMNS))).fetchall()
    except Exception:
        return {}
    out: Dict[str, Tuple[Any, ...]] = {}
    for row in rows:
        try:
            vals = tuple(row[col] for col in FINAL_RATINGS_COLUMNS)
            key = str(row["item_key"] or "")
            if key:
                out[key] = vals
        except Exception:
            continue
    return out


def _same_except_timestamps_1400(old_vals: Tuple[Any, ...], new_vals: Tuple[Any, ...]) -> bool:
    try:
        skip = {FINAL_RATINGS_COLUMNS.index("updated_at"), FINAL_RATINGS_COLUMNS.index("timestamp")}
    except Exception:
        skip = set()
    if len(old_vals) != len(new_vals):
        return False
    for idx, (old, new) in enumerate(zip(old_vals, new_vals)):
        if idx in skip:
            continue
        if str(old if old is not None else "") != str(new if new is not None else ""):
            return False
    return True



# -----------------------------------------------------------------------------
# v1.4.2 - SQLite transaction fix + heavy logs outside kodi.log
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 27)


def _append_lrs_verbose_line_1420(message: str) -> None:
    try:
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        _rotate_text_file_1400(RT_BADGE_SIMPLE_LOG_FILE)
        with open(RT_BADGE_SIMPLE_LOG_FILE, "a", encoding="utf-8") as handle:
            handle.write("{0} | {1}\n".format(now_iso(), str(message or "")))
    except Exception:  # pylint: disable=broad-except
        pass


# Final logging policy: heavy focus/publish/RT trace never spams kodi.log.
# When verbose diagnostics is enabled it goes to diagnostics/lrs.log instead.
def log(message: str, level: int = xbmc.LOGDEBUG) -> None:
    text = str(message or "")
    heavy = text.startswith((
        "LRS PUBLISH",
        "LRS SCREENSAVER CLEARLOGO",
        "RTBADGE ",
        "context=",
    ))
    if heavy:
        if verbose_debug_enabled():
            _append_lrs_verbose_line_1420(text)
        return
    if level != xbmc.LOGDEBUG or debug_enabled():
        xbmc.log("[{0}] {1}".format(ADDON_ID, text), level)


# Final save_cache: _sqlite_connect()/_ensure_current_cache_schema() may leave
# sqlite3 in an implicit transaction. Always close that transaction before
# BEGIN IMMEDIATE to avoid: cannot start a transaction within a transaction.

# -----------------------------------------------------------------------------
# v1.4.3 - external ratings table + Oscar Best Picture side-check
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 28)

# Same order as ratings, with the new Oscar BP flag directly after oscar_wins.
FINAL_RATINGS_COLUMNS = [
    "item_key", "title", "imdb", "tmdb", "rottentomatoes", "rottentomatoes_image",
    "rottentomatoes_user", "rottentomatoes_userimage", "metacritic", "trakt", "top250",
    "showtitle", "season", "episode", "year", "series_status", "series_status_date",
    "oscar_wins", "oscar_best_picture", "emmy_wins", "awards_text", "imdb_id", "tmdb_id", "dbid", "media_type",
    "rottentomatoes_slug", "rottentomatoes_status", "updated_at", "timestamp",
]
SIMPLE_RATING_COLUMNS = FINAL_RATINGS_COLUMNS


def _rating_schema_sql_1430(table_name: str = "ratings") -> str:
    return """
        CREATE TABLE IF NOT EXISTS {table} (
            item_key TEXT PRIMARY KEY,
            title TEXT,
            imdb TEXT,
            tmdb TEXT,
            rottentomatoes TEXT,
            rottentomatoes_image TEXT,
            rottentomatoes_user TEXT,
            rottentomatoes_userimage TEXT,
            metacritic TEXT,
            trakt TEXT,
            top250 INTEGER,
            showtitle TEXT,
            season INTEGER,
            episode INTEGER,
            year TEXT,
            series_status TEXT,
            series_status_date TEXT,
            oscar_wins INTEGER,
            oscar_best_picture TEXT,
            emmy_wins INTEGER,
            awards_text TEXT,
            imdb_id TEXT,
            tmdb_id TEXT,
            dbid INTEGER,
            media_type TEXT,
            rottentomatoes_slug TEXT,
            rottentomatoes_status TEXT,
            updated_at TEXT,
            timestamp INTEGER
        )
    """.format(table=str(table_name))


def _simple_rating_schema_sql() -> str:
    return _rating_schema_sql_1430("ratings")


def _normalize_oscar_bp_1430(value: Any) -> str:
    text = str(value if value is not None else "").strip()
    if not text:
        return ""
    if _is_metadata_na(text):
        return METADATA_NA_VALUE
    if text.lower() in ("1", "true", "yes", "y", "best_picture", "best-picture", "bp"):
        return "1"
    return METADATA_NA_VALUE if text.upper() == "N/A" else text


def _awards_best_picture_value_1430(awards: Dict[str, Any], entry: Dict[str, Any]) -> str:
    if isinstance(awards, dict) and "oscar_best_picture" in awards:
        return _normalize_oscar_bp_1430(awards.get("oscar_best_picture"))
    return _normalize_oscar_bp_1430((entry or {}).get("oscar_best_picture"))


def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    ratings = entry.get("ratings") or {}
    if not isinstance(ratings, dict):
        ratings = {}
    ids = entry.get("ids") or {}
    series = entry.get("series") or {}
    awards = entry.get("awards") or {}
    rt_images = entry.get("rt_images") if isinstance(entry.get("rt_images"), dict) else {}
    rt_badge = entry.get("rt_badge") if isinstance(entry.get("rt_badge"), dict) else {}

    rt_critic_cell = _display_number_for_db("rt_critic", ratings.get("rt_critic") or ratings.get("rottentomatoes") or {})
    rt_audience_cell = _display_number_for_db("rt_audience", ratings.get("rt_audience") or ratings.get("rottentomatoes_user") or {})
    metacritic_cell = _display_number_for_db("metacritic", ratings.get("metacritic") or {})
    trakt_cell = _display_number_for_db("trakt", ratings.get("trakt") or {})
    top250_value = _metadata_int_or_na(entry.get("imdb_top250_rank") if "imdb_top250_rank" in entry else entry.get("top250"))
    oscar_value = _metadata_int_or_na(awards.get("oscar_wins") if isinstance(awards, dict) and "oscar_wins" in awards else entry.get("oscar_wins"))
    oscar_bp = _awards_best_picture_value_1430(awards, entry)
    emmy_value = _metadata_int_or_na(awards.get("emmy_wins") if isinstance(awards, dict) and "emmy_wins" in awards else entry.get("emmy_wins"))
    awards_text = str((awards or {}).get("awards_text") or entry.get("awards_text") or "")
    critic_image = str(rt_images.get("critic") or entry.get("rottentomatoes_image") or "").strip().lower()
    audience_image = str(rt_images.get("audience") or entry.get("rottentomatoes_userimage") or "").strip().lower()
    if critic_image not in ("certified", "fresh", "rotten"):
        critic_image = _simple_rating_image("rt_critic", rt_critic_cell)
    if audience_image not in ("verifiedhot", "upright", "spilled"):
        audience_image = _simple_rating_image("rt_audience", rt_audience_cell)
    slug = _normalize_rt_slug_1393(rt_badge.get("slug") or entry.get("rottentomatoes_slug") or "")
    status = str(rt_badge.get("status") or entry.get("rottentomatoes_status") or "")[:240]
    return (
        str(item_key), str(entry.get("title") or ""),
        _display_number_for_db("imdb", ratings.get("imdb") or {}),
        _display_number_for_db("tmdb", ratings.get("tmdb") or {}),
        rt_critic_cell, critic_image, rt_audience_cell, audience_image,
        metacritic_cell, trakt_cell, top250_value,
        str(entry.get("showtitle") or ""), safe_int(entry.get("season")), safe_int(entry.get("episode")),
        str(entry.get("year") or ""), str(series.get("status") or entry.get("series_status") or ""),
        str(series.get("status_date") or entry.get("series_status_date") or ""),
        oscar_value, oscar_bp, emmy_value, awards_text,
        str(ids.get("imdb") or entry.get("imdb") or entry.get("imdbnumber") or ""),
        str(ids.get("tmdb") or entry.get("tmdb") or entry.get("tmdb_id") or ""),
        safe_int(entry.get("dbid")), str(entry.get("type") or ""), slug, status,
        str(entry.get("updated_at") or now_iso()).replace(" WIB", ""),
        safe_int(entry.get("timestamp")) or int(time.time()),
    )


_ratings_only_row_to_entry_1430_base = _ratings_only_row_to_entry

def _ratings_only_row_to_entry(row: sqlite3.Row) -> Dict[str, Any]:
    entry = _ratings_only_row_to_entry_1430_base(row)
    awards = dict(entry.get("awards") or {})
    raw_bp = _row_value(row, "oscar_best_picture")
    bp = _normalize_oscar_bp_1430(raw_bp)
    if bp:
        awards["oscar_best_picture"] = bp
        entry["oscar_best_picture"] = bp
    if awards:
        entry["awards"] = awards
    return entry


def _parse_mdblist_best_picture_1430(awards_text: Any) -> str:
    text = str(awards_text if awards_text is not None else "").strip()
    if not text or _is_metadata_na(text):
        return ""
    # Only winner section counts. Nominations must never set Best Picture.
    low = text.lower()
    won_section = ""
    m = re.search(r"\bwon\s*:\s*(.*)", text, flags=re.I | re.S)
    if m:
        won_section = m.group(1)
        stop = re.search(r"\b(?:nominated|nomination|nominations)\s*:", won_section, flags=re.I)
        if stop:
            won_section = won_section[:stop.start()]
    else:
        # Some strings may be plain prose; accept only if it clearly says won.
        if re.search(r"\bwon\b", low):
            won_section = text
    if not won_section:
        return METADATA_NA_VALUE
    section_low = won_section.lower()
    if re.search(r"\b(nominated|nomination|nominations)\b", section_low) and not re.search(r"\bwon\b", section_low):
        return METADATA_NA_VALUE
    has_bp = bool(re.search(r"\bbest\s+(?:motion\s+picture\s+of\s+the\s+year|picture)\b", section_low))
    has_oscars = bool(re.search(r"\b(oscars?|academy\s+awards?)\b", section_low))
    return "1" if has_bp and has_oscars else METADATA_NA_VALUE


def _mdblist_awards_candidates_1430(ids: Dict[str, str], media_type: str) -> List[Tuple[str, str]]:
    out: List[Tuple[str, str]] = []
    def add(provider: str, value: Any) -> None:
        value = str(value or "").strip()
        if not value:
            return
        if provider == "imdb" and not value.lower().startswith("tt"):
            return
        pair = (provider, value)
        if pair not in out:
            out.append(pair)
    if media_type == "show":
        add("tmdb", ids.get("tmdb") or ids.get("show_tmdb")); add("imdb", ids.get("imdb")); add("trakt", ids.get("trakt")); add("mdblist", ids.get("mdblist"))
    else:
        add("imdb", ids.get("imdb")); add("tmdb", ids.get("tmdb")); add("trakt", ids.get("trakt")); add("mdblist", ids.get("mdblist"))
    return out


def mdblist_best_picture_lookup_1430(ids: Dict[str, str], media_type: str, key: Any) -> Tuple[str, Dict[str, Any]]:
    """MDBList side-check for Oscar Best Picture only. Does not return ratings."""
    if media_type != "movie":
        return METADATA_NA_VALUE, {"policy": "movie_only"}
    keys = _provider_key_list(key)
    if not keys:
        return "", {"error": "api_key_missing", "attempts": []}
    candidates = _mdblist_awards_candidates_1430(ids or {}, "movie")
    if not candidates:
        return "", {"error": "no_ids", "attempts": []}
    all_attempts: List[Dict[str, Any]] = []
    limited_messages: List[str] = []
    for index, current_key in enumerate(keys):
        if _provider_key_is_limited(key, index):
            continue
        for provider, media_id in candidates:
            url = "https://api.mdblist.com/{0}/movie/{1}?{2}".format(provider, quote(media_id, safe=""), urlencode({"apikey": current_key, "format": "json"}))
            try:
                payload, headers = http_json(url)
            except Exception as exc:  # pylint: disable=broad-except
                all_attempts.append({"provider": provider, "id": media_id, "key_index": index + 1, "error": str(exc)})
                continue
            payload = payload if isinstance(payload, dict) else {}
            err = str(payload.get("error") or payload.get("message") or payload.get("detail") or payload.get("__error") or "")
            awards_text = str(payload.get("awards") or "").strip()
            all_attempts.append({
                "provider": provider, "id": media_id, "key_index": index + 1,
                "http_status": payload.get("__http_status", ""), "error": err,
                "has_awards": bool(awards_text),
            })
            if is_provider_limit_payload("mdblist", payload, headers):
                _provider_mark_limited(key, index)
                limited_messages.append(provider_limit_message("mdblist", payload))
                break
            if err:
                continue
            # Valid payload: with or without awards text, this is cacheable.
            bp = _parse_mdblist_best_picture_1430(awards_text)
            return bp or METADATA_NA_VALUE, {"source": "mdblist", "attempts": all_attempts, "awards_text": awards_text, "best_picture": bp or METADATA_NA_VALUE}
    if limited_messages:
        return "", {"limited": True, "limit_provider": "MDBList", "limit_message": "; ".join(limited_messages), "attempts": all_attempts}
    return "", {"attempts": all_attempts, "error": "no_cacheable_response"}


def _oscar_wins_positive_1430(awards: Dict[str, Any]) -> bool:
    val = (awards or {}).get("oscar_wins")
    return bool(safe_int(val) and safe_int(val) > 0)


def _oscar_bp_complete_1430(awards: Dict[str, Any]) -> bool:
    return _normalize_oscar_bp_1430((awards or {}).get("oscar_best_picture")) in ("1", METADATA_NA_VALUE)


def _movie_bp_needs_lookup_1430(awards: Dict[str, Any]) -> bool:
    return _oscar_wins_positive_1430(awards) and not _oscar_bp_complete_1430(awards)


def record_missing_awards(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    media = media_setting_type((item or {}).get("type"))
    awards = (record or {}).get("awards") or {}
    if _awards_needs_fill(awards, media):
        return True
    if media == "movie" and _movie_bp_needs_lookup_1430(awards):
        return True
    return False


def _merge_missing_awards(existing: Dict[str, Any], found: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(existing or {})
    found = found or {}
    # Keep OMDb-only policy for counts. MDBList may only contribute BP.
    source = str(found.get("source") or "").lower()
    if source and source not in ("omdb", "mdblist_bp"):
        return merged
    for key in ("awards_text", "source", "updated_at"):
        if source == "omdb" and found.get(key) not in (None, ""):
            merged[key] = found[key]
    for key in ("oscar_wins", "emmy_wins"):
        if source in ("", "omdb") and found.get(key) not in (None, ""):
            merged[key] = found[key]
    if found.get("oscar_best_picture") not in (None, ""):
        merged["oscar_best_picture"] = _normalize_oscar_bp_1430(found.get("oscar_best_picture"))
    return merged


def _omdb_awards_missing_marker_1390(media_type: Any, awards: Dict[str, Any]) -> Dict[str, Any]:
    media = media_setting_type(media_type)
    awards = dict(awards or {})
    awards["source"] = "omdb"
    awards.setdefault("awards_text", METADATA_NA_VALUE)
    if media == "movie":
        awards["oscar_wins"] = METADATA_NA_VALUE
        awards["oscar_best_picture"] = METADATA_NA_VALUE
        awards["emmy_wins"] = METADATA_NA_VALUE
    elif media == "tvshow":
        awards["oscar_wins"] = METADATA_NA_VALUE
        awards["oscar_best_picture"] = METADATA_NA_VALUE
        awards["emmy_wins"] = METADATA_NA_VALUE
    awards["updated_at"] = now_iso()
    return awards


def resolve_awards_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    """OMDb for Oscar/Emmy counts; MDBList only for Oscar Best Picture side-check."""
    media = media_setting_type((item or {}).get("type"))
    existing = dict(existing or {})
    if media not in ("movie", "tvshow"):
        return existing
    ids = dict(existing.get("ids") or {})
    for k, v in extract_ids(item).items():
        if v not in (None, ""):
            ids.setdefault(str(k), str(v))
    awards = dict(existing.get("awards") or {})
    provider_meta = dict(existing.get("provider_meta") or {})
    errors: List[str] = []

    # For old rows: if Oscar count already exists but BP is missing, do not waste OMDb.
    need_omdb = _awards_needs_fill(awards, media)
    if need_omdb:
        if not bool_setting("use_omdb", True) or not keys.get("omdb"):
            errors.append("omdb: api key missing or provider disabled")
        else:
            try:
                found, ids, omdb_meta = omdb_lookup(item, ids, keys["omdb"])
                provider_meta["omdb"] = omdb_meta
                found_awards = found.pop("__awards", {}) if isinstance(found, dict) else {}
                if found_awards:
                    awards = _merge_missing_awards(awards, found_awards)
                if _awards_needs_fill(awards, media):
                    awards = _omdb_awards_missing_marker_1390(media, awards)
            except ProviderLimitReached:
                raise
            except Exception as exc:  # pylint: disable=broad-except
                errors.append("omdb: {0}".format(exc))

    # Irrelevant columns should be visible N/A.
    if media == "tvshow":
        awards.setdefault("oscar_wins", METADATA_NA_VALUE)
        awards.setdefault("oscar_best_picture", METADATA_NA_VALUE)
    elif media == "movie":
        awards.setdefault("emmy_wins", METADATA_NA_VALUE)
        if _is_metadata_na(awards.get("oscar_wins")):
            awards.setdefault("oscar_best_picture", METADATA_NA_VALUE)

    if media == "movie" and _movie_bp_needs_lookup_1430(awards):
        if bool_setting("use_mdblist", True) and keys.get("mdblist"):
            try:
                bp, bp_meta = mdblist_best_picture_lookup_1430(ids, "movie", keys.get("mdblist"))
                provider_meta["mdblist_best_picture"] = bp_meta
                if bp in ("1", METADATA_NA_VALUE):
                    awards["oscar_best_picture"] = bp
                    awards["updated_at"] = now_iso()
                    # Do not replace OMDb awards_text. MDBList text stays in provider_meta.
                elif (bp_meta or {}).get("limited"):
                    errors.append("mdblist_bp: API limit reached; oscar_best_picture left blank for retry")
                else:
                    errors.append("mdblist_bp: no cacheable response; oscar_best_picture left blank for retry")
            except Exception as exc:  # pylint: disable=broad-except
                errors.append("mdblist_bp: {0}".format(exc))
        else:
            errors.append("mdblist_bp: provider disabled or api key missing")

    return _entry_with_awards_1390(item, existing, ids, awards, provider_meta, errors)


# External/non-library widget cache. Table schema intentionally mirrors ratings.
def external_item_key_1430(item: Dict[str, Any]) -> str:
    key = identity_key(item or {})
    if key.startswith("external|"):
        return key
    return "external|" + key


def _external_row_to_entry_1430(row: sqlite3.Row) -> Dict[str, Any]:
    return _ratings_only_row_to_entry(row)


def load_external_record_1430(item: Dict[str, Any]) -> Dict[str, Any]:
    if not valid_library_item(item):
        return {}
    conn = _sqlite_connect()
    try:
        _ensure_current_cache_schema(conn)
        key = external_item_key_1430(item)
        rows: List[sqlite3.Row] = []
        row = conn.execute("SELECT * FROM external_ratings WHERE item_key=?", (key,)).fetchone()
        if row:
            rows.append(row)
        imdb = _norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb"))
        tmdb = _norm_tmdb(item.get("tmdb_id") or item.get("tmdb"))
        if imdb:
            rows.extend(conn.execute("SELECT * FROM external_ratings WHERE imdb_id=?", (imdb,)).fetchall())
        if tmdb:
            rows.extend(conn.execute("SELECT * FROM external_ratings WHERE tmdb_id=?", (tmdb,)).fetchall())
        if not rows:
            title = _norm_text(item.get("title"))
            year = safe_int(item.get("year"))
            media = media_setting_type(item.get("type"))
            if title:
                for row in conn.execute("SELECT * FROM external_ratings WHERE media_type=? AND title=?", (media, item.get("title") or "")).fetchall():
                    if year is None or safe_int(_row_value(row, "year")) in (None, year):
                        rows.append(row)
        seen = set(); entries=[]
        for row in rows:
            rkey = str(_row_value(row, "item_key") or "")
            if rkey in seen:
                continue
            seen.add(rkey)
            entry = _external_row_to_entry_1430(row)
            if context_matches_record(item, entry):
                entries.append(entry)
        return _choose_best_record(media_setting_type(item.get("type")), entries, entries[0] if entries else None) if entries else {}
    except Exception as exc:  # pylint: disable=broad-except
        log("External ratings lookup failed: {0}".format(exc), xbmc.LOGWARNING)
        return {}
    finally:
        conn.close()


def save_external_record_1430(item: Dict[str, Any], entry: Dict[str, Any]) -> None:
    if not isinstance(entry, dict) or not entry:
        return
    row = dict(entry)
    row["dbid"] = None
    row["type"] = media_setting_type(row.get("type") or (item or {}).get("type"))
    if not row.get("title"):
        row["title"] = (item or {}).get("title") or ""
    if not row.get("year"):
        row["year"] = (item or {}).get("year") or ""
    key = external_item_key_1430(row if row.get("title") else item)
    conn = _sqlite_connect()
    try:
        if getattr(conn, "in_transaction", False):
            conn.commit()
        _ensure_current_cache_schema(conn)
        if getattr(conn, "in_transaction", False):
            conn.commit()
        vals = tuple(_simple_db_rating_values(row, key))
        conn.execute("INSERT OR REPLACE INTO external_ratings({0}) VALUES({1})".format(
            ",".join(FINAL_RATINGS_COLUMNS), ",".join(["?"] * len(FINAL_RATINGS_COLUMNS))
        ), vals)
        conn.commit()
    except Exception:
        try: conn.rollback()
        except Exception: pass
        raise
    finally:
        conn.close()


def external_item_released_1430(item: Dict[str, Any]) -> bool:
    # Conservative no-fetch for clearly future years. Same-year items are allowed;
    # many widgets do not expose a usable release date.
    year = safe_int((item or {}).get("year"))
    try:
        current_year = datetime.now().year
    except Exception:
        current_year = 0
    if year and current_year and year > current_year:
        return False
    return True


def resolve_external_item_1430(item: Dict[str, Any], keys: Dict[str, Any]) -> Dict[str, Any]:
    media = media_setting_type((item or {}).get("type"))
    if media not in ("movie", "tvshow"):
        return {}
    if not external_item_released_1430(item):
        return {}
    existing = load_external_record_1430(item)
    entry = resolve_item(item, keys, existing, missing_only=True, include_local=False)
    # Fill awards/BP for external widgets too, but only for this focused item.
    try:
        if record_missing_awards(item, entry):
            entry = resolve_awards_only(item, keys, entry)
    except ProviderLimitReached:
        raise
    except Exception as exc:  # pylint: disable=broad-except
        entry.setdefault("errors", []).append("external_awards: {0}".format(exc))
    try:
        if record_missing_rt_badge(item, entry):
            entry = resolve_rt_badge_only(item, keys, entry, force=False)
    except Exception as exc:  # pylint: disable=broad-except
        entry.setdefault("errors", []).append("external_rtbadge: {0}".format(exc))
    save_external_record_1430(item, entry)
    return entry


_af3_values_1430_base = af3_values

def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    values = _af3_values_1430_base(record)
    awards = (record or {}).get("awards") or {}
    if isinstance(awards, dict):
        bp = _normalize_oscar_bp_1430(awards.get("oscar_best_picture") or (record or {}).get("oscar_best_picture"))
        oscar_wins = safe_int(awards.get("oscar_wins"))
        if bp == "1":
            values["Oscar_BestPicture"] = "true"
            values["OscarBestPicture"] = "true"
            values["Oscar_BestPictureIcon"] = kpm_shared_icon_path_1513("oscars_bp.png")
            values["OscarBestPictureIcon"] = kpm_shared_icon_path_1513("oscars_bp.png")
            values["Oscar_Icon"] = kpm_shared_icon_path_1513("oscars_bp.png")
            values["OscarIcon"] = kpm_shared_icon_path_1513("oscars_bp.png")
        elif oscar_wins and oscar_wins > 0:
            values.setdefault("Oscar_Icon", kpm_shared_icon_path_1513("oscars.png"))
            values.setdefault("OscarIcon", kpm_shared_icon_path_1513("oscars.png"))
    return values

LRS_EXTRA_PROPERTY_NAMES = tuple(dict.fromkeys(tuple(LRS_EXTRA_PROPERTY_NAMES) + (
    "Oscar_BestPicture", "OscarBestPicture", "Oscar_BestPictureIcon", "OscarBestPictureIcon", "Oscar_Icon", "OscarIcon",
)))


_export_csv_1430_base = export_csv

def export_csv(cache: Dict[str, Any]) -> str:
    # Same report as before, plus oscar_best_picture after oscar_wins.
    os.makedirs(os.path.dirname(REPORT_FILE) or PROFILE, exist_ok=True)
    entries = list((cache.get("items") or {}).values())
    canonical_entries = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        row = dict(entry)
        row["ratings"] = preserve_ratings_for_item(row.get("type"), row.get("ratings") or {})
        canonical_entries.append(row)
    sources = sorted({source for entry in canonical_entries for source in (entry.get("ratings") or {}).keys()})
    fixed = [
        "type", "dbid", "title", "showtitle", "season", "episode", "year",
        "tmdb_id", "imdb_id", "imdb_top250_rank",
        "oscar_wins", "oscar_best_picture", "emmy_wins", "series_status", "series_status_date",
        "rottentomatoes_slug", "rottentomatoes_status", "updated_at",
    ]
    columns = fixed + ["rating_{0}".format(source) for source in sources]
    with open(REPORT_FILE, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for entry in sorted(canonical_entries, key=lambda row: (str(row.get("type")), str(row.get("showtitle")), str(row.get("title")), safe_int(row.get("season")) or -1, safe_int(row.get("episode")) or -1)):
            row = {key: entry.get(key, "") for key in fixed}
            ids = entry.get("ids") or {}
            row["tmdb_id"] = _csv_tmdb_id(ids.get("tmdb"))
            row["imdb_id"] = _csv_imdb_id(ids.get("imdb"))
            row["imdb_top250_rank"] = csv_top250_rank(entry)
            awards = entry.get("awards") or {}
            row["oscar_wins"] = awards.get("oscar_wins", "")
            row["oscar_best_picture"] = awards.get("oscar_best_picture", "")
            row["emmy_wins"] = awards.get("emmy_wins", "")
            series = entry.get("series") or {}
            row["series_status"] = series.get("status", "")
            row["series_status_date"] = series.get("status_date", "")
            rt_badge = entry.get("rt_badge") if isinstance(entry.get("rt_badge"), dict) else {}
            row["rottentomatoes_slug"] = rt_badge.get("slug") or entry.get("rottentomatoes_slug") or ""
            row["rottentomatoes_status"] = rt_badge.get("status") or entry.get("rottentomatoes_status") or ""
            for source in sources:
                rating = (entry.get("ratings") or {}).get(source) or {}
                row["rating_{0}".format(source)] = NO_RATING_VALUE if is_no_rating_marker(rating) else ("" if rating.get("value") in (None, "") else rating.get("value"))
            writer.writerow(row)
    return REPORT_FILE


# -----------------------------------------------------------------------------
# v1.4.5 - external/library de-dup + Oscar BP repair status + lighter missing scan
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 29)
OSCAR_BP_LOOKUP_VERSION_1450 = 1450


def _normalize_compare_cell_1450(col: str, value: Any, row_values: Optional[Tuple[Any, ...]] = None) -> str:
    text = str(value if value is not None else "").strip()
    # SQLite/CSV conversions can turn numeric TEXT into "89.0"; compare numeric
    # columns by numeric value where possible to avoid no-op rewrites.
    if col in ("imdb", "tmdb", "rottentomatoes", "rottentomatoes_user", "metacritic", "trakt"):
        try:
            if text != "" and not _is_metadata_na(text):
                return ("%.4f" % float(text)).rstrip("0").rstrip(".")
        except Exception:
            pass
    if col in ("top250", "season", "episode", "oscar_wins", "emmy_wins", "dbid", "timestamp"):
        try:
            if text != "" and not _is_metadata_na(text):
                return str(int(float(text)))
        except Exception:
            pass
    return text


def _same_except_timestamps_1400(old_vals: Tuple[Any, ...], new_vals: Tuple[Any, ...]) -> bool:
    """Final no-op writer comparison.

    v1.4.5 keeps the 1.4.2 no-rewrite optimization but normalizes numeric text
    and treats irrelevant Oscar-BP blanks for non-Oscar movies as no-change.
    """
    try:
        skip = {FINAL_RATINGS_COLUMNS.index("updated_at"), FINAL_RATINGS_COLUMNS.index("timestamp")}
    except Exception:
        skip = set()
    if len(old_vals) != len(new_vals):
        return False
    old_map = {FINAL_RATINGS_COLUMNS[i]: old_vals[i] for i in range(min(len(FINAL_RATINGS_COLUMNS), len(old_vals)))}
    new_map = {FINAL_RATINGS_COLUMNS[i]: new_vals[i] for i in range(min(len(FINAL_RATINGS_COLUMNS), len(new_vals)))}
    for idx, (old, new) in enumerate(zip(old_vals, new_vals)):
        if idx in skip:
            continue
        col = FINAL_RATINGS_COLUMNS[idx] if idx < len(FINAL_RATINGS_COLUMNS) else str(idx)
        # For movies with no Oscar wins, oscar_best_picture blank/N/A is display-irrelevant.
        if col == "oscar_best_picture":
            old_os = str(old_map.get("oscar_wins") if old_map.get("oscar_wins") is not None else "").strip()
            new_os = str(new_map.get("oscar_wins") if new_map.get("oscar_wins") is not None else "").strip()
            if (not old_os or _is_metadata_na(old_os)) and (not new_os or _is_metadata_na(new_os)):
                continue
        if _normalize_compare_cell_1450(col, old, old_vals) != _normalize_compare_cell_1450(col, new, new_vals):
            return False
    return True


def _ensure_oscar_bp_status_table_1450(conn: sqlite3.Connection) -> None:
    conn.execute("""
        CREATE TABLE IF NOT EXISTS oscar_bp_status (
            item_key TEXT PRIMARY KEY,
            imdb_id TEXT,
            tmdb_id TEXT,
            title TEXT,
            year TEXT,
            status TEXT,
            parser_version INTEGER,
            checked_at TEXT
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_lrs_oscar_bp_status_imdb ON oscar_bp_status(imdb_id)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_lrs_oscar_bp_status_tmdb ON oscar_bp_status(tmdb_id)")




def _bp_item_identity_1450(item: Dict[str, Any], record: Dict[str, Any]) -> Tuple[str, str, str, str, str]:
    item_key = record_item_key(record) or item_key_for(item or {})
    ids = dict((record or {}).get("ids") or {})
    for k, v in extract_ids(item or {}).items():
        if v not in (None, ""):
            ids.setdefault(str(k), str(v))
    imdb = _norm_imdb(ids.get("imdb") or (item or {}).get("imdbnumber") or (item or {}).get("imdb_id") or (item or {}).get("imdb"))
    tmdb = _norm_tmdb(ids.get("tmdb") or (item or {}).get("tmdb_id") or (item or {}).get("tmdb"))
    title = str((record or {}).get("title") or (item or {}).get("title") or "").strip()
    year = str((record or {}).get("year") or (item or {}).get("year") or "").strip()
    return item_key, imdb, tmdb, title, year


def _oscar_bp_status_current_1450(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    awards = (record or {}).get("awards") or {}
    if not _oscar_wins_positive_1430(awards):
        return True
    bp = _normalize_oscar_bp_1430(awards.get("oscar_best_picture") or (record or {}).get("oscar_best_picture"))
    if bp == "1":
        return True
    item_key, imdb, tmdb, title, year = _bp_item_identity_1450(item, record)
    conn = _sqlite_connect()
    try:
        _ensure_current_cache_schema(conn)
        rows: List[sqlite3.Row] = []
        if item_key:
            row = conn.execute("SELECT * FROM oscar_bp_status WHERE item_key=?", (item_key,)).fetchone()
            if row:
                rows.append(row)
        if imdb:
            rows.extend(conn.execute("SELECT * FROM oscar_bp_status WHERE imdb_id=?", (imdb,)).fetchall())
        if tmdb:
            rows.extend(conn.execute("SELECT * FROM oscar_bp_status WHERE tmdb_id=?", (tmdb,)).fetchall())
        for row in rows:
            try:
                if safe_int(row["parser_version"]) >= OSCAR_BP_LOOKUP_VERSION_1450 and str(row["status"] or "").strip() in ("1", METADATA_NA_VALUE):
                    return True
            except Exception:
                continue
        return False
    except Exception:
        return False
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _save_oscar_bp_status_1450(item: Dict[str, Any], record: Dict[str, Any], status: str) -> None:
    status = _normalize_oscar_bp_1430(status)
    if status not in ("1", METADATA_NA_VALUE):
        return
    item_key, imdb, tmdb, title, year = _bp_item_identity_1450(item, record)
    if not item_key and not imdb and not tmdb:
        return
    conn = _sqlite_connect()
    try:
        _ensure_current_cache_schema(conn)
        if getattr(conn, "in_transaction", False):
            conn.commit()
        conn.execute("INSERT OR REPLACE INTO oscar_bp_status(item_key, imdb_id, tmdb_id, title, year, status, parser_version, checked_at) VALUES(?,?,?,?,?,?,?,?)",
                     (item_key or (imdb or tmdb), imdb, tmdb, title, year, status, OSCAR_BP_LOOKUP_VERSION_1450, now_iso()))
        conn.commit()
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
    finally:
        try:
            conn.close()
        except Exception:
            pass


def _parse_mdblist_best_picture_1430(awards_text: Any) -> str:
    """Parse MDBList Oscar Best Picture winner text.

    Winner-only. Handles MDBList strings like:
      Won: Best Motion Picture of the Year (Oscars, 2005). Plus ...
    and never treats nominations as wins.
    """
    text = str(awards_text if awards_text is not None else "").strip()
    if not text or _is_metadata_na(text):
        return ""
    # Work only inside the winner part.
    m = re.search(r"\bwon\s*:\s*(.*)", text, flags=re.I | re.S)
    if m:
        section = m.group(1)
    elif re.search(r"\bwon\b", text, flags=re.I):
        section = text
    else:
        return METADATA_NA_VALUE
    # Stop at explicit nomination section, but do not stop at "Plus 2 Oscar nominations"
    # because the Best Picture sentence may be before it.
    stop = re.search(r"\b(?:nominated|nomination|nominations)\s*:", section, flags=re.I)
    if stop:
        section = section[:stop.start()]
    # Keep the early winner sentence; this avoids later nomination wording confusing
    # the detection while preserving "Won: Best Motion Picture..." text.
    first = re.split(r"\.\s+(?:Plus|Also|Nominated|Nomination|Nominations)\b", section, maxsplit=1, flags=re.I)[0]
    section_low = (first or section).lower()
    has_bp = bool(re.search(r"\bbest\s+(?:motion\s+picture\s+of\s+the\s+year|picture)\b", section_low))
    has_oscars = bool(re.search(r"\b(oscars?|academy\s+awards?)\b", section_low))
    if has_bp and has_oscars:
        return "1"
    return METADATA_NA_VALUE


_record_missing_awards_1450_base = record_missing_awards

def record_missing_awards(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    media = media_setting_type((item or {}).get("type"))
    awards = (record or {}).get("awards") or {}
    if _awards_needs_fill(awards, media):
        return True
    if media == "movie" and _oscar_wins_positive_1430(awards):
        bp = _normalize_oscar_bp_1430(awards.get("oscar_best_picture") or (record or {}).get("oscar_best_picture"))
        if bp == "1":
            return False
        # Blank BP is missing. N/A is final only after the v1.4.5 parser/status table
        # has checked this exact Oscar-winning movie.
        if not bp:
            return True
        if bp == METADATA_NA_VALUE and not _oscar_bp_status_current_1450(item, record):
            return True
    return False


_resolve_awards_only_1450_base = resolve_awards_only

def resolve_awards_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    entry = _resolve_awards_only_1450_base(item, keys, existing)
    media = media_setting_type((item or {}).get("type"))
    if media != "movie":
        return entry
    awards = dict((entry or {}).get("awards") or {})
    if not _oscar_wins_positive_1430(awards):
        return entry
    bp = _normalize_oscar_bp_1430(awards.get("oscar_best_picture") or (entry or {}).get("oscar_best_picture"))
    if bp == "1":
        _save_oscar_bp_status_1450(item, entry, "1")
        return entry
    if bp == METADATA_NA_VALUE and _oscar_bp_status_current_1450(item, entry):
        return entry
    # Force/repair BP lookup for old v1.4.3/v1.4.4 N/A rows and blank BP rows.
    ids = dict((entry or {}).get("ids") or {})
    for k, v in extract_ids(item or {}).items():
        if v not in (None, ""):
            ids.setdefault(str(k), str(v))
    provider_meta = dict((entry or {}).get("provider_meta") or {})
    errors = list((entry or {}).get("errors") or [])
    try:
        if bool_setting("use_mdblist", True) and keys.get("mdblist"):
            found_bp, bp_meta = mdblist_best_picture_lookup_1430(ids, "movie", keys.get("mdblist"))
            provider_meta["mdblist_best_picture"] = bp_meta
            if found_bp in ("1", METADATA_NA_VALUE):
                awards["oscar_best_picture"] = found_bp
                awards["updated_at"] = now_iso()
                entry["awards"] = awards
                entry["oscar_best_picture"] = found_bp
                entry["provider_meta"] = provider_meta
                _save_oscar_bp_status_1450(item, entry, found_bp)
            elif (bp_meta or {}).get("limited"):
                errors.append("mdblist_bp: API limit reached; oscar_best_picture left blank for retry")
            else:
                errors.append("mdblist_bp: no cacheable response; oscar_best_picture left blank for retry")
        else:
            errors.append("mdblist_bp: provider disabled or api key missing")
    except Exception as exc:  # pylint: disable=broad-except
        errors.append("mdblist_bp: {0}".format(exc))
    if errors:
        entry["errors"] = errors
    return entry


def _library_record_rows_for_external_1450(conn: sqlite3.Connection, item: Dict[str, Any]) -> List[sqlite3.Row]:
    media = media_setting_type((item or {}).get("type"))
    if media not in ("movie", "tvshow"):
        return []
    ids = extract_ids(item or {})
    imdb = _norm_imdb(ids.get("imdb") or (item or {}).get("imdbnumber") or (item or {}).get("imdb_id") or (item or {}).get("imdb"))
    tmdb = _norm_tmdb(ids.get("tmdb") or (item or {}).get("tmdb_id") or (item or {}).get("tmdb"))
    rows: List[sqlite3.Row] = []
    if imdb:
        rows.extend(conn.execute("SELECT * FROM ratings WHERE media_type=? AND imdb_id=?", (media, imdb)).fetchall())
    if tmdb:
        rows.extend(conn.execute("SELECT * FROM ratings WHERE media_type=? AND tmdb_id=?", (media, tmdb)).fetchall())
    if not rows:
        title = str((item or {}).get("title") or "").strip()
        year = safe_int((item or {}).get("year"))
        if title:
            candidates = conn.execute("SELECT * FROM ratings WHERE media_type=? AND title=?", (media, title)).fetchall()
            for row in candidates:
                ryear = safe_int(_row_value(row, "year"))
                if year is None or ryear is None or ryear == year:
                    rows.append(row)
    return rows


def find_library_record_for_external_1450(item: Dict[str, Any]) -> Dict[str, Any]:
    if not valid_library_item(item):
        return {}
    conn = _sqlite_connect()
    try:
        _ensure_current_cache_schema(conn)
        entries: List[Dict[str, Any]] = []
        seen = set()
        for row in _library_record_rows_for_external_1450(conn, item):
            key = str(_row_value(row, "item_key") or "")
            if key in seen:
                continue
            seen.add(key)
            entry = _ratings_only_row_to_entry(row)
            if context_matches_record(item, entry):
                entries.append(entry)
        return _choose_best_record(media_setting_type((item or {}).get("type")), entries, entries[0] if entries else None) if entries else {}
    except Exception as exc:
        log("Library external match failed: {0}".format(exc), xbmc.LOGWARNING)
        return {}
    finally:
        try:
            conn.close()
        except Exception:
            pass


def cleanup_external_duplicates_1450() -> int:
    """Remove external rows that now duplicate a real library row."""
    conn = _sqlite_connect()
    removed = 0
    try:
        _ensure_current_cache_schema(conn)
        rows = conn.execute("SELECT * FROM external_ratings").fetchall()
        for row in rows:
            item = {
                "type": _row_value(row, "media_type") or "movie",
                "title": _row_value(row, "title"),
                "year": _row_value(row, "year"),
                "imdbnumber": _row_value(row, "imdb_id"),
                "tmdb_id": _row_value(row, "tmdb_id"),
            }
            if _library_record_rows_for_external_1450(conn, item):
                key = str(_row_value(row, "item_key") or "")
                if key:
                    conn.execute("DELETE FROM external_ratings WHERE item_key=?", (key,))
                    removed += 1
        if removed:
            conn.commit()
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return removed




_af3_values_1450_base = af3_values

def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    values = _af3_values_1450_base(record)
    awards = (record or {}).get("awards") or {}
    if isinstance(awards, dict):
        bp = _normalize_oscar_bp_1430(awards.get("oscar_best_picture") or (record or {}).get("oscar_best_picture"))
        oscar_wins = safe_int(awards.get("oscar_wins"))
        if bp == "1":
            values["Oscar_BestPicture"] = "true"
            values["OscarBestPicture"] = "true"
            values["Oscar_BestPictureIcon"] = kpm_shared_icon_path_1513("oscars_bp.png")
            values["OscarBestPictureIcon"] = kpm_shared_icon_path_1513("oscars_bp.png")
            values["Oscar_Icon"] = kpm_shared_icon_path_1513("oscars_bp.png")
            values["OscarIcon"] = kpm_shared_icon_path_1513("oscars_bp.png")
        elif oscar_wins and oscar_wins > 0:
            # AF3 icon filename is plural: oscars.png
            values["Oscar_Icon"] = kpm_shared_icon_path_1513("oscars.png")
            values["OscarIcon"] = kpm_shared_icon_path_1513("oscars.png")
    return values

# -----------------------------------------------------------------------------
# v1.4.6 - clean-library safe cleanup + simpler Oscar BP state
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 30)



def _normalise_awards_bp_dependency_1460(entry: Dict[str, Any], media: Optional[str] = None) -> Dict[str, Any]:
    """If Oscar wins is N/A, Oscar Best Picture must also be N/A."""
    entry = dict(entry or {})
    media = media_setting_type(media or entry.get("type") or entry.get("media_type"))
    awards = dict(entry.get("awards") or {})
    if media == "tvshow":
        awards["oscar_wins"] = METADATA_NA_VALUE
        awards["oscar_best_picture"] = METADATA_NA_VALUE
    elif media == "movie":
        awards.setdefault("emmy_wins", METADATA_NA_VALUE)
        if _is_metadata_na(awards.get("oscar_wins") or entry.get("oscar_wins")):
            awards["oscar_best_picture"] = METADATA_NA_VALUE
    if awards:
        entry["awards"] = awards
        if "oscar_best_picture" in awards:
            entry["oscar_best_picture"] = awards.get("oscar_best_picture")
    return entry


_record_missing_awards_1460_base = record_missing_awards

def record_missing_awards(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    media = media_setting_type((item or {}).get("type") or (record or {}).get("type"))
    awards = (record or {}).get("awards") or {}
    if _awards_needs_fill(awards, media):
        return True
    if media == "movie":
        oscar_wins = awards.get("oscar_wins")
        bp = _normalize_oscar_bp_1430(awards.get("oscar_best_picture") or (record or {}).get("oscar_best_picture"))
        # Visible cleanup/backfill: Oscar count N/A means BP is also N/A.
        if _is_metadata_na(oscar_wins) and bp != METADATA_NA_VALUE:
            return True
        # Oscar winners need one MDBList BP lookup only while BP is blank.
        # Once BP is 1 or N/A, that column is final for missing mode.
        if _oscar_wins_positive_1430(awards) and not bp:
            return True
    return False


_resolve_awards_only_1460_base = _resolve_awards_only_1450_base if '_resolve_awards_only_1450_base' in globals() else resolve_awards_only

def resolve_awards_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    # Use the v1.4.3 awards implementation (OMDb counts + MDBList BP side-check)
    # and deliberately bypass the v1.4.5 oscar_bp_status repair wrapper.
    entry = _resolve_awards_only_1460_base(item, keys, existing)
    media = media_setting_type((item or {}).get("type") or (entry or {}).get("type"))
    return _normalise_awards_bp_dependency_1460(entry, media)


_ratings_only_row_to_entry_1460_base = _ratings_only_row_to_entry

def _ratings_only_row_to_entry(row: sqlite3.Row) -> Dict[str, Any]:
    entry = _ratings_only_row_to_entry_1460_base(row)
    return _normalise_awards_bp_dependency_1460(entry, entry.get("type") or entry.get("media_type"))


_simple_db_rating_values_1460_base = _simple_db_rating_values

def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    media = media_setting_type((entry or {}).get("type") or (entry or {}).get("media_type"))
    entry = _normalise_awards_bp_dependency_1460(entry, media)
    return _simple_db_rating_values_1460_base(entry, item_key)


def _current_kodi_library_keys_1460() -> Tuple[set, Dict[str, int]]:
    """Return current Kodi video-library item keys independent of LRS include settings."""
    keys = set()
    counts = {"movie": 0, "tvshow": 0, "episode": 0}
    try:
        movies = json_rpc("VideoLibrary.GetMovies", {"properties": ["title"]}).get("movies", []) or []
        for row in movies:
            dbid = safe_int((row or {}).get("movieid"))
            if dbid is not None:
                keys.add("movie|{0}".format(dbid)); counts["movie"] += 1
    except Exception as exc:
        log("Clean library: movie key snapshot failed: {0}".format(exc), xbmc.LOGWARNING)
    try:
        shows = json_rpc("VideoLibrary.GetTVShows", {"properties": ["title"]}).get("tvshows", []) or []
        for row in shows:
            dbid = safe_int((row or {}).get("tvshowid"))
            if dbid is not None:
                keys.add("tvshow|{0}".format(dbid)); counts["tvshow"] += 1
    except Exception as exc:
        log("Clean library: tvshow key snapshot failed: {0}".format(exc), xbmc.LOGWARNING)
    try:
        episodes = json_rpc("VideoLibrary.GetEpisodes", {"properties": ["title"]}).get("episodes", []) or []
        for row in episodes:
            dbid = safe_int((row or {}).get("episodeid"))
            if dbid is not None:
                keys.add("episode|{0}".format(dbid)); counts["episode"] += 1
    except Exception as exc:
        log("Clean library: episode key snapshot failed: {0}".format(exc), xbmc.LOGWARNING)
    return keys, counts


def clean_orphan_library_ratings_1460() -> Dict[str, Any]:
    """Delete rows from ratings whose Kodi DBID no longer exists after Clean Library.

    external_ratings is intentionally left alone because it is for non-library widgets.
    """
    current_keys, counts = _current_kodi_library_keys_1460()
    stats = {"removed": 0, "kept": 0, "checked": 0, "current": counts, "removed_items": []}
    if not current_keys:
        stats["error"] = "current_library_empty_or_unavailable"
        return stats
    conn = _sqlite_connect()
    try:
        if getattr(conn, "in_transaction", False):
            conn.commit()
        _ensure_current_cache_schema(conn)
        if getattr(conn, "in_transaction", False):
            conn.commit()
        rows = conn.execute("SELECT item_key,title,media_type,dbid FROM ratings").fetchall()
        for row in rows:
            key = str(_row_value(row, "item_key") or "")
            media = media_setting_type(_row_value(row, "media_type") or (key.split("|", 1)[0] if "|" in key else ""))
            dbid = safe_int(_row_value(row, "dbid") or (key.split("|", 1)[1] if "|" in key else ""))
            if media not in ("movie", "tvshow", "episode") or dbid is None:
                stats["kept"] += 1
                continue
            canonical = "{0}|{1}".format(media, dbid)
            stats["checked"] += 1
            if canonical not in current_keys:
                conn.execute("DELETE FROM ratings WHERE item_key=?", (key,))
                stats["removed"] += 1
                if len(stats["removed_items"]) < 50:
                    stats["removed_items"].append({"item_key": key, "title": _row_value(row, "title") or ""})
            else:
                stats["kept"] += 1
        if stats["removed"]:
            _db_set_meta(conn, "last_clean_library_at", now_iso())
            _db_set_meta(conn, "last_clean_library_removed", stats["removed"])
        conn.commit()
    except Exception as exc:
        try:
            conn.rollback()
        except Exception:
            pass
        stats["error"] = str(exc)
    finally:
        try:
            conn.close()
        except Exception:
            pass
    return stats


_af3_values_1460_base = af3_values

def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    record = _normalise_awards_bp_dependency_1460(record, (record or {}).get("type"))
    return _af3_values_1460_base(record)


_export_csv_1460_base = export_csv

def export_csv(cache: Dict[str, Any]) -> str:
    # Normalize cached award dependency before writing report.
    try:
        items = cache.get("items") or {}
        for key, row in list(items.items()):
            if isinstance(row, dict):
                items[key] = _normalise_awards_bp_dependency_1460(row, row.get("type"))
    except Exception:
        pass
    return _export_csv_1460_base(cache)


# -----------------------------------------------------------------------------
# v1.4.7 - pre-1.5 maintenance, status, provider health, AF3 integration helpers
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 31)
LRS_SCHEMA_VERSION = 1470
EXTERNAL_DEFAULT_TTL_DAYS_1470 = 30



def _metadata_snapshot_1470(conn: sqlite3.Connection) -> Dict[str, str]:
    out: Dict[str, str] = {}
    try:
        for row in conn.execute("SELECT key,value FROM metadata ORDER BY key").fetchall():
            out[str(row["key"])] = str(row["value"] if row["value"] is not None else "")
    except Exception:
        pass
    return out


def maintenance_summary_1470() -> Dict[str, Any]:
    conn = _sqlite_connect()
    try:
        _ensure_current_cache_schema(conn)
        def count(table: str, where: str = "", args: Tuple[Any, ...] = ()) -> int:
            try:
                q = "SELECT COUNT(*) FROM {0}".format(table) + ((" WHERE " + where) if where else "")
                return int(conn.execute(q, args).fetchone()[0] or 0)
            except Exception:
                return 0
        return {
            "ratings": count("ratings"),
            "external_ratings": count("external_ratings"),
            "external_expired": _external_expired_count_1470(conn),
            "rt_status_ok": count("ratings", "rottentomatoes_status='ok'"),
            "rt_status_na": count("ratings", "rottentomatoes_status='N/A'"),
            "top250_filled": count("ratings", "top250 IS NOT NULL AND top250!='' AND top250!='N/A' AND CAST(top250 AS INTEGER)>0"),
            "oscar_bp_winners": count("ratings", "oscar_best_picture='1'"),
            "schema": _metadata_snapshot_1470(conn),
        }
    finally:
        try: conn.close()
        except Exception: pass


def _external_expired_count_1470(conn: sqlite3.Connection, ttl_days: int = EXTERNAL_DEFAULT_TTL_DAYS_1470) -> int:
    cutoff = int(time.time()) - max(1, int(ttl_days or EXTERNAL_DEFAULT_TTL_DAYS_1470)) * 86400
    try:
        return int(conn.execute("SELECT COUNT(*) FROM external_ratings WHERE timestamp IS NOT NULL AND timestamp>0 AND timestamp<?", (cutoff,)).fetchone()[0] or 0)
    except Exception:
        return 0


def clean_expired_external_ratings_1470(ttl_days: int = EXTERNAL_DEFAULT_TTL_DAYS_1470) -> Dict[str, Any]:
    cutoff = int(time.time()) - max(1, int(ttl_days or EXTERNAL_DEFAULT_TTL_DAYS_1470)) * 86400
    conn = _sqlite_connect()
    stats = {"removed": 0, "ttl_days": int(ttl_days), "cutoff": cutoff, "error": ""}
    try:
        _ensure_current_cache_schema(conn)
        if getattr(conn, "in_transaction", False):
            conn.commit()
        before = int(conn.execute("SELECT COUNT(*) FROM external_ratings").fetchone()[0] or 0)
        conn.execute("DELETE FROM external_ratings WHERE timestamp IS NOT NULL AND timestamp>0 AND timestamp<?", (cutoff,))
        after = int(conn.execute("SELECT COUNT(*) FROM external_ratings").fetchone()[0] or 0)
        stats["removed"] = max(0, before - after)
        _db_set_meta(conn, "last_external_clean_at", now_iso())
        _db_set_meta(conn, "last_external_clean_removed", stats["removed"])
        conn.commit()
    except Exception as exc:
        try: conn.rollback()
        except Exception: pass
        stats["error"] = str(exc)
    finally:
        try: conn.close()
        except Exception: pass
    return stats


def vacuum_database_1470() -> Dict[str, Any]:
    stats = {"ok": False, "before_bytes": 0, "after_bytes": 0, "error": ""}
    try:
        if os.path.exists(CACHE_DB_FILE):
            stats["before_bytes"] = os.path.getsize(CACHE_DB_FILE)
        conn = _sqlite_connect()
        try:
            if getattr(conn, "in_transaction", False):
                conn.commit()
            conn.execute("VACUUM")
            _db_set_meta(conn, "last_vacuum_at", now_iso())
            conn.commit()
        finally:
            conn.close()
        if os.path.exists(CACHE_DB_FILE):
            stats["after_bytes"] = os.path.getsize(CACHE_DB_FILE)
        stats["ok"] = True
    except Exception as exc:
        stats["error"] = str(exc)
    return stats


def reset_rt_badge_status_1470(mode: str = "repairable") -> Dict[str, Any]:
    """Clear RT badge status so the RT badge phase can repair/re-scrape it.

    mode=repairable clears non-final error-ish statuses and blanks.
    mode=all clears every movie/tvshow RT badge slug/status.
    """
    mode = str(mode or "repairable").lower()
    conn = _sqlite_connect(); stats = {"updated": 0, "mode": mode, "error": ""}
    try:
        _ensure_current_cache_schema(conn)
        if mode == "all":
            cur = conn.execute("UPDATE ratings SET rottentomatoes_slug='', rottentomatoes_status='' WHERE media_type IN ('movie','tvshow')")
        else:
            final = ("ok", "N/A", "badge_not_found", "no_slug")
            cur = conn.execute("UPDATE ratings SET rottentomatoes_slug='', rottentomatoes_status='' WHERE media_type IN ('movie','tvshow') AND (rottentomatoes_status IS NULL OR rottentomatoes_status='' OR rottentomatoes_status NOT IN (?,?,?,?))", final)
        stats["updated"] = int(cur.rowcount if cur.rowcount is not None and cur.rowcount >= 0 else 0)
        _db_set_meta(conn, "last_reset_rt_badge_status_at", now_iso())
        _db_set_meta(conn, "last_reset_rt_badge_status_mode", mode)
        conn.commit()
    except Exception as exc:
        try: conn.rollback()
        except Exception: pass
        stats["error"] = str(exc)
    finally:
        try: conn.close()
        except Exception: pass
    return stats


def reset_imdb_top250_1470() -> Dict[str, Any]:
    conn = _sqlite_connect(); stats = {"updated": 0, "error": ""}
    try:
        _ensure_current_cache_schema(conn)
        cur = conn.execute("UPDATE ratings SET top250=NULL WHERE media_type IN ('movie','tvshow')")
        stats["updated"] = int(cur.rowcount if cur.rowcount is not None and cur.rowcount >= 0 else 0)
        _db_set_meta(conn, "last_reset_top250_at", now_iso())
        conn.commit()
    except Exception as exc:
        try: conn.rollback()
        except Exception: pass
        stats["error"] = str(exc)
    finally:
        try: conn.close()
        except Exception: pass
    return stats


def _provider_ok_row_1470(name: str, status: str, detail: str = "") -> Dict[str, str]:
    return {"provider": name, "status": status, "detail": detail}


def provider_health_check_1470(online: bool = True) -> Dict[str, Any]:
    keys = api_keys()
    rows: List[Dict[str, str]] = []
    # Key presence/shape first, then a tiny live probe where possible.
    mdblist_keys = _provider_key_list(keys.get("mdblist"))
    omdb_keys = _provider_key_list(keys.get("omdb"))
    tmdb_key = str(keys.get("tmdb") or "").strip()
    if not mdblist_keys:
        rows.append(_provider_ok_row_1470("MDBList", "MISSING", "No valid MDBList key"))
    elif online:
        try:
            found, meta = mdblist_lookup({"imdb": "tt0111161"}, "movie", keys.get("mdblist"))
            if meta.get("limited"):
                rows.append(_provider_ok_row_1470("MDBList", "LIMITED", meta.get("limit_message", "API limit")))
            elif found or meta.get("attempts"):
                rows.append(_provider_ok_row_1470("MDBList", "OK", "{0} key(s)".format(len(mdblist_keys))))
            else:
                rows.append(_provider_ok_row_1470("MDBList", "UNKNOWN", "No usable response"))
        except Exception as exc:
            rows.append(_provider_ok_row_1470("MDBList", "ERROR", str(exc)))
    else:
        rows.append(_provider_ok_row_1470("MDBList", "CONFIGURED", "{0} key(s)".format(len(mdblist_keys))))
    if not omdb_keys:
        rows.append(_provider_ok_row_1470("OMDb", "MISSING", "No valid OMDb key"))
    elif online:
        try:
            item = {"type": "movie", "title": "The Shawshank Redemption", "year": 1994, "imdbnumber": "tt0111161"}
            found, _ids, meta = omdb_lookup(item, {"imdb": "tt0111161"}, keys.get("omdb"))
            rows.append(_provider_ok_row_1470("OMDb", "OK" if found or meta.get("attempts") else "UNKNOWN", "{0} key(s)".format(len(omdb_keys))))
        except ProviderLimitReached as exc:
            rows.append(_provider_ok_row_1470("OMDb", "LIMITED", str(exc)))
        except Exception as exc:
            rows.append(_provider_ok_row_1470("OMDb", "ERROR", str(exc)))
    else:
        rows.append(_provider_ok_row_1470("OMDb", "CONFIGURED", "{0} key(s)".format(len(omdb_keys))))
    if not tmdb_key:
        rows.append(_provider_ok_row_1470("TMDb", "MISSING", "No TMDb key"))
    elif online:
        try:
            payload = tmdb_get("movie/278", tmdb_key, {"language": "en-US"})
            rows.append(_provider_ok_row_1470("TMDb", "OK" if payload.get("id") else "UNKNOWN", str(payload.get("title") or payload.get("status_message") or "")))
        except Exception as exc:
            rows.append(_provider_ok_row_1470("TMDb", "ERROR", str(exc)))
    else:
        rows.append(_provider_ok_row_1470("TMDb", "CONFIGURED", ""))
    try:
        movie_count = len(imdb_top250_ranks(False) or {})
        tv_count = len(imdb_top250_tv_ranks() or {})
        rows.append(_provider_ok_row_1470("IMDb Top 250", "OK" if movie_count or tv_count else "EMPTY", "movie={0}, tv={1}".format(movie_count, tv_count)))
    except Exception as exc:
        rows.append(_provider_ok_row_1470("IMDb Top 250", "ERROR", str(exc)))
    result = {"created_at": now_iso(), "online": bool(online), "providers": rows}
    try:
        path = os.path.join(DIAGNOSTICS_DIR, "provider-health.json")
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        _atomic_write_json(path, result)
        result["path"] = path
    except Exception:
        pass
    return result


def status_report_text_1470() -> str:
    state = background_job_state() or {}
    summary = _load_json(SUMMARY_FILE) or {}
    maint = maintenance_summary_1470()
    lines = []
    lines.append("Current status: {0}".format(state.get("status") or "idle"))
    if state.get("action"):
        lines.append("Current action: {0}".format(state.get("action")))
    if state.get("total"):
        lines.append("Progress: {0}/{1} ({2}%)".format(state.get("processed") or 0, state.get("total") or 0, state.get("percent") or 0))
        lines.append("Current: {0}".format(state.get("current") or "-"))
    lines.append("")
    lines.append("Last run:")
    if summary:
        for key in ("action", "status", "started_at", "finished_at", "items_total", "processed", "matched", "updated", "skipped", "failed", "online_lookups", "removed", "checked"):
            if key in summary and summary.get(key) not in (None, ""):
                lines.append("  {0}: {1}".format(key, summary.get(key)))
        phase = summary.get("phase_stats") or summary.get("phases") or {}
        if isinstance(phase, dict) and phase:
            lines.append("")
            lines.append("Phase breakdown:")
            for name, row in sorted(phase.items()):
                if isinstance(row, dict):
                    lines.append("  {0}: processed={1}, updated={2}, skipped={3}, failed={4}".format(name, row.get("processed", 0), row.get("updated", 0), row.get("skipped", 0), row.get("failed", 0)))
        if summary.get("report"):
            lines.append("  report: {0}".format(summary.get("report")))
    else:
        lines.append("  No completed run summary yet.")
    lines.append("")
    lines.append("Cache:")
    lines.append("  ratings: {0}".format(maint.get("ratings")))
    lines.append("  external ratings: {0} (expired: {1})".format(maint.get("external_ratings"), maint.get("external_expired")))
    lines.append("  RT ok: {0}, RT N/A: {1}".format(maint.get("rt_status_ok"), maint.get("rt_status_na")))
    lines.append("  Top250 filled: {0}".format(maint.get("top250_filled")))
    lines.append("  Oscar BP winners: {0}".format(maint.get("oscar_bp_winners")))
    schema = maint.get("schema") or {}
    if schema:
        lines.append("  schema_version: {0}".format(schema.get("schema_version") or "-"))
        if schema.get("last_clean_library_removed") not in (None, ""):
            lines.append("  last clean removed: {0}".format(schema.get("last_clean_library_removed")))
    return "\n".join(lines)


# External cache seed for newly added library items.
_resolve_item_1470_base = resolve_item

def resolve_item(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True, include_local: bool = True, ratings_only: bool = False) -> Dict[str, Any]:
    seed = existing
    try:
        if not seed and resolvable_library_item(item):
            ext = load_external_record_1430(item)
            if ext:
                seed = dict(ext)
                seed["dbid"] = item.get("dbid") or item.get("movieid") or item.get("tvshowid") or item.get("episodeid") or seed.get("dbid")
                seed["type"] = media_setting_type(item.get("type") or seed.get("type"))
                seed.setdefault("title", item.get("title") or seed.get("title"))
                seed.setdefault("year", item.get("year") or seed.get("year"))
    except Exception:
        seed = existing
    return _resolve_item_1470_base(item, keys, seed, missing_only=missing_only, include_local=include_local, ratings_only=ratings_only)


def af3_skin_1080i_path_1470() -> str:
    try:
        skin_id = xbmc.getSkinDir() or "skin.arctic.fuse.3"
    except Exception:
        skin_id = "skin.arctic.fuse.3"
    home = xbmcvfs.translatePath("special://home")
    return os.path.join(home, "addons", skin_id, "1080i")


def af3_integration_status_1470() -> Dict[str, Any]:
    base = af3_skin_1080i_path_1470()
    checks: Dict[str, Any] = {"skin_1080i": base, "files": {}, "ok": True}
    targets = {
        "Includes_Info.xml": ["LRS_Info_Meta_Ratings", "LibraryRatings.ListItem"],
        "Includes_Hubs.xml": ["LibraryRatings"],
        "screensaver-arctic-mirage.xml": ["LibraryRatings.Screensaver", "cropv2"],
    }
    for filename, markers in targets.items():
        path = os.path.join(base, filename)
        row = {"path": path, "exists": os.path.exists(path), "markers": {}}
        text = ""
        if row["exists"]:
            try:
                with open(path, "r", encoding="utf-8") as fh:
                    text = fh.read()
            except Exception:
                try:
                    with open(path, "r", encoding="utf-8-sig") as fh:
                        text = fh.read()
                except Exception:
                    text = ""
        for marker in markers:
            row["markers"][marker] = bool(marker in text)
        row["ok"] = bool(row["exists"] and all(row["markers"].values()))
        if not row["ok"]:
            checks["ok"] = False
        checks["files"][filename] = row
    return checks


def af3_integration_status_text_1470() -> str:
    status = af3_integration_status_1470()
    lines = ["AF3 integration status", "Skin 1080i: {0}".format(status.get("skin_1080i")), "Overall: {0}".format("OK" if status.get("ok") else "NEEDS PATCH/CHECK"), ""]
    for filename, row in (status.get("files") or {}).items():
        lines.append(filename + ": " + ("OK" if row.get("ok") else "NOT OK"))
        lines.append("  exists: {0}".format("YES" if row.get("exists") else "NO"))
        for marker, ok in (row.get("markers") or {}).items():
            lines.append("  {0}: {1}".format(marker, "YES" if ok else "NO"))
    return "\n".join(lines)


def run_af3_patch_tool_1470(mode: str = "status") -> Dict[str, Any]:
    """Run bundled r14 single-script patch from Kodi on Windows.

    The PowerShell script itself performs partial marker-based insert/remove and
    keeps full XML backups. This wrapper just feeds path + choice once.
    """
    mode = str(mode or "status").lower()
    choice = {"apply": "1", "patch": "1", "remove": "2", "restore": "2", "status": "3", "check": "3"}.get(mode, "3")
    script = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("path")), "resources", "tools", "PATCH-AF3-LRS-COMPLETE-SINGLE-SCRIPT.ps1")
    result = {"ok": False, "mode": mode, "script": script, "output": "", "error": ""}
    if not os.path.exists(script):
        result["error"] = "Bundled patch script not found"
        return result
    try:
        import subprocess  # pylint: disable=import-outside-toplevel
        skin = af3_skin_1080i_path_1470()
        input_text = "{0}\n{1}\n".format(skin, choice)
        proc = subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", script], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
        out, _ = proc.communicate(input_text, timeout=180)
        result["output"] = out[-12000:] if out else ""
        result["ok"] = proc.returncode == 0
        if proc.returncode != 0:
            result["error"] = "PowerShell exited {0}".format(proc.returncode)
    except Exception as exc:
        result["error"] = str(exc)
    return result


# Diagnostics v1.4.7: do not include rt-badge-sync-last scratch JSON anymore; include provider health.
def _diagnostic_candidates_1397() -> List[str]:
    paths: List[str] = []
    def add(path: Any) -> None:
        text = str(path or "").strip()
        if text and os.path.exists(text) and text not in paths:
            paths.append(text)
    for explicit in (CACHE_DB_FILE, os.path.join(PROFILE, "settings.xml"), REPORT_FILE, SUMMARY_FILE, BACKGROUND_STATE_FILE, BACKGROUND_REQUEST_FILE, BACKGROUND_CANCEL_FILE, BACKGROUND_FORCE_STOP_FILE, SAMPLE_CHECK_LOG_FILE, RT_BADGE_REPORT_FILE, RT_BADGE_SIMPLE_LOG_FILE, os.path.join(DIAGNOSTICS_DIR, "provider-health.json")):
        add(explicit)
    if os.path.isdir(DIAGNOSTICS_DIR):
        for name in os.listdir(DIAGNOSTICS_DIR):
            if name == "rt-badge-sync-last.json":
                continue
            if name.lower().endswith((".log", ".csv", ".json", ".db", ".xml", ".txt")):
                add(os.path.join(DIAGNOSTICS_DIR, name))
    for special in ("special://logpath", "special://home"):
        try:
            base = xbmcvfs.translatePath(special)
        except Exception:
            base = ""
        for filename in ("kodi.log", "kodi.old.log"):
            add(os.path.join(base, filename))
    return paths


# -----------------------------------------------------------------------------
# v1.4.8 - AF3 diagnostics/status fix + stricter external upcoming guard
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 32)
LRS_SCHEMA_VERSION = 1480



def _parse_lrs_date_1480(value: Any) -> Optional[datetime]:
    text = str(value or "").strip()
    if not text or text in ("0000-00-00", "0"):
        return None
    # Accept yyyy-mm-dd, yyyy/mm/dd, dd/mm/yyyy, and ISO datetime.
    text = text.split("T", 1)[0].strip()
    for fmt in ("%Y-%m-%d", "%Y/%m/%d", "%d/%m/%Y", "%m/%d/%Y", "%Y.%m.%d"):
        try:
            return datetime.strptime(text, fmt)
        except Exception:
            pass
    m = re.search(r"\b(19\d{2}|20\d{2})[-/.](\d{1,2})[-/.](\d{1,2})\b", text)
    if m:
        try:
            return datetime(int(m.group(1)), int(m.group(2)), int(m.group(3)))
        except Exception:
            return None
    return None


def _item_release_status_text_1480(item: Dict[str, Any]) -> str:
    keys = (
        "status", "release_status", "movie_status", "series_status", "tmdb_status",
        "ListItem.Status", "Property(status)", "Property(release_status)",
    )
    return " ".join(str((item or {}).get(k) or "") for k in keys).strip().lower()


def _item_release_date_1480(item: Dict[str, Any]) -> Optional[datetime]:
    keys = (
        "premiered", "release_date", "released", "aired", "firstaired", "date",
        "Premiered", "ReleaseDate", "FirstAired", "Aired", "Date",
    )
    for key in keys:
        parsed = _parse_lrs_date_1480((item or {}).get(key))
        if parsed:
            return parsed
    return None


def external_item_released_1430(item: Dict[str, Any]) -> bool:
    """Return whether a non-library widget item is safe to fetch externally.

    v1.4.8: do not rely only on year. TMDbHelper/AF3 widgets often expose
    release date or status for Upcoming items. Future dates and explicit upcoming
    statuses are blocked; released/post-production/returning/current items are allowed.
    If only a same-year value is available, allow it because many Popular widgets
    do not expose exact dates.
    """
    item = item or {}
    status = _item_release_status_text_1480(item)
    if any(word in status for word in ("upcoming", "planned", "rumored", "in production", "post production", "post-production", "announced")):
        # post-production/announced/planned/upcoming should not fetch ratings yet.
        return False
    release_date = _item_release_date_1480(item)
    if release_date is not None:
        today = datetime.now().replace(hour=0, minute=0, second=0, microsecond=0)
        if release_date > today:
            return False
        return True
    year = safe_int(item.get("year"))
    try:
        current_year = datetime.now().year
    except Exception:
        current_year = 0
    if year and current_year and year > current_year:
        return False
    return True


# Capture more identity/status/date from AF3/TMDbHelper list items so external
# upcoming filtering can be accurate.
def selected_library_item() -> Dict[str, Any]:
    raw_type = _info_label("ListItem.DBTYPE", "ListItem.DBType", "ListItem.Property(DBType)", "ListItem.Property(dbtype)", "ListItem.Property(type)")
    title = _info_label("ListItem.Title", "ListItem.Label", "ListItem.Property(title)")
    showtitle = _info_label("ListItem.TVShowTitle", "ListItem.ShowTitle", "ListItem.Property(tvshowtitle)", "ListItem.Property(showtitle)")
    season = _info_label("ListItem.Season", "ListItem.Property(season)")
    episode = _info_label("ListItem.Episode", "ListItem.Property(episode)")
    file_path = _info_label("ListItem.FilenameAndPath", "ListItem.FileNameAndPath", "ListItem.FileName", "ListItem.Path", "ListItem.FolderPath")
    parsed = _parse_videodb_identity(file_path)
    item = {
        "type": _infer_video_type(raw_type, title, showtitle, season, episode),
        "dbid": _info_label("ListItem.DBID", "ListItem.DBId", "ListItem.Property(dbid)", "ListItem.Property(DBID)"),
        "title": title,
        "showtitle": showtitle,
        "season": season,
        "episode": episode,
        "year": _info_label("ListItem.Year", "ListItem.Property(year)"),
        "premiered": _info_label("ListItem.Premiered", "ListItem.FirstAired", "ListItem.Property(premiered)", "ListItem.Property(release_date)", "ListItem.Property(firstaired)", "ListItem.Date"),
        "release_date": _info_label("ListItem.Property(release_date)", "ListItem.Property(released)", "ListItem.Property(ReleaseDate)"),
        "status": _info_label("ListItem.Property(status)", "ListItem.Property(release_status)", "ListItem.Status"),
        "imdbnumber": _info_label("ListItem.IMDBNumber", "ListItem.UniqueID(imdb)", "ListItem.Property(imdb_id)", "ListItem.Property(imdb)"),
        "tmdb_id": _info_label("ListItem.UniqueID(tmdb)", "ListItem.Property(tmdb_id)", "ListItem.Property(tmdbid)", "ListItem.Property(tmdb)"),
        "top250": _info_label("ListItem.Top250"),
        "file": file_path,
    }
    if parsed:
        item.update({k: v for k, v in parsed.items() if v not in (None, "")})
    return item


def lrs_active_item() -> Dict[str, Any]:
    imdb = _any_window_property(
        "LRS.Active.IMDb_ID", "LRS.Active.IMDbID", "LRS.Active.IMDbNumber",
        "LRS.Active.IMDBNumber", "LRS.Active.imdb_id",
    )
    tmdb = _any_window_property("LRS.Active.TMDb_ID", "LRS.Active.TMDbID", "LRS.Active.tmdb_id")
    return {
        "type": _clean_dbtype(_any_window_property("LRS.Active.DBTYPE", "LRS.Active.DBType", "LRS.Active.Type")),
        "dbid": _any_window_property("LRS.Active.DBID", "LRS.Active.DBId", "LRS.Active.dbid"),
        "title": _any_window_property("LRS.Active.Title", "LRS.Active.title", "LRS.Active.Label"),
        "showtitle": _any_window_property("LRS.Active.TVShowTitle", "LRS.Active.ShowTitle", "LRS.Active.tvshowtitle"),
        "season": _any_window_property("LRS.Active.Season", "LRS.Active.season"),
        "episode": _any_window_property("LRS.Active.Episode", "LRS.Active.episode"),
        "year": _any_window_property("LRS.Active.Year", "LRS.Active.year"),
        "premiered": _any_window_property("LRS.Active.Premiered", "LRS.Active.ReleaseDate", "LRS.Active.FirstAired"),
        "release_date": _any_window_property("LRS.Active.ReleaseDate", "LRS.Active.released", "LRS.Active.release_date"),
        "status": _any_window_property("LRS.Active.Status", "LRS.Active.release_status", "LRS.Active.tmdb_status"),
        "imdbnumber": imdb,
        "tmdb_id": tmdb,
        "top250": _any_window_property("LRS.Active.Top250"),
    }


def tmdbhelper_item() -> Dict[str, Any]:
    imdb = _any_window_property(
        "TMDbHelper.ListItem.IMDb_ID", "TMDbHelper.ListItem.IMDbID",
        "TMDbHelper.ListItem.IMDbNumber", "TMDbHelper.ListItem.IMDBNumber",
        "TMDbHelper.ListItem.imdb_id",
    )
    tmdb = _any_window_property("TMDbHelper.ListItem.TMDb_ID", "TMDbHelper.ListItem.TMDbID", "TMDbHelper.ListItem.tmdb_id")
    return {
        "type": _clean_dbtype(_any_window_property("TMDbHelper.ListItem.DBTYPE", "TMDbHelper.ListItem.DBType", "TMDbHelper.ListItem.Type", "TMDbHelper.ListItem.tmdb_type")),
        "dbid": _any_window_property("TMDbHelper.ListItem.DBID", "TMDbHelper.ListItem.DBId", "TMDbHelper.ListItem.dbid"),
        "title": _any_window_property("TMDbHelper.ListItem.Title", "TMDbHelper.ListItem.title", "TMDbHelper.ListItem.Label"),
        "showtitle": _any_window_property("TMDbHelper.ListItem.TVShowTitle", "TMDbHelper.ListItem.ShowTitle", "TMDbHelper.ListItem.tvshowtitle"),
        "season": _any_window_property("TMDbHelper.ListItem.Season", "TMDbHelper.ListItem.season"),
        "episode": _any_window_property("TMDbHelper.ListItem.Episode", "TMDbHelper.ListItem.episode"),
        "year": _any_window_property("TMDbHelper.ListItem.Year", "TMDbHelper.ListItem.year", "TMDbHelper.ListItem.ReleaseYear"),
        "premiered": _any_window_property("TMDbHelper.ListItem.Premiered", "TMDbHelper.ListItem.ReleaseDate", "TMDbHelper.ListItem.Released", "TMDbHelper.ListItem.FirstAired"),
        "release_date": _any_window_property("TMDbHelper.ListItem.ReleaseDate", "TMDbHelper.ListItem.released", "TMDbHelper.ListItem.release_date"),
        "status": _any_window_property("TMDbHelper.ListItem.Status", "TMDbHelper.ListItem.release_status", "TMDbHelper.ListItem.tmdb_status"),
        "imdbnumber": imdb,
        "tmdb_id": tmdb,
        "top250": _any_window_property("TMDbHelper.ListItem.Top250"),
    }


def container_item(container_id: int, offset: int = 0) -> Dict[str, Any]:
    def li(field: str) -> str:
        expression = "Container({0}).ListItem.{1}".format(container_id, field) if offset == 0 else "Container({0}).ListItem({1}).{2}".format(container_id, offset, field)
        try:
            return xbmc.getInfoLabel(expression).strip()
        except Exception:  # pylint: disable=broad-except
            return ""
    raw_type = li("DBTYPE") or li("DBType") or li("Property(DBType)") or li("Property(dbtype)") or li("Property(type)")
    title = li("Title") or li("Label") or li("Property(title)")
    showtitle = li("TVShowTitle") or li("ShowTitle") or li("Property(tvshowtitle)") or li("Property(showtitle)") or li("Property(tv_show_title)")
    season = li("Season") or li("Property(season)") or li("Property(tvshow.season)")
    episode = li("Episode") or li("Property(episode)") or li("Property(tvshow.episode)")
    file_path = li("FilenameAndPath") or li("FileNameAndPath") or li("FileName") or li("Path") or li("FolderPath")
    parsed = _parse_videodb_identity(file_path)
    item = {
        "type": _infer_video_type(raw_type, title, showtitle, season, episode),
        "dbid": li("DBID") or li("DBId") or li("Property(dbid)") or li("Property(DBID)"),
        "title": title,
        "showtitle": showtitle,
        "season": season,
        "episode": episode,
        "year": li("Year") or li("Property(year)") or li("Property(release_year)"),
        "premiered": li("Premiered") or li("FirstAired") or li("Property(premiered)") or li("Property(release_date)") or li("Property(firstaired)") or li("Date"),
        "release_date": li("Property(release_date)") or li("Property(released)") or li("Property(ReleaseDate)"),
        "status": li("Property(status)") or li("Property(release_status)") or li("Status") or li("Property(tmdb_status)"),
        "imdbnumber": li("IMDBNumber") or li("IMDbNumber") or li("UniqueID(imdb)") or li("Property(imdb_id)") or li("Property(imdb)"),
        "tmdb_id": li("UniqueID(tmdb)") or li("Property(tmdb_id)") or li("Property(tmdbid)") or li("Property(tmdb)"),
        "top250": li("Top250"),
        "file": file_path,
    }
    if parsed:
        item.update({k: v for k, v in parsed.items() if v not in (None, "")})
    return item


def af3_integration_status_1470() -> Dict[str, Any]:
    base = af3_skin_1080i_path_1470()
    checks: Dict[str, Any] = {"skin_1080i": base, "files": {}, "ok": True}
    targets = {
        "Includes_Info.xml": [
            "LRS_Info_Meta_Ratings",
            "LibraryRatings.ListItem",
            "LRS_ListItem_Oscar_Icon_Texture",
            kpm_shared_icon_path_1513("oscars_bp.png"),
        ],
        "Includes_Hubs.xml": [
            "LRS-AF3-ACTIVE-BRIDGE",
            "LRS.Active.ContainerID",
        ],
        "screensaver-arctic-mirage.xml": [
            "LibraryRatings.Screensaver",
            "ClearLogoFinal",
            "AFM-CLEARLOGO-FINAL-LRS",
            "LRS-OSCAR-BP-SCREENSAVER-START",
            kpm_shared_icon_path_1513("oscars_bp.png"),
        ],
    }
    for filename, markers in targets.items():
        path = os.path.join(base, filename)
        row = {"path": path, "exists": os.path.exists(path), "markers": {}}
        text = ""
        if row["exists"]:
            for enc in ("utf-8", "utf-8-sig"):
                try:
                    with open(path, "r", encoding=enc) as fh:
                        text = fh.read()
                    break
                except Exception:
                    text = ""
        for marker in markers:
            row["markers"][marker] = bool(marker in text)
        row["ok"] = bool(row["exists"] and all(row["markers"].values()))
        if not row["ok"]:
            checks["ok"] = False
        checks["files"][filename] = row
    return checks


def af3_integration_status_text_1470() -> str:
    status = af3_integration_status_1470()
    lines = ["AF3 integration status", "Skin 1080i: {0}".format(status.get("skin_1080i")), "Overall: {0}".format("OK" if status.get("ok") else "NEEDS PATCH/CHECK"), ""]
    for filename, row in (status.get("files") or {}).items():
        lines.append(filename + ": " + ("OK" if row.get("ok") else "NOT OK"))
        lines.append("  exists: {0}".format("YES" if row.get("exists") else "NO"))
        for marker, ok in (row.get("markers") or {}).items():
            lines.append("  {0}: {1}".format(marker, "YES" if ok else "NO"))
    return "\n".join(lines)


def _af3_xml_diagnostic_paths_1480() -> List[str]:
    base = af3_skin_1080i_path_1470()
    return [os.path.join(base, name) for name in ("Includes_Info.xml", "Includes_Hubs.xml", "screensaver-arctic-mirage.xml")]


def _diagnostic_candidates_1397() -> List[str]:
    paths: List[str] = []
    def add(path: Any) -> None:
        text = str(path or "").strip()
        if text and os.path.exists(text) and text not in paths:
            paths.append(text)
    for explicit in (CACHE_DB_FILE, os.path.join(PROFILE, "settings.xml"), REPORT_FILE, SUMMARY_FILE, BACKGROUND_STATE_FILE, BACKGROUND_REQUEST_FILE, BACKGROUND_CANCEL_FILE, BACKGROUND_FORCE_STOP_FILE, SAMPLE_CHECK_LOG_FILE, RT_BADGE_REPORT_FILE, RT_BADGE_SIMPLE_LOG_FILE, os.path.join(DIAGNOSTICS_DIR, "provider-health.json")):
        add(explicit)
    if os.path.isdir(DIAGNOSTICS_DIR):
        for name in os.listdir(DIAGNOSTICS_DIR):
            if name == "rt-badge-sync-last.json":
                continue
            if name.lower().endswith((".log", ".csv", ".json", ".db", ".xml", ".txt")):
                add(os.path.join(DIAGNOSTICS_DIR, name))
    for path in _af3_xml_diagnostic_paths_1480():
        add(path)
    for special in ("special://logpath", "special://home"):
        try:
            base = xbmcvfs.translatePath(special)
        except Exception:
            base = ""
        for filename in ("kodi.log", "kodi.old.log"):
            add(os.path.join(base, filename))
    return paths


def export_diagnostics_zip_1397() -> str:
    import zipfile  # pylint: disable=import-outside-toplevel
    os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    zip_path = os.path.join(DIAGNOSTICS_DIR, "lrs-diagnostics-{0}.zip".format(stamp))
    base_profile = os.path.abspath(PROFILE)
    af3_map = {os.path.abspath(p): "af3/" + os.path.basename(p) for p in _af3_xml_diagnostic_paths_1480()}
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        manifest = {"created_at": now_iso(), "addon_version": ADDON.getAddonInfo("version"), "files": []}
        for path in _diagnostic_candidates_1397():
            try:
                apath = os.path.abspath(path)
                if apath == os.path.abspath(zip_path):
                    continue
                if apath in af3_map:
                    arc = af3_map[apath]
                elif apath.startswith(base_profile):
                    arc = "profile/" + os.path.relpath(apath, base_profile).replace("\\", "/")
                else:
                    arc = "kodi/" + os.path.basename(apath)
                zf.write(apath, arc)
                manifest["files"].append({"source": apath, "archive": arc, "size": os.path.getsize(apath)})
            except Exception as exc:  # pylint: disable=broad-except
                manifest.setdefault("errors", []).append({"file": str(path), "error": str(exc)})
        zf.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True))
    return zip_path


# -----------------------------------------------------------------------------
# v1.4.9 - UI polish / schema metadata
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 32)
LRS_SCHEMA_VERSION = 1490



def _format_number_1490(value: Any) -> str:
    try:
        return "{:,}".format(int(value or 0))
    except Exception:
        return str(value or "0")


def _status_action_label_1490(action: str) -> str:
    action = str(action or "").strip().lower()
    return {
        "scrape": "Scrape missing data",
        "refresh": "Refresh all data",
        "awards": "Scrape awards only",
        "rtbadges": "Scrape missing Rotten Tomatoes badges",
        "top250": "Update IMDb Top 250",
        "auto_scrape_new_items": "Auto scrape new library items",
        "clean_library": "Clean removed library items",
    }.get(action, action or "-")


def status_report_text_1470() -> str:
    state = background_job_state() or {}
    summary = _load_json(SUMMARY_FILE) or {}
    maint = maintenance_summary_1470()
    lines = []
    lines.append("Current status: {0}".format(str(state.get("status") or "Idle").title()))
    if state.get("action"):
        lines.append("Current action: {0}".format(_status_action_label_1490(state.get("action"))))
    if state.get("total"):
        lines.append("Progress: {0}/{1} ({2}%)".format(_format_number_1490(state.get("processed") or 0), _format_number_1490(state.get("total") or 0), state.get("percent") or 0))
        lines.append("Current item: {0}".format(state.get("current") or "-"))
    lines.append("")
    lines.append("Last run")
    if summary:
        lines.append("Action: {0}".format(_status_action_label_1490(summary.get("action"))))
        if summary.get("status"):
            lines.append("Status: {0}".format(str(summary.get("status")).title()))
        if summary.get("started_at"):
            lines.append("Started: {0}".format(summary.get("started_at")))
        if summary.get("finished_at"):
            lines.append("Finished: {0}".format(summary.get("finished_at")))
        mapping = (("Items total", "items_total"), ("Processed", "processed"), ("Matched", "matched"), ("Updated items", "updated"), ("Skipped items", "skipped"), ("Failed items", "failed"), ("Online lookups", "online_lookups"), ("Removed items", "removed"), ("Checked items", "checked"))
        for label, key in mapping:
            if key in summary and summary.get(key) not in (None, ""):
                lines.append("{0}: {1}".format(label, _format_number_1490(summary.get(key))))
        phase = summary.get("phase_stats") or summary.get("phases") or {}
        if isinstance(phase, dict) and phase:
            lines.append("")
            lines.append("Phase breakdown")
            for name, row in sorted(phase.items()):
                if isinstance(row, dict):
                    lines.append("{0}: processed {1}, updated {2}, skipped {3}, failed {4}".format(str(name).title(), _format_number_1490(row.get("processed", 0)), _format_number_1490(row.get("updated", 0)), _format_number_1490(row.get("skipped", 0)), _format_number_1490(row.get("failed", 0))))
        if summary.get("report"):
            lines.append("Report: {0}".format(os.path.basename(str(summary.get("report")))))
    else:
        lines.append("No completed run summary yet.")
    lines.append("")
    lines.append("Cache")
    lines.append("Library ratings: {0}".format(_format_number_1490(maint.get("ratings"))))
    lines.append("External ratings: {0} (expired: {1})".format(_format_number_1490(maint.get("external_ratings")), _format_number_1490(maint.get("external_expired"))))
    lines.append("RT badge OK: {0}".format(_format_number_1490(maint.get("rt_status_ok"))))
    lines.append("RT badge N/A: {0}".format(_format_number_1490(maint.get("rt_status_na"))))
    lines.append("Top 250 filled: {0}".format(_format_number_1490(maint.get("top250_filled"))))
    lines.append("Oscar Best Picture winners: {0}".format(_format_number_1490(maint.get("oscar_bp_winners"))))
    schema = maint.get("schema") or {}
    if schema:
        lines.append("Schema version: {0}".format(schema.get("schema_version") or "-"))
        if schema.get("last_clean_library_removed") not in (None, ""):
            lines.append("Last clean removed: {0}".format(_format_number_1490(schema.get("last_clean_library_removed"))))
    return "\n".join(lines)

# -----------------------------------------------------------------------------
# v1.4.10 - Safe IMDb chart Top250 + AF3 icon folder from Kodi UI
# -----------------------------------------------------------------------------

IMDB_TOP250_MOVIE_CHART_URL_1410 = ""  # v1.4.13: disabled
IMDB_TOP250_TV_CHART_URL_1410 = ""  # v1.4.13: disabled
SCHEMA_VERSION_1410 = 1410


def sanitize_af3_icon_folder_1410(value: Any) -> str:
    text = str(value or "").strip().replace("\\", "/").split("/")[-1].strip()
    text = re.sub(r"[^A-Za-z0-9_.-]+", "", text)
    text = text.strip(". ")
    return text or "LRS_AF3"


def af3_icon_folder_1410() -> str:
    try:
        return sanitize_af3_icon_folder_1410(ADDON.getSetting("af3_icon_folder") or "LRS_AF3")
    except Exception:
        return "LRS_AF3"


def set_af3_icon_folder_1410(value: Any) -> str:
    folder = sanitize_af3_icon_folder_1410(value)
    try:
        ADDON.setSetting("af3_icon_folder", folder)
    except Exception:
        pass
    return folder


def _af3_skin_addon_path_1410() -> str:
    try:
        skin_id = xbmc.getSkinDir() or "skin.arctic.fuse.3"
    except Exception:
        skin_id = "skin.arctic.fuse.3"
    return os.path.join(xbmcvfs.translatePath("special://home"), "addons", skin_id)


def af3_icon_relative_1410(filename: str) -> str:
    return "{0}/{1}".format(af3_icon_folder_1410(), filename)


def _copy_file_if_possible_1410(src: str, dst: str) -> bool:
    try:
        if not src or not dst or not os.path.exists(src):
            return False
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        if os.path.abspath(src).lower() == os.path.abspath(dst).lower():
            return True
        try:
            import shutil  # pylint: disable=import-outside-toplevel
            shutil.copy2(src, dst)
            return True
        except Exception:
            data = None
            with open(src, "rb") as fh:
                data = fh.read()
            with open(dst, "wb") as fh:
                fh.write(data)
            return True
    except Exception as exc:  # pylint: disable=broad-except
        log("AF3 icon copy failed: {0} -> {1}: {2}".format(src, dst, exc), xbmc.LOGWARNING)
        return False


def kpm_shared_icon_dir_1513() -> str:
    try:
        return xbmcvfs.translatePath("special://home/addons/script.kodi.patch.manager/resources/media/shared-icons")
    except Exception:
        return ""


def kpm_shared_icon_path_1513(filename: str) -> str:
    base = kpm_shared_icon_dir_1513()
    return os.path.join(base, filename) if base else ""


def af3_prepare_icon_folder_1410(folder: Optional[str] = None) -> Dict[str, Any]:
    folder = sanitize_af3_icon_folder_1410(folder or af3_icon_folder_1410())
    skin_path = _af3_skin_addon_path_1410()
    ratings_root = os.path.join(skin_path, "media", "flags")
    result = {"folder": folder, "copied": 0, "created": 0, "paths": []}
    if not os.path.isdir(ratings_root):
        result["error"] = "AF3 flags folder not found"
        return result
    icon_names = ("oscars.png", "oscars_bp.png")
    try:
        for color in os.listdir(ratings_root):
            color_root = os.path.join(ratings_root, color, "ratings")
            if not os.path.isdir(color_root):
                continue
            target_dir = os.path.join(color_root, folder)
            if not os.path.isdir(target_dir):
                os.makedirs(target_dir, exist_ok=True)
                result["created"] += 1
            for icon in icon_names:
                dst = os.path.join(target_dir, icon)
                if os.path.exists(dst):
                    continue
                candidates = [
                    kpm_shared_icon_path_1513(icon),
                ]
                # Also look in any existing sibling LRS-like folder.
                try:
                    for sibling in os.listdir(color_root):
                        path = os.path.join(color_root, sibling, icon)
                        if os.path.isdir(os.path.join(color_root, sibling)) and path not in candidates:
                            candidates.append(path)
                except Exception:
                    pass
                for src in candidates:
                    if _copy_file_if_possible_1410(src, dst):
                        result["copied"] += 1
                        break
            result["paths"].append(target_dir)
    except Exception as exc:  # pylint: disable=broad-except
        result["error"] = str(exc)
    return result


def _read_text_file_1410(path: str) -> str:
    for enc in ("utf-8", "utf-8-sig"):
        try:
            with open(path, "r", encoding=enc) as fh:
                return fh.read()
        except Exception:
            continue
    return ""


def _write_text_file_1410(path: str, text: str) -> None:
    with open(path, "w", encoding="utf-8", newline="") as fh:
        fh.write(text)


def _backup_once_1410(path: str, suffix: str = ".lrs1410.bak") -> str:
    backup = path + suffix
    try:
        if os.path.exists(path) and not os.path.exists(backup):
            _copy_file_if_possible_1410(path, backup)
    except Exception:
        pass
    return backup


def af3_update_icon_folder_in_xml_1410(folder: Optional[str] = None) -> Dict[str, Any]:
    folder = sanitize_af3_icon_folder_1410(folder or af3_icon_folder_1410())
    set_af3_icon_folder_1410(folder)
    base = af3_skin_1080i_path_1470()
    result = {"folder": folder, "files_checked": 0, "files_updated": 0, "icons": af3_prepare_icon_folder_1410(folder)}
    targets = ["Includes_Info.xml", "Includes_Hubs.xml", "screensaver-arctic-mirage.xml"]
    # Replace only LRS award icon folders. Do not touch RT/MDb/TMDb/etc.
    pattern = re.compile(r"ratings/([A-Za-z0-9_.-]+)/((?:oscars|oscar|oscars_bp|oscar_bp)\.png)", re.I)
    prop_pattern = re.compile(r"(?<![A-Za-z0-9_.-])([A-Za-z0-9_.-]+)/((?:oscars|oscar|oscars_bp|oscar_bp)\.png)", re.I)
    for name in targets:
        path = os.path.join(base, name)
        if not os.path.exists(path):
            continue
        result["files_checked"] += 1
        old = _read_text_file_1410(path)
        if not old:
            continue
        new = pattern.sub(lambda m: "ratings/{0}/{1}".format(folder, m.group(2)), old)
        # Also update property default values like KPM shared-icons/oscars_bp.png, while
        # avoiding full flag paths already handled above.
        new = prop_pattern.sub(lambda m: "{0}/{1}".format(folder, m.group(2)) if m.group(1).upper().startswith("LRS") else m.group(0), new)
        if new != old:
            _backup_once_1410(path, ".lrs1410-iconfolder.bak")
            _write_text_file_1410(path, new)
            result["files_updated"] += 1
    return result


_af3_values_1410_base = af3_values

def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    values = _af3_values_1410_base(record)
    folder = af3_icon_folder_1410()
    # Normalize Oscar icon properties to the selected AF3 folder. This keeps
    # runtime properties aligned with XML after the user changes the folder name.
    bp = str(values.get("Oscar_BestPicture") or values.get("OscarBestPicture") or "").lower() == "true"
    if bp:
        icon = "{0}/oscars_bp.png".format(folder)
        values["Oscar_BestPictureIcon"] = icon
        values["OscarBestPictureIcon"] = icon
        values["Oscar_Icon"] = icon
        values["OscarIcon"] = icon
    elif values.get("Oscar_Icon") or values.get("OscarIcon"):
        icon = "{0}/oscars.png".format(folder)
        values["Oscar_Icon"] = icon
        values["OscarIcon"] = icon
    return values


_af3_integration_status_1470_base_1410 = af3_integration_status_1470

def af3_integration_status_1470() -> Dict[str, Any]:
    base = af3_skin_1080i_path_1470()
    folder = af3_icon_folder_1410()
    checks: Dict[str, Any] = {"skin_1080i": base, "icon_folder": folder, "files": {}, "ok": True}
    targets = {
        "Includes_Info.xml": ["LRS_Info_Meta_Ratings", "LibraryRatings.ListItem", "LRS_ListItem_Oscar_Icon_Texture", kpm_shared_icon_special_base_1515(folder) + "/oscars_bp.png"],
        "Includes_Hubs.xml": ["LRS-AF3-ACTIVE-BRIDGE", "LRS.Active.ContainerID"],
        "screensaver-arctic-mirage.xml": ["LibraryRatings.Screensaver", "ClearLogoFinal", "AFM-CLEARLOGO-FINAL-LRS", "LRS-OSCAR-BP-SCREENSAVER-START", kpm_shared_icon_special_base_1515(folder) + "/oscars_bp.png"],
    }
    for filename, markers in targets.items():
        path = os.path.join(base, filename)
        row = {"path": path, "exists": os.path.exists(path), "markers": {}}
        text = _read_text_file_1410(path) if row["exists"] else ""
        for marker in markers:
            row["markers"][marker] = bool(marker in text)
        row["ok"] = bool(row["exists"] and all(row["markers"].values()))
        if not row["ok"]:
            checks["ok"] = False
        checks["files"][filename] = row
    return checks


def af3_integration_status_text_1470() -> str:
    status = af3_integration_status_1470()
    lines = [
        "AF3 integration status",
        "Skin 1080i: {0}".format(status.get("skin_1080i")),
        "Icon folder: {0}".format(status.get("icon_folder") or af3_icon_folder_1410()),
        "Overall: {0}".format("OK" if status.get("ok") else "NEEDS PATCH/CHECK"),
        "",
    ]
    for filename, row in (status.get("files") or {}).items():
        lines.append(filename + ": " + ("OK" if row.get("ok") else "NOT OK"))
        lines.append("  exists: {0}".format("YES" if row.get("exists") else "NO"))
        for marker, ok in (row.get("markers") or {}).items():
            lines.append("  {0}: {1}".format(marker, "YES" if ok else "NO"))
    return "\n".join(lines)


def _run_af3_powershell_hidden_1410(mode: str = "status") -> Dict[str, Any]:
    mode = str(mode or "status").lower()
    choice = {"apply": "1", "patch": "1", "remove": "2", "restore": "2", "status": "3", "check": "3"}.get(mode, "3")
    script = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("path")), "resources", "tools", "PATCH-AF3-LRS-COMPLETE-SINGLE-SCRIPT.ps1")
    result = {"ok": False, "mode": mode, "script": script, "output": "", "error": ""}
    if not os.path.exists(script):
        result["error"] = "Bundled patch script not found"
        return result
    try:
        import subprocess  # pylint: disable=import-outside-toplevel
        skin = af3_skin_1080i_path_1470()
        input_text = "{0}\n{1}\n".format(skin, choice)
        kwargs = {"stdin": subprocess.PIPE, "stdout": subprocess.PIPE, "stderr": subprocess.STDOUT, "text": True}
        if os.name == "nt":
            kwargs["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        proc = subprocess.Popen(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-WindowStyle", "Hidden", "-File", script], **kwargs)
        out, _ = proc.communicate(input_text, timeout=180)
        result["output"] = out[-12000:] if out else ""
        result["ok"] = proc.returncode == 0
        if proc.returncode != 0:
            result["error"] = "PowerShell exited {0}".format(proc.returncode)
    except Exception as exc:  # pylint: disable=broad-except
        result["error"] = str(exc)
    return result


def run_af3_patch_tool_1470(mode: str = "status") -> Dict[str, Any]:
    """Apply/check/remove AF3 integration from Kodi without showing a console window.

    If existing LRS markers are present, Kodi Python updates XML/icon-folder paths
    directly. If full patch markers are missing, the bundled PowerShell patch is
    used as a hidden fallback, then Kodi Python normalizes the selected icon
    folder path.
    """
    mode = str(mode or "status").lower()
    if mode in ("status", "check"):
        return {"ok": bool(af3_integration_status_1470().get("ok")), "mode": mode, "output": af3_integration_status_text_1470(), "error": ""}
    if mode in ("apply", "patch"):
        status_before = af3_integration_status_1470()
        used_fallback = False
        out = []
        # If core integration markers are absent/incomplete, use the bundled
        # patcher silently. A custom icon-folder mismatch alone is fixed directly
        # by Kodi Python below.
        try:
            base_path = af3_skin_1080i_path_1470()
            info_text = _read_text_file_1410(os.path.join(base_path, "Includes_Info.xml"))
            hubs_text = _read_text_file_1410(os.path.join(base_path, "Includes_Hubs.xml"))
            ss_text = _read_text_file_1410(os.path.join(base_path, "screensaver-arctic-mirage.xml"))
            need_fallback = not ("LibraryRatings.ListItem" in info_text and "LRS-AF3-ACTIVE-BRIDGE" in hubs_text and "LibraryRatings.Screensaver" in ss_text)
        except Exception:
            need_fallback = True
        if need_fallback:
            ps = _run_af3_powershell_hidden_1410("apply")
            used_fallback = True
            out.append((ps.get("output") or ps.get("error") or "PowerShell fallback completed.").strip())
            if not ps.get("ok"):
                return {"ok": False, "mode": mode, "output": "\n".join(out), "error": ps.get("error") or "AF3 fallback patch failed"}
        icon_result = af3_update_icon_folder_in_xml_1410()
        status_after = af3_integration_status_1470()
        out.append("AF3 integration updated.")
        out.append("Icon folder: {0}".format(af3_icon_folder_1410()))
        out.append("XML files updated: {0}".format(icon_result.get("files_updated", 0)))
        icons = icon_result.get("icons") or {}
        out.append("KPM icons copied: {0} file copy operations into {1} folder(s)".format(icons.get("copied", 0), len(icons.get("targets") or [])))
        if used_fallback:
            out.append("Full patch fallback: used silently")
        return {"ok": bool(status_after.get("ok")), "mode": mode, "output": "\n".join([x for x in out if x]), "error": "" if status_after.get("ok") else "AF3 status still needs check"}
    if mode in ("remove", "restore"):
        return _run_af3_powershell_hidden_1410("remove")
    return {"ok": False, "mode": mode, "output": "", "error": "Unknown AF3 patch mode"}


# Safe chart cache helpers. Stored in metadata so no separate static TV DB is
# required for live web rebuilds.
def _top250_chart_meta_key_1410(media_type: str) -> str:
    return "top250_chart_{0}_json".format(media_setting_type(media_type))


def _load_top250_chart_from_meta_1410(media_type: str) -> Dict[str, int]:
    key = _top250_chart_meta_key_1410(media_type)
    try:
        with _sqlite_connect() as conn:
            text = _db_get_meta(conn, key, "{}") or "{}"
        parsed = json.loads(text)
        if isinstance(parsed, dict):
            return {str(k).lower(): int(v) for k, v in parsed.items() if re.fullmatch(r"tt\d+", str(k).lower()) and safe_int(v)}
    except Exception:
        pass
    return {}


def _save_top250_chart_to_meta_1410(media_type: str, ranks: Dict[str, int]) -> None:
    media_type = media_setting_type(media_type)
    serializable = {str(k).lower(): int(v) for k, v in (ranks or {}).items() if re.fullmatch(r"tt\d+", str(k).lower()) and safe_int(v)}
    with _sqlite_connect() as conn:
        _db_set_meta(conn, _top250_chart_meta_key_1410(media_type), json.dumps(serializable, sort_keys=True))
        _db_set_meta(conn, "top250_chart_{0}_updated_at".format(media_type), now_iso())
        _db_set_meta(conn, "top250_chart_{0}_count".format(media_type), len(serializable))
        _db_set_meta(conn, "top250_source", "Bundled Top250 database")
        conn.commit()


def _fetch_imdb_chart_ranks_1410(media_type: str) -> Dict[str, int]:
    media_type = media_setting_type(media_type)
    url = IMDB_TOP250_TV_CHART_URL_1410 if media_type == "tvshow" else IMDB_TOP250_MOVIE_CHART_URL_1410
    html = http_text(url)
    ranks = _parse_imdb_top250(html)
    # The parser returns rank by order/id. Validate hard before caller writes DB.
    if len(ranks) < 200:
        raise RuntimeError("{0} chart returned only {1} valid titles".format("TV" if media_type == "tvshow" else "Movie", len(ranks)))
    return dict(sorted(ranks.items(), key=lambda pair: int(pair[1]))[:250])


def imdb_top250_ranks(force_refresh: bool = False) -> Dict[str, int]:
    if force_refresh:
        ranks = _fetch_imdb_chart_ranks_1410("movie")
        _save_top250_chart_to_meta_1410("movie", ranks)
        return ranks
    ranks = _load_top250_chart_from_meta_1410("movie")
    return ranks or _load_local_top250_ranks("movie")


def imdb_top250_tv_ranks() -> Dict[str, int]:
    ranks = _load_top250_chart_from_meta_1410("tvshow")
    return ranks or _load_local_top250_ranks("tvshow")


def record_missing_top250(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    # Top250 is now handled by the single "Update IMDb Top 250" chart rebuild
    # workflow. Missing-only ratings scrape must not loop through thousands of
    # items just because Top250 was reset/blank.
    return False


_record_needs_update_1410_base = record_needs_update

def record_needs_update(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if not record:
        return True
    # Run the existing checks, but ignore the old Top250-only missing trigger.
    try:
        if _record_needs_update_1410_base(item, record):
            # If the only missing part is Top250, do not treat it as a scrape job.
            # Approximate by checking all non-Top250 missing categories directly.
            if record_missing_awards(item, record):
                return True
            if record_missing_rt_badge(item, record):
                return True
            media_type = media_setting_type((item or {}).get("type") or (record or {}).get("type"))
            ratings = preserve_ratings_for_item(media_type, (record or {}).get("ratings") or {})
            wanted = [x for x in RATING_LOGICALS_BY_TYPE.get(media_type, set()) if x != "top250" and rating_enabled(media_type, x, True)]
            for logical in wanted:
                # Accept either old nested ratings or final flat DB fields.
                if logical in ratings and not _is_rating_missing_value(ratings.get(logical)):
                    continue
                if logical == "rt_critic" and not _is_rating_missing_value((record or {}).get("rottentomatoes")):
                    continue
                if logical == "rt_audience" and not _is_rating_missing_value((record or {}).get("rottentomatoes_user")):
                    continue
                if logical == "imdb" and not _is_rating_missing_value((record or {}).get("imdb")):
                    continue
                if logical == "tmdb" and not _is_rating_missing_value((record or {}).get("tmdb")):
                    continue
                if logical == "metacritic" and not _is_rating_missing_value((record or {}).get("metacritic")):
                    continue
                if logical == "trakt" and not _is_rating_missing_value((record or {}).get("trakt")):
                    continue
                return True
            return False
    except Exception:
        return _record_needs_update_1410_base(item, record)
    return False


def sync_imdb_top250_to_library(force_chart_refresh: bool = False, progress: Any = None) -> Dict[str, int]:
    movie_enabled = rating_enabled("movie", "top250", True) and bool_setting("include_movies", True)
    tv_enabled = rating_enabled("tvshow", "top250", True) and bool_setting("include_tvshows", True)
    stats = {"movies": 0, "movie_matched": 0, "movie_updated": 0, "movie_missing_imdb": 0, "movie_chart_items": 0, "tvshows": 0, "tv_matched": 0, "tv_updated": 0, "tv_missing_imdb": 0, "tv_chart_items": 0, "updated": 0, "matched": 0, "total": 0, "processed": 0, "source": "imdb_chart_pages"}
    if progress is not None:
        try: progress.update(5, "Library Ratings Scraper", "1/5 FETCHING MOVIE CHART - TOP250")
        except TypeError: progress.update(5, "1/5 FETCHING MOVIE CHART - TOP250")
    movie_ranks = {}
    tv_ranks = {}
    if movie_enabled:
        movie_ranks = imdb_top250_ranks(True) if force_chart_refresh else imdb_top250_ranks(False)
    if progress is not None:
        try: progress.update(25, "Library Ratings Scraper", "2/5 FETCHING TV CHART - TOP250")
        except TypeError: progress.update(25, "2/5 FETCHING TV CHART - TOP250")
    if tv_enabled:
        if force_chart_refresh:
            tv_ranks = _fetch_imdb_chart_ranks_1410("tvshow")
            _save_top250_chart_to_meta_1410("tvshow", tv_ranks)
        else:
            tv_ranks = imdb_top250_tv_ranks()
    stats["movie_chart_items"] = len(movie_ranks)
    stats["tv_chart_items"] = len(tv_ranks)
    if force_chart_refresh:
        if movie_enabled and len(movie_ranks) < 200:
            raise RuntimeError("Movie chart validation failed")
        if tv_enabled and len(tv_ranks) < 200:
            raise RuntimeError("TV chart validation failed")
    if progress is not None:
        try: progress.update(55, "Library Ratings Scraper", "3/5 VALIDATING DATA - TOP250")
        except TypeError: progress.update(55, "3/5 VALIDATING DATA - TOP250")
    movies = json_rpc("VideoLibrary.GetMovies", {"properties": ["title", "year", "imdbnumber", "uniqueid", "top250"]}).get("movies", []) or [] if movie_enabled else []
    shows = json_rpc("VideoLibrary.GetTVShows", {"properties": ["title", "year", "imdbnumber", "uniqueid"]}).get("tvshows", []) or [] if tv_enabled else []
    stats["movies"] = len(movies)
    stats["tvshows"] = len(shows)
    total = len(movies) + len(shows)
    done = 0
    with _sqlite_connect() as conn:
        if progress is not None:
            try: progress.update(70, "Library Ratings Scraper", "4/5 UPDATING LIBRARY - TOP250")
            except TypeError: progress.update(70, "4/5 UPDATING LIBRARY - TOP250")
        for movie in movies:
            done += 1
            if progress is not None and done % 50 == 0:
                pct = 70 + int(done * 25 / max(1, total))
                try: progress.update(pct, "Library Ratings Scraper", "{0}/{1} UPDATING LIBRARY - TOP250".format(done, total))
                except TypeError: progress.update(pct, "{0}/{1} UPDATING LIBRARY - TOP250".format(done, total))
            imdb_id = _json_item_imdb_id(movie)
            value = int(movie_ranks.get(imdb_id)) if imdb_id and imdb_id in movie_ranks else METADATA_NA_VALUE
            if not imdb_id:
                stats["movie_missing_imdb"] += 1
            elif value != METADATA_NA_VALUE:
                stats["movie_matched"] += 1
            if _upsert_top250_row(conn, "movie", movie.get("movieid"), movie, value):
                stats["movie_updated"] += 1
        for show in shows:
            done += 1
            if progress is not None and done % 50 == 0:
                pct = 70 + int(done * 25 / max(1, total))
                try: progress.update(pct, "Library Ratings Scraper", "{0}/{1} UPDATING LIBRARY - TOP250".format(done, total))
                except TypeError: progress.update(pct, "{0}/{1} UPDATING LIBRARY - TOP250".format(done, total))
            imdb_id = _json_item_imdb_id(show)
            value = int(tv_ranks.get(imdb_id)) if imdb_id and imdb_id in tv_ranks else METADATA_NA_VALUE
            if not imdb_id:
                stats["tv_missing_imdb"] += 1
            elif value != METADATA_NA_VALUE:
                stats["tv_matched"] += 1
            if _upsert_top250_row(conn, "tvshow", show.get("tvshowid"), show, value):
                stats["tv_updated"] += 1
        _db_set_meta(conn, "top250_source", "Bundled Top250 database")
        _db_set_meta(conn, "top250_chart_sync_at", now_iso())
        conn.commit()
    stats["updated"] = int(stats.get("movie_updated") or 0) + int(stats.get("tv_updated") or 0)
    stats["matched"] = int(stats.get("movie_matched") or 0) + int(stats.get("tv_matched") or 0)
    stats["total"] = total
    stats["processed"] = total
    if progress is not None:
        try: progress.update(100, "Library Ratings Scraper", "5/5 COMPLETE - TOP250")
        except TypeError: progress.update(100, "5/5 COMPLETE - TOP250")
    return stats


# Ensure current schema metadata reflects the 1.4.10 behavior without requiring a
# destructive schema rewriting.

# Helper used by the 1.4.10 missing-only filter. Kept last deliberately:
# Python resolves this global at call time.
def _is_rating_missing_value(value: Any) -> bool:
    if value in (None, ""):
        return True
    text = str(value).strip()
    if text == "":
        return True
    if text.upper() in ("N/A", "NA", "NONE", "NULL"):
        return True
    if _is_metadata_na(value):
        return True
    return False

# -----------------------------------------------------------------------------
# v1.4.11 - AF3 icon folder path complete fix
# -----------------------------------------------------------------------------

SCHEMA_VERSION_1410 = 1411

_AF3_RATING_PATH_PREFIX_1411 = "flags/$VAR[Color_Directory]/ratings/"
_AF3_RATING_PATH_RE_1411 = re.compile(r"flags/\$VAR\[Color_Directory\]/ratings/([^<\"'\s]+)")
_AF3_PROP_ICON_RE_1411 = re.compile(r"(?<![A-Za-z0-9_.-])([A-Za-z0-9_.-]+)/((?:oscars|oscar|oscars_bp|oscar_bp)\.png)", re.I)


def _af3_normalize_icon_token_1411(token: str, folder: str) -> str:
    token = str(token or "").strip()
    folder = sanitize_af3_icon_folder_1410(folder)
    if not token:
        return token
    # Existing folder form, e.g. KPM shared-icons/oscars.png, 1/oscars.png,
    # LRSxAF3/$INFO[...] -> replace only the first folder segment.
    if "/" in token:
        first, rest = token.split("/", 1)
        # If first segment is already a folder name, replace it. Keep variables or
        # direct filenames intact as the real icon token.
        if first and not first.lower().endswith(".png") and not first.startswith("$"):
            token = rest
    return "{0}{1}/{2}".format(_AF3_RATING_PATH_PREFIX_1411, folder, token)


def _af3_rewrite_rating_icon_paths_1411(text: str, folder: str) -> Tuple[str, int]:
    folder = sanitize_af3_icon_folder_1410(folder)
    count = 0

    def repl(match: Any) -> str:
        nonlocal count
        old = match.group(0)
        token = match.group(1)
        new = _af3_normalize_icon_token_1411(token, folder)
        if new != old:
            count += 1
        return new

    new = _AF3_RATING_PATH_RE_1411.sub(repl, text or "")

    # Update standalone property default values like KPM shared-icons/oscars_bp.png.
    # This intentionally avoids full flags/... paths already handled above.
    def prop_repl(match: Any) -> str:
        nonlocal count
        first = match.group(1)
        file_name = match.group(2)
        if first.upper().startswith("LRS") or first == folder:
            replacement = "{0}/{1}".format(folder, file_name)
            if replacement != match.group(0):
                count += 1
            return replacement
        return match.group(0)

    new2 = _AF3_PROP_ICON_RE_1411.sub(prop_repl, new)
    return new2, count


def _af3_count_root_rating_icon_refs_1411(text: str, folder: str) -> int:
    folder = sanitize_af3_icon_folder_1410(folder)
    total = 0
    for match in _AF3_RATING_PATH_RE_1411.finditer(text or ""):
        token = match.group(1)
        if not token.startswith(folder + "/"):
            total += 1
    return total


def af3_copy_kpm_shared_icons_1514(folder: Optional[str] = None) -> Dict[str, Any]:
    """Copy every PNG from KPM shared-icons into AF3 ratings/<folder> folders.

    KPM is the only canonical icon source. There is no local LRS fallback and no
    compatible filename aliasing.
    """
    folder = sanitize_af3_icon_folder_1410(folder or af3_icon_folder_1410())
    skin_path = _af3_skin_addon_path_1410()
    ratings_root = os.path.join(skin_path, "media", "flags")
    src_dir = kpm_shared_icon_dir_1513()
    result: Dict[str, Any] = {"folder": folder, "source": src_dir, "copied": 0, "created": 0, "files": [], "targets": [], "missing_source": False}
    if not src_dir or not os.path.isdir(src_dir):
        result["missing_source"] = True
        result["error"] = "KPM shared icon folder not found"
        return result
    if not os.path.isdir(ratings_root):
        result["error"] = "AF3 flags folder not found"
        return result
    icon_names = sorted([name for name in os.listdir(src_dir) if name.lower().endswith(".png")])
    result["files"] = icon_names
    try:
        for color in os.listdir(ratings_root):
            color_root = os.path.join(ratings_root, color, "ratings")
            if not os.path.isdir(color_root):
                continue
            target_dir = os.path.join(color_root, folder)
            if not os.path.isdir(target_dir):
                os.makedirs(target_dir, exist_ok=True)
                result["created"] += 1
            for icon in icon_names:
                src = os.path.join(src_dir, icon)
                dst = os.path.join(target_dir, icon)
                if _copy_file_if_possible_1410(src, dst):
                    result["copied"] += 1
            result["targets"].append(target_dir)
    except Exception as exc:  # pylint: disable=broad-except
        result["error"] = str(exc)
    return result


def af3_prepare_icon_folder_1410(folder: Optional[str] = None) -> Dict[str, Any]:
    """Prepare AF3 icon folder by copying all KPM shared icons.

    v1.5.14 policy: KPM shared-icons is the only source. LRS does not use local
    fallback icons and does not synthesize compatibility aliases.
    """
    return af3_copy_kpm_shared_icons_1514(folder)


def af3_update_icon_folder_in_xml_1410(folder: Optional[str] = None) -> Dict[str, Any]:
    """Rewrite AF3 XML icon paths and copy every KPM shared icon to the selected folder."""
    folder = sanitize_af3_icon_folder_1410(folder or af3_icon_folder_1410())
    set_af3_icon_folder_1410(folder)
    base = af3_skin_1080i_path_1470()
    icon_copy = af3_prepare_icon_folder_1410(folder)
    result: Dict[str, Any] = {
        "folder": folder,
        "files_checked": 0,
        "files_updated": 0,
        "references_updated": 0,
        "root_references_remaining": 0,
        "icons": icon_copy,
        "files": {},
    }
    targets = ["Includes_Info.xml", "screensaver-arctic-mirage.xml", "Includes_Hubs.xml"]
    for name in targets:
        path = os.path.join(base, name)
        row: Dict[str, Any] = {"path": path, "exists": os.path.exists(path), "updated": False, "references_updated": 0, "root_references_remaining": 0}
        if not row["exists"]:
            result["files"][name] = row
            continue
        result["files_checked"] += 1
        old = _read_text_file_1410(path)
        if not old:
            result["files"][name] = row
            continue
        new, ref_count = _af3_rewrite_rating_icon_paths_1411(old, folder)
        row["references_updated"] = ref_count
        result["references_updated"] += ref_count
        if new != old:
            _backup_once_1410(path, ".lrs1514-iconfolder.bak")
            _write_text_file_1410(path, new)
            row["updated"] = True
            result["files_updated"] += 1
        row["root_references_remaining"] = _af3_count_root_rating_icon_refs_1411(new, folder)
        result["root_references_remaining"] += int(row.get("root_rating_icon_refs") or row.get("root_references_remaining") or 0)
        result["files"][name] = row
    return result

def af3_integration_status_1470() -> Dict[str, Any]:
    base = af3_skin_1080i_path_1470()
    folder = af3_icon_folder_1410()
    checks: Dict[str, Any] = {"skin_1080i": base, "icon_folder": folder, "files": {}, "ok": True}
    targets = {
        "Includes_Info.xml": ["LRS_Info_Meta_Ratings", "LibraryRatings.ListItem", "LRS_ListItem_Oscar_Icon_Texture", "ratings/{0}/".format(folder)],
        "Includes_Hubs.xml": ["LRS-AF3-ACTIVE-BRIDGE", "LRS.Active.ContainerID"],
        "screensaver-arctic-mirage.xml": ["LibraryRatings.Screensaver", "ClearLogoFinal", "AFM-CLEARLOGO-FINAL-LRS", "LRS-OSCAR-BP-SCREENSAVER-START", "ratings/{0}/".format(folder)],
    }
    for filename, markers in targets.items():
        path = os.path.join(base, filename)
        row = {"path": path, "exists": os.path.exists(path), "markers": {}, "root_rating_icon_refs": 0}
        text = _read_text_file_1410(path) if row["exists"] else ""
        for marker in markers:
            row["markers"][marker] = bool(marker in text)
        if filename in ("Includes_Info.xml", "screensaver-arctic-mirage.xml"):
            row["root_rating_icon_refs"] = _af3_count_root_rating_icon_refs_1411(text, folder)
        row["ok"] = bool(row["exists"] and all(row["markers"].values()) and int(row.get("root_rating_icon_refs") or 0) == 0)
        if not row["ok"]:
            checks["ok"] = False
        checks["files"][filename] = row
    return checks


def af3_integration_status_text_1470() -> str:
    status = af3_integration_status_1470()
    lines = [
        "AF3 integration status",
        "Skin 1080i: {0}".format(status.get("skin_1080i")),
        "Icon folder: {0}".format(status.get("icon_folder") or af3_icon_folder_1410()),
        "Overall: {0}".format("OK" if status.get("ok") else "NEEDS PATCH/CHECK"),
        "",
    ]
    for filename, row in (status.get("files") or {}).items():
        lines.append(filename + ": " + ("OK" if row.get("ok") else "NOT OK"))
        lines.append("  exists: {0}".format("YES" if row.get("exists") else "NO"))
        for marker, ok in (row.get("markers") or {}).items():
            lines.append("  {0}: {1}".format(marker, "YES" if ok else "NO"))
        if filename in ("Includes_Info.xml", "screensaver-arctic-mirage.xml"):
            lines.append("  root rating icon paths remaining: {0}".format(row.get("root_rating_icon_refs", 0)))
    return "\n".join(lines)

# -----------------------------------------------------------------------------
# v1.4.12 - live IMDb Top250 chart parser diagnostics + safe DB update
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 35)
LRS_SCHEMA_VERSION = 1412
SCHEMA_VERSION_1410 = 1412
TOP250_SYNC_LAST_FILE_1412 = os.path.join(DIAGNOSTICS_DIR, "top250-sync-last.json")
TOP250_SYNC_REPORT_FILE_1412 = os.path.join(DIAGNOSTICS_DIR, "top250-sync-report.csv")
TOP250_SAMPLE_LIMIT_1412 = 120000


def _top250_chart_url_1412(media_type: str) -> str:
    return IMDB_TOP250_TV_CHART_URL_1410 if media_setting_type(media_type) == "tvshow" else IMDB_TOP250_MOVIE_CHART_URL_1410


def _imdb_chart_fetch_1412(media_type: str) -> Dict[str, Any]:
    """Fetch an IMDb chart and keep enough diagnostics to prove what happened."""
    media_type = media_setting_type(media_type)
    url = _top250_chart_url_1412(media_type)
    detail: Dict[str, Any] = {
        "media_type": media_type,
        "url": url,
        "final_url": "",
        "http_status": None,
        "bytes": 0,
        "content_type": "",
        "page_title": "",
        "blocked_hint": False,
        "error": "",
    }
    html = ""
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0 Safari/537.36 Kodi-Library-Ratings-Scraper/1.4.12",
        "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,application/json;q=0.8,*/*;q=0.7",
        "Accept-Language": "en-US,en;q=0.9",
        "Cache-Control": "no-cache",
        "Pragma": "no-cache",
        "Referer": "https://www.imdb.com/",
    })
    try:
        with urlopen(request, timeout=NETWORK_TIMEOUT) as response:  # nosec B310 fixed HTTPS source URL
            raw = response.read()
            detail["http_status"] = getattr(response, "status", None) or response.getcode()
            detail["final_url"] = response.geturl()
            detail["bytes"] = len(raw or b"")
            detail["content_type"] = response.headers.get("content-type", "") if response.headers else ""
            html = (raw or b"").decode("utf-8", "replace")
    except HTTPError as exc:
        detail["http_status"] = exc.code
        detail["final_url"] = getattr(exc, "url", "") or url
        detail["content_type"] = exc.headers.get("content-type", "") if exc.headers else ""
        try:
            raw = exc.read()
            detail["bytes"] = len(raw or b"")
            html = (raw or b"").decode("utf-8", "replace")
        except Exception:
            html = ""
        detail["error"] = "HTTP {0}".format(exc.code)
    except (URLError, OSError, TimeoutError, ValueError) as exc:
        detail["error"] = str(exc)
    try:
        title_match = re.search(r"<title[^>]*>(.*?)</title>", html or "", flags=re.I | re.S)
        if title_match:
            import html as _html_module  # pylint: disable=import-outside-toplevel
            detail["page_title"] = re.sub(r"\s+", " ", _html_module.unescape(title_match.group(1))).strip()[:200]
    except Exception:
        pass
    lower = (html or "").lower()
    detail["blocked_hint"] = any(token in lower for token in (
        "captcha", "robot", "are you a human", "access denied", "request has been blocked", "unusual traffic", "enable cookies",
    ))
    return {"html": html, "detail": detail}


def _first_imdb_id_in_node_1412(node: Any) -> str:
    if isinstance(node, str):
        m = re.search(r"tt\d{5,12}", node, flags=re.I)
        return m.group(0).lower() if m else ""
    if isinstance(node, dict):
        # Prefer canonical id fields before scanning every child.
        for key in ("id", "titleId", "tconst", "const", "primaryConst"):
            value = node.get(key)
            if isinstance(value, str) and re.fullmatch(r"tt\d{5,12}", value, flags=re.I):
                return value.lower()
        for key in ("node", "item", "title", "titleNode", "titleDetails", "watchOptionsTitle"):
            if key in node:
                value = _first_imdb_id_in_node_1412(node.get(key))
                if value:
                    return value
        for value in node.values():
            found = _first_imdb_id_in_node_1412(value)
            if found:
                return found
    elif isinstance(node, list):
        for value in node:
            found = _first_imdb_id_in_node_1412(value)
            if found:
                return found
    return ""


def _walk_chart_json_1412(node: Any, path: str, ranked: Dict[str, int], candidates: List[Tuple[int, str, List[str]]]) -> None:
    if isinstance(node, dict):
        rank = None
        for key in ("rank", "currentRank", "chartRank", "position", "listPosition", "itemRank", "ranking"):
            value = safe_int(node.get(key))
            if value is not None and 1 <= value <= 250:
                rank = int(value)
                break
        if rank is not None:
            imdb_id = _first_imdb_id_in_node_1412(node)
            if imdb_id:
                ranked.setdefault(imdb_id, rank)
        for key, value in node.items():
            _walk_chart_json_1412(value, path + "/" + str(key), ranked, candidates)
    elif isinstance(node, list):
        ids: List[str] = []
        seen = set()
        for value in node:
            imdb_id = _first_imdb_id_in_node_1412(value)
            if imdb_id and imdb_id not in seen:
                seen.add(imdb_id)
                ids.append(imdb_id)
        if len(ids) >= 180:
            low_path = path.lower()
            score = 0
            if "chart" in low_path:
                score += 40
            if "edge" in low_path or "item" in low_path or "title" in low_path:
                score += 20
            score += max(0, 30 - abs(len(ids) - 250))
            score += min(len(ids), 250) // 20
            candidates.append((score, path, ids[:250]))
        # Still recurse because the actual chart list can be nested in an object
        # inside a longer generic list.
        for idx, value in enumerate(node[:600]):
            _walk_chart_json_1412(value, path + "/[]" if idx == 0 else path + "/[]", ranked, candidates)


def _script_json_blocks_1412(html_text: str) -> List[str]:
    blocks: List[str] = []
    for raw in re.findall(r'<script[^>]*(?:type=["\']application/(?:json|ld\+json)["\']|id=["\']__NEXT_DATA__["\'])[^>]*>(.*?)</script>', html_text or "", flags=re.I | re.S):
        text = raw.strip()
        if text:
            try:
                import html as _html_module  # pylint: disable=import-outside-toplevel
                text = _html_module.unescape(text)
            except Exception:
                pass
            blocks.append(text)
    return blocks


def _parse_imdb_top250_1412(html_text: str) -> Tuple[Dict[str, int], str]:
    """Return (rank map, parser method). Designed for IMDb's modern JSON pages."""
    if not html_text:
        return {}, "empty_response"
    ranked: Dict[str, int] = {}
    candidates: List[Tuple[int, str, List[str]]] = []
    json_blocks = _script_json_blocks_1412(html_text)
    for raw in json_blocks:
        try:
            parsed = json.loads(raw)
        except Exception:
            continue
        _walk_chart_json_1412(parsed, "$", ranked, candidates)
    if len(ranked) >= 200:
        clean = {imdb: int(rank) for imdb, rank in ranked.items() if 1 <= int(rank) <= 250}
        return dict(sorted(clean.items(), key=lambda pair: int(pair[1]))[:250]), "json_rank_fields"
    if candidates:
        candidates.sort(key=lambda row: (row[0], len(row[2])), reverse=True)
        ids = candidates[0][2]
        if len(ids) >= 200:
            return {imdb_id: index for index, imdb_id in enumerate(ids[:250], start=1)}, "json_ordered_list:{0}".format(candidates[0][1])
    # HTML/escaped URL fallback.
    patterns = [
        r'(?:/|\\/|\\u002[fF])title(?:/|\\/|\\u002[fF])(tt\d{5,12})(?:/|\\/|\\u002[fF])',
        r'["\']id["\']\s*:\s*["\'](tt\d{5,12})["\']',
        r'\b(tt\d{7,12})\b',
    ]
    for idx, pattern in enumerate(patterns, start=1):
        ordered: List[str] = []
        seen = set()
        for imdb_id in re.findall(pattern, html_text, flags=re.I):
            imdb_id = str(imdb_id).lower()
            if imdb_id not in seen:
                seen.add(imdb_id)
                ordered.append(imdb_id)
        if len(ordered) >= 200:
            return {imdb_id: rank for rank, imdb_id in enumerate(ordered[:250], start=1)}, "regex_order_{0}".format(idx)
    return {}, "no_parser_match"


def _write_top250_sample_1412(media_type: str, html_text: str, detail: Dict[str, Any]) -> str:
    try:
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        filename = "top250-fetch-{0}-sample.txt".format("tv" if media_setting_type(media_type) == "tvshow" else "movie")
        path = os.path.join(DIAGNOSTICS_DIR, filename)
        sample = html_text[:TOP250_SAMPLE_LIMIT_1412] if html_text else ""
        header = {
            "created_at": now_iso(),
            "note": "Truncated IMDb chart response sample for parser diagnostics.",
            "detail": detail,
        }
        with open(path, "w", encoding="utf-8", newline="") as fh:
            fh.write(json.dumps(header, indent=2, ensure_ascii=False, sort_keys=True))
            fh.write("\n\n--- HTML SAMPLE ---\n")
            fh.write(sample)
        return path
    except Exception:
        return ""


def _fetch_imdb_chart_result_1412(media_type: str) -> Dict[str, Any]:
    media_type = media_setting_type(media_type)
    fetched = _imdb_chart_fetch_1412(media_type)
    html_text = fetched.get("html") or ""
    detail = fetched.get("detail") or {}
    ranks, method = _parse_imdb_top250_1412(html_text)
    detail["parser_method"] = method
    detail["parsed_count"] = len(ranks)
    detail["valid"] = len(ranks) >= 200
    detail["top10"] = ["{0}:{1}".format(imdb, ranks[imdb]) for imdb in sorted(ranks, key=lambda k: int(ranks[k]))[:10]]
    if not detail.get("valid") or detail.get("blocked_hint") or detail.get("error"):
        sample_path = _write_top250_sample_1412(media_type, html_text, detail)
        if sample_path:
            detail["sample_path"] = sample_path
    return {"media_type": media_type, "ranks": ranks, "detail": detail}


def _save_top250_sync_files_1412(payload: Dict[str, Any]) -> None:
    try:
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        _atomic_write_json(TOP250_SYNC_LAST_FILE_1412, payload)
        rows = []
        for key in ("movie", "tvshow"):
            detail = ((payload.get("charts") or {}).get(key) or {}).get("detail") or {}
            rows.append({
                "media_type": key,
                "url": detail.get("url", ""),
                "final_url": detail.get("final_url", ""),
                "http_status": detail.get("http_status", ""),
                "bytes": detail.get("bytes", ""),
                "page_title": detail.get("page_title", ""),
                "parser_method": detail.get("parser_method", ""),
                "parsed_count": detail.get("parsed_count", ""),
                "valid": detail.get("valid", ""),
                "blocked_hint": detail.get("blocked_hint", ""),
                "error": detail.get("error", ""),
                "sample_path": detail.get("sample_path", ""),
            })
        with open(TOP250_SYNC_REPORT_FILE_1412, "w", encoding="utf-8", newline="") as fh:
            writer = csv.DictWriter(fh, fieldnames=["media_type", "url", "final_url", "http_status", "bytes", "page_title", "parser_method", "parsed_count", "valid", "blocked_hint", "error", "sample_path"])
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
    except Exception as exc:
        log("Failed to save Top250 diagnostics: {0}".format(exc), xbmc.LOGWARNING)


def _save_top250_chart_to_meta_1410(media_type: str, ranks: Dict[str, int]) -> None:
    # Override the 1.4.10 helper: store chart cache only after the caller has
    # validated all enabled charts. This function no longer marks source success
    # by itself; sync_imdb_top250_to_library writes source metadata after DB update.
    media_type = media_setting_type(media_type)
    serializable = {str(k).lower(): int(v) for k, v in (ranks or {}).items() if re.fullmatch(r"tt\d{5,12}", str(k).lower()) and safe_int(v)}
    with _sqlite_connect() as conn:
        _db_set_meta(conn, _top250_chart_meta_key_1410(media_type), json.dumps(serializable, sort_keys=True))
        _db_set_meta(conn, "top250_chart_{0}_updated_at".format(media_type), now_iso())
        _db_set_meta(conn, "top250_chart_{0}_count".format(media_type), len(serializable))
        conn.commit()


def _fetch_imdb_chart_ranks_1410(media_type: str) -> Dict[str, int]:
    result = _fetch_imdb_chart_result_1412(media_type)
    detail = result.get("detail") or {}
    ranks = result.get("ranks") or {}
    if len(ranks) < 200:
        raise RuntimeError("{0} chart returned only {1} valid titles; url={2}; status={3}; method={4}; title={5}".format(
            "TV" if media_setting_type(media_type) == "tvshow" else "Movie",
            len(ranks), detail.get("url", ""), detail.get("http_status", ""), detail.get("parser_method", ""), detail.get("page_title", ""),
        ))
    return dict(sorted(ranks.items(), key=lambda pair: int(pair[1]))[:250])


def imdb_top250_ranks(force_refresh: bool = False) -> Dict[str, int]:
    if force_refresh:
        result = _fetch_imdb_chart_result_1412("movie")
        ranks = result.get("ranks") or {}
        if len(ranks) < 200:
            _save_top250_sync_files_1412({"created_at": now_iso(), "ok": False, "charts": {"movie": result}, "error": "Movie chart returned only {0} valid titles".format(len(ranks))})
            raise RuntimeError("Movie chart returned only {0} valid titles".format(len(ranks)))
        _save_top250_chart_to_meta_1410("movie", ranks)
        return ranks
    ranks = _load_top250_chart_from_meta_1410("movie")
    return ranks or _load_local_top250_ranks("movie")


def imdb_top250_tv_ranks(force_refresh: bool = False) -> Dict[str, int]:
    if force_refresh:
        result = _fetch_imdb_chart_result_1412("tvshow")
        ranks = result.get("ranks") or {}
        if len(ranks) < 200:
            _save_top250_sync_files_1412({"created_at": now_iso(), "ok": False, "charts": {"tvshow": result}, "error": "TV chart returned only {0} valid titles".format(len(ranks))})
            raise RuntimeError("TV chart returned only {0} valid titles".format(len(ranks)))
        _save_top250_chart_to_meta_1410("tvshow", ranks)
        return ranks
    ranks = _load_top250_chart_from_meta_1410("tvshow")
    return ranks or _load_local_top250_ranks("tvshow")


def _top250_source_label_1412(movie_ranks: Dict[str, int], tv_ranks: Dict[str, int]) -> str:
    # If live web metadata exists, prefer clear wording; otherwise it is local fallback.
    try:
        with _sqlite_connect() as conn:
            movie_count = safe_int(_db_get_meta(conn, "top250_chart_movie_count")) or 0
            tv_count = safe_int(_db_get_meta(conn, "top250_chart_tvshow_count")) or 0
        if movie_count >= 200 or tv_count >= 200:
            return "Bundled Top250 database"
    except Exception:
        pass
    return _local_top250_db_path()


def sync_imdb_top250_to_library(force_chart_refresh: bool = False, progress: Any = None) -> Dict[str, int]:
    movie_enabled = rating_enabled("movie", "top250", True) and bool_setting("include_movies", True)
    tv_enabled = rating_enabled("tvshow", "top250", True) and bool_setting("include_tvshows", True)
    stats = {"movies": 0, "movie_matched": 0, "movie_updated": 0, "movie_missing_imdb": 0, "movie_chart_items": 0, "tvshows": 0, "tv_matched": 0, "tv_updated": 0, "tv_missing_imdb": 0, "tv_chart_items": 0, "updated": 0, "matched": 0, "total": 0, "processed": 0, "source": ""}
    charts: Dict[str, Any] = {}
    movie_ranks: Dict[str, int] = {}
    tv_ranks: Dict[str, int] = {}
    sync_payload: Dict[str, Any] = {"created_at": now_iso(), "ok": False, "force_chart_refresh": bool(force_chart_refresh), "charts": charts, "stats": stats}

    if force_chart_refresh:
        if progress is not None:
            try: progress.update(5, "Library Ratings Scraper", "1/5 FETCHING MOVIE CHART - TOP250")
            except TypeError: progress.update(5, "1/5 FETCHING MOVIE CHART - TOP250")
        if movie_enabled:
            charts["movie"] = _fetch_imdb_chart_result_1412("movie")
        if progress is not None:
            try: progress.update(25, "Library Ratings Scraper", "2/5 FETCHING TV CHART - TOP250")
            except TypeError: progress.update(25, "2/5 FETCHING TV CHART - TOP250")
        if tv_enabled:
            charts["tvshow"] = _fetch_imdb_chart_result_1412("tvshow")
        # Validate after both fetches, so diagnostics proves both URLs were tested.
        errors = []
        if movie_enabled:
            movie_ranks = (charts.get("movie") or {}).get("ranks") or {}
            if len(movie_ranks) < 200:
                d = (charts.get("movie") or {}).get("detail") or {}
                errors.append("Movie chart returned only {0} valid titles (status={1}, method={2})".format(len(movie_ranks), d.get("http_status"), d.get("parser_method")))
        if tv_enabled:
            tv_ranks = (charts.get("tvshow") or {}).get("ranks") or {}
            if len(tv_ranks) < 200:
                d = (charts.get("tvshow") or {}).get("detail") or {}
                errors.append("TV chart returned only {0} valid titles (status={1}, method={2})".format(len(tv_ranks), d.get("http_status"), d.get("parser_method")))
        if errors:
            sync_payload["error"] = "; ".join(errors)
            sync_payload["existing_ranks_kept"] = True
            _save_top250_sync_files_1412(sync_payload)
            raise RuntimeError(sync_payload["error"] + ". Existing Top 250 ranks were kept unchanged.")
        if progress is not None:
            try: progress.update(55, "Library Ratings Scraper", "3/5 VALIDATING DATA - TOP250")
            except TypeError: progress.update(55, "3/5 VALIDATING DATA - TOP250")
        if movie_enabled:
            _save_top250_chart_to_meta_1410("movie", movie_ranks)
        if tv_enabled:
            _save_top250_chart_to_meta_1410("tvshow", tv_ranks)
        stats["source"] = "Bundled Top250 database"
    else:
        movie_ranks = imdb_top250_ranks(False) if movie_enabled else {}
        tv_ranks = imdb_top250_tv_ranks(False) if tv_enabled else {}
        stats["source"] = _top250_source_label_1412(movie_ranks, tv_ranks)

    stats["movie_chart_items"] = len(movie_ranks)
    stats["tv_chart_items"] = len(tv_ranks)
    movies = json_rpc("VideoLibrary.GetMovies", {"properties": ["title", "year", "imdbnumber", "uniqueid", "top250"]}).get("movies", []) or [] if movie_enabled else []
    shows = json_rpc("VideoLibrary.GetTVShows", {"properties": ["title", "year", "imdbnumber", "uniqueid"]}).get("tvshows", []) or [] if tv_enabled else []
    stats["movies"] = len(movies)
    stats["tvshows"] = len(shows)
    total = len(movies) + len(shows)
    done = 0
    matched_titles: List[str] = []
    if progress is not None:
        try: progress.update(70, "Library Ratings Scraper", "4/5 UPDATING LIBRARY - TOP250")
        except TypeError: progress.update(70, "4/5 UPDATING LIBRARY - TOP250")
    with _sqlite_connect() as conn:
        for movie in movies:
            done += 1
            if progress is not None and (done == total or done % 50 == 0):
                pct = 70 + int(done * 25 / max(1, total))
                try: progress.update(pct, "Library Ratings Scraper", "{0}/{1} UPDATING LIBRARY - TOP250".format(done, total))
                except TypeError: progress.update(pct, "{0}/{1} UPDATING LIBRARY - TOP250".format(done, total))
            imdb_id = _json_item_imdb_id(movie)
            value = int(movie_ranks.get(imdb_id)) if imdb_id and imdb_id in movie_ranks else METADATA_NA_VALUE
            if not imdb_id:
                stats["movie_missing_imdb"] += 1
            elif value != METADATA_NA_VALUE:
                stats["movie_matched"] += 1
                if len(matched_titles) < 15:
                    matched_titles.append("{0} #{1}".format((movie or {}).get("title") or imdb_id, value))
            if _upsert_top250_row(conn, "movie", movie.get("movieid"), movie, value):
                stats["movie_updated"] += 1
        for show in shows:
            done += 1
            if progress is not None and (done == total or done % 50 == 0):
                pct = 70 + int(done * 25 / max(1, total))
                try: progress.update(pct, "Library Ratings Scraper", "{0}/{1} UPDATING LIBRARY - TOP250".format(done, total))
                except TypeError: progress.update(pct, "{0}/{1} UPDATING LIBRARY - TOP250".format(done, total))
            imdb_id = _json_item_imdb_id(show)
            value = int(tv_ranks.get(imdb_id)) if imdb_id and imdb_id in tv_ranks else METADATA_NA_VALUE
            if not imdb_id:
                stats["tv_missing_imdb"] += 1
            elif value != METADATA_NA_VALUE:
                stats["tv_matched"] += 1
                if len(matched_titles) < 15:
                    matched_titles.append("{0} #{1}".format((show or {}).get("title") or imdb_id, value))
            if _upsert_top250_row(conn, "tvshow", show.get("tvshowid"), show, value):
                stats["tv_updated"] += 1
        if force_chart_refresh:
            _db_set_meta(conn, "top250_source", "Bundled Top250 database")
            _db_set_meta(conn, "top250_chart_sync_at", now_iso())
            _db_set_meta(conn, "top250_last_success_at", now_iso())
        else:
            _db_set_meta(conn, "top250_source", stats.get("source") or _top250_source_label_1412(movie_ranks, tv_ranks))
            _db_set_meta(conn, "top250_local_sync_at", now_iso())
        _db_set_meta(conn, "addon_version", "1.4.12")
        conn.commit()
    stats["updated"] = int(stats.get("movie_updated") or 0) + int(stats.get("tv_updated") or 0)
    stats["matched"] = int(stats.get("movie_matched") or 0) + int(stats.get("tv_matched") or 0)
    stats["total"] = total
    stats["processed"] = total
    sync_payload["ok"] = True
    sync_payload["finished_at"] = now_iso()
    sync_payload["stats"] = dict(stats)
    sync_payload["matched_preview"] = matched_titles
    sync_payload["existing_ranks_kept"] = False
    _save_top250_sync_files_1412(sync_payload)
    if progress is not None:
        try: progress.update(100, "Library Ratings Scraper", "5/5 COMPLETE - TOP250")
        except TypeError: progress.update(100, "5/5 COMPLETE - TOP250")
    return stats




# -----------------------------------------------------------------------------
# v1.4.13 - Restore bundled IMDb Top 250 database source
# -----------------------------------------------------------------------------
# Live IMDb web syncing was intentionally removed. Kodi Python receives
# browser-verification / WAF HTML from Bundled Top250 database, so Top250 now uses the
# bundled local database again. This keeps updates fast, deterministic, and safe.
SCHEMA_VERSION_1413 = 1413
TOP250_LOCAL_SYNC_LAST_FILE_1413 = os.path.join(DIAGNOSTICS_DIR, "top250-local-sync-last.json")
TOP250_LOCAL_SYNC_REPORT_FILE_1413 = os.path.join(DIAGNOSTICS_DIR, "top250-local-sync-report.csv")


def _remove_live_top250_diagnostics_1413() -> None:
    try:
        for name in (
            "top250-sync-last.json",
            "top250-sync-report.csv",
            "top250-fetch-movie-sample.txt",
            "top250-fetch-tv-sample.txt",
        ):
            path = os.path.join(DIAGNOSTICS_DIR, name)
            if os.path.exists(path):
                try:
                    os.remove(path)
                except Exception:
                    pass
    except Exception:
        pass


def _top250_local_source_label_1413() -> str:
    path = _local_top250_db_path()
    return "Bundled Top250 database" if path else "Bundled Top250 database unavailable"


def imdb_top250_ranks(force_refresh: bool = False) -> Dict[str, int]:
    # force_refresh is ignored on purpose in v1.4.13. The source is the bundled DB.
    return _load_local_top250_ranks("movie")


def imdb_top250_tv_ranks(force_refresh: bool = False) -> Dict[str, int]:
    return _load_local_top250_ranks("tvshow")


def _load_top250_cache() -> Dict[str, Any]:
    return {
        "timestamp": int(time.time()),
        "updated_at": now_iso(),
        "ranks": imdb_top250_ranks(False),
        "source": "bundled_db",
    }


def _save_top250_cache(ranks: Dict[str, int]) -> None:
    # The runtime cache writer is intentionally disabled for Top250. The bundled DB
    # remains the source of truth; library rows are updated through sync only.
    return None


def _save_top250_local_sync_files_1413(payload: Dict[str, Any]) -> None:
    try:
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        _atomic_write_json(TOP250_LOCAL_SYNC_LAST_FILE_1413, payload)
        rows = []
        stats = payload.get("stats") or {}
        for key in ("source", "movies", "movie_chart_items", "movie_matched", "movie_updated", "movie_missing_imdb", "tvshows", "tv_chart_items", "tv_matched", "tv_updated", "tv_missing_imdb", "total", "processed", "matched", "updated"):
            rows.append({"field": key, "value": stats.get(key, payload.get(key, ""))})
        with open(TOP250_LOCAL_SYNC_REPORT_FILE_1413, "w", encoding="utf-8", newline="") as handle:
            writer = csv.DictWriter(handle, fieldnames=["field", "value"])
            writer.writeheader()
            writer.writerows(rows)
    except Exception as exc:  # pylint: disable=broad-except
        log("Top250 local sync diagnostics failed: {0}".format(exc), xbmc.LOGWARNING)


def sync_imdb_top250_to_library(force_chart_refresh: bool = False, progress: Any = None) -> Dict[str, int]:
    _remove_live_top250_diagnostics_1413()
    movie_enabled = rating_enabled("movie", "top250", True) and bool_setting("include_movies", True)
    tv_enabled = rating_enabled("tvshow", "top250", True) and bool_setting("include_tvshows", True)
    movie_ranks = imdb_top250_ranks(False) if movie_enabled else {}
    tv_ranks = imdb_top250_tv_ranks(False) if tv_enabled else {}
    stats = {
        "movies": 0, "movie_matched": 0, "movie_updated": 0, "movie_missing_imdb": 0, "movie_chart_items": len(movie_ranks),
        "tvshows": 0, "tv_matched": 0, "tv_updated": 0, "tv_missing_imdb": 0, "tv_chart_items": len(tv_ranks),
        "updated": 0, "matched": 0, "total": 0, "processed": 0, "source": _top250_local_source_label_1413(),
    }
    if progress is not None:
        try:
            progress.update(10, "Library Ratings Scraper", "1/3 LOADING LOCAL DATABASE - TOP250")
        except TypeError:
            progress.update(10, "1/3 LOADING LOCAL DATABASE - TOP250")
    movies = json_rpc("VideoLibrary.GetMovies", {"properties": ["title", "year", "imdbnumber", "uniqueid", "top250"]}).get("movies", []) or [] if movie_enabled else []
    shows = json_rpc("VideoLibrary.GetTVShows", {"properties": ["title", "year", "imdbnumber", "uniqueid"]}).get("tvshows", []) or [] if tv_enabled else []
    stats["movies"] = len(movies)
    stats["tvshows"] = len(shows)
    total = len(movies) + len(shows)
    stats["total"] = total
    if progress is not None:
        try:
            progress.update(35, "Library Ratings Scraper", "2/3 MATCHING LIBRARY - TOP250")
        except TypeError:
            progress.update(35, "2/3 MATCHING LIBRARY - TOP250")
    done = 0
    matched_titles: List[str] = []
    with _sqlite_connect() as conn:
        for movie in movies:
            done += 1
            if progress is not None:
                pct = 35 + int(done * 60 / max(1, total))
                label = str((movie or {}).get("title") or "UPDATING LIBRARY").replace("\n", " ").strip().upper()
                body = "{0}/{1} {2} - TOP250".format(done, total, label)
                try:
                    progress.update(pct, "Library Ratings Scraper", body)
                except TypeError:
                    progress.update(pct, body)
            imdb_id = _json_item_imdb_id(movie)
            value = int(movie_ranks.get(imdb_id)) if imdb_id and imdb_id in movie_ranks else METADATA_NA_VALUE
            if not imdb_id:
                stats["movie_missing_imdb"] += 1
            elif value != METADATA_NA_VALUE:
                stats["movie_matched"] += 1
                if len(matched_titles) < 15:
                    matched_titles.append("{0} #{1}".format((movie or {}).get("title") or imdb_id, value))
            if _upsert_top250_row(conn, "movie", movie.get("movieid"), movie, value):
                stats["movie_updated"] += 1
        for show in shows:
            done += 1
            if progress is not None:
                pct = 35 + int(done * 60 / max(1, total))
                label = str((show or {}).get("title") or "UPDATING LIBRARY").replace("\n", " ").strip().upper()
                body = "{0}/{1} {2} - TOP250".format(done, total, label)
                try:
                    progress.update(pct, "Library Ratings Scraper", body)
                except TypeError:
                    progress.update(pct, body)
            imdb_id = _json_item_imdb_id(show)
            value = int(tv_ranks.get(imdb_id)) if imdb_id and imdb_id in tv_ranks else METADATA_NA_VALUE
            if not imdb_id:
                stats["tv_missing_imdb"] += 1
            elif value != METADATA_NA_VALUE:
                stats["tv_matched"] += 1
                if len(matched_titles) < 15:
                    matched_titles.append("{0} #{1}".format((show or {}).get("title") or imdb_id, value))
            if _upsert_top250_row(conn, "tvshow", show.get("tvshowid"), show, value):
                stats["tv_updated"] += 1
        stats["updated"] = int(stats.get("movie_updated") or 0) + int(stats.get("tv_updated") or 0)
        stats["matched"] = int(stats.get("movie_matched") or 0) + int(stats.get("tv_matched") or 0)
        stats["processed"] = total
        _db_set_meta(conn, "top250_source", stats["source"])
        _db_set_meta(conn, "top250_local_sync_at", now_iso())
        _db_set_meta(conn, "top250_last_success_at", now_iso())
        _db_set_meta(conn, "top250_last_success_source", stats["source"])
        _db_set_meta(conn, "top250_last_attempt_status", "local_db_success")
        _db_set_meta(conn, "top250_last_error", "")
        _db_set_meta(conn, "addon_version", ADDON.getAddonInfo("version") or "1.5.0")
        conn.commit()
    payload = {
        "created_at": now_iso(),
        "ok": True,
        "source": stats["source"],
        "stats": dict(stats),
        "matched_preview": matched_titles,
        "live_chart_sync": False,
    }
    _save_top250_local_sync_files_1413(payload)
    if progress is not None:
        try:
            progress.update(100, "Library Ratings Scraper", "3/3 COMPLETE - TOP250")
        except TypeError:
            progress.update(100, "3/3 COMPLETE - TOP250")
    return stats


_provider_health_check_1413_base = provider_health_check_1470

def provider_health_check_1470(online: bool = True) -> Dict[str, Any]:
    result = _provider_health_check_1413_base(online)
    try:
        movie_count = len(imdb_top250_ranks(False) or {})
        tv_count = len(imdb_top250_tv_ranks(False) or {})
        for row in result.get("providers") or []:
            if row.get("provider") == "IMDb Top 250":
                row["status"] = "OK" if movie_count or tv_count else "EMPTY"
                row["detail"] = "local DB, movie={0}, tv={1}".format(movie_count, tv_count)
        path = os.path.join(DIAGNOSTICS_DIR, "provider-health.json")
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        _atomic_write_json(path, result)
        result["path"] = path
    except Exception:
        pass
    return result


_diagnostic_candidates_1413_base = _diagnostic_candidates_1397

def _diagnostic_candidates_1397() -> List[str]:
    paths = _diagnostic_candidates_1413_base()
    skip = {
        "top250-sync-last.json",
        "top250-sync-report.csv",
        "top250-fetch-movie-sample.txt",
        "top250-fetch-tv-sample.txt",
    }
    filtered = []
    for path in paths:
        try:
            if os.path.basename(path) in skip:
                continue
        except Exception:
            pass
        filtered.append(path)
    return filtered


_record_missing_top250_1413_base = record_missing_top250

def record_missing_top250(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    # Top250 is handled only by the dedicated local database update action.
    # Missing-only scrape should never become slow because Top250 is blank.
    return False




# v1.4.13 final safety: any old live IMDb web-sync helper is disabled.
def _fetch_imdb_chart_result_1412(media_type: str) -> Dict[str, Any]:
    mt = media_setting_type(media_type)
    ranks = _load_local_top250_ranks(mt)
    return {
        "media_type": mt,
        "ranks": ranks,
        "detail": {
            "ok": True,
            "source": _top250_local_source_label_1413(),
            "parsed_count": len(ranks),
            "parser_method": "bundled_db",
            "disabled_reason": "Live IMDb web syncing is disabled; bundled Top250 database is used in v1.5 stable.",
        },
    }


def _fetch_imdb_chart_ranks_1410(media_type: str) -> Dict[str, int]:
    return _load_local_top250_ranks(media_setting_type(media_type))


# -----------------------------------------------------------------------------
# v1.5.0 - stable diagnostics/report cleanup
# -----------------------------------------------------------------------------
SENSITIVE_SETTING_IDS_1500 = {
    "mdblist_apikey", "mdblist_apikey_2", "tmdb_apikey", "omdb_apikey", "omdb_apikey_2",
}


def _redact_diagnostic_text_1500(text: str) -> str:
    """Redact API keys from diagnostics text without touching binary DB files."""
    safe = str(text or "")
    ids = "|".join(re.escape(x) for x in sorted(SENSITIVE_SETTING_IDS_1500))
    # Kodi profile settings.xml usually stores values as: <setting id="x">value</setting>
    safe = re.sub(
        r'(<setting\s+id=["\'](?:' + ids + r')["\'][^>]*>)(.*?)(</setting>)',
        lambda m: m.group(1) + ("REDACTED" if m.group(2).strip() else "") + m.group(3),
        safe,
        flags=re.I | re.S,
    )
    # Some XML/JSON/debug forms can store the secret as an attribute or key/value pair.
    safe = re.sub(
        r'((?:' + ids + r')["\']?\s*[:=]\s*["\'])([^"\'\s<>&]{4,})(["\'])',
        lambda m: m.group(1) + "REDACTED" + m.group(3),
        safe,
        flags=re.I,
    )
    safe = re.sub(
        r'((?:api[_-]?key|apikey|apiKey)\s*[:=]\s*)([A-Za-z0-9_\-\.]{12,})',
        lambda m: m.group(1) + "REDACTED",
        safe,
        flags=re.I,
    )
    # Query strings in kodi.log or provider debug traces.
    safe = re.sub(r'([?&](?:api_key|apikey)=)([^&\s]+)', lambda m: m.group(1) + "REDACTED", safe, flags=re.I)
    return safe


def _diagnostic_text_file_1500(path: str) -> bool:
    low = str(path or "").lower()
    return low.endswith((".xml", ".json", ".txt", ".log", ".csv", ".po", ".md"))


def _rt_badge_report_has_rows_1500(path: str) -> bool:
    try:
        if not path or not os.path.exists(path) or os.path.getsize(path) <= 0:
            return False
        with open(path, "r", encoding="utf-8-sig", newline="") as handle:
            reader = csv.reader(handle)
            rows = 0
            for _row in reader:
                rows += 1
                if rows > 1:
                    return True
    except Exception:
        return False
    return False


def _ensure_rt_badges_report_snapshot_1500() -> None:
    """If the last RT badge report is header-only, export a cache snapshot instead."""
    try:
        if _rt_badge_report_has_rows_1500(RT_BADGE_REPORT_FILE):
            return
        if not os.path.exists(CACHE_DB_FILE):
            return
        fieldnames = _rt_report_fieldnames_1394()
        rows = []
        with _sqlite_connect() as conn:
            try:
                cur = conn.execute(
                    """
                    SELECT media_type,title,year,imdb_id,tmdb_id,rottentomatoes_slug,rottentomatoes_status,
                           rottentomatoes,rottentomatoes_image,rottentomatoes_user,rottentomatoes_userimage,updated_at
                    FROM ratings
                    WHERE media_type IN ('movie','tvshow')
                      AND (COALESCE(rottentomatoes_status,'')<>'' OR COALESCE(rottentomatoes_image,'')<>'' OR COALESCE(rottentomatoes_userimage,'')<>'')
                    ORDER BY media_type,title
                    """
                )
            except Exception:
                return
            for row in cur.fetchall():
                status = str(_row_value(row, "rottentomatoes_status") or "")
                rows.append({
                    "checked_at": str(_row_value(row, "updated_at") or now_iso()).replace(" WIB", ""),
                    "media_type": str(_row_value(row, "media_type") or ""),
                    "title": str(_row_value(row, "title") or ""),
                    "year": str(_row_value(row, "year") or ""),
                    "imdb_id": str(_row_value(row, "imdb_id") or ""),
                    "tmdb_id": str(_row_value(row, "tmdb_id") or ""),
                    "slug": str(_row_value(row, "rottentomatoes_slug") or ""),
                    "status": status.split(";", 1)[0] if status else "cache_snapshot",
                    "critic_score": str(_row_value(row, "rottentomatoes") or ""),
                    "rt_crit": str(_row_value(row, "rottentomatoes_image") or ""),
                    "audience_score": str(_row_value(row, "rottentomatoes_user") or ""),
                    "rt_aud": str(_row_value(row, "rottentomatoes_userimage") or ""),
                    "updated": "no",
                    "note": "diagnostic snapshot from ratings cache",
                })
        if rows:
            os.makedirs(os.path.dirname(RT_BADGE_REPORT_FILE), exist_ok=True)
            with open(RT_BADGE_REPORT_FILE, "w", encoding="utf-8-sig", newline="") as handle:
                writer = csv.DictWriter(handle, fieldnames=fieldnames)
                writer.writeheader()
                for row in rows:
                    writer.writerow({name: row.get(name, "") for name in fieldnames})
    except Exception as exc:  # pylint: disable=broad-except
        log("RT badge report snapshot failed: {0}".format(exc), xbmc.LOGWARNING)


_save_top250_local_sync_files_1500_base = _save_top250_local_sync_files_1413

def _save_top250_local_sync_files_1413(payload: Dict[str, Any]) -> None:
    """Write the normal Top250 diagnostics, with clearer checked/changed aliases."""
    try:
        stats = payload.get("stats") or {}
        checked = int(stats.get("processed") or stats.get("total") or 0)
        changed_rows = int(stats.get("updated") or 0)
        stats["checked"] = checked
        stats["changed_rows"] = changed_rows
        payload["stats"] = stats
        payload["checked"] = checked
        payload["changed_rows"] = changed_rows
    except Exception:
        pass
    return _save_top250_local_sync_files_1500_base(payload)


_export_diagnostics_zip_1500_base = export_diagnostics_zip_1397

def export_diagnostics_zip_1397() -> str:
    """Create diagnostics ZIP with redacted text files and non-empty RT badge snapshot."""
    import zipfile  # pylint: disable=import-outside-toplevel
    os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
    _ensure_rt_badges_report_snapshot_1500()
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    zip_path = os.path.join(DIAGNOSTICS_DIR, "lrs-diagnostics-{0}.zip".format(stamp))
    base_profile = os.path.abspath(PROFILE)
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        manifest = {"created_at": now_iso(), "addon_version": ADDON.getAddonInfo("version"), "redaction": "api_keys", "files": []}
        for path in _diagnostic_candidates_1397():
            try:
                apath = os.path.abspath(path)
                if apath == os.path.abspath(zip_path):
                    continue
                if apath.startswith(base_profile):
                    arc = "profile/" + os.path.relpath(apath, base_profile).replace("\\", "/")
                else:
                    arc = "kodi/" + os.path.basename(apath)
                redacted = False
                if _diagnostic_text_file_1500(apath):
                    try:
                        with open(apath, "rb") as handle:
                            raw = handle.read()
                        try:
                            text = raw.decode("utf-8-sig")
                        except UnicodeDecodeError:
                            text = raw.decode("latin-1", "replace")
                        safe = _redact_diagnostic_text_1500(text)
                        zf.writestr(arc, safe.encode("utf-8"))
                        redacted = safe != text
                    except Exception:
                        zf.write(apath, arc)
                else:
                    zf.write(apath, arc)
                manifest["files"].append({"source": apath, "archive": arc, "size": os.path.getsize(apath), "redacted": bool(redacted)})
            except Exception as exc:  # pylint: disable=broad-except
                manifest.setdefault("errors", []).append({"file": str(path), "error": str(exc)})
        zf.writestr("manifest.json", json.dumps(manifest, indent=2, ensure_ascii=False, sort_keys=True))
    return zip_path




# -----------------------------------------------------------------------------
# v1.5.6 - LRS diagnostics/report cleanup
# -----------------------------------------------------------------------------
# Cleanup-only patch:
# - regenerate ratings-report.csv after Clean Library removes stale cache rows;
# - keep background-job-state clear for clean_library runs;
# - add a small diagnostics heartbeat/status so lrs.log is not silently stale.

def _write_lrs_diagnostic_heartbeat_1560(reason: str = "diagnostics") -> None:
    try:
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        line = "{0} | {1}\n".format(now_iso(), str(reason or "diagnostics"))
        with open(RT_BADGE_SIMPLE_LOG_FILE, "a", encoding="utf-8") as handle:
            handle.write(line)
    except Exception as exc:  # pylint: disable=broad-except
        try:
            log("LRS diagnostic heartbeat failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass


def _write_lrs_log_status_1560(reason: str = "diagnostics") -> None:
    try:
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        log_path = RT_BADGE_SIMPLE_LOG_FILE
        payload = {
            "created_at": now_iso(),
            "reason": str(reason or "diagnostics"),
            "lrs_log_path": log_path,
            "lrs_log_exists": bool(os.path.exists(log_path)),
            "note": "lrs.log may stay quiet during normal operation; this heartbeat proves diagnostics export reached the current session.",
        }
        if os.path.exists(log_path):
            try:
                payload["lrs_log_size_bytes"] = int(os.path.getsize(log_path))
                payload["lrs_log_mtime"] = datetime.fromtimestamp(os.path.getmtime(log_path)).strftime("%Y-%m-%d %H:%M:%S")
            except Exception:
                pass
        _atomic_write_json(os.path.join(DIAGNOSTICS_DIR, "lrs-log-status.json"), payload)
    except Exception as exc:  # pylint: disable=broad-except
        try:
            log("LRS log status write failed: {0}".format(exc), xbmc.LOGWARNING)
        except Exception:
            pass


_save_background_state_1560_base = save_background_state

def save_background_state(state: Dict[str, Any]) -> None:
    clean = dict(state or {})
    try:
        action = str(clean.get("action") or "").strip().lower()
        if action == "clean_library":
            checked = int(clean.get("checked") or clean.get("total") or clean.get("processed") or 0)
            removed = int(clean.get("removed") or clean.get("updated") or 0)
            clean["total"] = checked
            clean["processed"] = checked
            clean["percent"] = 100 if checked or str(clean.get("status") or "") == "completed" else int(clean.get("percent") or 0)
            clean["updated"] = removed
            clean["removed"] = removed
            clean["current"] = clean.get("current") or "Clean library cleanup"
            clean["reporting_note"] = "clean_library updated/removed means stale LRS cache rows deleted, not rating rows refreshed."
        elif int(clean.get("total") or 0) == 0 and int(clean.get("updated") or 0) > 0 and str(clean.get("status") or "") == "completed":
            clean["reporting_note"] = clean.get("reporting_note") or "total=0 means this completed state did not use item progress; updated is a result counter."
    except Exception:
        pass
    return _save_background_state_1560_base(clean)


_clean_orphan_library_ratings_1560_base = clean_orphan_library_ratings_1460

def clean_orphan_library_ratings_1460() -> Dict[str, Any]:
    stats = _clean_orphan_library_ratings_1560_base()
    try:
        removed = int((stats or {}).get("removed") or 0)
        if removed > 0 and not (stats or {}).get("error"):
            report = export_csv(load_cache())
            stats["report"] = report
            stats["report_refreshed"] = True
            try:
                with _sqlite_connect() as conn:
                    _db_set_meta(conn, "last_clean_library_report_refreshed_at", now_iso())
                    _db_set_meta(conn, "last_clean_library_report", os.path.basename(report or ""))
                    conn.commit()
            except Exception:
                pass
    except Exception as exc:  # pylint: disable=broad-except
        try:
            stats["report_error"] = str(exc)
        except Exception:
            pass
        log("Clean library report refresh failed: {0}".format(exc), xbmc.LOGWARNING)
    return stats


_export_diagnostics_zip_1560_base = export_diagnostics_zip_1397

def export_diagnostics_zip_1397() -> str:
    _write_lrs_diagnostic_heartbeat_1560("diagnostics export requested")
    _write_lrs_log_status_1560("diagnostics export requested")
    return _export_diagnostics_zip_1560_base()

# -----------------------------------------------------------------------------
# v1.5.8 - MediaHub Widget game rating passthrough for LRS/AF3
# -----------------------------------------------------------------------------
# Games are not Kodi video-library rows and must not be resolved through the
# movie/tv/episode scraper/cache path. MediaHub Widget already prepares rating
# slot properties on the ListItem; LRS only mirrors those slots into the normal
# LibraryRatings.* property namespace used by AF3 screensaver/home layouts.
CACHE_VERSION = max(CACHE_VERSION, 33)

_LRS_GAME_MARKER_KEYS_1580 = (
    "lrs_game", "lrs_item_type", "library_ratings_type", "DBTYPE", "DBType", "dbtype",
    "MediaType", "mediatype", "type",
)

_LRS_GAME_PAYLOAD_KEYS_1580 = (
    "lrs_game", "lrs_item_type", "library_ratings_type", "lrs_skip_scrape",
    "DBTYPE", "DBType", "dbtype", "MediaType", "mediatype",
    "steam_appid", "steam_review_percent", "steam_review_desc", "steam_review_total",
    "metacritic_score", "achievement_unlocked", "achievement_total", "completed", "finished",
)

for _lrs_game_slot_idx_1580 in range(1, 8):
    for _lrs_game_slot_suffix_1580 in ("Source", "Icon", "IconFile", "IconPath", "Label", "Value"):
        _LRS_GAME_PAYLOAD_KEYS_1580 += ("RatingSlot{0}_{1}".format(_lrs_game_slot_idx_1580, _lrs_game_slot_suffix_1580),)


def _lrs_game_clean_1580(value: Any) -> str:
    return str(value or "").strip()


def _lrs_game_truthy_1580(value: Any) -> bool:
    return _lrs_game_clean_1580(value).lower() in ("1", "true", "yes", "y", "on")


def _lrs_game_marker_value_1580(item: Dict[str, Any], key: str) -> str:
    for candidate in (key, key.lower(), key.upper()):
        value = _lrs_game_clean_1580((item or {}).get(candidate))
        if value:
            return value
    return ""


def is_lrs_game_item(item: Dict[str, Any]) -> bool:
    item = item or {}
    if _lrs_game_truthy_1580(item.get("lrs_game")):
        return True
    if _lrs_game_clean_1580(item.get("type")).lower() == "game":
        return True
    for key in _LRS_GAME_MARKER_KEYS_1580:
        if _lrs_game_marker_value_1580(item, key).lower() == "game":
            return True
    return False


def _lrs_game_has_identity_1580(item: Dict[str, Any]) -> bool:
    if not isinstance(item, dict):
        return False
    if _lrs_game_clean_1580(item.get("steam_appid")):
        return True
    if _lrs_game_clean_1580(item.get("title") or item.get("Title") or item.get("label") or item.get("Label")):
        return True
    for idx in range(1, 8):
        if _lrs_game_clean_1580(item.get("RatingSlot{0}_Value".format(idx))):
            return True
    return False


def _lrs_game_enrich_from_getter_1580(item: Dict[str, Any], getter) -> Dict[str, Any]:
    out = dict(item or {})
    for key in _LRS_GAME_PAYLOAD_KEYS_1580:
        try:
            value = _lrs_game_clean_1580(getter(key))
        except Exception:
            value = ""
        if value:
            out[key] = value
    # MediaHub can mark the item using either DBTYPE/MediaType/lrs_item_type.
    # Force the type to game only when a real game marker is present so normal
    # title-only movie/TV fallbacks remain untouched.
    if is_lrs_game_item(out):
        out["type"] = "game"
        out.setdefault("lrs_game", "true")
        if not _lrs_game_clean_1580(out.get("title")):
            try:
                title = _lrs_game_clean_1580(getter("title")) or _lrs_game_clean_1580(getter("Title")) or _lrs_game_clean_1580(getter("label")) or _lrs_game_clean_1580(getter("Label"))
            except Exception:
                title = ""
            if title:
                out["title"] = title
    return out


def _lrs_game_info_property_1580(name: str) -> str:
    return _info_label(
        "ListItem.Property({0})".format(name),
        "ListItem.Property({0})".format(name.lower()),
        "ListItem.Property({0})".format(name.upper()),
    )


_selected_library_item_1580_base = selected_library_item

def selected_library_item() -> Dict[str, Any]:
    item = _selected_library_item_1580_base()
    return _lrs_game_enrich_from_getter_1580(item, _lrs_game_info_property_1580)


_container_item_1580_base = container_item

def container_item(container_id: int, offset: int = 0) -> Dict[str, Any]:
    item = _container_item_1580_base(container_id, offset)

    def getter(name: str) -> str:
        expression = "Container({0}).ListItem.Property({1})".format(container_id, name) if offset == 0 else "Container({0}).ListItem({1}).Property({2})".format(container_id, offset, name)
        try:
            return xbmc.getInfoLabel(expression).strip()
        except Exception:  # pylint: disable=broad-except
            return ""

    return _lrs_game_enrich_from_getter_1580(item, getter)


_lrs_active_item_1580_base = lrs_active_item

def lrs_active_item() -> Dict[str, Any]:
    item = _lrs_active_item_1580_base()

    def getter(name: str) -> str:
        return _any_window_property(
            "LRS.Active.{0}".format(name),
            "LRS.Active.{0}".format(name.lower()),
            "LRS.Active.{0}".format(name.upper()),
        )

    return _lrs_game_enrich_from_getter_1580(item, getter)


_valid_library_item_1580_base = valid_library_item

def valid_library_item(item: Dict[str, Any]) -> bool:
    if is_lrs_game_item(item):
        return _lrs_game_has_identity_1580(item)
    return _valid_library_item_1580_base(item)


_resolvable_library_item_1580_base = resolvable_library_item

def resolvable_library_item(item: Dict[str, Any]) -> bool:
    if is_lrs_game_item(item):
        return False
    return _resolvable_library_item_1580_base(item)


_identity_key_1580_base = identity_key

def identity_key(item: Dict[str, Any]) -> str:
    if is_lrs_game_item(item):
        appid = _lrs_game_clean_1580((item or {}).get("steam_appid"))
        if appid:
            return "game|steam|{0}".format(appid)
        title = _norm_text((item or {}).get("title") or (item or {}).get("Title") or (item or {}).get("label") or (item or {}).get("Label"))
        year = safe_int((item or {}).get("year")) or ""
        return "game|identity|{0}|{1}".format(title, year)
    return _identity_key_1580_base(item)


def _lrs_game_icon_1580(source: Any, label: Any, icon: Any = "", icon_file: Any = "") -> str:
    haystack = " ".join(str(v or "") for v in (source, label, icon, icon_file)).lower()
    # Lifetime playtime intentionally uses the established clock icon.
    # This rule must run before the generic Steam rule, otherwise
    # source=steam_playtime is incorrectly normalized to steam.png.
    if "steam_playtime" in haystack or "steam-playtime" in haystack or "playtime" in haystack or "play time" in haystack:
        return "ends.png"
    if "achiev" in haystack or "steam-ach" in haystack or "steam_ach" in haystack:
        return "steam-ach.png"
    if "steam" in haystack:
        return "steam.png"
    if "metacritic" in haystack or "meta critic" in haystack:
        return "metacritic.png"
    return _lrs_game_clean_1580(icon_file) or _lrs_game_clean_1580(icon)


def _lrs_game_slot_from_item_1580(item: Dict[str, Any], idx: int) -> Dict[str, str]:
    prefix = "RatingSlot{0}_".format(idx)
    source = _lrs_game_clean_1580(item.get(prefix + "Source"))
    icon = _lrs_game_clean_1580(item.get(prefix + "Icon"))
    icon_file = _lrs_game_clean_1580(item.get(prefix + "IconFile"))
    icon_path = _lrs_game_clean_1580(item.get(prefix + "IconPath"))
    label = _lrs_game_clean_1580(item.get(prefix + "Label"))
    value = _lrs_game_clean_1580(item.get(prefix + "Value"))
    if not (source or icon or icon_file or icon_path or label or value):
        return {}
    normalized_icon = _lrs_game_icon_1580(source, label, icon, icon_file)
    icon_file_out = os.path.basename(normalized_icon.replace("\\", "/")) if normalized_icon else ""
    if not icon_path and icon_file_out:
        icon_path = kpm_shared_icon_path_1513(icon_file_out)
    return {
        "Source": source,
        "Icon": normalized_icon,
        "IconFile": icon_file_out,
        "IconPath": icon_path,
        "Label": label,
        "Value": value,
    }


def _lrs_game_fallback_slots_1580(item: Dict[str, Any]) -> List[Dict[str, str]]:
    slots: List[Dict[str, str]] = []
    steam_percent = _lrs_game_clean_1580(item.get("steam_review_percent"))
    steam_desc = _lrs_game_clean_1580(item.get("steam_review_desc"))
    if steam_percent or steam_desc:
        value = steam_percent
        if value and value.isdigit():
            value = value + "%"
        slots.append({"Source": "Steam", "Icon": "steam.png", "IconFile": "steam.png", "IconPath": kpm_shared_icon_path_1513("steam.png"), "Label": steam_desc or value, "Value": value or steam_desc})
    unlocked = _lrs_game_clean_1580(item.get("achievement_unlocked"))
    total = _lrs_game_clean_1580(item.get("achievement_total"))
    if unlocked or total:
        value = "{0}/{1}".format(unlocked or "0", total or "0")
        slots.append({"Source": "Achievement", "Icon": "steam-ach.png", "IconFile": "steam-ach.png", "IconPath": kpm_shared_icon_path_1513("steam-ach.png"), "Label": "Achievements", "Value": value})
    meta = _lrs_game_clean_1580(item.get("metacritic_score"))
    if meta:
        slots.append({"Source": "Metacritic", "Icon": "metacritic.png", "IconFile": "metacritic.png", "IconPath": kpm_shared_icon_path_1513("metacritic.png"), "Label": meta, "Value": meta})
    return slots[:6]


def lrs_game_rating_slots(item: Dict[str, Any]) -> List[Dict[str, str]]:
    slots: List[Dict[str, str]] = []
    for idx in range(1, 8):
        row = _lrs_game_slot_from_item_1580(item or {}, idx)
        if row:
            slots.append(row)
    if not slots:
        slots = _lrs_game_fallback_slots_1580(item or {})
    return slots[:6]


def af3_values_for_game_item(item: Dict[str, Any]) -> Dict[str, str]:
    item = dict(item or {})
    values: Dict[str, str] = {
        "HasData": "true",
        "DBType": "game",
        "Title": _lrs_game_clean_1580(item.get("title") or item.get("Title") or item.get("label") or item.get("Label")),
        "Year": _lrs_game_clean_1580(item.get("year")),
        "Source": "plugin.video.mediahub.widget",
        "Game": "true",
        "LRS_Game": "true",
        "Steam_AppID": _lrs_game_clean_1580(item.get("steam_appid")),
        "Steam_ReviewPercent": _lrs_game_clean_1580(item.get("steam_review_percent")),
        "Steam_ReviewDesc": _lrs_game_clean_1580(item.get("steam_review_desc")),
        "Steam_ReviewTotal": _lrs_game_clean_1580(item.get("steam_review_total")),
        "Metacritic_Score": _lrs_game_clean_1580(item.get("metacritic_score")),
        "Achievement_Unlocked": _lrs_game_clean_1580(item.get("achievement_unlocked")),
        "Achievement_Total": _lrs_game_clean_1580(item.get("achievement_total")),
        "Completed": _lrs_game_clean_1580(item.get("completed")),
        "Finished": _lrs_game_clean_1580(item.get("finished")),
    }
    slots = lrs_game_rating_slots(item)
    for idx in range(1, 8):
        row = slots[idx - 1] if idx <= len(slots) else {}
        values["RatingSlot{0}_Source".format(idx)] = _lrs_game_clean_1580(row.get("Source"))
        values["RatingSlot{0}_Icon".format(idx)] = _lrs_game_clean_1580(row.get("Icon"))
        values["RatingSlot{0}_IconFile".format(idx)] = _lrs_game_clean_1580(row.get("IconFile"))
        values["RatingSlot{0}_IconPath".format(idx)] = _lrs_game_clean_1580(row.get("IconPath"))
        values["RatingSlot{0}_Label".format(idx)] = _lrs_game_clean_1580(row.get("Label"))
        values["RatingSlot{0}_Value".format(idx)] = _lrs_game_clean_1580(row.get("Value"))
    values.update(lrs_display_flags())
    values["Display_RatingSlots"] = "true"
    return {key: str(value) for key, value in values.items() if value not in (None, "")}


_lrs_game_extra_names_1580 = [
    "Game", "LRS_Game", "Steam_AppID", "Steam_ReviewPercent", "Steam_ReviewDesc", "Steam_ReviewTotal",
    "Metacritic_Score", "Achievement_Unlocked", "Achievement_Total", "Completed", "Finished",
]
for _idx_1580 in range(1, 8):
    for _suffix_1580 in ("Source", "Icon", "IconFile", "IconPath", "Label", "Value"):
        _lrs_game_extra_names_1580.append("RatingSlot{0}_{1}".format(_idx_1580, _suffix_1580))
LRS_EXTRA_PROPERTY_NAMES = tuple(dict.fromkeys(tuple(LRS_EXTRA_PROPERTY_NAMES) + tuple(_lrs_game_extra_names_1580)))

# -----------------------------------------------------------------------------
# v1.5.9 - service-scoped AF3 publisher for MediaHub game passthrough
# -----------------------------------------------------------------------------
# Game items already render their own metadata/rating row in MediaHub home/hub.
# For games LRS must feed the screensaver bridge without also populating
# LibraryRatings.ListItem.* / Player.* / VideoPlayer.*, otherwise AF3 home/hub
# draws a second rating row under the plot. Movie/TV/episode keeps using the
# normal publish_af3_properties() path above.
def publish_af3_properties_for_services(values: Dict[str, str], item_identity: str = "", compatibility: bool = True, services: Any = None) -> None:
    published = dict(values or {})
    published["ItemKey"] = item_identity
    display_flags = lrs_display_flags()
    published.update(display_flags)
    services = tuple(services or ("Screensaver",))
    property_names = tuple(dict.fromkeys(tuple(AF3_PROPERTY_NAMES) + tuple(LRS_EXTRA_PROPERTY_NAMES) + tuple(display_flags.keys())))
    compat = bool(compatibility and tmdbhelper_compat_enabled())
    for window in _publish_windows():
        for name, value in display_flags.items():
            _publish_property(window, AF3_PREFIX + "Display." + name.replace("Display_", ""), str(value))
        for service in services:
            for name in property_names:
                value = str(published.get(name, "") or "")
                _publish_property(window, AF3_PREFIX + service + "." + name, value)
                if compat:
                    _publish_property(window, TMDBHELPER_PREFIX + service + "." + name, value)


def clear_af3_services(services: Any = None, compatibility: bool = True) -> None:
    publish_af3_properties_for_services({}, "", compatibility, tuple(services or ("ListItem", "Player", "VideoPlayer")))



# -----------------------------------------------------------------------------
# v1.5.11-base159 - MediaHub/Steam game screensaver CropV2 clearlogo bridge
# -----------------------------------------------------------------------------
# Base: v1.5.9 game screensaver-only publish. This patch does not include the
# v1.5.10 home/library achievement bridge. Movies/TV keep the existing
# TMDbHelper CropV2 resolver; game items only add extra game clearlogo/property
# candidates before using the same crop_v2 local hash resolver.
CACHE_VERSION = max(CACHE_VERSION, 34)
_update_screensaver_clearlogo_properties_15110_base159_base = update_screensaver_clearlogo_properties


def _lrs_dedupe_15110_base159(values: Any) -> List[str]:
    out: List[str] = []
    for value in values or []:
        value = str(value or "").strip()
        if value and value not in out:
            out.append(value)
    return out


def _lrs_get_infolabel_15110_base159(label: str) -> str:
    try:
        return xbmc.getInfoLabel(label).strip()
    except Exception:  # pylint: disable=broad-except
        return ""


def _lrs_item_value_variants_15110_base159(item: Dict[str, Any], *names: str) -> List[str]:
    item = item or {}
    vals: List[str] = []
    for name in names:
        for key in (name, name.lower(), name.upper(), name[:1].upper() + name[1:] if name else name):
            try:
                vals.append(str(item.get(key) or "").strip())
            except Exception:  # pylint: disable=broad-except
                pass
    return _lrs_dedupe_15110_base159(vals)


def _lrs_game_crop_direct_candidates_15110_base159(item: Dict[str, Any], item_title: str) -> List[Dict[str, str]]:
    """CropV2 paths already published directly on the current game item."""
    candidates: List[Dict[str, str]] = []
    keys = (
        "CropV2Image", "CropImage.CropV2", "CropImage", "cropv2", "crop_v2",
        "lrs_cropv2_image", "LRS_CropV2Image", "clearlogo_cropv2", "clearlogo_crop_v2",
    )
    for key in keys:
        for value in _lrs_item_value_variants_15110_base159(item, key):
            candidates.append({"source": "game_item." + key, "image": value, "title": item_title})
        candidates.append({
            "source": "Container(1297).ListItem.Property({0})".format(key),
            "image": _lrs_get_infolabel_15110_base159("Container(1297).ListItem.Property({0})".format(key)),
            "title": item_title,
        })
        candidates.append({
            "source": "ListItem.Property({0})".format(key),
            "image": _lrs_get_infolabel_15110_base159("ListItem.Property({0})".format(key)),
            "title": item_title,
        })
        candidates.append({
            "source": "Window(Home).Property(LRS.Active.{0})".format(key),
            "image": _any_window_property("LRS.Active.{0}".format(key), "LRS.Active.{0}".format(key.lower())),
            "title": item_title,
        })
    out: List[Dict[str, str]] = []
    seen = set()
    for cand in candidates:
        image = str(cand.get("image") or "").strip()
        if not image or image in seen:
            continue
        seen.add(image)
        out.append({
            "source": str(cand.get("source") or "game_direct"),
            "image": image,
            "title": str(cand.get("title") or item_title or ""),
        })
    return out


def _lrs_game_logo_candidates_15110_base159(item: Dict[str, Any]) -> List[str]:
    """Clearlogo inputs used by the existing TMDbHelper crop_v2 hash resolver."""
    vals: List[str] = []
    vals.extend(_lrs_item_value_variants_15110_base159(
        item,
        "clearlogo", "clearlogo_url", "clear_logo", "clear_logo_url",
        "ClearLogo", "ClearLogoUrl", "logo", "logo_url", "Logo", "LogoUrl",
        "Art(clearlogo)", "art_clearlogo", "art.clearlogo",
    ))
    # Screensaver container is the source of truth while Arctic Mirage is active.
    for label in (
        "Container(1297).ListItem.Art(clearlogo)",
        "Container(1297).ListItem.Property(clearlogo)",
        "Container(1297).ListItem.Property(clearlogo_url)",
        "Container(1297).ListItem.Property(ClearLogo)",
        "Container(1297).ListItem.Property(ClearLogoUrl)",
        "Container(1297).ListItem.Property(logo)",
        "Container(1297).ListItem.Property(logo_url)",
        "ListItem.Art(clearlogo)",
        "ListItem.Property(clearlogo)",
        "ListItem.Property(clearlogo_url)",
        "Window(Home).Property(LRS.Active.ClearLogo)",
        "Window(Home).Property(LRS.Active.clearlogo)",
        "Window(Home).Property(LRS.Active.clearlogo_url)",
        "Window(Home).Property(TMDBHelper.ListItem.ClearLogo)",
        "Window(Home).Property(TMDBHelper.ListItem.clearlogo)",
    ):
        vals.append(_lrs_get_infolabel_15110_base159(label))
    return _lrs_dedupe_15110_base159(vals)


def _lrs_choose_game_cropv2_15110_base159(item: Dict[str, Any], item_title: str, default_logo: str) -> Dict[str, str]:
    item_norm = _norm_text(item_title)

    # 1) Same route as movies/series: use TMDbHelper CropImage/CropV2Image when
    # it matches the current screensaver title.
    tmdb_candidates = _tmdbhelper_crop_candidates()
    for cand in tmdb_candidates:
        cand_title = str(cand.get("title") or "").strip()
        if cand.get("image") and item_norm and cand_title and _norm_text(cand_title) == item_norm:
            return cand
    if item_norm and len(tmdb_candidates) == 1 and tmdb_candidates[0].get("image") and not str(tmdb_candidates[0].get("title") or "").strip():
        return tmdb_candidates[0]

    # 2) If MediaHub/Steam item already exposes a CropV2 path, use it.
    direct = _lrs_game_crop_direct_candidates_15110_base159(item, item_title)
    if len(direct) == 1:
        return direct[0]
    for cand in direct:
        cand_title = str(cand.get("title") or "").strip()
        if cand.get("image") and item_norm and (not cand_title or _norm_text(cand_title) == item_norm):
            return cand

    # 3) Same local crop_v2 hash lookup as movie/series, but try all game
    # clearlogo/url candidates instead of only Container(1297).Art(clearlogo).
    logos = _lrs_game_logo_candidates_15110_base159(item)
    if default_logo and default_logo not in logos:
        logos.insert(0, default_logo)
    for logo in logos:
        local = _find_local_cropv2_by_logo_1383(logo)
        if local.get("image"):
            out = dict(local)
            out["title"] = str(out.get("title") or item_title or "")
            if local.get("source"):
                out["source"] = "game_" + str(local.get("source"))
            return out
    return {"image": "", "source": "", "title": ""}


def update_screensaver_clearlogo_properties(item: Dict[str, Any]) -> Dict[str, str]:
    # Non-game path remains exactly the v1.5.9/movie/series resolver.
    if not is_lrs_game_item(item or {}):
        return _update_screensaver_clearlogo_properties_15110_base159_base(item)
    try:
        import xbmcgui  # pylint: disable=import-outside-toplevel
        home = xbmcgui.Window(10000)
    except Exception:
        return {}
    try:
        item_title = str(
            (item or {}).get("title")
            or xbmc.getInfoLabel("Container(1297).ListItem.Title")
            or xbmc.getInfoLabel("Container(1297).ListItem.Label")
            or ""
        ).strip()
    except Exception:
        item_title = str((item or {}).get("title") or "").strip()

    logos = _lrs_game_logo_candidates_15110_base159(item or {})
    default_logo = logos[0] if logos else ""
    chosen = _lrs_choose_game_cropv2_15110_base159(item or {}, item_title, default_logo)

    if chosen.get("image"):
        mode = "cropv2"
        final_image = str(chosen.get("image") or "")
        final_source = str(chosen.get("source") or "game_cropv2")
    elif default_logo:
        mode = "default_kodi"
        final_image = default_logo
        final_source = "game_default_kodi"
    else:
        mode = "title"
        final_image = ""
        final_source = "game_title"

    try:
        item_key = identity_key(item or {})
    except Exception:
        item_key = ""
    props = {
        "CropV2Image": str(chosen.get("image") or ""),
        "CropV2Source": str(chosen.get("source") or ""),
        "CropV2Title": str(chosen.get("title") or ""),
        "DefaultClearLogo": default_logo,
        "ClearLogoMode": mode,
        "ClearLogoFinal": final_image,
        "ClearLogoFinalMode": mode,
        "ClearLogoFinalSource": final_source,
        "ClearLogoFinalTitle": item_title,
        "ClearLogoFinalItemKey": item_key,
    }
    for key, value in props.items():
        _publish_property(home, AF3_PREFIX + "Screensaver." + key, str(value or ""))

    global _LAST_SCREENSAVER_CLEARLOGO_LOG, _LAST_SCREENSAVER_CLEARLOGO_FINAL_LOG
    sig = "game|{0}|{1}|{2}|{3}".format(mode, item_title, final_image, default_logo)
    try:
        if sig != _LAST_SCREENSAVER_CLEARLOGO_FINAL_LOG:
            _LAST_SCREENSAVER_CLEARLOGO_FINAL_LOG = sig
            _LAST_SCREENSAVER_CLEARLOGO_LOG = sig
            _record_screensaver_clearlogo_selection_1541({
                "title": item_title,
                "media_type": "game",
                "item_key": item_key,
                "selected": mode,
                "source": final_source,
                "final_path": final_image,
                "cropv2_path": str(chosen.get("image") or ""),
                "default_path": default_logo,
                "candidate_count": len(logos),
            })
    except Exception:  # pylint: disable=broad-except
        pass
    return props


# -----------------------------------------------------------------------------
# v1.5.12 - unified runtime layout
# -----------------------------------------------------------------------------
# Keep cache DB and Kodi settings.xml at add-on profile root; generated state,
# reports, diagnostics and logs live under runtime/. Diagnostics ZIPs are written
# to the add-on profile root and old ZIPs are removed before each export.
RUNTIME_DIR = os.path.join(PROFILE, "runtime")
STATE_DIR = os.path.join(RUNTIME_DIR, "state")
DIAGNOSTICS_DIR = os.path.join(RUNTIME_DIR, "diagnostics")
REPORTS_DIR = os.path.join(RUNTIME_DIR, "reports")
LOGS_DIR = os.path.join(RUNTIME_DIR, "logs")
EXPORTS_DIR = os.path.join(RUNTIME_DIR, "exports")
for _lrs_dir_1512 in (RUNTIME_DIR, STATE_DIR, DIAGNOSTICS_DIR, REPORTS_DIR, LOGS_DIR, EXPORTS_DIR):
    try:
        os.makedirs(_lrs_dir_1512, exist_ok=True)
    except Exception:
        pass
REPORT_FILE = os.path.join(REPORTS_DIR, "ratings-report.csv")
SUMMARY_FILE = os.path.join(REPORTS_DIR, "last-run-summary.json")
BACKGROUND_REQUEST_FILE = os.path.join(STATE_DIR, "background-job-request.json")
BACKGROUND_CANCEL_FILE = os.path.join(STATE_DIR, "background-job-cancel.json")
BACKGROUND_STATE_FILE = os.path.join(STATE_DIR, "background-job-state.json")
BACKGROUND_FORCE_STOP_FILE = os.path.join(STATE_DIR, "background-job-force-stop.json")
SAMPLE_CHECK_LOG_FILE = os.path.join(LOGS_DIR, "last-random-check-debug.txt")
RT_BADGE_SIMPLE_LOG_FILE = os.path.join(LOGS_DIR, "lrs.log")
RT_BADGE_DETAIL_LOG_FILE = os.path.join(LOGS_DIR, "lrs.log")
RT_BADGE_REPORT_FILE = os.path.join(REPORTS_DIR, "rt-badges-report.csv")
RT_BADGE_LAST_JSON_FILE = os.path.join(REPORTS_DIR, "rt-badge-sync-last.json")
RT_BADGE_NO_SLUG_REPORT_FILE = RT_BADGE_REPORT_FILE
RT_BADGE_BAD_SLUG_404_REPORT_FILE = RT_BADGE_REPORT_FILE
RT_BADGE_BAD_SLUG_MISMATCH_REPORT_FILE = RT_BADGE_REPORT_FILE
RT_BADGE_NOT_FOUND_REPORT_FILE = RT_BADGE_REPORT_FILE
TOP250_SYNC_LAST_FILE_1412 = os.path.join(REPORTS_DIR, "top250-sync-last.json")
TOP250_SYNC_REPORT_FILE_1412 = os.path.join(REPORTS_DIR, "top250-sync-report.csv")
TOP250_LOCAL_SYNC_LAST_FILE_1413 = os.path.join(REPORTS_DIR, "top250-local-sync-last.json")
TOP250_LOCAL_SYNC_REPORT_FILE_1413 = os.path.join(REPORTS_DIR, "top250-local-sync-report.csv")

# v1.5.41 - human-readable screensaver clearlogo diagnostics
SCREENSAVER_CLEARLOGO_REPORT_FILE_1541 = os.path.join(DIAGNOSTICS_DIR, "screensaver-clearlogo-report.txt")
SCREENSAVER_CLEARLOGO_STATE_FILE_1541 = os.path.join(STATE_DIR, "screensaver-clearlogo-history.json")
SCREENSAVER_CLEARLOGO_HISTORY_LIMIT_1541 = 100


def _clearlogo_mode_label_1541(mode: Any) -> str:
    value = str(mode or "").strip().lower()
    return {
        "cropv2": "CropV2 image",
        "default_kodi": "Kodi clearlogo",
        "title": "Text title fallback",
    }.get(value, value or "Unknown")


def _load_screensaver_clearlogo_history_1541() -> Dict[str, Any]:
    try:
        if os.path.exists(SCREENSAVER_CLEARLOGO_STATE_FILE_1541):
            with open(SCREENSAVER_CLEARLOGO_STATE_FILE_1541, "r", encoding="utf-8-sig", errors="replace") as handle:
                payload = json.load(handle)
            if isinstance(payload, dict):
                history = payload.get("history")
                payload["history"] = history if isinstance(history, list) else []
                return payload
    except Exception:
        pass
    return {"history": []}


def _atomic_write_text_1541(path: str, text: str) -> None:
    folder = os.path.dirname(path)
    if folder:
        os.makedirs(folder, exist_ok=True)
    temp = path + ".tmp"
    with open(temp, "w", encoding="utf-8-sig", newline="") as handle:
        handle.write(text)
    os.replace(temp, path)


def _write_screensaver_clearlogo_report_1541(payload: Dict[str, Any]) -> str:
    history = list((payload or {}).get("history") or [])
    current = dict((payload or {}).get("current") or (history[0] if history else {}))
    lines: List[str] = [
        "LRS Screensaver Clearlogo Report",
        "================================",
        "",
        "This report records the clearlogo actually selected for Arctic Mirage.",
        "It is written here instead of kodi.log and is included automatically in Export diagnostics ZIP.",
        "",
        "Report file : runtime/diagnostics/screensaver-clearlogo-report.txt",
        "Updated     : {0}".format(str((payload or {}).get("updated_at") or current.get("timestamp") or "Not recorded")),
        "",
        "CURRENT SELECTION",
        "-----------------",
    ]
    if current:
        lines.extend([
            "Title           : {0}".format(str(current.get("title") or "<untitled>")),
            "Media type      : {0}".format(str(current.get("media_type") or "unknown")),
            "Item key        : {0}".format(str(current.get("item_key") or "<none>")),
            "Selected result : {0}".format(_clearlogo_mode_label_1541(current.get("selected"))),
            "Resolver source : {0}".format(str(current.get("source") or "<none>")),
            "Final path      : {0}".format(str(current.get("final_path") or "<title fallback, no image path>")),
            "CropV2 path     : {0}".format(str(current.get("cropv2_path") or "<none>")),
            "Kodi logo path  : {0}".format(str(current.get("default_path") or "<none>")),
            "Candidates seen : {0}".format(str(current.get("candidate_count") if current.get("candidate_count") not in (None, "") else "unknown")),
            "Recorded at     : {0}".format(str(current.get("timestamp") or "unknown")),
        ])
    else:
        lines.append("No screensaver clearlogo selection has been recorded yet.")
    lines.extend([
        "",
        "RECENT HISTORY (NEWEST FIRST, MAX {0})".format(SCREENSAVER_CLEARLOGO_HISTORY_LIMIT_1541),
        "------------------------------------------",
    ])
    if not history:
        lines.append("No history available.")
    for idx, row in enumerate(history, 1):
        lines.extend([
            "{0}. [{1}] {2}".format(idx, str(row.get("timestamp") or "unknown"), str(row.get("title") or "<untitled>")),
            "   Type / selected : {0} / {1}".format(str(row.get("media_type") or "unknown"), _clearlogo_mode_label_1541(row.get("selected"))),
            "   Source          : {0}".format(str(row.get("source") or "<none>")),
            "   Final path      : {0}".format(str(row.get("final_path") or "<title fallback, no image path>")),
            "   CropV2 path     : {0}".format(str(row.get("cropv2_path") or "<none>")),
            "   Kodi logo path  : {0}".format(str(row.get("default_path") or "<none>")),
            "   Item key        : {0}".format(str(row.get("item_key") or "<none>")),
            "",
        ])
    _atomic_write_text_1541(SCREENSAVER_CLEARLOGO_REPORT_FILE_1541, "\n".join(lines).rstrip() + "\n")
    return SCREENSAVER_CLEARLOGO_REPORT_FILE_1541


def _record_screensaver_clearlogo_selection_1541(entry: Dict[str, Any]) -> str:
    try:
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        os.makedirs(STATE_DIR, exist_ok=True)
        row = {key: str(value or "") for key, value in dict(entry or {}).items() if key != "candidate_count"}
        row["candidate_count"] = int((entry or {}).get("candidate_count") or 0)
        row["timestamp"] = now_iso()
        payload = _load_screensaver_clearlogo_history_1541()
        history = list(payload.get("history") or [])
        signature = "|".join(str(row.get(key) or "") for key in ("item_key", "title", "selected", "source", "final_path", "cropv2_path", "default_path"))
        if not history or signature != str(history[0].get("signature") or ""):
            row["signature"] = signature
            history.insert(0, row)
        else:
            row["signature"] = signature
            history[0] = row
        history = history[:SCREENSAVER_CLEARLOGO_HISTORY_LIMIT_1541]
        payload = {"updated_at": row["timestamp"], "current": row, "history": history}
        _atomic_write_text_1541(SCREENSAVER_CLEARLOGO_STATE_FILE_1541, json.dumps(payload, indent=2, ensure_ascii=False, sort_keys=False) + "\n")
        return _write_screensaver_clearlogo_report_1541(payload)
    except Exception as exc:
        try:
            lines = [
                "LRS Screensaver Clearlogo Report",
                "================================",
                "",
                "The screensaver clearlogo recorder failed.",
                "This error is stored here instead of kodi.log.",
                "",
                "Error type : {0}".format(type(exc).__name__),
                "Error      : {0}".format(str(exc) or "<no message>"),
                "Recorded   : {0}".format(now_iso()),
            ]
            _atomic_write_text_1541(
                SCREENSAVER_CLEARLOGO_REPORT_FILE_1541,
                "\n".join(lines).rstrip() + "\n"
            )
        except Exception:
            pass
        return ""


def record_screensaver_clearlogo_from_props_1543(item: Dict[str, Any], props: Dict[str, Any]) -> str:
    """Persist the clearlogo decision returned by the active resolver.

    Called by service.py after every active screensaver item resolution. This
    avoids relying only on internal resolver wrappers, which could be bypassed
    by compatibility layers.
    """
    data = dict(props or {})
    source_item = dict(item or {})
    try:
        item_key = str(
            data.get("ClearLogoFinalItemKey")
            or identity_key(source_item)
            or ""
        )
    except Exception:
        item_key = str(data.get("ClearLogoFinalItemKey") or "")

    title = str(
        data.get("ClearLogoFinalTitle")
        or source_item.get("title")
        or source_item.get("label")
        or ""
    ).strip()

    media_type = "game" if is_lrs_game_item(source_item) else str(
        source_item.get("type")
        or source_item.get("DBTYPE")
        or source_item.get("dbtype")
        or "video"
    )

    entry = {
        "title": title,
        "media_type": media_type,
        "item_key": item_key,
        "selected": str(data.get("ClearLogoFinalMode") or data.get("ClearLogoMode") or "title"),
        "source": str(data.get("ClearLogoFinalSource") or ""),
        "final_path": str(data.get("ClearLogoFinal") or ""),
        "cropv2_path": str(data.get("CropV2Image") or ""),
        "default_path": str(data.get("DefaultClearLogo") or ""),
        "candidate_count": int(data.get("CandidateCount") or 0),
    }
    return _record_screensaver_clearlogo_selection_1541(entry)


def _ensure_screensaver_clearlogo_report_1541() -> str:
    try:
        payload = _load_screensaver_clearlogo_history_1541()
        if not payload.get("current") and payload.get("history"):
            payload["current"] = payload["history"][0]
        payload.setdefault("updated_at", str((payload.get("current") or {}).get("timestamp") or now_iso()))
        return _write_screensaver_clearlogo_report_1541(payload)
    except Exception:
        return ""


def _read_text_file_1500(path: str) -> str:
    try:
        return _read_text_file_1410(path)
    except Exception:
        with open(path, "r", encoding="utf-8-sig", errors="replace") as handle:
            return handle.read()


def _redact_text_1500(text: str) -> str:
    return _redact_diagnostic_text_1500(text)


def _is_text_diag_1500(path: str) -> bool:
    return _diagnostic_text_file_1500(path)

def _diagnostic_files_1500() -> List[str]:
    """Return diagnostics files for the runtime-v1 exporter.

    v1.5.33 moved diagnostics into runtime/ but the final exporter still
    called this helper after it had been removed by the clean-data-owner pass.
    Keep this helper intentionally broad and safe: include existing candidates,
    runtime state/log/report files, settings.xml, and the ratings cache DB.
    """
    files: List[str] = []
    def _add(path: Any) -> None:
        try:
            if not path:
                return
            apath = os.path.abspath(str(path))
            if os.path.exists(apath) and apath not in files:
                files.append(apath)
        except Exception:
            pass
    try:
        for path in _diagnostic_candidates_1397():
            _add(path)
    except Exception:
        pass
    for path in (
        os.path.join(PROFILE, "settings.xml"),
        CACHE_DB_FILE,
        REPORT_FILE,
        SUMMARY_FILE,
        BACKGROUND_REQUEST_FILE,
        BACKGROUND_CANCEL_FILE,
        BACKGROUND_STATE_FILE,
        BACKGROUND_FORCE_STOP_FILE,
        SAMPLE_CHECK_LOG_FILE,
        RT_BADGE_SIMPLE_LOG_FILE,
        RT_BADGE_REPORT_FILE,
        RT_BADGE_LAST_JSON_FILE,
        TOP250_SYNC_LAST_FILE_1412,
        TOP250_SYNC_REPORT_FILE_1412,
        TOP250_LOCAL_SYNC_LAST_FILE_1413,
        TOP250_LOCAL_SYNC_REPORT_FILE_1413,
    ):
        _add(path)
    for folder in (STATE_DIR, DIAGNOSTICS_DIR, REPORTS_DIR, LOGS_DIR):
        try:
            if os.path.isdir(folder):
                for name in os.listdir(folder):
                    if name.startswith("lrs-diagnostics-") and name.endswith(".zip"):
                        continue
                    _add(os.path.join(folder, name))
        except Exception:
            pass
    return files

_export_diagnostics_zip_1512_base = export_diagnostics_zip_1397
def export_diagnostics_zip_1397() -> str:
    import zipfile  # pylint: disable=import-outside-toplevel
    for folder in (STATE_DIR, DIAGNOSTICS_DIR, REPORTS_DIR, LOGS_DIR, EXPORTS_DIR):
        try:
            os.makedirs(folder, exist_ok=True)
        except Exception:
            pass
    try:
        _write_lrs_diagnostic_heartbeat_1560("diagnostics export requested")
        _write_lrs_log_status_1560("diagnostics export requested")
    except Exception:
        pass
    try:
        _ensure_screensaver_clearlogo_report_1541()
    except Exception:
        pass
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    for _name_1512 in os.listdir(PROFILE) if os.path.isdir(PROFILE) else []:
        if _name_1512.startswith("lrs-diagnostics-") and _name_1512.endswith(".zip"):
            try:
                os.remove(os.path.join(PROFILE, _name_1512))
            except Exception:
                pass
    for _zip_dir_1567 in (DIAGNOSTICS_DIR, EXPORTS_DIR):
        try:
            for _zip_name_1567 in os.listdir(_zip_dir_1567):
                if _zip_name_1567.startswith("lrs-diagnostics-") and _zip_name_1567.endswith(".zip"):
                    os.remove(os.path.join(_zip_dir_1567, _zip_name_1567))
        except Exception:
            pass
    zip_path = os.path.join(PROFILE, "lrs-diagnostics-{0}.zip".format(stamp))
    files = _diagnostic_files_1500()
    try:
        report = export_csv(load_cache())
        if report and os.path.exists(report) and report not in files:
            files.append(report)
    except Exception:
        pass
    with zipfile.ZipFile(zip_path, "w", zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps({"addon_id": ADDON_ID, "addon_name": ADDON.getAddonInfo("name"), "created_at": now_iso(), "zip_layout": "runtime-v1"}, indent=2) + "\n")
        for path in files:
            try:
                apath = os.path.abspath(path)
                if apath == os.path.abspath(zip_path) or not os.path.exists(apath):
                    continue
                base = os.path.basename(apath)
                if apath.startswith(os.path.abspath(STATE_DIR)):
                    arc = "runtime/state/" + base
                elif apath.startswith(os.path.abspath(REPORTS_DIR)):
                    arc = "runtime/reports/" + base
                elif apath.startswith(os.path.abspath(LOGS_DIR)):
                    arc = "runtime/logs/" + base
                elif apath.startswith(os.path.abspath(DIAGNOSTICS_DIR)):
                    arc = "runtime/diagnostics/" + base
                elif apath == os.path.abspath(os.path.join(PROFILE, "settings.xml")):
                    arc = "summary/settings.xml"
                elif apath == os.path.abspath(CACHE_DB_FILE):
                    arc = "profile/" + base
                else:
                    arc = "profile/" + base
                if _is_text_diag_1500(apath):
                    zf.writestr(arc, _redact_text_1500(_read_text_file_1500(apath)))
                else:
                    zf.write(apath, arc)
            except Exception as exc:  # pylint: disable=broad-except
                try:
                    zf.writestr("summary/include-error-{}.txt".format(base), str(exc))
                except Exception:
                    pass
    return zip_path


# -----------------------------------------------------------------------------
# v1.5.15 - KPM-only icon subfolder policy
# -----------------------------------------------------------------------------
# The AF3/LRS icon textbox no longer means a folder under the skin AF3 ratings
# directory. It now means an optional subfolder under KPM shared-icons:
#   special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/<textbox>/
# If the textbox is empty, the KPM shared-icons root is used directly.

KPM_SHARED_ICON_SPECIAL_ROOT_1515 = "special://home/addons/script.kodi.patch.manager/resources/media/shared-icons"


def sanitize_af3_icon_folder_1410(value: Any) -> str:
    text = str(value or "").strip().replace("\\", "/").strip()
    if not text:
        return ""
    # Keep only the last segment so the textbox cannot escape the KPM icon root.
    text = text.split("/")[-1].strip()
    text = re.sub(r"[^A-Za-z0-9_.-]+", "", text)
    text = text.strip(". ")
    return text


def af3_icon_folder_1410() -> str:
    try:
        return sanitize_af3_icon_folder_1410(ADDON.getSetting("af3_icon_folder") or "")
    except Exception:
        return ""


def set_af3_icon_folder_1410(value: Any) -> str:
    folder = sanitize_af3_icon_folder_1410(value)
    try:
        ADDON.setSetting("af3_icon_folder", folder)
    except Exception:
        pass
    return folder


def kpm_shared_icon_special_base_1515(folder: Optional[str] = None) -> str:
    folder = sanitize_af3_icon_folder_1410(af3_icon_folder_1410() if folder is None else folder)
    base = KPM_SHARED_ICON_SPECIAL_ROOT_1515
    return base + ("/" + folder if folder else "")


def kpm_shared_icon_dir_1513() -> str:
    try:
        return xbmcvfs.translatePath(KPM_SHARED_ICON_SPECIAL_ROOT_1515)
    except Exception:
        return ""


def kpm_shared_icon_target_dir_1515(folder: Optional[str] = None) -> str:
    try:
        return xbmcvfs.translatePath(kpm_shared_icon_special_base_1515(folder))
    except Exception:
        return ""


def kpm_shared_icon_path_1513(filename: str) -> str:
    filename = os.path.basename(str(filename or "").strip())
    if not filename:
        return kpm_shared_icon_special_base_1515()
    return kpm_shared_icon_special_base_1515() + "/" + filename


def af3_icon_relative_1410(filename: str) -> str:
    return kpm_shared_icon_path_1513(filename)


def _kpm_icon_filename_from_token_1515(token: str) -> str:
    token = str(token or "").strip().replace("\\", "/")
    if not token:
        return ""
    # Old values can be KPM shared-icons path or a direct filename. Only keep the filename.
    return os.path.basename(token)


def _af3_normalize_icon_token_1411(token: str, folder: str) -> str:
    filename = _kpm_icon_filename_from_token_1515(token)
    if not filename:
        return str(token or "")
    return kpm_shared_icon_special_base_1515(folder) + "/" + filename


def _af3_rewrite_rating_icon_paths_1411(text: str, folder: str) -> Tuple[str, int]:
    folder = sanitize_af3_icon_folder_1410(folder)
    count = 0

    def repl(match: Any) -> str:
        nonlocal count
        old = match.group(0)
        token = match.group(1)
        new = _af3_normalize_icon_token_1411(token, folder)
        if new != old:
            count += 1
        return new

    new = _AF3_RATING_PATH_RE_1411.sub(repl, text or "")

    def prop_repl(match: Any) -> str:
        nonlocal count
        file_name = match.group(2)
        replacement = kpm_shared_icon_special_base_1515(folder) + "/" + file_name
        if replacement != match.group(0):
            count += 1
        return replacement

    new2 = _AF3_PROP_ICON_RE_1411.sub(prop_repl, new)
    return new2, count


def _af3_count_root_rating_icon_refs_1411(text: str, folder: str) -> int:
    # Remaining old skin-relative AF3 rating icon paths that were not normalized
    # to KPM shared-icons.
    return len(list(_AF3_RATING_PATH_RE_1411.finditer(text or "")))


def af3_copy_kpm_shared_icons_1514(folder: Optional[str] = None) -> Dict[str, Any]:
    """Copy every PNG from KPM shared-icons root into KPM shared-icons/<folder>.

    If <folder> is blank, no extra folder is created and the KPM shared-icons root
    is used as the target/default. Nothing is copied into the skin AF3 directory.
    """
    folder = sanitize_af3_icon_folder_1410(folder if folder is not None else af3_icon_folder_1410())
    src_dir = kpm_shared_icon_dir_1513()
    target_dir = kpm_shared_icon_target_dir_1515(folder)
    result: Dict[str, Any] = {
        "folder": folder,
        "using_default_kpm_root": not bool(folder),
        "source": src_dir,
        "target": target_dir,
        "target_special": kpm_shared_icon_special_base_1515(folder),
        "copied": 0,
        "created": 0,
        "files": [],
        "targets": [target_dir] if target_dir else [],
        "missing_source": False,
    }
    if not src_dir or not os.path.isdir(src_dir):
        result["missing_source"] = True
        result["error"] = "KPM shared icon folder not found"
        return result
    icon_names = sorted([name for name in os.listdir(src_dir) if name.lower().endswith(".png") and os.path.isfile(os.path.join(src_dir, name))])
    result["files"] = icon_names
    if not folder:
        # Blank textbox means use the KPM root directly. Do not copy root files to
        # themselves and do not create any AF3 skin folder.
        return result
    try:
        if not os.path.isdir(target_dir):
            os.makedirs(target_dir, exist_ok=True)
            result["created"] += 1
        for icon in icon_names:
            src = os.path.join(src_dir, icon)
            dst = os.path.join(target_dir, icon)
            if _copy_file_if_possible_1410(src, dst):
                result["copied"] += 1
    except Exception as exc:  # pylint: disable=broad-except
        result["error"] = str(exc)
    return result


def af3_prepare_icon_folder_1410(folder: Optional[str] = None) -> Dict[str, Any]:
    return af3_copy_kpm_shared_icons_1514(folder)


def af3_update_icon_folder_in_xml_1410(folder: Optional[str] = None) -> Dict[str, Any]:
    """Rewrite AF3 XML icon paths to the selected KPM shared-icons path.

    No icons are copied into media/flags/<color>/ratings/LRS_AF3. The optional
    textbox only creates/uses a subfolder inside KPM shared-icons.
    """
    folder = sanitize_af3_icon_folder_1410(folder if folder is not None else af3_icon_folder_1410())
    set_af3_icon_folder_1410(folder)
    base = af3_skin_1080i_path_1470()
    icon_copy = af3_prepare_icon_folder_1410(folder)
    result: Dict[str, Any] = {
        "folder": folder,
        "kpm_icon_path": kpm_shared_icon_special_base_1515(folder),
        "files_checked": 0,
        "files_updated": 0,
        "references_updated": 0,
        "root_references_remaining": 0,
        "icons": icon_copy,
        "files": {},
    }
    targets = ["Includes_Info.xml", "screensaver-arctic-mirage.xml", "Includes_Hubs.xml"]
    for name in targets:
        path = os.path.join(base, name)
        row: Dict[str, Any] = {"path": path, "exists": os.path.exists(path), "updated": False, "references_updated": 0, "root_references_remaining": 0}
        if not row["exists"]:
            result["files"][name] = row
            continue
        result["files_checked"] += 1
        old = _read_text_file_1410(path)
        if not old:
            result["files"][name] = row
            continue
        new, ref_count = _af3_rewrite_rating_icon_paths_1411(old, folder)
        row["references_updated"] = ref_count
        result["references_updated"] += ref_count
        if new != old:
            _backup_once_1410(path, ".lrs1515-kpm-iconpath.bak")
            _write_text_file_1410(path, new)
            row["updated"] = True
            result["files_updated"] += 1
        row["root_references_remaining"] = _af3_count_root_rating_icon_refs_1411(new, folder)
        result["root_references_remaining"] += int(row.get("root_references_remaining") or 0)
        result["files"][name] = row
    return result


_af3_values_kpm_1515_base = af3_values


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    values = _af3_values_kpm_1515_base(record)
    bp = str(values.get("Oscar_BestPicture") or values.get("OscarBestPicture") or "").lower() == "true"
    if bp:
        icon = kpm_shared_icon_path_1513("oscars_bp.png")
        values["Oscar_BestPictureIcon"] = icon
        values["OscarBestPictureIcon"] = icon
        values["Oscar_Icon"] = icon
        values["OscarIcon"] = icon
    elif values.get("Oscar_Icon") or values.get("OscarIcon"):
        icon = kpm_shared_icon_path_1513("oscars.png")
        values["Oscar_Icon"] = icon
        values["OscarIcon"] = icon
    return values


def af3_integration_status_1470() -> Dict[str, Any]:
    base = af3_skin_1080i_path_1470()
    folder = af3_icon_folder_1410()
    kpm_path = kpm_shared_icon_special_base_1515(folder)
    checks: Dict[str, Any] = {"skin_1080i": base, "icon_folder": folder, "kpm_icon_path": kpm_path, "files": {}, "ok": True}
    targets = {
        "Includes_Info.xml": ["LRS_Info_Meta_Ratings", "LibraryRatings.ListItem", "LRS_ListItem_Oscar_Icon_Texture", kpm_path],
        "Includes_Hubs.xml": ["LRS-AF3-ACTIVE-BRIDGE", "LRS.Active.ContainerID"],
        "screensaver-arctic-mirage.xml": ["LibraryRatings.Screensaver", "ClearLogoFinal", "AFM-CLEARLOGO-FINAL-LRS", "LRS-OSCAR-BP-SCREENSAVER-START", kpm_path],
    }
    for filename, markers in targets.items():
        path = os.path.join(base, filename)
        row = {"path": path, "exists": os.path.exists(path), "markers": {}, "root_rating_icon_refs": 0}
        text = _read_text_file_1410(path) if row["exists"] else ""
        for marker in markers:
            row["markers"][marker] = bool(marker in text)
        if filename in ("Includes_Info.xml", "screensaver-arctic-mirage.xml"):
            row["root_rating_icon_refs"] = _af3_count_root_rating_icon_refs_1411(text, folder)
        row["ok"] = bool(row["exists"] and all(row["markers"].values()) and int(row.get("root_rating_icon_refs") or 0) == 0)
        if not row["ok"]:
            checks["ok"] = False
        checks["files"][filename] = row
    return checks


def af3_integration_status_text_1470() -> str:
    status = af3_integration_status_1470()
    folder = status.get("icon_folder") or ""
    lines = [
        "AF3 integration status",
        "Skin 1080i: {0}".format(status.get("skin_1080i")),
        "KPM icon path: {0}".format(status.get("kpm_icon_path") or kpm_shared_icon_special_base_1515(folder)),
        "KPM icon subfolder: {0}".format(folder or "<default KPM root>"),
        "Overall: {0}".format("OK" if status.get("ok") else "NEEDS PATCH/CHECK"),
        "",
    ]
    for filename, row in (status.get("files") or {}).items():
        lines.append(filename + ": " + ("OK" if row.get("ok") else "NOT OK"))
        lines.append("  exists: {0}".format("YES" if row.get("exists") else "NO"))
        for marker, ok in (row.get("markers") or {}).items():
            lines.append("  {0}: {1}".format(marker, "YES" if ok else "NO"))
        if filename in ("Includes_Info.xml", "screensaver-arctic-mirage.xml"):
            lines.append("  old AF3 rating icon paths remaining: {0}".format(row.get("root_rating_icon_refs", 0)))
    return "\n".join(lines)


def run_af3_patch_tool_1470(mode: str = "status") -> Dict[str, Any]:
    mode = str(mode or "status").lower()
    if mode in ("status", "check"):
        return {"ok": bool(af3_integration_status_1470().get("ok")), "mode": mode, "output": af3_integration_status_text_1470(), "error": ""}
    if mode in ("apply", "patch"):
        used_fallback = False
        out = []
        try:
            base_path = af3_skin_1080i_path_1470()
            info_text = _read_text_file_1410(os.path.join(base_path, "Includes_Info.xml"))
            hubs_text = _read_text_file_1410(os.path.join(base_path, "Includes_Hubs.xml"))
            ss_text = _read_text_file_1410(os.path.join(base_path, "screensaver-arctic-mirage.xml"))
            need_fallback = not ("LibraryRatings.ListItem" in info_text and "LRS-AF3-ACTIVE-BRIDGE" in hubs_text and "LibraryRatings.Screensaver" in ss_text)
        except Exception:
            need_fallback = True
        if need_fallback:
            ps = _run_af3_powershell_hidden_1410("apply")
            used_fallback = True
            out.append((ps.get("output") or ps.get("error") or "PowerShell fallback completed.").strip())
            if not ps.get("ok"):
                return {"ok": False, "mode": mode, "output": "\n".join(out), "error": ps.get("error") or "AF3 fallback patch failed"}
        icon_result = af3_update_icon_folder_in_xml_1410()
        status_after = af3_integration_status_1470()
        icons = icon_result.get("icons") or {}
        out.append("AF3 integration updated.")
        out.append("KPM icon path: {0}".format(icon_result.get("kpm_icon_path") or kpm_shared_icon_special_base_1515()))
        out.append("KPM icon subfolder: {0}".format((icon_result.get("folder") or "") or "<default KPM root>"))
        out.append("XML files updated: {0}".format(icon_result.get("files_updated", 0)))
        if icons.get("using_default_kpm_root"):
            out.append("Icon target: default KPM shared-icons root")
        else:
            out.append("KPM icons copied: {0} file copy operations into {1}".format(icons.get("copied", 0), icons.get("target_special") or icons.get("target") or ""))
        if used_fallback:
            out.append("Full patch fallback: used silently")
        return {"ok": bool(status_after.get("ok")), "mode": mode, "output": "\n".join([x for x in out if x]), "error": "" if status_after.get("ok") else "AF3 status still needs check"}
    if mode in ("remove", "restore"):
        return _run_af3_powershell_hidden_1410("remove")
    return {"ok": False, "mode": mode, "output": "", "error": "Unknown AF3 patch mode"}

# -----------------------------------------------------------------------------
# v1.5.19 - Home/Hub anti-game guard for LRS movie/TV row
# -----------------------------------------------------------------------------
# Home/Hub game metadata is read directly from the current ListItem by the Steam
# Library patch. LRS movie/TV metadata is published asynchronously in
# Window(Home).Property(LibraryRatings.ListItem.*). During a fast movie -> game
# focus change the old movie properties can still exist for a frame. The skin
# must therefore hide the LRS ListItem row immediately when the current item is a
# game, instead of waiting for the LRS service clear pass.

LRS_HOMEHUB_GAME_GUARD_MARKER_1519 = "LRS-HOMEHUB-GAME-GUARD-1519"


def af3_homehub_game_guard_expr_1519() -> str:
    item = "$PARAM[container]$PARAM[listitem]"
    return " + ".join([
        "String.IsEmpty({0}.Property(platform))".format(item),
        "!String.IsEqual({0}.Property(lrs_game),true)".format(item),
        "!String.IsEqual({0}.Property(lrs_item_type),game)".format(item),
        "!String.IsEqual({0}.Property(lrs_media_type),game)".format(item),
        "!String.IsEqual({0}.Property(library_ratings_type),game)".format(item),
        "!String.IsEqual({0}.Property(mediahub_type),game)".format(item),
        "!String.IsEqual({0}.Property(DBTYPE),game)".format(item),
        "!String.IsEqual({0}.Property(dbtype),game)".format(item),
        "!String.IsEqual({0}.Property(MediaType),game)".format(item),
        "!String.IsEqual({0}.Property(mediatype),game)".format(item),
        "!String.IsEqual({0}.DBType,game)".format(item),
    ])


def _lrs_add_guard_to_visible_param_1519(match: Any) -> str:
    prefix = match.group(1)
    visible = (match.group(2) or "").strip()
    suffix = match.group(3)
    block_tail = match.group(4)
    if LRS_HOMEHUB_GAME_GUARD_MARKER_1519 in visible or LRS_HOMEHUB_GAME_GUARD_MARKER_1519 in block_tail:
        return match.group(0)
    guard = af3_homehub_game_guard_expr_1519()
    # Group the original condition so old OR branches cannot bypass the game guard.
    new_visible = "[{0}] + [{1}]".format(visible or "true", guard)
    marker = "\n            <!-- {0} -->".format(LRS_HOMEHUB_GAME_GUARD_MARKER_1519)
    return prefix + new_visible + suffix + marker + block_tail


def af3_apply_homehub_game_guard_1519() -> Dict[str, Any]:
    base = af3_skin_1080i_path_1470()
    path = os.path.join(base, "Includes_Info.xml") if base else ""
    result: Dict[str, Any] = {"path": path, "exists": False, "updated": False, "count": 0, "marker": LRS_HOMEHUB_GAME_GUARD_MARKER_1519}
    if not path or not os.path.exists(path):
        return result
    result["exists"] = True
    old = _read_text_file_1410(path)
    if not old:
        return result
    pattern = re.compile(
        r'(<include\s+content="LRS_Info_Meta_Ratings"[^>]*>.*?<param\s+name="visible">)(.*?)(</param>)(.*?</include>)',
        re.I | re.S,
    )
    new, count = pattern.subn(_lrs_add_guard_to_visible_param_1519, old)
    result["count"] = count
    if new != old:
        _backup_once_1410(path, ".lrs1519-homehub-game-guard.bak")
        _write_text_file_1410(path, new)
        result["updated"] = True
    result["has_guard"] = LRS_HOMEHUB_GAME_GUARD_MARKER_1519 in new
    return result


_af3_update_icon_folder_in_xml_1519_prev = af3_update_icon_folder_in_xml_1410


def af3_update_icon_folder_in_xml_1410(folder: Optional[str] = None) -> Dict[str, Any]:
    result = _af3_update_icon_folder_in_xml_1519_prev(folder)
    try:
        guard = af3_apply_homehub_game_guard_1519()
        result["homehub_game_guard"] = guard
        if guard.get("updated"):
            result["files_updated"] = int(result.get("files_updated") or 0) + 1
    except Exception as exc:  # pylint: disable=broad-except
        result["homehub_game_guard"] = {"error": str(exc), "updated": False}
    return result


_af3_integration_status_1519_prev = af3_integration_status_1470


def af3_integration_status_1470() -> Dict[str, Any]:
    status = _af3_integration_status_1519_prev()
    try:
        base = af3_skin_1080i_path_1470()
        path = os.path.join(base, "Includes_Info.xml") if base else ""
        text = _read_text_file_1410(path) if path and os.path.exists(path) else ""
        has_guard = LRS_HOMEHUB_GAME_GUARD_MARKER_1519 in text
        status["homehub_game_guard"] = {"path": path, "ok": bool(has_guard), "marker": LRS_HOMEHUB_GAME_GUARD_MARKER_1519}
        if not has_guard:
            status["ok"] = False
    except Exception as exc:  # pylint: disable=broad-except
        status["homehub_game_guard"] = {"ok": False, "error": str(exc)}
        status["ok"] = False
    return status


_af3_integration_status_text_1519_prev = af3_integration_status_text_1470


def af3_integration_status_text_1470() -> str:
    text = _af3_integration_status_text_1519_prev()
    status = af3_integration_status_1470()
    guard = status.get("homehub_game_guard") or {}
    lines = [text, "", "Home/Hub game guard: {0}".format("OK" if guard.get("ok") else "NEEDS PATCH")]
    if guard.get("path"):
        lines.append("  path: {0}".format(guard.get("path")))
    return "\n".join(lines)


# -----------------------------------------------------------------------------
# v1.5.21 - LRS-owned Home/Hub Ends-at row; native AF3 Ends-at disabled
# -----------------------------------------------------------------------------
# The previous approach tried to hold AF3 native EndTime/FinishTime objects until
# the asynchronous LRS row was ready. This version removes those native objects
# from the Home/Hub meta strip and adds the Ends-at object inside
# LRS_Info_Meta_Ratings instead. That keeps IMDb/RT/Popcorn and Ends-at in one
# LRS-owned row and prevents one-frame native-only flicker on movie changes.

LRS_HOMEHUB_LRS_ENDSAT_MARKER_1521 = "LRS-HOMEHUB-LRS-ENDSAT-1521"
LRS_HOMEHUB_NATIVE_ENDSAT_DISABLED_MARKER_1521 = "LRS-HOMEHUB-NATIVE-ENDSAT-DISABLED-1521"
_LRS_OLD_READY_TOKEN_1521 = "Meta" + "Row" + "Ready"


def _lrs_remove_old_ready_guards_1521(text: str) -> str:
    if not text or _LRS_OLD_READY_TOKEN_1521 not in text:
        return text

    def _visible_repl(match: Any) -> str:
        visible = match.group(1) or ""
        if _LRS_OLD_READY_TOKEN_1521 not in visible:
            return match.group(0)
        clean = re.sub(
            r"^\s*\[(.*)\]\s*\+\s*\[\[.*?" + re.escape(_LRS_OLD_READY_TOKEN_1521) + r".*?\]\]\s*$",
            r"\1",
            visible,
            flags=re.I | re.S,
        ).strip()
        if not clean or clean == visible:
            clean = "false"
        return '<param name="visible">{0}</param>'.format(clean)

    text = re.sub(r'<param\s+name="visible">(.*?)</param>', _visible_repl, text, flags=re.I | re.S)
    old_marker = re.escape('LRS-HOMEHUB-' + 'META' + 'ROW-READY-1520')
    text = re.sub(r'\n?\s*<!--\s*' + old_marker + r'\s*-->', '', text, flags=re.I)
    return text



def _lrs_fix_duplicate_kpm_special_prefix_1521(text: str) -> str:
    good = "special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/"
    bad = "special://home/addons/script.kodi.patch.manager/resources/media/" + good
    while bad in text:
        text = text.replace(bad, good)
    return text

def _lrs_patch_lrs_rating_call_params_1521(text: str) -> str:
    pattern = re.compile(r'(<include\s+content="LRS_Info_Meta_Ratings"[^>]*>)(.*?)(\s*</include>)', re.I | re.S)

    def repl(match: Any) -> str:
        head, body, tail = match.group(1), match.group(2), match.group(3)
        inserts = []
        for name, value in (
            ("container", "$PARAM[container]"),
            ("listitem", "$PARAM[listitem]"),
            ("service", "$PARAM[service]"),
            ("override_movie", "$PARAM[override_movie]"),
            ("override_tvshow", "$PARAM[override_tvshow]"),
        ):
            if re.search(r'<param\s+name="{0}"\b'.format(re.escape(name)), body, re.I):
                continue
            inserts.append('                        <param name="{0}">{1}</param>'.format(name, value))
        if inserts:
            body = body.rstrip() + "\n" + "\n".join(inserts) + "\n                    "
        return head + body + tail

    return pattern.sub(repl, text)


def _lrs_insert_endsat_into_lrs_include_1521(text: str) -> str:
    # v1.5.22 supersedes v1.5.21. Keep this no-op so the chained AF3 patcher
    # can still run, but do not insert the old live-ListItem Ends-at objects.
    return text


def _lrs_disable_native_endsat_blocks_1521(text: str) -> str:
    pattern = re.compile(r'<include\s+content="Info_Meta_Object"[^>]*>.*?</include>', re.I | re.S)

    def repl(match: Any) -> str:
        block = match.group(0)
        if LRS_HOMEHUB_LRS_ENDSAT_MARKER_1521 in block or LRS_HOMEHUB_NATIVE_ENDSAT_DISABLED_MARKER_1521 in block:
            return block
        if "LibraryRatings.ListItem.HasData" in block:
            return block
        if not re.search(r'<param\s+name="label">.*?(EndTimeResume|FinishTime).*?</param>', block, re.I | re.S):
            return block
        new, count = re.subn(r'<param\s+name="visible">.*?</param>', '<param name="visible">false</param>\n            <!-- {0} -->'.format(LRS_HOMEHUB_NATIVE_ENDSAT_DISABLED_MARKER_1521), block, count=1, flags=re.I | re.S)
        return new if count else block

    return pattern.sub(repl, text)


def af3_apply_lrs_endsat_1521() -> Dict[str, Any]:
    base = af3_skin_1080i_path_1470()
    path = os.path.join(base, "Includes_Info.xml") if base else ""
    result: Dict[str, Any] = {"path": path, "exists": False, "updated": False, "marker": LRS_HOMEHUB_LRS_ENDSAT_MARKER_1521}
    if not path or not os.path.exists(path):
        return result
    result["exists"] = True
    old = _read_text_file_1410(path)
    if not old:
        return result
    new = _lrs_remove_old_ready_guards_1521(old)
    new = _lrs_fix_duplicate_kpm_special_prefix_1521(new)
    new = _lrs_patch_lrs_rating_call_params_1521(new)
    new = _lrs_disable_native_endsat_blocks_1521(new)
    new = _lrs_insert_endsat_into_lrs_include_1521(new)
    result["has_lrs_endsat"] = LRS_HOMEHUB_LRS_ENDSAT_MARKER_1521 in new
    result["native_disabled"] = LRS_HOMEHUB_NATIVE_ENDSAT_DISABLED_MARKER_1521 in new
    result["old_ready_remaining"] = _LRS_OLD_READY_TOKEN_1521 in new
    if new != old:
        _backup_once_1410(path, ".lrs1521-lrs-endsat.bak")
        _write_text_file_1410(path, new)
        result["updated"] = True
    return result


_af3_update_icon_folder_in_xml_1521_prev = af3_update_icon_folder_in_xml_1410


def af3_update_icon_folder_in_xml_1410(folder: Optional[str] = None) -> Dict[str, Any]:
    result = _af3_update_icon_folder_in_xml_1521_prev(folder)
    try:
        ends = af3_apply_lrs_endsat_1521()
        result["homehub_lrs_endsat"] = ends
        if ends.get("updated"):
            result["files_updated"] = int(result.get("files_updated") or 0) + 1
    except Exception as exc:  # pylint: disable=broad-except
        result["homehub_lrs_endsat"] = {"error": str(exc), "updated": False}
    return result


_af3_integration_status_1521_prev = af3_integration_status_1470


def af3_integration_status_1470() -> Dict[str, Any]:
    status = _af3_integration_status_1521_prev()
    try:
        base = af3_skin_1080i_path_1470()
        path = os.path.join(base, "Includes_Info.xml") if base else ""
        text = _read_text_file_1410(path) if path and os.path.exists(path) else ""
        has_lrs_endsat = LRS_HOMEHUB_LRS_ENDSAT_MARKER_1521 in text
        native_disabled = LRS_HOMEHUB_NATIVE_ENDSAT_DISABLED_MARKER_1521 in text
        old_ready_remaining = _LRS_OLD_READY_TOKEN_1521 in text
        status["homehub_lrs_endsat"] = {"path": path, "ok": bool(has_lrs_endsat and native_disabled and not old_ready_remaining), "lrs_endsat": has_lrs_endsat, "native_disabled": native_disabled, "old_ready_remaining": old_ready_remaining}
        if not status["homehub_lrs_endsat"].get("ok"):
            status["ok"] = False
    except Exception as exc:  # pylint: disable=broad-except
        status["homehub_lrs_endsat"] = {"ok": False, "error": str(exc)}
        status["ok"] = False
    return status


_af3_integration_status_text_1521_prev = af3_integration_status_text_1470


def af3_integration_status_text_1470() -> str:
    text = _af3_integration_status_text_1521_prev()
    status = af3_integration_status_1470()
    ends = status.get("homehub_lrs_endsat") or {}
    lines = [text, "", "Home/Hub LRS Ends-at: {0}".format("OK" if ends.get("ok") else "NEEDS PATCH")]
    if ends.get("path"):
        lines.append("  path: {0}".format(ends.get("path")))
    lines.append("  LRS Ends-at object: {0}".format("YES" if ends.get("lrs_endsat") else "NO"))
    lines.append("  native Ends-at disabled: {0}".format("YES" if ends.get("native_disabled") else "NO"))
    lines.append("  old ready guard remaining: {0}".format("YES" if ends.get("old_ready_remaining") else "NO"))
    return "\n".join(lines)

# -----------------------------------------------------------------------------
# v1.5.22 - Ends-at as fixed LRS extra slot (always last, not rating-setting slot)
# -----------------------------------------------------------------------------
# v1.5.21 still rendered the Ends-at label from the live Kodi ListItem inside the
# LRS include. Ratings stayed because they came from LibraryRatings.* window
# properties, but Ends-at could flicker when the live ListItem title/end-time
# changed before the service published the next row. This version publishes
# Ends-at as its own LibraryRatings.ListItem.EndsAt_* properties and renders it
# as a fixed object at the very end of LRS_Info_Meta_Ratings.

LRS_HOMEHUB_LRS_ENDSAT_MARKER_1522 = "LRS-HOMEHUB-LRS-ENDSAT-1522"
_LRS_ENDSAT_EXTRA_NAMES_1522 = (
    "EndsAt_Source", "EndsAt_Icon", "EndsAt_IconFile", "EndsAt_Label", "EndsAt_Value",
)
LRS_EXTRA_PROPERTY_NAMES = tuple(dict.fromkeys(tuple(LRS_EXTRA_PROPERTY_NAMES) + _LRS_ENDSAT_EXTRA_NAMES_1522))


def _lrs_info_label_safe_1522(label: str) -> str:
    try:
        return xbmc.getInfoLabel(label).strip()
    except Exception:  # pylint: disable=broad-except
        return ""


def _lrs_localize_1522(identifier: int, fallback: str) -> str:
    try:
        value = xbmc.getLocalizedString(identifier).strip()
        return value or fallback
    except Exception:  # pylint: disable=broad-except
        return fallback


def _lrs_endsat_source_labels_1522(item: Dict[str, Any], context: str = "") -> List[str]:
    labels: List[str] = []
    item = item or {}

    def add(label: str) -> None:
        if label and label not in labels:
            labels.append(label)

    for key in ("_af3_container", "_focused_container", "_fallback_container"):
        cid = str(item.get(key) or "").strip()
        if cid.isdigit():
            add("Container({0}).ListItem.EndTimeResume".format(cid))
            add("Container({0}).ListItem.FinishTime".format(cid))
            add("Container({0}).ListItem.EndTime".format(cid))

    if str(context or "").lower() in ("af3_visual", "hub", "hub_fallback", "listitem", "lrs_active"):
        for cid in (301, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510):
            add("Container({0}).ListItem.EndTimeResume".format(cid))
            add("Container({0}).ListItem.FinishTime".format(cid))
            add("Container({0}).ListItem.EndTime".format(cid))

    add("ListItem.EndTimeResume")
    add("ListItem.FinishTime")
    add("ListItem.EndTime")
    add("VideoPlayer.FinishTime")
    add("VideoPlayer.EndTime")
    return labels


def _lrs_clean_time_value_1522(value: Any) -> str:
    text = str(value or "").strip()
    if not text or text == "-" or text.lower() in ("n/a", "none", "null"):
        return ""
    text = re.sub(r"^\s*(ends\s+at|end\s+at)\s+", "", text, flags=re.I).strip()
    return text


def lrs_endsat_properties_1522(item: Dict[str, Any], context: str = "") -> Dict[str, str]:
    item = item or {}
    if is_lrs_game_item(item):
        return {}
    dbtype = str(item.get("type") or item.get("DBType") or item.get("dbtype") or "").strip().lower()
    allowed = dbtype in ("movie", "episode", "video", "tvshow", "season", "")
    if not allowed:
        return {}
    value = ""
    for label in _lrs_endsat_source_labels_1522(item, context):
        value = _lrs_clean_time_value_1522(_lrs_info_label_safe_1522(label))
        if value:
            break
    if not value:
        return {}
    prefix = _lrs_localize_1522(31600, "Ends at")
    full_label = value if prefix.lower() in value.lower() else "{0} {1}".format(prefix, value)
    return {
        "EndsAt_Source": "endsat",
        "EndsAt_Icon": "ends.png",
        "EndsAt_IconFile": "ends.png",
        "EndsAt_Label": full_label,
        "EndsAt_Value": value,
    }


def _lrs_remove_old_lrs_endsat_objects_1522(text: str) -> str:
    if not text:
        return text
    text = re.sub(r"\n?\s*<!--\s*" + re.escape(LRS_HOMEHUB_LRS_ENDSAT_MARKER_1521) + r"\s*-->", "", text, flags=re.I)
    pattern = re.compile(r'<include\s+content="Info_Meta_Object"[^>]*>.*?</include>', re.I | re.S)

    def repl(match: Any) -> str:
        block = match.group(0)
        if "LibraryRatings.ListItem.HasData" in block and ("EndTimeResume" in block or "FinishTime" in block):
            return ""
        return block

    return pattern.sub(repl, text)


def _lrs_insert_fixed_endsat_slot_1522(text: str) -> str:
    if LRS_HOMEHUB_LRS_ENDSAT_MARKER_1522 in text:
        return text
    object_xml = '''
            <!-- {marker} -->
            <include content="Info_Meta_Object">
                <param name="icon">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.ListItem.EndsAt_IconFile)]</param>
                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.EndsAt_Label)]</param>
                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.EndsAt_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.EndsAt_IconFile))</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
            </include>'''.format(marker=LRS_HOMEHUB_LRS_ENDSAT_MARKER_1522)
    pattern = re.compile(r'(<include\s+name="LRS_Info_Meta_Ratings"[^>]*>.*?<definition>)(.*?)(\s*</definition>\s*</include>)', re.I | re.S)

    def repl(match: Any) -> str:
        head, body, tail = match.group(1), match.group(2), match.group(3)
        body = body.rstrip() + object_xml + "\n        "
        return head + body + tail

    return pattern.sub(repl, text, count=1)


def af3_apply_lrs_endsat_slot_1522() -> Dict[str, Any]:
    base = af3_skin_1080i_path_1470()
    path = os.path.join(base, "Includes_Info.xml") if base else ""
    result: Dict[str, Any] = {"path": path, "exists": False, "updated": False, "marker": LRS_HOMEHUB_LRS_ENDSAT_MARKER_1522}
    if not path or not os.path.exists(path):
        return result
    result["exists"] = True
    old = _read_text_file_1410(path)
    if not old:
        return result
    new = _lrs_fix_duplicate_kpm_special_prefix_1521(old)
    new = _lrs_remove_old_ready_guards_1521(new)
    new = _lrs_patch_lrs_rating_call_params_1521(new)
    new = _lrs_disable_native_endsat_blocks_1521(new)
    new = _lrs_remove_old_lrs_endsat_objects_1522(new)
    new = _lrs_insert_fixed_endsat_slot_1522(new)
    if new != old:
        _backup_once_1410(path, ".lrs1522-endsat-slot.bak")
        _write_text_file_1410(path, new)
        result["updated"] = True
    result["has_slot"] = LRS_HOMEHUB_LRS_ENDSAT_MARKER_1522 in new
    result["old_lrs_endsat_remaining"] = LRS_HOMEHUB_LRS_ENDSAT_MARKER_1521 in new
    result["old_ready_remaining"] = _LRS_OLD_READY_TOKEN_1521 in new
    result["native_disabled"] = LRS_HOMEHUB_NATIVE_ENDSAT_DISABLED_MARKER_1521 in new
    return result


_af3_update_icon_folder_in_xml_1522_prev = af3_update_icon_folder_in_xml_1410


def af3_update_icon_folder_in_xml_1410(folder: Optional[str] = None) -> Dict[str, Any]:
    result = _af3_update_icon_folder_in_xml_1522_prev(folder)
    try:
        ends = af3_apply_lrs_endsat_slot_1522()
        result["homehub_endsat_slot"] = ends
        if ends.get("updated"):
            result["files_updated"] = int(result.get("files_updated") or 0) + 1
    except Exception as exc:  # pylint: disable=broad-except
        result["homehub_endsat_slot"] = {"error": str(exc), "updated": False}
    return result


_af3_integration_status_1522_prev = af3_integration_status_1470


def af3_integration_status_1470() -> Dict[str, Any]:
    status = _af3_integration_status_1522_prev()
    try:
        base = af3_skin_1080i_path_1470()
        path = os.path.join(base, "Includes_Info.xml") if base else ""
        text = _read_text_file_1410(path) if path and os.path.exists(path) else ""
        row = {
            "path": path,
            "ok": bool(
                LRS_HOMEHUB_LRS_ENDSAT_MARKER_1522 in text
                and LRS_HOMEHUB_LRS_ENDSAT_MARKER_1521 not in text
                and _LRS_OLD_READY_TOKEN_1521 not in text
                and "LibraryRatings.ListItem.EndsAt_Label" in text
            ),
            "slot": LRS_HOMEHUB_LRS_ENDSAT_MARKER_1522 in text,
            "old_lrs_endsat_remaining": LRS_HOMEHUB_LRS_ENDSAT_MARKER_1521 in text,
            "old_ready_remaining": _LRS_OLD_READY_TOKEN_1521 in text,
            "native_disabled": LRS_HOMEHUB_NATIVE_ENDSAT_DISABLED_MARKER_1521 in text,
        }
        status["homehub_endsat_slot"] = row
        if not row.get("ok"):
            status["ok"] = False
    except Exception as exc:  # pylint: disable=broad-except
        status["homehub_endsat_slot"] = {"ok": False, "error": str(exc)}
        status["ok"] = False
    return status


_af3_integration_status_text_1522_prev = af3_integration_status_text_1470


def af3_integration_status_text_1470() -> str:
    text = _af3_integration_status_text_1522_prev()
    status = af3_integration_status_1470()
    row = status.get("homehub_endsat_slot") or {}
    lines = [text, "", "Home/Hub fixed LRS Ends-at slot: {0}".format("OK" if row.get("ok") else "NEEDS PATCH")]
    if row.get("path"):
        lines.append("  path: {0}".format(row.get("path")))
    lines.append("  fixed slot: {0}".format("YES" if row.get("slot") else "NO"))
    lines.append("  old 1.5.21 Ends-at remaining: {0}".format("YES" if row.get("old_lrs_endsat_remaining") else "NO"))
    lines.append("  old ready guard remaining: {0}".format("YES" if row.get("old_ready_remaining") else "NO"))
    return "\n".join(lines)



# -----------------------------------------------------------------------------
# v1.5.23 - AF3 Home/Hub focused-widget neighbour prefetch helpers
# -----------------------------------------------------------------------------
# AF3 widgets are Kodi containers. While item N is focused, Kodi can expose
# N-1 and N+1 through Container(id).ListItemNoWrap(offset). LRS uses this only
# for cache prefetch; it does not queue online provider lookups.

def _lrs_container_item_no_wrap_1523(container_id: int, offset: int = 0) -> Dict[str, Any]:
    if offset == 0:
        item = container_item(container_id, 0)
        if isinstance(item, dict):
            item["_af3_container"] = str(container_id)
            item["_af3_offset"] = "0"
        return item

    def expr(field: str) -> str:
        return "Container({0}).ListItemNoWrap({1}).{2}".format(container_id, offset, field)

    def li(field: str) -> str:
        try:
            return xbmc.getInfoLabel(expr(field)).strip()
        except Exception:  # pylint: disable=broad-except
            return ""

    raw_type = li("DBTYPE") or li("DBType") or li("Property(DBType)") or li("Property(dbtype)") or li("Property(type)")
    title = li("Title") or li("Label") or li("Property(title)")
    showtitle = li("TVShowTitle") or li("ShowTitle") or li("Property(tvshowtitle)") or li("Property(showtitle)") or li("Property(tv_show_title)")
    season = li("Season") or li("Property(season)") or li("Property(tvshow.season)")
    episode = li("Episode") or li("Property(episode)") or li("Property(tvshow.episode)")
    file_path = li("FilenameAndPath") or li("FileNameAndPath") or li("FileName") or li("Path") or li("FolderPath")
    parsed = _parse_videodb_identity(file_path)
    item: Dict[str, Any] = {
        "type": _infer_video_type(raw_type, title, showtitle, season, episode),
        "dbid": li("DBID") or li("DBId") or li("Property(dbid)") or li("Property(DBID)"),
        "title": title,
        "showtitle": showtitle,
        "season": season,
        "episode": episode,
        "year": li("Year") or li("Property(year)") or li("Property(release_year)"),
        "premiered": li("Premiered") or li("FirstAired") or li("Property(premiered)") or li("Property(release_date)") or li("Property(firstaired)") or li("Date"),
        "release_date": li("Property(release_date)") or li("Property(released)") or li("Property(ReleaseDate)"),
        "status": li("Property(status)") or li("Property(release_status)") or li("Status") or li("Property(tmdb_status)"),
        "imdbnumber": li("IMDBNumber") or li("IMDbNumber") or li("UniqueID(imdb)") or li("Property(imdb_id)") or li("Property(imdb)"),
        "tmdb_id": li("UniqueID(tmdb)") or li("Property(tmdb_id)") or li("Property(tmdbid)") or li("Property(tmdb)"),
        "top250": li("Top250"),
        "file": file_path,
        "_af3_container": str(container_id),
        "_af3_offset": str(offset),
        "_af3_nowrap": "true",
    }
    if parsed:
        item.update({k: v for k, v in parsed.items() if v not in (None, "")})

    try:
        return _lrs_game_enrich_from_getter_1580(item, lambda name: li("Property({0})".format(name)))
    except Exception:  # pylint: disable=broad-except
        return item


def af3_neighbor_items_1523(current_item: Optional[Dict[str, Any]] = None, radius: int = 1) -> List[Dict[str, Any]]:
    if not af3_hub_window_active():
        return []
    current_item = current_item or {}
    cid = safe_int(
        current_item.get("_af3_container")
        or current_item.get("_focused_container")
        or current_item.get("_fallback_container")
        or _lrs_any_af3_property("LRS.Active.ContainerID", "LRS.Active.ContainerId", "LRS.Active.WidgetContainer")
    )
    if cid is None or cid <= 0:
        cid = af3_active_container_id()
    if cid is None or int(cid) <= 0:
        return []

    radius = max(0, min(2, safe_int(radius) or 1))
    offsets: List[int] = [0]
    for step in range(1, radius + 1):
        offsets.extend([-step, step])

    out: List[Dict[str, Any]] = []
    seen = set()
    for off in offsets:
        item = _lrs_container_item_no_wrap_1523(int(cid), off)
        if not valid_library_item(item):
            continue
        key = identity_key(item)
        if not key or key in seen:
            continue
        seen.add(key)
        out.append(item)
    return out

# -----------------------------------------------------------------------------
# v1.5.30 - AF3 lower rating row ownership / unified DisplaySlot
# -----------------------------------------------------------------------------
# LRS owns the lower rating row for Home.xml, Custom_*_Hub.xml, MyPrograms.xml
# and MyVideoNav.xml. Home/Hub uses keep-last DisplaySlot; Programs/Videos use
# strict-current DisplaySlot. Steam Library supplies RatingSlot bridge only.

LRS_HOMEHUB_DISPLAY_MARKER_1528 = "LRS-AF3-ROW-OWNERSHIP-1531"
LRS_HOMEHUB_DIRECT_GAME_DISABLED_MARKER_1528 = "LRS-AF3-DIRECT-GAME-ROW-DISABLED-1531"
_LRS_HOMEHUB_DISPLAY_ACTIVE_PROP_1528 = "LibraryRatings.HomeHub.DisplayActive"
_LRS_HOMEHUB_DISPLAY_MAX_SLOTS_1528 = 10
_LRS_HOMEHUB_DISPLAY_PROPERTY_NAMES_1528: List[str] = [
    "DisplayActive", "DisplayMode", "DisplayItemKey", "DisplaySource", "DisplayDBType", "DisplayTitle",
]
for _idx_1528 in range(1, _LRS_HOMEHUB_DISPLAY_MAX_SLOTS_1528 + 1):
    for _suffix_1528 in ("Source", "Icon", "IconFile", "Label", "Value"):
        _LRS_HOMEHUB_DISPLAY_PROPERTY_NAMES_1528.append("DisplaySlot{0}_{1}".format(_idx_1528, _suffix_1528))


def af3_rating_row_keep_last_window_1530() -> bool:
    """Home/Hub windows keep the previous row while a new row is being prepared."""
    return any(_lrs_safe_cond(cond) for cond in (
        "Window.IsActive(home)",
        "Window.IsActive(1101)",
        "Window.IsActive(1102)",
        "Window.IsActive(1103)",
        "Window.IsActive(1104)",
    ))


def af3_rating_row_strict_window_1530() -> bool:
    """Library windows render only the current focused item."""
    return any(_lrs_safe_cond(cond) for cond in (
        "Window.IsActive(programs)",
        "Window.IsActive(videos)",
        "Window.IsActive(MyPrograms.xml)",
        "Window.IsActive(MyVideoNav.xml)",
    ))


def af3_rating_row_window_active_1530() -> bool:
    return bool(af3_rating_row_keep_last_window_1530() or af3_rating_row_strict_window_1530())


# v1.5.31 keeps the 1.5.30 implementation names internally but exposes
# versioned aliases used by the cleaned service wrapper.
def af3_rating_row_keep_last_window_1531() -> bool:
    return af3_rating_row_keep_last_window_1530()


def af3_rating_row_strict_window_1531() -> bool:
    return af3_rating_row_strict_window_1530()


def af3_rating_row_window_active_1531() -> bool:
    return af3_rating_row_window_active_1530()


def _lrs_is_raw_infolabel_1528(value: Any) -> bool:
    text = str(value or "").strip()
    if not text:
        return False
    return bool(re.search(r"(?:^|\b)(?:Container\s*\(|ListItem\.|VideoPlayer\.|Window\s*\(|\$INFO\[)", text, flags=re.I))


def _lrs_display_clean_1528(value: Any) -> str:
    text = str(value or "").strip()
    if not text or text.lower() in ("none", "null", "n/a"):
        return ""
    if _lrs_is_raw_infolabel_1528(text):
        return ""
    return text


def _lrs_display_icon_file_1528(value: Any) -> str:
    text = str(value or "").strip().replace("\\", "/")
    if not text or _lrs_is_raw_infolabel_1528(text):
        return ""
    return os.path.basename(text)


def _lrs_display_digits_1530(text: Any) -> str:
    value = _lrs_display_clean_1528(text)
    if not value:
        return ""
    m = re.search(r"\d+(?:\.\d+)?", value)
    return m.group(0) if m else ""


def _lrs_display_percent_1530(text: Any) -> str:
    value = _lrs_display_clean_1528(text)
    if not value:
        return ""
    if "%" in value:
        return value
    number = _lrs_display_digits_1530(value)
    return (number + "%") if number else value


def _lrs_display_award_1530(text: Any) -> str:
    value = _lrs_display_clean_1528(text)
    if not value:
        return ""
    if value.lower().startswith("x"):
        return "x" + value[1:].strip()
    number = _lrs_display_digits_1530(value)
    return ("x" + number) if number else value


def _lrs_display_endsat_1530(label: Any, value: Any = "") -> str:
    label_text = _lrs_display_clean_1528(label)
    value_text = _lrs_display_clean_1528(value)
    text = label_text or value_text
    if not text:
        return ""
    if text.lower().startswith("ends at"):
        return text
    m = re.search(r"\b\d{1,2}:\d{2}\b", text)
    time_text = m.group(0) if m else text
    return "Ends at {0}".format(time_text)


def _lrs_series_status_label_1537(value: Any) -> str:
    text = _lrs_display_clean_1528(value)
    if not text:
        return ''
    text = re.sub(r'^\s*ends\s+at\s+', '', text, flags=re.I)
    text = re.sub(r'\s+-\s+\d{1,4}[-/]\d{1,2}[-/]\d{1,4}\s*$', '', text)
    text = re.sub(r'\s+\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\s*$', '', text)
    text = re.sub(r'\s+\d{4}[-/]\d{1,2}[-/]\d{1,2}\s*$', '', text)
    norm = text.strip().lower()
    if norm in ('returning series', 'returning'):
        return 'Returning'
    if norm in ('ended', 'end'):
        return 'Ended'
    if norm in ('canceled', 'cancelled'):
        return 'Cancelled'
    return text.strip()


def _lrs_slot_label_final_1530(source: Any, icon_file: Any, label: Any, value: Any = "") -> str:
    src = _lrs_display_clean_1528(source).lower().replace("-", "_").replace(" ", "_")
    icon = _lrs_display_icon_file_1528(icon_file).lower()
    label_text = _lrs_display_clean_1528(label)
    value_text = _lrs_display_clean_1528(value)
    hay = " ".join([src, icon]).lower()

    if src in ('tvstatus', 'tv_status', 'series_status', 'status'):
        return _lrs_series_status_label_1537(label_text or value_text)

    # TV status and Ends-at may use the same clock/ends artwork. Classify by
    # source/actual time content, never by the icon filename alone.
    if src in ("endsat", "ends_at") or (("ends" in icon or "clock" in icon) and src not in ("tvstatus", "tv_status", "series_status", "status") and re.search(r"\b\d{1,2}:\d{2}\b", label_text or value_text)):
        return _lrs_display_endsat_1530(label_text, value_text)
    if any(key in hay for key in ("rt_critic", "rtfresh", "rtrotten", "rotten", "tomato")):
        return _lrs_display_percent_1530(label_text or value_text)
    if any(key in hay for key in ("rt_audience", "popcorn")):
        return _lrs_display_percent_1530(label_text or value_text)
    if any(key in hay for key in ("oscar", "oscars", "emmy", "emmys")):
        return _lrs_display_award_1530(label_text or value_text)
    if "steam" in hay and "ach" not in hay:
        if value_text and ("%" in value_text or re.fullmatch(r"\d+(?:\.\d+)?", value_text)):
            return _lrs_display_percent_1530(value_text)
        return _lrs_display_percent_1530(label_text)
    if "achiev" in hay or "steam_ach" in hay or "steam-ach" in icon:
        if value_text and value_text.lower() != "achievements":
            return value_text
        if label_text.lower() == "achievements":
            return ""
        return label_text
    return label_text or value_text


def _lrs_homehub_add_display_slot_1528(slots: List[Dict[str, str]], source: Any, icon_file: Any, label: Any, value: Any = "") -> None:
    icon_name = _lrs_display_icon_file_1528(icon_file)
    label_text = _lrs_slot_label_final_1530(source, icon_name, label, value)
    if not label_text or not icon_name:
        return
    value_text = _lrs_display_clean_1528(value) or label_text
    slots.append({
        "Source": _lrs_display_clean_1528(source).lower().replace(" ", "_"),
        "Icon": icon_name,
        "IconFile": icon_name,
        "Label": label_text,
        "Value": value_text,
    })


def _lrs_homehub_display_slots_from_values_1528(values: Dict[str, Any]) -> List[Dict[str, str]]:
    values = values or {}
    slots: List[Dict[str, str]] = []
    for idx in range(1, 8):
        source = values.get("RatingSlot{0}_Source".format(idx))
        label = values.get("RatingSlot{0}_Label".format(idx))
        value = values.get("RatingSlot{0}_Value".format(idx))
        icon_file = values.get("RatingSlot{0}_IconFile".format(idx)) or values.get("RatingSlot{0}_Icon".format(idx)) or values.get("RatingSlot{0}_IconPath".format(idx))
        _lrs_homehub_add_display_slot_1528(slots, source, icon_file, label, value)

    oscar_wins = _lrs_display_clean_1528(values.get("Oscar_Wins") or values.get("OscarWins"))
    if oscar_wins:
        best_picture = str(values.get("Oscar_BestPicture") or values.get("OscarBestPicture") or "").lower() in ("true", "1", "yes")
        _lrs_homehub_add_display_slot_1528(slots, "oscars", "oscars_bp.png" if best_picture else "oscars.png", oscar_wins, oscar_wins)
    emmy_wins = _lrs_display_clean_1528(values.get("Emmy_Wins") or values.get("EmmyWins"))
    if emmy_wins:
        _lrs_homehub_add_display_slot_1528(slots, "emmys", "emmys.png", emmy_wins, emmy_wins)
    if _lrs_display_clean_1528(values.get("Series_StatusLabel") or values.get("SeriesStatusLabel")):
        _lrs_homehub_add_display_slot_1528(slots, "tvstatus", "ends.png", values.get("Series_StatusLabel") or values.get("SeriesStatusLabel"))
    if _lrs_display_clean_1528(values.get("EndsAt_Label") or values.get("EndsAt_Value")):
        _lrs_homehub_add_display_slot_1528(slots, "endsat", values.get("EndsAt_IconFile") or "ends.png", values.get("EndsAt_Label"), values.get("EndsAt_Value"))
    return slots[:_LRS_HOMEHUB_DISPLAY_MAX_SLOTS_1528]


def publish_homehub_display_active_1528(active: bool) -> None:
    for window in _publish_windows():
        _publish_property(window, _LRS_HOMEHUB_DISPLAY_ACTIVE_PROP_1528, "true" if active else "false")


def publish_homehub_display_1528(values: Dict[str, Any], item_identity: str = "", source: str = "", compatibility: bool = True, mode: str = "keep-last") -> bool:
    slots = _lrs_homehub_display_slots_from_values_1528(values or {})
    if not slots:
        return False
    payload: Dict[str, str] = {
        "DisplayActive": "true",
        "DisplayMode": str(mode or ""),
        "DisplayItemKey": str(item_identity or ""),
        "DisplaySource": str(source or (values or {}).get("SourceContext") or (values or {}).get("Source") or ""),
        "DisplayDBType": str((values or {}).get("DBType") or ""),
        "DisplayTitle": str((values or {}).get("Title") or ""),
    }
    for idx in range(1, _LRS_HOMEHUB_DISPLAY_MAX_SLOTS_1528 + 1):
        row = slots[idx - 1] if idx <= len(slots) else {}
        for suffix in ("Source", "Icon", "IconFile", "Label", "Value"):
            payload["DisplaySlot{0}_{1}".format(idx, suffix)] = str(row.get(suffix, "") or "")
    for window in _publish_windows():
        for key in _LRS_HOMEHUB_DISPLAY_PROPERTY_NAMES_1528:
            _publish_property(window, "LibraryRatings.HomeHub." + key, str(payload.get(key, "") or ""))
    return True


def _lrs_display_slot_objects_xml_1528() -> str:
    base_icon = "special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/"
    blocks: List[str] = ["            <!-- {0} -->".format(LRS_HOMEHUB_DISPLAY_MARKER_1528)]
    no_collection = "!String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) + !String.IsEqual($PARAM[container]$PARAM[listitem].DBType,collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(lrs_item_type),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(lrs_item_type),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(is_collection),true)"
    visible_base = "[$PARAM[visible]] + String.IsEqual(Window(Home).Property(LibraryRatings.HomeHub.DisplayActive),true) + " + no_collection + " + !String.IsEmpty(Window(Home).Property(LibraryRatings.HomeHub.DisplaySlot{idx}_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.HomeHub.DisplaySlot{idx}_IconFile))"
    for idx in range(1, _LRS_HOMEHUB_DISPLAY_MAX_SLOTS_1528 + 1):
        icon = base_icon + "$INFO[Window(Home).Property(LibraryRatings.HomeHub.DisplaySlot{0}_IconFile)]".format(idx)
        label = "$INFO[Window(Home).Property(LibraryRatings.HomeHub.DisplaySlot{0}_Label)]".format(idx)
        src = "Window(Home).Property(LibraryRatings.HomeHub.DisplaySlot{0}_Source)".format(idx)
        visible = visible_base.format(idx=idx)
        blocks.append("""            <include content="Info_Meta_Object">
                <param name="icon">{icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + String.IsEqual({src},imdb)</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
                <param name="icon_w">52</param>
            </include>
            <include content="Info_Meta_Object">
                <param name="icon">{icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + !String.IsEqual({src},imdb)</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
            </include>""".format(icon=icon, label=label, visible=visible, src=src))
    return "\n".join(blocks) + "\n"


def _lrs_remove_display_artifacts_1528(text: str) -> str:
    if not text:
        return text
    markers = (
        "LRS-HOMEHUB-UNIFIED-DISPLAYSLOT-1525",
        "LRS-HOMEHUB-DIRECT-GAME-ROW-GUARD-1525",
        "LRS-HOMEHUB-DIRECT-GAME-ROW-DISABLED-1526",
        "LRS-HOMEHUB-DISPLAYSLOT-FIXES-1526",
        "LRS-HOMEHUB-UNIFIED-DISPLAYSLOT-1527",
        "LRS-HOMEHUB-DIRECT-GAME-ROW-DISABLED-1527",
        "LRS-HOMEHUB-UNIFIED-DISPLAYSLOT-1528",
        "LRS-HOMEHUB-DIRECT-GAME-ROW-DISABLED-1528",
        "LRS-AF3-ROW-OWNERSHIP-1529",
        "LRS-AF3-DIRECT-GAME-ROW-DISABLED-1529",
        "LRS-AF3-ROW-OWNERSHIP-1530",
        "LRS-AF3-DIRECT-GAME-ROW-DISABLED-1530",
        LRS_HOMEHUB_DISPLAY_MARKER_1528,
        LRS_HOMEHUB_DIRECT_GAME_DISABLED_MARKER_1528,
    )
    for marker in markers:
        text = re.sub(r"\n?\s*<!--\s*" + re.escape(marker) + r"\s*-->", "", text, flags=re.I)
    
    def _drop_display_block_1530(match: Any) -> str:
        block = match.group(0)
        return "" if "LibraryRatings.HomeHub.DisplaySlot" in block else block

    text = re.sub(r'<include\s+content="Info_Meta_Object"[^>]*>.*?</include>', _drop_display_block_1530, text, flags=re.I | re.S)
    guard_patterns = (
        r"\s*\+\s*!String\.IsEqual\(Window\(Home\)\.Property\(LibraryRatings\.HomeHub\.DisplayActive\),true\)",
        r"\s*\+\s*String\.IsEqual\(Window\(Home\)\.Property\(LibraryRatings\.HomeHub\.DisplayActive\),true\)",
    )
    for pat in guard_patterns:
        text = re.sub(pat, "", text, flags=re.I)
    return text


def _lrs_patch_lrs_call_visible_unified_1528(text: str) -> str:
    if not text:
        return text
    game_ok = "!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) | String.IsEqual($PARAM[container]$PARAM[listitem].Property(lrs_game),true) | String.IsEqual($PARAM[container]$PARAM[listitem].Property(lrs_item_type),game) | String.IsEqual($PARAM[container]$PARAM[listitem].Property(lrs_media_type),game) | String.IsEqual($PARAM[container]$PARAM[listitem].Property(library_ratings_type),game) | String.IsEqual($PARAM[container]$PARAM[listitem].Property(mediahub_type),game) | String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),game) | String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),game) | String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),game) | String.IsEqual($PARAM[container]$PARAM[listitem].Property(mediatype),game) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,game)"
    video_ok = "String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,episode) | $PARAM[override_movie] | $PARAM[override_tvshow] | Window.IsActive(videoosd)"
    not_game = "String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(lrs_game),true) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(lrs_item_type),game) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(lrs_media_type),game) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(library_ratings_type),game) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(mediahub_type),game) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),game) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),game) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),game) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(mediatype),game) + !String.IsEqual($PARAM[container]$PARAM[listitem].DBType,game)"
    display_ok = "String.IsEqual(Window(Home).Property(LibraryRatings.HomeHub.DisplayActive),true)"
    new_visible = '<param name="visible">[$PARAM[visible]] + [{display} | [[{video}] + [{not_game}]] | [{game}]]</param>'.format(display=display_ok, video=video_ok, not_game=not_game, game=game_ok)
    pattern = re.compile(r'(<include\s+content="LRS_Info_Meta_Ratings"[^>]*>)(.*?)(\s*</include>)', re.I | re.S)

    def repl(match: Any) -> str:
        head, body, tail = match.group(1), match.group(2), match.group(3)
        body = _lrs_remove_display_artifacts_1528(body)
        body = re.sub(r"\n?\s*<!--\s*LRS-HOMEHUB-GAME-GUARD-1519.*?-->", "", body, flags=re.I | re.S)
        body, count = re.subn(r'<param\s+name="visible">.*?</param>', new_visible, body, count=1, flags=re.I | re.S)
        if not count:
            body = "\n" + new_visible + body
        colordiffuse = "main_fg"
        m_color = re.search(r'<param\s+name="colordiffuse">(.*?)</param>', body, flags=re.I | re.S)
        if m_color:
            colordiffuse = m_color.group(1).strip() or colordiffuse
        # Clean duplicate params left by older 1.5.21/1.5.29 patchers. Keep
        # exactly one set so Includes_Info.xml does not grow on every patch run.
        body = re.sub(r'\n?\s*<param\s+name="(?:colordiffuse|container|listitem|service|override_movie|override_tvshow)">.*?</param>', "", body, flags=re.I | re.S)
        fixed_params = (
            '\n                        <param name="colordiffuse">{color}</param>'
            '\n                        <param name="container">$PARAM[container]</param>'
            '\n                        <param name="listitem">$PARAM[listitem]</param>'
            '\n                        <param name="service">$PARAM[service]</param>'
            '\n                        <param name="override_movie">$PARAM[override_movie]</param>'
            '\n                        <param name="override_tvshow">$PARAM[override_tvshow]</param>'
        ).format(color=colordiffuse)
        body = re.sub(r'(<param\s+name="visible">.*?</param>)', r'\1' + fixed_params, body, count=1, flags=re.I | re.S)
        marker = "\n            <!-- LRS-AF3-CALL-VISIBLE-1531 -->"
        if "LRS-AF3-CALL-VISIBLE-1531" not in body:
            body = marker + body
        return head + body + tail

    return pattern.sub(repl, text)


def _lrs_patch_lrs_include_definition_unified_1528(text: str) -> str:
    if not text:
        return text
    pattern = re.compile(r'(<include\s+name="LRS_Info_Meta_Ratings"[^>]*>.*?<definition>)(.*?)(\s*</definition>\s*</include>)', re.I | re.S)
    guard = "!String.IsEqual(Window(Home).Property(LibraryRatings.HomeHub.DisplayActive),true)"

    def repl(match: Any) -> str:
        head, body, tail = match.group(1), match.group(2), match.group(3)
        body = _lrs_remove_display_artifacts_1528(body)
        body = _lrs_display_slot_objects_xml_1528() + body

        def visible_repl(vm: Any) -> str:
            visible = vm.group(1).strip()
            if "LibraryRatings.HomeHub.DisplaySlot" in visible or "LibraryRatings.HomeHub.DisplayActive" in visible:
                return vm.group(0)
            if "LibraryRatings.ListItem." not in visible:
                return vm.group(0)
            return '<param name="visible">{0} + {1}</param>'.format(visible, guard)

        body = re.sub(r'<param\s+name="visible">(.*?)</param>', visible_repl, body, flags=re.I | re.S)
        return head + "\n" + body + tail

    return pattern.sub(repl, text, count=1)


def _lrs_disable_direct_game_rows_1528(text: str) -> str:
    if not text:
        return text
    pattern = re.compile(r'<include\s+content="Info_Meta_Object"[^>]*>.*?</include>', re.I | re.S)

    def repl(match: Any) -> str:
        block = match.group(0)
        if not any(token in block for token in ("Property(steam_rating_display)", "Property(metacritic_score)", "Property(achievement_display)")):
            return block
        for marker in (
            "LRS-HOMEHUB-DIRECT-GAME-ROW-GUARD-1525",
            "LRS-HOMEHUB-DIRECT-GAME-ROW-DISABLED-1526",
            "LRS-HOMEHUB-DIRECT-GAME-ROW-DISABLED-1527",
            "LRS-HOMEHUB-DIRECT-GAME-ROW-DISABLED-1528",
            "LRS-AF3-DIRECT-GAME-ROW-DISABLED-1529",
            LRS_HOMEHUB_DIRECT_GAME_DISABLED_MARKER_1528,
        ):
            block = re.sub(r"\n?\s*<!--\s*" + re.escape(marker) + r"\s*-->", "", block, flags=re.I)
        new, count = re.subn(r'<param\s+name="visible">.*?</param>', '<param name="visible">false</param>\n                        <!-- ' + LRS_HOMEHUB_DIRECT_GAME_DISABLED_MARKER_1528 + ' -->', block, count=1, flags=re.I | re.S)
        if not count:
            new = block.replace("</include>", '    <param name="visible">false</param>\n                        <!-- ' + LRS_HOMEHUB_DIRECT_GAME_DISABLED_MARKER_1528 + ' -->\n                    </include>')
        return new

    return pattern.sub(repl, text)


def af3_apply_homehub_unified_display_slots_1528() -> Dict[str, Any]:
    base = af3_skin_1080i_path_1470()
    path = os.path.join(base, "Includes_Info.xml") if base else ""
    result: Dict[str, Any] = {"path": path, "exists": False, "updated": False, "marker": LRS_HOMEHUB_DISPLAY_MARKER_1528}
    if not path or not os.path.exists(path):
        return result
    result["exists"] = True
    old = _read_text_file_1410(path)
    if not old:
        return result
    new = _lrs_fix_duplicate_kpm_special_prefix_1521(old)
    new = _lrs_patch_lrs_rating_call_params_1521(new)
    new = _lrs_remove_display_artifacts_1528(new)
    new = _lrs_patch_lrs_call_visible_unified_1528(new)
    new = _lrs_patch_lrs_include_definition_unified_1528(new)
    new = _lrs_disable_direct_game_rows_1528(new)
    if new != old:
        _backup_once_1410(path, ".lrs1531-row-ownership.bak")
        _write_text_file_1410(path, new)
        result["updated"] = True
    result["display_slots"] = LRS_HOMEHUB_DISPLAY_MARKER_1528 in new
    result["call_visible"] = "LRS-AF3-CALL-VISIBLE-1531" in new
    result["direct_game_disabled"] = LRS_HOMEHUB_DIRECT_GAME_DISABLED_MARKER_1528 in new or "STEAM-LIBRARY-AF3-DIRECT-GAME-META-REMOVED-LRS-DISPLAYSLOT" in new
    result["old_1529_remaining"] = "LRS-AF3-ROW-OWNERSHIP-1529" in new or "LRS-AF3-DIRECT-GAME-ROW-DISABLED-1529" in new or "LRS-AF3-ROW-OWNERSHIP-1530" in new or "LRS-AF3-DIRECT-GAME-ROW-DISABLED-1530" in new
    return result


_af3_update_icon_folder_in_xml_1528_prev = af3_update_icon_folder_in_xml_1410


def af3_update_icon_folder_in_xml_1410(folder: Optional[str] = None) -> Dict[str, Any]:
    result = _af3_update_icon_folder_in_xml_1528_prev(folder)
    try:
        row = af3_apply_homehub_unified_display_slots_1528()
        result["af3_row_ownership_1530"] = row
        if row.get("updated"):
            result["files_updated"] = int(result.get("files_updated") or 0) + 1
    except Exception as exc:  # pylint: disable=broad-except
        result["af3_row_ownership_1530"] = {"error": str(exc), "updated": False}
    return result


_af3_integration_status_1528_prev = af3_integration_status_1470


def af3_integration_status_1470() -> Dict[str, Any]:
    status = _af3_integration_status_1528_prev()
    try:
        base = af3_skin_1080i_path_1470()
        path = os.path.join(base, "Includes_Info.xml") if base else ""
        text = _read_text_file_1410(path) if path and os.path.exists(path) else ""
        row = {
            "path": path,
            "ok": bool(LRS_HOMEHUB_DISPLAY_MARKER_1528 in text and "LRS-AF3-CALL-VISIBLE-1531" in text and "LRS-HOMEHUB-GAME-GUARD-1519" not in text and "LRS-AF3-ROW-OWNERSHIP-1529" not in text and "LRS-AF3-ROW-OWNERSHIP-1530" not in text),
            "display_slots": LRS_HOMEHUB_DISPLAY_MARKER_1528 in text,
            "call_visible": "LRS-AF3-CALL-VISIBLE-1531" in text,
            "direct_game_disabled": LRS_HOMEHUB_DIRECT_GAME_DISABLED_MARKER_1528 in text or "STEAM-LIBRARY-AF3-DIRECT-GAME-META-REMOVED-LRS-DISPLAYSLOT" in text,
            "old_game_guard_remaining": "LRS-HOMEHUB-GAME-GUARD-1519" in text,
            "old_1529_remaining": "LRS-AF3-ROW-OWNERSHIP-1529" in text or "LRS-AF3-ROW-OWNERSHIP-1530" in text,
        }
        status["af3_row_ownership_1530"] = row
        if not row.get("ok"):
            status["ok"] = False
    except Exception as exc:  # pylint: disable=broad-except
        status["af3_row_ownership_1530"] = {"ok": False, "error": str(exc)}
        status["ok"] = False
    return status


_af3_integration_status_text_1528_prev = af3_integration_status_text_1470


def af3_integration_status_text_1470() -> str:
    text = _af3_integration_status_text_1528_prev()
    status = af3_integration_status_1470()
    row = status.get("af3_row_ownership_1530") or {}
    lines = [text, "", "AF3 lower rating row ownership 1.5.31: {0}".format("OK" if row.get("ok") else "NEEDS PATCH")]
    if row.get("path"):
        lines.append("  path: {0}".format(row.get("path")))
    lines.append("  DisplaySlot objects: {0}".format("YES" if row.get("display_slots") else "NO"))
    lines.append("  call visible fixed: {0}".format("YES" if row.get("call_visible") else "NO"))
    lines.append("  direct game row disabled/removed: {0}".format("YES" if row.get("direct_game_disabled") else "NO"))
    lines.append("  old game guard remaining: {0}".format("YES" if row.get("old_game_guard_remaining") else "NO"))
    lines.append("  old 1.5.29/1.5.30 DisplaySlot marker: {0}".format("YES" if row.get("old_1529_remaining") else "NO"))
    return "\n".join(lines)


# Ends-at hardening and duration fallback. Keep this global so library fallback
# also benefits when Home/Hub DisplaySlot is inactive.
_lrs_endsat_properties_1528_base = lrs_endsat_properties_1522


def _lrs_parse_duration_minutes_1528(value: Any) -> int:
    text = str(value or "").strip().lower()
    if not text or _lrs_is_raw_infolabel_1528(text):
        return 0
    if text.isdigit():
        # Kodi sometimes exposes duration as seconds; treat large values as seconds.
        num = int(text)
        return int(round(num / 60.0)) if num > 300 else num
    hours = 0
    minutes = 0
    m = re.search(r"(\d+)\s*(?:h|hr|hrs|hour|hours)\b", text)
    if m:
        hours = int(m.group(1))
    m = re.search(r"(\d+)\s*(?:m|min|mins|minute|minutes)\b", text)
    if m:
        minutes = int(m.group(1))
    if hours or minutes:
        return hours * 60 + minutes
    m = re.search(r"\b(\d{1,2}):(\d{2})\b", text)
    if m:
        return int(m.group(1)) * 60 + int(m.group(2))
    return 0


def _lrs_duration_minutes_from_item_1528(item: Dict[str, Any], context: str = "") -> int:
    item = item or {}
    for key in ("duration", "Duration", "runtime", "Runtime", "totaltime", "TotalTime"):
        minutes = _lrs_parse_duration_minutes_1528(item.get(key))
        if minutes:
            return minutes
    labels = []
    for key in ("_af3_container", "_focused_container", "_fallback_container"):
        cid = str(item.get(key) or "").strip()
        if cid.isdigit():
            labels.append("Container({0}).ListItem.Duration".format(cid))
    labels.extend(["ListItem.Duration", "VideoPlayer.Duration"])
    for label in labels:
        minutes = _lrs_parse_duration_minutes_1528(_lrs_info_label_safe_1522(label))
        if minutes:
            return minutes
    return 0


def _lrs_item_type_for_endsat_1531(item: Dict[str, Any]) -> str:
    item = item or {}
    for key in ("type", "DBType", "dbtype", "DBTYPE", "MediaType", "mediatype", "lrs_item_type", "library_ratings_type"):
        value = _lrs_display_clean_1528(item.get(key)).lower()
        if value:
            return value
    return ""


def _lrs_item_allows_endsat_1531(item: Dict[str, Any], context: str = "") -> bool:
    if is_lrs_game_item(item):
        return False
    ctx = str(context or "").lower()
    kind = _lrs_item_type_for_endsat_1531(item)
    if kind in ("tvshow", "season", "set", "sets", "collection", "folder", "game"):
        return False
    if kind in ("movie", "episode"):
        return True
    if ctx in ("player", "videoplayer", "videoosd", "screensaver"):
        return True
    return False


def lrs_endsat_properties_1522(item: Dict[str, Any], context: str = "") -> Dict[str, str]:
    if not _lrs_item_allows_endsat_1531(item, context):
        return {}
    try:
        props = _lrs_endsat_properties_1528_base(item, context) or {}
        label = _lrs_display_clean_1528(props.get("EndsAt_Label"))
        value = _lrs_display_clean_1528(props.get("EndsAt_Value"))
        if props and label and value:
            props["EndsAt_Label"] = label
            props["EndsAt_Value"] = value
            props["EndsAt_IconFile"] = _lrs_display_icon_file_1528(props.get("EndsAt_IconFile") or "ends.png") or "ends.png"
            return props
    except Exception:
        pass
    try:
        if is_lrs_game_item(item):
            return {}
        minutes = _lrs_duration_minutes_from_item_1528(item, context)
        if not minutes:
            return {}
        finish = datetime.now() + timedelta(minutes=minutes)
        value = finish.strftime("%H:%M")
        prefix = _lrs_localize_1522(31600, "Ends at")
        return {
            "EndsAt_Source": "endsat",
            "EndsAt_Icon": "ends.png",
            "EndsAt_IconFile": "ends.png",
            "EndsAt_Label": "{0} {1}".format(prefix, value),
            "EndsAt_Value": value,
        }
    except Exception:
        return {}



def clean_architecture_role_1533():
    return {"role":"rating_data_owner","visual_owner":"script.kodi.patch.manager","patch_owner":"script.kodi.patch.manager"}

# -----------------------------------------------------------------------------
# v1.5.44 - One-shot TMDbHelper-compatible CropV2 cache builder
# -----------------------------------------------------------------------------
CROPV2_BATCH_REPORT_FILE_1544 = os.path.join(
    DIAGNOSTICS_DIR, "cropv2-batch-report.txt"
)


def _cropv2_clean_source_1544(value: Any) -> str:
    source = str(value or "").strip()
    if source.lower() in (
        "", "n/a", "na", "none", "null", "<none>", "unknown"
    ):
        return ""
    return source


def _cropv2_md5_1544(value: Any) -> str:
    import hashlib  # pylint: disable=import-outside-toplevel
    raw = str(value).encode("utf-8", errors="surrogatepass")
    return hashlib.md5(raw).hexdigest()


def _cropv2_canonical_source_1545(source: str) -> str:
    """Return the source string TMDbHelper receives from ListItem.Art.

    Kodi JSON-RPC commonly returns artwork as:
        image://https%3a%2f%2f.../

    TMDbHelper's skin monitor receives the decoded ListItem.Art URL and hashes
    that exact decoded URL before opening the image. Therefore the canonical
    cache filename must use the decoded plain URL, not the JSON-RPC image://
    wrapper and never the string representation of a Python list.
    """
    source = _cropv2_clean_source_1544(source)
    if not source:
        return ""
    variants = _decode_kodi_image_path_1383(source)
    for candidate in variants:
        candidate = _cropv2_clean_source_1544(candidate)
        if candidate:
            return candidate
    return source


def _cropv2_hash_inputs_1544(source: str) -> List[str]:
    """Return one canonical TMDbHelper-compatible hash input."""
    canonical = _cropv2_canonical_source_1545(source)
    return [canonical] if canonical else []


def _cropv2_art_sources_1544(art: Any) -> List[str]:
    if not isinstance(art, dict):
        return []
    priority = (
        "clearlogo", "logo", "tvshow.clearlogo", "artist.clearlogo"
    )
    values: List[str] = []
    for key in priority:
        value = _cropv2_clean_source_1544(art.get(key))
        if value and value not in values:
            values.append(value)
    for key, raw in art.items():
        key_l = str(key or "").lower()
        if not (
            key_l == "clearlogo"
            or key_l.endswith(".clearlogo")
            or key_l == "logo"
            or key_l.endswith(".logo")
        ):
            continue
        value = _cropv2_clean_source_1544(raw)
        if value and value not in values:
            values.append(value)
    return values


def _collect_kodi_cropv2_sources_1544() -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    requests = (
        ("movie", "VideoLibrary.GetMovies", "movies", "movieid"),
        ("tvshow", "VideoLibrary.GetTVShows", "tvshows", "tvshowid"),
    )
    for media_type, method, result_key, id_key in requests:
        result = json_rpc(
            method,
            {
                "properties": ["title", "art"],
                "sort": {"method": "title", "order": "ascending"},
            },
        )
        for item in result.get(result_key, []) or []:
            title = str(
                item.get("title") or item.get("label") or ""
            ).strip()
            dbid = str(item.get(id_key) or "")
            for source in _cropv2_art_sources_1544(item.get("art")):
                rows.append({
                    "media_type": media_type,
                    "title": title or "{0} {1}".format(media_type, dbid),
                    "item_id": dbid,
                    "source": source,
                })
    return rows


def _steam_cropv2_db_1544() -> str:
    try:
        return xbmcvfs.translatePath(
            "special://profile/addon_data/"
            "plugin.program.steam.library/steam_library.db"
        )
    except Exception:
        return os.path.join(
            os.path.dirname(PROFILE.rstrip(os.sep)),
            "plugin.program.steam.library",
            "steam_library.db",
        )


def _collect_steam_cropv2_sources_1544() -> List[Dict[str, str]]:
    path = _steam_cropv2_db_1544()
    if not path or not os.path.isfile(path):
        return []

    connection = None
    rows: List[Dict[str, str]] = []
    try:
        connection = sqlite3.connect(path, timeout=10)
        connection.row_factory = sqlite3.Row
        columns = set(_table_columns(connection, "games"))
        if "appid" not in columns or "clearlogo_url" not in columns:
            return []

        title_columns = [
            column for column in (
                "display_name", "steamedit_name", "name", "steam_name"
            )
            if column in columns
        ]
        title_expr = ", ".join(
            "NULLIF({0},'')".format(column)
            for column in title_columns
        )
        title_sql = (
            "COALESCE({0}, CAST(appid AS TEXT))".format(title_expr)
            if title_expr
            else "CAST(appid AS TEXT)"
        )
        query = (
            "SELECT appid, {0} AS title, clearlogo_url "
            "FROM games "
            "WHERE clearlogo_url IS NOT NULL "
            "AND TRIM(clearlogo_url) <> '' "
            "ORDER BY title COLLATE NOCASE"
        ).format(title_sql)

        for row in connection.execute(query).fetchall():
            source = _cropv2_clean_source_1544(row["clearlogo_url"])
            if not source:
                continue
            rows.append({
                "media_type": "game",
                "title": str(row["title"] or row["appid"]),
                "item_id": str(row["appid"]),
                "source": source,
            })
    except Exception:
        return []
    finally:
        if connection is not None:
            connection.close()
    return rows


def collect_all_cropv2_sources_1544() -> List[Dict[str, Any]]:
    raw_rows = (
        _collect_kodi_cropv2_sources_1544()
        + _collect_steam_cropv2_sources_1544()
    )
    grouped: Dict[str, Dict[str, Any]] = {}
    for row in raw_rows:
        source = _cropv2_clean_source_1544(row.get("source"))
        if not source:
            continue
        entry = grouped.setdefault(
            source,
            {
                "source": source,
                "items": [],
                "media_types": set(),
            },
        )
        identity = "{0}:{1}:{2}".format(
            row.get("media_type") or "",
            row.get("item_id") or "",
            row.get("title") or "",
        )
        if identity not in entry["items"]:
            entry["items"].append(identity)
        entry["media_types"].add(str(row.get("media_type") or ""))

    output: List[Dict[str, Any]] = []
    for source, entry in grouped.items():
        output.append({
            "source": source,
            "items": list(entry["items"]),
            "media_types": sorted(entry["media_types"]),
        })
    output.sort(
        key=lambda item: (
            ",".join(item.get("media_types") or []),
            (item.get("items") or [""])[0].casefold(),
        )
    )
    return output


def _cropv2_texture_db_path_1549() -> str:
    """Return the newest Kodi Textures*.db without creating or downloading anything."""
    db_dir = xbmcvfs.translatePath("special://profile/Database")
    names: List[str] = []
    try:
        names = os.listdir(db_dir)
    except Exception:
        try:
            _dirs, names = xbmcvfs.listdir(db_dir)
        except Exception:
            names = []
    candidates: List[Tuple[int, str]] = []
    for name in names:
        match = re.match(r"^Textures(\d+)\.db$", str(name or ""), re.I)
        if match:
            candidates.append((int(match.group(1)), os.path.join(db_dir, name)))
    if candidates:
        candidates.sort(reverse=True)
        return candidates[0][1]
    fixed = os.path.join(db_dir, "Textures13.db")
    return fixed if os.path.isfile(fixed) else ""


def _cropv2_texture_url_candidates_1549(source: str) -> List[str]:
    """Build lookup variants only; the canonical URL remains the hash input."""
    values: List[str] = []

    def add(value: Any) -> None:
        text = str(value or "").strip()
        if text and text not in values:
            values.append(text)

    add(source)
    for decoded in _decode_kodi_image_path_1383(source):
        add(decoded)
    canonical = _cropv2_canonical_source_1545(source)
    add(canonical)
    for value in list(values):
        if value.startswith("image://"):
            continue
        add("image://{0}/".format(quote(value, safe="")))
        add("image://{0}/".format(quote(value, safe=":/")))
    return values


def _cropv2_cached_file_1549(source: str) -> str:
    """Resolve a clearlogo URL to its existing local Kodi thumbnail-cache file."""
    raw = str(source or "").strip()
    thumbnails = os.path.normcase(os.path.abspath(
        xbmcvfs.translatePath("special://profile/Thumbnails")
    ))
    # A path already inside Kodi's thumbnail cache is safe to read directly.
    for candidate in _decode_kodi_image_path_1383(raw) + [raw]:
        candidate = str(candidate or "").strip()
        if candidate.startswith("special://"):
            candidate = xbmcvfs.translatePath(candidate)
        if candidate and os.path.isabs(candidate):
            try:
                normalized = os.path.normcase(os.path.abspath(candidate))
                if normalized.startswith(thumbnails + os.sep) and os.path.isfile(candidate) and os.path.getsize(candidate) > 0:
                    return candidate
            except Exception:
                pass

    db_path = _cropv2_texture_db_path_1549()
    if not db_path or not os.path.isfile(db_path):
        return ""
    candidates = _cropv2_texture_url_candidates_1549(raw)
    if not candidates:
        return ""
    conn = None
    try:
        conn = sqlite3.connect(db_path, timeout=5)
        conn.row_factory = sqlite3.Row
        columns = {
            str(row[1]) for row in conn.execute("PRAGMA table_info(texture)").fetchall()
        }
        if "url" not in columns or "cachedurl" not in columns:
            return ""
        placeholders = ",".join("?" for _ in candidates)
        rows = conn.execute(
            "SELECT rowid, url, cachedurl FROM texture "
            "WHERE url IN ({0}) ORDER BY rowid DESC".format(placeholders),
            candidates,
        ).fetchall()
        # Conservative case-insensitive fallback for Kodi's encoded image:// spelling.
        if not rows:
            for candidate in candidates:
                row = conn.execute(
                    "SELECT rowid, url, cachedurl FROM texture "
                    "WHERE url=? COLLATE NOCASE ORDER BY rowid DESC LIMIT 1",
                    (candidate,),
                ).fetchone()
                if row:
                    rows = [row]
                    break
        for row in rows:
            cachedurl = str(row["cachedurl"] or "").strip()
            if not cachedurl:
                continue
            if cachedurl.startswith("special://"):
                path = xbmcvfs.translatePath(cachedurl)
            elif os.path.isabs(cachedurl):
                path = cachedurl
            else:
                path = os.path.join(
                    xbmcvfs.translatePath("special://profile/Thumbnails"),
                    cachedurl.replace("/", os.sep),
                )
            try:
                if os.path.isfile(path) and os.path.getsize(path) > 0:
                    return path
            except Exception:
                continue
    except Exception as exc:  # pylint: disable=broad-except
        log("CropV2 texture-cache lookup failed: {0}".format(exc), xbmc.LOGWARNING)
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass
    return ""


def _cropv2_read_bytes_1544(source: str) -> bytes:
    """Read clearlogo bytes strictly from Kodi's existing texture cache."""
    cached_path = _cropv2_cached_file_1549(source)
    if not cached_path:
        raise RuntimeError("Clearlogo is not available in Kodi texture cache")
    handle = None
    try:
        handle = xbmcvfs.File(cached_path, "rb")
        data = handle.readBytes()
        if data:
            return bytes(data)
    finally:
        try:
            if handle is not None:
                handle.close()
        except Exception:
            pass
    raise RuntimeError("Kodi cached clearlogo file is empty or unreadable")


def _cropv2_render_png_1544(source: str) -> bytes:
    """TMDbHelper-compatible CropV2: normal bbox trim, then max 800x310."""
    import io  # pylint: disable=import-outside-toplevel
    from PIL import Image  # pylint: disable=import-outside-toplevel

    source_bytes = _cropv2_read_bytes_1544(source)
    image = Image.open(io.BytesIO(source_bytes))
    cropped = None
    rgba = None
    try:
        image.load()
        try:
            rgba = image.convert("RGBa")
            bbox = rgba.getbbox()
        except Exception:
            bbox = image.getbbox()
        if not bbox:
            raise RuntimeError("Artwork has no non-empty bounding box")
        cropped = image.crop(bbox)
        cropped.thumbnail((800, 310))
        output = io.BytesIO()
        cropped.save(output, "PNG")
        return output.getvalue()
    finally:
        try:
            if rgba is not None:
                rgba.close()
        except Exception:
            pass
        try:
            if cropped is not None:
                cropped.close()
        except Exception:
            pass
        try:
            image.close()
        except Exception:
            pass


def _cropv2_write_bytes_1544(path: str, data: bytes) -> None:
    temp = path + ".lrs1544.tmp"
    handle = None
    try:
        if xbmcvfs.exists(temp):
            xbmcvfs.delete(temp)
        handle = xbmcvfs.File(temp, "wb")
        written = handle.write(data)
        handle.close()
        handle = None
        if not written:
            raise RuntimeError("Kodi VFS wrote zero bytes")
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
        if not xbmcvfs.rename(temp, path):
            if not xbmcvfs.copy(temp, path):
                raise RuntimeError("Could not move temporary CropV2 file")
            xbmcvfs.delete(temp)
    finally:
        try:
            if handle is not None:
                handle.close()
        except Exception:
            pass
        try:
            if xbmcvfs.exists(temp):
                xbmcvfs.delete(temp)
        except Exception:
            pass


def _cropv2_progress_update_1544(
    progress: Any, percent: int, message: str
) -> None:
    if progress is None:
        return
    try:
        progress.update(max(0, min(100, int(percent))), str(message or ""))
    except TypeError:
        try:
            progress.update(
                max(0, min(100, int(percent))),
                "Building CropV2",
                str(message or ""),
            )
        except Exception:
            pass
    except Exception:
        pass


def _cropv2_progress_cancelled_1544(progress: Any) -> bool:
    if progress is None:
        return False
    try:
        return bool(progress.iscanceled())
    except Exception:
        return False


def _write_cropv2_batch_report_1544(lines: List[str]) -> str:
    try:
        os.makedirs(DIAGNOSTICS_DIR, exist_ok=True)
        _atomic_write_text_1541(
            CROPV2_BATCH_REPORT_FILE_1544,
            "\n".join(lines).rstrip() + "\n",
        )
        return CROPV2_BATCH_REPORT_FILE_1544
    except Exception:
        return ""


def read_cropv2_batch_report_1544() -> str:
    try:
        if not os.path.isfile(CROPV2_BATCH_REPORT_FILE_1544):
            return (
                "CropV2 batch report\n"
                "===================\n\n"
                "No CropV2 batch has run yet.\n"
            )
        with open(
            CROPV2_BATCH_REPORT_FILE_1544,
            "r",
            encoding="utf-8-sig",
            errors="replace",
        ) as handle:
            return handle.read()
    except Exception as exc:
        return "Could not read CropV2 report: {0}\n".format(exc)


def cropv2_cache_status_1544() -> Dict[str, Any]:
    crop_dir = _tmdbhelper_cropv2_base_1544()
    files: List[str] = []
    try:
        files = [
            name for name in os.listdir(crop_dir)
            if name.lower().startswith("cropped-")
            and name.lower().endswith(".png")
        ]
    except Exception:
        try:
            _, files = xbmcvfs.listdir(crop_dir)
            files = [
                name for name in files
                if name.lower().startswith("cropped-")
                and name.lower().endswith(".png")
            ]
        except Exception:
            files = []
    return {
        "path": crop_dir,
        "files": len(files),
    }


def _cropv2_read_file_bytes_1545(path: str) -> bytes:
    handle = None
    try:
        handle = xbmcvfs.File(path, "rb")
        data = handle.readBytes()
        return bytes(data or b"")
    finally:
        try:
            if handle is not None:
                handle.close()
        except Exception:
            pass


def _cropv2_same_file_1545(left: str, right: str) -> bool:
    try:
        left_data = _cropv2_read_file_bytes_1545(left)
        right_data = _cropv2_read_file_bytes_1545(right)
        return bool(left_data) and left_data == right_data
    except Exception:
        return False


def _cropv2_copy_file_1545(source: str, destination: str) -> bool:
    try:
        if xbmcvfs.exists(destination):
            return True
        if xbmcvfs.copy(source, destination):
            return xbmcvfs.exists(destination)
    except Exception:
        pass
    return False


def build_all_cropv2_1544(
    force: bool = False,
    progress: Any = None,
) -> Dict[str, Any]:
    started = time.time()
    crop_dir = _tmdbhelper_cropv2_base_1544()
    try:
        xbmcvfs.mkdirs(crop_dir)
    except Exception:
        pass
    try:
        os.makedirs(crop_dir, exist_ok=True)
    except Exception:
        pass

    sources = collect_all_cropv2_sources_1544()
    stats: Dict[str, Any] = {
        "total_sources": len(sources),
        "generated_sources": 0,
        "generated_files": 0,
        "existing_sources": 0,
        "failed_sources": 0,
        "cache_missing_sources": 0,
        "cancelled": False,
        "movie_sources": 0,
        "tvshow_sources": 0,
        "game_sources": 0,
        "path": crop_dir,
        "force": bool(force),
    }
    failures: List[Dict[str, str]] = []

    for entry in sources:
        for media_type in entry.get("media_types") or []:
            key = "{0}_sources".format(media_type)
            if key in stats:
                stats[key] += 1

    total = max(1, len(sources))
    for index, entry in enumerate(sources, start=1):
        if _cropv2_progress_cancelled_1544(progress):
            stats["cancelled"] = True
            break

        labels = entry.get("items") or [entry.get("source") or ""]
        label = labels[0]
        percent = int(((index - 1) * 100) / total)
        _cropv2_progress_update_1544(
            progress,
            percent,
            "{0}/{1}  {2}".format(index, len(sources), label),
        )

        source = str(entry.get("source") or "")
        canonical_source = _cropv2_canonical_source_1545(source)
        hash_inputs = _cropv2_hash_inputs_1544(source)
        destinations = [
            os.path.join(
                crop_dir,
                "cropped-{0}.png".format(_cropv2_md5_1544(value)),
            )
            for value in hash_inputs
        ]
        destinations = list(dict.fromkeys(destinations))

        existing = [
            path for path in destinations if xbmcvfs.exists(path)
        ]
        if existing and not force:
            stats["existing_sources"] += 1
            continue

        try:
            png_data = _cropv2_render_png_1544(canonical_source)
            for destination in destinations:
                if force or not xbmcvfs.exists(destination):
                    _cropv2_write_bytes_1544(destination, png_data)
                    stats["generated_files"] += 1
            stats["generated_sources"] += 1
        except Exception as exc:
            error_text = str(exc) or "<no message>"
            if (
                "Kodi texture cache" in error_text
                or "cached clearlogo" in error_text
            ):
                stats["cache_missing_sources"] += 1
            else:
                stats["failed_sources"] += 1
            failures.append({
                "item": label,
                "source": source,
                "error": "{0}: {1}".format(
                    type(exc).__name__,
                    error_text,
                ),
            })

    _cropv2_progress_update_1544(
        progress,
        100,
        "CropV2 build finished",
    )

    elapsed = time.time() - started
    lines = [
        "LRS CropV2 batch report",
        "=======================",
        "",
        "Recorded at       : {0}".format(now_iso()),
        "Mode              : {0}".format(
            "Rebuild" if force else "Fill missing"
        ),
        "Destination       : {0}".format(crop_dir),
        "TMDbHelper format : cropped-<md5(exact source)>.png",
        "Input bytes       : Kodi texture cache only",
        "Network fallback  : disabled",
        "Hash input        : canonical ListItem.Art source URL (unchanged)",
        "Crop algorithm    : TMDbHelper-compatible bbox, max 800x310",
        "",
        "SUMMARY",
        "-------",
        "Unique clearlogo sources : {0}".format(stats["total_sources"]),
        "Movie sources           : {0}".format(stats["movie_sources"]),
        "TV show sources         : {0}".format(stats["tvshow_sources"]),
        "Steam game sources      : {0}".format(stats["game_sources"]),
        "Generated sources       : {0}".format(stats["generated_sources"]),
        "Generated PNG files     : {0}".format(stats["generated_files"]),
        "Already generated       : {0}".format(stats["existing_sources"]),
        "Source absent in cache  : {0}".format(stats["cache_missing_sources"]),
        "Other failures          : {0}".format(stats["failed_sources"]),
        "Cancelled               : {0}".format(
            "yes" if stats["cancelled"] else "no"
        ),
        "Elapsed                 : {0:.1f} seconds".format(elapsed),
        "",
        "NOTES",
        "-----",
        "Existing CropV2 files are never deleted before a replacement is ready.",
        "Clearlogo bytes are read only from Textures*.db / userdata\\Thumbnails.",
        "A URL is retained only as the unchanged canonical MD5 hash input.",
        "If the texture is not cached, the item is skipped; no download is attempted.",
        "The batch runs only from the LRS menu.",
        "",
    ]

    if failures:
        lines.extend(["FAILURES", "--------"])
        for failure in failures:
            lines.extend([
                "",
                "Item   : {0}".format(failure["item"]),
                "Source : {0}".format(failure["source"]),
                "Error  : {0}".format(failure["error"]),
            ])
        lines.append("")

    report_path = _write_cropv2_batch_report_1544(lines)
    stats["report_path"] = report_path
    stats["elapsed_seconds"] = elapsed
    return stats



# -----------------------------------------------------------------------------
# v1.5.47 - persistent prebuilt clearlogo resolver cache + fail-closed runtime
# -----------------------------------------------------------------------------
# The resolver database is built explicitly from the LRS menu. Runtime never
# scans TMDbHelper's crop_v2 folder and never opens a remote URL. A small RAM
# hot cache is used only for rows already present in the persistent SQLite DB.
CLEARLOGO_RESOLVER_VERSION_1547 = 1
KPM_RUNTIME_ROOT_1568 = xbmcvfs.translatePath(
    "special://profile/addon_data/script.kodi.patch.manager/runtime"
)
KPM_RUNTIME_STATE_1568 = os.path.join(KPM_RUNTIME_ROOT_1568, "state")
KPM_RUNTIME_REPORTS_1568 = os.path.join(KPM_RUNTIME_ROOT_1568, "reports")
os.makedirs(KPM_RUNTIME_STATE_1568, exist_ok=True)
os.makedirs(KPM_RUNTIME_REPORTS_1568, exist_ok=True)
CLEARLOGO_RESOLVER_DB_FILE_1547 = os.path.join(
    KPM_RUNTIME_STATE_1568, "clearlogo-resolver-cache.db"
)
CLEARLOGO_RESOLVER_REPORT_FILE_1547 = os.path.join(
    KPM_RUNTIME_REPORTS_1568, "clearlogo-resolver-report.txt"
)
_CLEARLOGO_RESOLVER_MEMORY_1547: Dict[str, Dict[str, Any]] = {}
_CLEARLOGO_RESOLVER_LAST_ITEM_KEY_1547 = ""


def _clearlogo_resolver_connect_1547() -> sqlite3.Connection:
    os.makedirs(STATE_DIR, exist_ok=True)
    conn = sqlite3.connect(CLEARLOGO_RESOLVER_DB_FILE_1547, timeout=15)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
    except Exception:
        pass
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS resolver_items (
            item_key TEXT PRIMARY KEY,
            media_type TEXT NOT NULL,
            item_id TEXT,
            title TEXT,
            canonical_source TEXT,
            source_hash TEXT,
            resolved_path TEXT,
            status TEXT NOT NULL,
            file_size INTEGER DEFAULT 0,
            file_mtime REAL DEFAULT 0,
            resolver_version INTEGER NOT NULL,
            updated_at INTEGER NOT NULL
        )
        """
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_resolver_source_hash "
        "ON resolver_items(source_hash)"
    )
    conn.execute(
        "CREATE INDEX IF NOT EXISTS idx_resolver_status "
        "ON resolver_items(status)"
    )
    conn.execute(
        """
        CREATE TABLE IF NOT EXISTS resolver_meta (
            key TEXT PRIMARY KEY,
            value TEXT
        )
        """
    )
    return conn


def _clearlogo_resolver_row_dict_1547(row: Any) -> Dict[str, Any]:
    if row is None:
        return {}
    if isinstance(row, dict):
        return dict(row)
    try:
        return {key: row[key] for key in row.keys()}
    except Exception:
        return {}


def _clearlogo_resolver_file_valid_1547(path: Any) -> bool:
    path = str(path or "").strip()
    if not path:
        return False
    try:
        return os.path.isfile(path) and os.path.getsize(path) > 0
    except Exception:
        try:
            return bool(xbmcvfs.exists(path))
        except Exception:
            return False


def _clearlogo_resolver_source_1547(art: Any) -> str:
    values = _cropv2_art_sources_1544(art)
    return str(values[0] if values else "").strip()


def _collect_clearlogo_resolver_kodi_1547() -> List[Dict[str, str]]:
    rows: List[Dict[str, str]] = []
    requests = (
        ("movie", "VideoLibrary.GetMovies", "movies", "movieid"),
        ("tvshow", "VideoLibrary.GetTVShows", "tvshows", "tvshowid"),
    )
    for media_type, method, result_key, id_key in requests:
        try:
            result = json_rpc(
                method,
                {
                    "properties": ["title", "art"],
                    "sort": {"method": "title", "order": "ascending"},
                    "limits": {"start": 0, "end": 100000},
                },
            )
        except Exception as exc:  # pylint: disable=broad-except
            log(
                "Clearlogo resolver Kodi collection failed for {0}: {1}".format(
                    media_type, exc
                ),
                xbmc.LOGWARNING,
            )
            continue
        for item in result.get(result_key, []) or []:
            item_id = str(item.get(id_key) or "").strip()
            if not item_id:
                continue
            rows.append(
                {
                    "item_key": "{0}|{1}".format(media_type, item_id),
                    "media_type": media_type,
                    "item_id": item_id,
                    "title": str(item.get("title") or "").strip(),
                    "source": _clearlogo_resolver_source_1547(item.get("art")),
                }
            )
    return rows


def _collect_clearlogo_resolver_steam_1547() -> List[Dict[str, str]]:
    path = _steam_cropv2_db_1544()
    if not path or not os.path.isfile(path):
        return []
    conn = None
    output: List[Dict[str, str]] = []
    try:
        conn = sqlite3.connect(path, timeout=10)
        conn.row_factory = sqlite3.Row
        columns = set(_table_columns(conn, "games"))
        if "appid" not in columns:
            return []
        title_columns = [
            name
            for name in ("display_name", "steamedit_name", "name", "steam_name")
            if name in columns
        ]
        title_exprs = ["NULLIF(games.{0},'')".format(name) for name in title_columns]
        title_exprs.append("CAST(games.appid AS TEXT)")
        title_expr = (
            title_exprs[0]
            if len(title_exprs) == 1
            else "COALESCE({0})".format(", ".join(title_exprs))
        )
        source_expr = (
            "COALESCE(games.clearlogo_url,'')"
            if "clearlogo_url" in columns
            else "''"
        )
        sql = (
            "SELECT games.appid AS appid, {0} AS title, "
            "{1} AS clearlogo_url FROM games"
        ).format(title_expr, source_expr)
        clauses: List[str] = []
        tables = {
            str(row[0])
            for row in conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table'"
            ).fetchall()
        }
        if "library_membership" in tables:
            sql += (
                " JOIN library_membership "
                "ON library_membership.appid=games.appid"
            )
            clauses.append("library_membership.is_active=1")
        if "hidden_games" in tables:
            clauses.append(
                "games.appid NOT IN (SELECT appid FROM hidden_games)"
            )
        if "manual_hidden_games" in tables:
            clauses.append(
                "games.appid NOT IN (SELECT appid FROM manual_hidden_games)"
            )
        if clauses:
            sql += " WHERE " + " AND ".join(clauses)
        sql += " ORDER BY title COLLATE NOCASE"
        for row in conn.execute(sql).fetchall():
            appid = str(row["appid"] or "").strip()
            if not appid:
                continue
            output.append(
                {
                    "item_key": "game|steam|{0}".format(appid),
                    "media_type": "game",
                    "item_id": appid,
                    "title": str(row["title"] or appid).strip(),
                    "source": str(row["clearlogo_url"] or "").strip(),
                }
            )
    except Exception as exc:  # pylint: disable=broad-except
        log(
            "Clearlogo resolver Steam collection failed: {0}".format(exc),
            xbmc.LOGWARNING,
        )
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass
    return output


def collect_all_clearlogo_resolver_items_1547() -> List[Dict[str, str]]:
    grouped: Dict[str, Dict[str, str]] = {}
    for row in (
        _collect_clearlogo_resolver_kodi_1547()
        + _collect_clearlogo_resolver_steam_1547()
    ):
        key = str(row.get("item_key") or "").strip()
        if key:
            grouped[key] = dict(row)
    output = list(grouped.values())
    output.sort(
        key=lambda row: (
            str(row.get("media_type") or ""),
            str(row.get("title") or "").casefold(),
            str(row.get("item_id") or ""),
        )
    )
    return output


def _clearlogo_resolver_crop_index_1547() -> Dict[str, Any]:
    crop_dir = _tmdbhelper_cropv2_base_1544()
    names: List[str] = []
    try:
        names = [name for name in os.listdir(crop_dir) if name]
    except Exception:
        names = []
    return {
        "path": crop_dir,
        "names": names,
        "lower": {name.lower(): name for name in names},
    }


def _clearlogo_resolver_find_path_1547(
    source: str, crop_index: Dict[str, Any]
) -> str:
    source = str(source or "").strip()
    if not source:
        return ""
    crop_dir = str(crop_index.get("path") or "")
    lower_to_name = crop_index.get("lower") or {}
    names = crop_index.get("names") or []
    hashes = _candidate_crop_hashes_1383(source)
    if not hashes:
        return ""
    prefixes: List[str] = []
    for hash_value in hashes:
        prefixes.extend(("cropped-" + hash_value, hash_value))
    for prefix in prefixes:
        for ext in (".png", ".webp", ".jpg", ".jpeg"):
            actual = lower_to_name.get((prefix + ext).lower())
            if not actual:
                continue
            path = os.path.join(crop_dir, actual)
            if _clearlogo_resolver_file_valid_1547(path):
                return path
    matches: List[str] = []
    for name in names:
        low = str(name or "").lower()
        if not (
            low.startswith("cropped-")
            and low.rsplit(".", 1)[-1] in ("png", "webp", "jpg", "jpeg")
        ):
            continue
        for hash_value in hashes:
            if low.startswith(("cropped-" + hash_value[:16]).lower()):
                matches.append(name)
                break
    matches = list(dict.fromkeys(matches))
    if len(matches) == 1:
        path = os.path.join(crop_dir, matches[0])
        if _clearlogo_resolver_file_valid_1547(path):
            return path
    return ""


def _clearlogo_resolver_write_report_1547(lines: List[str]) -> str:
    try:
        os.makedirs(REPORTS_DIR, exist_ok=True)
        _atomic_write_text_1541(
            CLEARLOGO_RESOLVER_REPORT_FILE_1547,
            "\n".join(lines).rstrip() + "\n",
        )
        return CLEARLOGO_RESOLVER_REPORT_FILE_1547
    except Exception:
        return ""


def read_clearlogo_resolver_report_1547() -> str:
    try:
        if not os.path.isfile(CLEARLOGO_RESOLVER_REPORT_FILE_1547):
            return (
                "Clearlogo resolver cache report\n"
                "===============================\n\n"
                "No resolver cache build has run yet.\n"
            )
        with open(
            CLEARLOGO_RESOLVER_REPORT_FILE_1547,
            "r",
            encoding="utf-8-sig",
            errors="replace",
        ) as handle:
            return handle.read()
    except Exception as exc:  # pylint: disable=broad-except
        return "Could not read clearlogo resolver report: {0}\n".format(exc)


def clearlogo_resolver_status_1547() -> Dict[str, Any]:
    result: Dict[str, Any] = {
        "path": CLEARLOGO_RESOLVER_DB_FILE_1547,
        "exists": os.path.isfile(CLEARLOGO_RESOLVER_DB_FILE_1547),
        "total": 0,
        "resolved": 0,
        "no_source": 0,
        "cropv2_missing": 0,
        "invalid_file": 0,
        "resolver_version": CLEARLOGO_RESOLVER_VERSION_1547,
    }
    if not result["exists"]:
        return result
    conn = None
    try:
        conn = _clearlogo_resolver_connect_1547()
        for row in conn.execute(
            "SELECT status, COUNT(*) AS count FROM resolver_items GROUP BY status"
        ).fetchall():
            status = str(row["status"] or "")
            count = int(row["count"] or 0)
            result[status] = count
            result["total"] += count
        meta = conn.execute(
            "SELECT value FROM resolver_meta WHERE key='last_build_at'"
        ).fetchone()
        result["last_build_at"] = str(meta[0] if meta else "")
    except Exception as exc:  # pylint: disable=broad-except
        result["error"] = str(exc)
    finally:
        try:
            if conn is not None:
                conn.close()
        except Exception:
            pass
    return result


def build_clearlogo_resolver_cache_1547(
    rebuild: bool = False, progress: Any = None
) -> Dict[str, Any]:
    started = time.time()
    items = collect_all_clearlogo_resolver_items_1547()
    crop_index = _clearlogo_resolver_crop_index_1547()
    stats: Dict[str, Any] = {
        "mode": "rebuild_all" if rebuild else "fill_missing",
        "total": len(items),
        "resolved": 0,
        "no_source": 0,
        "cropv2_missing": 0,
        "invalid_file": 0,
        "kept_valid": 0,
        "written": 0,
        "removed_stale_items": 0,
        "cancelled": False,
        "network_access_attempted": 0,
        "database": CLEARLOGO_RESOLVER_DB_FILE_1547,
        "crop_dir": crop_index.get("path") or "",
    }
    conn = _clearlogo_resolver_connect_1547()
    try:
        if rebuild:
            conn.execute("DELETE FROM resolver_items")
        existing: Dict[str, Dict[str, Any]] = {}
        if not rebuild:
            for row in conn.execute("SELECT * FROM resolver_items").fetchall():
                data = _clearlogo_resolver_row_dict_1547(row)
                existing[str(data.get("item_key") or "")] = data

        seen = set()
        total = max(1, len(items))
        for index, item in enumerate(items, start=1):
            if _cropv2_progress_cancelled_1544(progress):
                stats["cancelled"] = True
                break
            item_key = str(item.get("item_key") or "").strip()
            if not item_key:
                continue
            seen.add(item_key)
            _cropv2_progress_update_1544(
                progress,
                int(((index - 1) * 100) / total),
                "{0}/{1}  {2}".format(
                    index, len(items), item.get("title") or item_key
                ),
            )
            source = str(item.get("source") or "").strip()
            canonical = _cropv2_canonical_source_1545(source) if source else ""
            source_hash = _cropv2_md5_1544(canonical) if canonical else ""
            old = existing.get(item_key) or {}
            old_valid = (
                int(old.get("resolver_version") or 0)
                == CLEARLOGO_RESOLVER_VERSION_1547
                and str(old.get("source_hash") or "") == source_hash
                and str(old.get("status") or "") == "resolved"
                and _clearlogo_resolver_file_valid_1547(old.get("resolved_path"))
            )
            if old_valid:
                resolved_path = str(old.get("resolved_path") or "")
                status = "resolved"
                stats["kept_valid"] += 1
            elif not canonical:
                resolved_path = ""
                status = "no_source"
            else:
                resolved_path = _clearlogo_resolver_find_path_1547(
                    source, crop_index
                )
                status = "resolved" if resolved_path else "cropv2_missing"
            file_size = 0
            file_mtime = 0.0
            if resolved_path:
                try:
                    file_size = int(os.path.getsize(resolved_path))
                    file_mtime = float(os.path.getmtime(resolved_path))
                except Exception:
                    if not _clearlogo_resolver_file_valid_1547(resolved_path):
                        resolved_path = ""
                        status = "invalid_file"
            stats[status] = int(stats.get(status) or 0) + 1
            conn.execute(
                """
                INSERT INTO resolver_items (
                    item_key, media_type, item_id, title,
                    canonical_source, source_hash, resolved_path, status,
                    file_size, file_mtime, resolver_version, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                ON CONFLICT(item_key) DO UPDATE SET
                    media_type=excluded.media_type,
                    item_id=excluded.item_id,
                    title=excluded.title,
                    canonical_source=excluded.canonical_source,
                    source_hash=excluded.source_hash,
                    resolved_path=excluded.resolved_path,
                    status=excluded.status,
                    file_size=excluded.file_size,
                    file_mtime=excluded.file_mtime,
                    resolver_version=excluded.resolver_version,
                    updated_at=excluded.updated_at
                """,
                (
                    item_key,
                    str(item.get("media_type") or ""),
                    str(item.get("item_id") or ""),
                    str(item.get("title") or ""),
                    canonical,
                    source_hash,
                    resolved_path,
                    status,
                    file_size,
                    file_mtime,
                    CLEARLOGO_RESOLVER_VERSION_1547,
                    int(time.time()),
                ),
            )
            stats["written"] += 1

        if not stats["cancelled"]:
            existing_keys = {
                str(row[0])
                for row in conn.execute("SELECT item_key FROM resolver_items")
            }
            stale = sorted(existing_keys - seen)
            if stale:
                conn.executemany(
                    "DELETE FROM resolver_items WHERE item_key=?",
                    [(key,) for key in stale],
                )
                stats["removed_stale_items"] = len(stale)
            meta = {
                "last_build_at": now_iso(),
                "last_build_mode": stats["mode"],
                "resolver_version": str(CLEARLOGO_RESOLVER_VERSION_1547),
                "item_count": str(len(items)),
                "crop_dir": str(crop_index.get("path") or ""),
                "network_policy": "cache-only-no-network",
            }
            for key, value in meta.items():
                conn.execute(
                    "INSERT INTO resolver_meta(key,value) VALUES(?,?) "
                    "ON CONFLICT(key) DO UPDATE SET value=excluded.value",
                    (key, str(value)),
                )
        conn.commit()
    finally:
        conn.close()

    _CLEARLOGO_RESOLVER_MEMORY_1547.clear()
    _cropv2_progress_update_1544(
        progress, 100, "Clearlogo resolver cache finished"
    )
    stats["elapsed_seconds"] = time.time() - started
    lines = [
        "LRS persistent clearlogo resolver cache",
        "=======================================",
        "",
        "Recorded at                  : {0}".format(now_iso()),
        "Mode                         : {0}".format(stats["mode"]),
        "Database                     : {0}".format(
            CLEARLOGO_RESOLVER_DB_FILE_1547
        ),
        "CropV2 directory             : {0}".format(
            stats.get("crop_dir") or ""
        ),
        "Resolver version             : {0}".format(
            CLEARLOGO_RESOLVER_VERSION_1547
        ),
        "Network access attempted     : 0",
        "Runtime folder scans         : disabled",
        "",
        "SUMMARY",
        "-------",
        "Library items found          : {0}".format(stats["total"]),
        "Resolved CropV2              : {0}".format(stats["resolved"]),
        "No clearlogo source          : {0}".format(stats["no_source"]),
        "CropV2 file missing          : {0}".format(
            stats["cropv2_missing"]
        ),
        "Invalid file                 : {0}".format(stats["invalid_file"]),
        "Existing valid rows kept     : {0}".format(stats["kept_valid"]),
        "Rows written/updated         : {0}".format(stats["written"]),
        "Removed library rows         : {0}".format(
            stats["removed_stale_items"]
        ),
        "Cancelled                    : {0}".format(
            "yes" if stats["cancelled"] else "no"
        ),
        "Elapsed                      : {0:.1f} seconds".format(
            stats["elapsed_seconds"]
        ),
        "",
        "RUNTIME POLICY",
        "--------------",
        "Runtime reads only this SQLite database and validates the mapped file.",
        "Runtime does not scan crop_v2, calculate alternate filenames, or use internet fallback.",
        "A missing/unbuilt row fails closed so the previous slide logo cannot be reused.",
        "",
    ]
    stats["report_path"] = _clearlogo_resolver_write_report_1547(lines)
    return stats


def clearlogo_resolver_lookup_1547(
    item_key: Any, runtime_source: Any = ""
) -> Dict[str, Any]:
    key = str(item_key or "").strip()
    if not key:
        return {"status": "identity_missing", "item_key": ""}
    runtime_canonical = (
        _cropv2_canonical_source_1545(str(runtime_source or "").strip())
        if str(runtime_source or "").strip()
        else ""
    )
    runtime_hash = (
        _cropv2_md5_1544(runtime_canonical) if runtime_canonical else ""
    )
    cached = _CLEARLOGO_RESOLVER_MEMORY_1547.get(key)
    if not cached:
        if not os.path.isfile(CLEARLOGO_RESOLVER_DB_FILE_1547):
            return {"status": "cache_unbuilt", "item_key": key}
        conn = None
        try:
            conn = _clearlogo_resolver_connect_1547()
            row = conn.execute(
                "SELECT * FROM resolver_items WHERE item_key=? LIMIT 1",
                (key,),
            ).fetchone()
            cached = _clearlogo_resolver_row_dict_1547(row)
        except Exception as exc:  # pylint: disable=broad-except
            return {
                "status": "cache_error",
                "item_key": key,
                "error": str(exc),
            }
        finally:
            try:
                if conn is not None:
                    conn.close()
            except Exception:
                pass
        if not cached:
            return {"status": "cache_miss", "item_key": key}
        _CLEARLOGO_RESOLVER_MEMORY_1547[key] = dict(cached)
    result = dict(cached)
    result["item_key"] = key
    if (
        int(result.get("resolver_version") or 0)
        != CLEARLOGO_RESOLVER_VERSION_1547
    ):
        result["status"] = "resolver_version_mismatch"
        return result
    saved_hash = str(result.get("source_hash") or "")
    if runtime_hash and saved_hash and runtime_hash != saved_hash:
        result["status"] = "source_changed"
        result["runtime_source_hash"] = runtime_hash
        return result
    if str(result.get("status") or "") == "resolved":
        path = str(result.get("resolved_path") or "")
        if not _clearlogo_resolver_file_valid_1547(path):
            result["status"] = "invalid_file"
            result["resolved_path"] = ""
    return result


def _publish_screensaver_clearlogo_props_1547(
    props: Dict[str, Any]
) -> None:
    try:
        import xbmcgui  # pylint: disable=import-outside-toplevel
        home = xbmcgui.Window(10000)
    except Exception:
        return
    for key, value in (props or {}).items():
        _publish_property(
            home,
            AF3_PREFIX + "Screensaver." + str(key),
            str(value or ""),
        )


def _screensaver_mediahub_key_1547() -> str:
    try:
        return xbmc.getInfoLabel(
            "Container(1297).ListItem.Property(mediahub_item_key)"
        ).strip()
    except Exception:
        return ""


def update_screensaver_clearlogo_properties(
    item: Dict[str, Any]
) -> Dict[str, str]:
    """Publish only a prebuilt resolver result for the active slide.

    No default/native clearlogo fallback is used. If the current item has not
    been built, changed, or lost its CropV2 file, the area stays blank. KPM's
    XML additionally compares the current ListItem mediahub_item_key directly
    with ClearLogoFinalItemKey, so a previous left/right logo cannot cross over.
    """
    global _CLEARLOGO_RESOLVER_LAST_ITEM_KEY_1547
    try:
        item_title = str(
            (item or {}).get("title")
            or xbmc.getInfoLabel("Container(1297).ListItem.Title")
            or xbmc.getInfoLabel("Container(1297).ListItem.Label")
            or ""
        ).strip()
        runtime_source = xbmc.getInfoLabel(
            "Container(1297).ListItem.Art(clearlogo)"
        ).strip()
    except Exception:
        item_title = str((item or {}).get("title") or "").strip()
        runtime_source = ""
    try:
        derived_key = identity_key(item or {})
    except Exception:
        derived_key = ""
    container_key = _screensaver_mediahub_key_1547()
    item_key = container_key or derived_key

    # Publish a current-key pending snapshot before any disk lookup. This turns
    # every slide transition into fail-closed behavior even if SQLite is busy.
    if item_key != _CLEARLOGO_RESOLVER_LAST_ITEM_KEY_1547:
        _CLEARLOGO_RESOLVER_LAST_ITEM_KEY_1547 = item_key
        _publish_screensaver_clearlogo_props_1547(
            {
                "CropV2Image": "",
                "CropV2Source": "persistent_resolver",
                "CropV2Title": item_title,
                "DefaultClearLogo": "",
                "ClearLogoMode": "pending",
                "ClearLogoFinal": "",
                "ClearLogoFinalMode": "pending",
                "ClearLogoFinalSource": "persistent_resolver_pending",
                "ClearLogoFinalTitle": item_title,
                "ClearLogoFinalItemKey": item_key,
                "ClearLogoResolverReady": "false",
                "ClearLogoResolverStatus": "pending",
                "ClearLogoResolverSourceHash": "",
            }
        )

    if container_key and derived_key and container_key != derived_key:
        resolved = {
            "status": "identity_mismatch",
            "item_key": container_key,
        }
    else:
        resolved = clearlogo_resolver_lookup_1547(item_key, runtime_source)
    status = str(resolved.get("status") or "cache_miss")
    final_image = ""
    mode = "pending"
    ready = "false"
    source_label = "persistent_resolver_" + status
    if status == "resolved" and resolved.get("resolved_path"):
        final_image = str(resolved.get("resolved_path") or "")
        mode = "cropv2"
        ready = "true"
        source_label = "persistent_resolver_db"
    elif status in ("no_source", "cropv2_missing"):
        # These are completed build results, not a transition gap. The skin may
        # render the current title, but never the previous item's image.
        mode = "title"
        ready = "true"

    props = {
        "CropV2Image": final_image,
        "CropV2Source": source_label,
        "CropV2Title": item_title,
        "DefaultClearLogo": "",
        "ClearLogoMode": mode,
        "ClearLogoFinal": final_image,
        "ClearLogoFinalMode": mode,
        "ClearLogoFinalSource": source_label,
        "ClearLogoFinalTitle": item_title,
        "ClearLogoFinalItemKey": item_key,
        "ClearLogoResolverReady": ready,
        "ClearLogoResolverStatus": status,
        "ClearLogoResolverSourceHash": str(resolved.get("source_hash") or ""),
    }
    _publish_screensaver_clearlogo_props_1547(props)
    # The service records only when this selection signature changes. Keeping
    # history I/O outside this hot path prevents a 0.05-second screensaver poll
    # from rewriting diagnostics twenty times per second.
    return {key: str(value or "") for key, value in props.items()}


def clear_screensaver_clearlogo_properties() -> None:
    global _CLEARLOGO_RESOLVER_LAST_ITEM_KEY_1547
    _CLEARLOGO_RESOLVER_LAST_ITEM_KEY_1547 = ""
    _publish_screensaver_clearlogo_props_1547(
        {
            "CropV2Image": "",
            "CropV2Source": "",
            "CropV2Title": "",
            "DefaultClearLogo": "",
            "ClearLogoMode": "",
            "ClearLogoFinal": "",
            "ClearLogoFinalMode": "",
            "ClearLogoFinalSource": "",
            "ClearLogoFinalTitle": "",
            "ClearLogoFinalItemKey": "",
            "ClearLogoResolverReady": "",
            "ClearLogoResolverStatus": "",
            "ClearLogoResolverSourceHash": "",
        }
    )


LRS_EXTRA_PROPERTY_NAMES = tuple(
    dict.fromkeys(
        tuple(LRS_EXTRA_PROPERTY_NAMES)
        + (
            "Screensaver.ClearLogoResolverReady",
            "Screensaver.ClearLogoResolverStatus",
            "Screensaver.ClearLogoResolverSourceHash",
        )
    )
)


_diagnostic_candidates_1547_base = _diagnostic_candidates_1397


def _diagnostic_candidates_1397() -> List[str]:
    paths = list(_diagnostic_candidates_1547_base())
    for path in (
        CLEARLOGO_RESOLVER_DB_FILE_1547,
        CLEARLOGO_RESOLVER_REPORT_FILE_1547,
    ):
        if path and os.path.exists(path) and path not in paths:
            paths.append(path)
    return paths

# -----------------------------------------------------------------------------
# v1.5.51 - MDBList Letterboxd source + persistent column + AF3/KPM slot
# -----------------------------------------------------------------------------
# MDBList returns an aggregate payload whose ratings[] rows identify the real
# source. Letterboxd must come only from the row whose normalized source is
# `letterboxd`; the MDBList aggregate score is a different rating family.
CACHE_VERSION = max(CACHE_VERSION, 31)

RATING_LOGICALS_BY_TYPE.setdefault("movie", set()).add("letterboxd")
RATING_LOGICALS_BY_TYPE.setdefault("tvshow", set()).add("letterboxd")
MDBLIST_PROVIDER_LOGICALS = set(MDBLIST_PROVIDER_LOGICALS) | {"letterboxd"}
MDBLIST_LOGICALS = set(MDBLIST_LOGICALS) | {"letterboxd"}
RATING_SOURCE_TO_LOGICAL.update({
    "letterboxd": "letterboxd",
    "letterboxdscore": "letterboxd",
    "letterboxdrating": "letterboxd",
})
RATING_ALIAS_PRIORITY["letterboxd"] = ["letterboxd", "letterboxdscore", "letterboxdrating"]
RATING_PROVIDER_PRIORITY["letterboxd"] = ["mdblist", "kodi"]
RATING_LOGICAL_TO_CACHE_KEY["letterboxd"] = "letterboxd"

# Add the persistent value directly after Trakt. Existing databases are rebuilt
# transactionally and preserve all old values.
FINAL_RATINGS_COLUMNS = [
    "item_key", "title", "imdb", "tmdb", "rottentomatoes", "rottentomatoes_image",
    "rottentomatoes_user", "rottentomatoes_userimage", "metacritic", "trakt", "letterboxd", "top250",
    "showtitle", "season", "episode", "year", "series_status", "series_status_date",
    "oscar_wins", "oscar_best_picture", "emmy_wins", "awards_text", "imdb_id", "tmdb_id", "dbid", "media_type",
    "rottentomatoes_slug", "rottentomatoes_status", "updated_at", "timestamp",
]
SIMPLE_RATING_COLUMNS = FINAL_RATINGS_COLUMNS


def _rating_schema_sql_1551(table_name: str = "ratings") -> str:
    return """
        CREATE TABLE IF NOT EXISTS {table} (
            item_key TEXT PRIMARY KEY,
            title TEXT,
            imdb TEXT,
            tmdb TEXT,
            rottentomatoes TEXT,
            rottentomatoes_image TEXT,
            rottentomatoes_user TEXT,
            rottentomatoes_userimage TEXT,
            metacritic TEXT,
            trakt TEXT,
            letterboxd TEXT,
            top250 INTEGER,
            showtitle TEXT,
            season INTEGER,
            episode INTEGER,
            year TEXT,
            series_status TEXT,
            series_status_date TEXT,
            oscar_wins INTEGER,
            oscar_best_picture TEXT,
            emmy_wins INTEGER,
            awards_text TEXT,
            imdb_id TEXT,
            tmdb_id TEXT,
            dbid INTEGER,
            media_type TEXT,
            rottentomatoes_slug TEXT,
            rottentomatoes_status TEXT,
            updated_at TEXT,
            timestamp INTEGER
        )
    """.format(table=str(table_name))


def _rating_schema_sql_1430(table_name: str = "ratings") -> str:
    return _rating_schema_sql_1551(table_name)


def _simple_rating_schema_sql() -> str:
    return _rating_schema_sql_1551("ratings")


_simple_db_rating_values_1551_base = _simple_db_rating_values

def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    old_values = tuple(_simple_db_rating_values_1551_base(entry, item_key))
    ratings = (entry or {}).get("ratings") or {}
    letterboxd = _display_number_for_db("letterboxd", ratings.get("letterboxd") or {})
    # Current schema inserts Letterboxd before Top 250.
    return old_values[:10] + (letterboxd,) + old_values[10:]


_ratings_only_row_to_entry_1551_base = _ratings_only_row_to_entry

def _ratings_only_row_to_entry(row: sqlite3.Row) -> Dict[str, Any]:
    entry = _ratings_only_row_to_entry_1551_base(row)
    rating = _simple_rating_from_cell("letterboxd", _row_value(row, "letterboxd"))
    if rating:
        ratings = dict(entry.get("ratings") or {})
        ratings["letterboxd"] = rating
        entry["ratings"] = preserve_ratings_for_item(entry.get("type") or entry.get("media_type"), ratings)
    return entry


_rating_slot_order_1551_base = _rating_slot_order

def _rating_slot_order() -> List[str]:
    defaults = ["imdb", "rt_audience", "rt_critic", "metacritic", "tmdb", "trakt", "letterboxd"]
    allowed = set(defaults + ["none"])
    out: List[str] = []
    for idx, default in enumerate(defaults, start=1):
        value = _rating_setting_choice("display_rating_slot_{0}".format(idx), default)
        if value not in allowed:
            value = default
        if value in ("none", ""):
            continue
        if value not in out:
            out.append(value)
    return out


_slot_source_value_1551_base = _slot_source_value

def _slot_source_value(record: Dict[str, Any], logical: str, ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> Optional[Dict[str, str]]:
    if logical == "letterboxd":
        value = display_decimal(first_rating(ratings, "letterboxd"))
        if not value:
            return None
        return {"Source": "letterboxd", "Icon": "letterboxd.png", "IconFile": "letterboxd.png", "Label": value, "Value": value}
    return _slot_source_value_1551_base(record, logical, ratings, icons, top250_display)


_af3_values_1551_base = af3_values

def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    values = _af3_values_1551_base(record)
    ratings = preserve_ratings_for_item((record or {}).get("type"), (record or {}).get("ratings") or {})
    value = display_decimal(first_rating(ratings, "letterboxd"))
    if value:
        values["Letterboxd_Rating"] = value
        values["Letterboxd"] = value
        values["letterboxd"] = value
        values["letterboxd_rating"] = value
    return values

# Make the additional compatibility aliases clearable between focus changes.
LRS_EXTRA_PROPERTY_NAMES = tuple(dict.fromkeys(tuple(LRS_EXTRA_PROPERTY_NAMES) + (
    "Letterboxd", "letterboxd", "letterboxd_rating",
)))



# -----------------------------------------------------------------------------
# v1.5.52 - Letterboxd uses MDBList ratings[].score (0-100), not value (0-5)
# -----------------------------------------------------------------------------
# Example MDBList row:
#   {"source":"letterboxd", "value":3.1, "score":62, ...}
# The user-facing Letterboxd number is therefore 62. Keep the icon/slot family
# unchanged and publish a whole number without a percent sign.
CACHE_VERSION = max(CACHE_VERSION, 32)


def _letterboxd_score_1552(rating: Any) -> Optional[float]:
    if not isinstance(rating, dict) or is_no_rating_marker(rating):
        return None
    score = safe_float(rating.get("score"))
    value = safe_float(rating.get("value"))
    provider = str(rating.get("provider") or "").strip().lower()

    # Current MDBList payload: score is authoritative.
    if score is not None and score > 5:
        return max(0.0, min(100.0, score))
    if value is not None and value > 5:
        return max(0.0, min(100.0, value))

    # Defensive final fallback for unusual non-MDBList rows.
    if score is not None:
        return max(0.0, min(100.0, score))
    if value is not None:
        return max(0.0, min(100.0, value))
    return None


_normalized_rating_1552_base = normalized_rating

def normalized_rating(source: str, value: Any = None, score: Any = None, votes: Any = None, provider: str = "") -> Dict[str, Any]:
    rating = _normalized_rating_1552_base(source, value, score, votes, provider)
    clean = re.sub(r"[^a-z0-9]", "", str(source or "").lower())
    if clean == "letterboxd" and str(provider or "").strip().lower() == "mdblist":
        numeric_score = safe_float(score)
        if numeric_score is None:
            numeric_value = safe_float(value)
            numeric_score = numeric_value * 20.0 if numeric_value is not None else None
        if numeric_score is not None:
            numeric_score = max(0.0, min(100.0, numeric_score))
            rating["value"] = numeric_score
            rating["score"] = numeric_score
    return rating


_rating_display_number_1552_base = _rating_display_number

def _rating_display_number(logical: str, rating: Dict[str, Any]) -> Any:
    if str(logical or "").strip().lower() == "letterboxd":
        number = _letterboxd_score_1552(rating)
        if number is None:
            return ""
        return NO_RATING_VALUE if number <= 0 else number
    return _rating_display_number_1552_base(logical, rating)


_display_number_for_db_1552_base = _display_number_for_db

def _display_number_for_db(logical: str, rating: Any) -> str:
    if str(logical or "").strip().lower() == "letterboxd":
        number = _letterboxd_score_1552(rating)
        if number is None or number <= 0:
            return ""
        return _whole_percent(number)
    return _display_number_for_db_1552_base(logical, rating)


_simple_rating_from_cell_1552_base = _simple_rating_from_cell

def _simple_rating_from_cell(logical: str, cell: Any) -> Dict[str, Any]:
    if str(logical or "").strip().lower() == "letterboxd":
        text = str(cell if cell is not None else "").strip()
        if not text:
            return {}
        if text.upper() in ("N/A", "NO_RATING", "NA"):
            return {"cache_key": "letterboxd", "logical": "letterboxd", "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
        number = safe_float(text.replace("%", ""))
        if number is None:
            return {}
        if number <= 0:
            return {"cache_key": "letterboxd", "logical": "letterboxd", "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE, "value": NO_RATING_VALUE, "score": "", "votes": "", "no_rating": True}
        number = max(0.0, min(100.0, number))
        return {"cache_key": "letterboxd", "logical": "letterboxd", "provider": "letterboxd", "source": "letterboxd", "value": number, "score": number, "votes": ""}
    return _simple_rating_from_cell_1552_base(logical, cell)




_rating_display_for_report_1552_base = _rating_display_for_report

def _rating_display_for_report(logical: str, rating: Dict[str, Any]) -> str:
    if str(logical or "").strip().lower() == "letterboxd":
        number = _letterboxd_score_1552(rating)
        return _whole_percent(number) if number is not None and number > 0 else ""
    return _rating_display_for_report_1552_base(logical, rating)


_slot_source_value_1552_base = _slot_source_value

def _slot_source_value(record: Dict[str, Any], logical: str, ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> Optional[Dict[str, str]]:
    if logical == "letterboxd":
        number = _letterboxd_score_1552(first_rating(ratings, "letterboxd"))
        value = _whole_percent(number) if number is not None and number > 0 else ""
        if not value:
            return None
        return {"Source": "letterboxd", "Icon": "letterboxd.png", "IconFile": "letterboxd.png", "Label": value, "Value": value}
    return _slot_source_value_1552_base(record, logical, ratings, icons, top250_display)


_af3_values_1552_base = af3_values

def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    values = _af3_values_1552_base(record)
    ratings = preserve_ratings_for_item((record or {}).get("type"), (record or {}).get("ratings") or {})
    number = _letterboxd_score_1552(first_rating(ratings, "letterboxd"))
    value = _whole_percent(number) if number is not None and number > 0 else ""
    if value:
        values["Letterboxd_Rating"] = value
        values["Letterboxd"] = value
        values["letterboxd"] = value
        values["letterboxd_rating"] = value
    return values

_record_missing_logicals_1553_base = record_missing_logicals

# -----------------------------------------------------------------------------
# v1.5.53 - strict MDBList Letterboxd score, no database reinterpretation
# -----------------------------------------------------------------------------
# Letterboxd is accepted only from MDBList ratings[] where:
#   source == "letterboxd"
#   score  == an integer in the 1..100 range
# The 0-5 `value` field is deliberately ignored. Old 0-5 cache values are not
# converted, and non-MDBList/Kodi aliases are not accepted for this family.
CACHE_VERSION = max(CACHE_VERSION, 33)

RATING_SOURCE_TO_LOGICAL.pop("letterboxdscore", None)
RATING_SOURCE_TO_LOGICAL.pop("letterboxdrating", None)
RATING_ALIAS_PRIORITY["letterboxd"] = ["letterboxd"]
RATING_PROVIDER_PRIORITY["letterboxd"] = ["mdblist"]


def _strict_letterboxd_score_1553(rating: Any) -> Optional[int]:
    if not isinstance(rating, dict) or is_no_rating_marker(rating):
        return None
    source = clean_rating_source(rating.get("source") or "")
    provider = clean_rating_source(rating.get("provider") or "")
    if source != "letterboxd" or provider != "mdblist":
        return None
    number = safe_float(rating.get("score"))
    if number is None or not float(number).is_integer():
        return None
    score = int(number)
    return score if 1 <= score <= 100 else None


_normalized_rating_1553_base = _normalized_rating_1552_base

def normalized_rating(source: str, value: Any = None, score: Any = None, votes: Any = None, provider: str = "") -> Dict[str, Any]:
    clean = clean_rating_source(source)
    provider_clean = clean_rating_source(provider)
    rating = _normalized_rating_1553_base(source, value, score, votes, provider)
    if clean != "letterboxd":
        return rating

    # Strict Letterboxd path: only the MDBList score field is valid.
    numeric = safe_float(score)
    if provider_clean != "mdblist" or numeric is None or not float(numeric).is_integer():
        rating["value"] = None
        rating["score"] = None
        return rating
    strict_score = int(numeric)
    if not 1 <= strict_score <= 100:
        rating["value"] = None
        rating["score"] = None
        return rating
    rating["source"] = "letterboxd"
    rating["provider"] = "mdblist"
    rating["value"] = strict_score
    rating["score"] = strict_score
    return rating


def _rating_display_number(logical: str, rating: Dict[str, Any]) -> Any:
    if str(logical or "").strip().lower() == "letterboxd":
        score = _strict_letterboxd_score_1553(rating)
        return score if score is not None else ""
    return _rating_display_number_1552_base(logical, rating)


def _display_number_for_db(logical: str, rating: Any) -> str:
    if str(logical or "").strip().lower() == "letterboxd":
        score = _strict_letterboxd_score_1553(rating)
        return str(score) if score is not None else ""
    return _display_number_for_db_1552_base(logical, rating)


def _simple_rating_from_cell(logical: str, cell: Any) -> Dict[str, Any]:
    if str(logical or "").strip().lower() == "letterboxd":
        text = str(cell if cell is not None else "").strip()
        if not text:
            return {}
        if text.upper() in ("N/A", "NO_RATING", "NA"):
            return {
                "cache_key": "letterboxd", "logical": "letterboxd",
                "provider": NO_RATING_SOURCE, "source": NO_RATING_SOURCE,
                "value": NO_RATING_VALUE, "score": "", "votes": "",
                "no_rating": True,
            }
        number = safe_float(text)
        if number is None or not float(number).is_integer():
            return {}
        score = int(number)
        if not 1 <= score <= 100:
            return {}
        return {
            "cache_key": "letterboxd", "logical": "letterboxd",
            "provider": "mdblist", "source": "letterboxd",
            "value": score, "score": score, "votes": "",
        }
    return _simple_rating_from_cell_1552_base(logical, cell)



def record_missing_logicals(media_type: Any, record: Dict[str, Any]) -> set:
    missing = set(_record_missing_logicals_1553_base(media_type, record))
    media = media_setting_type(media_type)
    wanted = enabled_rating_logicals(media)
    if "letterboxd" not in wanted:
        return missing
    ratings = (record or {}).get("ratings") or {}
    row = first_rating(ratings, "letterboxd")
    if _strict_letterboxd_score_1553(row) is None:
        missing.add("letterboxd")
    else:
        missing.discard("letterboxd")
    return missing


def _rating_display_for_report(logical: str, rating: Dict[str, Any]) -> str:
    if str(logical or "").strip().lower() == "letterboxd":
        score = _strict_letterboxd_score_1553(rating)
        return str(score) if score is not None else ""
    return _rating_display_for_report_1552_base(logical, rating)


def _slot_source_value(record: Dict[str, Any], logical: str, ratings: Dict[str, Any], icons: Dict[str, str], top250_display: str) -> Optional[Dict[str, str]]:
    if logical == "letterboxd":
        score = _strict_letterboxd_score_1553(first_rating(ratings, "letterboxd"))
        if score is None:
            return None
        value = str(score)
        return {"Source": "letterboxd", "Icon": "letterboxd.png", "IconFile": "letterboxd.png", "Label": value, "Value": value}
    return _slot_source_value_1552_base(record, logical, ratings, icons, top250_display)


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    # Start from the pre-1.5.51 publisher so no decimal/value compatibility
    # alias can leak into the strict Letterboxd path.
    values = _af3_values_1551_base(record)
    ratings = preserve_ratings_for_item((record or {}).get("type"), (record or {}).get("ratings") or {})
    score = _strict_letterboxd_score_1553(first_rating(ratings, "letterboxd"))
    if score is not None:
        value = str(score)
        values["Letterboxd_Rating"] = value
        values["Letterboxd"] = value
        values["letterboxd"] = value
        values["letterboxd_rating"] = value
    return values

# -----------------------------------------------------------------------------
# v1.5.54 - MDBList Letterboxd score, or value x20 when score is absent
# -----------------------------------------------------------------------------
# This is a scrape-time rule only. It does not reinterpret stored database values
# rows. Letterboxd remains accepted only from MDBList source=letterboxd.
# Priority:
#   1. ratings[].score when it is an integer from 1..100
#   2. ratings[].value * 20 when score is absent and value is in 0..5
CACHE_VERSION = max(CACHE_VERSION, 34)


def _strict_letterboxd_score_1553(rating: Any) -> Optional[int]:
    """Return the final MDBList Letterboxd score on a 1..100 scale.

    Existing database cells are not converted here because rows loaded from the
    simple DB always contain an explicit integer score. The value x20 path is
    used only for a current MDBList rating dictionary whose provider and source
    are both explicit.
    """
    if not isinstance(rating, dict) or is_no_rating_marker(rating):
        return None
    source = clean_rating_source(rating.get("source") or "")
    provider = clean_rating_source(rating.get("provider") or "")
    if source != "letterboxd" or provider != "mdblist":
        return None

    numeric_score = safe_float(rating.get("score"))
    if numeric_score is not None:
        if not float(numeric_score).is_integer():
            return None
        final_score = int(numeric_score)
        return final_score if 1 <= final_score <= 100 else None

    numeric_value = safe_float(rating.get("value"))
    if numeric_value is None or not 0 < numeric_value <= 5:
        return None
    final_score = int(round(numeric_value * 20.0))
    return final_score if 1 <= final_score <= 100 else None


_normalized_rating_1554_base = normalized_rating


def normalized_rating(source: str, value: Any = None, score: Any = None, votes: Any = None, provider: str = "") -> Dict[str, Any]:
    clean = clean_rating_source(source)
    provider_clean = clean_rating_source(provider)
    if clean != "letterboxd":
        return _normalized_rating_1554_base(source, value, score, votes, provider)

    # No aliases and no alternate providers. Only the MDBList ratings[] row is
    # valid. Prefer score; derive from value only when score is genuinely absent.
    if provider_clean != "mdblist":
        return {
            "source": "letterboxd", "value": None, "score": None,
            "votes": safe_int(votes), "provider": provider,
        }

    numeric_score = safe_float(score)
    final_score: Optional[int] = None
    if numeric_score is not None:
        if float(numeric_score).is_integer():
            candidate = int(numeric_score)
            if 1 <= candidate <= 100:
                final_score = candidate
    else:
        numeric_value = safe_float(value)
        if numeric_value is not None and 0 < numeric_value <= 5:
            candidate = int(round(numeric_value * 20.0))
            if 1 <= candidate <= 100:
                final_score = candidate

    return {
        "source": "letterboxd",
        "value": final_score,
        "score": final_score,
        "votes": safe_int(votes),
        "provider": "mdblist",
    }




# -----------------------------------------------------------------------------
# v1.5.55 - seven configurable rating slots
# -----------------------------------------------------------------------------
# Slot 7 defaults to Letterboxd. Stored rating values are not reinterpreted.
LRS_RATING_SLOT_COUNT = 7


# -----------------------------------------------------------------------------
# v1.5.56 - keep no-rating markers internal; never publish N/A rating slots
# -----------------------------------------------------------------------------
# `no_rating=1` and value `N/A` remain valid internal cache/database markers so
# Scrape Missing does not repeatedly query a provider that already returned no
# value. They must never become visible AF3/KPM slot labels.
_LRS_DISPLAY_EMPTY_TOKENS_1556 = frozenset(('N/A', 'NA', 'NO_RATING', 'NONE', 'NULL'))


def _lrs_display_is_na_1556(value: Any) -> bool:
    return str(value if value is not None else '').strip().upper() in _LRS_DISPLAY_EMPTY_TOKENS_1556


def _lrs_strip_na_rating_slots_1556(values: Dict[str, Any]) -> Dict[str, Any]:
    cleaned = dict(values or {})
    for idx in range(1, 8):
        label_key = 'RatingSlot{0}_Label'.format(idx)
        value_key = 'RatingSlot{0}_Value'.format(idx)
        if not (_lrs_display_is_na_1556(cleaned.get(label_key)) or _lrs_display_is_na_1556(cleaned.get(value_key))):
            continue
        for suffix in ('Source', 'Icon', 'IconFile', 'IconPath', 'Label', 'Value'):
            cleaned['RatingSlot{0}_{1}'.format(idx, suffix)] = ''

    # Compatibility aliases are also presentation properties. Keep internal DB
    # markers untouched, but prevent an N/A alias from leaking into a skin.
    for key in ('Letterboxd_Rating', 'Letterboxd', 'letterboxd', 'letterboxd_rating'):
        if _lrs_display_is_na_1556(cleaned.get(key)):
            cleaned[key] = ''
    return cleaned


_af3_values_1556_base = af3_values


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    return _lrs_strip_na_rating_slots_1556(_af3_values_1556_base(record))


_af3_values_for_game_item_1556_base = af3_values_for_game_item


def af3_values_for_game_item(item: Dict[str, Any]) -> Dict[str, str]:
    return _lrs_strip_na_rating_slots_1556(_af3_values_for_game_item_1556_base(item))


_lrs_homehub_add_display_slot_1556_base = _lrs_homehub_add_display_slot_1528


def _lrs_homehub_add_display_slot_1528(slots: List[Dict[str, str]], source: Any, icon_file: Any, label: Any, value: Any = '') -> None:
    if _lrs_display_is_na_1556(label) or _lrs_display_is_na_1556(value):
        return
    _lrs_homehub_add_display_slot_1556_base(slots, source, icon_file, label, value)

# -----------------------------------------------------------------------------
# v1.5.57 - global no-rating closeout for every rating family
# -----------------------------------------------------------------------------
# Rules:
#   * Numeric rating found                           -> keep the number.
#   * Provider returned a valid/definitive response -> store N/A for every
#     applicable rating family that had no value.
#   * Temporary failure, auth error, rate limit      -> keep blank so Scrape
#     Missing can retry later.
#   * Episode-only unsupported families              -> store N/A in the wide
#     cache/report columns without querying movie/show providers.
#   * N/A is internal/report data only. AF3/KPM slots remain hidden by 1.5.56.
CACHE_VERSION = max(CACHE_VERSION, 36)

_LRS_WIDE_RATING_LOGICALS_1557 = (
    "imdb", "tmdb", "rt_critic", "rt_audience",
    "metacritic", "trakt", "letterboxd",
)
_LRS_EPISODE_UNSUPPORTED_LOGICALS_1557 = (
    "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd",
)
_LRS_NA_TOKENS_1557 = frozenset(("N/A", "NA", "NO_RATING", "UNAVAILABLE"))


def _lrs_is_no_rating_1557(rating: Any) -> bool:
    if is_no_rating_marker(rating):
        return True
    if not isinstance(rating, dict):
        return False
    value = str(rating.get("value") if rating.get("value") is not None else "").strip().upper()
    source = str(rating.get("source") or "").strip().lower()
    provider = str(rating.get("provider") or "").strip().lower()
    return value in _LRS_NA_TOKENS_1557 or source == NO_RATING_SOURCE or provider in (NO_RATING_SOURCE, NO_RATING_PROVIDER)


# Preserve every no-rating marker during wide SQLite serialization. This also
# repairs the Letterboxd 1.5.53/1.5.54 override that previously turned N/A into
# an empty string.
_display_number_for_db_1557_base = _display_number_for_db


def _display_number_for_db(logical: str, rating: Any) -> str:
    if _lrs_is_no_rating_1557(rating):
        return NO_RATING_VALUE
    return _display_number_for_db_1557_base(logical, rating)


# A stored N/A is complete, not missing. This is deliberately global so no
# rating family, including Letterboxd, is scraped forever after a definitive
# provider response with no value.
_record_missing_logicals_1557_base = record_missing_logicals


def record_missing_logicals(media_type: Any, record: Dict[str, Any]) -> set:
    missing = set(_record_missing_logicals_1557_base(media_type, record))
    media = media_setting_type(media_type)
    ratings = (record or {}).get("ratings") or {}
    for logical in enabled_rating_logicals(media):
        row = first_rating(ratings, logical)
        if _lrs_is_no_rating_1557(row):
            missing.discard(logical)
    return missing


# Earlier key/identity attempts may fail before a later MDBList identity returns
# a valid payload. Treat the lookup as cacheable when at least one attempt is a
# definitive response. Do not let a prior 401/429/timeout poison a later success.
_mdblist_lookup_cacheable_1557_base = mdblist_lookup_cacheable


def mdblist_lookup_cacheable(meta: Dict[str, Any]) -> bool:
    if not isinstance(meta, dict) or meta.get("limited"):
        return False
    attempts = [row for row in (meta.get("attempts") or []) if isinstance(row, dict)]
    if not attempts:
        return False

    # The last meaningful attempt decides the result. This permits an earlier
    # failed identity/key followed by a successful one, but does not mislabel an
    # earlier empty success as final when the later alternate identity timed out.
    for attempt in reversed(attempts):
        status = safe_int(attempt.get("http_status"))
        error = str(attempt.get("error") or "").strip().lower()
        if _attempt_has_temp_failure(attempt):
            return False
        # Any successful HTTP payload is definitive even when ratings[] is empty.
        if status == 200:
            return True
        # MDBList item-not-found is a definitive checked result, not a retryable
        # transport failure. The provider flow may still use OMDb/TMDb fallbacks.
        if status == 404:
            return True
        # Some Kodi/Python HTTP wrappers omit status for a valid JSON payload.
        if status is None and not error and (
            "ratings" in attempt or attempt.get("payload_keys") or attempt.get("sources") is not None
        ):
            return True

    # Unknown provider metadata is not persisted as a completed lookup.
    return False


# Make report/debug formatting show N/A for every no-rating marker. Skin output
# is still stripped later by the 1.5.56 presentation layer.
_rating_display_for_report_1557_base = _rating_display_for_report


def _rating_display_for_report(logical: str, rating: Dict[str, Any]) -> str:
    if _lrs_is_no_rating_1557(rating):
        return NO_RATING_VALUE
    return _rating_display_for_report_1557_base(logical, rating)


# Final result closeout. Unsupported episode rating families are not queried,
# but their wide DB/report cells must be explicit N/A rather than ambiguous
# blanks. Movie/show families are left to provider-specific closeout above so
# temporary network/API failures remain blank and retryable.
_resolve_item_1557_base = resolve_item


def resolve_item(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True, include_local: bool = True, ratings_only: bool = False) -> Dict[str, Any]:
    result = _resolve_item_1557_base(item, keys, existing, missing_only=missing_only, include_local=include_local, ratings_only=ratings_only)
    media = media_setting_type((item or {}).get("type") or (result or {}).get("type"))
    if media == "episode" and isinstance(result, dict):
        ratings = dict(result.get("ratings") or {})
        for logical in _LRS_EPISODE_UNSUPPORTED_LOGICALS_1557:
            cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
            row = ratings.get(cache_key)
            if not isinstance(row, dict) or (
                safe_float(row.get("score")) is None
                and safe_float(row.get("value")) is None
                and not _lrs_is_no_rating_1557(row)
            ):
                ratings[cache_key] = no_rating_row(logical, "not_applicable_to_episode")
        result["ratings"] = ratings
    return result


# Belt-and-suspenders serialization for records loaded from older caches where
# unsupported episode families were never present in result[ratings].
_simple_db_rating_values_1557_base = _simple_db_rating_values


def _simple_db_rating_values(entry: Dict[str, Any], item_key: str) -> Tuple[Any, ...]:
    values = list(_simple_db_rating_values_1557_base(entry, item_key))
    if media_setting_type((entry or {}).get("type") or (entry or {}).get("media_type")) == "episode":
        for column in ("rottentomatoes", "rottentomatoes_user", "metacritic", "trakt", "letterboxd"):
            try:
                values[FINAL_RATINGS_COLUMNS.index(column)] = NO_RATING_VALUE
            except (ValueError, IndexError):
                pass
    return tuple(values)





# -----------------------------------------------------------------------------
# v1.5.59 - DBID reuse identity guard (episode direct fallback superseded by 1.5.60)
# -----------------------------------------------------------------------------
# Kodi may reuse a movie/tvshow/episode DBID after Clean Library or a source-path
# move. A DBID is therefore a locator, not a permanent media identity. Every
# cache-read path now validates stable IDs and descriptive episode identity
# before preserving old ratings. When the identity changed, the old record is
# discarded and the item is scraped as new.
#
# The old direct IMDb-page experiment is disabled and superseded by v1.5.60.
# Episodes use OMDb only for IMDb ratings; MDBList remains movie/show only.
CACHE_VERSION = max(CACHE_VERSION, 38)
LRS_SCHEMA_VERSION = max(globals().get("LRS_SCHEMA_VERSION", 0), 1559)
_LRS_EPISODE_IMDB_RECHECK_META_1558 = "episode_imdb_direct_recheck_epoch_1559"
_LRS_EPISODE_IMDB_RECHECK_CACHE_1558 = None


def _lrs_identity_ids_1558(value: Any) -> Dict[str, str]:
    value = value if isinstance(value, dict) else {}
    out: Dict[str, str] = {}
    # Item identity must use IDs belonging to the item itself.  Episode rows
    # also carry show_ids for provider lookups, but those are IDs of the parent
    # TV show and must never overwrite the episode IMDb/TMDb/TVDb IDs.
    for source in (value.get("ids"), value.get("uniqueid")):
        if not isinstance(source, dict):
            continue
        for key, raw in source.items():
            raw = str(raw or "").strip()
            if raw:
                out[str(key).lower()] = raw
    direct = {
        "imdb": value.get("imdb_id") or value.get("imdbnumber") or value.get("imdb"),
        "tmdb": value.get("tmdb_id") or value.get("tmdb"),
        "tvdb": value.get("tvdb_id") or value.get("tvdb"),
    }
    for key, raw in direct.items():
        raw = str(raw or "").strip()
        if raw:
            out.setdefault(key, raw)
    imdb = _norm_imdb(out.get("imdb"))
    tmdb = _norm_tmdb(out.get("tmdb"))
    if imdb:
        out["imdb"] = imdb
    elif "imdb" in out:
        out.pop("imdb", None)
    if tmdb:
        out["tmdb"] = tmdb
    elif "tmdb" in out:
        out.pop("tmdb", None)
    return out


def _lrs_text_same_1558(left: Any, right: Any) -> bool:
    return bool(_norm_text(left)) and _norm_text(left) == _norm_text(right)


def cache_identity_matches_1558(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    """Return True only when a cached row still describes the current Kodi item.

    Matching DBIDs alone are deliberately insufficient. A common stable ID is
    strongest; episodes otherwise require show + season + episode. Movies/shows
    otherwise require title and a non-conflicting year.
    """
    if not isinstance(item, dict) or not isinstance(record, dict) or not record:
        return False
    item_media = media_setting_type(item.get("type") or item.get("media_type"))
    row_media = media_setting_type(record.get("type") or record.get("media_type"))
    if item_media not in ("movie", "tvshow", "episode") or row_media != item_media:
        return False

    item_ids = _lrs_identity_ids_1558(item)
    row_ids = _lrs_identity_ids_1558(record)
    strong_match = False
    for provider in ("imdb", "tmdb", "tvdb"):
        left = str(item_ids.get(provider) or "").strip().lower()
        right = str(row_ids.get(provider) or "").strip().lower()
        if left and right:
            if left != right:
                return False
            strong_match = True

    if item_media == "episode":
        item_season, row_season = safe_int(item.get("season")), safe_int(record.get("season"))
        item_episode, row_episode = safe_int(item.get("episode")), safe_int(record.get("episode"))
        if item_season is not None and row_season is not None and item_season != row_season:
            return False
        if item_episode is not None and row_episode is not None and item_episode != row_episode:
            return False
        item_show, row_show = _norm_text(item.get("showtitle")), _norm_text(record.get("showtitle"))
        if item_show and row_show and item_show != row_show:
            return False
        if strong_match:
            return True
        # Without a common provider ID, require the complete episode coordinate.
        if item_show and row_show and item_season is not None and row_season is not None and item_episode is not None and row_episode is not None:
            return item_show == row_show and item_season == row_season and item_episode == row_episode
        # Last defensive fallback for sparse library rows.
        return (
            _lrs_text_same_1558(item.get("title"), record.get("title"))
            and item_season is not None and item_season == row_season
            and item_episode is not None and item_episode == row_episode
        )

    if strong_match:
        return True
    item_title, row_title = _norm_text(item.get("title")), _norm_text(record.get("title"))
    if item_title and row_title and item_title != row_title:
        return False
    item_year, row_year = safe_int(item.get("year")), safe_int(record.get("year"))
    if item_year is not None and row_year is not None and item_year != row_year:
        return False
    return bool(item_title and row_title and item_title == row_title)


# Presentation stale guard must use real identity rather than type|DBID alone.
context_matches_record = cache_identity_matches_1558


def _lrs_episode_imdb_id_1558(value: Dict[str, Any]) -> str:
    imdb = _norm_imdb(_lrs_identity_ids_1558(value or {}).get("imdb"))
    return imdb if imdb and imdb.startswith("tt") else ""


def _lrs_episode_recheck_epoch_1558() -> int:
    global _LRS_EPISODE_IMDB_RECHECK_CACHE_1558
    if _LRS_EPISODE_IMDB_RECHECK_CACHE_1558 is not None:
        return int(_LRS_EPISODE_IMDB_RECHECK_CACHE_1558 or 0)
    value = 0
    try:
        with _sqlite_connect() as conn:
            value = safe_int(_db_get_meta(conn, _LRS_EPISODE_IMDB_RECHECK_META_1558)) or 0
    except Exception:
        value = 0
    _LRS_EPISODE_IMDB_RECHECK_CACHE_1558 = value
    return value


def _lrs_episode_recheck_available_1558() -> bool:
    # OMDb is already attempted by the base episode resolver. The direct IMDb
    # title-page fallback does not use an addon API key.
    return True


_record_missing_logicals_1558_base = record_missing_logicals


def record_missing_logicals(media_type: Any, record: Dict[str, Any]) -> set:
    missing = set(_record_missing_logicals_1558_base(media_type, record))
    if media_setting_type(media_type) != "episode" or not rating_enabled("episode", "imdb", True):
        return missing
    ratings = (record or {}).get("ratings") or {}
    imdb_row = first_rating(ratings, "imdb")
    cutoff = _lrs_episode_recheck_epoch_1558()
    stamp = safe_int((record or {}).get("timestamp")) or 0
    # Re-open only old definitive N/A rows once. New N/A rows written after the
    # fallback pass remain complete and do not become an endless missing loop.
    if cutoff and stamp < cutoff and _lrs_is_no_rating_1557(imdb_row) and _lrs_episode_imdb_id_1558(record or {}) and _lrs_episode_recheck_available_1558():
        missing.add("imdb")
    return missing


_record_needs_update_1558_base = record_needs_update


def record_needs_update(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if not record or not cache_identity_matches_1558(item or {}, record or {}):
        return True
    if media_setting_type((item or {}).get("type")) == "episode" and "imdb" in record_missing_logicals("episode", record or {}):
        return True
    return _record_needs_update_1558_base(item, record)


_record_missing_awards_1558_base = record_missing_awards


def record_missing_awards(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if record and not cache_identity_matches_1558(item or {}, record or {}):
        return True
    return _record_missing_awards_1558_base(item, record)


_record_missing_rt_badge_1558_base = record_missing_rt_badge


def record_missing_rt_badge(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if record and not cache_identity_matches_1558(item or {}, record or {}):
        return True
    return _record_missing_rt_badge_1558_base(item, record)


def _lrs_imdb_jsonld_rating_1558(item: Dict[str, Any], imdb_id: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    # Retained only as a compatibility symbol. v1.5.60 never fetches imdb.com.
    return {}, {"source": "disabled_in_1560", "temporary": False, "disabled": True}

def _lrs_recover_episode_imdb_1558(item: Dict[str, Any], result: Dict[str, Any], keys: Dict[str, Any]) -> Dict[str, Any]:
    # v1.5.60 episode IMDb is OMDb-only.
    return result


_resolve_item_1558_base = resolve_item


def resolve_item(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True, include_local: bool = True, ratings_only: bool = False) -> Dict[str, Any]:
    current_existing = existing if isinstance(existing, dict) else {}
    identity_reused = bool(current_existing) and not cache_identity_matches_1558(item or {}, current_existing)
    if identity_reused:
        log("LRS identity guard: discarded stale {0} for current {1}".format(record_item_key(current_existing), item_key(item or {})), xbmc.LOGWARNING)
        current_existing = {}
    result = _resolve_item_1558_base(item, keys, current_existing, missing_only=missing_only, include_local=include_local, ratings_only=ratings_only)
    if isinstance(result, dict):
        result = _lrs_recover_episode_imdb_1558(item or {}, result, keys or {})
        if identity_reused:
            result.setdefault("provider_meta", {})["identity_guard_1558"] = {
                "reused_dbid": True,
                "discarded_item_key": record_item_key(existing or {}),
                "current_item_key": item_key(item or {}),
                "updated_at": now_iso(),
            }
    return result


_resolve_awards_only_1558_base = resolve_awards_only


def resolve_awards_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    current_existing = existing if isinstance(existing, dict) else {}
    if current_existing and not cache_identity_matches_1558(item or {}, current_existing):
        current_existing = {}
    return _resolve_awards_only_1558_base(item, keys, current_existing)


_resolve_rt_badge_only_1558_base = resolve_rt_badge_only


def resolve_rt_badge_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None, force: bool = False) -> Dict[str, Any]:
    current_existing = existing if isinstance(existing, dict) else {}
    if current_existing and not cache_identity_matches_1558(item or {}, current_existing):
        current_existing = {}
    return _resolve_rt_badge_only_1558_base(item, keys, current_existing, force=force)


def _lrs_current_library_identity_map_1558() -> Dict[str, Dict[str, Any]]:
    output: Dict[str, Dict[str, Any]] = {}
    common = ["title", "year", "imdbnumber", "uniqueid"]
    shows_by_id: Dict[int, Dict[str, Any]] = {}
    for row in json_rpc("VideoLibrary.GetTVShows", {"properties": common}).get("tvshows", []) or []:
        if not isinstance(row, dict):
            continue
        dbid = safe_int(row.get("tvshowid"))
        if dbid is None:
            continue
        item = dict(row); item.update({"type": "tvshow", "dbid": dbid})
        output[item_key(item)] = item
        shows_by_id[dbid] = item
    for row in json_rpc("VideoLibrary.GetMovies", {"properties": common}).get("movies", []) or []:
        if not isinstance(row, dict):
            continue
        dbid = safe_int(row.get("movieid"))
        if dbid is None:
            continue
        item = dict(row); item.update({"type": "movie", "dbid": dbid})
        output[item_key(item)] = item
    episode_props = ["title", "showtitle", "season", "episode", "tvshowid", "uniqueid", "file"]
    for row in json_rpc("VideoLibrary.GetEpisodes", {"properties": episode_props}).get("episodes", []) or []:
        if not isinstance(row, dict):
            continue
        dbid = safe_int(row.get("episodeid"))
        if dbid is None:
            continue
        item = dict(row); item.update({"type": "episode", "dbid": dbid})
        parent = shows_by_id.get(safe_int(row.get("tvshowid")) or -1, {})
        item["showtitle"] = row.get("showtitle") or parent.get("title") or ""
        output[item_key(item)] = item
    return output


_clean_orphan_library_ratings_1558_base = clean_orphan_library_ratings_1460


def clean_orphan_library_ratings_1460() -> Dict[str, Any]:
    stats = _clean_orphan_library_ratings_1558_base()
    if (stats or {}).get("error"):
        return stats
    removed_identity = 0
    try:
        current = _lrs_current_library_identity_map_1558()
        if current:
            with _sqlite_connect() as conn:
                _ensure_current_cache_schema(conn)
                rows = conn.execute("SELECT * FROM ratings").fetchall()
                for row in rows:
                    key = str(_row_value(row, "item_key") or "")
                    item = current.get(key)
                    if not item:
                        continue
                    entry = _ratings_only_row_to_entry(row)
                    if cache_identity_matches_1558(item, entry):
                        continue
                    conn.execute("DELETE FROM ratings WHERE item_key=?", (key,))
                    removed_identity += 1
                    if len(stats.setdefault("removed_items", [])) < 50:
                        stats["removed_items"].append({"item_key": key, "title": _row_value(row, "title") or "", "reason": "dbid_identity_reused"})
                if removed_identity:
                    _db_set_meta(conn, "last_identity_reuse_clean_at", now_iso())
                    _db_set_meta(conn, "last_identity_reuse_clean_removed", removed_identity)
                conn.commit()
        if removed_identity:
            stats["removed_identity_reuse"] = removed_identity
            stats["removed"] = int(stats.get("removed") or 0) + removed_identity
            stats["kept"] = max(0, int(stats.get("kept") or 0) - removed_identity)
            report = export_csv(load_cache())
            stats["report"] = report
            stats["report_refreshed"] = True
    except Exception as exc:
        stats["identity_guard_error"] = str(exc)
        log("LRS identity clean 1.5.59 failed: {0}".format(exc), xbmc.LOGWARNING)
    return stats




# -----------------------------------------------------------------------------
# v1.5.60 - OMDb-only IMDb ratings for episodes
# -----------------------------------------------------------------------------
# Episode IMDb ratings intentionally use OMDb only, matching the established
# provider design. MDBList remains movie/TV-show only, and LRS never fetches or
# parses imdb.com title pages. The v1.5.59 DBID-reuse identity guard is retained.
CACHE_VERSION = max(CACHE_VERSION, 39)
LRS_SCHEMA_VERSION = max(globals().get("LRS_SCHEMA_VERSION", 0), 1560)


def _lrs_episode_recheck_available_1558() -> bool:
    """No special recheck epoch: an OMDb N/A is a completed episode result."""
    return False


def record_missing_logicals(media_type: Any, record: Dict[str, Any]) -> set:
    # Restore the normal 1.5.57 missing semantics. In particular, do not reopen
    # old episode IMDb N/A rows for a web-page fallback.
    return set(_record_missing_logicals_1558_base(media_type, record))


def _lrs_recover_episode_imdb_1558(item: Dict[str, Any], result: Dict[str, Any], keys: Dict[str, Any]) -> Dict[str, Any]:
    # Compatibility symbol kept for older callers/tests. Deliberately no-op.
    return result


def resolve_item(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True, include_local: bool = True, ratings_only: bool = False) -> Dict[str, Any]:
    """Resolve with DBID identity protection and the normal OMDb episode path."""
    current_existing = existing if isinstance(existing, dict) else {}
    identity_reused = bool(current_existing) and not cache_identity_matches_1558(item or {}, current_existing)
    if identity_reused:
        log("LRS identity guard: discarded stale {0} for current {1}".format(record_item_key(current_existing), item_key(item or {})), xbmc.LOGWARNING)
        current_existing = {}
    # _resolve_item_1558_base points to the 1.5.57 resolver. That resolver uses
    # OMDb for episode IMDb and TMDb for episode TMDb, with no IMDb web fetch.
    result = _resolve_item_1558_base(item, keys, current_existing, missing_only=missing_only, include_local=include_local, ratings_only=ratings_only)
    if isinstance(result, dict) and identity_reused:
        result.setdefault("provider_meta", {})["identity_guard_1560"] = {
            "reused_dbid": True,
            "discarded_item_key": record_item_key(existing or {}),
            "current_item_key": item_key(item or {}),
            "updated_at": now_iso(),
        }
    return result



# -----------------------------------------------------------------------------
# v1.5.61 - official IMDb dataset fallback for OMDb N/A episode ratings
# -----------------------------------------------------------------------------
# OMDb remains the first episode IMDb provider. Only when OMDb has no numeric
# rating does LRS query a local SQLite copy of IMDb's official
# title.ratings.tsv.gz dataset by the exact episode tconst. No imdb.com title
# page is fetched or parsed, and TMDb/TVDB scores are never mislabeled as IMDb.
CACHE_VERSION = max(CACHE_VERSION, 40)
LRS_SCHEMA_VERSION = max(globals().get("LRS_SCHEMA_VERSION", 0), 1561)

try:
    from . import imdb_dataset_ratings as _imdb_dataset_ratings_1561
except Exception:  # pragma: no cover - Kodi fallback import style
    import imdb_dataset_ratings as _imdb_dataset_ratings_1561  # type: ignore

IMDB_EPISODE_DATASET_REPORT_1561 = os.path.join(REPORTS_DIR, "imdb-episode-dataset-report.csv")

# Direct IMDb dataset data should win over aggregator/API aliases if rows are
# ever merged again after the resolve-time replacement below.
try:
    _imdb_priority_1561 = list(RATING_PROVIDER_PRIORITY.get("imdb") or [])
    if "imdb_dataset" in _imdb_priority_1561:
        _imdb_priority_1561.remove("imdb_dataset")
    RATING_PROVIDER_PRIORITY["imdb"] = ["imdb_dataset"] + _imdb_priority_1561
except Exception:
    pass


def _lrs_imdb_dataset_log_1561(message: str) -> None:
    log(str(message or ""), xbmc.LOGINFO)


def _lrs_imdb_row_needs_dataset_1561(row: Any) -> bool:
    if not isinstance(row, dict) or not row:
        return True
    if is_no_rating_marker(row):
        return True
    text = str(row.get("value") if row.get("value") not in (None, "") else row.get("score") or "").strip().upper()
    if text in ("", "N/A", "NA", "NO_RATING", "UNAVAILABLE"):
        return True
    return safe_float(row.get("value")) is None and safe_float(row.get("score")) is None


def _lrs_imdb_dataset_verified_row_1561(row: Any) -> bool:
    return isinstance(row, dict) and str(row.get("provider") or "").strip().lower() == "imdb_dataset"


def _lrs_imdb_dataset_meta_1561(lookup: Dict[str, Any]) -> Dict[str, Any]:
    dataset = lookup.get("dataset") if isinstance(lookup, dict) else {}
    dataset = dataset if isinstance(dataset, dict) else {}
    metadata = dataset.get("metadata") if isinstance(dataset.get("metadata"), dict) else {}
    return {
        "status": str(lookup.get("status") or ""),
        "imdb_id": str(lookup.get("imdb_id") or ""),
        "rating": lookup.get("rating") if lookup.get("rating") is not None else "",
        "dataset": "title.ratings.tsv.gz",
        "dataset_fetched_at": metadata.get("fetched_at") or "",
        "dataset_rows": metadata.get("rows") or "",
        "dataset_refreshed": bool(dataset.get("refreshed")),
        "stale_fallback": bool(dataset.get("stale_fallback")),
        "temporary": bool(lookup.get("temporary")),
        "error": str(lookup.get("error") or "")[:500],
        "updated_at": now_iso(),
    }


def _append_imdb_dataset_report_1561(item: Dict[str, Any], prior_row: Any, lookup: Dict[str, Any]) -> None:
    try:
        os.makedirs(os.path.dirname(IMDB_EPISODE_DATASET_REPORT_1561), exist_ok=True)
        exists = os.path.isfile(IMDB_EPISODE_DATASET_REPORT_1561) and os.path.getsize(IMDB_EPISODE_DATASET_REPORT_1561) > 0
        with open(IMDB_EPISODE_DATASET_REPORT_1561, "a", encoding="utf-8-sig" if not exists else "utf-8", newline="") as handle:
            writer = csv.writer(handle)
            if not exists:
                writer.writerow([
                    "checked_at", "item_key", "show", "season", "episode", "title", "imdb_id",
                    "previous_provider", "previous_value", "dataset_status", "dataset_rating",
                    "dataset_fetched_at", "stale_fallback", "error"
                ])
            prior = prior_row if isinstance(prior_row, dict) else {}
            meta = _lrs_imdb_dataset_meta_1561(lookup)
            writer.writerow([
                now_iso(), item_key(item or {}), item.get("showtitle") or item.get("tvshowtitle") or "",
                item.get("season") or "", item.get("episode") or "", item.get("title") or "",
                meta.get("imdb_id") or "", prior.get("provider") or "", prior.get("value") or prior.get("score") or "",
                meta.get("status") or "", meta.get("rating") or "",
                meta.get("dataset_fetched_at") or "", meta.get("stale_fallback") or False, meta.get("error") or "",
            ])
    except Exception as exc:
        log("IMDb episode dataset report failed: {0}".format(exc), xbmc.LOGWARNING)


_record_missing_logicals_1561_base = record_missing_logicals


def record_missing_logicals(media_type: Any, record: Dict[str, Any]) -> set:
    missing = set(_record_missing_logicals_1561_base(media_type, record))
    if media_setting_type(media_type) != "episode" or not rating_enabled("episode", "imdb", True):
        return missing
    imdb_id = _lrs_episode_imdb_id_1558(record or {})
    if not imdb_id:
        return missing
    row = first_rating((record or {}).get("ratings") or {}, "imdb")
    if _lrs_imdb_dataset_verified_row_1561(row):
        # Numeric and definitive dataset N/A rows are both complete until the
        # normal item refresh path is explicitly requested.
        missing.discard("imdb")
    elif _lrs_imdb_row_needs_dataset_1561(row):
        # Re-open OMDb N/A/empty rows so Scrape Missing performs the exact-ID
        # dataset lookup once.
        missing.add("imdb")
    return missing


_resolve_item_1561_base = resolve_item


def resolve_item(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None,
                 missing_only: bool = True, include_local: bool = True,
                 ratings_only: bool = False) -> Dict[str, Any]:
    result = _resolve_item_1561_base(
        item, keys, existing, missing_only=missing_only,
        include_local=include_local, ratings_only=ratings_only
    )
    if not isinstance(result, dict) or media_setting_type((item or {}).get("type")) != "episode":
        return result
    if not rating_enabled("episode", "imdb", True):
        return result
    imdb_id = _lrs_episode_imdb_id_1558(item or {}) or _lrs_episode_imdb_id_1558(result or {})
    if not imdb_id:
        return result
    ratings = result.setdefault("ratings", {})
    prior_row = first_rating(ratings, "imdb")
    if not _lrs_imdb_row_needs_dataset_1561(prior_row):
        return result

    lookup = _imdb_dataset_ratings_1561.lookup(
        PROFILE, imdb_id, max_age_days=7, timeout=45,
        log_callback=_lrs_imdb_dataset_log_1561
    )
    status = str(lookup.get("status") or "")
    if status == "found":
        row = normalized_rating(
            "imdb", lookup.get("rating"), None, None, "imdb_dataset"
        )
        row.update({
            "logical": "imdb", "cache_key": "imdb", "source": "imdb",
            "provider": "imdb_dataset", "updated_at": now_iso(),
        })
        ratings["imdb"] = row
    elif status == "not_found":
        row = no_rating_row("imdb", "not_present_in_official_imdb_ratings_dataset")
        row.update({
            "source": "imdb", "provider": "imdb_dataset",
            "logical": "imdb", "cache_key": "imdb", "updated_at": now_iso(),
        })
        ratings["imdb"] = row
    # unavailable/temporary keeps the OMDb N/A row. record_missing_logicals()
    # will reopen it on a later Scrape Missing instead of persisting a false
    # dataset result.
    result.setdefault("provider_meta", {})["imdb_dataset_1561"] = _lrs_imdb_dataset_meta_1561(lookup)
    _append_imdb_dataset_report_1561(item or {}, prior_row, lookup)
    return result





_diagnostic_candidates_1561_base = _diagnostic_candidates_1397


def _diagnostic_candidates_1397() -> List[str]:
    paths = list(_diagnostic_candidates_1561_base())
    # Keep diagnostics compact: include the CSV audit report, not the full
    # multi-million-row IMDb dataset SQLite cache.
    for path in (
        IMDB_EPISODE_DATASET_REPORT_1561,
    ):
        if path and path not in paths:
            paths.append(path)
    return paths


# -----------------------------------------------------------------------------
# v1.5.62 - batch IMDb dataset flow, no vote data, no Kodi-local ratings
# -----------------------------------------------------------------------------
# Final rules:
# * IMDb ratings use the official local dataset first.
# * Episode IMDb never calls OMDb.
# * Movie/show MDBList supplies non-IMDb ratings; its IMDb row is ignored.
# * Existing OMDb/TMDb fallbacks remain for MDBList item-not-found.
# * Refresh All audits IMDb for every enabled item.
# * Scrape Missing audits all IMDb rows only when a dataset generation has not
#   yet been applied to the library; otherwise it checks genuinely blank IMDb
#   rows only. Numeric and N/A rows are complete in normal missing mode.
# * A dataset miss never destroys an existing IMDb value.
# * Vote counts are not read, retained, compared, published, or reported.
CACHE_VERSION = max(CACHE_VERSION, 41)
LRS_SCHEMA_VERSION = max(globals().get("LRS_SCHEMA_VERSION", 0), 1562)
IMDB_DATASET_SYNC_STATE_1562 = os.path.join(PROFILE, "imdb-dataset-sync-state.json")
IMDB_DATASET_REPORT_1562 = os.path.join(REPORTS_DIR, "imdb-dataset-sync-report.csv")

def _lrs_strip_vote_data_1562(value: Any) -> Any:
    """Recursively remove every vote-count field from runtime structures."""
    blocked = {"votes", "votecount", "vote_count", "imdbvotes", "num_votes", "numvotes"}
    if isinstance(value, dict):
        return {
            key: _lrs_strip_vote_data_1562(child)
            for key, child in value.items()
            if str(key or "").replace("-", "").replace("_", "").lower() not in blocked
        }
    if isinstance(value, list):
        return [_lrs_strip_vote_data_1562(child) for child in value]
    if isinstance(value, tuple):
        return tuple(_lrs_strip_vote_data_1562(child) for child in value)
    return value


_normalized_rating_1562_base = normalized_rating


def normalized_rating(source: str, value: Any = None, score: Any = None,
                      votes: Any = None, provider: str = "") -> Dict[str, Any]:
    row = _normalized_rating_1562_base(source, value, score, None, provider)
    return _lrs_strip_vote_data_1562(row if isinstance(row, dict) else {})


_no_rating_row_1562_base = no_rating_row


def no_rating_row(logical: str, reason: str = "provider_returned_no_value") -> Dict[str, Any]:
    return _lrs_strip_vote_data_1562(_no_rating_row_1562_base(logical, reason))


# Kodi-local ratings were never enabled by any active caller. Keep a harmless
# compatibility symbol for old wrappers, but do not request Kodi's `ratings`
# property in library_items()/parent_show_map() and never return local rows.
def local_ratings(row: Dict[str, Any]) -> Dict[str, Any]:
    return {}


_mdblist_lookup_1562_base = mdblist_lookup


def mdblist_lookup(ids: Dict[str, str], media_type: str, key: Any) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    found, meta = _mdblist_lookup_1562_base(ids, media_type, key)
    cleaned: Dict[str, Any] = {}
    for cache_key, row in (found or {}).items():
        logical = str((row or {}).get("logical") or cache_key or "").strip().lower() if isinstance(row, dict) else str(cache_key or "").lower()
        source = clean_rating_source((row or {}).get("source") or "") if isinstance(row, dict) else ""
        if logical == "imdb" or source == "imdb":
            continue
        cleaned[cache_key] = _lrs_strip_vote_data_1562(row)
    return cleaned, _lrs_strip_vote_data_1562(meta if isinstance(meta, dict) else {})


_omdb_lookup_1562_base = omdb_lookup
_OMDB_RUN_BLOCKED_1568 = False
_OMDB_RUN_BLOCK_REASON_1568 = ""


def omdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: Any) -> Tuple[Dict[str, Any], Dict[str, str], Dict[str, Any]]:
    global _OMDB_RUN_BLOCKED_1568, _OMDB_RUN_BLOCK_REASON_1568
    if _OMDB_RUN_BLOCKED_1568:
        raise ProviderLimitReached("OMDb", _OMDB_RUN_BLOCK_REASON_1568 or "OMDb disabled after an authorization failure in this run")
    try:
        found, updated_ids, meta = _omdb_lookup_1562_base(item, ids, key)
    except ProviderLimitReached as exc:
        message = str(exc or "")
        lower = message.lower()
        if any(token in lower for token in ("401", "403", "invalid api key", "unauthorized", "forbidden", "apikey")):
            _OMDB_RUN_BLOCKED_1568 = True
            _OMDB_RUN_BLOCK_REASON_1568 = message or "OMDb authorization failed"
            log("OMDb circuit breaker opened for this run: {0}".format(_OMDB_RUN_BLOCK_REASON_1568), xbmc.LOGWARNING)
        raise
    return _lrs_strip_vote_data_1562(found), updated_ids, _lrs_strip_vote_data_1562(meta)


_tmdb_lookup_1562_base = tmdb_lookup


def tmdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: Any) -> Tuple[Dict[str, Any], Dict[str, str]]:
    found, updated_ids = _tmdb_lookup_1562_base(item, ids, key)
    return _lrs_strip_vote_data_1562(found), updated_ids


_tmdb_rating_lookup_1562_base = tmdb_rating_lookup_1397


def tmdb_rating_lookup_1397(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str], Dict[str, Any]]:
    found, updated_ids, meta = _tmdb_rating_lookup_1562_base(item, ids, key)
    return _lrs_strip_vote_data_1562(found), updated_ids, _lrs_strip_vote_data_1562(meta)


def _lrs_imdb_dataset_state_1562() -> Dict[str, Any]:
    try:
        with open(IMDB_DATASET_SYNC_STATE_1562, "r", encoding="utf-8") as handle:
            row = json.load(handle)
        return row if isinstance(row, dict) else {}
    except Exception:
        return {}


def imdb_dataset_applied_generation_1562() -> str:
    return str(_lrs_imdb_dataset_state_1562().get("applied_fetched_at") or "")


def mark_imdb_dataset_generation_applied_1562(fetched_at: Any, reason: str = "") -> None:
    value = str(fetched_at or "").strip()
    if not value:
        return
    os.makedirs(PROFILE, exist_ok=True)
    payload = {
        "applied_fetched_at": value,
        "applied_at": now_iso(),
        "reason": str(reason or ""),
    }
    temp = IMDB_DATASET_SYNC_STATE_1562 + ".tmp"
    with open(temp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(temp, IMDB_DATASET_SYNC_STATE_1562)


def ensure_imdb_dataset_1562(force_refresh: bool = False) -> Dict[str, Any]:
    return _imdb_dataset_ratings_1561.ensure_dataset(
        PROFILE, max_age_days=7, timeout=45, force=bool(force_refresh),
        log_callback=_lrs_imdb_dataset_log_1561,
    )


def imdb_dataset_generation_1562(ensured: Dict[str, Any]) -> str:
    metadata = (ensured or {}).get("metadata") or {}
    return str(metadata.get("fetched_at") or "") if isinstance(metadata, dict) else ""


def imdb_dataset_generation_pending_1562(ensured: Dict[str, Any]) -> bool:
    generation = imdb_dataset_generation_1562(ensured)
    return bool(generation and generation != imdb_dataset_applied_generation_1562())


def _lrs_imdb_id_1562(item: Dict[str, Any], existing: Optional[Dict[str, Any]] = None) -> str:
    ids: Dict[str, Any] = {}
    if isinstance(existing, dict):
        ids.update(existing.get("ids") or {})
    try:
        ids.update(extract_ids(item or {}))
    except Exception:
        pass
    value = str(ids.get("imdb") or "").strip().lower()
    return value if re.match(r"^tt\d+$", value, re.I) else ""


def _lrs_imdb_row_1562(record: Optional[Dict[str, Any]]) -> Dict[str, Any]:
    return first_rating((record or {}).get("ratings") or {}, "imdb") if isinstance(record, dict) else {}


def _lrs_imdb_row_blank_1562(row: Any) -> bool:
    if not isinstance(row, dict) or not row:
        return True
    if is_no_rating_marker(row):
        return False
    value = row.get("value")
    score = row.get("score")
    return safe_float(value) is None and safe_float(score) is None and not str(value or score or "").strip()


def _lrs_dataset_rating_row_1562(rating: Any) -> Dict[str, Any]:
    row = normalized_rating("imdb", rating, None, None, "imdb_dataset")
    row.update({
        "logical": "imdb", "cache_key": "imdb", "source": "imdb",
        "provider": "imdb_dataset", "updated_at": now_iso(),
    })
    return _lrs_strip_vote_data_1562(row)


def _lrs_merge_dataset_entry_1562(item: Dict[str, Any], existing: Dict[str, Any], rating: Any) -> Dict[str, Any]:
    media = media_setting_type((item or {}).get("type"))
    entry = dict(existing or {})
    ids = dict(entry.get("ids") or {})
    for key, value in extract_ids(item or {}).items():
        if value not in (None, ""):
            ids[str(key)] = str(value)
    ratings = preserve_ratings_for_item(media, entry.get("ratings") or {})
    ratings["imdb"] = _lrs_dataset_rating_row_1562(rating)
    entry.update({
        "type": item.get("type"), "dbid": item.get("dbid"),
        "title": item.get("title") or entry.get("title") or "",
        "year": item.get("year") or entry.get("year") or "",
        "showtitle": item.get("showtitle") or entry.get("showtitle") or "",
        "season": item.get("season") if item.get("type") == "episode" else None,
        "episode": item.get("episode") if item.get("type") == "episode" else None,
        "ids": ids, "ratings": ratings,
        "provider_meta": _lrs_strip_vote_data_1562(entry.get("provider_meta") or {}),
        "series": entry.get("series") or {}, "awards": entry.get("awards") or {},
        "imdb_top250_rank": entry.get("imdb_top250_rank") or 0,
        "errors": entry.get("errors") or [],
        "timestamp": int(time.time()), "updated_at": now_iso(),
    })
    return _lrs_strip_vote_data_1562(entry)


def _append_imdb_dataset_report_1562(rows: List[Dict[str, Any]], ensured: Dict[str, Any], mode: str) -> None:
    if not rows:
        return
    try:
        os.makedirs(os.path.dirname(IMDB_DATASET_REPORT_1562), exist_ok=True)
        exists = os.path.isfile(IMDB_DATASET_REPORT_1562) and os.path.getsize(IMDB_DATASET_REPORT_1562) > 0
        metadata = (ensured or {}).get("metadata") or {}
        with open(IMDB_DATASET_REPORT_1562, "a", encoding="utf-8-sig" if not exists else "utf-8", newline="") as handle:
            writer = csv.writer(handle)
            if not exists:
                writer.writerow([
                    "checked_at", "mode", "item_key", "media_type", "title", "show",
                    "season", "episode", "imdb_id", "status", "rating",
                    "dataset_fetched_at", "dataset_refreshed", "error",
                ])
            for row in rows:
                writer.writerow([
                    now_iso(), mode, row.get("item_key") or "", row.get("media_type") or "",
                    row.get("title") or "", row.get("showtitle") or "",
                    row.get("season") if row.get("season") is not None else "",
                    row.get("episode") if row.get("episode") is not None else "",
                    row.get("imdb_id") or "", row.get("status") or "",
                    row.get("rating") if row.get("rating") is not None else "",
                    metadata.get("fetched_at") or "", bool((ensured or {}).get("refreshed")),
                    row.get("error") or "",
                ])
    except Exception as exc:
        log("IMDb dataset report failed: {0}".format(exc), xbmc.LOGWARNING)


def apply_imdb_dataset_batch_1562(items: Iterable[Dict[str, Any]], cache: Dict[str, Any],
                                  ensured: Optional[Dict[str, Any]] = None,
                                  mode: str = "blank_only") -> Dict[str, Any]:
    """Batch IMDb lookup before online providers.

    mode=all audits every exact IMDb ID. mode=blank_only checks only records whose
    IMDb cell is genuinely empty; numeric and N/A cells are complete.
    """
    ensured = dict(ensured or ensure_imdb_dataset_1562(False))
    item_rows: List[Tuple[Dict[str, Any], str, str, Dict[str, Any]]] = []
    imdb_ids: List[str] = []
    cache_items = cache.setdefault("items", {})
    for item in list(items or []):
        if not isinstance(item, dict) or not resolvable_library_item(item):
            continue
        key = item_key(item)
        existing = cache_items.get(key) or {}
        if mode != "all" and not _lrs_imdb_row_blank_1562(_lrs_imdb_row_1562(existing)):
            continue
        imdb_id = _lrs_imdb_id_1562(item, existing)
        if not imdb_id:
            continue
        item_rows.append((item, key, imdb_id, existing))
        imdb_ids.append(imdb_id)

    batch = _imdb_dataset_ratings_1561.lookup_many(
        PROFILE, imdb_ids, max_age_days=7, timeout=45,
        log_callback=_lrs_imdb_dataset_log_1561, ensured=ensured,
    )
    results = batch.get("results") or {}
    annotations: Dict[str, Dict[str, Any]] = {}
    report_rows: List[Dict[str, Any]] = []
    found_count = 0
    changed_count = 0
    for item, key, imdb_id, existing in item_rows:
        lookup = dict(results.get(imdb_id) or {"status": "unavailable", "imdb_id": imdb_id})
        status = str(lookup.get("status") or "")
        annotation = {
            "checked": True, "status": status, "imdb_id": imdb_id,
            "rating": lookup.get("rating"), "error": str(lookup.get("error") or ""),
        }
        annotations[key] = annotation
        item["__lrs_imdb_dataset_1562"] = dict(annotation)
        if status == "found" and safe_float(lookup.get("rating")) is not None:
            before = _display_number_for_db("imdb", _lrs_imdb_row_1562(existing))
            updated = _lrs_merge_dataset_entry_1562(item, existing, lookup.get("rating"))
            cache_items[key] = updated
            after = _display_number_for_db("imdb", _lrs_imdb_row_1562(updated))
            found_count += 1
            if str(before) != str(after):
                changed_count += 1
        report_rows.append({
            "item_key": key, "media_type": media_setting_type(item.get("type")),
            "title": item.get("title") or "", "showtitle": item.get("showtitle") or "",
            "season": item.get("season"), "episode": item.get("episode"),
            "imdb_id": imdb_id, "status": status, "rating": lookup.get("rating"),
            "error": lookup.get("error") or "",
        })
    _append_imdb_dataset_report_1562(report_rows, ensured, mode)
    return {
        "ensured": ensured, "annotations": annotations,
        "checked": len(item_rows), "found": found_count, "changed": changed_count,
        "generation": imdb_dataset_generation_1562(ensured),
    }


_record_missing_logicals_1562_base = _record_missing_logicals_1561_base


def record_missing_logicals(media_type: Any, record: Dict[str, Any]) -> set:
    missing = set(_record_missing_logicals_1562_base(media_type, record))
    media = media_setting_type(media_type)
    if not rating_enabled(media, "imdb", True):
        missing.discard("imdb")
        return missing
    row = _lrs_imdb_row_1562(record or {})
    if row and (is_no_rating_marker(row) or not _lrs_imdb_row_blank_1562(row)):
        missing.discard("imdb")
    else:
        missing.add("imdb")
    return missing


_resolve_item_1562_online_base = _resolve_item_1561_base


def _lrs_dataset_annotation_1562(item: Dict[str, Any]) -> Dict[str, Any]:
    row = (item or {}).get("__lrs_imdb_dataset_1562")
    return dict(row) if isinstance(row, dict) else {}


def resolve_item(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None,
                 missing_only: bool = True, include_local: bool = False,
                 ratings_only: bool = False) -> Dict[str, Any]:
    """Final 1.5.62 resolver with dataset-first IMDb and no local/vote flow."""
    current_existing = existing if isinstance(existing, dict) else {}
    old_imdb = dict(_lrs_imdb_row_1562(current_existing) or {})
    annotation = _lrs_dataset_annotation_1562(item or {})
    should_check = not bool(annotation)
    if should_check:
        should_check = (not missing_only) or _lrs_imdb_row_blank_1562(old_imdb)
    if should_check:
        imdb_id = _lrs_imdb_id_1562(item or {}, current_existing)
        if imdb_id:
            lookup = _imdb_dataset_ratings_1561.lookup(
                PROFILE, imdb_id, max_age_days=7, timeout=45,
                log_callback=_lrs_imdb_dataset_log_1561,
            )
            annotation = {
                "checked": True, "status": str(lookup.get("status") or ""),
                "imdb_id": imdb_id, "rating": lookup.get("rating"),
                "error": str(lookup.get("error") or ""),
            }
        else:
            annotation = {"checked": False, "status": "invalid_id", "imdb_id": ""}

    dataset_found = (
        annotation.get("status") == "found"
        and safe_float(annotation.get("rating")) is not None
    )
    prepared_existing = dict(current_existing)
    if dataset_found:
        prepared_existing = _lrs_merge_dataset_entry_1562(
            item or {}, current_existing, annotation.get("rating")
        )

    online_keys = dict(keys or {})
    if media_setting_type((item or {}).get("type")) == "episode":
        # Episode IMDb is dataset-only. OMDb is not called for episodes.
        online_keys["omdb"] = ""

    result = _resolve_item_1562_online_base(
        item, online_keys, prepared_existing,
        missing_only=missing_only, include_local=False, ratings_only=ratings_only,
    )
    if not isinstance(result, dict):
        return result
    result = _lrs_strip_vote_data_1562(result)
    ratings = result.setdefault("ratings", {})

    if dataset_found:
        ratings["imdb"] = _lrs_dataset_rating_row_1562(annotation.get("rating"))
    elif old_imdb:
        # A dataset miss or outage must never destroy the previous value/N/A.
        ratings["imdb"] = _lrs_strip_vote_data_1562(old_imdb)
    elif media_setting_type((item or {}).get("type")) == "episode":
        ratings.pop("imdb", None)
    else:
        # MDBList IMDb rows are removed globally. Keep only a genuine OMDb
        # fallback result after MDBList item-not-found; remove synthetic N/A
        # closeout created solely because MDBList had no IMDb value.
        row = first_rating(ratings, "imdb")
        if row and is_no_rating_marker(row):
            meta = result.get("provider_meta") or {}
            if not isinstance(meta, dict) or "omdb" not in meta:
                ratings.pop("imdb", None)

    result["ratings"] = preserve_ratings_for_item(
        media_setting_type((item or {}).get("type")), ratings
    )
    result.setdefault("provider_meta", {})["imdb_dataset_1562"] = {
        "status": annotation.get("status") or "not_checked",
        "imdb_id": annotation.get("imdb_id") or "",
        "rating": annotation.get("rating") if dataset_found else "",
        "updated_at": now_iso(),
    }
    return _lrs_strip_vote_data_1562(result)





_diagnostic_candidates_1562_base = _diagnostic_candidates_1397


def _diagnostic_candidates_1397() -> List[str]:
    paths = []
    for path in _diagnostic_candidates_1562_base():
        if path not in paths:
            paths.append(path)
    if os.path.isfile(IMDB_DATASET_REPORT_1562) and IMDB_DATASET_REPORT_1562 not in paths:
        paths.append(IMDB_DATASET_REPORT_1562)
    return paths


# -----------------------------------------------------------------------------
# v1.5.63 - episode identity IDs must not be overwritten by parent-show IDs
# -----------------------------------------------------------------------------
# library_items() intentionally carries show_ids for TMDb/OMDb provider lookup.
# cache_identity_matches_1558() now ignores that provider-only field and compares
# only the current item's own ids/uniqueid/direct ID columns.  This prevents an
# ordinary post-scan auto scrape from treating every episode as a reused DBID.
LRS_SCHEMA_VERSION = max(globals().get("LRS_SCHEMA_VERSION", 0), 1564)


# -----------------------------------------------------------------------------
# Active DBID handoff, precise provider logs, and definitive TMDb episode 404
# -----------------------------------------------------------------------------
LRS_SCHEMA_VERSION = max(globals().get("LRS_SCHEMA_VERSION", 0), 1565)
LRS_DBID_HANDOFF_REPORT_1600 = os.path.join(REPORTS_DIR if 'REPORTS_DIR' in globals() else PROFILE, 'dbid-handoff-report.json')


def _lrs_basename_1565(value: Any) -> str:
    text = str(value or "").replace("/", "\\").rstrip("\\").lower()
    name = text.rsplit("\\", 1)[-1]
    return name.rsplit(".", 1)[0] if "." in name else name


def _lrs_handoff_identity_1600(value: Dict[str, Any]) -> Dict[str, Any]:
    value = value if isinstance(value, dict) else {}
    media = media_setting_type(value.get("type") or value.get("media_type"))
    ids = _lrs_identity_ids_1558(value)
    return {
        "media": media,
        "ids": ids,
        "title": _norm_text(value.get("title")),
        "show": _norm_text(value.get("showtitle")),
        "season": safe_int(value.get("season")),
        "episode": safe_int(value.get("episode")),
        "year": safe_int(value.get("year")),
        "basename": _lrs_basename_1565(value.get("file")),
    }


def handoff_source_replaced_1600(old_item: Dict[str, Any], new_item: Dict[str, Any]) -> bool:
    old_file = str((old_item or {}).get("file") or "").strip()
    new_file = str((new_item or {}).get("file") or "").strip()
    old_norm = old_file.replace("/", "\\").rstrip("\\").lower()
    new_norm = new_file.replace("/", "\\").rstrip("\\").lower()
    if old_norm and new_norm and old_norm == new_norm:
        return True
    if not old_file:
        return True
    try:
        # A different old source that still exists is an alternate/duplicate,
        # not a replacement. Keep both and scrape the new DBID normally.
        return not bool(xbmcvfs.exists(old_file))
    except Exception:
        return False


def handoff_identity_matches_1600(old_item: Dict[str, Any], new_item: Dict[str, Any]) -> bool:
    old = _lrs_handoff_identity_1600(old_item)
    new = _lrs_handoff_identity_1600(new_item)
    if old["media"] != new["media"] or old["media"] not in ("movie", "tvshow", "episode"):
        return False
    common = set(old["ids"]).intersection(new["ids"])
    strong = False
    for provider in ("imdb", "tmdb", "tvdb"):
        if provider not in common:
            continue
        left = str(old["ids"].get(provider) or "").lower()
        right = str(new["ids"].get(provider) or "").lower()
        if left and right:
            if left != right:
                return False
            strong = True
    if old["media"] == "episode":
        if old["show"] and new["show"] and old["show"] != new["show"]:
            return False
        if old["season"] is None or new["season"] is None or old["season"] != new["season"]:
            return False
        if old["episode"] is None or new["episode"] is None or old["episode"] != new["episode"]:
            return False
        if strong:
            return True
        if old["basename"] and new["basename"] and old["basename"] == new["basename"]:
            return True
        return bool(old["show"] and old["show"] == new["show"])
    if strong:
        return True
    if old["title"] and old["title"] == new["title"]:
        if old["year"] is not None and new["year"] is not None and old["year"] != new["year"]:
            return False
        return True
    return bool(old["basename"] and old["basename"] == new["basename"])


def handoff_cache_record_1600(cache: Dict[str, Any], old_item: Dict[str, Any], new_item: Dict[str, Any]) -> Dict[str, Any]:
    items = (cache or {}).setdefault("items", {})
    old_key, new_key = item_key(old_item), item_key(new_item)
    if not old_key or not new_key or old_key == new_key or old_key not in items:
        return {"handed_off": False}
    old_record = dict(items.get(old_key) or {})
    if not old_record:
        return {"handed_off": False}
    existing_new = items.get(new_key) or {}
    if existing_new and not cache_identity_matches_1558(new_item, existing_new):
        return {"handed_off": False, "reason": "new_key_conflict"}
    ids = dict(old_record.get("ids") or {})
    for key, value in extract_ids(new_item).items():
        if value not in (None, ""):
            ids[str(key)] = str(value)
    record = dict(old_record)
    record.update({
        "type": new_item.get("type"), "dbid": new_item.get("dbid"),
        "title": new_item.get("title") or old_record.get("title") or "",
        "showtitle": new_item.get("showtitle") or old_record.get("showtitle") or "",
        "season": new_item.get("season") if media_setting_type(new_item.get("type")) == "episode" else None,
        "episode": new_item.get("episode") if media_setting_type(new_item.get("type")) == "episode" else None,
        "year": new_item.get("year") or old_record.get("year") or "",
        "file": new_item.get("file") or old_record.get("file") or "",
        "ids": ids, "timestamp": int(time.time()), "updated_at": now_iso(),
    })
    items[new_key] = _lrs_strip_vote_data_1562(record)
    items.pop(old_key, None)
    return {"handed_off": True, "old_key": old_key, "new_key": new_key, "record": items[new_key]}


def salvage_dbid_handoffs_before_clean_1620() -> Dict[str, Any]:
    """Move stale cache rows to current uncached DBIDs before Clean Library deletes them.

    This is a current-runtime safety net, not a schema migration. It runs only
    around Kodi CleanFinished, requires a strong one-to-one identity match, and
    refuses alternate sources whose old file still exists.
    """
    stats: Dict[str, Any] = {"handed_off": 0, "rows": [], "ambiguous": 0, "candidates": 0}
    try:
        cache = load_cache()
        cache_items = (cache or {}).get("items") or {}
        current_items = [dict(item) for item in library_items() if resolvable_library_item(item)]
        current_by_key = dict((item_key(item), item) for item in current_items if item_key(item))
        if not current_by_key:
            stats["error"] = "current_library_empty_or_unavailable"
            return stats

        old_items = []
        for key, row in cache_items.items():
            if key in current_by_key or not isinstance(row, dict):
                continue
            old = dict(row)
            if not old.get("type") or safe_int(old.get("dbid")) is None:
                try:
                    media, raw_dbid = str(key).split("|", 1)
                    old.setdefault("type", media)
                    old.setdefault("dbid", int(raw_dbid))
                except Exception:
                    continue
            old_items.append(old)

        new_items = [item for key, item in current_by_key.items() if key not in cache_items]
        stats["candidates"] = len(new_items)
        plans = []
        for new_item in new_items:
            matches = [old for old in old_items
                       if handoff_source_replaced_1600(old, new_item)
                       and handoff_identity_matches_1600(old, new_item)]
            if len(matches) == 1:
                plans.append((new_item, matches[0]))
            elif len(matches) > 1:
                stats["ambiguous"] += 1
                log("Clean-time rating handoff skipped for {0}: ambiguous old DBIDs {1}".format(
                    item_key(new_item), [item_key(old) for old in matches]), xbmc.LOGWARNING)

        old_use: Dict[str, int] = {}
        for _new_item, old_item in plans:
            key = item_key(old_item)
            old_use[key] = old_use.get(key, 0) + 1

        rows = []
        for new_item, old_item in plans:
            old_key = item_key(old_item)
            if old_use.get(old_key, 0) != 1:
                stats["ambiguous"] += 1
                continue
            result = handoff_cache_record_1600(cache, old_item, new_item)
            if not result.get("handed_off"):
                continue
            rows.append({
                "old_key": result.get("old_key"),
                "new_key": result.get("new_key"),
                "title": new_item.get("title") or new_item.get("showtitle") or "",
                "reason": "clean_time_active_dbid_handoff",
            })

        if rows:
            save_cache(cache)
            write_dbid_handoff_report_1600(rows)
        stats["handed_off"] = len(rows)
        stats["rows"] = rows
        return stats
    except Exception as exc:
        stats["error"] = str(exc)
        log("Clean-time DBID handoff salvage failed: {0}".format(exc), xbmc.LOGWARNING)
        return stats


def write_dbid_handoff_report_1600(rows: List[Dict[str, Any]]) -> None:
    if not rows:
        return
    try:
        _atomic_json(LRS_DBID_HANDOFF_REPORT_1600, {"created_at": now_iso(), "count": len(rows), "items": rows})
    except Exception as exc:
        log("DBID handoff report failed: {0}".format(exc), xbmc.LOGWARNING)


_tmdb_lookup_1565_base = tmdb_lookup


def tmdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: Any) -> Tuple[Dict[str, Any], Dict[str, str]]:
    if media_setting_type((item or {}).get("type")) != "episode":
        return _tmdb_lookup_1565_base(item, ids, key)
    if not key:
        return {}, dict(ids or {})
    output: Dict[str, Any] = {}
    updated_ids = dict(ids or {})
    show_ids = dict((item or {}).get("show_ids") or {})
    # Episode endpoints require a parent-show TMDb ID. Trust only the typed
    # parent ID supplied by Kodi. Do not reinterpret TVDb/imdbnumber values and
    # do not title-search a potentially different show.
    show_tmdb = show_ids.get("tmdb")
    season, episode = safe_int(item.get("season")), safe_int(item.get("episode"))
    if not show_tmdb or season is None or episode is None:
        return output, updated_ids
    payload = tmdb_get("tv/{0}/season/{1}/episode/{2}".format(show_tmdb, season, episode), str(key))
    payload = payload if isinstance(payload, dict) else {}
    http_status = safe_int(payload.get("__http_status"))
    tmdb_status = safe_int(payload.get("status_code"))
    if http_status == 404 or tmdb_status == 34:
        updated_ids.setdefault("show_tmdb", str(show_tmdb))
        output["tmdb"] = no_rating_row("tmdb", "tmdb_episode_not_found_404")
        return output, updated_ids
    if _tmdb_payload_has_error_157(payload):
        return output, updated_ids
    if _tmdb_episode_payload_valid_157(payload):
        updated_ids.setdefault("show_tmdb", str(show_tmdb))
        if payload.get("id") not in (None, ""):
            updated_ids.setdefault("tmdb", str(payload.get("id")))
        vote = safe_float(payload.get("vote_average"))
        if vote is None or vote <= 0:
            output["tmdb"] = no_rating_row("tmdb", "tmdb_episode_vote_empty")
        else:
            merge_rating(output, normalized_rating("tmdb", vote, vote * 10, None, "tmdb"), overwrite=True)
    return _lrs_strip_vote_data_1562(output), updated_ids


_mdblist_lookup_1565_base = mdblist_lookup


def mdblist_lookup(ids: Dict[str, str], media_type: str, key: Any) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    before = dict((key.get("limited") or {})) if isinstance(key, dict) else {}
    found, meta = _mdblist_lookup_1565_base(ids, media_type, key)
    after = dict((key.get("limited") or {})) if isinstance(key, dict) else {}
    total = len(_provider_key_list(key))
    newly_limited = sorted(int(idx) + 1 for idx, value in after.items() if value and not before.get(idx))
    for index in newly_limited:
        log("MDBList key {0} daily limit reached".format(index), xbmc.LOGWARNING)
    if (meta or {}).get("all_keys_limited") or ((meta or {}).get("limited") and total and len(after) >= total):
        log("All MDBList API keys are limited; current job will stop", xbmc.LOGWARNING)
    else:
        used = safe_int((meta or {}).get("key_index")) or 0
        if newly_limited and used:
            log("MDBList request continued with key {0}".format(used), xbmc.LOGINFO)
        elif newly_limited and total > max(newly_limited):
            log("Switching MDBList request to key {0}".format(max(newly_limited) + 1), xbmc.LOGINFO)
    return found, meta





# v1.5.65 typed provider-ID safety. Kodi's untyped imdbnumber field can be
# numeric for either TMDb or TVDb depending on the scraper. Never relabel a
# number that Kodi already typed as another provider.
_extract_ids_1565_typed_base = extract_ids

def extract_ids(row: Dict[str, Any]) -> Dict[str, str]:
    row = row if isinstance(row, dict) else {}
    ids: Dict[str, str] = {}
    unique = row.get("uniqueid") or {}
    if isinstance(unique, dict):
        for provider, raw in unique.items():
            raw = str(raw or "").strip()
            if raw:
                ids[str(provider).lower()] = raw
    number = str(row.get("imdbnumber") or "").strip()
    if number:
        if number.lower().startswith("tt"):
            ids.setdefault("imdb", number)
        elif number.isdigit():
            typed_same = [provider for provider, raw in ids.items() if str(raw or "").strip() == number]
            if "tmdb" in typed_same:
                ids.setdefault("tmdb", number)
            elif typed_same:
                # Example: TVDb scraper stores uniqueid.tvdb=293146 and the same
                # value in imdbnumber. It must remain TVDb-only.
                pass
            # Untyped numeric imdbnumber values are deliberately ignored.
    return ids


# -----------------------------------------------------------------------------
# v1.5.67 - family layout and batch-close unavailable IMDb rows
# -----------------------------------------------------------------------------
LRS_SCHEMA_VERSION = max(globals().get("LRS_SCHEMA_VERSION", 0), 1567)
IMDB_DATASET_DIR_1567 = os.path.join(PROFILE, "cache", "imdb")
IMDB_DATASET_SYNC_STATE_1562 = os.path.join(STATE_DIR, "imdb-dataset-sync-state.json")



def ensure_imdb_dataset_1562(force_refresh: bool = False) -> Dict[str, Any]:
    return _imdb_dataset_ratings_1561.ensure_dataset(
        IMDB_DATASET_DIR_1567, max_age_days=7, timeout=45,
        force=bool(force_refresh), log_callback=_lrs_imdb_dataset_log_1561,
    )


def _lrs_unavailable_imdb_entry_1567(item: Dict[str, Any], existing: Dict[str, Any]) -> Dict[str, Any]:
    media = media_setting_type((item or {}).get("type"))
    entry = dict(existing or {})
    ids = dict(entry.get("ids") or {})
    for key, value in extract_ids(item or {}).items():
        if value not in (None, ""):
            ids[str(key)] = str(value)
    ratings = preserve_ratings_for_item(media, entry.get("ratings") or {})
    row = no_rating_row("imdb", "")
    row.update({
        "reason": "",
        "logical": "imdb", "cache_key": "imdb", "source": "imdb",
        "provider": "imdb_dataset", "updated_at": now_iso(),
    })
    ratings["imdb"] = _lrs_strip_vote_data_1562(row)
    provider_meta = dict(entry.get("provider_meta") or {})
    provider_meta.pop("imdb_dataset_1561", None)
    provider_meta.pop("imdb_dataset_1562", None)
    entry.update({
        "type": item.get("type"), "dbid": item.get("dbid"),
        "title": item.get("title") or entry.get("title") or "",
        "year": item.get("year") or entry.get("year") or "",
        "showtitle": item.get("showtitle") or entry.get("showtitle") or "",
        "season": item.get("season") if item.get("type") == "episode" else None,
        "episode": item.get("episode") if item.get("type") == "episode" else None,
        "ids": ids, "ratings": ratings,
        "provider_meta": _lrs_strip_vote_data_1562(provider_meta),
        "series": entry.get("series") or {}, "awards": entry.get("awards") or {},
        "imdb_top250_rank": entry.get("imdb_top250_rank") or 0,
        "errors": entry.get("errors") or [], "timestamp": int(time.time()),
        "updated_at": now_iso(),
    })
    return _lrs_strip_vote_data_1562(entry)


def apply_imdb_dataset_batch_1562(items: Iterable[Dict[str, Any]], cache: Dict[str, Any],
                                  ensured: Optional[Dict[str, Any]] = None,
                                  mode: str = "blank_only") -> Dict[str, Any]:
    """One local batch. Found rows become numeric; definitive misses become N/A.

    No per-item technical reason is persisted. A new global dataset generation
    audits all IMDb rows again, while an item identity/IMDb-ID change reopens the
    normal missing flow.
    """
    ensured = dict(ensured or ensure_imdb_dataset_1562(False))
    item_rows = []
    imdb_ids = []
    cache_items = cache.setdefault("items", {})
    for item in list(items or []):
        if not isinstance(item, dict) or not resolvable_library_item(item):
            continue
        key = item_key(item)
        existing = cache_items.get(key) or {}
        if mode != "all" and not _lrs_imdb_row_blank_1562(_lrs_imdb_row_1562(existing)):
            continue
        imdb_id = _lrs_imdb_id_1562(item, existing)
        item_rows.append((item, key, imdb_id, existing))
        if imdb_id:
            imdb_ids.append(imdb_id)

    batch = _imdb_dataset_ratings_1561.lookup_many(
        IMDB_DATASET_DIR_1567, imdb_ids, max_age_days=7, timeout=45,
        log_callback=_lrs_imdb_dataset_log_1561, ensured=ensured,
    ) if imdb_ids else {"results": {}}
    results = batch.get("results") or {}
    annotations = {}
    report_rows = []
    found_count = changed_count = unavailable_count = 0
    for item, key, imdb_id, existing in item_rows:
        if imdb_id:
            lookup = dict(results.get(imdb_id) or {"status": "unavailable", "imdb_id": imdb_id})
            status = str(lookup.get("status") or "unavailable")
        else:
            lookup = {"status": "unavailable", "imdb_id": "", "rating": None, "error": ""}
            status = "unavailable"
        annotation = {"checked": True, "status": status, "imdb_id": imdb_id,
                      "rating": lookup.get("rating"), "error": str(lookup.get("error") or "")}
        annotations[key] = annotation
        item["__lrs_imdb_dataset_1562"] = dict(annotation)
        before = _display_number_for_db("imdb", _lrs_imdb_row_1562(existing))
        if status == "found" and safe_float(lookup.get("rating")) is not None:
            updated = _lrs_merge_dataset_entry_1562(item, existing, lookup.get("rating"))
            found_count += 1
        elif status in ("not_found", "unavailable") and not str(lookup.get("error") or "").strip():
            updated = _lrs_unavailable_imdb_entry_1567(item, existing)
            unavailable_count += 1
        else:
            updated = existing
        if updated is not existing:
            cache_items[key] = updated
            after = _display_number_for_db("imdb", _lrs_imdb_row_1562(updated))
            if str(before) != str(after):
                changed_count += 1
        report_rows.append({
            "item_key": key, "media_type": media_setting_type(item.get("type")),
            "title": item.get("title") or "", "showtitle": item.get("showtitle") or "",
            "season": item.get("season"), "episode": item.get("episode"),
            "imdb_id": imdb_id, "status": status, "rating": lookup.get("rating"),
            "error": lookup.get("error") or "",
        })
    _append_imdb_dataset_report_1562(report_rows, ensured, mode)
    return {"ensured": ensured, "annotations": annotations,
            "checked": len(item_rows), "found": found_count,
            "unavailable": unavailable_count, "changed": changed_count,
            "generation": imdb_dataset_generation_1562(ensured)}



# Active DBID handoff report belongs under runtime/reports.
LRS_DBID_HANDOFF_REPORT_1600 = os.path.join(REPORTS_DIR, 'dbid-handoff-report.json')


# v1.5.67 family diagnostics retention: build and validate the replacement ZIP
# first, then remove older exports. A failed export never destroys the last good ZIP.
def export_diagnostics_zip_1397() -> str:
    import zipfile  # pylint: disable=import-outside-toplevel
    for folder in (STATE_DIR, DIAGNOSTICS_DIR, REPORTS_DIR, LOGS_DIR, EXPORTS_DIR):
        try:
            os.makedirs(folder, exist_ok=True)
        except Exception:
            pass
    try:
        _write_lrs_diagnostic_heartbeat_1560("diagnostics export requested")
        _write_lrs_log_status_1560("diagnostics export requested")
        _ensure_screensaver_clearlogo_report_1541()
    except Exception:
        pass
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    zip_path = os.path.join(PROFILE, "lrs-diagnostics-{0}.zip".format(stamp))
    tmp_path = zip_path + ".tmp"
    files = _diagnostic_files_1500()
    try:
        report = export_csv(load_cache())
        if report and os.path.exists(report) and report not in files:
            files.append(report)
    except Exception:
        pass
    try:
        with zipfile.ZipFile(tmp_path, "w", zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("manifest.json", json.dumps({
                "addon_id": ADDON_ID,
                "addon_name": ADDON.getAddonInfo("name"),
                "addon_version": ADDON.getAddonInfo("version"),
                "created_at": now_iso(),
                "zip_layout": "runtime-v1",
            }, indent=2) + "\n")
            for path in files:
                try:
                    apath = os.path.abspath(path)
                    if apath in (os.path.abspath(zip_path), os.path.abspath(tmp_path)) or not os.path.exists(apath):
                        continue
                    base = os.path.basename(apath)
                    if apath.startswith(os.path.abspath(STATE_DIR)):
                        arc = "runtime/state/" + base
                    elif apath.startswith(os.path.abspath(REPORTS_DIR)):
                        arc = "runtime/reports/" + base
                    elif apath.startswith(os.path.abspath(LOGS_DIR)):
                        arc = "runtime/logs/" + base
                    elif apath.startswith(os.path.abspath(DIAGNOSTICS_DIR)):
                        arc = "runtime/diagnostics/" + base
                    elif apath == os.path.abspath(os.path.join(PROFILE, "settings.xml")):
                        arc = "summary/settings.xml"
                    elif apath == os.path.abspath(CACHE_DB_FILE):
                        arc = "profile/" + base
                    else:
                        arc = "profile/" + base
                    if _is_text_diag_1500(apath):
                        zf.writestr(arc, _redact_text_1500(_read_text_file_1500(apath)))
                    else:
                        zf.write(apath, arc)
                except Exception as exc:  # pylint: disable=broad-except
                    try:
                        zf.writestr("summary/include-error-{0}.txt".format(base), str(exc))
                    except Exception:
                        pass
        with zipfile.ZipFile(tmp_path, "r") as test_zf:
            bad = test_zf.testzip()
            if bad:
                raise RuntimeError("Diagnostics ZIP validation failed at {0}".format(bad))
        for folder in (PROFILE, DIAGNOSTICS_DIR, EXPORTS_DIR):
            try:
                for name in os.listdir(folder):
                    path = os.path.join(folder, name)
                    if name.startswith("lrs-diagnostics-") and name.endswith(".zip") and os.path.abspath(path) != os.path.abspath(zip_path):
                        os.remove(path)
            except Exception:
                pass
        os.replace(tmp_path, zip_path)
        return zip_path
    except Exception:
        try:
            if os.path.isfile(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        raise



# -----------------------------------------------------------------------------
# v1.5.69 - definitive N/A closeout
# -----------------------------------------------------------------------------
_LRS_RT_PERMANENT_1569 = ('no_slug', 'slug_mismatch', 'badge_not_found', 'not_found')


def _rt_status_base_1569(value):
    text = str(value or '').strip().lower()
    return text.split(' ', 1)[0].split('(', 1)[0].strip()


_record_missing_rt_badge_1569_base = record_missing_rt_badge

def record_missing_rt_badge(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if media_setting_type((item or {}).get('type')) != 'movie':
        return False
    status = _rt_status_base_1569(((record or {}).get('rt_badge') or {}).get('status') or (record or {}).get('rottentomatoes_status'))
    if status == 'n/a' or status in _LRS_RT_PERMANENT_1569:
        return False
    return _record_missing_rt_badge_1569_base(item, record)


_resolve_rt_badge_only_1569_base = resolve_rt_badge_only

def resolve_rt_badge_only(item: Dict[str, Any], keys: Dict[str, Any], existing: Optional[Dict[str, Any]] = None, force: bool = False) -> Dict[str, Any]:
    result = _resolve_rt_badge_only_1569_base(item, keys, existing, force=force)
    if not isinstance(result, dict):
        return result
    badge = result.setdefault('rt_badge', {})
    status = _rt_status_base_1569(badge.get('status') or result.get('rottentomatoes_status'))
    if status in _LRS_RT_PERMANENT_1569:
        badge['status'] = 'N/A'
        result['rottentomatoes_status'] = 'N/A'
    return result




# -----------------------------------------------------------------------------
# v1.5.70 - in-memory external ratings + definitive TMDb/RT closeout
# -----------------------------------------------------------------------------
CACHE_VERSION = max(CACHE_VERSION, 42)
LRS_SCHEMA_VERSION = max(globals().get("LRS_SCHEMA_VERSION", 0), 1570)
_EXTERNAL_MEMORY_1570 = {
    "loaded": False,
    "by_key": {},
    "by_imdb": {},
    "by_tmdb": {},
    "by_title_year": {},
}


def _external_title_year_key_1570(item: Dict[str, Any]) -> str:
    media = media_setting_type((item or {}).get("type") or (item or {}).get("media_type"))
    title = _norm_text((item or {}).get("title"))
    year = safe_int((item or {}).get("year"))
    return "{0}|{1}|{2}".format(media, title, year if year is not None else "")


def _external_memory_clear_1570() -> None:
    for name in ("by_key", "by_imdb", "by_tmdb", "by_title_year"):
        _EXTERNAL_MEMORY_1570[name] = {}
    _EXTERNAL_MEMORY_1570["loaded"] = False


def _external_memory_add_1570(entry: Dict[str, Any]) -> None:
    if not isinstance(entry, dict) or not entry:
        return
    row = dict(entry)
    key = str(row.get("item_key") or "")
    if key:
        _EXTERNAL_MEMORY_1570["by_key"][key] = row
    imdb = _norm_imdb((row.get("ids") or {}).get("imdb") or row.get("imdb_id") or row.get("imdbnumber"))
    tmdb = _norm_tmdb((row.get("ids") or {}).get("tmdb") or row.get("tmdb_id"))
    if imdb:
        _EXTERNAL_MEMORY_1570["by_imdb"][imdb] = row
    if tmdb:
        _EXTERNAL_MEMORY_1570["by_tmdb"][tmdb] = row
    title_key = _external_title_year_key_1570(row)
    if title_key:
        _EXTERNAL_MEMORY_1570["by_title_year"][title_key] = row


def load_external_memory_1570(force: bool = False) -> Dict[str, Any]:
    if _EXTERNAL_MEMORY_1570.get("loaded") and not force:
        return _EXTERNAL_MEMORY_1570
    _external_memory_clear_1570()
    conn = None
    try:
        conn = _sqlite_connect()
        rows = conn.execute("SELECT * FROM external_ratings ORDER BY timestamp DESC, item_key").fetchall()
        for dbrow in rows:
            entry = _external_row_to_entry_1430(dbrow)
            # Preserve the physical external key, which may intentionally be a
            # title/year identity created before provider IDs became available.
            entry["item_key"] = str(_row_value(dbrow, "item_key") or record_item_key(entry) or "")
            _external_memory_add_1570(entry)
        _EXTERNAL_MEMORY_1570["loaded"] = True
    except Exception as exc:  # pylint: disable=broad-except
        log("External memory cache load failed: {0}".format(exc), xbmc.LOGWARNING)
        _EXTERNAL_MEMORY_1570["loaded"] = True
    finally:
        if conn is not None:
            try:
                conn.close()
            except Exception:
                pass
    return _EXTERNAL_MEMORY_1570


def _external_memory_find_1570(item: Dict[str, Any]) -> Dict[str, Any]:
    load_external_memory_1570(False)
    candidates: List[Dict[str, Any]] = []
    key = external_item_key_1430(item or {})
    direct = _EXTERNAL_MEMORY_1570["by_key"].get(key)
    if isinstance(direct, dict):
        candidates.append(direct)
    imdb = _norm_imdb((item or {}).get("imdbnumber") or (item or {}).get("imdb_id") or (item or {}).get("imdb"))
    tmdb = _norm_tmdb((item or {}).get("tmdb_id") or (item or {}).get("tmdb"))
    for row in (
        _EXTERNAL_MEMORY_1570["by_imdb"].get(imdb) if imdb else None,
        _EXTERNAL_MEMORY_1570["by_tmdb"].get(tmdb) if tmdb else None,
        _EXTERNAL_MEMORY_1570["by_title_year"].get(_external_title_year_key_1570(item or {})),
    ):
        if isinstance(row, dict) and row not in candidates:
            candidates.append(row)
    valid = [row for row in candidates if context_matches_record(item or {}, row)]
    return _choose_best_record(media_setting_type((item or {}).get("type")), valid, valid[0] if valid else None) if valid else {}


_load_external_record_1570_db_base = load_external_record_1430


def load_external_record_1430(item: Dict[str, Any]) -> Dict[str, Any]:
    """RAM-first external lookup; SQLite is only a fallback/recovery path."""
    if not valid_library_item(item):
        return {}
    record = _external_memory_find_1570(item or {})
    if record:
        return record
    record = _load_external_record_1570_db_base(item)
    if record:
        _external_memory_add_1570(record)
    return record


_save_external_record_1570_db_base = save_external_record_1430


def save_external_record_1430(item: Dict[str, Any], entry: Dict[str, Any]) -> None:
    _save_external_record_1570_db_base(item, entry)
    row = dict(entry or {})
    row["item_key"] = external_item_key_1430(row if row.get("title") else (item or {}))
    _external_memory_add_1570(row)
    _EXTERNAL_MEMORY_1570["loaded"] = True


_cache_record_1570_base = cache_record


def cache_record(cache: Dict[str, Any], item: Dict[str, Any]) -> Dict[str, Any]:
    record = _cache_record_1570_base(cache, item)
    if record:
        return record
    try:
        if valid_library_item(item) and not resolvable_library_item(item):
            return load_external_record_1430(item)
    except Exception:
        pass
    return {}







# -----------------------------------------------------------------------------
# v1.6.1 - direct clean database implementation
# -----------------------------------------------------------------------------
def _clean_table_columns_1600(conn: sqlite3.Connection, table: str) -> List[str]:
    """Return the current physical column order without rewriting the table."""
    return [str(row[1]) for row in conn.execute("PRAGMA table_info({0})".format(str(table))).fetchall()]

LRS_SCHEMA_VERSION = "1.6.1"
_LRS_CLEAN_SCHEMA_NAME_1610 = "ratings-clean-baseline-v1610"

def _ensure_current_cache_schema(conn: sqlite3.Connection) -> None:
    conn.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)")
    for table in ("ratings", "external_ratings"):
        columns = _clean_table_columns_1600(conn, table)
        if not columns:
            conn.execute(_rating_schema_sql_1551(table))
            columns = _clean_table_columns_1600(conn, table)
        expected = list(FINAL_RATINGS_COLUMNS)
        if list(columns) != expected:
            raise RuntimeError(
                "Unsupported LRS database schema. Fresh install required; "
                "current columns required for {0}.".format(table)
            )
        conn.execute("CREATE INDEX IF NOT EXISTS idx_lrs_{0}_type_dbid ON {0}(media_type, dbid)".format(table))
        conn.execute("CREATE INDEX IF NOT EXISTS idx_lrs_{0}_title ON {0}(title)".format(table))
        conn.execute("CREATE INDEX IF NOT EXISTS idx_lrs_{0}_imdb_id ON {0}(imdb_id)".format(table))
        conn.execute("CREATE INDEX IF NOT EXISTS idx_lrs_{0}_tmdb_id ON {0}(tmdb_id)".format(table))
    _db_set_meta(conn, "schema_version", LRS_SCHEMA_VERSION)
    _db_set_meta(conn, "schema", _LRS_CLEAN_SCHEMA_NAME_1610)
    _db_set_meta(conn, "backend", "sqlite-ratings-only")
    _db_set_meta(conn, "addon_version", LRS_SCHEMA_VERSION)
    _db_set_meta(conn, "vote_data", "disabled")

def _sqlite_connect() -> sqlite3.Connection:
    os.makedirs(PROFILE, exist_ok=True)
    conn = sqlite3.connect(CACHE_DB_FILE, timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA busy_timeout=30000")
        _ensure_current_cache_schema(conn)
        conn.commit()
        return conn
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        conn.close()
        raise

def load_cache() -> Dict[str, Any]:
    try:
        conn = _sqlite_connect()
        try:
            rows = conn.execute("SELECT * FROM ratings ORDER BY media_type, dbid, item_key").fetchall()
            items: Dict[str, Any] = {}
            for row in rows:
                key = str(_row_value(row, "item_key") or "")
                if key:
                    items[key] = _ratings_only_row_to_entry(row)
            return {
                "version": safe_int(_db_get_meta(conn, "version")) or CACHE_VERSION,
                "updated_at": _db_get_meta(conn, "updated_at"),
                "backend": "sqlite-ratings-only",
                "items": items,
            }
        finally:
            conn.close()
    except sqlite3.Error as exc:
        log("SQLite cache load failed: {0}".format(exc), xbmc.LOGWARNING)
        return {"version": CACHE_VERSION, "updated_at": "", "backend": "sqlite-ratings-only", "items": {}}

def save_cache(cache: Dict[str, Any]) -> None:
    cache["version"] = CACHE_VERSION
    cache["updated_at"] = now_iso()
    cache["backend"] = "sqlite-ratings-only"
    conn = _sqlite_connect()
    try:
        if getattr(conn, "in_transaction", False):
            conn.commit()
        conn.execute("BEGIN IMMEDIATE")
        conn.execute("DELETE FROM ratings")
        for item_key, entry in (cache.get("items") or {}).items():
            _db_upsert_entry(conn, str(item_key), entry)
        _db_set_meta(conn, "version", CACHE_VERSION)
        _db_set_meta(conn, "updated_at", cache["updated_at"])
        _db_set_meta(conn, "backend", "sqlite-ratings-only")
        _db_set_meta(conn, "schema_version", LRS_SCHEMA_VERSION)
        _db_set_meta(conn, "schema", _LRS_CLEAN_SCHEMA_NAME_1610)
        _db_set_meta(conn, "addon_version", LRS_SCHEMA_VERSION)
        conn.commit()
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        conn.close()


# -----------------------------------------------------------------------------
# v1.6.3 - stable missing closeout and differential SQLite persistence
# -----------------------------------------------------------------------------
LRS_SCHEMA_VERSION = "1.6.3"


def _rt_status_base_1569(value):
    text = str(value or "").strip().lower()
    # Proven final states may carry structured detail after a semicolon.
    # Example: no_slug;src=rt_search;2026-07-25 18:44:22
    return text.split(";", 1)[0].split(" ", 1)[0].split("(", 1)[0].strip()


def _lrs_substantive_tuple_1630(values):
    values = tuple(values or ())
    ignored = {"updated_at", "timestamp"}
    return tuple(values[index] for index, name in enumerate(FINAL_RATINGS_COLUMNS) if name not in ignored)


def save_cache(cache: Dict[str, Any]) -> None:
    """Persist only new, changed, or removed rows.

    A missing-only pass must not make every database row look freshly updated.
    In-memory timestamp churn is ignored unless a substantive column changed.
    """
    cache["version"] = CACHE_VERSION
    cache["updated_at"] = now_iso()
    cache["backend"] = "sqlite-ratings-only"
    conn = _sqlite_connect()
    try:
        if getattr(conn, "in_transaction", False):
            conn.commit()
        conn.execute("BEGIN IMMEDIATE")
        existing_rows = {
            str(row["item_key"]): row
            for row in conn.execute("SELECT * FROM ratings").fetchall()
            if str(row["item_key"] or "")
        }
        incoming = cache.get("items") or {}
        changed = 0
        unchanged = 0
        for item_key, entry in incoming.items():
            item_key = str(item_key)
            values = list(_simple_db_rating_values(entry, item_key))
            old = existing_rows.get(item_key)
            if old is not None:
                old_values = tuple(old[name] for name in FINAL_RATINGS_COLUMNS)
                if _lrs_substantive_tuple_1630(values) == _lrs_substantive_tuple_1630(old_values):
                    unchanged += 1
                    # Preserve authentic row age in the in-memory object too.
                    try:
                        entry["updated_at"] = str(old["updated_at"] or "")
                        entry["timestamp"] = safe_int(old["timestamp"]) or 0
                    except Exception:
                        pass
                    continue
            now_text = now_iso()
            now_stamp = int(time.time())
            try:
                values[FINAL_RATINGS_COLUMNS.index("updated_at")] = now_text
                values[FINAL_RATINGS_COLUMNS.index("timestamp")] = now_stamp
                entry["updated_at"] = now_text
                entry["timestamp"] = now_stamp
            except Exception:
                pass
            conn.execute(
                "INSERT OR REPLACE INTO ratings({0}) VALUES({1})".format(
                    ",".join(FINAL_RATINGS_COLUMNS), ",".join(["?"] * len(FINAL_RATINGS_COLUMNS))
                ),
                tuple(values),
            )
            changed += 1
        stale = sorted(set(existing_rows) - {str(key) for key in incoming})
        if stale:
            conn.executemany("DELETE FROM ratings WHERE item_key=?", [(key,) for key in stale])
        _db_set_meta(conn, "version", CACHE_VERSION)
        _db_set_meta(conn, "updated_at", cache["updated_at"])
        _db_set_meta(conn, "backend", "sqlite-ratings-only")
        _db_set_meta(conn, "schema_version", LRS_SCHEMA_VERSION)
        _db_set_meta(conn, "schema", _LRS_CLEAN_SCHEMA_NAME_1610)
        _db_set_meta(conn, "addon_version", LRS_SCHEMA_VERSION)
        _db_set_meta(conn, "last_save_changed_rows", str(changed))
        _db_set_meta(conn, "last_save_unchanged_rows", str(unchanged))
        _db_set_meta(conn, "last_save_removed_rows", str(len(stale)))
        conn.commit()
    except Exception:
        try:
            conn.rollback()
        except Exception:
            pass
        raise
    finally:
        conn.close()

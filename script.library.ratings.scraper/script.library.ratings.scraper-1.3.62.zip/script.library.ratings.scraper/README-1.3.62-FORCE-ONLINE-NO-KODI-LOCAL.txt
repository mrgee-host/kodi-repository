Library Ratings Scraper 1.3.62

Fixes:
- Manual scrape/refresh no longer seeds ratings from Kodi local library ratings.
- This fixes RT/Metacritic/Trakt staying 0-10 after deleting ratings-cache.db.
- Kodi local rating fallback now converts RT/Metacritic/Trakt 0-10 to 0-100 if any non-manual path ever uses it.
- MDBList HTTP 401 for one item is no longer treated as Daily API Limit. Only HTTP 429 or explicit daily-limit text stops the run.
- MDBList URL now includes format=json.
- Rating scale trace remains enabled.

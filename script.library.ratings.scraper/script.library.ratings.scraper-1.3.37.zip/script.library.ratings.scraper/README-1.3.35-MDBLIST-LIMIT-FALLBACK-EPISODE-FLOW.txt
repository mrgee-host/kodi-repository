Library Ratings Scraper 1.3.35

Changes:
- MDBList API limit is no longer fatal. If MDBList returns HTTP 429 or Daily API limit exceeded, the current manual scrape disables MDBList for the rest of that run and falls back to OMDb/TMDb.
- OMDb request limit remains fatal for the current run because OMDb is the fallback provider for IMDb/RT/Metacritic/Awards and continuing would only waste time.
- Episode flow remains cache-first: read Kodi library metadata/IDs, check cache, then hit OMDb only for IMDb episode rating and TMDb only for TMDb episode rating when missing or forced.

Library Ratings Scraper 1.3.32

Changes:
- Restores add-on menu items for Cancel background process, View background status, and View CSV report.
- Keeps UI/menu text in English.
- Uses one generic CSV field for Top 250 rank: imdb_top250_rank. Movies and TV shows both write to this field.
- Keeps manual-only online scraping: focus lookup, screensaver preload and auto-refresh remain disabled in service code.
- Keeps TMDbHelper-compatible property publishing so Arctic Fuse 3 can read cached values.
- Makes setting reads more tolerant of older saved settings that are no longer present in settings.xml.

Scrape missing behavior:
The add-on scans all enabled media types, skips complete cached items, and hits a provider only when an enabled field is missing. When a provider is hit, every enabled rating returned by that same response is merged because it costs no extra request.

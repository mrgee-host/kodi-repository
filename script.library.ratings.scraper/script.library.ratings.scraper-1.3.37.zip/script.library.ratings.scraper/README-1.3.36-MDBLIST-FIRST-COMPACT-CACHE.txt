Library Ratings Scraper 1.3.36

Changes:
- OMDb IMDb-ID success stops immediately. If i=tt... returns a valid OMDb item, no title/season/episode fallback request is made.
- Movie/TV rating flow is MDBList-first and final: a normal MDBList response is accepted even when some rating families are absent; OMDb is not queried for ratings after that.
- MDBList API limit still falls back to OMDb/TMDb for the rest of the run.
- OMDb is still used for Oscar/Emmy wins when Awards is enabled.
- TV status/date still comes from TMDb when status is enabled.
- Cache/debug provider metadata is compacted: no raw byte counts, payload keys, duplicate scheme noise, or verbose HTTP internals.

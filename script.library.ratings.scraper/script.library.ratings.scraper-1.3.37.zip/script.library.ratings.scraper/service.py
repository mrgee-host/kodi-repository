# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import time
import xbmc
import xbmcgui
from resources.lib import core

POLL_SECONDS = 0.40
STATE_FILE = os.path.join(core.PROFILE, "service-state.json")
TITLE = "Library Ratings Scraper"


def load_state():
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as handle:
            row = json.load(handle)
        return row if isinstance(row, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(state):
    os.makedirs(core.PROFILE, exist_ok=True)
    temp = STATE_FILE + ".tmp"
    with open(temp, "w", encoding="utf-8") as handle:
        json.dump(state, handle, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(temp, STATE_FILE)


def current_item():
    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        item = core.screensaver_item(0)
        if core.valid_library_item(item):
            return item
        # Some screensaver widgets temporarily expose empty DBID while fanart is
        # fading. Fall back to the normal selected item for that single cycle.
        item = core.selected_library_item()
        if core.valid_library_item(item):
            return item
        item = core.lrs_active_item()
        if core.valid_library_item(item):
            return item
        # Some screensaver widgets temporarily expose empty DBID while fanart is
        # fading. Fall back to the normal selected item for that single cycle.
        return core.tmdbhelper_item()
    item = core.selected_library_item()
    if core.valid_library_item(item):
        return item
    item = core.lrs_active_item()
    if core.valid_library_item(item):
        return item
    # Arctic Fuse 3 hub/spotlight often focuses a button. Use AF3/TMDbHelper's
    # current-window or Home identity properties to find our local cache row.
    return core.tmdbhelper_item()


def queue_item(queue, queued, item, front=False):
    # Background lookup requires a Kodi DBID. Title-only hub fallbacks can still
    # publish cached values, but should not be looked up online as a new item.
    if not core.resolvable_library_item(item):
        return
    key = core.item_key(item)
    if key in queued:
        return
    queued.add(key)
    if front:
        queue.insert(0, item)
    else:
        queue.append(item)


def publish_current(cache, item, previous_key):
    compatibility = core.bool_setting("publish_af3_cache", True)
    if not core.valid_library_item(item):
        core.clear_af3_properties(compatibility)
        return ""

    record = core.cache_record(cache, item)
    # Use an exact DBID key when available; otherwise use a stable title/year key
    # so AF3 hub title-only fallbacks can still update without waiting online.
    key = core.item_key(item) if core.safe_int(item.get("dbid")) is not None else "fallback|{0}|{1}|{2}".format(item.get("type", ""), item.get("title", ""), item.get("year", ""))
    # Always republish the current item. TMDbHelper/skin helpers can rewrite the same
    # compatibility properties after our first publish, especially on AF3 Hub/Spotlight.
    # Re-publishing keeps offline cache values stable instead of alternating between
    # TMDbHelper cached values and LRS cached values.
    values = core.af3_values(record)
    if record:
        core.publish_af3_properties(values, key, compatibility)
    else:
        # Clear quickly when the item is known but not cached. This avoids the
        # old-film rating flashing on a new hub/screensaver slide.
        core.publish_af3_properties({}, key, compatibility)
    return key


def item_label(item):
    title = item.get("title") or "Untitled"
    if item.get("type") == "episode":
        return "{0} - S{1:02d}E{2:02d} - {3}".format(
            item.get("showtitle") or "Series",
            core.safe_int(item.get("season")) or 0,
            core.safe_int(item.get("episode")) or 0,
            title,
        )
    return title


def notify(message, icon=xbmcgui.NOTIFICATION_INFO, duration=5000):
    xbmcgui.Dialog().notification(TITLE, message, icon, duration, False)


def write_job_state(job, status=None):
    item_total = len(job.get("items") or [])
    raw_total = job.get("total")
    total = int(raw_total) if raw_total not in (None, "") and int(raw_total or 0) > 0 else item_total
    processed = int(job.get("processed") or job.get("index") or 0)
    if total and processed > total:
        processed = total
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    state = {
        "status": status or job.get("status") or "running",
        "action": job.get("action") or "scrape",
        "force": bool(job.get("force")),
        "requested_at": job.get("requested_at") or "",
        "started_at": job.get("started_at") or "",
        "finished_at": job.get("finished_at") or "",
        "total": total,
        "processed": processed,
        "percent": percent,
        "updated": int(job.get("updated") or 0),
        "matched": int(job.get("matched") or 0),
        "skipped": int(job.get("skipped") or 0),
        "failed": int(job.get("failed") or 0),
        "current": job.get("current") or "",
        "report": job.get("report") or "",
    }
    core.save_background_state(state)


def compact_text(value, limit=26):
    text = str(value or "Preparing...").replace("\n", " ").strip()
    return text if len(text) <= limit else text[: max(0, limit - 3)].rstrip() + "..."


def update_bg(job, message=None):
    progress = job.get("progress")
    if progress is None:
        return
    total = int(job.get("total") or len(job.get("items") or []))
    processed = int(job.get("processed") or job.get("index") or 0)
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    # Keep the background notification deliberately minimal. Arctic Fuse 3
    # only has room for one compact body line. Detailed counters remain
    # available from the add-on menu: "View background status".
    text = message or "{0}/{1}  {2}".format(
        processed,
        total,
        compact_text(job.get("current")),
    )
    progress.update(percent, TITLE, compact_text(text, 58))


def new_scrape_job(request):
    items = core.library_items()
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, "Preparing background scrape...")
    total = len(items)
    job = {
        "action": "scrape",
        "force": bool(request.get("force")),
        "requested_at": request.get("requested_at") or core.now_iso(),
        "started_at": core.now_iso(),
        "items": items,
        "keys": core.api_keys(),
        "index": 0,
        "updated": 0,
        "matched": 0,
        "processed": 0,
        "total": total,
        "skipped": 0,
        "failed": 0,
        "looked_up": 0,
        "current": "Preparing...",
        "next_at": 0.0,
        "progress": progress,
        "status": "running",
    }
    write_job_state(job)
    notify("Background scrape running", xbmcgui.NOTIFICATION_INFO, 5000)
    return job


def new_top250_job(request):
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, "Syncing IMDb Top 250 Movies + TV Shows in background...")
    job = {
        "action": "top250",
        "force": True,
        "requested_at": request.get("requested_at") or core.now_iso(),
        "started_at": core.now_iso(),
        "items": [],
        "index": 0,
        "updated": 0,
        "skipped": 0,
        "failed": 0,
        "matched": 0,
        "processed": 0,
        "total": 0,
        "current": "IMDb Top 250",
        "progress": progress,
        "status": "running",
    }
    write_job_state(job)
    notify("IMDb Top 250 Movies + TV Shows sync running in background", xbmcgui.NOTIFICATION_INFO, 5000)
    return job


def finish_job(job, cache, canceled=False, stopped_reason=""):
    job["status"] = "finishing"
    write_job_state(job, "finishing")
    update_bg(job, "Saving cache...")
    core.save_cache(cache)

    if job.get("action") == "scrape" and not canceled and not stopped_reason:
        update_bg(job, "Syncing IMDb Top 250...")
        try:
            stats = core.sync_imdb_top250_to_library(False, None)
            job["matched"] = int(stats.get("matched") or 0)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("IMDb Top 250 sync failed after background scrape: {0}".format(exc), xbmc.LOGWARNING)
    elif job.get("action") == "top250" and not canceled:
        update_bg(job, "Reading and saving IMDb Top 250...")
        try:
            stats = core.sync_imdb_top250_to_library(True, None)
            job["updated"] = int(stats.get("updated") or 0)
            job["matched"] = int(stats.get("matched") or 0)
            job["total"] = int(stats.get("total") or 0)
            job["processed"] = int(stats.get("processed") or stats.get("total") or 0)
            job["percent"] = 100
            cache = core.load_cache()
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] = 1
            core.log("Manual IMDb Top 250 sync failed: {0}".format(exc), xbmc.LOGWARNING)

    update_bg(job, "Exporting CSV report...")
    report = core.export_csv(core.load_cache())
    job["report"] = report

    summary = {
        "started_at": job.get("started_at"),
        "finished_at": core.now_iso(),
        "items_total": int(job.get("total") or len(job.get("items") or [])),
        "matched": int(job.get("matched") or 0),
        "updated": int(job.get("updated") or 0),
        "matched": int(job.get("matched") or 0),
        "skipped": int(job.get("skipped") or 0),
        "failed": int(job.get("failed") or 0),
        "online_lookups": int(job.get("looked_up") or 0),
        "report": report,
        "canceled": bool(canceled),
        "stopped_reason": stopped_reason or "",
        "action": job.get("action"),
    }
    core.save_summary(summary)
    job["finished_at"] = summary["finished_at"]
    if stopped_reason:
        job["status"] = "stopped"
        job["current"] = stopped_reason
    else:
        job["status"] = "canceled" if canceled else "completed"
        job["current"] = "Canceled" if canceled else "Finished"
    if job.get("progress") is not None:
        job["progress"].close()
    write_job_state(job, job["status"])
    if stopped_reason:
        notify(stopped_reason, xbmcgui.NOTIFICATION_WARNING, 8000)
    elif canceled:
        notify("Background scrape canceled", xbmcgui.NOTIFICATION_WARNING, 6000)
    else:
        notify("Background scrape completed", xbmcgui.NOTIFICATION_INFO, 6000)


def force_stop_job(job):
    if job and job.get("progress") is not None:
        try:
            job["progress"].close()
        except Exception:  # pylint: disable=broad-except
            pass
    state = {
        "status": "force_stopped",
        "action": (job or {}).get("action", "scrape"),
        "force": bool((job or {}).get("force")),
        "requested_at": (job or {}).get("requested_at", ""),
        "started_at": (job or {}).get("started_at", ""),
        "finished_at": core.now_iso(),
        "percent": int((job or {}).get("percent") or 0),
        "processed": int((job or {}).get("index") or 0),
        "total": len((job or {}).get("items") or []),
        "updated": int((job or {}).get("updated") or 0),
        "skipped": int((job or {}).get("skipped") or 0),
        "failed": int((job or {}).get("failed") or 0),
        "current": "Force stopped",
    }
    core.save_background_state(state)


def advance_scrape(job, cache):
    if time.time() < float(job.get("next_at") or 0):
        return False
    items = job.get("items") or []
    total = len(items)
    job["total"] = total
    job["processed"] = int(job.get("index") or 0)
    if job.get("index", 0) >= total:
        finish_job(job, cache, False)
        return True

    # Skip fresh rows quickly in one UI cycle. Stop after the first online/local
    # resolve so API pacing remains predictable and the service stays responsive.
    handled = 0
    while job.get("index", 0) < total and handled < 100:
        item = items[job["index"]]
        job["index"] += 1
        job["processed"] = int(job.get("index") or 0)
        handled += 1
        key = core.item_key(item)
        existing = (cache.get("items") or {}).get(key) or {}
        label = item_label(item)
        job["current"] = label
        if not job.get("force") and existing and not core.record_needs_update(item, existing):
            job["skipped"] += 1
            update_bg(job)
            continue
        try:
            cache.setdefault("items", {})[key] = core.resolve_item(item, job.get("keys") or core.api_keys(), existing, missing_only=not job.get("force"))
            job["updated"] += 1
            job["looked_up"] += 1
        except core.ProviderLimitReached as exc:
            message = "Stopped: {0} API limit reached".format(exc.provider)
            detail = str(exc)
            job["failed"] += 1
            job["current"] = message
            job["stopped_reason"] = message
            core.log("{0}. {1}".format(message, detail), xbmc.LOGWARNING)
            core.save_cache(cache)
            finish_job(job, cache, False, message)
            return True
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] += 1
            core.log("Background full scrape failed for {0}: {1}".format(label, exc), xbmc.LOGWARNING)
        if job["index"] % max(1, core.int_setting("save_every", 10)) == 0:
            core.save_cache(cache)
        delay = max(0, core.int_setting("delay_ms", 1100)) / 1000.0
        job["next_at"] = time.time() + delay
        update_bg(job)
        write_job_state(job)
        return False

    job["processed"] = int(job.get("index") or 0)
    write_job_state(job)
    if job.get("index", 0) >= total:
        finish_job(job, cache, False)
        return True
    return False


def advance_job(job, cache):
    if core.consume_background_force_stop():
        force_stop_job(job)
        return True
    if core.consume_background_cancel():
        finish_job(job, cache, True)
        return True
    if job.get("action") == "top250":
        finish_job(job, cache, False)
        return True
    return advance_scrape(job, cache)


def main():
    monitor = xbmc.Monitor()
    cache = core.load_cache()
    state = load_state()
    queue = []
    queued = set()
    previous_key = ""
    preloaded_key = ""
    next_lookup_at = 0.0
    manual_job = None
    compatibility = core.bool_setting("publish_af3_cache", True)
    core.clear_af3_properties(compatibility)
    core.log("Library Ratings Scraper service started", xbmc.LOGINFO)

    while not monitor.abortRequested():
        now = time.time()
        if core.consume_background_force_stop():
            queue = []
            queued = set()
            if manual_job is not None:
                force_stop_job(manual_job)
                manual_job = None
                cache = core.load_cache()
            notify("Force stop background", xbmcgui.NOTIFICATION_WARNING, 5000)
            previous_key = ""
            preloaded_key = ""

        item = current_item()
        previous_key = publish_current(cache, item, previous_key)

        request = core.consume_background_request()
        if request:
            if manual_job is not None:
                notify("Previous background process is still running", xbmcgui.NOTIFICATION_WARNING, 5000)
            elif request.get("action") == "top250":
                manual_job = new_top250_job(request)
            else:
                manual_job = new_scrape_job(request)

        # Missing focused local items are queued, but stale cache remains visible
        # until the refreshed value is ready. This removes visible rating gaps.
        if False and core.valid_library_item(item):
            record = core.cache_record(cache, item)
            if not record or core.record_needs_update(item, record):
                queue_item(queue, queued, item, front=True)

        # Arctic Mirage gets one-item look-ahead. During the current 20-second
        # slide, the next random slide is resolved into the same scraper cache.
        if False and xbmc.getCondVisibility("System.ScreenSaverActive"):
            upcoming = core.screensaver_item(1)
            upcoming_key = core.item_key(upcoming) if core.valid_library_item(upcoming) else ""
            if upcoming_key and upcoming_key != preloaded_key:
                preloaded_key = upcoming_key
                record = core.cache_record(cache, upcoming)
                if not record or not core.fresh(record):
                    queue_item(queue, queued, upcoming, front=True)

        # Once per configured check interval, maintain the month-long cache.
        if False and core.bool_setting("auto_refresh", False):
            check_hours = max(1, core.int_setting("auto_refresh_check_hours", 24))
            last_check = core.safe_float(state.get("last_auto_check")) or 0
            if now - last_check >= check_hours * 3600:
                state["last_auto_check"] = int(now)
                # The first complete fill remains manual so a fresh installation
                # cannot unexpectedly issue thousands of API calls. After that,
                # newly added and expired items are maintained automatically.
                if (cache.get("items") or {}):
                    for stale in core.stale_or_missing_items(cache, include_missing=True):
                        queue_item(queue, queued, stale)
                    try:
                        core.sync_imdb_top250_to_library(False, None)
                    except Exception as exc:  # pylint: disable=broad-except
                        core.log("Automatic IMDb Top 250 sync failed: {0}".format(exc), xbmc.LOGWARNING)
                save_state(state)

        # Manual library scrape has priority but executes inside this background
        # service. Kodi's UI remains usable and DialogProgressBG appears only in
        # the notification area.
        if manual_job is not None:
            if advance_job(manual_job, cache):
                manual_job = None
                previous_key = ""
        elif queue and now >= next_lookup_at:
            queued_item = queue.pop(0)
            queued.discard(core.item_key(queued_item))
            try:
                k = core.item_key(queued_item)
                existing = (cache.get("items") or {}).get(k) or {}
                cache.setdefault("items", {})[k] = core.resolve_item(queued_item, core.api_keys(), existing, missing_only=True)
                core.save_cache(cache)
            except core.ProviderLimitReached as exc:
                core.log("Stopped idle lookup because {0} API limit reached: {1}".format(exc.provider, exc), xbmc.LOGWARNING)
                queue = []
                queued = set()
            except Exception as exc:  # pylint: disable=broad-except
                core.log("Background scrape failed: {0}".format(exc), xbmc.LOGWARNING)
            delay = max(250, core.int_setting("auto_refresh_delay_ms", 1500)) / 1000.0
            next_lookup_at = time.time() + delay
            previous_key = ""

        monitor.waitForAbort(POLL_SECONDS)

    if manual_job is not None and manual_job.get("progress") is not None:
        manual_job["progress"].close()
    core.clear_af3_properties(core.bool_setting("publish_af3_cache", True))
    core.log("Library Ratings Scraper service stopped", xbmc.LOGINFO)


if __name__ == "__main__":
    main()

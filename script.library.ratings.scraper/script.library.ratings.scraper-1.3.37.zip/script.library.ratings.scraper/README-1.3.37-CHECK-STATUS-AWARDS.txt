Library Ratings Scraper 1.3.37

Changes:
- Check random LIVE internet output now shows TV show status and award wins next to rating rows.
- TV shows show Status from TMDb when Status is enabled.
- Movies show Oscar wins from OMDb when Awards is enabled.
- TV shows show Emmy wins from OMDb when Awards is enabled.
- Sample result JSON includes compact series/awards fields for debugging.

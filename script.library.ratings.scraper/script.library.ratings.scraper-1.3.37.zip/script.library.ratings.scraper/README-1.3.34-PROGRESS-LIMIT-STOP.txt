Library Ratings Scraper 1.3.34

Fixes:
- Background scrape status now shows real processed/total counters instead of 0/0.
- Cancel background process is shown only while a job is active.
- MDBList HTTP 429 / "Daily API limit exceeded!" stops the whole scrape immediately instead of falling back to OMDb and continuing uselessly.
- OMDb "Request limit reached!" stops the whole scrape immediately.
- Limit stops are written to Kodi log and background status/summary.

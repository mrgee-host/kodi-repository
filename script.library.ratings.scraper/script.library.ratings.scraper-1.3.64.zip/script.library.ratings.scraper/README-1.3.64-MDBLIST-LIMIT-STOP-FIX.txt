Library Ratings Scraper 1.3.64

Fixes:
- Awards/status toggle is now respected before MDBList-limit fallback checks.
- When Awards OFF and TV status OFF, MDBList 429 stops the job instead of continuing through the rest of the library with empty rows.
- Fixes misleading state where processed/updated could show the whole library while ratings DB/report only contained the successful pre-limit rows.
- Trace header now prints the actual addon version instead of hardcoded 1.3.62.
- Does not change the rating provider flow: movie/tv rating remains MDBList-only; episodes remain OMDb/TMDb.

v1.5.16 KPM icon filename compatibility fix

- Verified Hot now maps to verified.png, matching the KPM shared-icons set.
- Legacy verifiedhot.png is no longer emitted as a texture filename.
- Legacy oscar.png/oscar_bp.png/oscars-bp.png normalize to oscars.png/oscars_bp.png.
- AF3/LRS patch fallback no longer intentionally copies icons into skin media/flags ratings folders. KPM shared-icons remains the canonical icon location.

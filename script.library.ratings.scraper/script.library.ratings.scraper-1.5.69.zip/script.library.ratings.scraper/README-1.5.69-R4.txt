script.library.ratings.scraper 1.5.69 - R4

MrGee Kodi Family R4 runtime and consistency fixes.

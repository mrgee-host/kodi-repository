Library Ratings Scraper 1.3.57

Fixes:
- Fixes service crash on startup: UnboundLocalError cache_mtime.
- DB cache is now ratings-only. The old items table is dropped after one final metadata backfill.
- The ratings table remains the single cache table used by service/load/save.
- Existing ratings fields and title/search columns are preserved.
- Manual-only behavior and API key rotation from 1.3.56 are preserved.

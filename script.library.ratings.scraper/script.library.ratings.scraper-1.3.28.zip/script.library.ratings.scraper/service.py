# -*- coding: utf-8 -*-
import os
import xbmc  # type: ignore
from resources.lib import core


class Service(xbmc.Monitor):
    def __init__(self):
        super(Service, self).__init__()
        self.last_key = ''
        self.last_mtime = 0
        self.cache = {"items": {}}

    def maybe_load_cache(self):
        try:
            mtime = os.path.getmtime(core.CACHE_FILE) if os.path.exists(core.CACHE_FILE) else 0
        except Exception:
            mtime = 0
        if mtime != self.last_mtime:
            self.cache = core.load_cache()
            self.last_mtime = mtime

    def run(self):
        core.log('service started')
        while not self.abortRequested():
            self.maybe_load_cache()
            rec = core.record_for_current_focus(self.cache)
            key = '{0}|{1}'.format(rec.get('type'), rec.get('dbid')) if rec else ''
            if key != self.last_key:
                core.publish_record(rec)
                self.last_key = key
            if self.waitForAbort(0.5):
                break
        core.clear_publish_properties()
        core.log('service stopped')


if __name__ == '__main__':
    Service().run()

Library Ratings Scraper 1.3.28

Simplified manual-only build.

Added:
- Bundled IMDb Top 250 TV Shows source: resources/data/imdb_top_tv_shows_with_id.json
- Sync IMDb Top 250 TV Shows menu item
- TV show Top 250 rank is applied during normal scrape and sync
- Unified rating settings for movies / series / episodes
- Episodes only use IMDb and TMDb even when other rating toggles are enabled
- MDBList is always first for movies and series; OMDb and TMDb are fallback/API sources
- Unavailable ratings are always marked as NO_RATING after a successful provider check

Removed from settings:
- Automatic scraping
- Cache age/lifetime
- Provider enable/disable toggles
- Separate movie/series/episode rating toggles
- Include animation short films
- Include Indonesian Movies Collection
- Mark unavailable ratings as checked toggle

Menus:
- Scrape missing ratings/status/Top 250
- Refresh all ratings/status/Top 250
- Sync IMDb Top 250 TV Shows
- Export CSV report
- Check random LIVE internet
- Settings

LRS 1.5.28 - clean Home/Hub DisplaySlot coordination

Base: 1.5.24, not 1.5.25/1.5.26/1.5.27.

Purpose:
- Rebuild the unified Home/Hub DisplaySlot path cleanly without carrying the broken 1.5.25/1.5.26/1.5.27 XML artifacts.
- Game is detected before valid_library_item/video checks.
- Home/Hub non-media/menu focus keeps the previous visual row untouched.
- AF3 patch removes 1.5.25/1.5.26/1.5.27 DisplaySlot markers before applying the clean 1.5.28 marker.
- Direct Steam/MediaHub game meta rows in Includes_Info.xml are disabled so there is only one lower meta row source.
- Ends-at raw infolabels such as Container(...).ListItem.FinishTime are filtered.

Important coordination requirement:
Steam Library AF3 patch must stop re-inserting its old direct game meta row after LRS applies the AF3 patch. If Steam Library patch is run after LRS and re-adds the direct row, movie DisplaySlot + direct game row can mix again.

LRS 1.5.30

Clean lower rating row ownership fix for AF3 XML contexts.
- fixes LRS_Info_Meta_Ratings caller visible so DisplayActive can show game rows.
- formats DisplaySlot labels as final UI labels: RT/Popcorn percent, awards xN, Ends at HH:MM.
- uses DisplaySlot row for Home/Hub keep-last and MyPrograms/MyVideoNav strict-current.
- keeps Steam Library direct lower row disabled; Steam Library provides RatingSlot bridge only.

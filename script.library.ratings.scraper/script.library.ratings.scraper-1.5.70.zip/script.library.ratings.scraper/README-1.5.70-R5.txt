Library Ratings Scraper 1.5.70

- Loads external_ratings into a service-scoped RAM index at startup.
- External records are indexed by item key, IMDb ID, TMDb ID and title/year.
- Neighbor prefetch now resolves cached non-library items without reopening SQLite.
- Newly saved external rows are inserted into RAM immediately.
- Definitively blank episode TMDb values are closed as N/A.
- Non-movie empty Rotten Tomatoes status columns are normalized to N/A.

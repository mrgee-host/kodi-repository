LRS 1.5.31 - AF3 row polish

Base: 1.5.30 AF3 row ownership.

Fixes:
- Ends at is allowed only for movie/episode/player/videoosd contexts.
  TV show/season/game/set/collection/folder do not get Ends at.
- Movie sets / collections / folder-like items clear DisplayActive immediately,
  so the previous movie row does not flash half-visible on collection pages.
- AF3 XML DisplaySlot objects now include an immediate set/collection guard.
- Oscar Best Picture remains the same count label as Oscar wins (x1/x3/etc.)
  and only swaps the icon to oscars_bp.png.

Kept:
- Home/Hub keep-last DisplaySlot.
- MyPrograms/MyVideoNav strict-current DisplaySlot.
- Steam Library bridge-only lower row model.
- KPM shared-icons path.

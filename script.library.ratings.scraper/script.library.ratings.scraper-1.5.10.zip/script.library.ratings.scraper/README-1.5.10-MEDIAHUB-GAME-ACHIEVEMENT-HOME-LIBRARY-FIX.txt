script.library.ratings.scraper 1.5.10 - MediaHub game achievement home/library fix

Problem fixed:
- v1.5.9 prevented duplicate Home/Hub rows by publishing game ratings only to LibraryRatings.Screensaver.*.
- That also meant the Achievement rating was only available in screensaver, while Home/Hub/library kept showing only MediaHub native Steam/Metacritic.

Patch behavior:
- Game items still bypass all movie/TV scrapers and cache lookup.
- Screensaver receives the full MediaHub game RatingSlot1..6 payload.
- ListItem receives only one compact Achievement slot so Home/Hub/library can show Achievement without repeating Steam and Metacritic.
- Player and VideoPlayer game namespaces are cleared to avoid stale movie/TV values.
- Movie, TV show, season, and episode flow is unchanged.

Changed files:
- addon.xml
- resources/lib/core.py
- service.py

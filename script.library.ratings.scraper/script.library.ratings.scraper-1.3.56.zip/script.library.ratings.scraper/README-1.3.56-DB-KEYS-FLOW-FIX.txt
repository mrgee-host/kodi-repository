Library Ratings Scraper 1.3.56

Base: 1.3.55.

Fixes:
- ratings table schema cleaned and reordered:
  item_key, title, imdb, tmdb, rottentomatoes, rottentomatoes_image, rottentomatoes_user, rottentomatoes_userimage, metacritic, trakt, top250, media_type, showtitle, season, episode, year, series_status, series_status_date, oscar_wins, emmy_wins, imdb_id, tmdb_id, dbid, updated_at, timestamp
- Removed letterboxd/mdblist from the ratings table and from normal enabled rating families.
- Removed tvdb/show_tmdb from ratings table because they are not useful for searching/display; they remain in items internally.
- Metacritic is stored as 0-100 integer, not 0-10.
- updated_at now uses WIB readable format: YYYY-MM-DD HH:MM:SS WIB.
- Added MDBList API key 2 and OMDb API key 2 settings.
- MDBList/OMDb key rotation: if key 1 hits limit, key 2 is tried in the same run.
- Corrected MDBList-limit policy: if awards/status are OFF and MDBList keys are limited, stop instead of falling back to OMDb/TMDb.
- If awards or status is ON, OMDb/TMDb fallback remains available only for those requested features.

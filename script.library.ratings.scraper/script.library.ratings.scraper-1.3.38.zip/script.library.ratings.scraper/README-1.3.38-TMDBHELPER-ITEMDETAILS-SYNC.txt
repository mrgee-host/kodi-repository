Library Ratings Scraper 1.3.38

Adds TMDbHelper ItemDetails.db sync.

- New menu button: Sync cache to TMDbHelper ItemDetails.db
- Background scrape/top250 jobs also sync the cache to ItemDetails.db after saving/exporting.
- Expiry written to TMDbHelper DB is 10 years.
- Votes are not updated/scraped. Existing vote columns are left untouched.
- Ratings table receives IMDb/TMDb/RT/Metacritic/Trakt/Letterboxd/MDBList/Top250/Awards.
- movie.rating, tvshow.rating and episode.rating are updated from cached TMDb rating only.
- episode IMDb rating is written to the generic ratings table using the episode ItemDetails id (tv.<show_tmdb>.<season>.<episode>); the episode table itself is not altered because TMDbHelper will not read custom columns.
- LRS cache JSON is compacted on save.

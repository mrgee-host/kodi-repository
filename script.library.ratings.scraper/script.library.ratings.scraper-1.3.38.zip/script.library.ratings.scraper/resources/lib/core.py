# -*- coding: utf-8 -*-
from __future__ import annotations

import csv
import json
import os
import random
import re
import sqlite3
import time
from datetime import datetime
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import Request, urlopen

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
DATA_DIR = os.path.join(ADDON_PATH, "resources", "data")
CACHE_DB_FILE = os.path.join(PROFILE, "ratings-cache.db")
LEGACY_CACHE_FILE = os.path.join(PROFILE, "ratings-cache.json")
CACHE_FILE = CACHE_DB_FILE
REPORT_FILE = os.path.join(PROFILE, "ratings-report.csv")
SUMMARY_FILE = os.path.join(PROFILE, "last-run-summary.json")
NETWORK_TIMEOUT = 10
CACHE_VERSION = 6
IMDB_TOP250_URL = "https://www.imdb.com/chart/top/"
LEGACY_IMDB_TOP250_CACHE_FILE = os.path.join(PROFILE, "imdb-top250-cache.json")
IMDB_TOP250_CACHE_FILE = CACHE_DB_FILE
IMDB_TOP250_TV_DB_FILE = os.path.join(DATA_DIR, "imdb_top_tv_shows.db")
IMDB_TOP250_TV_FILE = IMDB_TOP250_TV_DB_FILE
BACKGROUND_REQUEST_FILE = os.path.join(PROFILE, "background-job-request.json")
BACKGROUND_CANCEL_FILE = os.path.join(PROFILE, "background-job-cancel.json")
BACKGROUND_STATE_FILE = os.path.join(PROFILE, "background-job-state.json")
BACKGROUND_FORCE_STOP_FILE = os.path.join(PROFILE, "background-job-force-stop.json")
SAMPLE_CHECK_LOG_FILE = os.path.join(PROFILE, "last-random-check-debug.txt")


def debug_enabled() -> bool:
    return ADDON.getSetting("debug_logging").lower() == "true"


def log(message: str, level: int = xbmc.LOGDEBUG) -> None:
    if level != xbmc.LOGDEBUG or debug_enabled():
        xbmc.log("[{0}] {1}".format(ADDON_ID, message), level)


class ProviderLimitReached(Exception):
    """Raised when a provider explicitly reports that the API limit is exhausted."""

    def __init__(self, provider: str, message: str, retry_after: Any = "") -> None:
        self.provider = provider
        self.message = str(message or "API limit reached")
        self.retry_after = str(retry_after or "")
        suffix = " Retry-After: {0}".format(self.retry_after) if self.retry_after else ""
        super().__init__("{0}: {1}{2}".format(provider, self.message, suffix))


def _limit_text(*values: Any) -> str:
    return " ".join(str(value or "") for value in values if value not in (None, "")).lower()


def is_provider_limit_payload(provider: str, payload: Any, headers: Optional[Dict[str, str]] = None) -> bool:
    if not isinstance(payload, dict):
        return False
    headers = headers or {}
    status = safe_int(payload.get("__http_status"))
    if status == 429:
        return True
    text = _limit_text(payload.get("error"), payload.get("Error"), payload.get("message"), payload.get("detail"), payload.get("__error"), payload.get("__body"), headers.get("x-ratelimit-remaining"))
    if provider.lower() == "mdblist":
        return "daily api limit exceeded" in text or "api limit exceeded" in text or "rate limit" in text or "too many requests" in text
    if provider.lower() == "omdb":
        return "request limit reached" in text or "daily request limit" in text or "api limit" in text or "too many requests" in text
    return "limit" in text and ("reached" in text or "exceeded" in text)


def provider_limit_message(provider: str, payload: Any) -> str:
    if not isinstance(payload, dict):
        return "API limit reached"
    for key in ("error", "Error", "message", "detail", "__error", "__body"):
        value = str(payload.get(key) or "").strip()
        if value:
            return value[:240]
    status = payload.get("__http_status")
    return "HTTP {0}".format(status) if status else "API limit reached"


def _public_params(params: Dict[str, Any]) -> Dict[str, Any]:
    """Return provider request params without exposing API keys."""
    public: Dict[str, Any] = {}
    for key, value in (params or {}).items():
        if str(key).lower() in ("apikey", "api_key", "key"):
            public[key] = "***"
        else:
            public[key] = value
    return public


def _compact_rating_sources(ratings: Any) -> List[str]:
    output: List[str] = []
    if not isinstance(ratings, list):
        return output
    for row in ratings:
        if not isinstance(row, dict):
            continue
        source = str(row.get("source") or row.get("Source") or "").strip()
        value = row.get("value") if "value" in row else row.get("Value")
        score = row.get("score") if "score" in row else ""
        if source:
            if value not in (None, ""):
                output.append("{0}={1}".format(source, value))
            elif score not in (None, ""):
                output.append("{0}={1}".format(source, score))
            else:
                output.append(source)
    return output


def safe_int(value: Any) -> Optional[int]:
    try:
        if value in (None, ""):
            return None
        return int(float(str(value).strip()))
    except (TypeError, ValueError):
        return None


def safe_float(value: Any) -> Optional[float]:
    try:
        if value in (None, "", "N/A"):
            return None
        match = re.search(r"-?\d+(?:[.,]\d+)?", str(value))
        return float(match.group(0).replace(",", ".")) if match else None
    except (TypeError, ValueError):
        return None


def bool_setting(name: str, default: bool = False) -> bool:
    try:
        value = ADDON.getSetting(name)
    except Exception:  # pylint: disable=broad-except
        return default
    return default if value == "" else value.lower() == "true"


def int_setting(name: str, default: int) -> int:
    try:
        value = ADDON.getSetting(name)
    except Exception:  # pylint: disable=broad-except
        return default
    return safe_int(value) or default


RATING_LOGICALS_BY_TYPE = {
    "movie": {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist", "top250"},
    "tvshow": {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist", "top250"},
    "episode": {"imdb", "tmdb"},
}

RATING_SOURCE_TO_LOGICAL = {
    # Canonical keys (v1.3.8 cache format)
    "imdb": "imdb",
    "tmdb": "tmdb",
    "rtcritic": "rt_critic",
    "rtaudience": "rt_audience",
    "metacritic": "metacritic",
    "trakt": "trakt",
    "letterboxd": "letterboxd",
    "mdblist": "mdblist",
    # Kodi / provider aliases observed in existing caches
    "internetmoviedatabase": "imdb",
    "themoviedb": "tmdb",
    "tomatoes": "rt_critic",
    "rottentomatoes": "rt_critic",
    "tomatometer": "rt_critic",
    "tomatometerallcritics": "rt_critic",
    "tomatometerallaudience": "rt_audience",
    "audience": "rt_audience",
    "rottentomatoesaudience": "rt_audience",
    "popcorn": "rt_audience",
    "metascore": "metacritic",
    "metacriticuser": "metacritic",
}

# One visible/cache key per rating family. Aliases such as tomatoes,
# rottentomatoes, popcorn, and rottentomatoesaudience are folded into these
# canonical keys so a single item cannot alternate between duplicate values.
RATING_LOGICAL_TO_CACHE_KEY = {
    "imdb": "imdb",
    "tmdb": "tmdb",
    "rt_critic": "rt_critic",
    "rt_audience": "rt_audience",
    "metacritic": "metacritic",
    "trakt": "trakt",
    "letterboxd": "letterboxd",
    "mdblist": "mdblist",
}

# Provider/source preference inside each rating family. The first available
# candidate wins and all aliases are discarded from the final cache row.
RATING_ALIAS_PRIORITY = {
    "imdb": ["imdb", "internetmoviedatabase"],
    "tmdb": ["tmdb", "themoviedb"],
    "rt_critic": ["tomatoes", "tomatometer", "tomatometerallcritics", "rottentomatoes", "rtcritic"],
    "rt_audience": ["popcorn", "audience", "rtaudience", "tomatometerallaudience", "rottentomatoesaudience"],
    "metacritic": ["metacritic", "metascore", "metacriticuser"],
    "trakt": ["trakt"],
    "letterboxd": ["letterboxd"],
    "mdblist": ["mdblist"],
}

# Provider preference per rating family. This prevents MDBList aggregator rows
# from replacing an original/source-specific row for the same displayed rating.
RATING_PROVIDER_PRIORITY = {
    "imdb": ["omdb", "kodi", "mdblist"],
    "tmdb": ["tmdb", "kodi", "mdblist"],
    "rt_critic": ["omdb", "mdblist", "kodi"],
    "rt_audience": ["mdblist", "kodi", "omdb"],
    "metacritic": ["omdb", "mdblist", "kodi"],
    "trakt": ["kodi", "mdblist"],
    "letterboxd": ["mdblist", "kodi"],
    "mdblist": ["mdblist"],
}

MDBLIST_LOGICALS = {"imdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist"}
OMDB_LOGICALS = {"imdb", "rt_critic", "metacritic"}
# MDBList is an aggregator provider. These are the rating families it can be
# used for when the corresponding checkbox is enabled. The separate
# `ratings_*_mdblist` checkbox controls only the visible MDBList score itself;
# it must not disable MDBList as a source for RT audience/popcorn, Trakt, etc.
MDBLIST_PROVIDER_LOGICALS = {"imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist"}
NO_RATING_PROVIDER = "unavailable"
NO_RATING_SOURCE = "no_rating"
NO_RATING_VALUE = "NO_RATING"



def media_setting_type(media_type: Any) -> str:
    value = str(media_type or "").strip().lower()
    if value in ("tv", "show", "series", "season"):
        return "tvshow"
    if value in ("movies",):
        return "movie"
    if value in ("episodes",):
        return "episode"
    return value


def rating_setting_id(media_type: Any, logical: str) -> str:
    return "ratings_{0}_{1}".format(media_setting_type(media_type), logical)


def rating_enabled(media_type: Any, logical: str, default: bool = True) -> bool:
    media_type = media_setting_type(media_type)
    if logical not in RATING_LOGICALS_BY_TYPE.get(media_type, set()):
        return False
    # Episode intentionally stays simple: only IMDb and TMDb are scraped/published.
    if media_type == "episode" and logical not in ("imdb", "tmdb"):
        return False
    # v1.3.30 simplified settings: one global checkbox per rating family.
    # Fall back to legacy per-media setting IDs so old user settings/cache still work.
    if logical == "top250":
        if media_type == "movie":
            value = ADDON.getSetting("rating_top250_movies")
            return default if value == "" else value.lower() == "true"
        if media_type == "tvshow":
            value = ADDON.getSetting("rating_top250_tvshows")
            return default if value == "" else value.lower() == "true"
        return False
    value = ADDON.getSetting("rating_{0}".format(logical))
    if value != "":
        return value.lower() == "true"
    return bool_setting(rating_setting_id(media_type, logical), default)


def any_rating_enabled(media_type: Any, logicals: Iterable[str]) -> bool:
    return any(rating_enabled(media_type, logical, True) for logical in logicals)


def clean_rating_source(source: Any) -> str:
    return re.sub(r"[^a-z0-9]", "", str(source or "").lower())


def logical_for_rating_source(source: Any) -> str:
    return RATING_SOURCE_TO_LOGICAL.get(clean_rating_source(source), "")


def _rating_alias_rank(logical: str, source: Any) -> int:
    clean = clean_rating_source(source)
    priority = RATING_ALIAS_PRIORITY.get(logical, [])
    return priority.index(clean) if clean in priority else len(priority) + 100


def _provider_rank(logical: str, provider: Any) -> int:
    clean = clean_rating_source(provider)
    priority = RATING_PROVIDER_PRIORITY.get(logical, [])
    return priority.index(clean) if clean in priority else len(priority) + 100


def _candidate_score_for_dedupe(logical: str, alias: str, rating: Dict[str, Any]) -> Tuple[int, int, int, float, int]:
    """Lower tuple wins.

    Pick one stable provider/source for each logical rating. Provider priority
    comes before alias priority so e.g. TMDb direct/Kodi TMDb is not replaced by
    MDBList's aggregate TMDb alias. Votes are only a final tie breaker.
    """
    has_number = 0 if (safe_float(rating.get("score")) is not None or safe_float(rating.get("value")) is not None) else 1
    votes = safe_int(rating.get("votes")) or 0
    return (_provider_rank(logical, rating.get("provider")), _rating_alias_rank(logical, alias), has_number, -float(votes), 0)


def _canonical_rating_row(logical: str, alias: str, rating: Any) -> Dict[str, Any]:
    row = dict(rating) if isinstance(rating, dict) else normalized_rating(alias, rating, None, None, "")
    row.setdefault("provider", "")
    row["source"] = clean_rating_source(row.get("source") or alias)
    row["logical"] = logical
    row["cache_key"] = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
    return row


def is_no_rating_marker(rating: Any) -> bool:
    return isinstance(rating, dict) and bool(rating.get("no_rating"))


def no_rating_row(logical: str, reason: str = "provider_returned_no_value") -> Dict[str, Any]:
    cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
    return {
        "source": cache_key,
        "logical": logical,
        "cache_key": cache_key,
        "provider": NO_RATING_PROVIDER,
        "value": NO_RATING_VALUE,
        "score": "",
        "votes": "",
        "no_rating": True,
        "no_rating_reason": reason,
        "updated_at": now_iso(),
    }


def mark_unavailable_ratings(target: Dict[str, Any], media_type: Any, logicals: Iterable[str], reason: str = "provider_returned_no_value") -> None:
    if not bool_setting("mark_unavailable_ratings", True):
        return
    media_type = media_setting_type(media_type)
    for logical in logicals:
        if not rating_enabled(media_type, logical, True):
            continue
        cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
        row = target.get(cache_key)
        if isinstance(row, dict) and (safe_float(row.get("score")) is not None or safe_float(row.get("value")) is not None or is_no_rating_marker(row)):
            continue
        target[cache_key] = no_rating_row(logical, reason)


def _attempt_has_temp_failure(attempt: Any) -> bool:
    if not isinstance(attempt, dict):
        return False
    status = safe_int(attempt.get("http_status"))
    error = str(attempt.get("error") or "").lower()
    if status in (401, 403, 408, 409, 425, 429) or (status is not None and status >= 500):
        return True
    temporary_words = ("limit", "quota", "unauthorized", "forbidden", "timeout", "timed out", "temporar", "connection", "ssl", "429", "401", "403")
    return any(word in error for word in temporary_words)


def mdblist_lookup_cacheable(meta: Dict[str, Any]) -> bool:
    attempts = (meta or {}).get("attempts") or []
    if not attempts:
        return False
    return not any(_attempt_has_temp_failure(attempt) for attempt in attempts)


def omdb_lookup_cacheable(meta: Dict[str, Any]) -> bool:
    attempts = (meta or {}).get("attempts") or []
    if not attempts:
        return False
    return not any(_attempt_has_temp_failure(attempt) for attempt in attempts)


def filter_ratings_for_item(media_type: Any, ratings: Dict[str, Any]) -> Dict[str, Any]:
    """Apply checkboxes and fold duplicate aliases into one canonical value.

    v1.3.8 cache rule: one key per displayed rating family only:
    imdb, tmdb, rt_critic, rt_audience, metacritic, trakt, letterboxd, mdblist.
    Old aliases from Kodi/MDBList/OMDb are read for compatibility, then dropped.
    """
    media_type = media_setting_type(media_type)
    if not isinstance(ratings, dict) or media_type not in RATING_LOGICALS_BY_TYPE:
        return {}

    grouped: Dict[str, List[Tuple[str, Dict[str, Any]]]] = {}
    for alias, rating in ratings.items():
        logical = logical_for_rating_source(alias)
        if not logical:
            # Do not keep unknown rating names in the final cache/publish map;
            # the user asked for no duplicate/alias rows.
            continue
        if not rating_enabled(media_type, logical, True):
            continue
        grouped.setdefault(logical, []).append((str(alias), _canonical_rating_row(logical, str(alias), rating)))

    output: Dict[str, Any] = {}
    for logical, rows in grouped.items():
        if not rows:
            continue
        rows.sort(key=lambda pair: _candidate_score_for_dedupe(logical, pair[0], pair[1]))
        cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
        output[cache_key] = rows[0][1]
    return output



def now_iso() -> str:
    return datetime.utcnow().replace(microsecond=0).isoformat() + "Z"


def json_rpc(method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    payload = {"jsonrpc": "2.0", "id": 1, "method": method, "params": params or {}}
    try:
        response = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
        if response.get("error"):
            log("JSON-RPC error {0}: {1}".format(method, response["error"]), xbmc.LOGWARNING)
            return {}
        result = response.get("result") or {}
        return result if isinstance(result, dict) else {}
    except Exception as exc:  # pylint: disable=broad-except
        log("JSON-RPC failure {0}: {1}".format(method, exc), xbmc.LOGWARNING)
        return {}


def _sqlite_connect() -> sqlite3.Connection:
    os.makedirs(PROFILE, exist_ok=True)
    conn = sqlite3.connect(CACHE_DB_FILE, timeout=30)
    conn.row_factory = sqlite3.Row
    try:
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
    except sqlite3.Error:
        pass
    conn.execute("CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT)")
    conn.execute("""
        CREATE TABLE IF NOT EXISTS items (
            item_key TEXT PRIMARY KEY,
            media_type TEXT,
            dbid INTEGER,
            title TEXT,
            showtitle TEXT,
            imdb TEXT,
            tmdb TEXT,
            updated_at TEXT,
            timestamp INTEGER,
            payload TEXT NOT NULL
        )
    """)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_lrs_items_type_dbid ON items(media_type, dbid)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_lrs_items_imdb ON items(imdb)")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_lrs_items_tmdb ON items(tmdb)")
    conn.execute("CREATE TABLE IF NOT EXISTS top250_movie (imdb TEXT PRIMARY KEY, rank INTEGER NOT NULL, updated_at TEXT)")
    return conn


def _db_get_meta(conn: sqlite3.Connection, key: str, default: str = "") -> str:
    row = conn.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone()
    return str(row["value"]) if row and row["value"] is not None else default


def _db_set_meta(conn: sqlite3.Connection, key: str, value: Any) -> None:
    conn.execute("INSERT OR REPLACE INTO metadata(key, value) VALUES(?, ?)", (key, str(value if value is not None else "")))


def _cache_entry_indexes(item_key: str, entry: Dict[str, Any]) -> Tuple[str, int, str, str, str, str, str, int]:
    ids = entry.get("ids") or {}
    dbid = safe_int(entry.get("dbid"))
    timestamp = safe_int(entry.get("timestamp")) or 0
    return (
        str(entry.get("type") or ""),
        int(dbid or 0),
        str(entry.get("title") or ""),
        str(entry.get("showtitle") or ""),
        str(ids.get("imdb") or entry.get("imdb") or ""),
        str(ids.get("tmdb") or entry.get("tmdb") or ""),
        str(entry.get("updated_at") or ""),
        int(timestamp),
    )


def _load_legacy_json_cache() -> Dict[str, Any]:
    try:
        with open(LEGACY_CACHE_FILE, "r", encoding="utf-8") as handle:
            parsed = json.load(handle)
        if isinstance(parsed, dict) and isinstance(parsed.get("items"), dict):
            return parsed
    except (OSError, ValueError):
        pass
    return {}


def load_cache() -> Dict[str, Any]:
    try:
        conn = _sqlite_connect()
        try:
            rows = conn.execute("SELECT item_key, payload FROM items ORDER BY media_type, dbid, item_key").fetchall()
            if not rows and os.path.exists(LEGACY_CACHE_FILE):
                legacy = _load_legacy_json_cache()
                if legacy.get("items"):
                    save_cache(legacy)
                    return legacy
            items: Dict[str, Any] = {}
            for row in rows:
                try:
                    payload = json.loads(row["payload"])
                except (TypeError, ValueError):
                    continue
                if isinstance(payload, dict):
                    items[str(row["item_key"])] = payload
            return {
                "version": safe_int(_db_get_meta(conn, "version")) or CACHE_VERSION,
                "updated_at": _db_get_meta(conn, "updated_at"),
                "backend": "sqlite",
                "items": items,
            }
        finally:
            conn.close()
    except sqlite3.Error as exc:
        log("SQLite cache load failed, falling back to legacy JSON: {0}".format(exc), xbmc.LOGWARNING)
        legacy = _load_legacy_json_cache()
        return legacy if legacy.get("items") else {"version": CACHE_VERSION, "updated_at": "", "backend": "sqlite", "items": {}}


def _atomic_write_json(path: str, payload: Dict[str, Any]) -> None:
    # Kept for small job-state/summary files only. Ratings cache is SQLite.
    os.makedirs(os.path.dirname(path) or PROFILE, exist_ok=True)
    last_error = None
    for attempt in range(12):
        temp = "{0}.tmp.{1}.{2}".format(path, os.getpid(), int(time.time() * 1000))
        try:
            with open(temp, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
                handle.flush()
                try:
                    os.fsync(handle.fileno())
                except OSError:
                    pass
            os.replace(temp, path)
            return
        except OSError as exc:
            last_error = exc
            try:
                if os.path.exists(temp):
                    os.remove(temp)
            except OSError:
                pass
            time.sleep(0.20 + (attempt * 0.05))
    raise last_error or OSError("Failed to write {0}".format(path))


def save_cache(cache: Dict[str, Any]) -> None:
    cache["version"] = CACHE_VERSION
    cache["updated_at"] = now_iso()
    cache["backend"] = "sqlite"
    items = cache.get("items") or {}
    conn = _sqlite_connect()
    try:
        conn.execute("BEGIN")
        conn.execute("DELETE FROM items")
        for item_key, entry in items.items():
            if not isinstance(entry, dict):
                continue
            media_type, dbid, title, showtitle, imdb, tmdb, updated_at, timestamp = _cache_entry_indexes(str(item_key), entry)
            conn.execute(
                """
                INSERT OR REPLACE INTO items(item_key, media_type, dbid, title, showtitle, imdb, tmdb, updated_at, timestamp, payload)
                VALUES(?,?,?,?,?,?,?,?,?,?)
                """,
                (str(item_key), media_type, dbid, title, showtitle, imdb, tmdb, updated_at, timestamp, json.dumps(entry, ensure_ascii=False, sort_keys=True)),
            )
        _db_set_meta(conn, "version", CACHE_VERSION)
        _db_set_meta(conn, "updated_at", cache.get("updated_at") or now_iso())
        _db_set_meta(conn, "backend", "sqlite")
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def save_summary(summary: Dict[str, Any]) -> None:
    os.makedirs(PROFILE, exist_ok=True)
    with open(SUMMARY_FILE, "w", encoding="utf-8") as handle:
        json.dump(summary, handle, ensure_ascii=False, indent=2, sort_keys=True)


def _atomic_json(path: str, payload: Dict[str, Any]) -> None:
    _atomic_write_json(path, payload)


def _load_json(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        return payload if isinstance(payload, dict) else {}
    except (OSError, ValueError):
        return {}


def clear_background_control_flags() -> None:
    """Remove stale cancel/force-stop flags before starting a new job.

    If the user used Force Stop previously, Kodi can leave the cancel/force
    marker files in addon_data until the service consumes them. Starting a new
    scrape while those files still exist makes the new job cancel immediately.
    """
    for path in (BACKGROUND_CANCEL_FILE, BACKGROUND_FORCE_STOP_FILE):
        try:
            if os.path.exists(path):
                os.remove(path)
        except OSError:
            pass


def queue_background_job(action: str, force: bool = False) -> None:
    clear_background_control_flags()
    payload = {"action": action, "force": bool(force), "requested_at": now_iso(), "timestamp": int(time.time())}
    _atomic_json(BACKGROUND_REQUEST_FILE, payload)
    _atomic_json(BACKGROUND_STATE_FILE, {"status": "queued", "action": action, "force": bool(force), "requested_at": payload["requested_at"], "percent": 0, "processed": 0, "total": 0})


def request_background_cancel() -> None:
    _atomic_json(BACKGROUND_CANCEL_FILE, {"cancel": True, "requested_at": now_iso(), "timestamp": int(time.time())})


def request_background_force_stop() -> None:
    """Request an immediate hard stop from the service loop.

    Normal cancel lets the service finish the current item and save a clean
    partial cache/report. Force stop is for stuck or unwanted long runs: it
    clears pending request files and tells the service to drop the running job
    as soon as the current HTTP/JSON-RPC call returns.
    """
    try:
        if os.path.exists(BACKGROUND_REQUEST_FILE):
            os.remove(BACKGROUND_REQUEST_FILE)
    except OSError:
        pass
    payload = {"force_stop": True, "requested_at": now_iso(), "timestamp": int(time.time())}
    _atomic_json(BACKGROUND_FORCE_STOP_FILE, payload)
    _atomic_json(BACKGROUND_CANCEL_FILE, {"cancel": True, "force_stop": True, "requested_at": payload["requested_at"], "timestamp": payload["timestamp"]})
    _atomic_json(BACKGROUND_STATE_FILE, {"status": "force_stop_requested", "action": "force_stop", "requested_at": payload["requested_at"], "percent": 0, "processed": 0, "total": 0, "current": "Force stop diminta"})


def background_job_state() -> Dict[str, Any]:
    return _load_json(BACKGROUND_STATE_FILE)


def consume_background_request() -> Dict[str, Any]:
    payload = _load_json(BACKGROUND_REQUEST_FILE)
    if payload:
        try:
            os.remove(BACKGROUND_REQUEST_FILE)
        except OSError:
            pass
    return payload


def consume_background_cancel() -> bool:
    payload = _load_json(BACKGROUND_CANCEL_FILE)
    if payload:
        try:
            os.remove(BACKGROUND_CANCEL_FILE)
        except OSError:
            pass
    return bool(payload.get("cancel"))


def consume_background_force_stop() -> bool:
    payload = _load_json(BACKGROUND_FORCE_STOP_FILE)
    if payload:
        try:
            os.remove(BACKGROUND_FORCE_STOP_FILE)
        except OSError:
            pass
    return bool(payload.get("force_stop"))


def save_background_state(state: Dict[str, Any]) -> None:
    _atomic_json(BACKGROUND_STATE_FILE, state)


def item_key(item: Dict[str, Any]) -> str:
    return "{0}|{1}".format(item.get("type", "unknown"), item.get("dbid", ""))


def fresh(entry: Dict[str, Any]) -> bool:
    stamp = safe_float(entry.get("timestamp")) or 0
    return stamp > 0 and (time.time() - stamp) < max(1, int_setting("cache_days", 14)) * 86400


def get_setting_from(addon: xbmcaddon.Addon, candidates: Iterable[str]) -> str:
    for setting_id in candidates:
        try:
            value = addon.getSetting(setting_id)
        except Exception:  # pylint: disable=broad-except
            value = ""
        if value:
            return value.strip()
    return ""


def api_keys() -> Dict[str, str]:
    def _local_key(setting_id: str) -> str:
        try:
            return ADDON.getSetting(setting_id).strip()
        except Exception:  # pylint: disable=broad-except
            return ""
    keys = {
        "mdblist": _local_key("mdblist_apikey"),
        "tmdb": _local_key("tmdb_apikey"),
        "omdb": _local_key("omdb_apikey"),
    }
    if not bool_setting("try_tmdbhelper_keys", True):
        return keys
    try:
        helper = xbmcaddon.Addon("plugin.video.themoviedb.helper")
    except Exception:  # pylint: disable=broad-except
        return keys
    if not keys["mdblist"]:
        keys["mdblist"] = get_setting_from(helper, ("mdblist_apikey", "mdblist_api_key", "mdblist_key"))
    if not keys["tmdb"]:
        keys["tmdb"] = get_setting_from(helper, ("tmdb_apikey", "tmdb_api_key", "tmdb_key", "tmdb_api"))
    if not keys["omdb"]:
        keys["omdb"] = get_setting_from(helper, ("omdb_apikey", "omdb_api_key", "omdb_key"))
    return keys


def http_json(url: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    """Fetch JSON and preserve provider/network errors for debug output.

    Older builds returned an empty dict on HTTP/network/JSON failures. That made
    OMDb debug output look like `Response=True` with no Title/Ratings, and
    MDBList look like `ratings_count=0`, which is misleading. Return a small
    error payload instead so callers can show the real failure.
    """
    request = Request(url, headers={"User-Agent": "Kodi-Library-Ratings-Scraper/1.3.38", "Accept": "application/json"})
    try:
        with urlopen(request, timeout=NETWORK_TIMEOUT) as response:  # nosec B310 fixed HTTPS hosts only
            headers = {k.lower(): v for k, v in response.headers.items()}
            status = getattr(response, "status", None) or getattr(response, "code", None) or 200
            raw = response.read().decode("utf-8", "replace")
        parsed = json.loads(raw)
        if isinstance(parsed, dict):
            if status and "__http_status" not in parsed:
                parsed["__http_status"] = status
            if raw and "__raw_len" not in parsed:
                parsed["__raw_len"] = len(raw)
            return parsed, headers
        return {"Response": "False", "__error": "JSON root is {0}".format(type(parsed).__name__), "__http_status": status, "__raw_len": len(raw)}, headers
    except HTTPError as exc:
        retry = exc.headers.get("Retry-After", "") if exc.headers else ""
        body = ""
        try:
            body = exc.read().decode("utf-8", "replace")[:500]
        except Exception:  # pylint: disable=broad-except
            body = ""
        log("HTTP {0} for {1}; retry-after={2}".format(exc.code, url.split("?")[0], retry), xbmc.LOGWARNING)
        return {"Response": "False", "__error": "HTTP {0}".format(exc.code), "__http_status": exc.code, "__retry_after": retry, "__body": body}, {k.lower(): v for k, v in exc.headers.items()} if exc.headers else {}
    except (URLError, OSError, ValueError, TimeoutError) as exc:
        log("Provider request failed: {0}".format(exc), xbmc.LOGWARNING)
        return {"Response": "False", "__error": str(exc)}, {}


def http_text(url: str) -> str:
    request = Request(url, headers={
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Kodi-Library-Ratings-Scraper/1.3.38",
        "Accept": "text/html,application/xhtml+xml,application/json;q=0.9,*/*;q=0.8",
        "Accept-Language": "en-US,en;q=0.9",
    })
    try:
        with urlopen(request, timeout=NETWORK_TIMEOUT) as response:  # nosec B310 fixed HTTPS host only
            return response.read().decode("utf-8", "replace")
    except HTTPError as exc:
        log("HTTP {0} for IMDb Top 250 chart".format(exc.code), xbmc.LOGWARNING)
    except (URLError, OSError, TimeoutError) as exc:
        log("IMDb Top 250 chart request failed: {0}".format(exc), xbmc.LOGWARNING)
    return ""


def _load_top250_cache() -> Dict[str, Any]:
    try:
        conn = _sqlite_connect()
        try:
            ranks = {str(row["imdb"]): int(row["rank"]) for row in conn.execute("SELECT imdb, rank FROM top250_movie ORDER BY rank")}
            timestamp = safe_int(_db_get_meta(conn, "top250_movie_timestamp")) or 0
            return {"timestamp": timestamp, "updated_at": _db_get_meta(conn, "top250_movie_updated_at"), "ranks": ranks}
        finally:
            conn.close()
    except sqlite3.Error as exc:
        log("SQLite Top250 movie cache load failed: {0}".format(exc), xbmc.LOGWARNING)
    try:
        with open(LEGACY_IMDB_TOP250_CACHE_FILE, "r", encoding="utf-8") as handle:
            parsed = json.load(handle)
        return parsed if isinstance(parsed, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_top250_cache(ranks: Dict[str, int]) -> None:
    conn = _sqlite_connect()
    try:
        conn.execute("BEGIN")
        conn.execute("DELETE FROM top250_movie")
        for imdb, rank in sorted((ranks or {}).items(), key=lambda pair: int(pair[1] or 0)):
            if re.fullmatch(r"tt\d+", str(imdb or "").lower()) and safe_int(rank):
                conn.execute("INSERT OR REPLACE INTO top250_movie(imdb, rank, updated_at) VALUES(?,?,?)", (str(imdb).lower(), int(rank), now_iso()))
        _db_set_meta(conn, "top250_movie_timestamp", int(time.time()))
        _db_set_meta(conn, "top250_movie_updated_at", now_iso())
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def _walk_top250_json(node: Any, ranks: Dict[str, int]) -> None:
    if isinstance(node, dict):
        imdb_id = ""
        for key in ("id", "titleId", "const", "tconst"):
            value = node.get(key)
            if isinstance(value, str) and re.fullmatch(r"tt\d+", value):
                imdb_id = value.lower()
                break
        rank = None
        for key in ("rank", "currentRank", "position"):
            value = safe_int(node.get(key))
            if value is not None and 1 <= value <= 250:
                rank = value
                break
        if imdb_id and rank is not None:
            ranks.setdefault(imdb_id, rank)
        for value in node.values():
            _walk_top250_json(value, ranks)
    elif isinstance(node, list):
        for value in node:
            _walk_top250_json(value, ranks)


def _parse_imdb_top250(html: str) -> Dict[str, int]:
    ranks: Dict[str, int] = {}
    for raw in re.findall(r'<script[^>]*type=["\\\']application/json["\\\'][^>]*>(.*?)</script>', html, flags=re.I | re.S):
        try:
            _walk_top250_json(json.loads(raw), ranks)
        except ValueError:
            continue
    if len(ranks) >= 200:
        return dict(sorted(ranks.items(), key=lambda pair: pair[1])[:250])
    ordered: List[str] = []
    seen = set()
    for imdb_id in re.findall(r'/title/(tt\d+)/', html, flags=re.I):
        imdb_id = imdb_id.lower()
        if imdb_id not in seen:
            seen.add(imdb_id)
            ordered.append(imdb_id)
    if len(ordered) >= 200:
        return {imdb_id: index for index, imdb_id in enumerate(ordered[:250], start=1)}
    return {}


def imdb_top250_ranks(force_refresh: bool = False) -> Dict[str, int]:
    cached = _load_top250_cache()
    cached_ranks = cached.get("ranks") or {}
    max_age_hours = 24
    stamp = safe_float(cached.get("timestamp")) or 0
    if not force_refresh and cached_ranks and time.time() - stamp < max_age_hours * 3600:
        return {str(key).lower(): int(value) for key, value in cached_ranks.items() if safe_int(value) is not None}
    parsed = _parse_imdb_top250(http_text(IMDB_TOP250_URL))
    if parsed:
        _save_top250_cache(parsed)
        return parsed
    return {str(key).lower(): int(value) for key, value in cached_ranks.items() if safe_int(value) is not None}


def imdb_top250_tv_ranks() -> Dict[str, int]:
    ranks: Dict[str, int] = {}
    try:
        conn = sqlite3.connect(IMDB_TOP250_TV_DB_FILE)
        try:
            for imdb, rank in conn.execute("SELECT imdb, rank FROM top250_tv ORDER BY rank"):
                imdb_id = str(imdb or "").strip().lower()
                if re.fullmatch(r"tt\d+", imdb_id):
                    ranks.setdefault(imdb_id, int(rank))
            return ranks
        finally:
            conn.close()
    except sqlite3.Error as exc:
        log("IMDb Top250 TV DB unavailable: {0} ({1})".format(IMDB_TOP250_TV_DB_FILE, exc), xbmc.LOGWARNING)
        return {}



def _entry_imdb_id(entry: Dict[str, Any]) -> str:
    ids = entry.get("ids") or {}
    imdb_id = str(ids.get("imdb") or entry.get("imdb") or "").strip().lower()
    return imdb_id if imdb_id.startswith("tt") else ""


def _set_entry_top250(entry: Dict[str, Any], media_type: str, rank: int) -> bool:
    rank = safe_int(rank) or 0
    if media_type == "movie":
        old = safe_int(entry.get("imdb_top250_movie_rank") or entry.get("imdb_top250_rank")) or 0
        entry["imdb_top250_movie_rank"] = rank
        entry["imdb_top250_rank"] = rank
        if "imdb_top250_tv_rank" in entry:
            entry["imdb_top250_tv_rank"] = 0
    elif media_type == "tvshow":
        old = safe_int(entry.get("imdb_top250_tv_rank") or entry.get("imdb_top250_rank")) or 0
        entry["imdb_top250_tv_rank"] = rank
        entry["imdb_top250_rank"] = rank
        if "imdb_top250_movie_rank" in entry:
            entry["imdb_top250_movie_rank"] = 0
    else:
        old = safe_int(entry.get("imdb_top250_rank")) or 0
        entry["imdb_top250_rank"] = rank
    entry["updated_at"] = now_iso()
    entry["timestamp"] = int(time.time())
    return rank != old


def sync_imdb_top250_to_library(force_chart_refresh: bool = False, progress: Any = None) -> Dict[str, int]:
    movie_enabled = rating_enabled("movie", "top250", True) and bool_setting("include_movies", True)
    tv_enabled = rating_enabled("tvshow", "top250", True) and bool_setting("include_tvshows", True)
    ratings_cache = load_cache()
    ratings_cache.setdefault("items", {})

    movie_ranks = imdb_top250_ranks(force_chart_refresh) if movie_enabled else {}
    tv_ranks = imdb_top250_tv_ranks() if tv_enabled else {}

    stats = {
        "movies": 0, "movie_matched": 0, "movie_updated": 0, "movie_missing_imdb": 0, "movie_chart_items": len(movie_ranks),
        "tvshows": 0, "tv_matched": 0, "tv_updated": 0, "tv_missing_imdb": 0, "tv_chart_items": len(tv_ranks),
        "updated": 0, "matched": 0,
    }

    if movie_enabled:
        movies = json_rpc("VideoLibrary.GetMovies", {"properties": ["title", "year", "imdbnumber", "uniqueid", "top250"]}).get("movies", []) or []
        stats["movies"] = len(movies)
        for movie in movies:
            if isinstance(movie, dict):
                _ensure_cache_entry(ratings_cache, "movie", movie.get("movieid"), movie)

        if movie_ranks:
            movie_entries = [entry for entry in (ratings_cache.get("items") or {}).values() if isinstance(entry, dict) and entry.get("type") == "movie"]
            for index, entry in enumerate(movie_entries, start=1):
                if progress is not None:
                    progress.update(int(index * 50 / max(1, len(movie_entries))), "Movies Top 250 [{0}/{1}] {2}".format(index, len(movie_entries), entry.get("title") or "Untitled"))
                    if progress.iscanceled():
                        break
                imdb_id = _entry_imdb_id(entry)
                if not imdb_id:
                    stats["movie_missing_imdb"] += 1
                    continue
                rank = safe_int(movie_ranks.get(imdb_id)) or 0
                if rank:
                    stats["movie_matched"] += 1
                if _set_entry_top250(entry, "movie", rank):
                    stats["movie_updated"] += 1

            # Kodi's built-in movie Top250 field is updated only when the online movie chart is available.
            for movie in movies:
                if not isinstance(movie, dict):
                    continue
                imdb_id = _movie_imdb_id(movie, ratings_cache)
                rank = safe_int(movie_ranks.get(imdb_id)) or 0
                old_rank = safe_int(movie.get("top250")) or 0
                if rank != old_rank and safe_int(movie.get("movieid")) is not None:
                    json_rpc("VideoLibrary.SetMovieDetails", {"movieid": int(movie["movieid"]), "top250": rank})

    if tv_enabled:
        shows = json_rpc("VideoLibrary.GetTVShows", {"properties": ["title", "year", "imdbnumber", "uniqueid"]}).get("tvshows", []) or []
        stats["tvshows"] = len(shows)
        for show in shows:
            if isinstance(show, dict):
                _ensure_cache_entry(ratings_cache, "tvshow", show.get("tvshowid"), show)

        if tv_ranks:
            tv_entries = [entry for entry in (ratings_cache.get("items") or {}).values() if isinstance(entry, dict) and entry.get("type") == "tvshow"]
            for index, entry in enumerate(tv_entries, start=1):
                if progress is not None:
                    progress.update(50 + int(index * 50 / max(1, len(tv_entries))), "TV Top 250 [{0}/{1}] {2}".format(index, len(tv_entries), entry.get("title") or "Untitled"))
                    if progress.iscanceled():
                        break
                imdb_id = _entry_imdb_id(entry)
                if not imdb_id:
                    stats["tv_missing_imdb"] += 1
                    continue
                rank = safe_int(tv_ranks.get(imdb_id)) or 0
                if rank:
                    stats["tv_matched"] += 1
                if _set_entry_top250(entry, "tvshow", rank):
                    stats["tv_updated"] += 1

    stats["updated"] = int(stats.get("movie_updated") or 0) + int(stats.get("tv_updated") or 0)
    stats["matched"] = int(stats.get("movie_matched") or 0) + int(stats.get("tv_matched") or 0)
    stats["total"] = int(stats.get("movies") or 0) + int(stats.get("tvshows") or 0)
    stats["processed"] = int(stats.get("total") or 0)
    save_cache(ratings_cache)
    log("IMDb Top250 sync: movies={0} tvshows={1} movie_chart={2} tv_chart={3} matched={4} updated={5} missing_imdb={6}".format(
        stats.get("movies"), stats.get("tvshows"), stats.get("movie_chart_items"), stats.get("tv_chart_items"), stats.get("matched"), stats.get("updated"), int(stats.get("movie_missing_imdb") or 0) + int(stats.get("tv_missing_imdb") or 0)
    ), xbmc.LOGINFO)
    return stats

def normalized_rating(source: str, value: Any = None, score: Any = None, votes: Any = None, provider: str = "") -> Dict[str, Any]:
    clean = re.sub(r"[^a-z0-9]", "", source.lower())
    number = safe_float(value)
    normalized = safe_float(score)

    # MDBList reports TMDb/Trakt in a 0-100 style value (for example 68),
    # while AF3/TMDbHelper rating fields expect decimal 0-10 (6.8). Store the
    # user-visible value as 0-10 but keep the normalized score as 0-100.
    if str(provider or "").lower() == "mdblist" and clean in ("tmdb", "trakt") and number is not None and number > 10:
        if normalized is None:
            normalized = number
        number = number / 10.0

    if normalized is None and number is not None:
        if clean in ("imdb", "tmdb", "trakt", "letterboxd", "metacriticuser") and number <= 10:
            normalized = number * 10
        else:
            normalized = number
    return {"source": clean, "value": number, "score": normalized, "votes": safe_int(votes), "provider": provider}


def merge_rating(target: Dict[str, Any], rating: Dict[str, Any], overwrite: bool = False) -> None:
    source = rating.get("source", "")
    if source and (overwrite or source not in target):
        target[source] = rating


def merge_provider_ratings(
    target: Dict[str, Any],
    found: Dict[str, Any],
    media_type: Any,
    allowed_logicals: Optional[Iterable[str]] = None,
    overwrite: bool = False,
) -> None:
    """Merge provider rows into canonical cache keys.

    v1.3.23 smart mode: missing-only decides whether an API needs to be hit.
    Once a provider has already been hit, all enabled fields returned by that
    same response may be updated because it costs no extra request.
    """
    media_type = media_setting_type(media_type)
    allowed = set(allowed_logicals or [])
    for rating in (found or {}).values():
        if not isinstance(rating, dict):
            continue
        logical = logical_for_rating_source(rating.get("source"))
        if not logical:
            continue
        if allowed and logical not in allowed:
            continue
        if not rating_enabled(media_type, logical, True):
            continue
        cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
        if cache_key and (overwrite or cache_key not in target):
            target[cache_key] = _canonical_rating_row(logical, rating.get("source") or cache_key, rating)


def local_ratings(row: Dict[str, Any]) -> Dict[str, Any]:
    output: Dict[str, Any] = {}
    ratings = row.get("ratings") or {}
    if not isinstance(ratings, dict):
        return output
    for source, payload in ratings.items():
        if isinstance(payload, dict):
            rating = normalized_rating(str(source), payload.get("rating"), None, payload.get("votes"), "kodi")
        else:
            rating = normalized_rating(str(source), payload, None, None, "kodi")
        merge_rating(output, rating)
    return output


def extract_ids(row: Dict[str, Any]) -> Dict[str, str]:
    ids: Dict[str, str] = {}
    unique = row.get("uniqueid") or {}
    if isinstance(unique, dict):
        for key, value in unique.items():
            if value not in (None, ""):
                ids[str(key).lower()] = str(value).strip()
    number = str(row.get("imdbnumber") or "").strip()
    if number:
        if number.lower().startswith("tt"):
            ids.setdefault("imdb", number)
        elif number.isdigit():
            # Common TMDb scraper output observed in Kodi libraries.
            ids.setdefault("tmdb", number)
    return ids



def _values_lower(*values: Any) -> str:
    parts: List[str] = []
    for value in values:
        if value in (None, ""):
            continue
        if isinstance(value, (list, tuple, set)):
            for item in value:
                if item not in (None, ""):
                    parts.append(str(item).lower())
        elif isinstance(value, dict):
            for item in value.values():
                if item not in (None, ""):
                    parts.append(str(item).lower())
        else:
            parts.append(str(value).lower())
    return " ".join(parts)


def is_animation_short_movie(row: Dict[str, Any]) -> bool:
    """Best-effort detection for the user's Animation Short Films bucket.

    Kodi does not expose a dedicated "short film" media type, so we detect it
    from genre/tag/set text first and only use runtime as a conservative backup.
    This keeps normal animated feature films from being skipped.
    """
    text = _values_lower(
        row.get("title"), row.get("genre"), row.get("tag"), row.get("set"), row.get("sorttitle"), row.get("file")
    )
    compact = re.sub(r"[^a-z0-9]+", " ", text).strip()
    if not compact:
        return False

    explicit_markers = (
        "animation short",
        "animated short",
        "animation shorts",
        "animated shorts",
        "animation short films",
        "animated short films",
        "short animation",
        "short animations",
    )
    if any(marker in compact for marker in explicit_markers):
        return True

    # Kodi tags/genres may be split into separate values such as
    # ["Animation", "Short"] or a set named "Short Films".
    has_animation = "animation" in compact or "animated" in compact
    has_short = re.search(r"\bshort\b|\bshorts\b", compact) is not None
    has_film_bucket = "short film" in compact or "short films" in compact
    if has_animation and (has_short or has_film_bucket):
        return True

    # Conservative fallback: only skip very short animated entries when the
    # movie has an Animation genre/tag. Runtime is usually seconds in Kodi.
    runtime = safe_int(row.get("runtime")) or 0
    if has_animation and runtime and runtime <= 2700 and has_short:
        return True
    return False

def is_indonesian_collection_movie(row: Dict[str, Any]) -> bool:
    """Detect the user's Indonesian Movies Collection bucket."""
    text = _values_lower(row.get("title"), row.get("genre"), row.get("tag"), row.get("set"), row.get("sorttitle"), row.get("file"))
    compact = re.sub(r"[^a-z0-9]+", " ", text).strip()
    if not compact:
        return False
    markers = (
        "indonesian movies collection",
        "indonesian movie collection",
        "indonesian movies",
        "indonesian movie",
        "indonesia movies collection",
        "indonesia movie collection",
        "film indonesia",
        "indonesian collection",
    )
    return any(marker in compact for marker in markers)


def parent_show_map() -> Dict[int, Dict[str, Any]]:
    props = ["title", "year", "imdbnumber", "uniqueid", "ratings"]
    shows = json_rpc("VideoLibrary.GetTVShows", {"properties": props}).get("tvshows", []) or []
    output: Dict[int, Dict[str, Any]] = {}
    for row in shows:
        if isinstance(row, dict) and safe_int(row.get("tvshowid")) is not None:
            output[int(row["tvshowid"])] = row
    return output


def library_items() -> List[Dict[str, Any]]:
    output: List[Dict[str, Any]] = []
    common = ["title", "year", "imdbnumber", "uniqueid", "ratings"]
    if bool_setting("include_movies", True):
        movie_props = common + ["top250", "genre", "tag", "set", "runtime", "sorttitle", "file"]
        movies = json_rpc("VideoLibrary.GetMovies", {"properties": movie_props}).get("movies", []) or []
        include_animation_shorts = bool_setting("include_animation_shorts", True)
        include_indonesian_collection = bool_setting("include_indonesian_collection", True)
        for row in movies:
            if not isinstance(row, dict):
                continue
            if not include_animation_shorts and is_animation_short_movie(row):
                continue
            if not include_indonesian_collection and is_indonesian_collection_movie(row):
                continue
            item = dict(row); item["type"] = "movie"; item["dbid"] = row.get("movieid")
            output.append(item)
    shows_map: Dict[int, Dict[str, Any]] = {}
    if bool_setting("include_tvshows", True) or bool_setting("include_episodes", True):
        shows_map = parent_show_map()
    if bool_setting("include_tvshows", True):
        for row in shows_map.values():
            item = dict(row); item["type"] = "tvshow"; item["dbid"] = row.get("tvshowid")
            output.append(item)
    if bool_setting("include_episodes", True):
        episode_props = ["title", "showtitle", "season", "episode", "tvshowid", "firstaired", "uniqueid", "ratings"]
        episodes = json_rpc("VideoLibrary.GetEpisodes", {"properties": episode_props}).get("episodes", []) or []
        for row in episodes:
            if not isinstance(row, dict):
                continue
            item = dict(row); item["type"] = "episode"; item["dbid"] = row.get("episodeid")
            parent = shows_map.get(safe_int(row.get("tvshowid")) or -1, {})
            item["showtitle"] = row.get("showtitle") or parent.get("title") or ""
            item["show_year"] = parent.get("year") or ""
            item["show_ids"] = extract_ids(parent)
            output.append(item)
    return output


def mdblist_lookup(ids: Dict[str, str], media_type: str, key: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    if not key or media_type not in ("movie", "show"):
        return {}, {}

    # v1.3.14: do not rely on one MDBList identity only. Movies often work
    # via IMDb, but TV shows can return a different/partial rating set depending
    # on whether the lookup uses TMDb or IMDb. Try all available stable IDs and
    # merge the first value for each source so series can get popcorn/tomatoes
    # when the primary IMDb show lookup only returns IMDb or nothing.
    candidates: List[Tuple[str, str]] = []

    def add_candidate(provider: str, media_id: Any) -> None:
        media_id = str(media_id or "").strip()
        if not media_id:
            return
        if provider == "imdb" and not media_id.lower().startswith("tt"):
            return
        pair = (provider, media_id)
        if pair not in candidates:
            candidates.append(pair)

    if media_type == "show":
        # TMDb IDs are type-scoped and usually more reliable for show-specific
        # ratings. Keep IMDb as fallback because many libraries only have tt ids.
        add_candidate("tmdb", ids.get("tmdb") or ids.get("show_tmdb"))
        add_candidate("imdb", ids.get("imdb"))
        add_candidate("trakt", ids.get("trakt"))
        add_candidate("mdblist", ids.get("mdblist"))
    else:
        add_candidate("imdb", ids.get("imdb"))
        add_candidate("tmdb", ids.get("tmdb"))
        add_candidate("trakt", ids.get("trakt"))
        add_candidate("mdblist", ids.get("mdblist"))

    output: Dict[str, Any] = {}
    meta: Dict[str, Any] = {"ids": {}, "rate_limit_remaining": "", "attempts": []}
    for provider, media_id in candidates:
        url = "https://api.mdblist.com/{0}/{1}/{2}?{3}".format(provider, media_type, quote(media_id, safe=""), urlencode({"apikey": key}))
        try:
            payload, headers = http_json(url)
        except Exception as exc:  # pylint: disable=broad-except
            meta["attempts"].append({"provider": provider, "id": media_id, "error": str(exc)})
            continue
        payload_error = ""
        if isinstance(payload, dict):
            payload_error = str(payload.get("error") or payload.get("message") or payload.get("detail") or payload.get("__error") or payload.get("__body") or "")
        rows = payload.get("ratings") if isinstance(payload, dict) else []
        if rows is None:
            rows = []
        count = len(rows) if isinstance(rows, list) else 0
        meta["attempts"].append({
            "provider": provider,
            "media_type": media_type,
            "id": media_id,
            "ratings": count,
            "sources": _compact_rating_sources(rows),
            "error": payload_error,
            "http_status": payload.get("__http_status") if isinstance(payload, dict) else "",
            "raw_len": payload.get("__raw_len") if isinstance(payload, dict) else "",
            "payload_keys": sorted([str(k) for k in payload.keys() if not str(k).startswith("__body")])[:20] if isinstance(payload, dict) else [],
        })
        if is_provider_limit_payload("mdblist", payload, headers):
            message = provider_limit_message("mdblist", payload)
            retry_after = payload.get("__retry_after") if isinstance(payload, dict) else ""
            meta["limited"] = True
            meta["limit_provider"] = "MDBList"
            meta["limit_message"] = message
            meta["retry_after"] = retry_after or ""
            log("MDBList API limit reached; falling back to OMDb for this run: {0}".format(message), xbmc.LOGWARNING)
            return output, meta
        if payload_error:
            continue
        useful_rows = False
        if isinstance(rows, list):
            for row in rows:
                if isinstance(row, dict):
                    rating = normalized_rating(str(row.get("source", "")), row.get("value"), row.get("score"), row.get("votes"), "mdblist")
                    if safe_float(rating.get("score")) is not None or safe_float(rating.get("value")) is not None:
                        useful_rows = True
                    # Preserve the first result for a source. Candidate order is
                    # deliberate; later IDs are only fallback when the primary
                    # lookup returns no useful numeric ratings at all.
                    merge_rating(output, rating, overwrite=False)
        for id_key, id_value in (payload.get("ids") or {}).items():
            if id_value not in (None, ""):
                meta["ids"].setdefault(str(id_key), str(id_value))
        if headers.get("x-ratelimit-remaining") not in (None, ""):
            meta["rate_limit_remaining"] = headers.get("x-ratelimit-remaining", "")
        # v1.3.23: normal movie/series rating scrape should cost one MDBList
        # request. Only try alternate IDs if the primary response is empty or
        # unusable.
        if useful_rows:
            break
    return output, meta


def tmdb_get(path: str, key: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    if not key:
        return {}
    query = {"api_key": key, "language": "en-US"}
    if params:
        query.update(params)
    payload, _ = http_json("https://api.themoviedb.org/3/{0}?{1}".format(path.lstrip("/"), urlencode(query)))
    return payload


def tmdb_search(item: Dict[str, Any], key: str, show: bool = False) -> str:
    title = str(item.get("showtitle") if show else item.get("title") or "").strip()
    if not title:
        return ""
    params: Dict[str, Any] = {"query": title}
    year = safe_int(item.get("show_year") if show else item.get("year"))
    if year:
        params["first_air_date_year" if show else "year"] = year
    payload = tmdb_get("search/tv" if show else "search/movie", key, params)
    rows = payload.get("results") or []
    if isinstance(rows, list) and rows:
        candidate = rows[0] if isinstance(rows[0], dict) else {}
        return str(candidate.get("id") or "")
    return ""


def tmdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    if not key:
        return {}, ids
    output: Dict[str, Any] = {}
    updated_ids = dict(ids)
    media_type = item.get("type")
    payload: Dict[str, Any] = {}
    if media_type == "movie":
        tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, False)
        if tmdb_id:
            updated_ids.setdefault("tmdb", str(tmdb_id))
            payload = tmdb_get("movie/{0}".format(tmdb_id), key)
    elif media_type == "tvshow":
        tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, True)
        if tmdb_id:
            updated_ids.setdefault("tmdb", str(tmdb_id))
            payload = tmdb_get("tv/{0}".format(tmdb_id), key)
    elif media_type == "episode":
        show_ids = dict(item.get("show_ids") or {})
        show_tmdb = show_ids.get("tmdb") or tmdb_search(item, key, True)
        season, episode = safe_int(item.get("season")), safe_int(item.get("episode"))
        if show_tmdb and season is not None and episode is not None:
            payload = tmdb_get("tv/{0}/season/{1}/episode/{2}".format(show_tmdb, season, episode), key)
            updated_ids.setdefault("show_tmdb", str(show_tmdb))
            if payload.get("id") not in (None, ""):
                updated_ids.setdefault("tmdb", str(payload["id"]))
    vote = payload.get("vote_average")
    if vote not in (None, ""):
        merge_rating(output, normalized_rating("tmdb", vote, safe_float(vote) * 10 if safe_float(vote) is not None else None, payload.get("vote_count"), "tmdb"), overwrite=True)
    return output, updated_ids



def _date_display(value: Any) -> str:
    text = str(value or "").strip()
    if not text:
        return ""
    match = re.match(r"^(\d{4})-(\d{2})-(\d{2})$", text)
    if match:
        return "{0}/{1}/{2}".format(match.group(3), match.group(2), match.group(1))
    return text


def _normalize_tmdb_status(value: Any) -> str:
    """Match the AF3/TMDbHelper-facing spelling without touching cached rows.

    TMDb returns `Canceled`. AF3/TMDbHelper commonly displays `Cancelled`.
    Only newly fetched empty status fields use this normalized value; existing
    cache fields are never rewritten by the missing-only status merge.
    """
    text = str(value or "").strip()
    if text.lower() == "canceled":
        return "Cancelled"
    return text


def _series_meta_needs_fill(series: Dict[str, Any]) -> bool:
    if not isinstance(series, dict):
        return True
    # Missing-only means any important blank metadata field can be filled, while
    # values that already exist are preserved exactly.
    for key in (
        "status",
        "status_date",
        "status_date_display",
        "first_air_date",
        "last_air_date",
        "next_episode_air_date",
        "last_episode_air_date",
    ):
        if not str(series.get(key) or "").strip():
            return True
    return False


def _merge_missing_series_meta(existing: Dict[str, Any], found: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(existing or {})
    for key, value in (found or {}).items():
        if value in (None, ""):
            continue
        if not str(merged.get(key) or "").strip():
            merged[key] = value
    return merged


def _award_count(pattern: str, text: Any) -> int:
    raw = str(text or "")
    match = re.search(pattern, raw, flags=re.I)
    return safe_int(match.group(1)) or 0 if match else 0


def parse_awards_wins(awards_text: Any) -> Dict[str, Any]:
    """Parse wins only from OMDb Awards text.

    TMDbHelper exposes Oscar_Wins and Emmy_Wins; nominations are deliberately
    ignored per user request. Keep this conservative: only explicit `Won N ...`
    phrases count, while `Nominated for N ...` remains blank/zero.
    """
    text = str(awards_text or "").strip()
    if not text or text.upper() == "N/A":
        return {}
    oscar_wins = _award_count(r"\bWon\s+(\d+)\s+Oscars?\b", text)
    emmy_wins = _award_count(r"\bWon\s+(\d+)\s+(?:Primetime\s+|Daytime\s+)?Emmys?\b", text)
    output: Dict[str, Any] = {"source": "omdb", "awards_text": text, "updated_at": now_iso()}
    if oscar_wins > 0:
        output["oscar_wins"] = oscar_wins
    if emmy_wins > 0:
        output["emmy_wins"] = emmy_wins
    return output


def _awards_needs_fill(awards: Dict[str, Any], media_type: Any) -> bool:
    if media_setting_type(media_type) not in ("movie", "tvshow"):
        return False
    if not bool_setting("scrape_awards_wins", True):
        return False
    if not isinstance(awards, dict):
        return True
    # Movies mostly need Oscar_Wins; TV shows mostly need Emmy_Wins. We still
    # allow either family on either media type, but do not force an OMDb lookup
    # forever after a source text is already cached.
    if str(awards.get("awards_text") or "").strip():
        return False
    return True


def _merge_missing_awards(existing: Dict[str, Any], found: Dict[str, Any]) -> Dict[str, Any]:
    merged = dict(existing or {})
    for key, value in (found or {}).items():
        if value in (None, ""):
            continue
        if key in ("oscar_wins", "emmy_wins"):
            if safe_int(merged.get(key)) is None:
                merged[key] = value
        elif not str(merged.get(key) or "").strip():
            merged[key] = value
    return merged


def _episode_air_date(payload: Any) -> str:
    if isinstance(payload, dict):
        return str(payload.get("air_date") or "").strip()
    return ""


def _series_status_date(payload: Dict[str, Any]) -> Tuple[str, str]:
    next_date = _episode_air_date(payload.get("next_episode_to_air"))
    last_date = _episode_air_date(payload.get("last_episode_to_air")) or str(payload.get("last_air_date") or "").strip()
    first_date = str(payload.get("first_air_date") or "").strip()
    status = str(payload.get("status") or "").strip()
    status_l = status.lower()
    if next_date and status_l in ("returning series", "in production", "planned", "pilot"):
        return next_date, "next_episode_air_date"
    if last_date and status_l in ("ended", "canceled", "cancelled"):
        return last_date, "last_episode_air_date"
    if last_date:
        return last_date, "last_episode_air_date"
    return first_date, "first_air_date"


def tmdb_tv_status_lookup(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str]]:
    """Fetch TV show status/date metadata from TMDb.

    Stored separately from ratings so there is still only one visible value per
    rating family. Used for AF3's existing TMDbHelper.ListItem.Status display.
    """
    if not key or item.get("type") != "tvshow":
        return {}, ids
    updated_ids = dict(ids)
    tmdb_id = updated_ids.get("tmdb") or tmdb_search(item, key, True)
    if not tmdb_id:
        return {}, ids
    updated_ids.setdefault("tmdb", str(tmdb_id))
    payload = tmdb_get("tv/{0}".format(tmdb_id), key)
    if not payload:
        return {}, updated_ids
    status = _normalize_tmdb_status(payload.get("status"))
    date_value, date_kind = _series_status_date(payload)
    meta = {
        "status": status,
        "first_air_date": str(payload.get("first_air_date") or "").strip(),
        "last_air_date": str(payload.get("last_air_date") or "").strip(),
        "next_episode_air_date": _episode_air_date(payload.get("next_episode_to_air")),
        "last_episode_air_date": _episode_air_date(payload.get("last_episode_to_air")),
        "status_date": date_value,
        "status_date_kind": date_kind,
        "status_date_display": _date_display(date_value),
        "source": "tmdb",
        "updated_at": now_iso(),
    }
    return {key: value for key, value in meta.items() if value not in (None, "")}, updated_ids



def _omdb_payload_has_data(payload: Any) -> bool:
    """Return True when an OMDb response contains actual title/rating data.

    Some Kodi/Python/SSL combinations can produce an empty response object, which
    older builds logged as Response=True because OMDb defaults were assumed. For
    episode checks we need to know whether the request really returned useful
    fields before deciding not to try the fallback URL scheme.
    """
    if not isinstance(payload, dict):
        return False
    if str(payload.get("Response", "True")).lower() == "false":
        return False
    if payload.get("Title") or payload.get("imdbID"):
        return True
    if payload.get("imdbRating") not in (None, "", "N/A"):
        return True
    if payload.get("Metascore") not in (None, "", "N/A"):
        return True
    ratings = payload.get("Ratings")
    return isinstance(ratings, list) and bool(ratings)

def omdb_lookup(item: Dict[str, Any], ids: Dict[str, str], key: str) -> Tuple[Dict[str, Any], Dict[str, str], Dict[str, Any]]:
    meta: Dict[str, Any] = {"attempts": []}
    if not key:
        return {}, ids, meta

    def parse_payload(payload: Dict[str, Any], output: Dict[str, Any], updated_ids: Dict[str, str]) -> None:
        if not payload or payload.get("__error") or str(payload.get("Response", "True")).lower() == "false":
            return
        if str(payload.get("imdbID") or "").lower().startswith("tt"):
            updated_ids.setdefault("imdb", str(payload["imdbID"]))
        if payload.get("imdbRating") not in (None, "", "N/A"):
            merge_rating(output, normalized_rating("imdb", payload.get("imdbRating"), None, payload.get("imdbVotes"), "omdb"), overwrite=False)
        if payload.get("Metascore") not in (None, "", "N/A"):
            merge_rating(output, normalized_rating("metacritic", payload.get("Metascore"), None, None, "omdb"), overwrite=False)
        for row in payload.get("Ratings") or []:
            if not isinstance(row, dict):
                continue
            source, value = str(row.get("Source", "")).lower(), row.get("Value")
            if "rotten tomatoes" in source:
                merge_rating(output, normalized_rating("tomatoes", value, None, None, "omdb"), overwrite=False)
            elif "internet movie database" in source:
                merge_rating(output, normalized_rating("imdb", value, None, None, "omdb"), overwrite=False)
            elif "metacritic" in source:
                merge_rating(output, normalized_rating("metacritic", value, None, None, "omdb"), overwrite=False)
        awards = parse_awards_wins(payload.get("Awards"))
        if awards:
            output["__awards"] = awards

    base: Dict[str, Any] = {"apikey": key, "r": "json", "tomatoes": "true"}
    attempts: List[Dict[str, Any]] = []
    imdb_id = ids.get("imdb", "")
    if imdb_id.lower().startswith("tt"):
        params = dict(base); params["i"] = imdb_id
        attempts.append(params)

    if item.get("type") == "episode":
        if item.get("showtitle") and safe_int(item.get("season")) is not None and safe_int(item.get("episode")) is not None:
            params = dict(base)
            params["t"] = str(item["showtitle"])
            params["Season"] = int(item["season"])
            params["Episode"] = int(item["episode"])
            attempts.append(params)
    elif not attempts:
        title = str(item.get("title") or "").strip()
        if not title:
            return {}, ids, meta
        params = dict(base)
        params["t"] = title
        year = safe_int(item.get("year"))
        if year:
            params["y"] = year
        params["type"] = "series" if item.get("type") == "tvshow" else "movie"
        attempts.append(params)

    output: Dict[str, Any] = {}
    updated_ids = dict(ids)
    seen_urls = set()
    for params in attempts:
        query = urlencode(params)
        # v1.3.18: OMDb episode lookups are retried through the plain HTTP
        # endpoint because the public OMDb examples and some Kodi/Python builds
        # are more reliable there than through HTTPS. This is a read-only API
        # request; the API key is still redacted in logs.
        url_candidates = [
            "http://www.omdbapi.com/?" + query,
            "https://www.omdbapi.com/?" + query,
        ]
        for url in url_candidates:
            if url in seen_urls:
                continue
            seen_urls.add(url)
            attempt_meta: Dict[str, Any] = {"params": _public_params(params), "scheme": url.split(":", 1)[0]}
            payload: Dict[str, Any] = {}
            try:
                payload, _ = http_json(url)
                response = str(payload.get("Response", "True")) if isinstance(payload, dict) else ""
                attempt_meta.update({
                    "response": response,
                    "http_status": payload.get("__http_status") if isinstance(payload, dict) else "",
                    "raw_len": payload.get("__raw_len") if isinstance(payload, dict) else "",
                    "title": payload.get("Title") if isinstance(payload, dict) else "",
                    "type": payload.get("Type") if isinstance(payload, dict) else "",
                    "year": payload.get("Year") if isinstance(payload, dict) else "",
                    "imdbID": payload.get("imdbID") if isinstance(payload, dict) else "",
                    "error": (payload.get("Error") or payload.get("__error") or payload.get("__body") or "") if isinstance(payload, dict) else "",
                    "ratings": _compact_rating_sources(payload.get("Ratings") if isinstance(payload, dict) else []),
                    "imdbRating": payload.get("imdbRating") if isinstance(payload, dict) else "",
                    "Metascore": payload.get("Metascore") if isinstance(payload, dict) else "",
                    "Awards": payload.get("Awards") if isinstance(payload, dict) else "",
                })
                if is_provider_limit_payload("omdb", payload):
                    message = provider_limit_message("omdb", payload)
                    log("OMDb API limit reached; stopping scrape: {0}".format(message), xbmc.LOGWARNING)
                    meta["attempts"].append(attempt_meta)
                    raise ProviderLimitReached("OMDb", message, payload.get("__retry_after") if isinstance(payload, dict) else "")
                parse_payload(payload, output, updated_ids)
                # If an explicit IMDb ID lookup succeeds, stop immediately.
                # Do not burn another OMDb request with title/season/episode.
                if params.get("i") and str(payload.get("Response", "True")).lower() == "true" and _omdb_payload_has_data(payload):
                    meta["attempts"].append(attempt_meta)
                    meta["found_sources"] = [str(k) for k in output.keys()]
                    return output, updated_ids, compact_provider_meta({"omdb": meta}).get("omdb", meta)
            except ProviderLimitReached:
                raise
            except Exception as exc:  # pylint: disable=broad-except
                attempt_meta["error"] = str(exc)
            meta["attempts"].append(attempt_meta)
            # Stop trying the alternate scheme once the current response actually
            # contains OMDb data or an explicit provider error. Empty/network-like
            # responses fall through to the alternate scheme.
            if _omdb_payload_has_data(payload) or (isinstance(payload, dict) and str(payload.get("Response", "True")).lower() == "false" and payload.get("Error")):
                break
    meta["found_sources"] = [str(k) for k in output.keys()]
    return output, updated_ids, meta


def _omdb_attempt_via(attempt: Dict[str, Any]) -> str:
    params = attempt.get("params") or {}
    if params.get("i"):
        return "i={0}".format(params.get("i"))
    if params.get("t"):
        via = "t={0}".format(params.get("t"))
        if params.get("Season") not in (None, ""):
            via += " S{0}E{1}".format(params.get("Season"), params.get("Episode"))
        elif params.get("type"):
            via += " type={0}".format(params.get("type"))
        return via
    return str(params)


def compact_provider_meta(provider_meta: Dict[str, Any]) -> Dict[str, Any]:
    """Keep cache/debug metadata small.

    Ratings, ids, series status and awards are the real cache payload. Provider
    attempts are only for debugging, so keep a compact human-readable summary and
    drop noisy HTTP byte counts, payload keys, schemes, duplicate internals, etc.
    """
    if not isinstance(provider_meta, dict):
        return {}
    output: Dict[str, Any] = {}

    mdblist = provider_meta.get("mdblist") or {}
    if isinstance(mdblist, dict):
        row: Dict[str, Any] = {}
        if mdblist.get("limited"):
            row["limited"] = True
            if mdblist.get("limit_message"):
                row["limit_message"] = mdblist.get("limit_message")
        attempts: List[Dict[str, Any]] = []
        for attempt in mdblist.get("attempts") or []:
            if not isinstance(attempt, dict):
                continue
            compact_attempt: Dict[str, Any] = {
                "via": "{0}/{1}/{2}".format(attempt.get("provider") or "", attempt.get("media_type") or "", attempt.get("id") or "").strip("/"),
            }
            if attempt.get("ratings") not in (None, ""):
                compact_attempt["ratings"] = attempt.get("ratings")
            if attempt.get("sources"):
                compact_attempt["sources"] = attempt.get("sources")
            if attempt.get("error"):
                compact_attempt["error"] = attempt.get("error")
            status = safe_int(attempt.get("http_status"))
            if status and status != 200:
                compact_attempt["http_status"] = status
            attempts.append(compact_attempt)
        if attempts:
            row["attempts"] = attempts
        if row:
            output["mdblist"] = row

    omdb = provider_meta.get("omdb") or {}
    if isinstance(omdb, dict):
        row: Dict[str, Any] = {}
        attempts: List[Dict[str, Any]] = []
        for attempt in omdb.get("attempts") or []:
            if not isinstance(attempt, dict):
                continue
            compact_attempt: Dict[str, Any] = {"via": _omdb_attempt_via(attempt)}
            for key in ("response", "title", "imdbRating", "Metascore", "error"):
                value = attempt.get(key)
                if value not in (None, "", "N/A"):
                    compact_attempt[key] = value
            if attempt.get("ratings"):
                compact_attempt["ratings"] = attempt.get("ratings")
            status = safe_int(attempt.get("http_status"))
            if status and status != 200:
                compact_attempt["http_status"] = status
            attempts.append(compact_attempt)
        if attempts:
            row["attempts"] = attempts
        if omdb.get("found_sources"):
            row["found_sources"] = omdb.get("found_sources")
        if row:
            output["omdb"] = row
    return output


def _resolve_top250_rank_for_item(item: Dict[str, Any], ids: Dict[str, str], existing: Dict[str, Any]) -> int:
    media_type = media_setting_type(item.get("type"))
    if media_type == "movie":
        return safe_int(existing.get("imdb_top250_movie_rank") or existing.get("imdb_top250_rank")) or safe_int(item.get("top250")) or 0
    if media_type == "tvshow":
        old = safe_int(existing.get("imdb_top250_tv_rank") or existing.get("imdb_top250_rank")) or 0
        imdb_id = str((ids or {}).get("imdb") or "").lower()
        rank = safe_int(imdb_top250_tv_ranks().get(imdb_id)) or 0
        return rank or old
    return 0


def resolve_item(item: Dict[str, Any], keys: Dict[str, str], existing: Optional[Dict[str, Any]] = None, missing_only: bool = True, include_local: bool = True) -> Dict[str, Any]:
    media_type = media_setting_type(item.get("type"))
    existing = existing if isinstance(existing, dict) else {}

    # Missing-only decides whether we need to hit an API. Once an API is hit,
    # v1.3.23 uses all enabled values returned by that same response because it
    # costs no extra request.
    ratings = filter_ratings_for_item(media_type, existing.get("ratings") or {}) if missing_only and existing else {}
    ids = dict(existing.get("ids") or {}) if missing_only and existing else {}
    provider_meta: Dict[str, Any] = dict(existing.get("provider_meta") or {}) if missing_only and existing else {}
    series_meta: Dict[str, Any] = dict(existing.get("series") or {}) if missing_only and existing else {}
    awards_meta: Dict[str, Any] = dict(existing.get("awards") or {}) if missing_only and existing else {}

    if include_local:
        local = filter_ratings_for_item(media_type, local_ratings(item))
        for key, row in local.items():
            if key not in ratings:
                ratings[key] = row

    item_ids = extract_ids(item)
    for key, value in item_ids.items():
        if value not in (None, ""):
            ids.setdefault(str(key), str(value))

    errors: List[str] = []
    item_type = item.get("type")
    is_movie_or_show = item_type in ("movie", "tvshow")
    status_missing = item_type == "tvshow" and bool_setting("scrape_tv_status", True) and _series_meta_needs_fill(series_meta)
    awards_missing = _awards_needs_fill(awards_meta, item_type)

    def current_missing() -> set:
        return record_missing_logicals(media_type, {"ratings": ratings})

    checked_no_value_logicals: set = set()
    mdblist_final_for_ratings = False

    missing = current_missing()

    # TMDb is still needed for series status/date and sometimes to discover the
    # TMDb id when the library only has a title. For movie/series ratings, MDBList
    # is the primary aggregator and can also return TMDb rating.
    need_tmdb_id_for_mdblist = is_movie_or_show and bool(missing & MDBLIST_PROVIDER_LOGICALS) and not (ids.get("imdb") or ids.get("tmdb"))
    need_tmdb_episode_rating = item_type == "episode" and "tmdb" in missing
    need_tmdb_direct_movie_show = is_movie_or_show and "tmdb" in missing and not (bool_setting("use_mdblist", True) and keys.get("mdblist"))
    if bool_setting("use_tmdb", True) and keys.get("tmdb") and (need_tmdb_id_for_mdblist or need_tmdb_episode_rating or need_tmdb_direct_movie_show):
        try:
            found, ids = tmdb_lookup(item, ids, keys["tmdb"])
            # Episode TMDb is a dedicated TMDb API hit; direct movie/show TMDb is
            # only fallback when MDBList cannot be used. Do not rewrite existing
            # fields unless force refresh is active.
            merge_provider_ratings(ratings, found, media_type, allowed_logicals={"tmdb"}, overwrite=not missing_only)
            if need_tmdb_episode_rating or need_tmdb_direct_movie_show:
                checked_no_value_logicals.add("tmdb")
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("tmdb: {0}".format(exc))

    if bool_setting("use_tmdb", True) and keys.get("tmdb") and status_missing:
        try:
            found_series, ids = tmdb_tv_status_lookup(item, ids, keys["tmdb"])
            if found_series:
                # Status metadata remains strict missing-only: never overwrite
                # status/date fields the cache already has.
                series_meta = _merge_missing_series_meta(series_meta, found_series)
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("tmdb_status: {0}".format(exc))

    # Movie/series: MDBList first. One usable MDBList response can fill/update
    # IMDb, TMDb, RT critics, RT audience, Metacritic, Trakt, Letterboxd, MDBList.
    missing = current_missing()
    mdblist_needed = is_movie_or_show and bool(missing & MDBLIST_PROVIDER_LOGICALS)
    if mdblist_needed:
        if keys.get("__mdblist_limited"):
            errors.append("mdblist: skipped for this run after API limit; falling back to OMDb/TMDb")
        elif not bool_setting("use_mdblist", True):
            errors.append("mdblist: provider disabled")
        elif not keys.get("mdblist"):
            errors.append("mdblist: api key missing")
        else:
            try:
                mdblist_missing_before = set(missing & MDBLIST_PROVIDER_LOGICALS)
                found, meta = mdblist_lookup(ids, "movie" if item_type == "movie" else "show", keys["mdblist"])
                provider_meta["mdblist"] = meta
                if meta.get("limited"):
                    keys["__mdblist_limited"] = "true"
                    errors.append("mdblist: API limit reached; falling back to OMDb/TMDb for this run")
                else:
                    # Smart update: because we already spent this MDBList request to
                    # fill a missing enabled field, use every enabled rating family
                    # present in the same response, including fields that already had
                    # an older value.
                    merge_provider_ratings(ratings, found, media_type, allowed_logicals=MDBLIST_PROVIDER_LOGICALS, overwrite=True)
                    for key, value in (meta.get("ids") or {}).items():
                        if value not in (None, ""):
                            ids.setdefault(str(key), str(value))
                    if mdblist_lookup_cacheable(meta):
                        checked_no_value_logicals.update(mdblist_missing_before)
                        mdblist_final_for_ratings = True
            except ProviderLimitReached:
                # Kept for forward compatibility; MDBList limits are intentionally
                # non-fatal now so OMDb can be used as fallback.
                keys["__mdblist_limited"] = "true"
                errors.append("mdblist: API limit reached; falling back to OMDb/TMDb for this run")
            except Exception as exc:  # pylint: disable=broad-except
                errors.append("mdblist: {0}".format(exc))

    # Fallbacks after MDBList. For episodes, OMDb is the primary IMDb episode
    # provider. For movie/series it is only used when MDBList did not/could not
    # fill still-missing OMDb-compatible families.
    missing = current_missing()
    omdb_needed = bool(missing & OMDB_LOGICALS)
    if is_movie_or_show and mdblist_final_for_ratings:
        # MDBList is the authoritative movie/series rating aggregator in this add-on.
        # Once it replied normally, do not query OMDb just because some rating
        # families are absent there. OMDb is still allowed for awards.
        omdb_needed = False
    omdb_awards_needed = awards_missing and item_type in ("movie", "tvshow")
    if bool_setting("use_omdb", True) and keys.get("omdb") and (omdb_needed or omdb_awards_needed):
        try:
            omdb_missing_before = set(missing & OMDB_LOGICALS)
            found, ids, omdb_meta = omdb_lookup(item, ids, keys["omdb"])
            provider_meta["omdb"] = omdb_meta
            found_awards = found.pop("__awards", {}) if isinstance(found, dict) else {}
            if found_awards:
                awards_meta = _merge_missing_awards(awards_meta, found_awards)
            # One OMDb response can include IMDb, Metacritic and sometimes RT.
            # If OMDb was hit only to fill Awards, do not rewrite ratings from
            # MDBList/TMDb because that would be a different extra API source.
            if omdb_needed:
                merge_provider_ratings(ratings, found, media_type, allowed_logicals=OMDB_LOGICALS, overwrite=True)
                if omdb_lookup_cacheable(omdb_meta):
                    checked_no_value_logicals.update(omdb_missing_before)
        except ProviderLimitReached:
            raise
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("omdb: {0}".format(exc))

    # Final fallback for TMDb rating if MDBList did not provide it and direct
    # TMDb was not already attempted above.
    missing = current_missing()
    if bool_setting("use_tmdb", True) and keys.get("tmdb") and "tmdb" in missing and not mdblist_final_for_ratings and not need_tmdb_episode_rating and not need_tmdb_direct_movie_show:
        try:
            found, ids = tmdb_lookup(item, ids, keys["tmdb"])
            merge_provider_ratings(ratings, found, media_type, allowed_logicals={"tmdb"}, overwrite=False)
            checked_no_value_logicals.add("tmdb")
        except Exception as exc:  # pylint: disable=broad-except
            errors.append("tmdb_fallback: {0}".format(exc))

    remaining_missing = current_missing()
    if checked_no_value_logicals:
        mark_unavailable_ratings(ratings, media_type, remaining_missing & checked_no_value_logicals)

    return {
        "type": item.get("type"), "dbid": item.get("dbid"), "title": item.get("title") or "",
        "year": item.get("year") or "", "showtitle": item.get("showtitle") or "",
        "season": item.get("season") if item.get("type") == "episode" else None,
        "episode": item.get("episode") if item.get("type") == "episode" else None,
        "ids": ids, "ratings": filter_ratings_for_item(media_type, ratings), "provider_meta": compact_provider_meta(provider_meta),
        "series": series_meta, "awards": awards_meta,
        "imdb_top250_rank": _resolve_top250_rank_for_item(item, ids, existing) if rating_enabled(media_type, "top250", True) else 0,
        "errors": errors, "timestamp": int(time.time()), "updated_at": now_iso(),
    }

def _csv_imdb_id(value: Any) -> str:
    value = str(value or "").strip()
    return value if value.lower().startswith("tt") else ""

def _csv_tmdb_id(value: Any) -> str:
    value = str(value or "").strip()
    return value if value.isdigit() else ""

def csv_top250_rank(entry: Dict[str, Any]) -> Any:
    media_type = media_setting_type(entry.get("type"))
    if media_type == "movie":
        return safe_int(entry.get("imdb_top250_movie_rank") or entry.get("imdb_top250_rank")) or ""
    if media_type == "tvshow":
        return safe_int(entry.get("imdb_top250_tv_rank") or entry.get("imdb_top250_rank")) or ""
    return safe_int(entry.get("imdb_top250_rank")) or ""


def export_csv(cache: Dict[str, Any]) -> str:
    os.makedirs(PROFILE, exist_ok=True)
    entries = list((cache.get("items") or {}).values())
    canonical_entries = []
    for entry in entries:
        if not isinstance(entry, dict):
            continue
        row = dict(entry)
        row["ratings"] = filter_ratings_for_item(row.get("type"), row.get("ratings") or {})
        canonical_entries.append(row)

    # Keep ID columns and rating columns explicitly separate. Older reports used
    # duplicated headers such as `imdb` and `tmdb` for both IDs and ratings,
    # which made spreadsheet apps collapse/overwrite the second value.
    sources = sorted({source for entry in canonical_entries for source in (entry.get("ratings") or {}).keys()})
    fixed = [
        "type", "dbid", "title", "showtitle", "season", "episode", "year",
        "tmdb_id", "imdb_id", "imdb_top250_rank",
        "oscar_wins", "emmy_wins", "series_status", "series_status_date", "updated_at",
    ]
    rating_columns = ["rating_{0}".format(source) for source in sources]
    columns = fixed + rating_columns

    with open(REPORT_FILE, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=columns)
        writer.writeheader()
        for entry in sorted(canonical_entries, key=lambda row: (str(row.get("type")), str(row.get("showtitle")), str(row.get("title")), safe_int(row.get("season")) or -1, safe_int(row.get("episode")) or -1)):
            row = {key: entry.get(key, "") for key in fixed}
            ids = entry.get("ids") or {}
            row["tmdb_id"] = _csv_tmdb_id(ids.get("tmdb"))
            row["imdb_id"] = _csv_imdb_id(ids.get("imdb"))
            row["imdb_top250_rank"] = csv_top250_rank(entry)
            awards = entry.get("awards") or {}
            row["oscar_wins"] = awards.get("oscar_wins", "")
            row["emmy_wins"] = awards.get("emmy_wins", "")
            series = entry.get("series") or {}
            row["series_status"] = series.get("status", "")
            row["series_status_date"] = series.get("status_date", "")
            for source in sources:
                rating = (entry.get("ratings") or {}).get(source) or {}
                if is_no_rating_marker(rating):
                    row["rating_{0}".format(source)] = NO_RATING_VALUE
                else:
                    value = rating.get("value")
                    row["rating_{0}".format(source)] = "" if value in (None, "") else value
            writer.writerow(row)
    return REPORT_FILE


def cache_stats(cache: Dict[str, Any]) -> Dict[str, Any]:
    entries = list((cache.get("items") or {}).values())
    stats: Dict[str, Any] = {"total": len(entries), "movie": 0, "tvshow": 0, "episode": 0, "fresh": 0, "with_ratings": 0, "sources": {}, "imdb_top250": 0, "imdb_top250_tv": 0}
    for entry in entries:
        kind = str(entry.get("type") or "")
        if kind in stats:
            stats[kind] += 1
        if fresh(entry): stats["fresh"] += 1
        ratings = entry.get("ratings") or {}
        if ratings: stats["with_ratings"] += 1
        if entry.get("type") == "movie" and (safe_int(entry.get("imdb_top250_movie_rank") or entry.get("imdb_top250_rank")) or 0) > 0:
            stats["imdb_top250"] += 1
        if entry.get("type") == "tvshow" and (safe_int(entry.get("imdb_top250_tv_rank") or entry.get("imdb_top250_rank")) or 0) > 0:
            stats["imdb_top250_tv"] += 1
        for source in ratings:
            stats["sources"][source] = stats["sources"].get(source, 0) + 1
    return stats



def _rating_display_for_report(logical: str, rating: Dict[str, Any]) -> str:
    if not isinstance(rating, dict):
        return ""
    if is_no_rating_marker(rating):
        return NO_RATING_VALUE
    if logical in ("imdb", "tmdb", "trakt", "letterboxd"):
        return display_decimal(rating)
    if logical in ("rt_critic", "rt_audience", "metacritic", "mdblist"):
        value = display_percent(rating)
        return value + "%" if value else ""
    return str(rating.get("value") or rating.get("score") or "")


def _rating_label(logical: str) -> str:
    labels = {
        "imdb": "IMDb",
        "tmdb": "TMDb",
        "rt_critic": "RT critics",
        "rt_audience": "RT audience",
        "metacritic": "Metacritic",
        "trakt": "Trakt",
        "letterboxd": "Letterboxd",
        "mdblist": "MDBList",
        "top250": "IMDb Top 250",
    }
    return labels.get(logical, logical)


def _sample_item_title(item: Dict[str, Any]) -> str:
    if item.get("type") == "episode":
        return "{0} S{1:02d}E{2:02d} - {3}".format(
            item.get("showtitle") or "Series",
            safe_int(item.get("season")) or 0,
            safe_int(item.get("episode")) or 0,
            item.get("title") or "Untitled",
        )
    return str(item.get("title") or "Untitled")


def sample_rating_test(sample_size: int = 5, progress: Any = None) -> Dict[str, Any]:
    """Live-test random items without writing cache.

    Samples up to `sample_size` movies, TV shows, and episodes. For each item it
    resolves only the rating families currently enabled in settings and returns
    a human-readable result so the user can verify whether the selected sources
    actually produce values.

    v1.3.16: this is a true live provider check. Existing cache is used only for
    IDs (imdb/tmdb) so the provider can be queried accurately. Cached ratings and
    local Kodi ratings are ignored; if the internet/provider is unavailable the
    result must be MISS.
    """
    keys = api_keys()
    all_items = library_items()
    by_type = {"movie": [], "tvshow": [], "episode": []}
    for item in all_items:
        kind = str(item.get("type") or "")
        if kind in by_type:
            by_type[kind].append(item)

    selected: List[Dict[str, Any]] = []
    for kind in ("movie", "tvshow", "episode"):
        rows = by_type.get(kind) or []
        if not rows:
            continue
        random.shuffle(rows)
        selected.extend(rows[:max(1, int(sample_size))])

    cache = load_cache()
    total = len(selected)
    results: List[Dict[str, Any]] = []
    canceled = False
    for index, item in enumerate(selected, start=1):
        if progress is not None:
            try:
                if progress.iscanceled():
                    canceled = True
                    break
                progress.update(int((index - 1) * 100 / max(1, total)), "{0}/{1}  {2}".format(index, total, _sample_item_title(item)))
            except Exception:  # pylint: disable=broad-except
                pass
        cached_existing = (cache.get("items") or {}).get(item_key(item)) or {}
        existing = {"ids": dict((cached_existing.get("ids") or {}))}
        try:
            # TRUE LIVE CHECK:
            # Use cached IDs only. Do NOT use cached rating rows. Do NOT use
            # local Kodi ratings. This proves whether enabled online providers
            # can return values right now.
            resolved = resolve_item(item, keys, existing, missing_only=True, include_local=False)
        except Exception as exc:  # pylint: disable=broad-except
            resolved = {"type": item.get("type"), "title": item.get("title"), "errors": [str(exc)], "ratings": {}}
        media_type = media_setting_type(item.get("type"))
        wanted = sorted(enabled_rating_logicals(media_type))
        ratings = filter_ratings_for_item(media_type, resolved.get("ratings") or {})
        rows = []
        for logical in wanted:
            cache_key = RATING_LOGICAL_TO_CACHE_KEY.get(logical, logical)
            rating = ratings.get(cache_key)
            if isinstance(rating, dict) and (safe_float(rating.get("score")) is not None or safe_float(rating.get("value")) is not None):
                rows.append({
                    "logical": logical,
                    "label": _rating_label(logical),
                    "value": _rating_display_for_report(logical, rating),
                    "provider": str(rating.get("provider") or ""),
                    "source": str(rating.get("source") or ""),
                    "ok": True,
                })
            else:
                rows.append({"logical": logical, "label": _rating_label(logical), "value": "", "provider": "", "source": "", "ok": False})
        results.append({
            "type": item.get("type"),
            "dbid": item.get("dbid"),
            "title": _sample_item_title(item),
            "ids": resolved.get("ids") or {},
            "ratings": rows,
            "series": resolved.get("series") or {},
            "awards": resolved.get("awards") or {},
            "errors": resolved.get("errors") or [],
            "provider_meta": resolved.get("provider_meta") or {},
            "wanted": wanted,
        })
        delay = max(0, int_setting("delay_ms", 1100)) / 1000.0
        if delay:
            time.sleep(delay)

    if progress is not None:
        try:
            progress.update(100, "Finished")
        except Exception:  # pylint: disable=broad-except
            pass
    return {
        "canceled": canceled,
        "total": total,
        "sample_size": max(1, int(sample_size)),
        "include": {
            "movie": bool_setting("include_movies", True),
            "tvshow": bool_setting("include_tvshows", True),
            "episode": bool_setting("include_episodes", True),
        },
        "results": results,
        "keys": {k: bool(v) for k, v in keys.items()},
    }


def _format_provider_attempts(provider_meta: Dict[str, Any]) -> List[str]:
    lines: List[str] = []
    omdb = provider_meta.get("omdb") or {}
    if omdb.get("attempts"):
        lines.append("  OMDb attempts:")
        for attempt in omdb.get("attempts") or []:
            via = attempt.get("via") or _omdb_attempt_via(attempt)
            ratings = ", ".join(attempt.get("ratings") or []) or "no ratings"
            bits = []
            if attempt.get("response") not in (None, ""):
                bits.append("response={0}".format(attempt.get("response")))
            if attempt.get("title"):
                bits.append("title={0}".format(attempt.get("title")))
            if attempt.get("imdbRating") not in (None, ""):
                bits.append("imdb={0}".format(attempt.get("imdbRating")))
            if attempt.get("Metascore") not in (None, ""):
                bits.append("metascore={0}".format(attempt.get("Metascore")))
            if ratings != "no ratings":
                bits.append("ratings=[{0}]".format(ratings))
            if attempt.get("error"):
                bits.append("error={0}".format(attempt.get("error")))
            if attempt.get("http_status") not in (None, ""):
                bits.append("http={0}".format(attempt.get("http_status")))
            lines.append("    - {0} -> {1}".format(via, " ".join(bits) or "no data"))
    mdblist = provider_meta.get("mdblist") or {}
    if mdblist.get("attempts"):
        lines.append("  MDBList attempts:")
        for attempt in mdblist.get("attempts") or []:
            sources = ", ".join(attempt.get("sources") or []) or "no sources"
            via = attempt.get("via") or "{0}/{1}/{2}".format(attempt.get("provider") or "", attempt.get("media_type") or "", attempt.get("id") or "").strip("/")
            bits = ["ratings_count={0}".format(attempt.get("ratings") or 0)]
            if sources != "no sources":
                bits.append("sources=[{0}]".format(sources))
            if attempt.get("error"):
                bits.append("error={0}".format(attempt.get("error")))
            if attempt.get("http_status") not in (None, ""):
                bits.append("http={0}".format(attempt.get("http_status")))
            lines.append("    - {0} -> {1}".format(via, " ".join(bits)))
        remaining = mdblist.get("rate_limit_remaining")
        if remaining not in (None, ""):
            lines.append("    rate_limit_remaining={0}".format(remaining))
    return lines


def write_sample_rating_test_log(report: Dict[str, Any]) -> str:
    os.makedirs(PROFILE, exist_ok=True)
    text = format_sample_rating_test_report(report)
    try:
        with open(SAMPLE_CHECK_LOG_FILE, "w", encoding="utf-8") as handle:
            handle.write(text)
            handle.write("\n\n===== RAW JSON =====\n")
            handle.write(json.dumps(report, indent=2, ensure_ascii=False, sort_keys=True))
    except Exception as exc:  # pylint: disable=broad-except
        log("Failed to write sample check log: {0}".format(exc), xbmc.LOGWARNING)
    return SAMPLE_CHECK_LOG_FILE


def _format_sample_status_awards(row: Dict[str, Any]) -> List[str]:
    lines: List[str] = []
    kind = media_setting_type(row.get("type"))

    if kind == "tvshow" and bool_setting("scrape_tv_status", True):
        series = row.get("series") or {}
        status = str(series.get("status") or "").strip()
        status_date = str(series.get("status_date_display") or series.get("status_date") or "").strip()
        if status:
            value = status + (" {0}".format(status_date) if status_date else "")
            lines.append("  [OK]   Status: {0}  (tmdb/status)".format(value))
        else:
            lines.append("  [MISS] Status")

    if kind in ("movie", "tvshow") and bool_setting("scrape_awards_wins", True):
        awards = row.get("awards") or {}
        oscar_wins = safe_int(awards.get("oscar_wins")) or 0
        emmy_wins = safe_int(awards.get("emmy_wins")) or 0
        if kind == "movie":
            if oscar_wins > 0:
                lines.append("  [OK]   Oscar wins: {0}  (omdb/awards)".format(oscar_wins))
            else:
                lines.append("  [MISS] Oscar wins")
        elif kind == "tvshow":
            if emmy_wins > 0:
                lines.append("  [OK]   Emmy wins: {0}  (omdb/awards)".format(emmy_wins))
            else:
                lines.append("  [MISS] Emmy wins")
    return lines


def format_sample_rating_test_report(report: Dict[str, Any]) -> str:
    lines = []
    keys = report.get("keys") or {}
    lines.append("Active API keys: MDBList={0}, TMDb={1}, OMDb={2}".format("ON" if keys.get("mdblist") else "OFF", "ON" if keys.get("tmdb") else "OFF", "ON" if keys.get("omdb") else "OFF"))
    inc = report.get("include") or {}
    lines.append("Enabled media: Movies={0}, Series={1}, Episodes={2}".format("ON" if inc.get("movie") else "OFF", "ON" if inc.get("tvshow") else "OFF", "ON" if inc.get("episode") else "OFF"))
    lines.append("Sample per enabled media type: {0}".format(report.get("sample_size") or 5))
    if report.get("canceled"):
        lines.append("Status: canceled")
    lines.append("")
    current_type = None
    type_labels = {"movie": "MOVIES", "tvshow": "SERIES", "episode": "EPISODES"}
    for row in report.get("results") or []:
        kind = str(row.get("type") or "")
        if kind != current_type:
            current_type = kind
            lines.append("===== {0} =====".format(type_labels.get(kind, kind.upper() or "UNKNOWN")))
        ids = row.get("ids") or {}
        id_text = ""
        if ids.get("imdb") or ids.get("tmdb"):
            id_text = "  [imdb={0} tmdb={1}]".format(ids.get("imdb", "-"), ids.get("tmdb", "-"))
        lines.append("\n{0}{1}".format(row.get("title") or "Untitled", id_text))
        for rating in row.get("ratings") or []:
            if rating.get("ok"):
                source = rating.get("source") or ""
                provider = rating.get("provider") or ""
                detail = "{0}/{1}".format(provider, source).strip("/")
                lines.append("  [OK]   {0}: {1}{2}".format(rating.get("label"), rating.get("value"), "  ({0})".format(detail) if detail else ""))
            else:
                lines.append("  [MISS] {0}".format(rating.get("label")))
        lines.extend(_format_sample_status_awards(row))
        errors = [str(e) for e in (row.get("errors") or []) if str(e).strip()]
        if errors:
            lines.append("  errors: {0}".format(" | ".join(errors[:3])))
        provider_lines = _format_provider_attempts(row.get("provider_meta") or {})
        if provider_lines:
            lines.extend(provider_lines)
    if not (report.get("results") or []):
        lines.append("No sample items were processed.")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Arctic Fuse 3 cache publisher and automatic-maintenance helpers (v1.2.0)
# ---------------------------------------------------------------------------
AF3_PREFIX = "LibraryRatings."
TMDBHELPER_PREFIX = "TMDbHelper."
AF3_PROPERTY_NAMES = (
    "IMDb_Rating", "Top250", "TMDb_Rating", "RottenTomatoes_Rating",
    "RottenTomatoes_UserMeter", "MetaCritic_Rating", "Trakt_Rating",
    "MDBList_Rating", "Letterboxd_Rating", "RottenTomatoesIcon",
    "RottenTomatoesImage", "RottenTomatoes_Image", "RottenTomatoes_CriticImage",
    "RottenTomatoesCriticImage", "RottenTomatoesAudienceIcon",
    "RottenTomatoesAudienceImage", "RottenTomatoesAudience_Image",
    "RottenTomatoes_UserImage", "RottenTomatoesUserImage", "Source", "Status", "StatusDate",
    "StatusDateDisplay", "FirstAirDate", "LastAirDate", "NextAirDate",
    "NextEpisodeAirDate", "LastEpisodeAirDate", "First_Air_Date",
    "Last_Air_Date", "Next_Air_Date", "Oscar_Wins", "Emmy_Wins",
    "OscarWins", "EmmyWins", "ItemKey",
)


def _norm_text(value: Any) -> str:
    return re.sub(r"\s+", " ", str(value or "").strip().lower())


def cache_record(cache: Dict[str, Any], item: Dict[str, Any]) -> Dict[str, Any]:
    """Find a cached record for the current skin item.

    Normal library windows give us type+DBID, which is exact. Some Arctic Fuse
    3 hub/spotlight controls focus a Play/Options button instead of the media
    item, or expose only title/year through TMDbHelper properties. For those
    cases, fall back to title/year matching so cached library ratings can still
    be published instead of waiting for TMDbHelper's online lookup.
    """
    records = cache.get("items") or {}
    exact = records.get(item_key(item)) if safe_int(item.get("dbid")) is not None else None
    if isinstance(exact, dict) and exact:
        return exact

    kind = str(item.get("type") or "").lower()
    imdb_id = _norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb"))
    tmdb_id = _norm_tmdb(item.get("tmdb_id") or item.get("tmdb"))
    if imdb_id or tmdb_id:
        for row in records.values():
            if not isinstance(row, dict):
                continue
            row_kind = str(row.get("type") or "").lower()
            if kind and row_kind != kind:
                continue
            if not kind and row_kind not in ("movie", "tvshow", "episode"):
                continue
            ids = row.get("ids") or {}
            if imdb_id and _norm_imdb(ids.get("imdb")) == imdb_id:
                return row
            if tmdb_id and _norm_tmdb(ids.get("tmdb")) == tmdb_id:
                return row

    title = _norm_text(item.get("title"))
    year = safe_int(item.get("year"))
    showtitle = _norm_text(item.get("showtitle"))
    season = safe_int(item.get("season"))
    episode = safe_int(item.get("episode"))
    if not title:
        return {}

    candidates = []
    for row in records.values():
        if not isinstance(row, dict):
            continue
        row_kind = str(row.get("type") or "").lower()
        # Hub/spotlight buttons can expose title/year but no DBTYPE. In that
        # case accept movie/tvshow matches. Episodes still need explicit kind.
        if kind and row_kind != kind:
            continue
        if not kind and row_kind not in ("movie", "tvshow"):
            continue
        if _norm_text(row.get("title")) != title:
            continue
        if year is not None and safe_int(row.get("year")) not in (None, year):
            continue
        if kind == "episode":
            if season is not None and safe_int(row.get("season")) != season:
                continue
            if episode is not None and safe_int(row.get("episode")) != episode:
                continue
            if showtitle and _norm_text(row.get("showtitle")) not in ("", showtitle):
                continue
        candidates.append(row)

    if not candidates:
        return {}
    if len(candidates) == 1:
        return candidates[0]

    # Prefer an exact year and then a fresh record when duplicate titles exist.
    if year is not None:
        exact_year = [row for row in candidates if safe_int(row.get("year")) == year]
        if exact_year:
            candidates = exact_year
    fresh_rows = [row for row in candidates if fresh(row)]
    return (fresh_rows or candidates)[0]


def record_is_fresh(record: Dict[str, Any]) -> bool:
    return bool(record) and fresh(record)


def display_percent(rating: Dict[str, Any]) -> str:
    if not isinstance(rating, dict):
        return ""
    # v1.3.4: no automatic 0-10 -> 0-100 conversion.
    # Publish the cached/provider value as-is so values like 8, 9, 10 stay
    # 8%, 9%, 10% and never jump to 80%, 90%, 100%.
    score = safe_float(rating.get("score"))
    value = safe_float(rating.get("value"))
    number = score if score is not None else value
    if number is None:
        return ""
    return str(int(round(number)))


def display_decimal(rating: Dict[str, Any]) -> str:
    if not isinstance(rating, dict): return ""
    number = safe_float(rating.get("value"))
    if number is None:
        score = safe_float(rating.get("score"))
        number = None if score is None else score / 10.0
    return "" if number is None else "{0:.1f}".format(number)


def first_rating(ratings: Dict[str, Any], *names: str) -> Dict[str, Any]:
    for name in names:
        row = ratings.get(name)
        if isinstance(row, dict): return row
    return {}


def af3_values(record: Dict[str, Any]) -> Dict[str, str]:
    ratings = record.get("ratings") or {}
    if not isinstance(ratings, dict): ratings = {}
    ratings = filter_ratings_for_item(record.get("type"), ratings)
    # v1.3.8: publish only canonical keys. No alias fallback here, because
    # filter_ratings_for_item already folds all old aliases into one value.
    critic = display_percent(first_rating(ratings, "rt_critic"))
    audience = display_percent(first_rating(ratings, "rt_audience"))
    critic_n = safe_int(critic); audience_n = safe_int(audience)
    rt_image = "rtfresh.png" if critic_n is None or critic_n >= 60 else "rtrotten.png"
    rt_audience_image = "popcorn.png" if audience_n is None or audience_n >= 60 else "popcorn_spilt.png"
    values = {
        "IMDb_Rating": display_decimal(first_rating(ratings, "imdb")),
        "Top250": str((safe_int(record.get("imdb_top250_rank")) or "") if rating_enabled(record.get("type"), "top250", True) else ""),
        "TMDb_Rating": display_decimal(first_rating(ratings, "tmdb")),
        "RottenTomatoes_Rating": critic,
        "RottenTomatoes_UserMeter": audience,
        "MetaCritic_Rating": display_percent(first_rating(ratings, "metacritic")),
        "Trakt_Rating": display_decimal(first_rating(ratings, "trakt")),
        "MDBList_Rating": display_percent(first_rating(ratings, "mdblist")),
        "Letterboxd_Rating": display_decimal(first_rating(ratings, "letterboxd")),
        "RottenTomatoesIcon": rt_image,
        "RottenTomatoesImage": rt_image,
        "RottenTomatoes_Image": rt_image,
        "RottenTomatoes_CriticImage": rt_image,
        "RottenTomatoesCriticImage": rt_image,
        "RottenTomatoesAudienceIcon": rt_audience_image,
        "RottenTomatoesAudienceImage": rt_audience_image,
        "RottenTomatoesAudience_Image": rt_audience_image,
        "RottenTomatoes_UserImage": rt_audience_image,
        "RottenTomatoesUserImage": rt_audience_image,
        "Source": "script.library.ratings.scraper",
    }
    awards = record.get("awards") or {}
    if bool_setting("publish_awards_wins", True) and isinstance(awards, dict):
        oscar_wins = safe_int(awards.get("oscar_wins"))
        emmy_wins = safe_int(awards.get("emmy_wins"))
        if oscar_wins and oscar_wins > 0:
            values["Oscar_Wins"] = str(oscar_wins)
            values["OscarWins"] = str(oscar_wins)
        if emmy_wins and emmy_wins > 0:
            values["Emmy_Wins"] = str(emmy_wins)
            values["EmmyWins"] = str(emmy_wins)

    series = record.get("series") or {}
    if bool_setting("publish_tv_status", True) and record.get("type") in ("tvshow", "season", "episode") and isinstance(series, dict):
        status = str(series.get("status") or "").strip()
        status_date = str(series.get("status_date") or "").strip()
        status_date_display = str(series.get("status_date_display") or _date_display(status_date)).strip()
        first_air = str(series.get("first_air_date") or "").strip()
        last_air = str(series.get("last_air_date") or "").strip()
        next_air = str(series.get("next_episode_air_date") or "").strip()
        last_episode_air = str(series.get("last_episode_air_date") or "").strip()
        values.update({
            "Status": status,
            "StatusDate": status_date_display or _date_display(status_date),
            "StatusDateDisplay": status_date_display,
            "FirstAirDate": _date_display(first_air),
            "LastAirDate": _date_display(last_air),
            "NextAirDate": _date_display(next_air),
            "NextEpisodeAirDate": _date_display(next_air),
            "LastEpisodeAirDate": _date_display(last_episode_air),
            "First_Air_Date": _date_display(first_air),
            "Last_Air_Date": _date_display(last_air),
            "Next_Air_Date": _date_display(next_air),
        })
    return {key: str(value) for key, value in values.items() if value not in (None, "")}



def _window_home():
    import xbmcgui
    return xbmcgui.Window(10000)


def publish_af3_properties(values: Dict[str, str], item_identity: str = "", compatibility: bool = True) -> None:
    home = _window_home()
    published = dict(values)
    published["ItemKey"] = item_identity
    for name in AF3_PROPERTY_NAMES:
        value = str(published.get(name, "") or "")
        home.setProperty(AF3_PREFIX + "ListItem." + name, value)
        if compatibility:
            # Arctic Fuse 3 already reads the TMDbHelper.ListItem.* property
            # namespace. Publishing the cache there avoids a skin-file patch.
            home.setProperty(TMDBHELPER_PREFIX + "ListItem." + name, value)


def clear_af3_properties(compatibility: bool = True) -> None:
    publish_af3_properties({}, "", compatibility)


def _info_label(*names: str) -> str:
    for name in names:
        value = xbmc.getInfoLabel(name).strip()
        if value:
            return value
    return ""


def _home_property(*names: str) -> str:
    import xbmcgui
    home = xbmcgui.Window(10000)
    for name in names:
        value = home.getProperty(name).strip()
        if value:
            return value
    return ""


def _window_property(*names: str) -> str:
    """Read properties from the currently visible window.

    Arctic Fuse 3 often stores the item context for Hub/Spotlight on the
    current window, while the focused Kodi control can be a Play/More button.
    The old fallback only checked Window(Home), so it could miss the same item
    that the skin was already using for clearlogo/plot.
    """
    for name in names:
        try:
            value = xbmc.getInfoLabel("Window.Property({0})".format(name)).strip()
        except Exception:  # pylint: disable=broad-except
            value = ""
        if value:
            return value
    return ""


def _any_window_property(*names: str) -> str:
    return _window_property(*names) or _home_property(*names)


def _norm_imdb(value: Any) -> str:
    match = re.search(r"tt\d+", str(value or ""), re.I)
    return match.group(0).lower() if match else ""


def _norm_tmdb(value: Any) -> str:
    number = safe_int(value)
    return str(number) if number is not None else str(value or "").strip()


def _clean_dbtype(value: str) -> str:
    value = str(value or "").strip().lower()
    aliases = {"movies": "movie", "tv": "tvshow", "show": "tvshow", "series": "tvshow", "episodes": "episode"}
    return aliases.get(value, value)


def selected_library_item() -> Dict[str, Any]:
    return {
        "type": _clean_dbtype(_info_label("ListItem.DBTYPE", "ListItem.DBType")),
        "dbid": _info_label("ListItem.DBID"),
        "title": _info_label("ListItem.Title"),
        "year": _info_label("ListItem.Year"),
        "imdbnumber": _info_label("ListItem.IMDBNumber", "ListItem.UniqueID(imdb)", "ListItem.Property(imdb_id)"),
        "tmdb_id": _info_label("ListItem.UniqueID(tmdb)", "ListItem.Property(tmdb_id)", "ListItem.Property(tmdbid)"),
        "top250": _info_label("ListItem.Top250"),
    }


def lrs_active_item() -> Dict[str, Any]:
    """Optional skin bridge target.

    A tiny AF3 skin patch can set LRS.Active.* properties from the media item
    it is drawing, even when focus is on a hub button. This function is harmless
    without that patch and lets future skin-side bridges work without changing
    the display layout.
    """
    imdb = _any_window_property(
        "LRS.Active.IMDb_ID", "LRS.Active.IMDbID", "LRS.Active.IMDbNumber",
        "LRS.Active.IMDBNumber", "LRS.Active.imdb_id",
    )
    tmdb = _any_window_property("LRS.Active.TMDb_ID", "LRS.Active.TMDbID", "LRS.Active.tmdb_id")
    return {
        "type": _clean_dbtype(_any_window_property("LRS.Active.DBTYPE", "LRS.Active.DBType", "LRS.Active.Type")),
        "dbid": _any_window_property("LRS.Active.DBID", "LRS.Active.DBId", "LRS.Active.dbid"),
        "title": _any_window_property("LRS.Active.Title", "LRS.Active.title", "LRS.Active.Label"),
        "year": _any_window_property("LRS.Active.Year", "LRS.Active.year"),
        "imdbnumber": imdb,
        "tmdb_id": tmdb,
        "top250": _any_window_property("LRS.Active.Top250"),
    }


def tmdbhelper_item() -> Dict[str, Any]:
    """Fallback for Arctic Fuse 3 hub/spotlight windows.

    Hub/Spotlight can focus a Play/Options button, not the media list item.
    AF3/TMDbHelper can still expose identity on either the current window or
    Window(Home). Check both, then match our local cache by DBID, IMDb ID,
    TMDb ID, or title/year. Rating values still come from this add-on cache.
    """
    imdb = _any_window_property(
        "TMDbHelper.ListItem.IMDb_ID", "TMDbHelper.ListItem.IMDbID",
        "TMDbHelper.ListItem.IMDbNumber", "TMDbHelper.ListItem.IMDBNumber",
        "TMDbHelper.ListItem.imdb_id",
    )
    tmdb = _any_window_property("TMDbHelper.ListItem.TMDb_ID", "TMDbHelper.ListItem.TMDbID", "TMDbHelper.ListItem.tmdb_id")
    return {
        "type": _clean_dbtype(_any_window_property("TMDbHelper.ListItem.DBTYPE", "TMDbHelper.ListItem.DBType", "TMDbHelper.ListItem.Type", "TMDbHelper.ListItem.tmdb_type")),
        "dbid": _any_window_property("TMDbHelper.ListItem.DBID", "TMDbHelper.ListItem.DBId", "TMDbHelper.ListItem.dbid"),
        "title": _any_window_property("TMDbHelper.ListItem.Title", "TMDbHelper.ListItem.title", "TMDbHelper.ListItem.Label", "TMDbHelper.ListItem.TVShowTitle"),
        "year": _any_window_property("TMDbHelper.ListItem.Year", "TMDbHelper.ListItem.year", "TMDbHelper.ListItem.ReleaseYear"),
        "imdbnumber": imdb,
        "tmdb_id": tmdb,
        "top250": _any_window_property("TMDbHelper.ListItem.Top250"),
    }

def screensaver_item(offset: int = 0) -> Dict[str, Any]:
    def li(field: str) -> str:
        expression = "Container(1297).ListItem.{0}".format(field) if offset == 0 else "Container(1297).ListItem({0}).{1}".format(offset, field)
        return xbmc.getInfoLabel(expression).strip()
    return {
        "type": _clean_dbtype(li("DBTYPE") or li("DBType")),
        "dbid": li("DBID"), "title": li("Title"), "year": li("Year"),
        "imdbnumber": li("IMDBNumber") or li("UniqueID(imdb)") or li("Property(imdb_id)"),
        "tmdb_id": li("UniqueID(tmdb)") or li("Property(tmdb_id)") or li("Property(tmdbid)"),
        "top250": li("Top250"),
    }


def valid_library_item(item: Dict[str, Any]) -> bool:
    kind = str(item.get("type") or "")
    has_identity = (
        safe_int(item.get("dbid")) is not None
        or bool(str(item.get("title") or "").strip())
        or bool(_norm_imdb(item.get("imdbnumber") or item.get("imdb_id") or item.get("imdb")))
        or bool(_norm_tmdb(item.get("tmdb_id") or item.get("tmdb")))
    )
    # Empty kind is allowed for AF3 hub/spotlight fallbacks where the focused
    # control is a button but title/year/IMDb/TMDb ID are still available
    # through properties.
    return has_identity and (kind in ("", "movie", "tvshow", "episode"))


def resolvable_library_item(item: Dict[str, Any]) -> bool:
    return str(item.get("type") or "") in ("movie", "tvshow", "episode") and safe_int(item.get("dbid")) is not None


def enabled_rating_logicals(media_type: Any) -> set:
    media_type = media_setting_type(media_type)
    logicals = set()
    for logical in RATING_LOGICALS_BY_TYPE.get(media_type, set()):
        if logical == "top250":
            continue
        if rating_enabled(media_type, logical, True):
            logicals.add(logical)
    return logicals


def record_missing_logicals(media_type: Any, record: Dict[str, Any]) -> set:
    media_type = media_setting_type(media_type)
    wanted = enabled_rating_logicals(media_type)
    if not wanted:
        return set()
    ratings = filter_ratings_for_item(media_type, (record or {}).get("ratings") or {})
    present = set()
    for key, row in ratings.items():
        logical = logical_for_rating_source(key) or key
        if logical in wanted and isinstance(row, dict):
            if is_no_rating_marker(row):
                present.add(logical)
            elif safe_float(row.get("score")) is not None or safe_float(row.get("value")) is not None:
                present.add(logical)
    return wanted - present


def record_missing_series_status(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if item.get("type") != "tvshow" or not bool_setting("scrape_tv_status", True):
        return False
    series = (record or {}).get("series") or {}
    if not isinstance(series, dict):
        return True
    return not bool(str(series.get("status") or "").strip())


def record_missing_awards(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    return _awards_needs_fill((record or {}).get("awards") or {}, item.get("type"))


def record_needs_update(item: Dict[str, Any], record: Dict[str, Any]) -> bool:
    if not record:
        return True
    # Manual-only mode: missing-only checks missing fields, not cache age.
    if bool_setting("refresh_expired_cache", False) and not fresh(record):
        return True
    if record_missing_logicals(item.get("type"), record):
        return True
    if record_missing_series_status(item, record):
        return True
    if record_missing_awards(item, record):
        return True
    return False


def stale_or_missing_items(cache: Dict[str, Any], include_missing: bool = True) -> List[Dict[str, Any]]:
    records = cache.get("items") or {}
    items = library_items()
    result: List[Dict[str, Any]] = []
    for item in items:
        row = records.get(item_key(item)) or {}
        if (include_missing and not row) or (row and record_needs_update(item, row)):
            result.append(item)
    return result

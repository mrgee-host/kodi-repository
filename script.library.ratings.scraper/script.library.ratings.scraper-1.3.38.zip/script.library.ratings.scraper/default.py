# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import xbmcgui
from resources.lib import core

TITLE = "Library Ratings Scraper"


def online_sources():
    keys = core.api_keys()
    online = []
    if keys.get("mdblist"):
        online.append("MDBList")
    if keys.get("tmdb"):
        online.append("TMDb")
    if keys.get("omdb"):
        online.append("OMDb")
    return online


def show_stats() -> None:
    stats = core.cache_stats(core.load_cache())
    sources = ", ".join("{0}: {1}".format(k, v) for k, v in sorted(stats.get("sources", {}).items())) or "none"
    xbmcgui.Dialog().textviewer(
        TITLE,
        "Total cache: {0}\nMovies: {1}\nTV shows: {2}\nEpisodes: {3}\nFresh cache: {4}\nItems with ratings: {5}\nIMDb Top 250: {6}\nIMDb Top 250 TV: {8}\n\nRating sources:\n{7}".format(
            stats["total"], stats["movie"], stats["tvshow"], stats["episode"], stats["fresh"], stats["with_ratings"], stats.get("imdb_top250", 0), sources, stats.get("imdb_top250_tv", 0)
        ),
    )


def queue_scrape(force: bool = False) -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if state.get("status") in ("queued", "running", "finishing"):
        dialog.notification(TITLE, "Background scrape is already running", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return

    online = online_sources()
    if not online:
        if not dialog.yesno(
            TITLE,
            "No online API key was found.\n\nContinue only to copy local Kodi ratings into the cache?",
            nolabel="Cancel",
            yeslabel="Continue",
        ):
            return

    mode = "force refresh all selected media" if force else "missing fields only"
    if not dialog.yesno(
        TITLE,
        "Start background scrape?\n\nMode: {0}\nOnline sources: {1}\n\nKodi can still be used while this runs.".format(mode, ", ".join(online) or "none"),
        nolabel="Cancel",
        yeslabel="Start",
    ):
        return

    core.queue_background_job("scrape", force=force)
    dialog.notification(TITLE, "Background scrape queued", xbmcgui.NOTIFICATION_INFO, 5000, False)


def queue_top250() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if state.get("status") in ("queued", "running", "finishing"):
        dialog.notification(TITLE, "A background process is already running", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return
    core.queue_background_job("top250", force=True)
    dialog.notification(TITLE, "IMDb Top 250 Movies + TV Shows sync started in background", xbmcgui.NOTIFICATION_INFO, 5000, False)


def show_background_status() -> None:
    state = core.background_job_state()
    status = state.get("status") or "idle"
    action = state.get("action") or "-"
    total = state.get("total") or 0
    processed = state.get("processed") or 0
    percent = state.get("percent") or 0
    matched = state.get("matched") or 0
    updated = state.get("updated") or 0
    skipped = state.get("skipped") or 0
    failed = state.get("failed") or 0
    current = state.get("current") or "-"
    started = state.get("started_at") or "-"
    finished = state.get("finished_at") or "-"
    report = state.get("report") or "-"
    xbmcgui.Dialog().textviewer(
        TITLE,
        "Status: {0}\nAction: {1}\nProgress: {2}% ({3}/{4})\nCurrent item: {5}\n\nMatched: {6}\nUpdated: {7}\nSkipped: {8}\nFailed: {9}\n\nStarted: {10}\nFinished: {11}\nCSV report: {12}".format(
            status, action, percent, processed, total, current, matched, updated, skipped, failed, started, finished, report
        ),
    )


def cancel_background() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if state.get("status") not in ("queued", "running", "finishing", "force_stop_requested"):
        dialog.notification(TITLE, "No active background process", xbmcgui.NOTIFICATION_INFO, 4000, False)
        return
    if dialog.yesno(TITLE, "Cancel the current background process?", nolabel="No", yeslabel="Cancel"):
        core.request_background_cancel()
        dialog.notification(TITLE, "Cancel request sent", xbmcgui.NOTIFICATION_INFO, 4000, False)


def force_stop_background() -> None:
    dialog = xbmcgui.Dialog()
    if dialog.yesno(TITLE, "FORCE STOP the background process now?\n\nThis is stronger than normal cancel. The process will stop as soon as the service returns from its current request.", nolabel="No", yeslabel="Force stop"):
        core.request_background_force_stop()
        dialog.notification(TITLE, "Force stop request sent", xbmcgui.NOTIFICATION_WARNING, 5000, False)


def _enabled_media_text() -> str:
    parts = [
        "Movies={0}".format("ON" if core.bool_setting("include_movies", True) else "OFF"),
        "Series={0}".format("ON" if core.bool_setting("include_tvshows", True) else "OFF"),
        "Episodes={0}".format("ON" if core.bool_setting("include_episodes", True) else "OFF"),
    ]
    return ", ".join(parts)


def test_random_ratings() -> None:
    dialog = xbmcgui.Dialog()
    sample_size = max(1, min(25, core.int_setting("sample_check_size", 5)))
    enabled_media = _enabled_media_text()
    if not dialog.yesno(
        TITLE,
        "Check LIVE internet using the current settings?\n\nMedia: {0}\nSample: {1} item per enabled media type\n\nRatings follow the current Movies/TV shows/Episodes settings. Cache is not used as the result and is not saved.".format(enabled_media, sample_size),
        nolabel="Cancel",
        yeslabel="Start",
    ):
        return
    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Checking random ratings...")
    try:
        report = core.sample_rating_test(sample_size, progress)
    finally:
        try:
            progress.close()
        except Exception:  # pylint: disable=broad-except
            pass
    log_path = core.write_sample_rating_test_log(report)
    text = core.format_sample_rating_test_report(report)
    text += "\n\nDetailed log saved at:\n{0}".format(log_path)
    dialog.textviewer(TITLE + " - Check Random Live", text)


def export_only() -> None:
    path = core.export_csv(core.load_cache())
    xbmcgui.Dialog().ok(TITLE, "CSV report updated:\n{0}".format(path))


def clear_cache() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if state.get("status") in ("queued", "running", "finishing"):
        dialog.ok(TITLE, "Background scrape is already running. Cancel it or wait for it to finish before clearing the cache.")
        return
    if not dialog.yesno(
        TITLE,
        "Clear this rating scraper cache?\n\nTMDbHelper cache and the Kodi video database will not be touched.",
        nolabel="Cancel",
        yeslabel="Clear",
    ):
        return
    try:
        for path in (core.CACHE_FILE, core.REPORT_FILE, core.SUMMARY_FILE, core.BACKGROUND_STATE_FILE, core.BACKGROUND_REQUEST_FILE, core.BACKGROUND_CANCEL_FILE, core.BACKGROUND_FORCE_STOP_FILE):
            if os.path.exists(path):
                os.remove(path)
    except OSError as exc:
        dialog.ok(TITLE, "Failed to clear cache:\n{0}".format(exc))
        return
    dialog.ok(TITLE, "Scraper cache cleared.")


def sync_itemdetails_db() -> None:
    dialog = xbmcgui.Dialog()
    if not dialog.yesno(
        TITLE,
        "Sync all current LRS cache into TMDbHelper ItemDetails.db?\n\nThis writes ratings/status/awards to TMDbHelper with a 10-year expiry. Votes are left untouched.",
        nolabel="Cancel",
        yeslabel="Sync",
    ):
        return
    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Syncing cache to TMDbHelper ItemDetails.db...")
    try:
        summary = core.sync_cache_to_tmdbhelper_itemdetails(core.load_cache())
    finally:
        try:
            progress.close()
        except Exception:  # pylint: disable=broad-except
            pass
    if summary.get("ok"):
        dialog.textviewer(
            TITLE + " - TMDbHelper DB Sync",
            "Completed.\n\nDB: {db_path}\nProcessed: {processed}/{total_cache_items}\nRatings rows: {ratings_rows}\nBaseitem rows: {baseitem_rows}\nMovie/TV/Episode rating rows: {media_rating_rows}\nStatus rows: {status_rows}\nEpisode IMDb rows in ratings table: {episode_imdb_rows}\nSkipped: {skipped}\nExpiry: 10 years".format(**summary),
        )
    else:
        dialog.ok(TITLE, "TMDbHelper DB sync failed:\n{0}".format(summary.get("error") or "Unknown error"))


def main() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    active = state.get("status") in ("queued", "running", "finishing", "force_stop_requested")
    actions = [
        ("Scrape missing ratings/status/Top 250", lambda: queue_scrape(False)),
        ("Refresh all ratings/status/Top 250", lambda: queue_scrape(True)),
        ("Sync IMDb Top 250 Movies + TV Shows", queue_top250),
    ]
    if active:
        actions.append(("Cancel background process", cancel_background))
    actions.extend([
        ("View background status", show_background_status),
        ("Export CSV report", export_only),
        ("Sync cache to TMDbHelper ItemDetails.db", sync_itemdetails_db),
        ("Check random LIVE internet", test_random_ratings),
    ])
    choice = dialog.select(TITLE, [label for label, _ in actions])
    if choice >= 0:
        actions[choice][1]()


if __name__ == "__main__":
    main()

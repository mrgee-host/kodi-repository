# -*- coding: utf-8 -*-
from __future__ import annotations

import sys
import xbmc
import xbmcgui
from resources.lib import core

TITLE = "Library Ratings Scraper"


def _notify(msg: str) -> None:
    xbmcgui.Dialog().notification(TITLE, msg, xbmcgui.NOTIFICATION_INFO, 4000, False)


def _queue(action: str, force: bool = False) -> None:
    state = core.background_job_state()
    if core.background_state_is_active(state):
        if xbmcgui.Dialog().yesno(TITLE, "Background job is already running or stuck.\n\nReset state now?", nolabel="Cancel", yeslabel="Reset"):
            core.reset_background_job_state("Manual stuck-state reset")
            _notify("Background state reset")
        else:
            _notify("Background job already running")
        return
    core.queue_background_job(action, force=force)
    _notify("Queued: {0}".format(action))


def show_status() -> None:
    state = core.background_job_state()
    stats = core.cache_stats(core.load_cache())
    lines = [
        "Role: rating database/scraper owner",
                "Background status: {0}".format(state.get("status") or "idle"),
        "Action: {0}".format(state.get("action") or ""),
        "Current: {0}".format(state.get("current") or ""),
        "Percent: {0}".format(state.get("percent") or ""),
        "",
        "Cache total: {0}".format(stats.get("total")),
        "Movies: {0}".format(stats.get("movie")),
        "TV shows: {0}".format(stats.get("tvshow")),
        "Episodes: {0}".format(stats.get("episode")),
        "With ratings: {0}".format(stats.get("with_ratings")),
        "IMDb Top250 movies: {0}".format(stats.get("imdb_top250", 0)),
        "IMDb Top250 TV: {0}".format(stats.get("imdb_top250_tv", 0)),
    ]
    xbmcgui.Dialog().textviewer(TITLE + " - Status", "\n".join(str(x) for x in lines))


def export_diag() -> None:
    path = core.export_diagnostics_zip_1397()
    xbmcgui.Dialog().ok(TITLE, "Diagnostics exported:\n{0}".format(path or "unknown"))


def _run_cropv2_batch(force: bool = False) -> None:
    mode = "REBUILD ALL" if force else "BUILD MISSING"
    status = core.cropv2_cache_status_1544()
    message = (
        "{0} CropV2 files for every clearlogo found in:\n"
        "- Kodi movies\n"
        "- Kodi TV shows\n"
        "- Steam Library games\n\n"
        "Destination:\n{1}\n\n"
        "Existing files: {2}\n\n"
        "{3}"
    ).format(
        mode,
        status.get("path") or "unknown",
        status.get("files") or 0,
        (
            "Existing files will be replaced."
            if force
            else "Existing files will be kept."
        ),
    )
    if not xbmcgui.Dialog().yesno(
        TITLE + " - CropV2",
        message,
        nolabel="Cancel",
        yeslabel="Start",
    ):
        return

    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Collecting clearlogos...")
    try:
        result = core.build_all_cropv2_1544(
            force=force,
            progress=progress,
        )
    finally:
        try:
            progress.close()
        except Exception:
            pass

    xbmcgui.Dialog().textviewer(
        TITLE + " - CropV2 batch report",
        core.read_cropv2_batch_report_1544(),
    )
    if result.get("cancelled"):
        _notify("CropV2 build cancelled")
    elif result.get("failed_sources"):
        _notify(
            "CropV2 finished: {0} generated, {1} failed".format(
                result.get("generated_sources") or 0,
                result.get("failed_sources") or 0,
            )
        )
    else:
        _notify(
            "CropV2 finished: {0} generated".format(
                result.get("generated_sources") or 0
            )
        )


def build_missing_cropv2() -> None:
    _run_cropv2_batch(False)


def rebuild_all_cropv2() -> None:
    _run_cropv2_batch(True)


def view_cropv2_report() -> None:
    xbmcgui.Dialog().textviewer(
        TITLE + " - CropV2 batch report",
        core.read_cropv2_batch_report_1544(),
    )


def main() -> None:
    actions = [
        ("Refresh all rating data", lambda: _queue("scrape", True)),
        ("Scrape missing rating data", lambda: _queue("scrape", False)),
        ("Scrape missing RT badges only", lambda: _queue("rtbadges", False)),
        ("Scrape awards only", lambda: _queue("awards", False)),
        ("Update IMDb Top 250 only", lambda: _queue("top250", False)),
        ("Build missing CropV2 for all clearlogos", build_missing_cropv2),
        ("Rebuild all CropV2 for all clearlogos", rebuild_all_cropv2),
        ("View CropV2 batch report", view_cropv2_report),
        ("View status", show_status),
        ("Export diagnostics ZIP", export_diag),
        ("Settings", lambda: xbmc.executebuiltin("Addon.OpenSettings(script.library.ratings.scraper)")),
        ("Exit", None),
    ]
    idx = xbmcgui.Dialog().select(TITLE, [a[0] for a in actions])
    if idx < 0 or idx >= len(actions) - 1:
        return
    actions[idx][1]()


if __name__ == "__main__":
    main()

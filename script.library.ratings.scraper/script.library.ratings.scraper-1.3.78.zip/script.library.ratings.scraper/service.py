# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import time
import xbmc
import xbmcgui
from resources.lib import core

POLL_SECONDS = 0.10
STATE_FILE = os.path.join(core.PROFILE, "service-state.json")
TITLE = "Library Ratings Scraper"


def load_state():
    try:
        with open(STATE_FILE, "r", encoding="utf-8") as handle:
            row = json.load(handle)
        return row if isinstance(row, dict) else {}
    except (OSError, ValueError):
        return {}


def save_state(state):
    os.makedirs(core.PROFILE, exist_ok=True)
    temp = STATE_FILE + ".tmp"
    with open(temp, "w", encoding="utf-8") as handle:
        json.dump(state, handle, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(temp, STATE_FILE)


def current_context_item():
    if core.player_context_active():
        return "player", core.player_item()

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item
    item = core.lrs_active_item()
    if core.valid_library_item(item):
        return "lrs_active", item
    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity
    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}


def context_log(state, context, item_key, title, published, reason):
    signature = "{0}|{1}|{2}|{3}".format(context, item_key, int(bool(published)), reason)
    if state.get("last_context_log") == signature:
        return
    state["last_context_log"] = signature
    clean_title = str(title or "").replace("\\n", " ")[:80]
    core.log(
        "context={0} item_key={1} title={2} published={3} reason={4}".format(
            context, item_key or "", clean_title, "yes" if published else "no", reason
        ),
        xbmc.LOGDEBUG,
    )


def _record_from_cache(cache, item, preload=None):
    preload = preload or {}
    identity = core.identity_key(item)
    cached = preload.get(identity)
    if isinstance(cached, dict):
        return cached
    return core.cache_record(cache, item)


def queue_item(queue, queued, item, front=False):
    # Background lookup requires a Kodi DBID. Title-only hub fallbacks can still
    # publish cached values, but should not be looked up online as a new item.
    if not core.resolvable_library_item(item):
        return
    key = core.item_key(item)
    if key in queued:
        return
    queued.add(key)
    if front:
        queue.insert(0, item)
    else:
        queue.append(item)


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}

    if not core.valid_library_item(item):
        core.clear_af3_properties(compatibility)
        context_log(state, context, "", item.get("title") if isinstance(item, dict) else "", False, "identity_missing")
        return ""

    active_key = core.identity_key(item)
    if active_key != previous_key:
        # Clear first on every context/key change. If cache lookup misses or waits
        # one cycle, AF3 sees blank properties instead of the previous item.
        core.publish_af3_properties({}, active_key, compatibility)

    record = _record_from_cache(cache, item, preload)
    if not record and context == "player":
        # Player/OSD must not stay blank just because the service loaded cache
        # before a manual scrape/rebuild finished. Reload DB once on player miss.
        try:
            fresh_cache = core.load_cache()
            record = _record_from_cache(fresh_cache, item, preload)
            if record:
                cache.clear(); cache.update(fresh_cache)
        except Exception:  # pylint: disable=broad-except
            record = None
    if not record:
        core.publish_af3_properties({}, active_key, compatibility)
        context_log(state, context, active_key, item.get("title"), False, "cache_miss")
        return active_key

    if not core.context_matches_record(item, record):
        core.publish_af3_properties({}, active_key, compatibility)
        context_log(state, context, active_key, item.get("title"), False, "stale_guard")
        return active_key

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    core.publish_af3_properties(values, publish_key, compatibility)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), True, "cache_hit")
    return active_key


def item_label(item):
    title = item.get("title") or "Untitled"
    if item.get("type") == "episode":
        return "{0} - S{1:02d}E{2:02d} - {3}".format(
            item.get("showtitle") or "Series",
            core.safe_int(item.get("season")) or 0,
            core.safe_int(item.get("episode")) or 0,
            title,
        )
    return title


def notify(message, icon=xbmcgui.NOTIFICATION_INFO, duration=5000):
    xbmcgui.Dialog().notification(TITLE, message, icon, duration, False)


def write_job_state(job, status=None):
    item_total = len(job.get("items") or [])
    raw_total = job.get("total")
    total = int(raw_total) if raw_total not in (None, "") and int(raw_total or 0) > 0 else item_total
    processed = int(job.get("processed") or job.get("index") or 0)
    if total and processed > total:
        processed = total
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    state = {
        "status": status or job.get("status") or "running",
        "action": job.get("action") or "scrape",
        "force": bool(job.get("force")),
        "requested_at": job.get("requested_at") or "",
        "started_at": job.get("started_at") or "",
        "finished_at": job.get("finished_at") or "",
        "total": total,
        "processed": processed,
        "percent": percent,
        "updated": int(job.get("updated") or 0),
        "matched": int(job.get("matched") or 0),
        "skipped": int(job.get("skipped") or 0),
        "failed": int(job.get("failed") or 0),
        "current": job.get("current") or "",
        "report": job.get("report") or "",
    }
    core.save_background_state(state)


def compact_text(value, limit=26):
    text = str(value or "Preparing...").replace("\n", " ").strip()
    return text if len(text) <= limit else text[: max(0, limit - 3)].rstrip() + "..."


def update_bg(job, message=None):
    progress = job.get("progress")
    if progress is None:
        return
    total = int(job.get("total") or len(job.get("items") or []))
    processed = int(job.get("processed") or job.get("index") or 0)
    percent = int(processed * 100 / max(1, total)) if total else int(job.get("percent") or 0)
    # Keep the background notification deliberately minimal. Arctic Fuse 3
    # only has room for one compact body line. Detailed counters remain
    # available from the add-on menu: "View background status".
    text = message or "{0}/{1}  {2}".format(
        processed,
        total,
        compact_text(job.get("current")),
    )
    progress.update(percent, TITLE, compact_text(text, 58))


def new_scrape_job(request):
    items = core.library_items()
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, "Preparing background scrape...")
    total = len(items)
    job = {
        "action": "scrape",
        "force": bool(request.get("force")),
        "requested_at": request.get("requested_at") or core.now_iso(),
        "started_at": core.now_iso(),
        "items": items,
        "keys": core.api_keys(),
        "index": 0,
        "updated": 0,
        "matched": 0,
        "processed": 0,
        "total": total,
        "skipped": 0,
        "failed": 0,
        "looked_up": 0,
        "current": "Preparing...",
        "next_at": 0.0,
        "progress": progress,
        "status": "running",
    }
    write_job_state(job)
    notify("Background scrape running", xbmcgui.NOTIFICATION_INFO, 5000)
    return job


def new_top250_job(request):
    progress = xbmcgui.DialogProgressBG()
    progress.create(TITLE, "Syncing IMDb Top 250 Movies + TV Shows in background...")
    job = {
        "action": "top250",
        "force": True,
        "requested_at": request.get("requested_at") or core.now_iso(),
        "started_at": core.now_iso(),
        "items": [],
        "index": 0,
        "updated": 0,
        "skipped": 0,
        "failed": 0,
        "matched": 0,
        "processed": 0,
        "total": 0,
        "current": "IMDb Top 250",
        "progress": progress,
        "status": "running",
    }
    write_job_state(job)
    notify("Local IMDb Top 250 sync running in background", xbmcgui.NOTIFICATION_INFO, 5000)
    return job


def finish_job(job, cache, canceled=False, stopped_reason=""):
    job["status"] = "finishing"
    write_job_state(job, "finishing")
    update_bg(job, "Saving cache...")
    core.save_cache(cache)

    if job.get("action") == "scrape" and not canceled and not stopped_reason:
        update_bg(job, "Syncing IMDb Top 250...")
        try:
            stats = core.sync_imdb_top250_to_library(False, None)
            job["matched"] = int(stats.get("matched") or 0)
        except Exception as exc:  # pylint: disable=broad-except
            core.log("IMDb Top 250 sync failed after background scrape: {0}".format(exc), xbmc.LOGWARNING)
    elif job.get("action") == "top250" and not canceled:
        update_bg(job, "Reading local IMDb Top 250...")
        try:
            stats = core.sync_imdb_top250_to_library(True, None)
            job["updated"] = int(stats.get("updated") or 0)
            job["matched"] = int(stats.get("matched") or 0)
            job["total"] = int(stats.get("total") or 0)
            job["processed"] = int(stats.get("processed") or stats.get("total") or 0)
            job["percent"] = 100
            cache = core.load_cache()
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] = 1
            core.log("Manual IMDb Top 250 sync failed: {0}".format(exc), xbmc.LOGWARNING)

    update_bg(job, "Exporting CSV report...")
    report = core.export_csv(core.load_cache())
    job["report"] = report

    summary = {
        "started_at": job.get("started_at"),
        "finished_at": core.now_iso(),
        "items_total": int(job.get("total") or len(job.get("items") or [])),
        "matched": int(job.get("matched") or 0),
        "updated": int(job.get("updated") or 0),
        "matched": int(job.get("matched") or 0),
        "skipped": int(job.get("skipped") or 0),
        "failed": int(job.get("failed") or 0),
        "online_lookups": int(job.get("looked_up") or 0),
        "report": report,
        "canceled": bool(canceled),
        "stopped_reason": stopped_reason or "",
        "action": job.get("action"),
    }
    core.save_summary(summary)
    job["finished_at"] = summary["finished_at"]
    if stopped_reason:
        job["status"] = "stopped"
        job["current"] = stopped_reason
    else:
        job["status"] = "canceled" if canceled else "completed"
        job["current"] = "Canceled" if canceled else "Finished"
    if job.get("progress") is not None:
        job["progress"].close()
    write_job_state(job, job["status"])
    if stopped_reason:
        notify(stopped_reason, xbmcgui.NOTIFICATION_WARNING, 8000)
    elif canceled:
        notify("Background scrape canceled", xbmcgui.NOTIFICATION_WARNING, 6000)
    else:
        notify("Background scrape completed", xbmcgui.NOTIFICATION_INFO, 6000)


def force_stop_job(job):
    if job and job.get("progress") is not None:
        try:
            job["progress"].close()
        except Exception:  # pylint: disable=broad-except
            pass
    state = {
        "status": "force_stopped",
        "action": (job or {}).get("action", "scrape"),
        "force": bool((job or {}).get("force")),
        "requested_at": (job or {}).get("requested_at", ""),
        "started_at": (job or {}).get("started_at", ""),
        "finished_at": core.now_iso(),
        "percent": int((job or {}).get("percent") or 0),
        "processed": int((job or {}).get("index") or 0),
        "total": len((job or {}).get("items") or []),
        "updated": int((job or {}).get("updated") or 0),
        "skipped": int((job or {}).get("skipped") or 0),
        "failed": int((job or {}).get("failed") or 0),
        "current": "Force stopped",
    }
    core.save_background_state(state)


def advance_scrape(job, cache):
    if time.time() < float(job.get("next_at") or 0):
        return False
    items = job.get("items") or []
    total = len(items)
    job["total"] = total
    job["processed"] = int(job.get("index") or 0)
    if job.get("index", 0) >= total:
        finish_job(job, cache, False)
        return True

    # Skip fresh rows quickly in one UI cycle. Stop after the first online/local
    # resolve so API pacing remains predictable and the service stays responsive.
    handled = 0
    while job.get("index", 0) < total and handled < 100:
        item = items[job["index"]]
        job["index"] += 1
        job["processed"] = int(job.get("index") or 0)
        handled += 1
        key = core.item_key(item)
        existing = (cache.get("items") or {}).get(key) or {}
        label = item_label(item)
        job["current"] = label
        if not job.get("force") and existing and not core.record_needs_update(item, existing):
            job["skipped"] += 1
            update_bg(job)
            continue
        try:
            cache.setdefault("items", {})[key] = core.resolve_item(item, job.get("keys") or core.api_keys(), existing, missing_only=not job.get("force"), include_local=False)
            job["updated"] += 1
            job["looked_up"] += 1
        except core.ProviderLimitReached as exc:
            message = "Stopped: {0} API limit reached".format(exc.provider)
            detail = str(exc)
            job["failed"] += 1
            job["current"] = message
            job["stopped_reason"] = message
            core.log("{0}. {1}".format(message, detail), xbmc.LOGWARNING)
            core.save_cache(cache)
            finish_job(job, cache, False, message)
            return True
        except Exception as exc:  # pylint: disable=broad-except
            job["failed"] += 1
            core.log("Background full scrape failed for {0}: {1}".format(label, exc), xbmc.LOGWARNING)
        if job["index"] % max(1, core.int_setting("save_every", 10)) == 0:
            core.save_cache(cache)
        delay = max(0, core.int_setting("delay_ms", 1100)) / 1000.0
        job["next_at"] = time.time() + delay
        update_bg(job)
        write_job_state(job)
        return False

    job["processed"] = int(job.get("index") or 0)
    write_job_state(job)
    if job.get("index", 0) >= total:
        finish_job(job, cache, False)
        return True
    return False


def advance_job(job, cache):
    if core.consume_background_force_stop():
        force_stop_job(job)
        return True
    if core.consume_background_cancel():
        finish_job(job, cache, True)
        return True
    if job.get("action") == "top250":
        finish_job(job, cache, False)
        return True
    return advance_scrape(job, cache)


# -----------------------------------------------------------------------------
# v1.3.74 AF3/LRS active bridge + sticky publisher overrides (superseded by v1.3.75 below)
# -----------------------------------------------------------------------------
def current_context_item():
    # Player/OSD always wins.
    if core.player_context_active():
        return "player", core.player_item()

    # AF3 skin bridge is the highest priority for hub/library panels because
    # it represents the item currently being drawn, not the focused button.
    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus
    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item
    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity
    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}

    # Invalid focus/button/dialog should not clear the visible media row.
    if not core.valid_library_item(item):
        context_log(state, context, previous_key or "", item.get("title") if isinstance(item, dict) else "", False, "identity_missing_keep_last")
        return previous_key or ""

    active_key = core.identity_key(item)
    record = _record_from_cache(cache, item, preload)
    if not record and context == "player":
        try:
            fresh_cache = core.load_cache()
            record = _record_from_cache(fresh_cache, item, preload)
            if record:
                cache.clear(); cache.update(fresh_cache)
        except Exception:  # pylint: disable=broad-except
            record = None

    if not record:
        # If the incoming identity is incomplete/title-only, keep the previous
        # row rather than blanking. If it is a strong different media id, clear
        # to avoid showing stale values for a real new item.
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "cache_miss_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "cache_miss_keep_last")
        return previous_key or active_key

    if not core.context_matches_record(item, record):
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "stale_guard_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "stale_guard_keep_last")
        return previous_key or active_key

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    core.publish_af3_properties(values, publish_key, compatibility)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), True, "cache_hit_bridge")
    return active_key



# -----------------------------------------------------------------------------
# v1.3.75 AF3/LRS active bridge + strict episode sticky publisher
# -----------------------------------------------------------------------------
def current_context_item():
    # Player/OSD always wins.
    if core.player_context_active():
        return "player", core.player_item()

    # Screensaver must use the screensaver container. Do not let a stale hub
    # bridge override the active slide.
    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    # AF3 skin bridge wins for hub/library panels because it represents the
    # item being drawn, not the focused Play/Options button.
    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item
    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus
    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity
    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}


def publish_current(cache, item, previous_key, context="listitem", state=None, preload=None):
    compatibility = core.bool_setting("publish_af3_cache", True)
    state = state if isinstance(state, dict) else {}

    if not core.valid_library_item(item):
        context_log(state, context, previous_key or "", item.get("title") if isinstance(item, dict) else "", False, "identity_missing_keep_last")
        return previous_key or ""

    active_key = core.identity_key(item)
    record = _record_from_cache(cache, item, preload)
    if not record and context == "player":
        try:
            fresh_cache = core.load_cache()
            record = _record_from_cache(fresh_cache, item, preload)
            if record:
                cache.clear(); cache.update(fresh_cache)
        except Exception:  # pylint: disable=broad-except
            record = None

    if not record:
        # Strong new media IDs should clear; weak/title-only button/dialog focus
        # keeps the last row to avoid flicker.
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "cache_miss_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "cache_miss_keep_last")
        return previous_key or active_key

    if not core.context_matches_record(item, record):
        if core.resolvable_library_item(item) and active_key and active_key != previous_key:
            core.publish_af3_properties({}, active_key, compatibility)
            context_log(state, context, active_key, item.get("title"), False, "strict_guard_clear_new_media")
            return active_key
        context_log(state, context, previous_key or active_key, item.get("title"), False, "strict_guard_keep_last")
        return previous_key or active_key

    publish_key = core.record_item_key(record) or active_key
    values = core.af3_values(record)
    values["SourceContext"] = context
    try:
        core._lrs_log_publish_values(context, record, values)  # pylint: disable=protected-access
    except Exception:  # pylint: disable=broad-except
        pass
    core.publish_af3_properties(values, publish_key, compatibility)
    context_log(state, context, publish_key, item.get("title") or record.get("title"), True, "cache_hit_strict")
    return active_key


# -----------------------------------------------------------------------------
# v1.3.76 context override: do not let AF3 Home buttons replace episode focus with parent tvshow
# -----------------------------------------------------------------------------
def current_context_item():
    if core.player_context_active():
        item = core.player_item()
        if core.valid_library_item(item):
            return "player", item

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus

    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        # When AF3 Home focus is on Play/More Options, TMDbHelper often exposes
        # the parent tvshow while the visible panel is an episode. Publishing that
        # parent causes exactly the wrong episode/series rating. Keep last valid
        # row until a strong visual/list/player identity is available.
        if core.af3_home_action_button_focused() and str(tmdb_identity.get("type") or "").lower() == "tvshow":
            return "identity_missing", {}
        return "tmdbhelper", tmdb_identity

    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}



# -----------------------------------------------------------------------------
# v1.3.78 context override: AF3 visual item wins; TMDbHelper cannot override
# Home/Hub buttons or category tabs with stale media.
# -----------------------------------------------------------------------------
def current_context_item():
    if core.player_context_active():
        item = core.player_item()
        if core.valid_library_item(item):
            return "player", item

    if xbmc.getCondVisibility("System.ScreenSaverActive"):
        for offset in (0, 1, -1, 2):
            item = core.screensaver_item(offset)
            if core.valid_library_item(item):
                return "screensaver", item
        return "screensaver", core.screensaver_item(0)

    # In AF3 Home/Hub the focused control can be a button/tab while the visual
    # item is drawn from a widget/spotlight container. Read that container first.
    if core.af3_hub_window_active():
        visual = core.af3_visual_item()
        if core.valid_library_item(visual):
            return "af3_visual", visual
        active = core.lrs_active_item()
        if core.valid_library_item(active):
            return "lrs_active", active
        hub_focus = core.hub_focus_container_item()
        if core.valid_library_item(hub_focus):
            return "hub", hub_focus
        # If focus is on a Home/Hub button or selector and the visual resolver is
        # empty, keep the previous published row. Do not let stale TMDbHelper or
        # stale ListItem values overwrite the current background/title.
        if core.af3_button_or_selector_focused():
            return "identity_missing", {}
        item = core.selected_library_item()
        if core.valid_library_item(item):
            return "listitem", item
        hub_item = core.hub_primary_item()
        if core.valid_library_item(hub_item):
            return "hub_fallback", hub_item
        return "identity_missing", {}

    active = core.lrs_active_item()
    if core.valid_library_item(active):
        return "lrs_active", active

    item = core.selected_library_item()
    if core.valid_library_item(item):
        return "listitem", item

    hub_focus = core.hub_focus_container_item()
    if core.valid_library_item(hub_focus):
        return "hub", hub_focus

    tmdb_identity = core.tmdbhelper_item()
    if core.valid_library_item(tmdb_identity):
        return "tmdbhelper", tmdb_identity

    hub_item = core.hub_primary_item()
    if core.valid_library_item(hub_item):
        return "hub_fallback", hub_item
    return "identity_missing", {}

def main():
    monitor = xbmc.Monitor()
    cache = core.load_cache()
    cache_mtime = core.cache_db_mtime()
    state = load_state()
    queue = []
    queued = set()
    previous_key = ""
    preloaded_key = ""
    preloaded_cache = {}
    next_lookup_at = 0.0
    manual_job = None
    compatibility = core.bool_setting("publish_af3_cache", True)
    core.clear_af3_properties(compatibility)
    core.reset_stale_background_on_service_start()
    core.log("Library Ratings Scraper service started", xbmc.LOGINFO)

    while not monitor.abortRequested():
        now = time.time()
        if core.consume_background_force_stop():
            queue = []
            queued = set()
            if manual_job is not None:
                force_stop_job(manual_job)
                manual_job = None
                cache = core.load_cache()
            notify("Force stop background", xbmcgui.NOTIFICATION_WARNING, 5000)
            previous_key = ""
            preloaded_key = ""
            preloaded_cache = {}

        latest_cache_mtime = core.cache_db_mtime()
        # v1.3.65: Do not reload the in-memory scrape cache from disk while a
        # manual scrape is running. The service itself writes ratings-cache.db
        # every save_every items. Older builds saw their own DB mtime change,
        # reloaded from disk before the next item, and discarded unsaved rows
        # between save points. That is why the DB contained movie|1..10 then
        # movie|20, movie|30, movie|40, etc.
        if manual_job is None:
            if latest_cache_mtime and latest_cache_mtime != cache_mtime:
                try:
                    cache = core.load_cache()
                    # load_cache may touch schema/meta and update file mtime;
                    # store the post-load mtime, not the stale value read before.
                    cache_mtime = core.cache_db_mtime()
                    previous_key = ""
                except Exception as exc:  # pylint: disable=broad-except
                    core.log("Cache reload after external update failed: {0}".format(exc), xbmc.LOGWARNING)
            elif not latest_cache_mtime and cache_mtime:
                # User deleted ratings-cache.db while Kodi/service was still running.
                # Do not keep the old in-memory cache and write it back again.
                cache = {"version": core.CACHE_VERSION, "updated_at": "", "backend": "sqlite-ratings-only", "items": {}}
                cache_mtime = 0.0
                previous_key = ""
                preloaded_cache = {}
                core.clear_af3_properties(compatibility)
                core.log("ratings-cache.db disappeared; cleared in-memory LRS cache", xbmc.LOGWARNING)

        context, item = current_context_item()
        previous_key = publish_current(cache, item, previous_key, context, state, preloaded_cache)

        request = core.consume_background_request()
        if request:
            if manual_job is not None:
                notify("Previous background process is still running", xbmcgui.NOTIFICATION_WARNING, 5000)
            elif request.get("action") == "top250":
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                manual_job = new_top250_job(request)
            else:
                # Always reload from disk when a manual scrape starts. If user has
                # deleted ratings-cache.db, this starts from an empty cache instead
                # of the old service RAM cache.
                cache = core.load_cache()
                cache_mtime = core.cache_db_mtime()
                core.reset_scale_trace_log()
                manual_job = new_scrape_job(request)

        # Manual-only: focus changes never queue online scraping.

        # Screensaver one-item cache preload only. No online scrape is queued here.
        # This simply resolves current/next slide identity against the in-memory LRS
        # cache so the next publish can happen immediately after the slide changes.
        if xbmc.getCondVisibility("System.ScreenSaverActive"):
            upcoming = {}
            for offset in (1, 2, -1):
                candidate = core.screensaver_item(offset)
                if core.valid_library_item(candidate):
                    upcoming = candidate
                    break
            upcoming_key = core.identity_key(upcoming) if core.valid_library_item(upcoming) else ""
            if upcoming_key and upcoming_key != preloaded_key:
                preloaded_key = upcoming_key
                record = core.cache_record(cache, upcoming)
                preloaded_cache = {upcoming_key: record} if record else {}
                context_log(state, "screensaver", upcoming_key, upcoming.get("title"), bool(record), "preload_cache_hit" if record else "preload_cache_miss")
        else:
            preloaded_key = ""
            preloaded_cache = {}

        # Manual-only: no automatic refresh, no automatic Top 250 sync.

        # Manual library scrape has priority but executes inside this background
        # service. Kodi's UI remains usable and DialogProgressBG appears only in
        # the notification area.
        if manual_job is not None:
            if advance_job(manual_job, cache):
                manual_job = None
                cache_mtime = core.cache_db_mtime()
                previous_key = ""
            else:
                # save_cache may have run inside advance_scrape; keep this mtime
                # synchronized so the next non-manual loop does not treat our own
                # write as an external DB replacement.
                cache_mtime = core.cache_db_mtime() or cache_mtime
        # Strict manual-only mode: no focus/screensaver/idle item is ever
        # resolved online here. Online scraping only happens from explicit
        # menu actions that create manual_job.

        wait_seconds = 0.10 if (xbmc.getCondVisibility("System.ScreenSaverActive") or core.player_context_active()) else POLL_SECONDS
        monitor.waitForAbort(wait_seconds)

    if manual_job is not None and manual_job.get("progress") is not None:
        manual_job["progress"].close()
    core.clear_af3_properties(core.bool_setting("publish_af3_cache", True))
    core.log("Library Ratings Scraper service stopped", xbmc.LOGINFO)


if __name__ == "__main__":
    main()

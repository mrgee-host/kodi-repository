Library Ratings Scraper 1.3.55

Base: 1.3.54.

Fixes:
- ratings table now contains searchable metadata columns: media_type, title, showtitle, season, episode, year, imdb_id, tmdb_id.
- Existing ratings-cache.db gets these columns via ALTER TABLE and auto-backfills from items.
- Context-menu refresh is visible without Kodi restart: service reloads cache when ratings-cache.db changes.
- Keeps 1.3.54 display helper fix and OSD namespace publishing.

Note: OSD movie double rows / episode TMDb hidden are caused by the AF3 XML injected LRS block; use the companion Includes_Info patch for that.

Library Ratings Scraper 1.3.54

Base: 1.3.53.

Fixes:
- Fix service crash: NameError: display_percent is not defined.
- Restores display_decimal/display_percent/display_rt_percent helper functions used by AF3 property publishing and reports.
- RT values are still published as number only, so AF3 will show 78% instead of 78% %.
- Keeps 1.3.53 service namespace publishing: ListItem, Player, and VideoPlayer.
- Reduces noisy Window id does not exist errors by no longer opening current dialog Window(id).

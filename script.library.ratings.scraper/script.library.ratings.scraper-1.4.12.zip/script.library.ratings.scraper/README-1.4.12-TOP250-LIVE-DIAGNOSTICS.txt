Library Ratings Scraper 1.4.12

Focus:
- Fix live IMDb Top 250 chart rebuild diagnostics.
- Fetch movie and TV chart independently:
  https://www.imdb.com/chart/top/
  https://www.imdb.com/chart/toptv/
- Do not overwrite existing Top250 ranks unless enabled charts validate with at least 200 titles.
- Save top250-sync-last.json and top250-sync-report.csv under diagnostics.
- Store HTTP status, final URL, byte count, page title, parser method, parsed count and failure sample.
- Keep AF3 icon path complete fix from 1.4.11.
- Update schema/addon metadata to 1.4.12.

LRS 1.6.7

1. Strong identity wins over label deny words.
   Home + DBID 982 + DBType movie is a movie.
   Home without DBID/type/item key remains a navigation label.

2. Arctic Mirage uses independent BundleA and BundleB snapshots.
   Plot, rating, awards/status, title, and final CropV2 logo are copied only
   after the global current-key bundle is complete.

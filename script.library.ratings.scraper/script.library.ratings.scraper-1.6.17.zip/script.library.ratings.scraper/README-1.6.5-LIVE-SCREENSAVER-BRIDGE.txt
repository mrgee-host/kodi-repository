Library Ratings Scraper 1.6.5

- Removes the R10 display-contract JSON pipeline.
- Keeps the existing live screensaver publisher in service.py.
- Movie/series library and screensaver both call af3_values(record).
- Games mirror RatingSlotN properties supplied by MediaHub.
- CropV2 remains resolved live through the persistent resolver cache.
- Keeps 1.6.3 differential SQLite writes, no_slug closeout, DBID handoff,
  DBID reuse protection, clean final schema, diagnostics and provider logic.

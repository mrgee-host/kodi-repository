Library Ratings Scraper 1.6.2

Runtime handoff recovery update:
- Late-start snapshot during an already-running Kodi video scan.
- OnUpdate added=true candidate journal only when ScanStarted was missed.
- CleanFinished salvage before stale rows are deleted.
- Strong one-to-one identity checks remain mandatory.
- No legacy schema migration or generic cache-miss fallback was restored.

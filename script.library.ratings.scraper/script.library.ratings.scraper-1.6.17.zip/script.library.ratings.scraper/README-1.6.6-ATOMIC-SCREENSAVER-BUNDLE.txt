LRS 1.6.6 ATOMIC SCREENSAVER BUNDLE

Plot, rating and clearlogo/title are displayed as one metadata unit.
The unit remains hidden until rating and logo are both complete for the exact current mediahub_item_key.
No display contract JSON is used. The existing live LRS bridge remains active.

Library Ratings Scraper 1.6.3

Differential SQLite saves prevent timestamp churn.
Permanent RT closeout is respected.
CropV2 resolver bootstrap uses local cached artwork only and performs no network download.
The existing KPM keep-last row transition remains unchanged.

# -*- coding: utf-8 -*-
from __future__ import annotations

import re
import xbmc
import xbmcgui

from resources.lib import core

TITLE = "Library Ratings Scraper"


def _compact_context_text(value, limit=58):
    text = " ".join(str(value or "").replace("\n", " ").split()).upper().rstrip()
    text = re.sub(r"\bHANDED OFF\b", "MIGRATED", text)
    text = re.sub(r"\bHANDOFF\b", "MIGRATED", text)
    parts0 = text.replace(" • ", " - ").split(" - ") if text else []
    if len(parts0) > 1:
        text = " - ".join([parts0[0]] + [part for part in parts0[1:] if not re.match(r"^0(?:\s+|$)", part)])
    elif text and re.match(r"^0(?:\s+|$)", text):
        return ""
    if len(text) <= limit:
        return text
    raw = text[:limit - 1].rstrip()
    return (raw.rsplit(" ", 1)[0] if " " in raw else raw) + "…"


def _notify(message, icon=xbmcgui.NOTIFICATION_INFO, duration=5000):
    text = _compact_context_text(message)
    if text:
        xbmcgui.Dialog().notification(TITLE, text, icon, duration, False)


def _context_item():
    # Context menu normally exposes ListItem.* for the selected row/card.
    for getter in (core.selected_library_item, core.hub_focus_container_item, core.lrs_active_item, core.tmdbhelper_item):
        try:
            item = getter()
        except Exception:  # pylint: disable=broad-except
            item = {}
        if core.valid_library_item(item):
            return item
    return {}


def _is_game_item(item):
    try:
        return core.is_lrs_game_item(item)
    except Exception:
        kind = str((item or {}).get("type") or (item or {}).get("MediaType") or (item or {}).get("DBTYPE") or "").strip().lower()
        return kind == "game" or str((item or {}).get("lrs_game") or "").strip().lower() in ("true", "1", "yes")


def refresh_selected_item():
    dialog = xbmcgui.Dialog()
    item = _context_item()
    if not core.valid_library_item(item) or _is_game_item(item):
        _notify("NO MOVIE / TV SHOW / EPISODE IDENTITY", xbmcgui.NOTIFICATION_WARNING, 5000)
        return

    media_type = item.get("type") or "item"
    title = item.get("title") or item.get("showtitle") or "Selected item"
    if item.get("type") == "episode":
        title = "{0} - S{1:02d}E{2:02d} - {3}".format(
            item.get("title") or "Episode",
            core.safe_int(item.get("season")) or 0,
            core.safe_int(item.get("episode")) or 0,
            item.get("showtitle") or "Series",
        )

    if not dialog.yesno(TITLE, "Refresh ratings for this item:\n\n\n{0}\n\nThis force-refreshes all LRS data for this selected item.".format(title), nolabel="Cancel", yeslabel="Refresh"):
        return

    compact_title = _compact_context_text(title, 44)
    _notify("REFRESH RATINGS - {0}".format(compact_title), xbmcgui.NOTIFICATION_INFO, 3500)
    try:
        cache = core.load_cache()
        existing = core.cache_record(cache, item) or {}
        refreshed = core.resolve_item(item, core.api_keys(), existing, missing_only=False, include_local=False, ratings_only=False)
        if core.media_setting_type(item.get("type")) in ("movie", "tvshow"):
            refreshed = core.resolve_awards_only(item, core.api_keys(), refreshed)
            refreshed = core.resolve_rt_badge_only(item, core.api_keys(), refreshed, force=True)
        key = core.item_key(refreshed)
        if not key or key.endswith("|"):
            key = core.item_key(item)
        cache.setdefault("items", {})[key] = refreshed
        core.save_cache(cache)
        values = core.af3_values(refreshed)
        values["SourceContext"] = "context"
        core.publish_af3_properties(values, key, core.bool_setting("publish_af3_cache", True))
        _notify("REFRESH RATINGS FINISHED - 1 ITEM - 0 ERRORS", xbmcgui.NOTIFICATION_INFO, 5000)
    except core.ProviderLimitReached as exc:
        core.log("Context refresh API limit: {0}".format(exc), xbmc.LOGWARNING)
        _notify("REFRESH RATINGS STOPPED - API LIMIT", xbmcgui.NOTIFICATION_WARNING, 6000)
    except Exception as exc:  # pylint: disable=broad-except
        core.log("Context refresh failed: {0}".format(exc), xbmc.LOGERROR)
        _notify("REFRESH RATINGS FAILED - 1 ERROR", xbmcgui.NOTIFICATION_ERROR, 6000)


if __name__ == "__main__":
    refresh_selected_item()

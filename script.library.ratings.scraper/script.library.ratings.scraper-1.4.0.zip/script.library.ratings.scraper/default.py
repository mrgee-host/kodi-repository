# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import xbmcgui
from resources.lib import core

TITLE = "Library Ratings Scraper"


def online_sources():
    keys = core.api_keys()
    online = []
    if keys.get("mdblist"):
        online.append("MDBList")
    if keys.get("tmdb"):
        online.append("TMDb")
    if keys.get("omdb"):
        online.append("OMDb")
    return online


def show_stats() -> None:
    stats = core.cache_stats(core.load_cache())
    sources = ", ".join("{0}: {1}".format(k, v) for k, v in sorted(stats.get("sources", {}).items())) or "none"
    xbmcgui.Dialog().textviewer(
        TITLE,
        "Total cache: {0}\nMovies: {1}\nTV shows: {2}\nEpisodes: {3}\nFresh cache: {4}\nItems with ratings: {5}\nIMDb Top 250: {6}\nIMDb Top 250 TV: {8}\n\nRating sources:\n{7}".format(
            stats["total"], stats["movie"], stats["tvshow"], stats["episode"], stats["fresh"], stats["with_ratings"], stats.get("imdb_top250", 0), sources, stats.get("imdb_top250_tv", 0)
        ),
    )


def queue_scrape(force: bool = False) -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if core.background_state_is_active(state):
        if dialog.yesno(TITLE, "Background job is already marked as running.\n\nCancel/reset the stuck state now?", nolabel="Back", yeslabel="Reset"):
            core.reset_background_job_state("Manual stuck-state reset")
            dialog.notification(TITLE, "Background state reset. Run the scrape again.", xbmcgui.NOTIFICATION_INFO, 5000, False)
        else:
            dialog.notification(TITLE, "Background scrape is already running", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return

    online = online_sources()
    if not online:
        if not dialog.yesno(
            TITLE,
            "No online API key was found.\n\nContinue only to copy local Kodi ratings into the cache?",
            nolabel="Cancel",
            yeslabel="Continue",
        ):
            return

    if force:
        if not dialog.yesno(
            TITLE,
            "WARNING: Refresh all data\n\nThis will re-scrape ALL selected movies, TV shows, and episodes.\nExisting cached ratings, status, awards, Top250, and RT badges may be overwritten.\nThis can take a long time and may hit API rate limits.\n\nContinue?",
            nolabel="Cancel",
            yeslabel="Refresh all",
        ):
            return
    else:
        if not dialog.yesno(
            TITLE,
            "Start scraping missing data?\n\nThis only processes missing/repairable cache data and then runs the normal awards, Top250, and RT badge phases.\n\nOnline sources: {0}".format(", ".join(online) or "none"),
            nolabel="Cancel",
            yeslabel="Start",
        ):
            return

    core.queue_background_job("scrape", force=force)
    dialog.notification(TITLE, "Background process queued", xbmcgui.NOTIFICATION_INFO, 5000, False)



def queue_awards_only() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if core.background_state_is_active(state):
        if dialog.yesno(TITLE, "Background job is already marked as running.\n\nCancel/reset the stuck state now?", nolabel="Back", yeslabel="Reset"):
            core.reset_background_job_state("Manual stuck-state reset")
            dialog.notification(TITLE, "Background state reset. Run awards scrape again.", xbmcgui.NOTIFICATION_INFO, 5000, False)
        else:
            dialog.notification(TITLE, "A background process is already running", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return
    online = online_sources()
    if not dialog.yesno(
        TITLE,
        "Start awards-only scrape?\n\nMovies/series awards use OMDb only. MDBList awards are deliberately ignored. Ratings/status/Top250 are not changed.\n\nOnline sources: {0}".format(", ".join(online) or "none"),
        nolabel="Cancel",
        yeslabel="Start",
    ):
        return
    core.queue_background_job("awards", force=False)
    dialog.notification(TITLE, "Awards-only process queued", xbmcgui.NOTIFICATION_INFO, 5000, False)



def queue_rt_badges(force: bool = False) -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if core.background_state_is_active(state):
        if dialog.yesno(TITLE, "Background job is already marked as running.\n\nCancel/reset the stuck state now?", nolabel="Back", yeslabel="Reset"):
            core.reset_background_job_state("Manual stuck-state reset")
            dialog.notification(TITLE, "Background state reset. Run RT badge scrape again.", xbmcgui.NOTIFICATION_INFO, 5000, False)
        else:
            dialog.notification(TITLE, "A background process is already running", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return
    if not dialog.yesno(TITLE, "Scrape missing Rotten Tomatoes badges only?\n\nThis does not refresh main ratings. Stable RT badge rows are skipped.", nolabel="Cancel", yeslabel="Start"):
        return
    core.queue_background_job("rtbadges", force=False)
    dialog.notification(TITLE, "RT badge scrape queued", xbmcgui.NOTIFICATION_INFO, 5000, False)


def queue_top250() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if core.background_state_is_active(state):
        if dialog.yesno(TITLE, "Background job is already marked as running.\n\nCancel/reset the stuck state now?", nolabel="Back", yeslabel="Reset"):
            core.reset_background_job_state("Manual stuck-state reset")
            dialog.notification(TITLE, "Background state reset. Run the sync again.", xbmcgui.NOTIFICATION_INFO, 5000, False)
        else:
            dialog.notification(TITLE, "A background process is already running", xbmcgui.NOTIFICATION_INFO, 5000, False)
        return
    core.queue_background_job("top250", force=True)
    dialog.notification(TITLE, "IMDb Top 250 update queued", xbmcgui.NOTIFICATION_INFO, 5000, False)


def show_background_status() -> None:
    state = core.background_job_state()
    status = state.get("status") or "idle"
    action = state.get("action") or "-"
    total = state.get("total") or 0
    processed = state.get("processed") or 0
    percent = state.get("percent") or 0
    matched = state.get("matched") or 0
    updated = state.get("updated") or 0
    skipped = state.get("skipped") or 0
    failed = state.get("failed") or 0
    current = state.get("current") or "-"
    started = state.get("started_at") or "-"
    finished = state.get("finished_at") or "-"
    report = state.get("report") or "-"
    xbmcgui.Dialog().textviewer(
        TITLE,
        "Last action: {1}\nStatus: {0}\nProgress: {2}% ({3}/{4})\nCurrent: {5}\n\nSummary:\n  Matched: {6}\n  Updated: {7}\n  Skipped: {8}\n  Failed: {9}\n\nStarted: {10}\nFinished: {11}\nReport: {12}".format(
            status, action, percent, processed, total, current, matched, updated, skipped, failed, started, finished, report
        ),
    )


def cancel_background() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if not core.background_state_is_active(state):
        dialog.notification(TITLE, "No active background process", xbmcgui.NOTIFICATION_INFO, 4000, False)
        return
    choice = dialog.select(TITLE, [
        "Force stop running process",
        "Clear stuck background state",
        "Back",
    ])
    if choice == 0:
        core.request_background_force_stop()
        dialog.notification(TITLE, "Force stop request sent", xbmcgui.NOTIFICATION_WARNING, 5000, False)
    elif choice == 1:
        core.reset_background_job_state("Manual stuck-state reset")
        dialog.notification(TITLE, "Background state cleared", xbmcgui.NOTIFICATION_INFO, 5000, False)


def force_stop_background() -> None:
    dialog = xbmcgui.Dialog()
    if dialog.yesno(TITLE, "FORCE STOP the background process now?\n\nThis is stronger than normal cancel. The process will stop as soon as the service returns from its current request.", nolabel="No", yeslabel="Force stop"):
        core.request_background_force_stop()
        dialog.notification(TITLE, "Force stop request sent", xbmcgui.NOTIFICATION_WARNING, 5000, False)


def _enabled_media_text() -> str:
    parts = [
        "Movies={0}".format("ON" if core.bool_setting("include_movies", True) else "OFF"),
        "Series={0}".format("ON" if core.bool_setting("include_tvshows", True) else "OFF"),
        "Episodes={0}".format("ON" if core.bool_setting("include_episodes", True) else "OFF"),
    ]
    return ", ".join(parts)


def test_random_ratings() -> None:
    dialog = xbmcgui.Dialog()
    sample_size = max(1, min(25, core.int_setting("sample_check_size", 5)))
    enabled_media = _enabled_media_text()
    if not dialog.yesno(
        TITLE,
        "Check LIVE internet using the current settings?\n\nMedia: {0}\nSample: {1} item per enabled media type\n\nRatings follow the current Movies/TV shows/Episodes settings. Cache is not used as the result and is not saved.".format(enabled_media, sample_size),
        nolabel="Cancel",
        yeslabel="Start",
    ):
        return
    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Checking random ratings...")
    try:
        report = core.sample_rating_test(sample_size, progress)
    finally:
        try:
            progress.close()
        except Exception:  # pylint: disable=broad-except
            pass
    log_path = core.write_sample_rating_test_log(report)
    text = core.format_sample_rating_test_report(report)
    text += "\n\nDetailed log saved at:\n{0}".format(log_path)
    dialog.textviewer(TITLE + " - Check Random Live", text)


def export_only() -> None:
    path = core.export_csv(core.load_cache())
    xbmcgui.Dialog().ok(TITLE, "CSV report updated:\n{0}".format(path))



def export_diagnostics_zip() -> None:
    try:
        path = core.export_diagnostics_zip_1397()
        xbmcgui.Dialog().ok(TITLE, "Diagnostics ZIP created:\n{0}".format(path))
    except Exception as exc:  # pylint: disable=broad-except
        xbmcgui.Dialog().ok(TITLE, "Failed to create diagnostics ZIP:\n{0}".format(exc))


def clear_cache() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    if core.background_state_is_active(state):
        dialog.ok(TITLE, "Background scrape is already running. Cancel/reset it before clearing the cache.")
        return
    if not dialog.yesno(
        TITLE,
        "Clear this rating scraper cache?\n\nTMDbHelper cache and the Kodi video database will not be touched.",
        nolabel="Cancel",
        yeslabel="Clear",
    ):
        return
    try:
        for path in (core.CACHE_FILE, getattr(core, "LEGACY_CACHE_FILE", ""), getattr(core, "LEGACY_IMDB_TOP250_CACHE_FILE", ""), core.REPORT_FILE, core.SUMMARY_FILE, core.BACKGROUND_STATE_FILE, core.BACKGROUND_REQUEST_FILE, core.BACKGROUND_CANCEL_FILE, core.BACKGROUND_FORCE_STOP_FILE):
            if os.path.exists(path):
                os.remove(path)
    except OSError as exc:
        dialog.ok(TITLE, "Failed to clear cache:\n{0}".format(exc))
        return
    dialog.ok(TITLE, "Scraper cache cleared.")


def toggle_debug_logging() -> None:
    enabled = not core.debug_enabled()
    core.set_debug_enabled(enabled)
    xbmcgui.Dialog().notification(TITLE, "Debug logging {0}".format("ON" if enabled else "OFF"), xbmcgui.NOTIFICATION_INFO, 4000, False)


def main() -> None:
    dialog = xbmcgui.Dialog()
    state = core.background_job_state()
    active = core.background_state_is_active(state)
    actions = [
        ("Refresh all data", lambda: queue_scrape(True)),
        ("Scrape missing data", lambda: queue_scrape(False)),
        ("Scrape missing RT badges only", lambda: queue_rt_badges(False)),
        ("Scrape awards only", queue_awards_only),
        ("Update IMDb Top 250 only", queue_top250),
    ]
    if active:
        actions.append(("Cancel/reset background process", cancel_background))
    actions.extend([
        ("View status", show_background_status),
        ("Export diagnostics ZIP", export_diagnostics_zip),
    ])
    choice = dialog.select(TITLE, [label for label, _ in actions])
    if choice >= 0:
        actions[choice][1]()


if __name__ == "__main__":
    main()

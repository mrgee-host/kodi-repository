# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import xbmc
import xbmcgui
from resources.lib import core

TITLE = "Library Ratings Scraper"


def _compact(value: object, limit: int = 58) -> str:
    text = " ".join(str(value or "").split()).upper().rstrip()
    if len(text) <= int(limit):
        return text
    parts = text.replace(" • ", " - ").split(" - ")
    protected = ("ERROR", "FAILED", "UPDATED", "ARTWORK", "ITEM", "CACHED", "MOVED", "SCRAPED", "N/A")
    if len(parts) > 1 and any(token in " - ".join(parts[1:]) for token in protected):
        suffix = " - " + " - ".join(parts[1:])
        budget = max(4, int(limit) - len(suffix))
        action = parts[0]
        if len(action) > budget:
            action = action[:max(1, budget - 3)].rstrip() + "..."
        return (action + suffix)[:int(limit)].rstrip()
    raw = text[:max(1, int(limit) - 3)].rstrip()
    return (raw.rsplit(" ", 1)[0] if " " in raw else raw) + "..."


def _notify(msg: str, icon=xbmcgui.NOTIFICATION_INFO, duration: int = 5000) -> None:
    xbmcgui.Dialog().notification(TITLE, _compact(msg), icon, duration, False)


def _show_text(title: str, body: str) -> None:
    text = str(body or "").strip()
    if len(text) <= 520 and len(text.splitlines()) <= 7:
        xbmcgui.Dialog().ok(title, text or "NO DETAILS")
    else:
        xbmcgui.Dialog().textviewer(title, text)


def _queue(action: str, force: bool = False) -> None:
    state = core.background_job_state()
    if core.background_state_is_active(state):
        if xbmcgui.Dialog().yesno(
            TITLE,
            "Background job is already running or stuck.\n\nReset state now?",
            nolabel="Cancel",
            yeslabel="Reset",
        ):
            core.reset_background_job_state("Manual stuck-state reset")
            _notify("Background state reset")
        else:
            _notify("Background job already running")
        return
    core.queue_background_job(action, force=force)
    _notify("Queued: {0}".format(action))


def show_status() -> None:
    state = core.background_job_state()
    stats = core.cache_stats(core.load_cache())
    resolver = core.clearlogo_resolver_status_1547()
    lines = [
        "Role: rating database/scraper owner",
        "Background status: {0}".format(state.get("status") or "idle"),
        "Action: {0}".format(state.get("action") or ""),
        "Current: {0}".format(state.get("current") or ""),
        "Percent: {0}".format(state.get("percent") or ""),
        "",
        "Cache total: {0}".format(stats.get("total")),
        "Movies: {0}".format(stats.get("movie")),
        "TV shows: {0}".format(stats.get("tvshow")),
        "Episodes: {0}".format(stats.get("episode")),
        "With ratings: {0}".format(stats.get("with_ratings")),
        "IMDb Top250 movies: {0}".format(stats.get("imdb_top250", 0)),
        "IMDb Top250 TV: {0}".format(stats.get("imdb_top250_tv", 0)),
        "",
        "Clearlogo resolver rows: {0}".format(resolver.get("total", 0)),
        "Clearlogo resolver resolved: {0}".format(resolver.get("resolved", 0)),
        "Clearlogo resolver DB: {0}".format(resolver.get("path", "")),
    ]
    _show_text(TITLE + " - Status", "\n".join(str(x) for x in lines))


def export_diag() -> None:
    path = core.export_diagnostics_zip_1397()
    filename = os.path.basename(str(path or "")) or "UNKNOWN"
    try:
        icon = core.ADDON.getAddonInfo("icon") or xbmcgui.NOTIFICATION_INFO
    except Exception:
        icon = xbmcgui.NOTIFICATION_INFO
    _notify("DIAGNOSTICS EXPORTED - LRS-{0}".format(filename.split("lrs-", 1)[-1]), icon, 7000)


def _choose_rebuild_fill_cancel(title: str, message: str) -> str:
    """One AF3-style three-button confirmation dialog.

    Kodi yesnocustom return values:
    -1 = dialog closed, 0 = NO, 1 = YES, 2 = CUSTOM.
    Visual AF3 order is YES, NO, CUSTOM, so labels are mapped to
    Rebuild, Fill missing, Cancel respectively.
    """
    dialog = xbmcgui.Dialog()
    if hasattr(dialog, "yesnocustom"):
        default_yes = getattr(xbmcgui, "DLG_YESNO_YES_BTN", None)
        try:
            if default_yes is not None:
                result = dialog.yesnocustom(
                    title,
                    message,
                    "Cancel",
                    "Fill missing",
                    "Rebuild",
                    defaultbutton=default_yes,
                )
            else:
                result = dialog.yesnocustom(
                    title,
                    message,
                    "Cancel",
                    "Fill missing",
                    "Rebuild",
                )
        except TypeError:
            try:
                if default_yes is not None:
                    result = dialog.yesnocustom(
                        title,
                        message,
                        "Cancel",
                        "Fill missing",
                        "Rebuild",
                        0,
                        default_yes,
                    )
                else:
                    result = dialog.yesnocustom(
                        title,
                        message,
                        "Cancel",
                        "Fill missing",
                        "Rebuild",
                    )
            except TypeError:
                result = dialog.yesnocustom(
                    title,
                    message,
                    "Cancel",
                    "Fill missing",
                    "Rebuild",
                )
        if result == 1:
            return "rebuild"
        if result == 0:
            return "fill_missing"
        return "cancel"

    # Compatibility fallback for Kodi builds without yesnocustom.
    index = dialog.select(
        title,
        ["Rebuild", "Fill missing", "Cancel"],
        preselect=0,
    )
    if index == 0:
        return "rebuild"
    if index == 1:
        return "fill_missing"
    return "cancel"


def _execute_cropv2_batch(force: bool = False) -> None:
    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Reading cached clearlogos...")
    try:
        result = core.build_all_cropv2_1544(force=force, progress=progress)
    finally:
        try:
            progress.close()
        except Exception:
            pass

    _show_text(TITLE + " - CropV2 report", core.read_cropv2_batch_report_1544())
    if result.get("cancelled"):
        _notify("CropV2 cancelled")
    else:
        _notify(
            "CropV2: {0} generated, {1} cache-missing".format(
                result.get("generated_sources") or 0,
                result.get("cache_missing_sources") or 0,
            )
        )


def cropv2_action_dialog() -> None:
    status = core.cropv2_cache_status_1544()
    message = (
        "Build CropV2 for Kodi movies, Kodi TV shows, and active Steam games.\n\n"
        "Input image bytes: Kodi texture cache only\n"
        "Network fallback: disabled\n"
        "Hash: unchanged, md5 of canonical ListItem.Art source URL\n"
        "Crop algorithm: TMDbHelper-compatible transparent bbox\n\n"
        "Destination:\n{0}\n\n"
        "Existing files: {1}\n\n"
        "Rebuild replaces an existing file only when its cached source is available.\n"
        "Fill missing keeps existing files and builds only absent results."
    ).format(
        status.get("path") or "unknown",
        status.get("files") or 0,
    )
    action = _choose_rebuild_fill_cancel(TITLE + " - CropV2", message)
    if action == "rebuild":
        _execute_cropv2_batch(True)
    elif action == "fill_missing":
        _execute_cropv2_batch(False)


def _execute_clearlogo_resolver_cache(rebuild: bool = False) -> None:
    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Building resolver cache...")
    try:
        result = core.build_clearlogo_resolver_cache_1547(
            rebuild=rebuild,
            progress=progress,
        )
    finally:
        try:
            progress.close()
        except Exception:
            pass

    _show_text(
        TITLE + " - Resolver cache report",
        core.read_clearlogo_resolver_report_1547(),
    )
    if result.get("cancelled"):
        _notify("Resolver cache cancelled")
    else:
        _notify(
            "Resolver: {0} resolved, {1} missing".format(
                result.get("resolved") or 0,
                int(result.get("cropv2_missing") or 0)
                + int(result.get("no_source") or 0),
            )
        )


def resolver_cache_action_dialog() -> None:
    status = core.clearlogo_resolver_status_1547()
    message = (
        "Build the persistent clearlogo resolver cache for Kodi movies, "
        "Kodi TV shows, and active Steam games.\n\n"
        "Database:\n{0}\n\n"
        "Current rows: {1}\n"
        "Resolved: {2}\n"
        "Missing/no source: {3}\n\n"
        "No images are downloaded. The unchanged canonical clearlogo hash "
        "is mapped to an existing local CropV2 file.\n\n"
        "Rebuild checks every library item again.\n"
        "Fill missing processes only absent or unresolved entries."
    ).format(
        status.get("path") or "unknown",
        status.get("total") or 0,
        status.get("resolved") or 0,
        int(status.get("cropv2_missing") or 0)
        + int(status.get("no_source") or 0),
    )
    action = _choose_rebuild_fill_cancel(TITLE + " - Resolver cache", message)
    if action == "rebuild":
        _execute_clearlogo_resolver_cache(True)
    elif action == "fill_missing":
        _execute_clearlogo_resolver_cache(False)

def _run_kpm_runtime_shortcut() -> None:
    xbmc.executebuiltin('RunScript(script.kodi.patch.manager,artwork_runtime)')


def _direct_runtime_action(action: str) -> bool:
    action = str(action or '').strip().lower()
    if action == 'resolver_rebuild_engine':
        _execute_clearlogo_resolver_cache(True); return True
    if action == 'resolver_fill_engine':
        _execute_clearlogo_resolver_cache(False); return True
    if action == 'cropv2_rebuild_engine':
        _execute_cropv2_batch(True); return True
    if action == 'cropv2_fill_engine':
        _execute_cropv2_batch(False); return True
    if action == 'display_contract':
        core.build_display_contract_1640(); return True
    if action == 'runtime_status_engine':
        resolver = core.clearlogo_resolver_status_1547()
        crop = core.cropv2_cache_status_1544()
        _show_text('Kodi Patch Manager - Artwork Runtime Status',
                   ('Resolver DB: {0}\nRows: {1}\nResolved: {2}\nMissing: {3}'
                    '\n\nCropV2 path: {4}\nFiles: {5}').format(
                       resolver.get('path') or '-', resolver.get('total') or 0,
                       resolver.get('resolved') or 0,
                       int(resolver.get('cropv2_missing') or 0)+int(resolver.get('no_source') or 0),
                       crop.get('path') or '-', crop.get('files') or 0))
        return True
    return False

def main() -> None:
    actions = [
        ("Refresh All Rating Data", lambda: _queue("scrape", True)),
        ("Scrape Missing Rating Data", lambda: _queue("scrape", False)),
        ("Scrape Missing RT Badges Only", lambda: _queue("rtbadges", False)),
        ("Scrape Awards Only", lambda: _queue("awards", False)),
        ("Update IMDb Top 250 Only", lambda: _queue("top250", False)),
        ("View Status", show_status),
        ("Export diagnostics ZIP", export_diag),
        (
            "Settings",
            lambda: xbmc.executebuiltin(
                "Addon.OpenSettings(script.library.ratings.scraper)"
            ),
        ),
        ("Exit", None),
    ]
    idx = xbmcgui.Dialog().select(TITLE, [row[0] for row in actions])
    if idx < 0 or idx >= len(actions) - 1:
        return
    actions[idx][1]()


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and _direct_runtime_action(sys.argv[1]):
        pass
    else:
        main()

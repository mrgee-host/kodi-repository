Library Ratings Scraper 1.5.48
================================

- CropV2 bounding boxes now ignore alpha values 1-3 using threshold 4.
- No extra padding is added.
- Adds a local-only repair action for existing cropped PNGs.
- The repair reads only existing crop_v2 files, does not open source artwork,
  does not use internet, and does not rescale the logo.
- Persistent resolver file size/mtime metadata is refreshed automatically for
  repaired paths, and the RAM hot cache is cleared.

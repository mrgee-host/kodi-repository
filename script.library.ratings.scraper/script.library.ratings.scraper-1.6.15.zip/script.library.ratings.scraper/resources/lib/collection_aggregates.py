# -*- coding: utf-8 -*-
from __future__ import annotations

import glob
import hashlib
import json
import os
import re
import sqlite3
import threading
import time
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Any, Dict, Iterable, List, Optional, Tuple

import xbmc
import xbmcgui
import xbmcvfs

from resources.lib import core

SCHEMA_VERSION = "2"
DB_FILE = os.path.join(core.PROFILE, "collection-aggregates.db")
_REFRESH_LOCK = threading.Lock()
_LAST_SOURCE_SIGNATURE = ""
_LAST_PUBLISHED_KEY = ""
_LAST_PUBLISHED_GENERATION = -1
_LAST_PUBLISHED_SHOWN = False
_CACHE_GENERATION = 0

_SUMMARY_COLUMNS = (
    "id_set", "name", "plot", "custom_tagline", "summary", "member_count",
    "year_start", "year_end", "year_known_count", "runtime_total_seconds",
    "runtime_known_count", "star_source", "star_rating", "members_fingerprint",
    "ratings_fingerprint", "updated_at",
)
_RATING_SOURCES = (
    "imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd",
)
_RATING_DB_COLUMNS = {
    "imdb": "imdb",
    "tmdb": "tmdb",
    "rt_critic": "rottentomatoes",
    "rt_audience": "rottentomatoes_user",
    "metacritic": "metacritic",
    "trakt": "trakt",
    "letterboxd": "letterboxd",
}
_PROPERTY_NAMES = (
    "Visible", "ItemKey", "IDSet", "Title", "Plot", "CustomTagline", "Summary",
    "DisplayTagline", "MemberCount", "YearStart", "YearEnd", "YearRange",
    "RuntimeTotalSeconds", "RuntimeDisplay", "StarSource", "StarRating",
    "MembersFingerprint", "RatingsFingerprint", "UpdatedAt",
)


def _log(message: str, level: int = xbmc.LOGDEBUG) -> None:
    try:
        core.log("Collection aggregates: " + str(message), level)
    except Exception:
        pass


def _connect() -> sqlite3.Connection:
    os.makedirs(core.PROFILE, exist_ok=True)
    con = sqlite3.connect(DB_FILE, timeout=30.0)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=30000")
    con.execute("PRAGMA journal_mode=WAL")
    con.execute("PRAGMA synchronous=NORMAL")
    try:
        tables = {
            row[0] for row in con.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'"
            ).fetchall()
        }
        if not tables:
            con.execute("BEGIN IMMEDIATE")
            con.execute(
                """CREATE TABLE collection_summary (
                    id_set INTEGER PRIMARY KEY,
                    name TEXT NOT NULL,
                    plot TEXT,
                    custom_tagline TEXT,
                    summary TEXT,
                    member_count INTEGER NOT NULL,
                    year_start INTEGER,
                    year_end INTEGER,
                    year_known_count INTEGER NOT NULL,
                    runtime_total_seconds INTEGER NOT NULL,
                    runtime_known_count INTEGER NOT NULL,
                    star_source TEXT,
                    star_rating REAL,
                    members_fingerprint TEXT NOT NULL,
                    ratings_fingerprint TEXT NOT NULL,
                    updated_at INTEGER NOT NULL
                )"""
            )
            con.execute(
                """CREATE TABLE collection_ratings (
                    id_set INTEGER NOT NULL,
                    source TEXT NOT NULL,
                    rating_value REAL,
                    rated_count INTEGER NOT NULL,
                    member_count INTEGER NOT NULL,
                    updated_at INTEGER NOT NULL,
                    PRIMARY KEY(id_set, source)
                )"""
            )
            con.execute(
                """CREATE TABLE collection_members (
                    id_set INTEGER NOT NULL,
                    id_movie INTEGER NOT NULL,
                    movie_fingerprint TEXT NOT NULL,
                    PRIMARY KEY(id_set, id_movie)
                )"""
            )
            con.execute("CREATE TABLE metadata (key TEXT PRIMARY KEY, value TEXT)")
            con.execute("CREATE INDEX idx_collection_summary_name ON collection_summary(name COLLATE NOCASE)")
            con.execute("CREATE INDEX idx_collection_members_movie ON collection_members(id_movie)")
            con.execute("INSERT INTO metadata(key,value) VALUES('schema_version',?)", (SCHEMA_VERSION,))
            con.commit()
        else:
            required = {"collection_summary", "collection_ratings", "collection_members", "metadata"}
            if tables != required:
                raise sqlite3.DatabaseError(
                    "collection-aggregates.db uses an unsupported schema; fresh install required, no migration is performed"
                )
            version_row = con.execute("SELECT value FROM metadata WHERE key='schema_version'").fetchone()
            if not version_row or str(version_row[0]) != SCHEMA_VERSION:
                raise sqlite3.DatabaseError(
                    "collection-aggregates.db schema version is unsupported; fresh install required, no migration is performed"
                )
            actual = [row[1] for row in con.execute("PRAGMA table_info(collection_summary)").fetchall()]
            if tuple(actual) != _SUMMARY_COLUMNS:
                raise sqlite3.DatabaseError(
                    "collection-aggregates.db column layout is unsupported; fresh install required, no migration is performed"
                )
        return con
    except Exception:
        try:
            con.rollback()
        except Exception:
            pass
        con.close()
        raise


def _latest_video_db() -> str:
    db_dir = xbmcvfs.translatePath("special://profile/Database")
    candidates = []
    for path in glob.glob(os.path.join(db_dir, "MyVideos*.db")):
        match = re.search(r"MyVideos(\d+)\.db$", os.path.basename(path), re.I)
        version = int(match.group(1)) if match else -1
        try:
            mtime = os.path.getmtime(path)
        except OSError:
            mtime = 0.0
        candidates.append((version, mtime, path))
    candidates.sort(reverse=True)
    return candidates[0][2] if candidates else ""


def _source_signature(video_db: str, ratings_db: str) -> str:
    parts = []
    for path in (video_db, ratings_db):
        try:
            stat = os.stat(path)
            parts.append("{}:{}:{}".format(os.path.abspath(path), int(stat.st_mtime_ns), int(stat.st_size)))
        except OSError:
            parts.append("{}:missing".format(os.path.abspath(path)))
    return hashlib.sha1("|".join(parts).encode("utf-8")).hexdigest()


def _year(value: Any) -> Optional[int]:
    match = re.search(r"(?:19|20)\d{2}", str(value or ""))
    return int(match.group(0)) if match else None


def _runtime(value: Any) -> Optional[int]:
    try:
        number = int(float(str(value or "").strip()))
        return number if number > 0 else None
    except (TypeError, ValueError):
        return None


def _numeric(value: Any) -> Optional[float]:
    if value is None:
        return None
    text = str(value).strip()
    if not text or text.upper() in ("N/A", "NA", "NONE", "NULL", "NO_RATING"):
        return None
    match = re.search(r"-?\d+(?:[.,]\d+)?", text)
    if not match:
        return None
    try:
        number = float(match.group(0).replace(",", "."))
    except ValueError:
        return None
    return number if number > 0 else None


def _average(values: Iterable[Optional[float]]) -> Tuple[Optional[float], int]:
    clean = [float(value) for value in values if value is not None]
    if not clean:
        return None, 0
    return sum(clean) / float(len(clean)), len(clean)


def _one_decimal(value: Optional[float]) -> Optional[float]:
    """Normalize aggregate ratings to one decimal at the persistence boundary.

    Source ratings-cache.db values remain untouched. SQLite receives a float so
    whole values are stored as REAL values such as 73.0.
    """
    if value is None:
        return None
    try:
        return float(Decimal(str(value)).quantize(Decimal("0.1"), rounding=ROUND_HALF_UP))
    except (InvalidOperation, TypeError, ValueError):
        return None


def _runtime_display(seconds: int) -> str:
    seconds = max(0, int(seconds or 0))
    minutes = int(round(seconds / 60.0))
    hours, remainder = divmod(minutes, 60)
    if hours and remainder:
        return "{}h {}m".format(hours, remainder)
    if hours:
        return "{}h".format(hours)
    return "{}m".format(remainder) if remainder else ""


def _summary_text(member_count: int, year_range: str = "", runtime_display: str = "") -> str:
    del year_range, runtime_display
    return "{} FILM{}".format(member_count, "" if member_count == 1 else "S")


def _rating_record(values: Dict[str, Optional[float]]) -> Dict[str, Any]:
    ratings: Dict[str, Dict[str, Any]] = {}
    for source, value in values.items():
        if value is None:
            continue
        provider = "mdblist" if source == "letterboxd" else "collection"
        display_value: Any = value
        if source == "letterboxd":
            # Individual Letterboxd rows are strict integer scores from 1..100.
            # A collection mean can be fractional, so round only the published
            # aggregate while retaining the exact mean in collection_ratings.
            display_value = int(float(value) + 0.5)
        row = {
            "source": source,
            "provider": provider,
            "value": display_value,
            "score": display_value,
            "votes": "",
        }
        ratings[source] = row
    return {"type": "movie", "media_type": "movie", "ratings": ratings}


def _collection_name_key(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value or "").strip().lower())


def _uses_top_coverage_policy(name: Any) -> bool:
    # Deliberate single-collection exception requested by the project owner.
    return _collection_name_key(name) in {
        "indonesianmoviescollection",
        "indonesiamoviescollection",
    }


def _stored_rating_sources(
    name: Any,
    averages: Dict[str, Optional[float]],
    counts: Dict[str, int],
    member_count: int,
) -> List[str]:
    if _uses_top_coverage_policy(name):
        ranked = sorted(
            (
                source for source in _RATING_SOURCES
                if averages.get(source) is not None and int(counts.get(source, 0)) > 0
            ),
            key=lambda source: (-int(counts.get(source, 0)), _RATING_SOURCES.index(source)),
        )
        return ranked[:3]
    return [
        source for source in _RATING_SOURCES
        if averages.get(source) is not None and int(counts.get(source, 0)) == int(member_count)
    ]


def build_from_paths(video_db: str, ratings_db: str, output_db: Optional[str] = None, source_signature: str = "") -> Dict[str, Any]:
    """Build or refresh aggregate rows from explicit database paths.

    This function is also used by validation outside Kodi. It never changes the
    source databases.
    """
    global DB_FILE
    original_db = DB_FILE
    if output_db:
        DB_FILE = output_db
    try:
        video = sqlite3.connect("file:{}?mode=ro".format(video_db.replace("\\", "/")), uri=True, timeout=30)
        video.row_factory = sqlite3.Row
        ratings = sqlite3.connect("file:{}?mode=ro".format(ratings_db.replace("\\", "/")), uri=True, timeout=30)
        ratings.row_factory = sqlite3.Row
        target = _connect()
        try:
            rating_rows = {
                int(row["dbid"]): dict(row)
                for row in ratings.execute(
                    "SELECT * FROM ratings WHERE media_type='movie' AND dbid IS NOT NULL"
                ).fetchall()
            }
            sets = video.execute(
                "SELECT idSet,strSet,strOverview,strOriginalSet FROM sets ORDER BY idSet"
            ).fetchall()
            movie_rows = video.execute(
                "SELECT idMovie,idSet,c00,c03,c11,premiered FROM movie WHERE idSet IS NOT NULL AND idSet>0 ORDER BY idSet,idMovie"
            ).fetchall()
            by_set: Dict[int, List[sqlite3.Row]] = {}
            for row in movie_rows:
                by_set.setdefault(int(row["idSet"]), []).append(row)

            current_ids = set()
            changed = 0
            unchanged = 0
            created = 0
            now = int(time.time())
            write_started = False

            def ensure_write() -> None:
                nonlocal write_started
                if not write_started:
                    target.execute("BEGIN IMMEDIATE")
                    write_started = True

            for set_row in sets:
                id_set = int(set_row["idSet"])
                members = by_set.get(id_set, [])
                if not members:
                    continue
                current_ids.add(id_set)
                member_payload = []
                rating_payload = []
                years: List[int] = []
                runtimes: List[int] = []
                per_source: Dict[str, List[Optional[float]]] = {source: [] for source in _RATING_SOURCES}
                member_fingerprints: Dict[int, str] = {}
                for movie in members:
                    id_movie = int(movie["idMovie"])
                    year = _year(movie["premiered"])
                    runtime = _runtime(movie["c11"])
                    if year is not None:
                        years.append(year)
                    if runtime is not None:
                        runtimes.append(runtime)
                    raw_rating = rating_rows.get(id_movie, {})
                    source_values = {
                        source: _numeric(raw_rating.get(column))
                        for source, column in _RATING_DB_COLUMNS.items()
                    }
                    for source, value in source_values.items():
                        per_source[source].append(value)
                    member_payload.append((id_movie, str(movie["c00"] or ""), year, runtime))
                    rating_payload.append((id_movie, source_values, str(raw_rating.get("updated_at") or "")))
                    member_fingerprints[id_movie] = hashlib.sha1(
                        json.dumps(member_payload[-1], ensure_ascii=False, sort_keys=True).encode("utf-8")
                    ).hexdigest()

                members_fp = hashlib.sha1(
                    json.dumps(
                        {
                            "set": [id_set, str(set_row["strSet"] or ""), str(set_row["strOverview"] or "")],
                            "members": member_payload,
                        },
                        ensure_ascii=False,
                        sort_keys=True,
                    ).encode("utf-8")
                ).hexdigest()
                ratings_fp = hashlib.sha1(
                    json.dumps(rating_payload, ensure_ascii=False, sort_keys=True).encode("utf-8")
                ).hexdigest()
                existing = target.execute(
                    "SELECT members_fingerprint,ratings_fingerprint FROM collection_summary WHERE id_set=?",
                    (id_set,),
                ).fetchone()
                if existing and existing[0] == members_fp and existing[1] == ratings_fp:
                    unchanged += 1
                    continue

                averages: Dict[str, Optional[float]] = {}
                counts: Dict[str, int] = {}
                for source in _RATING_SOURCES:
                    averages[source], counts[source] = _average(per_source[source])
                star_source = "imdb" if averages.get("imdb") is not None else ("tmdb" if averages.get("tmdb") is not None else "")
                star_rating = _one_decimal(averages.get(star_source)) if star_source else None
                year_start = min(years) if years else None
                year_end = max(years) if years else None
                year_range = ""
                if year_start is not None and year_end is not None and len(years) == len(members):
                    year_range = str(year_start) if year_start == year_end else "{}–{}".format(year_start, year_end)
                runtime_total = sum(runtimes)
                runtime_display = _runtime_display(runtime_total) if len(runtimes) == len(members) else ""
                summary = _summary_text(len(members), year_range, runtime_display)
                ensure_write()
                target.execute(
                    """INSERT INTO collection_summary(
                        id_set,name,plot,custom_tagline,summary,member_count,year_start,year_end,
                        year_known_count,runtime_total_seconds,runtime_known_count,star_source,
                        star_rating,members_fingerprint,ratings_fingerprint,updated_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON CONFLICT(id_set) DO UPDATE SET
                        name=excluded.name,plot=excluded.plot,custom_tagline=collection_summary.custom_tagline,
                        summary=excluded.summary,member_count=excluded.member_count,
                        year_start=excluded.year_start,year_end=excluded.year_end,
                        year_known_count=excluded.year_known_count,
                        runtime_total_seconds=excluded.runtime_total_seconds,
                        runtime_known_count=excluded.runtime_known_count,
                        star_source=excluded.star_source,star_rating=excluded.star_rating,
                        members_fingerprint=excluded.members_fingerprint,
                        ratings_fingerprint=excluded.ratings_fingerprint,updated_at=excluded.updated_at""",
                    (
                        id_set, str(set_row["strSet"] or ""), str(set_row["strOverview"] or ""), "", summary,
                        len(members), year_start, year_end, len(years), runtime_total, len(runtimes),
                        star_source, star_rating, members_fp, ratings_fp, now,
                    ),
                )
                target.execute("DELETE FROM collection_ratings WHERE id_set=?", (id_set,))
                stored_sources = set(
                    _stored_rating_sources(
                        str(set_row["strSet"] or ""), averages, counts, len(members)
                    )
                )
                for source in _RATING_SOURCES:
                    # Normal collections remain strict full-coverage. Only the
                    # Indonesian Movies Collection stores its three sources with
                    # the greatest member coverage; rated_count stays explicit.
                    if source not in stored_sources:
                        continue
                    target.execute(
                        "INSERT INTO collection_ratings(id_set,source,rating_value,rated_count,member_count,updated_at) VALUES(?,?,?,?,?,?)",
                        (id_set, source, _one_decimal(averages[source]), counts[source], len(members), now),
                    )
                target.execute("DELETE FROM collection_members WHERE id_set=?", (id_set,))
                for id_movie, fingerprint in member_fingerprints.items():
                    target.execute(
                        "INSERT INTO collection_members(id_set,id_movie,movie_fingerprint) VALUES(?,?,?)",
                        (id_set, id_movie, fingerprint),
                    )
                if existing:
                    changed += 1
                else:
                    created += 1

            stale = [
                int(row[0]) for row in target.execute("SELECT id_set FROM collection_summary").fetchall()
                if int(row[0]) not in current_ids
            ]
            if stale:
                ensure_write()
            for id_set in stale:
                target.execute("DELETE FROM collection_summary WHERE id_set=?", (id_set,))
                target.execute("DELETE FROM collection_ratings WHERE id_set=?", (id_set,))
                target.execute("DELETE FROM collection_members WHERE id_set=?", (id_set,))
            metadata_values = {
                "source_video_db": video_db,
                "source_ratings_db": ratings_db,
                "source_signature": source_signature or _source_signature(video_db, ratings_db),
            }
            metadata_changed = any(
                (target.execute("SELECT value FROM metadata WHERE key=?", (key,)).fetchone() or [None])[0] != value
                for key, value in metadata_values.items()
            )
            if metadata_changed:
                ensure_write()
            if write_started:
                metadata_values["last_refresh"] = str(now)
                for key, value in metadata_values.items():
                    target.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)", (key, value))
                target.commit()
            return {
                "ok": True,
                "sets": len(current_ids),
                "created": created,
                "changed": changed,
                "unchanged": unchanged,
                "removed": len(stale),
                "database_write": write_started,
                "database": DB_FILE,
            }
        except Exception:
            target.rollback()
            raise
        finally:
            target.close()
            ratings.close()
            video.close()
    finally:
        DB_FILE = original_db


def _stored_source_signature() -> str:
    if not os.path.isfile(DB_FILE):
        return ""
    con = _connect()
    try:
        row = con.execute("SELECT value FROM metadata WHERE key='source_signature'").fetchone()
        return str(row[0] or "") if row else ""
    finally:
        con.close()


def rebuild_if_changed(force: bool = False) -> Dict[str, Any]:
    global _LAST_SOURCE_SIGNATURE, _CACHE_GENERATION
    if not _REFRESH_LOCK.acquire(False):
        return {"ok": True, "busy": True}
    try:
        video_db = _latest_video_db()
        ratings_db = core.CACHE_DB_FILE
        if not video_db or not os.path.isfile(video_db):
            return {"ok": False, "error": "MyVideos database not found"}
        if not ratings_db or not os.path.isfile(ratings_db):
            return {"ok": False, "error": "ratings-cache.db not found"}
        signature = _source_signature(video_db, ratings_db)
        if not force and os.path.isfile(DB_FILE):
            if signature == _LAST_SOURCE_SIGNATURE:
                return {"ok": True, "unchanged_source": True, "persistent": False}
            stored = _stored_source_signature()
            if signature == stored:
                _LAST_SOURCE_SIGNATURE = signature
                return {"ok": True, "unchanged_source": True, "persistent": True}
        result = build_from_paths(video_db, ratings_db, source_signature=signature)
        _LAST_SOURCE_SIGNATURE = signature
        _CACHE_GENERATION += 1
        if result.get("created") or result.get("changed") or result.get("removed"):
            _log(
                "refresh sets={sets} created={created} changed={changed} removed={removed} unchanged={unchanged}".format(**result),
                xbmc.LOGINFO,
            )
        return result
    except Exception as exc:
        _log("refresh failed: {}".format(exc), xbmc.LOGERROR)
        return {"ok": False, "error": str(exc)}
    finally:
        _REFRESH_LOCK.release()


def _item_type(item: Dict[str, Any]) -> str:
    for key in ("type", "DBType", "dbtype", "DBTYPE", "MediaType", "mediatype", "lrs_item_type"):
        value = str((item or {}).get(key) or "").strip().lower()
        if value:
            return "set" if value in ("set", "sets", "collection", "collections") else value
    path = str((item or {}).get("file") or (item or {}).get("path") or (item or {}).get("FolderPath") or "").lower()
    return "set" if "videodb://movies/sets" in path else ""


def is_collection_item(item: Dict[str, Any]) -> bool:
    return _item_type(item or {}) == "set"


def _item_id_set(item: Dict[str, Any]) -> Optional[int]:
    for key in ("dbid", "DBID", "DBId", "idSet", "setid", "set_id"):
        value = core.safe_int((item or {}).get(key))
        if value is not None and value > 0:
            return value
    return None


def _item_title(item: Dict[str, Any]) -> str:
    for key in ("title", "label", "Title", "Label", "set", "collection"):
        value = str((item or {}).get(key) or "").strip()
        if value:
            return value
    return ""


def load_for_item(item: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    if not is_collection_item(item):
        return None
    try:
        con = _connect()
        try:
            id_set = _item_id_set(item)
            row = None
            if id_set is not None:
                row = con.execute("SELECT * FROM collection_summary WHERE id_set=?", (id_set,)).fetchone()
            if row is None:
                title = _item_title(item)
                if title:
                    row = con.execute(
                        "SELECT * FROM collection_summary WHERE name=? COLLATE NOCASE",
                        (title,),
                    ).fetchone()
            if row is None:
                return None
            out = dict(row)
            out["ratings"] = {
                str(rating["source"]): {
                    "value": rating["rating_value"],
                    "rated_count": int(rating["rated_count"] or 0),
                    "member_count": int(rating["member_count"] or 0),
                }
                for rating in con.execute(
                    "SELECT source,rating_value,rated_count,member_count FROM collection_ratings WHERE id_set=?",
                    (int(row["id_set"]),),
                ).fetchall()
            }
            return out
        finally:
            con.close()
    except Exception as exc:
        _log("load failed: {}".format(exc), xbmc.LOGWARNING)
        return None


def _home() -> xbmcgui.Window:
    return xbmcgui.Window(10000)


def _set_prop(name: str, value: Any) -> None:
    try:
        _home().setProperty("LibraryRatings.Collection." + name, str(value if value is not None else ""))
    except Exception:
        pass


def clear_properties() -> None:
    global _LAST_PUBLISHED_KEY, _LAST_PUBLISHED_GENERATION, _LAST_PUBLISHED_SHOWN
    if not _LAST_PUBLISHED_KEY:
        return
    for name in _PROPERTY_NAMES:
        try:
            _home().clearProperty("LibraryRatings.Collection." + name)
        except Exception:
            pass
    _LAST_PUBLISHED_KEY = ""
    _LAST_PUBLISHED_GENERATION = -1
    _LAST_PUBLISHED_SHOWN = False


def publish_for_item(item: Dict[str, Any]) -> bool:
    global _LAST_PUBLISHED_KEY, _LAST_PUBLISHED_GENERATION, _LAST_PUBLISHED_SHOWN
    id_set_hint = _item_id_set(item)
    title_hint = _item_title(item).casefold()
    requested_key = "set|{}".format(id_set_hint) if id_set_hint is not None else "settitle|{}".format(title_hint)
    if requested_key == _LAST_PUBLISHED_KEY and _LAST_PUBLISHED_GENERATION == _CACHE_GENERATION:
        return _LAST_PUBLISHED_SHOWN
    payload = load_for_item(item)
    if not payload:
        clear_properties()
        _LAST_PUBLISHED_KEY = requested_key
        _LAST_PUBLISHED_GENERATION = _CACHE_GENERATION
        _LAST_PUBLISHED_SHOWN = False
        try:
            core.publish_homehub_display_active_1528(False)
        except Exception:
            pass
        return False
    id_set = int(payload["id_set"])
    item_key = "set|{}".format(id_set)
    member_count = int(payload.get("member_count") or 0)
    year_known = int(payload.get("year_known_count") or 0)
    year_start = payload.get("year_start")
    year_end = payload.get("year_end")
    year_range = ""
    if member_count and year_known == member_count and year_start and year_end:
        year_range = str(year_start) if int(year_start) == int(year_end) else "{}–{}".format(year_start, year_end)
    runtime_known = int(payload.get("runtime_known_count") or 0)
    runtime_seconds = int(payload.get("runtime_total_seconds") or 0)
    runtime_display = _runtime_display(runtime_seconds) if member_count and runtime_known == member_count else ""
    display_tagline = str(payload.get("custom_tagline") or "").strip() or str(payload.get("summary") or "").strip()
    values = {
        source: (payload.get("ratings") or {}).get(source, {}).get("value")
        for source in _RATING_SOURCES
    }
    record = _rating_record(values)
    record.update({"title": str(payload.get("name") or ""), "type": "movie", "media_type": "movie"})
    af3 = core.af3_values(record)
    af3["DBType"] = "set"
    af3["Title"] = str(payload.get("name") or "")
    af3["SourceContext"] = "collection"
    af3["DisplayMode"] = "strict-current"
    lower_row_shown = bool(core.publish_homehub_display_1528(af3, item_key, "collection", True, mode="strict-current"))
    # The top collection line is valid whenever the aggregate payload exists.
    # The lower numeric row may legitimately be empty under full-coverage rules.
    collection_visible = True
    props = {
        "Visible": "true",
        "ItemKey": item_key,
        "IDSet": id_set,
        "Title": payload.get("name") or "",
        "Plot": payload.get("plot") or "",
        "CustomTagline": payload.get("custom_tagline") or "",
        "Summary": payload.get("summary") or "",
        "DisplayTagline": display_tagline,
        "MemberCount": member_count,
        "YearStart": year_start or "",
        "YearEnd": year_end or "",
        "YearRange": year_range,
        "RuntimeTotalSeconds": runtime_seconds if runtime_display else "",
        "RuntimeDisplay": runtime_display,
        "StarSource": payload.get("star_source") or "",
        "StarRating": payload.get("star_rating") if payload.get("star_rating") is not None else "",
        "MembersFingerprint": payload.get("members_fingerprint") or "",
        "RatingsFingerprint": payload.get("ratings_fingerprint") or "",
        "UpdatedAt": payload.get("updated_at") or "",
    }
    for name, value in props.items():
        _set_prop(name, value)
    _LAST_PUBLISHED_KEY = item_key
    _LAST_PUBLISHED_GENERATION = _CACHE_GENERATION
    _LAST_PUBLISHED_SHOWN = collection_visible
    return collection_visible


def worker() -> None:
    monitor = xbmc.Monitor()
    rebuild_if_changed(force=False)
    while not monitor.waitForAbort(30.0):
        rebuild_if_changed(force=False)

# -*- coding: utf-8 -*-
from __future__ import annotations

import xbmc
import xbmcgui
from resources.lib import core

TITLE = "Library Ratings Scraper"


def _notify(msg: str) -> None:
    xbmcgui.Dialog().notification(TITLE, msg, xbmcgui.NOTIFICATION_INFO, 4000, False)


def _show_text(title: str, body: str) -> None:
    """Use Kodi's scrollable DialogTextViewer for every status/result/report."""
    xbmcgui.Dialog().textviewer(title, str(body or ""))


def _queue(action: str, force: bool = False) -> None:
    state = core.background_job_state()
    if core.background_state_is_active(state):
        if xbmcgui.Dialog().yesno(
            TITLE,
            "Background job is already running or stuck.\n\nReset state now?",
            nolabel="Cancel",
            yeslabel="Reset",
        ):
            core.reset_background_job_state("Manual stuck-state reset")
            _notify("Background state reset")
        else:
            _notify("Background job already running")
        return
    core.queue_background_job(action, force=force)
    _notify("Queued: {0}".format(action))


def show_status() -> None:
    state = core.background_job_state()
    stats = core.cache_stats(core.load_cache())
    resolver = core.clearlogo_resolver_status_1547()
    lines = [
        "Role: rating database/scraper owner",
        "Background status: {0}".format(state.get("status") or "idle"),
        "Action: {0}".format(state.get("action") or ""),
        "Current: {0}".format(state.get("current") or ""),
        "Percent: {0}".format(state.get("percent") or ""),
        "",
        "Cache total: {0}".format(stats.get("total")),
        "Movies: {0}".format(stats.get("movie")),
        "TV shows: {0}".format(stats.get("tvshow")),
        "Episodes: {0}".format(stats.get("episode")),
        "With ratings: {0}".format(stats.get("with_ratings")),
        "IMDb Top250 movies: {0}".format(stats.get("imdb_top250", 0)),
        "IMDb Top250 TV: {0}".format(stats.get("imdb_top250_tv", 0)),
        "",
        "Clearlogo resolver rows: {0}".format(resolver.get("total", 0)),
        "Clearlogo resolver resolved: {0}".format(resolver.get("resolved", 0)),
        "Clearlogo resolver DB: {0}".format(resolver.get("path", "")),
    ]
    _show_text(TITLE + " - Status", "\n".join(str(x) for x in lines))


def export_diag() -> None:
    path = core.export_diagnostics_zip_1397()
    _show_text(
        TITLE + " - Diagnostics export",
        "Diagnostics exported:\n\n{0}".format(path or "unknown"),
    )


def _run_cropv2_batch(force: bool = False) -> None:
    status = core.cropv2_cache_status_1544()
    mode = "REBUILD" if force else "FILL MISSING"
    message = (
        "{0} CropV2 for Kodi movies, Kodi TV shows, and active Steam games.\n\n"
        "Input image bytes: Kodi texture cache only\n"
        "Network fallback: disabled\n"
        "Hash: unchanged, md5 of canonical ListItem.Art source URL\n"
        "Crop algorithm: TMDbHelper-compatible transparent bbox\n\n"
        "Destination:\n{1}\n\n"
        "Existing files: {2}\n\n"
        "{3}"
    ).format(
        mode,
        status.get("path") or "unknown",
        status.get("files") or 0,
        (
            "Existing files are replaced only when a cached source is available."
            if force
            else "Existing files are kept; only missing files are built."
        ),
    )
    if not xbmcgui.Dialog().yesno(
        TITLE + " - CropV2",
        message,
        nolabel="Cancel",
        yeslabel="Start",
    ):
        return

    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Reading cached clearlogos...")
    try:
        result = core.build_all_cropv2_1544(force=force, progress=progress)
    finally:
        try:
            progress.close()
        except Exception:
            pass

    _show_text(TITLE + " - CropV2 report", core.read_cropv2_batch_report_1544())
    if result.get("cancelled"):
        _notify("CropV2 cancelled")
    else:
        _notify(
            "CropV2: {0} generated, {1} cache-missing".format(
                result.get("generated_sources") or 0,
                result.get("cache_missing_sources") or 0,
            )
        )


def _run_clearlogo_resolver_cache(rebuild: bool = False) -> None:
    status = core.clearlogo_resolver_status_1547()
    mode = "REBUILD" if rebuild else "FILL MISSING"
    message = (
        "{0} persistent resolver cache for Kodi movies, Kodi TV shows, "
        "and active Steam games.\n\n"
        "Database:\n{1}\n\n"
        "Current rows: {2}\n"
        "Resolved: {3}\n"
        "Missing/no source: {4}\n\n"
        "This operation never downloads images. It maps the unchanged "
        "canonical clearlogo hash to existing CropV2 files."
    ).format(
        mode,
        status.get("path") or "unknown",
        status.get("total") or 0,
        status.get("resolved") or 0,
        int(status.get("cropv2_missing") or 0)
        + int(status.get("no_source") or 0),
    )
    if not xbmcgui.Dialog().yesno(
        TITLE + " - Resolver cache",
        message,
        nolabel="Cancel",
        yeslabel="Start",
    ):
        return

    progress = xbmcgui.DialogProgress()
    progress.create(TITLE, "Building resolver cache...")
    try:
        result = core.build_clearlogo_resolver_cache_1547(
            rebuild=rebuild,
            progress=progress,
        )
    finally:
        try:
            progress.close()
        except Exception:
            pass

    _show_text(
        TITLE + " - Resolver cache report",
        core.read_clearlogo_resolver_report_1547(),
    )
    if result.get("cancelled"):
        _notify("Resolver cache cancelled")
    else:
        _notify(
            "Resolver: {0} resolved, {1} missing".format(
                result.get("resolved") or 0,
                int(result.get("cropv2_missing") or 0)
                + int(result.get("no_source") or 0),
            )
        )


def _submenu(title: str, actions) -> None:
    labels = [row[0] for row in actions] + ["Back"]
    index = xbmcgui.Dialog().select(title, labels)
    if index < 0 or index >= len(actions):
        return
    actions[index][1]()


def resolver_cache_menu() -> None:
    _submenu(
        TITLE + " - Resolver cache",
        [
            ("Rebuild", lambda: _run_clearlogo_resolver_cache(True)),
            ("Fill missing", lambda: _run_clearlogo_resolver_cache(False)),
        ],
    )


def cropv2_menu() -> None:
    _submenu(
        TITLE + " - CropV2",
        [
            ("Rebuild", lambda: _run_cropv2_batch(True)),
            ("Fill missing", lambda: _run_cropv2_batch(False)),
        ],
    )


def main() -> None:
    actions = [
        ("Refresh all rating data", lambda: _queue("scrape", True)),
        ("Scrape missing rating data", lambda: _queue("scrape", False)),
        ("Scrape missing RT badges only", lambda: _queue("rtbadges", False)),
        ("Scrape awards only", lambda: _queue("awards", False)),
        ("Update IMDb Top 250 only", lambda: _queue("top250", False)),
        ("Resolver cache", resolver_cache_menu),
        ("CropV2", cropv2_menu),
        ("View status", show_status),
        ("Export diagnostics ZIP", export_diag),
        (
            "Settings",
            lambda: xbmc.executebuiltin(
                "Addon.OpenSettings(script.library.ratings.scraper)"
            ),
        ),
        ("Exit", None),
    ]
    idx = xbmcgui.Dialog().select(TITLE, [row[0] for row in actions])
    if idx < 0 or idx >= len(actions) - 1:
        return
    actions[idx][1]()


if __name__ == "__main__":
    main()

# -*- coding: utf-8 -*-
"""Library Ratings Scraper core - v1.3.29 simplified manual flow."""
from __future__ import annotations

import csv
import json
import os
import random
import re
import time
from datetime import datetime, timezone
from typing import Any, Dict, Iterable, List, Optional, Tuple
from urllib.parse import urlencode, quote
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

import xbmc  # type: ignore
import xbmcaddon  # type: ignore
import xbmcgui  # type: ignore
import xbmcvfs  # type: ignore

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
ADDON_PATH = xbmcvfs.translatePath(ADDON.getAddonInfo("path"))
CACHE_FILE = os.path.join(PROFILE, "ratings-cache.json")
REPORT_FILE = os.path.join(PROFILE, "ratings-report.csv")
SUMMARY_FILE = os.path.join(PROFILE, "last-run-summary.json")
LIVE_CHECK_FILE = os.path.join(PROFILE, "last-random-check-debug.txt")
TOP_TV_FILE = os.path.join(ADDON_PATH, "resources", "data", "imdb_top_tv_shows_with_id.json")

NO_RATING_VALUE = "NO_RATING"
NO_RATING_PROVIDER = "unavailable"
USER_AGENT = "Kodi-Library-Ratings-Scraper/1.3.29"

MOVIE_SERIES_RATINGS = ("imdb", "tmdb", "rt_critic", "rt_audience", "metacritic", "trakt", "letterboxd", "mdblist")
EPISODE_RATINGS = ("imdb", "tmdb")
ALL_RATINGS = ("imdb", "rt_audience", "rt_critic", "metacritic", "trakt", "letterboxd", "mdblist", "tmdb")
RATING_LABELS = {
    "imdb": "IMDb",
    "tmdb": "TMDb",
    "rt_critic": "RT critics",
    "rt_audience": "RT audience",
    "metacritic": "Metacritic",
    "trakt": "Trakt",
    "letterboxd": "Letterboxd",
    "mdblist": "MDBList",
}
SOURCE_TO_LOGICAL = {
    "imdb": "imdb",
    "tmdb": "tmdb",
    "trakt": "trakt",
    "tomatoes": "rt_critic",
    "rottentomatoes": "rt_critic",
    "rotten_tomatoes": "rt_critic",
    "rt_critic": "rt_critic",
    "popcorn": "rt_audience",
    "rt_audience": "rt_audience",
    "metacritic": "metacritic",
    "letterboxd": "letterboxd",
    "mdblist": "mdblist",
}

PUBLISH_NAMES = (
    "IMDb_Rating", "TMDb_Rating", "RottenTomatoes_Rating", "RottenTomatoes_UserMeter",
    "MetaCritic_Rating", "Trakt_Rating", "Letterboxd_Rating", "MDBList_Rating",
    "Top250", "IMDb_Top250_Rank", "IMDb_Top250_TV_Rank", "Status", "StatusDate",
    "First_Air_Date", "Last_Air_Date", "Next_Air_Date", "Oscar_Wins", "Emmy_Wins",
    "ItemKey",
)


def ensure_profile() -> None:
    if not xbmcvfs.exists(PROFILE):
        xbmcvfs.mkdirs(PROFILE)


def now_iso() -> str:
    return datetime.now(timezone.utc).replace(microsecond=0).isoformat().replace("+00:00", "Z")


def log(message: str, level: int = xbmc.LOGINFO) -> None:
    xbmc.log("[{0}] {1}".format(ADDON_ID, message), level)


def get_setting(key: str, default: str = "") -> str:
    try:
        value = ADDON.getSetting(key)
        return value if value not in (None, "") else default
    except Exception:
        return default


def bool_setting(key: str, default: bool = True) -> bool:
    value = get_setting(key, "true" if default else "false")
    return str(value).lower() in ("true", "1", "yes", "on")


def enabled_logicals(media_type: str) -> List[str]:
    if media_type == "episode":
        allowed = EPISODE_RATINGS
    else:
        allowed = MOVIE_SERIES_RATINGS
    return [logical for logical in allowed if bool_setting("rating_" + logical, logical != "mdblist")]


def safe_float(value: Any) -> Optional[float]:
    if value in (None, "", "N/A", NO_RATING_VALUE):
        return None
    try:
        return float(str(value).replace("%", "").strip())
    except Exception:
        return None


def safe_int(value: Any) -> Optional[int]:
    if value in (None, "", "N/A", NO_RATING_VALUE):
        return None
    try:
        return int(float(str(value).strip()))
    except Exception:
        return None


def clean_imdb(value: Any) -> str:
    value = str(value or "").strip()
    if value and value.lower().startswith("tt"):
        return value
    return ""


def clean_id(value: Any) -> str:
    value = str(value or "").strip()
    if value and value not in ("0", "None", "null"):
        return value
    return ""


def json_rpc(method: str, params: Dict[str, Any]) -> Dict[str, Any]:
    payload = {"jsonrpc": "2.0", "method": method, "params": params, "id": 1}
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    data = json.loads(raw or "{}")
    if data.get("error"):
        raise RuntimeError("JSON-RPC {0}: {1}".format(method, data.get("error")))
    return data.get("result") or {}


def json_rpc_items(method: str, root_key: str, properties: List[str]) -> List[Dict[str, Any]]:
    params = {"properties": properties, "limits": {"start": 0, "end": 100000}}
    try:
        return json_rpc(method, params).get(root_key, []) or []
    except Exception as exc:
        log("Property fallback for {0}: {1}".format(method, exc), xbmc.LOGWARNING)
        minimal = [p for p in properties if p in ("title", "year", "imdbnumber", "uniqueid", "ratings", "season", "episode", "showtitle", "tvshowid")]
        return json_rpc(method, {"properties": minimal, "limits": {"start": 0, "end": 100000}}).get(root_key, []) or []


def extract_ids(row: Dict[str, Any]) -> Dict[str, str]:
    ids: Dict[str, str] = {}
    unique = row.get("uniqueid") or {}
    if isinstance(unique, dict):
        for key, value in unique.items():
            k = str(key).lower()
            if k in ("imdb", "imdb_id", "imdbid"):
                ids["imdb"] = clean_imdb(value)
            elif k in ("tmdb", "tmdb_id", "tmdbid"):
                ids["tmdb"] = clean_id(value)
            elif k in ("tvdb", "tvdb_id", "tvdbid"):
                ids["tvdb"] = clean_id(value)
            elif k == "trakt":
                ids["trakt"] = clean_id(value)
            elif k == "mdblist":
                ids["mdblist"] = clean_id(value)
    imdb = clean_imdb(row.get("imdbnumber"))
    if imdb:
        ids["imdb"] = imdb
    return {k: v for k, v in ids.items() if v}


def library_items() -> List[Dict[str, Any]]:
    output: List[Dict[str, Any]] = []
    include_movies = bool_setting("include_movies", True)
    include_tvshows = bool_setting("include_tvshows", True)
    include_episodes = bool_setting("include_episodes", True)

    movie_props = ["title", "year", "imdbnumber", "uniqueid", "ratings", "top250"]
    tv_props = ["title", "year", "imdbnumber", "uniqueid", "ratings"]
    ep_props = ["title", "year", "imdbnumber", "uniqueid", "ratings", "showtitle", "season", "episode", "tvshowid"]

    if include_movies:
        for row in json_rpc_items("VideoLibrary.GetMovies", "movies", movie_props):
            if isinstance(row, dict):
                item = dict(row)
                item["type"] = "movie"
                item["dbid"] = row.get("movieid")
                output.append(item)

    show_map: Dict[int, Dict[str, Any]] = {}
    if include_tvshows or include_episodes:
        for row in json_rpc_items("VideoLibrary.GetTVShows", "tvshows", tv_props):
            if isinstance(row, dict):
                item = dict(row)
                item["type"] = "tvshow"
                item["dbid"] = row.get("tvshowid")
                show_map[safe_int(row.get("tvshowid")) or -1] = item
                if include_tvshows:
                    output.append(item)

    if include_episodes:
        for row in json_rpc_items("VideoLibrary.GetEpisodes", "episodes", ep_props):
            if isinstance(row, dict):
                item = dict(row)
                item["type"] = "episode"
                item["dbid"] = row.get("episodeid")
                parent = show_map.get(safe_int(row.get("tvshowid")) or -1) or {}
                parent_ids = extract_ids(parent)
                if parent_ids.get("tmdb"):
                    item["show_tmdb"] = parent_ids.get("tmdb")
                if parent_ids.get("imdb"):
                    item["show_imdb"] = parent_ids.get("imdb")
                output.append(item)
    return output

def load_cache() -> Dict[str, Any]:
    ensure_profile()
    if not os.path.exists(CACHE_FILE):
        return {"items": {}, "version": 2, "updated_at": now_iso()}
    try:
        with open(CACHE_FILE, "r", encoding="utf-8") as handle:
            cache = json.load(handle)
        if not isinstance(cache, dict):
            raise ValueError("cache root not dict")
        cache.setdefault("items", {})
        return cache
    except Exception as exc:
        log("Cache read failed: {0}".format(exc), xbmc.LOGERROR)
        return {"items": {}, "version": 2, "updated_at": now_iso()}


def save_cache(cache: Dict[str, Any]) -> None:
    ensure_profile()
    cache["version"] = 2
    cache["updated_at"] = now_iso()
    tmp = CACHE_FILE + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        json.dump(cache, handle, indent=2, sort_keys=True, ensure_ascii=False)
    if os.path.exists(CACHE_FILE):
        try:
            os.remove(CACHE_FILE)
        except Exception:
            pass
    os.replace(tmp, CACHE_FILE)


def item_key(item: Dict[str, Any]) -> str:
    return "{0}|{1}".format(item.get("type"), item.get("dbid"))


def http_json(url: str, timeout: int = 20, method: str = "GET", body: Optional[Dict[str, Any]] = None) -> Tuple[Any, Dict[str, str]]:
    data = None
    headers = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    if body is not None:
        data = json.dumps(body).encode("utf-8")
        headers["Content-Type"] = "application/json"
    req = Request(url, data=data, headers=headers, method=method)
    try:
        with urlopen(req, timeout=timeout) as resp:
            raw = resp.read().decode("utf-8", "replace")
            response_headers = {str(k): str(v) for k, v in resp.headers.items()}
            return json.loads(raw or "{}"), response_headers
    except HTTPError as exc:
        raw = exc.read().decode("utf-8", "replace") if exc.fp else ""
        try:
            payload = json.loads(raw) if raw else {}
        except Exception:
            payload = {"error": raw[:300]}
        payload.setdefault("error", "HTTP {0}".format(exc.code))
        payload["http_status"] = exc.code
        return payload, {"http_status": str(exc.code)}
    except URLError as exc:
        return {"error": str(exc.reason)}, {}


def normalized_rating(logical: str, source: str, value: Any, score: Any = None, votes: Any = None, provider: str = "") -> Optional[Dict[str, Any]]:
    val = safe_float(value)
    scr = safe_float(score)
    if val is None and scr is None:
        return None
    if scr is None:
        if logical in ("imdb", "tmdb", "trakt", "letterboxd"):
            scr = (val or 0.0) * 10.0 if (val or 0.0) <= 10 else val
        else:
            scr = val
    if val is None:
        val = scr / 10.0 if logical in ("imdb", "tmdb", "trakt", "letterboxd") and scr > 10 else scr
    # MDBList returns TMDb/Trakt sometimes as 0-100; display as 0-10.
    if logical in ("tmdb", "trakt") and val is not None and val > 10:
        val = val / 10.0
    if logical == "letterboxd" and val is not None and val <= 5:
        val = val * 2.0
    return {
        "source": source,
        "logical": logical,
        "provider": provider,
        "value": round(float(val), 1) if val is not None else "",
        "score": round(float(scr), 1) if scr is not None else "",
        "votes": safe_int(votes) or "",
        "updated_at": now_iso(),
    }


def no_rating_row(logical: str, provider: str) -> Dict[str, Any]:
    return {
        "source": logical,
        "logical": logical,
        "provider": NO_RATING_PROVIDER,
        "value": NO_RATING_VALUE,
        "score": "",
        "votes": "",
        "no_rating": True,
        "checked_provider": provider,
        "updated_at": now_iso(),
    }


def has_rating_value(row: Any) -> bool:
    if isinstance(row, dict) and row.get("no_rating"):
        return True
    if isinstance(row, dict):
        return safe_float(row.get("score")) is not None or safe_float(row.get("value")) is not None
    return safe_float(row) is not None


def _attempt_temp_failure(attempt: Any) -> bool:
    if not isinstance(attempt, dict):
        return False
    status = safe_int(attempt.get("http_status"))
    error = str(attempt.get("error") or "").lower()
    if status in (401, 403, 408, 409, 425, 429) or (status is not None and status >= 500):
        return True
    words = ("limit", "quota", "unauthorized", "forbidden", "timeout", "timed out", "temporar", "connection", "ssl", "429", "401", "403")
    return any(word in error for word in words)


def meta_cacheable(meta: Dict[str, Any]) -> bool:
    attempts = (meta or {}).get("attempts") or []
    if not attempts:
        return False
    return not any(_attempt_temp_failure(attempt) for attempt in attempts)


def merge_rating(ratings: Dict[str, Any], logical: str, row: Optional[Dict[str, Any]], overwrite: bool = True) -> None:
    if not row:
        return
    if overwrite or not has_rating_value(ratings.get(logical)):
        ratings[logical] = row


def mdblist_lookup(ids: Dict[str, str], media_type: str, api_key: str) -> Tuple[Dict[str, Any], Dict[str, Any]]:
    meta: Dict[str, Any] = {"attempts": [], "ids": {}}
    if not api_key:
        return {}, meta
    candidates: List[Tuple[str, str]] = []
    for provider in ("imdb", "tmdb", "trakt", "mdblist"):
        if ids.get(provider):
            candidates.append((provider, ids[provider]))
    for provider, media_id in candidates:
        url = "https://api.mdblist.com/{0}/{1}/{2}?{3}".format(
            quote(provider), quote(media_type), quote(str(media_id)), urlencode({"apikey": api_key})
        )
        payload, headers = http_json(url)
        ratings_out: Dict[str, Any] = {}
        attempt = {"route": "{0}/{1}/{2}".format(provider, media_type, media_id), "ratings_count": 0}
        if isinstance(payload, dict):
            if payload.get("ids") and isinstance(payload.get("ids"), dict):
                for key, value in payload.get("ids", {}).items():
                    if value not in (None, ""):
                        meta["ids"][str(key)] = str(value)
            if payload.get("ratings") and isinstance(payload.get("ratings"), list):
                attempt["ratings_count"] = len(payload.get("ratings") or [])
                for rating in payload.get("ratings") or []:
                    if not isinstance(rating, dict):
                        continue
                    source = str(rating.get("source") or "").lower().strip()
                    logical = SOURCE_TO_LOGICAL.get(source)
                    if not logical:
                        continue
                    row = normalized_rating(logical, source, rating.get("value"), rating.get("score"), rating.get("votes"), "mdblist")
                    merge_rating(ratings_out, logical, row, overwrite=True)
            if payload.get("score") not in (None, ""):
                row = normalized_rating("mdblist", "mdblist", payload.get("score"), payload.get("score"), None, "mdblist")
                merge_rating(ratings_out, "mdblist", row, overwrite=True)
            if payload.get("error"):
                attempt["error"] = payload.get("error")
            if payload.get("http_status"):
                attempt["http_status"] = payload.get("http_status")
        else:
            attempt["error"] = "non-dict response"
        if headers.get("X-RateLimit-Remaining"):
            meta["rate_limit_remaining"] = headers.get("X-RateLimit-Remaining")
        meta["attempts"].append(attempt)
        if ratings_out:
            return ratings_out, meta
    return {}, meta


def omdb_lookup(item: Dict[str, Any], ids: Dict[str, str], api_key: str) -> Tuple[Dict[str, Any], Dict[str, Any], Dict[str, Any]]:
    meta: Dict[str, Any] = {"attempts": []}
    found: Dict[str, Any] = {}
    if not api_key:
        return found, ids, meta
    queries = []
    if ids.get("imdb"):
        queries.append({"i": ids["imdb"]})
    title = item.get("title") or ""
    if item.get("type") == "episode" and item.get("showtitle"):
        q = {"t": item.get("showtitle"), "Season": item.get("season"), "Episode": item.get("episode")}
        queries.append(q)
    elif title:
        q = {"t": title}
        if item.get("year"):
            q["y"] = item.get("year")
        queries.append(q)
    for query in queries:
        params = {"apikey": api_key, "r": "json"}
        params.update({k: v for k, v in query.items() if v not in (None, "")})
        url = "https://www.omdbapi.com/?" + urlencode(params)
        payload, _headers = http_json(url)
        attempt = dict(query)
        if isinstance(payload, dict):
            attempt["response"] = payload.get("Response")
            attempt["title"] = payload.get("Title", "")
            attempt["imdbRating"] = payload.get("imdbRating", "")
            attempt["Metascore"] = payload.get("Metascore", "")
            attempt["Awards"] = payload.get("Awards", "")
            if payload.get("Error"):
                attempt["error"] = payload.get("Error")
            if payload.get("http_status"):
                attempt["http_status"] = payload.get("http_status")
            if str(payload.get("Response", "")).lower() == "true":
                if clean_imdb(payload.get("imdbID")):
                    ids.setdefault("imdb", clean_imdb(payload.get("imdbID")))
                row = normalized_rating("imdb", "imdb", payload.get("imdbRating"), None, payload.get("imdbVotes"), "omdb")
                merge_rating(found, "imdb", row, overwrite=True)
                row = normalized_rating("metacritic", "metacritic", payload.get("Metascore"), payload.get("Metascore"), None, "omdb")
                merge_rating(found, "metacritic", row, overwrite=True)
                for rating in payload.get("Ratings") or []:
                    src = str(rating.get("Source") or "").lower()
                    val = rating.get("Value")
                    if "rotten" in src:
                        row = normalized_rating("rt_critic", "tomatoes", val, val, None, "omdb")
                        merge_rating(found, "rt_critic", row, overwrite=True)
                    elif "metacritic" in src:
                        row = normalized_rating("metacritic", "metacritic", val, val, None, "omdb")
                        merge_rating(found, "metacritic", row, overwrite=True)
                awards = parse_awards(payload.get("Awards"))
                if awards:
                    found["__awards"] = awards
                meta["attempts"].append(attempt)
                return found, ids, meta
        meta["attempts"].append(attempt)
    return found, ids, meta


def tmdb_find_external(imdb_id: str, api_key: str) -> Dict[str, str]:
    ids: Dict[str, str] = {}
    if not api_key or not imdb_id:
        return ids
    url = "https://api.themoviedb.org/3/find/{0}?{1}".format(quote(imdb_id), urlencode({"api_key": api_key, "external_source": "imdb_id"}))
    payload, _headers = http_json(url)
    if isinstance(payload, dict):
        if payload.get("movie_results"):
            ids["tmdb"] = str(payload["movie_results"][0].get("id"))
        if payload.get("tv_results"):
            ids["tmdb"] = str(payload["tv_results"][0].get("id"))
    return ids


def tmdb_lookup(item: Dict[str, Any], ids: Dict[str, str], api_key: str) -> Tuple[Dict[str, Any], Dict[str, str], Dict[str, Any]]:
    meta: Dict[str, Any] = {"attempts": []}
    found: Dict[str, Any] = {}
    if not api_key:
        return found, ids, meta
    item_type = item.get("type")
    if not ids.get("tmdb") and ids.get("imdb"):
        ids.update({k: v for k, v in tmdb_find_external(ids["imdb"], api_key).items() if v})
    if item_type == "episode":
        show_tmdb = ids.get("show_tmdb") or clean_id(item.get("show_tmdb"))
        if not show_tmdb and item.get("show_tmdb"):
            show_tmdb = str(item.get("show_tmdb"))
        if show_tmdb and item.get("season") not in (None, "") and item.get("episode") not in (None, ""):
            url = "https://api.themoviedb.org/3/tv/{0}/season/{1}/episode/{2}?{3}".format(
                quote(str(show_tmdb)), quote(str(item.get("season"))), quote(str(item.get("episode"))), urlencode({"api_key": api_key})
            )
            payload, _headers = http_json(url)
            att = {"route": "episode", "show_tmdb": show_tmdb, "season": item.get("season"), "episode": item.get("episode")}
            if isinstance(payload, dict):
                if payload.get("id"):
                    ids.setdefault("tmdb", str(payload.get("id")))
                row = normalized_rating("tmdb", "tmdb", payload.get("vote_average"), (safe_float(payload.get("vote_average")) or 0) * 10, payload.get("vote_count"), "tmdb")
                merge_rating(found, "tmdb", row, overwrite=True)
                if payload.get("external_ids") and isinstance(payload.get("external_ids"), dict):
                    imdb = clean_imdb(payload["external_ids"].get("imdb_id"))
                    if imdb:
                        ids.setdefault("imdb", imdb)
                if payload.get("error"):
                    att["error"] = payload.get("error")
                if payload.get("http_status"):
                    att["http_status"] = payload.get("http_status")
            meta["attempts"].append(att)
        return found, ids, meta

    if item_type in ("movie", "tvshow") and ids.get("tmdb"):
        route = "movie" if item_type == "movie" else "tv"
        url = "https://api.themoviedb.org/3/{0}/{1}?{2}".format(quote(route), quote(str(ids["tmdb"])), urlencode({"api_key": api_key, "append_to_response": "external_ids"}))
        payload, _headers = http_json(url)
        att = {"route": route, "tmdb": ids.get("tmdb")}
        if isinstance(payload, dict):
            row = normalized_rating("tmdb", "tmdb", payload.get("vote_average"), (safe_float(payload.get("vote_average")) or 0) * 10, payload.get("vote_count"), "tmdb")
            merge_rating(found, "tmdb", row, overwrite=True)
            ex = payload.get("external_ids") or {}
            if isinstance(ex, dict):
                imdb = clean_imdb(ex.get("imdb_id"))
                if imdb:
                    ids.setdefault("imdb", imdb)
            if item_type == "tvshow":
                found["__series"] = parse_series_status(payload)
            if payload.get("error"):
                att["error"] = payload.get("error")
            if payload.get("http_status"):
                att["http_status"] = payload.get("http_status")
        meta["attempts"].append(att)
    return found, ids, meta


def parse_date_display(value: Any) -> str:
    raw = str(value or "").strip()
    if not raw:
        return ""
    try:
        return datetime.strptime(raw, "%Y-%m-%d").strftime("%d/%m/%Y")
    except Exception:
        return raw


def parse_series_status(payload: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(payload, dict):
        return {}
    status = str(payload.get("status") or "").strip()
    if status == "Returning Series":
        status = "Returning"
    if status == "Canceled":
        status = "Cancelled"
    next_ep = payload.get("next_episode_to_air") or {}
    last_ep = payload.get("last_episode_to_air") or {}
    next_date = next_ep.get("air_date") if isinstance(next_ep, dict) else ""
    last_ep_date = last_ep.get("air_date") if isinstance(last_ep, dict) else ""
    last_air = payload.get("last_air_date") or last_ep_date or ""
    first_air = payload.get("first_air_date") or ""
    status_date = next_date if status in ("Returning", "In Production", "Planned", "Pilot") and next_date else last_air
    return {
        "status": status,
        "status_date": status_date or "",
        "status_date_display": parse_date_display(status_date),
        "first_air_date": first_air,
        "last_air_date": last_air,
        "next_air_date": next_date or "",
        "updated_at": now_iso(),
    }


def parse_awards(text: Any) -> Dict[str, Any]:
    raw = str(text or "").strip()
    if not raw or raw.upper() == "N/A":
        return {"source": "omdb", "awards_text": raw or "N/A", "updated_at": now_iso()}
    out = {"source": "omdb", "awards_text": raw, "updated_at": now_iso()}
    m = re.search(r"\bWon\s+(\d+)\s+Oscars?\b", raw, re.I)
    if m:
        out["oscar_wins"] = safe_int(m.group(1)) or 0
    m = re.search(r"\bWon\s+(\d+)\s+(?:Primetime\s+|Daytime\s+)?Emmys?\b", raw, re.I)
    if m:
        out["emmy_wins"] = safe_int(m.group(1)) or 0
    return out


def load_top_tv_ranks() -> Dict[str, int]:
    try:
        with open(TOP_TV_FILE, "r", encoding="utf-8") as handle:
            data = json.load(handle)
        ranks: Dict[str, int] = {}
        for idx, row in enumerate(data.get("top_tv_shows") or [], start=1):
            imdb = clean_imdb(row.get("id"))
            if imdb:
                ranks[imdb] = idx
        return ranks
    except Exception as exc:
        log("Top TV file failed: {0}".format(exc), xbmc.LOGERROR)
        return {}


def apply_top250(item_type: str, ids: Dict[str, str], item: Dict[str, Any], existing: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {}
    # Preserve movie rank from Kodi/library or existing cache. TV uses bundled JSON.
    if item_type == "movie" and bool_setting("sync_imdb_top250_movie", True):
        rank = safe_int(item.get("top250")) or safe_int(existing.get("imdb_top250_rank")) or 0
        out["imdb_top250_rank"] = rank
    elif item_type in ("tvshow", "episode") and bool_setting("sync_imdb_top250_tv", True):
        imdb = clean_imdb(item.get("show_imdb")) if item_type == "episode" else ""
        imdb = imdb or ids.get("imdb") or clean_imdb(item.get("show_imdb"))
        rank = load_top_tv_ranks().get(imdb, 0) if imdb else 0
        if rank:
            out["imdb_top250_tv_rank"] = rank
            out["imdb_top250_rank"] = rank
        else:
            out["imdb_top250_tv_rank"] = safe_int(existing.get("imdb_top250_tv_rank")) or 0
            out["imdb_top250_rank"] = safe_int(existing.get("imdb_top250_rank")) or 0
    else:
        out["imdb_top250_rank"] = safe_int(existing.get("imdb_top250_rank")) or 0
    return out


def missing_logicals(item_type: str, ratings: Dict[str, Any]) -> List[str]:
    missing = []
    for logical in enabled_logicals(item_type):
        if not has_rating_value(ratings.get(logical)):
            missing.append(logical)
    return missing


def should_process(item: Dict[str, Any], existing: Dict[str, Any], refresh: bool = False) -> bool:
    if refresh or not existing:
        return True
    item_type = item.get("type")
    if missing_logicals(item_type, existing.get("ratings") or {}):
        return True
    if item_type == "tvshow" and bool_setting("scrape_tv_status", True) and not (existing.get("series") or {}).get("status"):
        return True
    if item_type in ("movie", "tvshow") and bool_setting("scrape_awards_wins", True) and not (existing.get("awards") or {}).get("awards_text"):
        return True
    if item_type == "movie" and bool_setting("sync_imdb_top250_movie", True) and safe_int(item.get("top250")) and not safe_int(existing.get("imdb_top250_rank")):
        return True
    if item_type == "tvshow" and bool_setting("sync_imdb_top250_tv", True) and not safe_int(existing.get("imdb_top250_tv_rank")):
        return True
    return False


def resolve_item(item: Dict[str, Any], existing: Optional[Dict[str, Any]] = None, refresh: bool = False) -> Dict[str, Any]:
    existing = existing or {}
    item_type = item.get("type") or ""
    ids = dict(existing.get("ids") or {})
    ids.update(extract_ids(item))
    if item.get("show_tmdb"):
        ids.setdefault("show_tmdb", str(item.get("show_tmdb")))
    if item.get("show_imdb"):
        if item_type == "episode":
            ids.setdefault("show_imdb", clean_imdb(item.get("show_imdb")))
        else:
            ids.setdefault("imdb", clean_imdb(item.get("show_imdb")))
    ratings: Dict[str, Any] = {} if refresh else dict(existing.get("ratings") or {})
    provider_meta: Dict[str, Any] = {} if refresh else dict(existing.get("provider_meta") or {})
    series_meta: Dict[str, Any] = {} if refresh else dict(existing.get("series") or {})
    awards_meta: Dict[str, Any] = {} if refresh else dict(existing.get("awards") or {})
    errors: List[str] = []

    mdblist_key = get_setting("mdblist_api_key")
    tmdb_key = get_setting("tmdb_api_key")
    omdb_key = get_setting("omdb_api_key")
    checked_no_value: set = set()

    if item_type in ("movie", "tvshow") and mdblist_key:
        need = set(enabled_logicals(item_type)) - {"tmdb"}
        if refresh or any(not has_rating_value(ratings.get(x)) for x in need):
            try:
                found, meta = mdblist_lookup(ids, "movie" if item_type == "movie" else "show", mdblist_key)
                provider_meta["mdblist"] = meta
                for key, value in (meta.get("ids") or {}).items():
                    if value:
                        ids.setdefault(key, str(value))
                for logical, row in found.items():
                    if logical in enabled_logicals(item_type):
                        merge_rating(ratings, logical, row, overwrite=True)
                if meta_cacheable(meta):
                    checked_no_value.update(need)
            except Exception as exc:
                errors.append("mdblist: {0}".format(exc))

    # TMDb is always the TMDb rating/status fallback and episode TMDb source.
    if tmdb_key:
        need_tmdb = "tmdb" in enabled_logicals(item_type) and (refresh or not has_rating_value(ratings.get("tmdb")))
        need_status = item_type == "tvshow" and bool_setting("scrape_tv_status", True) and (refresh or not series_meta.get("status"))
        if need_tmdb or need_status:
            try:
                found, ids, meta = tmdb_lookup(item, ids, tmdb_key)
                provider_meta["tmdb"] = meta
                if "tmdb" in found and "tmdb" in enabled_logicals(item_type):
                    merge_rating(ratings, "tmdb", found.get("tmdb"), overwrite=True)
                if isinstance(found.get("__series"), dict):
                    series_meta.update({k: v for k, v in found["__series"].items() if v not in (None, "")})
                if need_tmdb and meta_cacheable(meta):
                    checked_no_value.add("tmdb")
            except Exception as exc:
                errors.append("tmdb: {0}".format(exc))

    # OMDb fills episode IMDb and fallback IMDb/Metacritic/RT/Awards.
    if omdb_key:
        omdb_targets = set(enabled_logicals(item_type)) & {"imdb", "metacritic", "rt_critic", "rt_audience"}
        need_omdb = refresh or any(not has_rating_value(ratings.get(x)) for x in omdb_targets)
        need_awards = item_type in ("movie", "tvshow") and bool_setting("scrape_awards_wins", True) and (refresh or not awards_meta.get("awards_text"))
        if need_omdb or need_awards:
            try:
                found, ids, meta = omdb_lookup(item, ids, omdb_key)
                provider_meta["omdb"] = meta
                awards = found.pop("__awards", {}) if isinstance(found, dict) else {}
                if awards:
                    awards_meta.update({k: v for k, v in awards.items() if v not in (None, "")})
                for logical, row in found.items():
                    if logical in enabled_logicals(item_type):
                        merge_rating(ratings, logical, row, overwrite=True)
                if need_omdb and meta_cacheable(meta):
                    checked_no_value.update(omdb_targets)
            except Exception as exc:
                errors.append("omdb: {0}".format(exc))

    # Mark enabled fields that providers checked but still have no value.
    for logical in checked_no_value:
        if logical in enabled_logicals(item_type) and not has_rating_value(ratings.get(logical)):
            ratings[logical] = no_rating_row(logical, "checked")

    out: Dict[str, Any] = {
        "type": item_type,
        "dbid": item.get("dbid"),
        "title": item.get("title") or "",
        "showtitle": item.get("showtitle") or "",
        "season": item.get("season") if item.get("season") not in (None, "") else "",
        "episode": item.get("episode") if item.get("episode") not in (None, "") else "",
        "year": item.get("year") or "",
        "ids": ids,
        "show_imdb": clean_imdb(item.get("show_imdb")),
        "show_tmdb": clean_id(item.get("show_tmdb")),
        "ratings": ratings,
        "provider_meta": provider_meta,
        "series": series_meta,
        "awards": awards_meta,
        "errors": errors,
        "updated_at": now_iso(),
        "timestamp": int(time.time()),
    }
    out.update(apply_top250(item_type, ids, item, existing))
    return out


def run_scrape(refresh: bool = False) -> Dict[str, Any]:
    ensure_profile()
    items = library_items()
    cache = load_cache()
    records = cache.setdefault("items", {})
    progress = xbmcgui.DialogProgressBG()
    progress.create(ADDON_NAME, "starting")
    total = len(items) or 1
    processed = 0
    updated = 0
    skipped = 0
    errors = 0
    try:
        for index, item in enumerate(items, start=1):
            key = item_key(item)
            existing = records.get(key) or {}
            if not should_process(item, existing, refresh=refresh):
                skipped += 1
                continue
            pct = int((index / float(total)) * 100)
            title = item.get("title") or item.get("showtitle") or key
            progress.update(pct, "scraping", "{0}/{1} {2}".format(index, total, title))
            record = resolve_item(item, existing=existing, refresh=refresh)
            records[key] = record
            updated += 1
            if record.get("errors"):
                errors += 1
            processed += 1
            if index % 20 == 0:
                save_cache(cache)
            xbmc.sleep(250)
        apply_top250_movies_to_cache(cache, items)
        apply_top250_tv_items_to_cache(cache, items)
        save_cache(cache)
        report = export_csv(cache)
        summary = {"processed": processed, "updated": updated, "skipped": skipped, "errors": errors, "items": total, "report": report, "updated_at": now_iso()}
        with open(SUMMARY_FILE, "w", encoding="utf-8") as handle:
            json.dump(summary, handle, indent=2, sort_keys=True)
        return summary
    finally:
        try:
            progress.close()
        except Exception:
            pass


def _ensure_basic_cache_record(records: Dict[str, Any], item: Dict[str, Any]) -> Dict[str, Any]:
    key = item_key(item)
    record = records.get(key)
    if not isinstance(record, dict):
        record = {"ratings": {}, "provider_meta": {}, "series": {}, "awards": {}, "errors": []}
        records[key] = record
    record["type"] = item.get("type")
    record["dbid"] = item.get("dbid")
    record["title"] = item.get("title") or ""
    record["showtitle"] = item.get("showtitle") or record.get("showtitle", "") or ""
    record["season"] = item.get("season") if item.get("season") not in (None, "") else record.get("season", "")
    record["episode"] = item.get("episode") if item.get("episode") not in (None, "") else record.get("episode", "")
    record["year"] = item.get("year") or record.get("year", "") or ""
    ids = dict(record.get("ids") or {})
    ids.update(extract_ids(item))
    if item.get("show_tmdb"):
        record["show_tmdb"] = clean_id(item.get("show_tmdb"))
        ids.setdefault("show_tmdb", clean_id(item.get("show_tmdb")))
    if item.get("show_imdb"):
        record["show_imdb"] = clean_imdb(item.get("show_imdb"))
    record["ids"] = {k: v for k, v in ids.items() if v}
    record.setdefault("ratings", {})
    record.setdefault("provider_meta", {})
    record.setdefault("series", {})
    record.setdefault("awards", {})
    record.setdefault("errors", [])
    record["updated_at"] = record.get("updated_at") or now_iso()
    record["timestamp"] = record.get("timestamp") or int(time.time())
    return record


def apply_top250_movies_to_cache(cache: Dict[str, Any], items: Optional[List[Dict[str, Any]]] = None) -> int:
    if not bool_setting("sync_imdb_top250_movie", True):
        return 0
    if items is None:
        items = library_items()
    records = cache.setdefault("items", {})
    count = 0
    for item in items:
        if item.get("type") != "movie":
            continue
        rank = safe_int(item.get("top250")) or 0
        if not rank:
            continue
        record = _ensure_basic_cache_record(records, item)
        record["imdb_top250_rank"] = rank
        record["updated_at"] = now_iso()
        record["timestamp"] = int(time.time())
        count += 1
    cache["top250_movie_synced_at"] = now_iso()
    return count


def apply_top250_tv_to_cache(cache: Dict[str, Any]) -> int:
    ranks = load_top_tv_ranks()
    count = 0
    for record in (cache.get("items") or {}).values():
        if not isinstance(record, dict):
            continue
        if record.get("type") not in ("tvshow", "episode"):
            continue
        ids = record.get("ids") or {}
        imdb = clean_imdb(record.get("show_imdb")) if record.get("type") == "episode" else ""
        imdb = imdb or clean_imdb(ids.get("imdb"))
        if not imdb:
            continue
        rank = ranks.get(imdb, 0)
        if rank:
            record["imdb_top250_tv_rank"] = rank
            record["imdb_top250_rank"] = rank
            count += 1
    cache["top250_tv_synced_at"] = now_iso()
    return count


def apply_top250_tv_items_to_cache(cache: Dict[str, Any], items: Optional[List[Dict[str, Any]]] = None) -> int:
    if not bool_setting("sync_imdb_top250_tv", True):
        return 0
    if items is None:
        items = library_items()
    ranks = load_top_tv_ranks()
    records = cache.setdefault("items", {})
    count = 0
    for item in items:
        if item.get("type") not in ("tvshow", "episode"):
            continue
        ids = extract_ids(item)
        imdb = clean_imdb(item.get("show_imdb")) if item.get("type") == "episode" else ""
        imdb = imdb or ids.get("imdb") or clean_imdb(item.get("show_imdb"))
        rank = ranks.get(imdb, 0) if imdb else 0
        if not rank:
            continue
        record = _ensure_basic_cache_record(records, item)
        record["imdb_top250_tv_rank"] = rank
        record["imdb_top250_rank"] = rank
        record["updated_at"] = now_iso()
        record["timestamp"] = int(time.time())
        count += 1
    cache["top250_tv_synced_at"] = now_iso()
    return count


def sync_top250_tv() -> Dict[str, Any]:
    cache = load_cache()
    count = apply_top250_tv_items_to_cache(cache, library_items())
    save_cache(cache)
    export_csv(cache)
    return {"updated": count, "updated_at": now_iso()}


def sync_top250_all() -> Dict[str, Any]:
    cache = load_cache()
    items = library_items()
    movie_count = apply_top250_movies_to_cache(cache, items)
    tv_count = apply_top250_tv_items_to_cache(cache, items)
    cache["top250_all_synced_at"] = now_iso()
    save_cache(cache)
    export_csv(cache)
    return {"movies": movie_count, "tv": tv_count, "updated": movie_count + tv_count, "updated_at": now_iso()}


def rating_display(logical: str, row: Any) -> str:
    if not isinstance(row, dict) or row.get("no_rating"):
        return ""
    value = safe_float(row.get("value"))
    if value is None:
        return ""
    if logical in ("rt_critic", "rt_audience", "metacritic"):
        return str(int(round(value)))
    return "{0:.1f}".format(value)


def export_csv(cache: Dict[str, Any]) -> str:
    ensure_profile()
    fixed = [
        "type", "dbid", "title", "showtitle", "season", "episode", "year",
        "tmdb_id", "imdb_id", "imdb_top250_rank", "imdb_top250_tv_rank",
        "oscar_wins", "emmy_wins", "series_status", "series_status_date", "updated_at",
    ]
    rating_cols = ["rating_" + logical for logical in ALL_RATINGS]
    with open(REPORT_FILE, "w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fixed + rating_cols)
        writer.writeheader()
        rows = list((cache.get("items") or {}).values())
        rows.sort(key=lambda r: (str(r.get("type")), str(r.get("showtitle")), str(r.get("title")), safe_int(r.get("season")) or -1, safe_int(r.get("episode")) or -1))
        for record in rows:
            ids = record.get("ids") or {}
            awards = record.get("awards") or {}
            series = record.get("series") or {}
            row = {
                "type": record.get("type", ""), "dbid": record.get("dbid", ""), "title": record.get("title", ""),
                "showtitle": record.get("showtitle", ""), "season": record.get("season", ""), "episode": record.get("episode", ""),
                "year": record.get("year", ""), "tmdb_id": ids.get("tmdb", ""), "imdb_id": clean_imdb(ids.get("imdb")),
                "imdb_top250_rank": record.get("imdb_top250_rank", "") or "",
                "imdb_top250_tv_rank": record.get("imdb_top250_tv_rank", "") or "",
                "oscar_wins": awards.get("oscar_wins", "") or "", "emmy_wins": awards.get("emmy_wins", "") or "",
                "series_status": series.get("status", "") or "", "series_status_date": series.get("status_date_display") or parse_date_display(series.get("status_date")),
                "updated_at": record.get("updated_at", ""),
            }
            ratings = record.get("ratings") or {}
            for logical in ALL_RATINGS:
                rr = ratings.get(logical) or {}
                row["rating_" + logical] = NO_RATING_VALUE if isinstance(rr, dict) and rr.get("no_rating") else (rr.get("value", "") if isinstance(rr, dict) else "")
            writer.writerow(row)
    return REPORT_FILE


def live_check(sample: int = 2) -> str:
    items = library_items()
    groups = {"movie": [], "tvshow": [], "episode": []}
    for item in items:
        if item.get("type") in groups:
            groups[item.get("type")].append(item)
    lines = []
    lines.append("API key aktif: MDBList={0}, TMDb={1}, OMDb={2}".format("ON" if get_setting("mdblist_api_key") else "OFF", "ON" if get_setting("tmdb_api_key") else "OFF", "ON" if get_setting("omdb_api_key") else "OFF"))
    lines.append("Jenis media aktif: Movies={0}, Series={1}, Episodes={2}".format("ON" if bool_setting("include_movies", True) else "OFF", "ON" if bool_setting("include_tvshows", True) else "OFF", "ON" if bool_setting("include_episodes", True) else "OFF"))
    lines.append("Sample per jenis: {0}".format(sample))
    lines.append("")
    for media_type, title in (("movie", "MOVIES"), ("tvshow", "TV SHOWS"), ("episode", "EPISODES")):
        lines.append("===== {0} =====".format(title))
        for item in random.sample(groups[media_type], min(sample, len(groups[media_type]))):
            rec = resolve_item(item, existing={}, refresh=True)
            ids = rec.get("ids") or {}
            lines.append("")
            prefix = item.get("showtitle") + " S{0:02d}E{1:02d} - ".format(safe_int(item.get("season")) or 0, safe_int(item.get("episode")) or 0) if media_type == "episode" and item.get("showtitle") else ""
            lines.append("{0}{1}  [imdb={2} tmdb={3}]".format(prefix, item.get("title"), ids.get("imdb", ""), ids.get("tmdb", "")))
            for logical in enabled_logicals(media_type):
                row = (rec.get("ratings") or {}).get(logical) or {}
                val = rating_display(logical, row)
                if val:
                    lines.append("  [OK]   {0}: {1} ({2}/{3})".format(RATING_LABELS.get(logical, logical), val, row.get("provider", ""), row.get("source", "")))
                elif isinstance(row, dict) and row.get("no_rating"):
                    lines.append("  [NO]   {0}: NO_RATING".format(RATING_LABELS.get(logical, logical)))
                else:
                    lines.append("  [MISS] {0}".format(RATING_LABELS.get(logical, logical)))
            if rec.get("series", {}).get("status"):
                lines.append("  [OK]   Status: {0} {1}".format(rec["series"].get("status"), rec["series"].get("status_date_display", "")))
            if rec.get("imdb_top250_tv_rank"):
                lines.append("  [OK]   IMDb Top 250 TV: #{0}".format(rec.get("imdb_top250_tv_rank")))
        lines.append("")
    text = "\n".join(lines)
    ensure_profile()
    with open(LIVE_CHECK_FILE, "w", encoding="utf-8") as handle:
        handle.write(text)
    return LIVE_CHECK_FILE


def clear_publish_properties() -> None:
    win = xbmcgui.Window(10000)
    for prefix in ("LibraryRatings.ListItem.", "TMDbHelper.ListItem."):
        for name in PUBLISH_NAMES:
            win.clearProperty(prefix + name)


def publish_record(record: Optional[Dict[str, Any]]) -> None:
    win = xbmcgui.Window(10000)
    clear_publish_properties()
    if not record:
        return
    values: Dict[str, str] = {}
    ratings = record.get("ratings") or {}
    mapping = {
        "imdb": "IMDb_Rating", "tmdb": "TMDb_Rating", "rt_critic": "RottenTomatoes_Rating",
        "rt_audience": "RottenTomatoes_UserMeter", "metacritic": "MetaCritic_Rating", "trakt": "Trakt_Rating",
        "letterboxd": "Letterboxd_Rating", "mdblist": "MDBList_Rating",
    }
    for logical, prop in mapping.items():
        val = rating_display(logical, ratings.get(logical))
        if val:
            values[prop] = val
    rank = safe_int(record.get("imdb_top250_tv_rank")) or safe_int(record.get("imdb_top250_rank")) or 0
    if rank:
        values["Top250"] = str(rank)
        values["IMDb_Top250_Rank"] = str(rank)
        if record.get("imdb_top250_tv_rank"):
            values["IMDb_Top250_TV_Rank"] = str(record.get("imdb_top250_tv_rank"))
    series = record.get("series") or {}
    if series.get("status"):
        values["Status"] = str(series.get("status"))
    if series.get("status_date_display") or series.get("status_date"):
        values["StatusDate"] = str(series.get("status_date_display") or parse_date_display(series.get("status_date")))
    for source_key, prop in (("first_air_date", "First_Air_Date"), ("last_air_date", "Last_Air_Date"), ("next_air_date", "Next_Air_Date")):
        if series.get(source_key):
            values[prop] = str(series.get(source_key))
    awards = record.get("awards") or {}
    if safe_int(awards.get("oscar_wins")):
        values["Oscar_Wins"] = str(awards.get("oscar_wins"))
    if safe_int(awards.get("emmy_wins")):
        values["Emmy_Wins"] = str(awards.get("emmy_wins"))
    values["ItemKey"] = "{0}|{1}".format(record.get("type"), record.get("dbid"))
    for prefix in ("LibraryRatings.ListItem.", "TMDbHelper.ListItem."):
        for name, value in values.items():
            win.setProperty(prefix + name, str(value))


def record_for_current_focus(cache: Dict[str, Any]) -> Optional[Dict[str, Any]]:
    dbid = xbmc.getInfoLabel("ListItem.DBID")
    dbtype = xbmc.getInfoLabel("ListItem.DBTYPE") or xbmc.getInfoLabel("ListItem.DBType")
    dbtype = (dbtype or "").lower().strip()
    if dbtype == "tvshow":
        key = "tvshow|" + str(dbid)
    elif dbtype == "episode":
        key = "episode|" + str(dbid)
    elif dbtype == "movie":
        key = "movie|" + str(dbid)
    else:
        return None
    return (cache.get("items") or {}).get(key)

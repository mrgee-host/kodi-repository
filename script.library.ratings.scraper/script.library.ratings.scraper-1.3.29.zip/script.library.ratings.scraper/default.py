# -*- coding: utf-8 -*-
import xbmcgui  # type: ignore
import xbmcaddon  # type: ignore
from resources.lib import core

ADDON = xbmcaddon.Addon()


def notify(msg):
    xbmcgui.Dialog().notification(ADDON.getAddonInfo('name'), msg, xbmcgui.NOTIFICATION_INFO, 5000)


def main():
    items = [
        'Scrape missing ratings/status/Top 250',
        'Refresh all ratings/status/Top 250',
        'Sync IMDb Top 250 Movies + TV Shows',
        'Export CSV report',
        'Check random LIVE internet',
    ]
    idx = xbmcgui.Dialog().select('Library Ratings Scraper', items)
    if idx < 0:
        return
    try:
        if idx == 0:
            summary = core.run_scrape(refresh=False)
            notify('updated {0}, skipped {1}'.format(summary.get('updated'), summary.get('skipped')))
        elif idx == 1:
            ok = xbmcgui.Dialog().yesno('Library Ratings Scraper', 'Refresh all cached ratings/status/Top 250?')
            if ok:
                summary = core.run_scrape(refresh=True)
                notify('refreshed {0}'.format(summary.get('updated')))
        elif idx == 2:
            result = core.sync_top250_all()
            notify('Top 250 synced: movies {0}, tv {1}'.format(result.get('movies'), result.get('tv')))
        elif idx == 3:
            report = core.export_csv(core.load_cache())
            xbmcgui.Dialog().ok('Library Ratings Scraper', 'CSV exported:', report)
        elif idx == 4:
            path = core.live_check(sample=2)
            xbmcgui.Dialog().ok('Library Ratings Scraper', 'Live check saved:', path)
    except Exception as exc:  # pylint: disable=broad-except
        core.log('Menu error: {0}'.format(exc), core.xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Library Ratings Scraper', 'Error:', str(exc))


if __name__ == '__main__':
    main()

Library Ratings Scraper 1.3.29

Fixes the simplified build:
- API key fields are in their own Add-on Settings category: API keys.
- Scrape media type checkboxes are restored: Movies, TV shows, Episodes.
- Settings is removed from the run menu; open settings from Kodi Add-on settings.
- IMDb Top 250 sync now handles both Movies and TV Shows.
- Top 250 sync respects the active media type checkboxes.
- Automatic scraping and cache lifetime remain removed; scraping is manual-only.
- Provider toggles remain removed; flow is fixed internally:
  Movies/TV shows: MDBList first, then OMDb/TMDb fallback.
  Episodes: OMDb for IMDb and TMDb for TMDb.
- NO_RATING marker remains always-on internally.

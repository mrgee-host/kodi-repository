Library Ratings Scraper 1.5.39

- Refresh ratings for this item no longer opens DialogProgress.
- Uses compact AF3 two-line notifications for start, complete, limit, and failure.
- Ratings, awards, RT badges, cache save, and property publication remain unchanged.

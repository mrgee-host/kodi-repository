LRS 1.5.38

Fixes Refresh ratings for this item failing with:
resolve_item() got an unexpected keyword argument ratings_only

The final 1.4.70 external-cache wrapper now accepts and forwards ratings_only.

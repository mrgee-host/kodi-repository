# -*- coding: utf-8 -*-
from __future__ import annotations

import xbmc
import xbmcgui

from resources.lib import core

TITLE = "Library Ratings Scraper"


def _compact_context_text(value, limit=92):
    text = str(value or "").replace("\n", " ").strip().upper()
    text = " ".join(text.split())
    return text if len(text) <= limit else text[: max(0, limit - 3)].rstrip() + "..."


def _context_progress_body(processed, total, title, phase, limit=92):
    prefix = "{0}/{1} ".format(processed, total)
    suffix = " - {0}".format(str(phase or "RATINGS").upper())
    text = str(title or "SELECTED ITEM").replace("\n", " ").strip().upper()
    text = " ".join(text.split())
    available = max(12, limit - len(prefix) - len(suffix))
    if len(text) > available:
        text = text[: max(0, available - 3)].rstrip() + "..."
    return prefix + text + suffix


def _context_item():
    # Context menu normally exposes ListItem.* for the selected row/card.
    for getter in (core.selected_library_item, core.hub_focus_container_item, core.lrs_active_item, core.tmdbhelper_item):
        try:
            item = getter()
        except Exception:  # pylint: disable=broad-except
            item = {}
        if core.valid_library_item(item):
            return item
    return {}


def _is_game_item(item):
    try:
        return core.is_lrs_game_item(item)
    except Exception:
        kind = str((item or {}).get("type") or (item or {}).get("MediaType") or (item or {}).get("DBTYPE") or "").strip().lower()
        return kind == "game" or str((item or {}).get("lrs_game") or "").strip().lower() in ("true", "1", "yes")


def refresh_selected_item():
    dialog = xbmcgui.Dialog()
    item = _context_item()
    if not core.valid_library_item(item) or _is_game_item(item):
        dialog.notification(TITLE, "No movie / TV show / episode identity found", xbmcgui.NOTIFICATION_WARNING, 5000, False)
        return

    media_type = item.get("type") or "item"
    title = item.get("title") or item.get("showtitle") or "Selected item"
    if item.get("type") == "episode":
        title = "{0} - S{1:02d}E{2:02d} - {3}".format(
            item.get("title") or "Episode",
            core.safe_int(item.get("season")) or 0,
            core.safe_int(item.get("episode")) or 0,
            item.get("showtitle") or "Series",
        )

    if not dialog.yesno(TITLE, "Refresh ratings for this item:\n\n\n{0}\n\nThis force-refreshes all LRS data for this selected item.".format(title), nolabel="Cancel", yeslabel="Refresh"):
        return

    compact_title = _compact_context_text(title, 76).title()
    dialog.notification(TITLE, "Refreshing • {0}".format(compact_title), xbmcgui.NOTIFICATION_INFO, 3500, False)
    try:
        cache = core.load_cache()
        existing = core.cache_record(cache, item) or {}
        refreshed = core.resolve_item(item, core.api_keys(), existing, missing_only=False, include_local=False, ratings_only=False)
        if core.media_setting_type(item.get("type")) in ("movie", "tvshow"):
            refreshed = core.resolve_awards_only(item, core.api_keys(), refreshed)
            refreshed = core.resolve_rt_badge_only(item, core.api_keys(), refreshed, force=True)
        key = core.item_key(refreshed)
        if not key or key.endswith("|"):
            key = core.item_key(item)
        cache.setdefault("items", {})[key] = refreshed
        core.save_cache(cache)
        values = core.af3_values(refreshed)
        values["SourceContext"] = "context"
        core.publish_af3_properties(values, key, core.bool_setting("publish_af3_cache", True))
        dialog.notification(TITLE, "Refresh complete • {0}".format(compact_title), xbmcgui.NOTIFICATION_INFO, 5000, False)
    except core.ProviderLimitReached as exc:
        core.log("Context refresh API limit: {0}".format(exc), xbmc.LOGWARNING)
        dialog.notification(TITLE, "API limit reached • {0}".format(compact_title), xbmcgui.NOTIFICATION_WARNING, 6000, False)
    except Exception as exc:  # pylint: disable=broad-except
        core.log("Context refresh failed: {0}".format(exc), xbmc.LOGERROR)
        dialog.notification(TITLE, "Refresh failed • {0}".format(compact_title), xbmcgui.NOTIFICATION_ERROR, 6000, False)


if __name__ == "__main__":
    refresh_selected_item()

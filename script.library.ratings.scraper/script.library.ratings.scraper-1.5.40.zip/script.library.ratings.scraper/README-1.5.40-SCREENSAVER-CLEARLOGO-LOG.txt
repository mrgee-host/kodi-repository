Library Ratings Scraper 1.5.40

Base: 1.5.39

Change:
- Adds one deduplicated INFO log whenever the Arctic Mirage screensaver clearlogo decision changes.
- Logs selected mode: cropv2, default_kodi, or title.
- Logs the item title, final source, exact final path, CropV2 candidate path, and Kodi default clearlogo path.
- Game entries also log the number of clearlogo candidates examined.
- No artwork-selection behavior was changed. This release adds diagnostics only.

Example:
LRS SCREENSAVER CLEARLOGO selected=cropv2 title="Example" source="crop_v2_hash" path="..." cropv2_path="..." default_path="..."

Series status display is normalized to Returning, Ended, or Cancelled without dates. Stored metadata dates remain in the database; only display labels are compacted.

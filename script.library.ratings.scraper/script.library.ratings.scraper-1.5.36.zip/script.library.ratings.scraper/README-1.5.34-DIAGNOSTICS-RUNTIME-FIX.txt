Library Ratings Scraper 1.5.34

- Keeps LRS as rating scrape/cache/settings data owner.
- Restores _diagnostic_files_1500() used by the runtime-v1 diagnostics exporter.
- LRS diagnostic export no longer crashes with NameError after the clean architecture pass.

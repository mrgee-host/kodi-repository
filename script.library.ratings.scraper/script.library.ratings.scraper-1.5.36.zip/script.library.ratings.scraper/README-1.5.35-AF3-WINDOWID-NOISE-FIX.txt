LRS 1.5.35
- Keeps data-owner/diagnostics behavior from 1.5.34.
- Avoids invalid hard-coded AF3 window ids 1101-1104 that caused Kodi 22 repeated Window id does not exist exceptions in Hub windows.

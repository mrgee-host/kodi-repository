Library Ratings Scraper 1.5.36

- Fixes TV status being converted to "Ends at ..." merely because both use ends.png.
- Ends-at is now recognized by source/time semantics.
- Explicitly republishes LibraryRatings.Screensaver.* from the cached record while KPM remains the XML/visual owner.
- Moves the service main entry point after the final compatibility override so the final wrapper is active at runtime.

LRS 1.5.33 clean rating data-owner

Role: rating scraping, refresh, cache and database. Display settings remain in LRS; KPM reads them. AF3 patching and visual row rendering are owned by KPM.

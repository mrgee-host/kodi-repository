Library Ratings Scraper 1.3.60

Fixes the real DB-scale bug:
- MDBList raw JSON value for tomatoes/popcorn/metacritic/trakt is already 0-100.
- DB writer now uses score first for 0-100 families, value only as fallback.
- IMDb/TMDb remain 0-10.
- RT/RT audience/Metacritic/Trakt remain 0-100.
- Fixes rows like RT=4, Meta=5, Trakt=6 caused by earlier normalized in-memory values being chosen before score.

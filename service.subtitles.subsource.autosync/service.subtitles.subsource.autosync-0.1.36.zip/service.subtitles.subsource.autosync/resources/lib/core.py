# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from dataclasses import dataclass
from functools import cmp_to_key
from typing import Any, Dict, List, Optional, Sequence, Tuple

import xbmc
import xbmcgui

from .common import (
    ADDON,
    Cue,
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARNING,
    MediaContext,
    SubtitleCandidate,
    SubtitleTrack,
    SyncResult,
    failure_message,
    log,
    notify,
    read_text,
    setting_bool,
    setting_float,
    setting_int,
)
from .kodi_runtime import automatic_skip_reason, apply_external_subtitle, get_media_context
from .local_scan import LocalSubtitle, load_local_subtitles
from .mkv_timeline import find_indonesian_embedded, rank_reference_tracks, read_mkv_subtitle_tracks
from .release_match import RELEASE_FAMILY_ORDER, arrange_candidates_for_auto, candidate_owner, rank_candidates, release_family, trusted_source
from .smartsync_engine import synchronize
from .storage import load_manifest, save_profile_variant, rewrite_cleaned_local_subtitle
from .diagnostics_store import save_snapshot
from .subtitle_io import parse_subtitle_text, parse_subtitle_text_with_report, render_srt
from .subsource_api import SubSourceClient, SubSourceError
from .profile_store import (
    activate_profile,
    load_season_preference,
    load_session,
    preference_bonus,
    profile_preference_score,
    save_season_preference,
    save_session,
)

PAUSE_WINDOW_PROPERTY = "SubSourceAutoSync.PausedForSubtitle"


@dataclass
class TargetSource:
    label: str
    cues: List[Cue]
    candidate: Optional[SubtitleCandidate] = None
    filename: str = ""
    runtime_score: float = 0.0
    ads_removed: int = 0
    cleanup_changed: bool = False


@dataclass
class ReferenceSource:
    label: str
    cues: List[Cue]
    embedded_track: Optional[SubtitleTrack] = None
    candidate: Optional[SubtitleCandidate] = None
    filename: str = ""
    family: str = "other"
    runtime_score: float = 0.0
    ads_removed: int = 0


@dataclass
class SyncChoice:
    target: TargetSource
    reference: ReferenceSource
    result: SyncResult


class AutoSyncWorkflow:
    _lock = threading.Lock()

    def __init__(self, player: xbmc.Player):
        self.player = player
        self._paused_by_addon = False
        self._pause_position = 0.0
        self._manual_window_opened = False
        self._workflow_token = ""
        self._current_local_reference_paths: List[str] = []
        self._diagnostics: Dict[str, Any] = {
            "english_candidates": [],
            "indonesian_candidates": [],
            "sync_matrix": [],
            "selected_profiles": [],
        }

    def _save_diagnostics(self, media: MediaContext, status: str = "") -> None:
        try:
            payload = dict(self._diagnostics)
            payload["status"] = status
            save_snapshot(media, payload)
        except Exception as exc:
            log("diagnostic snapshot failed: %s" % exc, LOG_DEBUG)

    def _still_current(self, media: MediaContext) -> bool:
        try:
            if not (self.player.isPlayingVideo() and self.player.getPlayingFile() == media.path):
                return False
            if self._workflow_token:
                current = xbmcgui.Window(10000).getProperty("SubSourceAutoSync.WorkflowToken")
                if current and current != self._workflow_token:
                    return False
            return True
        except Exception:
            return False

    @staticmethod
    def _candidate_stats(candidate: SubtitleCandidate) -> str:
        return (
            "id=%s score=%.2f rating=%.2f votes=%d trusted=%s latest=%d downloads=%d hi=%s release=%s"
            % (
                candidate.subtitle_id,
                candidate.score,
                candidate.rating,
                candidate.rating_votes,
                trusted_source(candidate) or "no",
                int(getattr(candidate, "uploaded_at", 0) or 0),
                candidate.download_count,
                "yes" if candidate.hearing_impaired else "no",
                candidate.release_info,
            )
        )

    def _pause_episode_if_needed(self, media: MediaContext) -> None:
        if not media.is_episode or not setting_bool("pause_episode_until_ready", True):
            return
        if not self._still_current(media):
            return
        try:
            position = float(self.player.getTime())
        except Exception:
            position = 0.0
        # Do not interrupt somebody who intentionally started searching well
        # into an episode. This protection is for dialogue at cold start.
        if position > 15.0:
            return
        try:
            already_paused = bool(xbmc.getCondVisibility("Player.Paused"))
        except Exception:
            already_paused = False
        if already_paused:
            return
        try:
            self.player.pause()
            self._paused_by_addon = True
            self._pause_position = position
            xbmcgui.Window(10000).setProperty(PAUSE_WINDOW_PROPERTY, "1")
            log("episode paused at %.3fs while subtitle is prepared" % position, LOG_INFO)
        except Exception as exc:
            log("could not pause episode: %s" % exc, LOG_WARNING)

    def _resume_after_search(self, rewind: bool = True) -> None:
        if not self._paused_by_addon:
            return
        try:
            if rewind and self._pause_position >= 0:
                self.player.seekTime(max(0.0, self._pause_position - 0.35))
        except Exception:
            pass
        try:
            if xbmc.getCondVisibility("Player.Paused"):
                self.player.pause()
        except Exception:
            try:
                self.player.pause()
            except Exception:
                pass
        try:
            xbmcgui.Window(10000).clearProperty(PAUSE_WINDOW_PROPERTY)
        except Exception:
            pass
        self._paused_by_addon = False

    def _open_manual_search(self, media: MediaContext, reason: str) -> None:
        log("automatic selection fell back to manual search: %s" % reason, LOG_WARNING)
        self._diagnostics["fallback_reason"] = reason
        self._save_diagnostics(media, "manual_fallback")
        if not setting_bool("open_manual_on_failure", True) or not self._still_current(media):
            self._resume_after_search(rewind=True)
            notify(failure_message("AUTOSYNC FAILED", reason), warning=True, timeout=6500)
            return
        notify("AUTO MATCH UNCERTAIN • CHOOSE A SUBTITLE", warning=True, timeout=5000)
        self._manual_window_opened = True
        try:
            xbmc.executebuiltin("ActivateWindow(SubtitleSearch)")
        except Exception as exc:
            log("failed opening SubtitleSearch: %s" % exc, LOG_WARNING)
            self._resume_after_search(rewind=True)

    @staticmethod
    def _target_from_local(item: LocalSubtitle, media: MediaContext) -> TargetSource:
        return TargetSource(
            label="local: %s" % os.path.basename(item.path),
            cues=item.cues,
            filename=item.path,
            runtime_score=AutoSyncWorkflow._runtime_score(item.cues, media),
            ads_removed=int(item.ads_removed or 0),
            cleanup_changed=bool(item.cleanup_changed),
        )

    @staticmethod
    def _reference_from_local(item: LocalSubtitle, media: MediaContext) -> ReferenceSource:
        return ReferenceSource(
            label="local English: %s" % os.path.basename(item.path),
            cues=item.cues,
            filename=item.path,
            family="local",
            runtime_score=AutoSyncWorkflow._runtime_score(item.cues, media),
            ads_removed=int(item.ads_removed or 0),
        )

    def _save_single_direct_profile(
        self,
        media: MediaContext,
        target: TargetSource,
        mode: str,
        status: str,
        apply_external: bool = True,
        announce: bool = True,
    ) -> str:
        if mode.startswith("local") and target.filename and target.cleanup_changed:
            try:
                rewrite_cleaned_local_subtitle(media, target.filename, render_srt(target.cues))
            except Exception as exc:
                log("selected local subtitle in-place cleanup failed: %s" % exc, LOG_WARNING)
        profile = self._raw_profile(target)
        profile.update({
            "mode": mode,
            "language": "indonesian",
            "source_family": "embedded" if mode == "embedded_indonesian" else "local",
            "target_owner": "embedded" if mode == "embedded_indonesian" else "local",
            "cycle_enabled": True,
            "risky": False,
            "ads_removed": int(target.ads_removed or 0),
        })
        profile["manifest"]["method"] = mode
        profile["manifest"]["alternatives_loaded"] = False
        profile["variant_path"] = save_profile_variant(media, 0, profile.pop("_srt"))
        session = {
            "version": 6,
            "profile_order": "single_direct_then_expand_v1",
            "active_index": 0,
            "cycle_indices": [0],
            "alternatives_loaded": False,
            "changed_at": 0,
            "stable_play_seconds": 0.0,
            "profiles": [profile],
        }
        save_session(media, session)
        self._diagnostics["selected_profiles"] = [{
            "index": 0, "family": "raw", "mode": mode,
            "target_id": profile.get("target_subsource_id"),
            "reference_id": None, "risky": False, "cycle_enabled": True,
        }]
        self._save_diagnostics(media, status)
        if apply_external:
            return activate_profile(self.player, media, session, 0, announce=announce)
        return profile["variant_path"]

    def _embedded_references(self, tracks: Sequence[SubtitleTrack], media: MediaContext) -> List[ReferenceSource]:
        english_tracks = [
            track for track in rank_reference_tracks(tracks, media.duration_ms)
            if track.language == "en" or "english" in (track.name or "").lower()
        ][:2]
        return [
            ReferenceSource(
                label="embedded track %s (%s/%s)" % (track.track_number, track.language, track.codec_id),
                cues=track.cues,
                embedded_track=track,
                family="embedded",
                runtime_score=self._runtime_score(track.cues, media),
                ads_removed=int(track.ads_removed or 0),
            )
            for track in english_tracks
        ]

    def _active_target_from_session(self, media: MediaContext, session: Dict[str, Any]) -> Optional[TargetSource]:
        profiles = list(session.get("profiles") or [])
        if not profiles:
            return None
        index = int(session.get("active_index", 0)) % len(profiles)
        profile = profiles[index]
        if str(profile.get("language") or "indonesian").lower().startswith("en"):
            return None
        path = str(profile.get("variant_path") or "")
        if not path:
            return None
        try:
            cues = parse_subtitle_text(read_text(path), path, media.show_title or media.title)
        except Exception as exc:
            log("active profile could not be parsed for expansion: %s" % exc, LOG_WARNING)
            return None
        if len(cues) < 8:
            return None
        candidate = None
        subtitle_id = str(profile.get("target_subsource_id") or "")
        if subtitle_id:
            candidate = SubtitleCandidate(
                subtitle_id=subtitle_id,
                language="indonesian",
                release_info=str(profile.get("target_release") or profile.get("target_label") or ""),
                owner=str(profile.get("target_owner") or ""),
            )
        return TargetSource(
            label=str(profile.get("target_label") or "active profile"),
            cues=cues,
            candidate=candidate,
            filename=str(profile.get("target_filename") or path),
            runtime_score=self._runtime_score(cues, media),
            ads_removed=int(profile.get("ads_removed") or 0),
        )

    def run(self) -> None:
        if not setting_bool("enabled", True):
            return
        if not self._lock.acquire(False):
            log("workflow skipped because another run is active", LOG_DEBUG)
            return
        try:
            self._run_locked()
        except Exception as exc:
            log("workflow failed: %s" % exc, LOG_WARNING)
            self._resume_after_search(rewind=True)
            notify(failure_message("AUTOSYNC FAILED", exc), warning=True)
        finally:
            # When SubtitleSearch was opened we intentionally leave playback
            # paused. Selecting a result through this add-on resumes it. If the
            # dialog is cancelled, pressing Play resumes normally.
            if not self._manual_window_opened:
                self._resume_after_search(rewind=True)
            self._lock.release()

    @staticmethod
    def _arrange_auto_candidates(
        candidates: Sequence[SubtitleCandidate],
        media: MediaContext,
        preferred_id: str = "",
    ) -> List[SubtitleCandidate]:
        mode = "tv-family-best" if media.is_episode else "movie-family-first"
        arranged = arrange_candidates_for_auto(candidates, media, mode=mode, preferred_id=preferred_id)
        log(
            "automatic Indonesian candidate mode=%s order=%s"
            % (mode, ["%s:%s:%s" % (release_family(item.release_info), item.subtitle_id, trusted_source(item) or "-") for item in arranged[:12]]),
            LOG_INFO,
        )
        return arranged

    def _run_locked(self) -> None:
        media = get_media_context(self.player)
        if not media:
            return

        skip_reason = automatic_skip_reason(self.player, media)
        if skip_reason:
            log(
                "automatic subtitle skipped reason=%s type=%s library_id=%s path=%s"
                % (skip_reason, media.media_type, media.library_id, media.path),
                LOG_INFO,
            )
            return

        # A manual subtitle selection changes this token and invalidates any
        # older automatic worker that is still downloading in the background.
        self._workflow_token = "%d:%s" % (int(time.time() * 1000), media.path)
        try:
            xbmcgui.Window(10000).setProperty("SubSourceAutoSync.WorkflowToken", self._workflow_token)
        except Exception:
            pass

        preference = load_season_preference(media)
        tracks = read_mkv_subtitle_tracks(media.path, media.duration_ms, media.show_title or media.title)
        local_subtitles = load_local_subtitles(media)
        local_indonesian = [item for item in local_subtitles if item.language == "id"]
        local_english = [item for item in local_subtitles if item.language == "en"]
        self._diagnostics["local_subtitles"] = [
            {"path": item.path, "language": item.language, "cue_count": len(item.cues)}
            for item in local_subtitles
        ]

        # Exact-video Indonesian text always wins over learned online season
        # data. Embedded is preferred first, then matching sidecars beside the
        # video (including Subs/Subtitles folders).
        embedded_indonesian = find_indonesian_embedded(tracks, media.duration_ms)
        if embedded_indonesian and self._still_current(media):
            target = TargetSource(
                label="embedded Indonesian track %s" % embedded_indonesian.track_number,
                cues=embedded_indonesian.cues,
                filename="embedded-track-%s" % embedded_indonesian.track_number,
                runtime_score=self._runtime_score(embedded_indonesian.cues, media),
                ads_removed=int(embedded_indonesian.ads_removed or 0),
            )
            # Embedded text is extracted, cleaned, rendered to an external SRT,
            # then applied. Selecting the original internal track directly would
            # bypass the always-on ad/credit cleaner.
            self._save_single_direct_profile(
                media, target, "embedded_indonesian", "embedded_indonesian_cleaned_direct",
                apply_external=True, announce=False,
            )
            ready = ["SUBTITLE READY"]
            if target.ads_removed:
                ready.append("%d ADS REMOVED" % target.ads_removed)
            ready.append("F3 FOR ALTERNATIVES")
            notify(" • ".join(ready), timeout=6000)
            return

        if local_indonesian and self._still_current(media):
            target = self._target_from_local(local_indonesian[0], media)
            self._save_single_direct_profile(
                media, target, "local_indonesian", "local_indonesian_direct", announce=False
            )
            ready = ["SUBTITLE READY"]
            if target.ads_removed:
                ready.append("%d ADS REMOVED" % target.ads_removed)
            ready.append("F3 FOR ALTERNATIVES")
            notify(" • ".join(ready), timeout=6000)
            return

        manifest = load_manifest(media)
        session = load_session(media)
        current_local_reference_paths = sorted(item.path for item in local_english)
        self._current_local_reference_paths = list(current_local_reference_paths)
        if manifest and session:
            saved_local_reference_paths = sorted(manifest.get("local_reference_paths") or [])
            if saved_local_reference_paths == current_local_reference_paths:
                profiles = list(session.get("profiles") or [])
                active = int(session.get("active_index") or 0) if profiles else -1
                active_profile = profiles[active] if 0 <= active < len(profiles) else {}
                output_path = (
                    manifest.get("active_profile_path")
                    or session.get("active_output_path")
                    or (active_profile.get("variant_path") if isinstance(active_profile, dict) else "")
                    or manifest.get("output_path")
                )
                if output_path and self._still_current(media) and apply_external_subtitle(self.player, output_path):
                    log("reused valid AutoSync result with %d profiles: %s" % (len(session.get("profiles") or []), output_path))
                    return
            else:
                log(
                    "manifest reuse skipped because local English sidecars changed saved=%s current=%s"
                    % (saved_local_reference_paths, current_local_reference_paths),
                    LOG_INFO,
                )

        # Only text tied to this exact video is trusted automatically: embedded
        # English or a matching English sidecar in the same folder tree.
        references = self._embedded_references(tracks, media)
        references.extend(self._reference_from_local(item, media) for item in local_english[:4])
        local_targets = [self._target_from_local(item, media) for item in local_indonesian]
        has_subsource_identity = bool(media.imdb_id or (media.is_episode and media.show_title))
        if not has_subsource_identity and not local_targets:
            self._open_manual_search(media, "Identitas IMDb/judul serial tidak tersedia di metadata Kodi.")
            return

        api_key = ADDON.getSetting("subsource_api_key").strip()
        client: Optional[SubSourceClient] = None
        movie_id = ""
        if api_key and has_subsource_identity:
            client = SubSourceClient(api_key)
            try:
                movie_id = client.resolve_movie_id(media)
            except SubSourceError as exc:
                log("SubSource identity resolution failed: %s" % exc, LOG_WARNING)
                if not local_targets:
                    self._open_manual_search(media, str(exc))
                    return
        elif not local_targets:
            notify("ADD SUBSOURCE API KEY IN SETTINGS", warning=True)
            return

        # A proven season source is tried directly. Broad candidate search only
        # runs when that exact source/member is unavailable or unreadable.
        if client and movie_id and preference and self._try_manual_season_preference(
            client, movie_id, media, preference, references
        ):
            return

        self._pause_episode_if_needed(media)

        candidates: List[SubtitleCandidate] = []
        if client and movie_id:
            try:
                candidates = rank_candidates(
                    client.list_subtitles(movie_id, "indonesian"),
                    media,
                    prefer_non_sdh=setting_bool("prefer_non_sdh", True),
                )
            except SubSourceError as exc:
                if not local_targets:
                    self._open_manual_search(media, "Pencarian subtitle Indonesia gagal: %s" % exc)
                    return

        self._diagnostics["indonesian_candidates"] = [
            {
                "subtitle_id": candidate.subtitle_id,
                "language": "indonesian",
                "family": release_family(candidate.release_info),
                "release": candidate.release_info,
                "owner": candidate_owner(candidate),
                "trusted_source": trusted_source(candidate),
                "caption": str(getattr(candidate, "caption", "") or ""),
                "uploaded_at": int(getattr(candidate, "uploaded_at", 0) or 0),
                "rating": float(candidate.rating or 0.0),
                "rating_votes": int(candidate.rating_votes or 0),
                "downloads": int(candidate.download_count or 0),
                "rank": rank,
                "score": round(candidate.score, 4),
                "attempted": False,
                "accepted": False,
                "reason": "not attempted",
            }
            for rank, candidate in enumerate(candidates[:100], 1)
        ]

        # A saved season source is already attempted explicitly above. If that
        # exact source fails, broad search returns to the normal community order
        # instead of promoting the failed preference a second time.
        preferred_id = str((preference or {}).get("target_subsource_id") or "")
        candidates = self._arrange_auto_candidates(candidates, media, preferred_id)
        self._diagnostics["automatic_candidate_mode"] = ("tv-family-best" if media.is_episode else "movie-family-first")

        desired = max(1, min(setting_int("automatic_indonesian_profiles", 5), 8))
        targets = list(local_targets)
        cursor = 0
        attempt_limit = min(len(candidates), max(20, desired * 5), 40)
        while len([item for item in targets if item.candidate]) < desired and cursor < attempt_limit:
            if not self._still_current(media):
                log("automatic workflow cancelled by a newer/manual subtitle session", LOG_INFO)
                return
            workers = max(1, min(setting_int("parallel_downloads", 3), 4))
            chunk = candidates[cursor : min(attempt_limit, cursor + workers)]
            cursor += len(chunk)
            targets.extend(self._download_indonesian_chunk(client, chunk, media, workers) if client else [])
            if not chunk:
                break

        if not targets:
            self._save_diagnostics(media, "no_indonesian_candidates")
            self._open_manual_search(media, "Subtitle Indonesia tidak ditemukan di SubSource.")
            return

        if not self._still_current(media):
            log("automatic workflow cancelled before profile creation", LOG_INFO)
            return

        if references:
            choices = self._rank_sync_choices(targets, references)
            if choices:
                self._apply_choices(media, choices, choices[0].target, preference)
                return
            # Embedded reference exists but sync failed. RAW candidates remain
            # useful and must still be offered to the user.
            self._apply_raw_targets(media, targets, preference, "trusted_text_sync_failed_raw_fallback")
            return

        # No embedded or matching local English text reference: do not guess the MKV release and
        # do not fetch online English. Cycle untouched Indonesian candidates.
        self._apply_raw_targets(media, targets, preference, "automatic_raw_no_trusted_text")

    def expand_alternatives(self, media: Optional[MediaContext] = None) -> bool:
        """Expand a one-profile fast path into normal alternatives on F3/Back-Select."""
        if not setting_bool("enabled", True):
            return False
        if not self._lock.acquire(False):
            notify("ALTERNATIVE SEARCH IS STILL RUNNING", timeout=3500)
            return False
        try:
            media = media or get_media_context(self.player)
            if not media:
                return False
            self._workflow_token = "%d:%s:expand" % (int(time.time() * 1000), media.path)
            try:
                xbmcgui.Window(10000).setProperty("SubSourceAutoSync.WorkflowToken", self._workflow_token)
            except Exception:
                pass
            return self._expand_alternatives_locked(media)
        except Exception as exc:
            log("alternative expansion failed: %s" % exc, LOG_WARNING)
            notify(failure_message("ALTERNATIVE SEARCH FAILED", exc), warning=True, timeout=6500)
            return False
        finally:
            self._lock.release()

    def _verified_reference_from_session(
        self,
        client: Optional[SubSourceClient],
        media: MediaContext,
        session: Dict[str, Any],
    ) -> Optional[ReferenceSource]:
        profiles = list(session.get("profiles") or [])
        if not profiles or client is None:
            return None
        index = int(session.get("active_index", 0)) % len(profiles)
        profile = profiles[index]
        reference_id = str(profile.get("reference_subsource_id") or "")
        mode = str(profile.get("mode") or "")
        if not reference_id or mode not in (
            "manual_reference_confirmed", "synced_to_manual_reference", "manual_reference_only"
        ):
            return None
        candidate = SubtitleCandidate(
            subtitle_id=reference_id,
            language="english",
            release_info=str(profile.get("reference_release") or profile.get("reference_label") or ""),
            owner=str(profile.get("reference_owner") or ""),
        )
        try:
            downloaded = client.download_and_select(candidate, media)
            cues, cleanup_report = parse_subtitle_text_with_report(
                self._decode_payload(downloaded.payload), downloaded.filename, media.show_title or media.title
            )
            if len(cues) < 20:
                return None
            return ReferenceSource(
                label="verified season English [%s]: %s" % (candidate.subtitle_id, candidate.release_info),
                cues=cues,
                candidate=candidate,
                filename=downloaded.filename,
                family=str(profile.get("source_family") or profile.get("family") or "other"),
                runtime_score=self._runtime_score(cues, media),
                ads_removed=int(cleanup_report.removed_lines or 0),
            )
        except Exception as exc:
            log("verified season English could not be reused for expansion: %s" % exc, LOG_WARNING)
            return None

    def _expand_alternatives_locked(self, media: MediaContext) -> bool:
        session = load_session(media)
        if not session:
            raise RuntimeError("profil aktif belum tersedia")
        if session.get("alternatives_loaded"):
            raise RuntimeError("semua alternatif yang tersedia sudah dimuat")

        notify("SEARCHING FOR INDONESIAN ALTERNATIVES", timeout=4500)
        tracks = read_mkv_subtitle_tracks(media.path, media.duration_ms, media.show_title or media.title)
        local_subtitles = load_local_subtitles(media)
        local_indonesian = [item for item in local_subtitles if item.language == "id"]
        local_english = [item for item in local_subtitles if item.language == "en"]
        references = self._embedded_references(tracks, media)
        references.extend(self._reference_from_local(item, media) for item in local_english[:4])
        self._current_local_reference_paths = sorted(item.path for item in local_english)

        has_identity = bool(media.imdb_id or (media.is_episode and media.show_title))
        client: Optional[SubSourceClient] = None
        movie_id = ""
        api_key = ADDON.getSetting("subsource_api_key").strip()
        if api_key and has_identity:
            client = SubSourceClient(api_key)
            movie_id = client.resolve_movie_id(media)

        verified = self._verified_reference_from_session(client, media, session)
        if verified is not None and not references:
            references.append(verified)

        targets: List[TargetSource] = []
        active_target = self._active_target_from_session(media, session)
        if active_target is not None:
            targets.append(active_target)
        targets.extend(self._target_from_local(item, media) for item in local_indonesian)

        candidates: List[SubtitleCandidate] = []
        if client and movie_id:
            candidates = rank_candidates(
                client.list_subtitles(movie_id, "indonesian"), media,
                prefer_non_sdh=setting_bool("prefer_non_sdh", True),
            )
            desired = max(2, min(setting_int("automatic_indonesian_profiles", 5), 8))
            existing_id = str((session.get("profiles") or [{}])[int(session.get("active_index", 0))].get("target_subsource_id") or "")
            candidates = [item for item in candidates if str(item.subtitle_id) != existing_id]
            candidates = self._arrange_auto_candidates(candidates, media)
            self._diagnostics["automatic_candidate_mode"] = ("tv-family-best" if media.is_episode else "movie-family-first")
            cursor = 0
            attempt_limit = min(len(candidates), max(20, desired * 5), 40)
            while len([item for item in targets if item.candidate]) < desired and cursor < attempt_limit:
                workers = max(1, min(setting_int("parallel_downloads", 3), 4))
                chunk = candidates[cursor:min(attempt_limit, cursor + workers)]
                cursor += len(chunk)
                targets.extend(self._download_indonesian_chunk(client, chunk, media, workers))
                if not chunk:
                    break

        if len(targets) < 2:
            session["alternatives_loaded"] = True
            save_session(media, session)
            raise RuntimeError("subtitle Indonesia alternatif tidak ditemukan")

        if references:
            choices = self._rank_sync_choices(targets, references)
            if choices:
                self._apply_choices(media, choices, active_target, None)
                return True

        # No trusted English clock. Keep the current fast-path subtitle at 00
        # and jump directly to the first newly downloaded RAW alternative.
        self._apply_raw_targets(
            media, targets, None,
            status="expanded_raw_after_single_profile",
            initial_index=1,
        )
        return True

    @staticmethod
    def _candidate_from_preference(preference: Dict[str, Any], kind: str, language: str) -> Optional[SubtitleCandidate]:
        subtitle_id = str(preference.get("%s_subsource_id" % kind) or "")
        if not subtitle_id:
            return None
        return SubtitleCandidate(
            subtitle_id=subtitle_id,
            language=language,
            release_info=str(preference.get("%s_release" % kind) or ""),
            owner=str(preference.get("%s_owner" % kind) or ""),
        )

    def _apply_manual_original_target(
        self, media: MediaContext, target: TargetSource, source: str = "season_manual_original"
    ) -> str:
        profile = self._raw_profile(target)
        candidate = target.candidate
        profile.update({
            "mode": "manual_original",
            "language": "indonesian",
            "source_family": release_family(candidate.release_info if candidate else target.label),
            "target_owner": candidate_owner(candidate) if candidate else "local",
            "target_filename": target.filename,
            "cycle_enabled": True,
        })
        profile["manifest"]["method"] = "manual_indonesian_original"
        profile["variant_path"] = save_profile_variant(media, 0, profile.pop("_srt"))
        session = {
            "version": 4, "profile_order": "manual_single_original_v1",
            "active_index": 0, "cycle_indices": [0], "changed_at": 0,
            "stable_play_seconds": 0.0, "alternatives_loaded": False, "profiles": [profile],
        }
        save_session(media, session)
        self._diagnostics["selected_profiles"] = [{
            "index": 0, "mode": "manual_original",
            "target_id": profile.get("target_subsource_id"), "risky": False,
        }]
        self._save_diagnostics(media, source)
        return activate_profile(self.player, media, session, 0, announce=True)

    def _try_manual_season_preference(
        self, client: SubSourceClient, movie_id: str, media: MediaContext, preference: Dict[str, Any],
        embedded_references: Optional[Sequence[ReferenceSource]] = None,
    ) -> bool:
        mode = str(preference.get("mode") or "")
        if mode in ("manual_original", "automatic_raw", "indonesian_raw"):
            candidate = self._candidate_from_preference(preference, "target", "indonesian")
            if not candidate:
                return False
            try:
                downloaded = client.download_and_select(candidate, media)
                cues, cleanup_report = parse_subtitle_text_with_report(
                    self._decode_payload(downloaded.payload), downloaded.filename, media.show_title or media.title
                )
                if len(cues) < 8:
                    raise ValueError("subtitle has too few cues: %d" % len(cues))
                target = TargetSource(
                    label="Season manual Indonesian [%s]: %s" % (candidate.subtitle_id, candidate.release_info),
                    cues=cues, candidate=candidate, filename=downloaded.filename,
                    runtime_score=self._runtime_score(cues, media),
                    ads_removed=int(cleanup_report.removed_lines or 0),
                )
                log(
                    "manual Indonesian season preference reused id=%s member=%s"
                    % (candidate.subtitle_id, downloaded.filename), LOG_INFO,
                )
                self._apply_manual_original_target(media, target)
                return True
            except Exception as exc:
                log("manual Indonesian season preference failed: %s" % exc, LOG_WARNING)
                return False

        if mode in ("embedded_sync", "local_reference_sync", "automatic_embedded_sync", "automatic") and embedded_references:
            candidate = self._candidate_from_preference(preference, "target", "indonesian")
            if candidate:
                try:
                    downloaded = client.download_and_select(candidate, media)
                    cues, cleanup_report = parse_subtitle_text_with_report(
                        self._decode_payload(downloaded.payload), downloaded.filename, media.show_title or media.title
                    )
                    if len(cues) < 8:
                        raise ValueError("subtitle has too few cues: %d" % len(cues))
                    target = TargetSource(
                        label="Season trusted-text-sync Indonesian [%s]: %s" % (candidate.subtitle_id, candidate.release_info),
                        cues=cues, candidate=candidate, filename=downloaded.filename,
                        runtime_score=self._runtime_score(cues, media),
                        ads_removed=int(cleanup_report.removed_lines or 0),
                    )
                    choices = self._rank_sync_choices([target], list(embedded_references))
                    if choices:
                        self._apply_choices(media, choices, target, preference)
                        log("trusted-text-reference season preference reused target=%s" % candidate.subtitle_id, LOG_INFO)
                        return True
                except Exception as exc:
                    log("trusted-text-reference season preference failed: %s" % exc, LOG_WARNING)

        if mode not in ("manual_reference_confirmed", "synced_to_manual_reference", "manual_reference_only"):
            return False
        reference_candidate = self._candidate_from_preference(preference, "reference", "english")
        if not reference_candidate:
            return False
        try:
            downloaded_ref = client.download_and_select(reference_candidate, media)
            reference_cues, cleanup_report = parse_subtitle_text_with_report(
                self._decode_payload(downloaded_ref.payload), downloaded_ref.filename, media.show_title or media.title
            )
            if len(reference_cues) < 20:
                raise ValueError("English reference has too few cues: %d" % len(reference_cues))
            reference = ReferenceSource(
                label="Season manual English [%s]: %s" % (reference_candidate.subtitle_id, reference_candidate.release_info),
                cues=reference_cues, candidate=reference_candidate, filename=downloaded_ref.filename,
                family=str(preference.get("family") or release_family(reference_candidate.release_info)),
                runtime_score=self._runtime_score(reference_cues, media),
                ads_removed=int(cleanup_report.removed_lines or 0),
            )
            reference_profile = {
                "family": "english",
                "source_family": reference.family,
                "language": "english",
                "mode": "manual_reference_preview",
                "reference_label": reference.label,
                "reference_release": reference_candidate.release_info,
                "reference_subsource_id": reference_candidate.subtitle_id,
                "reference_owner": candidate_owner(reference_candidate),
                "reference_filename": downloaded_ref.filename,
                "risky": False,
            }

            candidates = rank_candidates(
                client.list_subtitles(movie_id, "indonesian"), media,
                prefer_non_sdh=setting_bool("prefer_non_sdh", True),
            )
            preferred_target = self._candidate_from_preference(preference, "target", "indonesian")
            if preferred_target:
                exact_targets = self._download_indonesian_chunk(client, [preferred_target], media, 1)
                exact_choices = self._rank_sync_choices(exact_targets, [reference]) if exact_targets else []
                if exact_choices:
                    self._apply_manual_reference_choices(media, exact_choices, reference_profile, reference, preference)
                    log(
                        "manual English season pair reused directly reference=%s target=%s"
                        % (reference_candidate.subtitle_id, preferred_target.subtitle_id), LOG_INFO,
                    )
                    return True
                log("saved manual English target unavailable; falling back to broad Indonesian search", LOG_WARNING)
                candidates = [
                    item for item in candidates if str(item.subtitle_id) != str(preferred_target.subtitle_id)
                ]
            candidates = self._arrange_auto_candidates(
                candidates, media,
                str(preferred_target.subtitle_id) if preferred_target else "",
            )
            self._diagnostics["automatic_candidate_mode"] = ("tv-family-best" if media.is_episode else "movie-family-first")
            max_valid = max(3, setting_int("max_candidates", 10))
            attempt_limit = min(len(candidates), max(30, max_valid * 5), 50)
            targets: List[TargetSource] = []
            cursor = 0
            while len(targets) < max_valid and cursor < attempt_limit:
                workers = max(1, min(setting_int("parallel_downloads", 3), 4))
                chunk = candidates[cursor : min(attempt_limit, cursor + workers)]
                cursor += len(chunk)
                targets.extend(self._download_indonesian_chunk(client, chunk, media, workers))
                if not chunk:
                    break
            choices = self._rank_sync_choices(targets, [reference]) if targets else []
            self._apply_manual_reference_choices(media, choices, reference_profile, reference, preference)
            log(
                "manual English season reference reused id=%s member=%s"
                % (reference_candidate.subtitle_id, downloaded_ref.filename), LOG_INFO,
            )
            return True
        except Exception as exc:
            log("manual English season reference reuse failed: %s" % exc, LOG_WARNING)
            return False

    def _download_reference_candidates(
        self,
        client: SubSourceClient,
        movie_id: str,
        media: MediaContext,
        preference: Optional[Dict[str, Any]] = None,
    ) -> List[ReferenceSource]:
        try:
            candidates = rank_candidates(
                client.list_subtitles(movie_id, "english"),
                media,
                prefer_non_sdh=setting_bool("prefer_non_sdh", True),
            )
        except SubSourceError as exc:
            log("English reference search failed: %s" % exc, LOG_WARNING)
            return []

        grouped: Dict[str, List[SubtitleCandidate]] = {}
        diag_rows: Dict[str, Dict[str, Any]] = {}
        for rank, candidate in enumerate(candidates[:100], 1):
            family = release_family(candidate.release_info)
            grouped.setdefault(family, []).append(candidate)
            row = {
                "subtitle_id": candidate.subtitle_id,
                "language": "english",
                "family": family,
                "release": candidate.release_info,
                "owner": candidate_owner(candidate),
                "trusted_source": trusted_source(candidate),
                "caption": str(getattr(candidate, "caption", "") or ""),
                "uploaded_at": int(getattr(candidate, "uploaded_at", 0) or 0),
                "rating": float(candidate.rating or 0.0),
                "rating_votes": int(candidate.rating_votes or 0),
                "downloads": int(candidate.download_count or 0),
                "rank": rank,
                "score": round(candidate.score, 4),
                "attempted": False,
                "accepted": False,
                "reason": "not attempted",
            }
            diag_rows[candidate.subtitle_id] = row
        self._diagnostics["english_candidates"] = list(diag_rows.values())

        preferred_family = str((preference or {}).get("family") or "")
        family_order = list(RELEASE_FAMILY_ORDER)
        if preferred_family in family_order:
            family_order.remove(preferred_family)
            family_order.insert(0, preferred_family)
        max_families = max(2, min(setting_int("english_release_families", 8), len(RELEASE_FAMILY_ORDER)))
        selected_families = [family for family in family_order if grouped.get(family)][:max_families]
        if not selected_families:
            return []

        for family in selected_families:
            grouped[family].sort(
                key=lambda item: (
                    preference_bonus(item.subtitle_id, item.release_info, preference, "reference"),
                    item.score, item.download_count, item.rating_votes, item.rating,
                ),
                reverse=True,
            )

        log(
            "English references grouped families=%s candidates=%d"
            % (selected_families, len(candidates)),
            LOG_INFO,
        )

        def fetch_family(family: str) -> List[ReferenceSource]:
            # SubRip gets its own family. Generic Other is deliberately wider
            # because unrelated official rips and fan packs often share it.
            accept_limit = 5 if family == "other" else 2
            attempt_limit = 12 if family == "other" else 6
            attempts = grouped.get(family, [])[:attempt_limit]
            accepted: List[ReferenceSource] = []
            for index, candidate in enumerate(attempts, 1):
                row = diag_rows.get(candidate.subtitle_id)
                if row is not None:
                    row["attempted"] = True
                log(
                    "English family=%s attempt %d/%d %s"
                    % (family, index, len(attempts), self._candidate_stats(candidate)),
                    LOG_INFO,
                )
                try:
                    downloaded = client.download_and_select(candidate, media)
                    cues, cleanup_report = parse_subtitle_text_with_report(
                        self._decode_payload(downloaded.payload), downloaded.filename, media.show_title or media.title
                    )
                    if len(cues) < 20:
                        raise ValueError("subtitle has too few cues: %d" % len(cues))
                    runtime_score = self._runtime_score(cues, media)
                    reference = ReferenceSource(
                        label="SubSource English [%s]: %s" % (candidate.subtitle_id, candidate.release_info),
                        cues=cues, candidate=candidate, filename=downloaded.filename,
                        family=family, runtime_score=runtime_score,
                        ads_removed=int(cleanup_report.removed_lines or 0),
                    )
                    accepted.append(reference)
                    if row is not None:
                        row.update({
                            "accepted": True, "reason": "accepted",
                            "member": downloaded.filename, "cue_count": len(cues),
                            "runtime_score": round(runtime_score, 4),
                        })
                    log(
                        "English accepted family=%s id=%s owner=%s member=%s cues=%d runtime_score=%.3f"
                        % (family, candidate.subtitle_id, candidate_owner(candidate), downloaded.filename, len(cues), runtime_score),
                        LOG_INFO,
                    )
                    if len(accepted) >= accept_limit:
                        break
                except Exception as exc:
                    if row is not None:
                        row["reason"] = str(exc)
                    log(
                        "English candidate rejected family=%s id=%s reason=%s"
                        % (family, candidate.subtitle_id, exc),
                        LOG_INFO,
                    )
            return accepted

        workers = max(1, min(setting_int("parallel_downloads", 3), 4, len(selected_families)))
        accepted_by_family: Dict[str, List[ReferenceSource]] = {}
        if workers <= 1:
            for family in selected_families:
                accepted_by_family[family] = fetch_family(family)
        else:
            with ThreadPoolExecutor(max_workers=workers) as executor:
                futures = {executor.submit(fetch_family, family): family for family in selected_families}
                for future in as_completed(futures):
                    family = futures[future]
                    accepted_by_family[family] = future.result()
        result: List[ReferenceSource] = []
        for family in selected_families:
            result.extend(accepted_by_family.get(family) or [])
        return result

    def _download_indonesian_chunk(
        self,
        client: SubSourceClient,
        candidates: Sequence[SubtitleCandidate],
        media: MediaContext,
        workers: int,
    ) -> List[TargetSource]:
        if not candidates:
            return []

        def fetch(candidate: SubtitleCandidate) -> Optional[TargetSource]:
            row = next(
                (item for item in self._diagnostics.get("indonesian_candidates", [])
                 if str(item.get("subtitle_id")) == str(candidate.subtitle_id)),
                None,
            )
            if row is None:
                row = {
                    "subtitle_id": candidate.subtitle_id, "language": "indonesian",
                    "family": release_family(candidate.release_info), "release": candidate.release_info,
                    "owner": candidate_owner(candidate), "attempted": False, "accepted": False,
                    "reason": "not attempted",
                }
                self._diagnostics.setdefault("indonesian_candidates", []).append(row)
            row["attempted"] = True
            log("Indonesian candidate attempt %s" % self._candidate_stats(candidate), LOG_INFO)
            try:
                downloaded = client.download_and_select(candidate, media)
                cues, cleanup_report = parse_subtitle_text_with_report(
                    self._decode_payload(downloaded.payload), downloaded.filename, media.show_title or media.title
                )
                if len(cues) < 8:
                    raise ValueError("subtitle has too few cues: %d" % len(cues))
                row.update({
                    "accepted": True, "reason": "accepted", "member": downloaded.filename,
                    "selection_reason": downloaded.selection_reason, "cue_count": len(cues),
                    "runtime_score": round(self._runtime_score(cues, media), 4),
                })
                log(
                    "Indonesian accepted id=%s owner=%s member=%s reason=%s cues=%d"
                    % (candidate.subtitle_id, candidate_owner(candidate), downloaded.filename, downloaded.selection_reason, len(cues)),
                    LOG_INFO,
                )
                return TargetSource(
                    label="SubSource Indonesian [%s]: %s" % (candidate.subtitle_id, candidate.release_info),
                    cues=cues,
                    candidate=candidate,
                    filename=downloaded.filename,
                    runtime_score=self._runtime_score(cues, media),
                    ads_removed=int(cleanup_report.removed_lines or 0),
                )
            except Exception as exc:
                row["reason"] = str(exc)
                log(
                    "Indonesian rejected id=%s release=%s reason=%s"
                    % (candidate.subtitle_id, candidate.release_info, exc),
                    LOG_INFO,
                )
                return None

        if workers <= 1 or len(candidates) <= 1:
            return [target for target in (fetch(candidate) for candidate in candidates) if target]

        indexed = {candidate.subtitle_id: index for index, candidate in enumerate(candidates)}
        fetched: List[TargetSource] = []
        with ThreadPoolExecutor(max_workers=min(workers, len(candidates))) as executor:
            futures = {executor.submit(fetch, candidate): candidate for candidate in candidates}
            for future in as_completed(futures):
                target = future.result()
                if target:
                    fetched.append(target)
        fetched.sort(key=lambda target: indexed.get(target.candidate.subtitle_id if target.candidate else "", 9999))
        return fetched

    @staticmethod
    def _runtime_score(cues: Sequence[Cue], media: MediaContext) -> float:
        if not cues or media.duration_ms <= 0:
            return 0.5
        first = min(cue.start_ms for cue in cues)
        last = max(cue.end_ms for cue in cues)
        span = max(0, last - first)
        duration = max(1, media.duration_ms)
        coverage = min(1.0, span / float(duration))
        gap = duration - last
        if 0 <= gap <= 180000:
            gap_score = 1.0
        elif -30000 <= gap < 0:
            gap_score = 0.85
        else:
            gap_score = max(0.0, 1.0 - min(1.0, abs(gap - 60000) / 600000.0))
        return max(0.0, min(1.0, 0.65 * gap_score + 0.35 * coverage))

    @staticmethod
    def _decode_payload(payload: bytes) -> str:
        for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
            try:
                return payload.decode(encoding)
            except UnicodeDecodeError:
                continue
        return payload.decode("utf-8", "replace")

    @staticmethod
    def _target_tiebreak(target: TargetSource) -> Tuple[float, int, int, float]:
        if not target.candidate:
            return (0.0, 0, 0, 0.0)
        candidate = target.candidate
        return (candidate.score, candidate.download_count, candidate.rating_votes, candidate.rating)

    def _is_auto_acceptable(self, choice: SyncChoice) -> bool:
        result = choice.result
        return bool(
            result.confidence >= setting_float("accept_confidence", 0.90)
            and abs(result.global_offset_ms) <= max(100, setting_int("max_auto_offset_ms", 2000))
            and result.p90_error_ms <= max(300, setting_int("max_auto_p90_ms", 1200))
        )

    def _is_strong_early_result(self, choice: SyncChoice) -> bool:
        result = choice.result
        threshold = max(setting_float("accept_confidence", 0.90), 0.94)
        return bool(
            result.confidence >= threshold
            and abs(result.global_offset_ms) <= min(700, max(100, setting_int("max_auto_offset_ms", 2000)))
            and result.p90_error_ms <= min(850, max(300, setting_int("max_auto_p90_ms", 1200)))
            and result.median_error_ms <= 300
        )

    def _compare_choices(self, left: SyncChoice, right: SyncChoice) -> int:
        left_ok = self._is_auto_acceptable(left)
        right_ok = self._is_auto_acceptable(right)
        if left_ok != right_ok:
            return -1 if left_ok else 1

        a = left.result
        b = right.result
        confidence_window = 0.020
        if a.confidence > b.confidence + confidence_window:
            return -1
        if b.confidence > a.confidence + confidence_window:
            return 1

        runtime_a = 0.55 * left.reference.runtime_score + 0.45 * left.target.runtime_score
        runtime_b = 0.55 * right.reference.runtime_score + 0.45 * right.target.runtime_score
        if runtime_a > runtime_b + 0.12:
            return -1
        if runtime_b > runtime_a + 0.12:
            return 1

        # Close confidence means both synchronize into a similar shape. Prefer
        # the subtitle that needed less correction from its original timing.
        offset_a = abs(a.global_offset_ms)
        offset_b = abs(b.global_offset_ms)
        if offset_a + 100 < offset_b:
            return -1
        if offset_b + 100 < offset_a:
            return 1

        if a.p90_error_ms + 80 < b.p90_error_ms:
            return -1
        if b.p90_error_ms + 80 < a.p90_error_ms:
            return 1
        if a.median_error_ms + 40 < b.median_error_ms:
            return -1
        if b.median_error_ms + 40 < a.median_error_ms:
            return 1
        if a.overlap_ratio != b.overlap_ratio:
            return -1 if a.overlap_ratio > b.overlap_ratio else 1
        if a.confidence != b.confidence:
            return -1 if a.confidence > b.confidence else 1

        left_meta = self._target_tiebreak(left.target)
        right_meta = self._target_tiebreak(right.target)
        if left_meta != right_meta:
            return -1 if left_meta > right_meta else 1
        return 0

    def _rank_sync_choices(
        self,
        targets: Sequence[TargetSource],
        references: Sequence[ReferenceSource],
    ) -> List[SyncChoice]:
        choices: List[SyncChoice] = []
        for reference in references:
            for target in targets:
                try:
                    result = synchronize(target.cues, reference.cues)
                except Exception as exc:
                    log("sync failed target=%s ref=%s: %s" % (target.label, reference.label, exc), LOG_INFO)
                    continue
                self._diagnostics.setdefault("sync_matrix", []).append({
                    "target_id": target.candidate.subtitle_id if target.candidate else None,
                    "target_release": target.candidate.release_info if target.candidate else target.label,
                    "target_owner": candidate_owner(target.candidate) if target.candidate else "local",
                    "reference_id": reference.candidate.subtitle_id if reference.candidate else None,
                    "reference_release": reference.candidate.release_info if reference.candidate else reference.label,
                    "reference_owner": candidate_owner(reference.candidate) if reference.candidate else "embedded",
                    "reference_family": reference.family,
                    "confidence": round(result.confidence, 6),
                    "global_offset_ms": result.global_offset_ms,
                    "median_error_ms": round(result.median_error_ms, 2),
                    "p90_error_ms": round(result.p90_error_ms, 2),
                    "overlap_ratio": round(result.overlap_ratio, 6),
                })
                log(
                    "sync result target=%s ref=%s confidence=%.4f offset=%sms median=%.0f p90=%.0f overlap=%.3f"
                    % (
                        target.label,
                        reference.label,
                        result.confidence,
                        result.global_offset_ms,
                        result.median_error_ms,
                        result.p90_error_ms,
                        result.overlap_ratio,
                    ),
                    LOG_INFO,
                )
                choices.append(SyncChoice(target=target, reference=reference, result=result))
        choices.sort(key=cmp_to_key(self._compare_choices))
        if choices:
            best = choices[0]
            candidate = best.target.candidate
            log(
                "best sync target=%s id=%s confidence=%.4f offset=%d p90=%.0f downloads=%s"
                % (
                    best.target.label,
                    candidate.subtitle_id if candidate else "local",
                    best.result.confidence,
                    best.result.global_offset_ms,
                    best.result.p90_error_ms,
                    candidate.download_count if candidate else 0,
                ),
                LOG_INFO,
            )
        return choices

    @staticmethod
    def _target_identity(choice: SyncChoice) -> str:
        if choice.target.candidate:
            return "subsource:%s" % choice.target.candidate.subtitle_id
        return "local:%s" % (choice.target.filename or choice.target.label)

    def _is_decisive(self, choices: Sequence[SyncChoice]) -> bool:
        if not choices:
            return False
        distinct: List[SyncChoice] = []
        seen = set()
        for choice in choices:
            key = self._target_identity(choice)
            if key in seen:
                continue
            seen.add(key)
            distinct.append(choice)
        if len(distinct) <= 1:
            return True

        best, second = distinct[0], distinct[1]
        if self._is_auto_acceptable(best) and not self._is_auto_acceptable(second):
            return True
        a, b = best.result, second.result
        if a.confidence >= b.confidence + 0.020:
            return True
        if (
            abs(a.global_offset_ms) + 150 <= abs(b.global_offset_ms)
            and a.confidence >= b.confidence - 0.015
        ):
            return True
        if (
            a.p90_error_ms + 200 <= b.p90_error_ms
            and abs(a.global_offset_ms) <= abs(b.global_offset_ms) + 100
            and a.confidence >= b.confidence - 0.010
        ):
            return True
        return False

    @staticmethod
    def _short_release(value: str, fallback: str = "Subtitle Indonesia") -> str:
        text = " ".join((value or fallback).split())
        return text if len(text) <= 64 else text[:61] + "..."

    @staticmethod
    def _family_label(family: str) -> str:
        return {
            "embedded": "Embedded",
            "webdl": "WEB-DL",
            "webrip": "WEBRip",
            "bluray": "BluRay",
            "dvd": "DVD",
            "hdtv": "HDTV",
            "remux": "Remux",
            "subrip": "Sub Rip",
            "english": "English",
            "raw": "Original",
            "other": "Other",
        }.get(family or "other", (family or "other").upper())

    def _profile_from_choice(self, choice: SyncChoice) -> Dict[str, Any]:
        target_candidate = choice.target.candidate
        reference_candidate = choice.reference.candidate
        offsets = [choice.result.global_offset_ms] + [int(item[1]) for item in choice.result.knots]
        max_abs = max((abs(value) for value in offsets), default=0)
        correction_span = (max(offsets) - min(offsets)) if offsets else 0
        risky = bool(max_abs > 5000 or correction_span > 5000 or choice.result.p90_error_ms > 2000)
        target_release = (
            target_candidate.release_info
            if target_candidate
            else os.path.basename(choice.target.filename) or choice.target.label
        )
        reference_release = (
            reference_candidate.release_info
            if reference_candidate
            else choice.reference.label
        )
        family = choice.reference.family or ("embedded" if choice.reference.embedded_track else "other")
        target_short = self._short_release(target_release)
        manifest = {
            "method": "subtitle_to_subtitle_smartsync_v4_release_profiles",
            "target": choice.target.label,
            "reference": choice.reference.label,
            "reference_track": choice.reference.embedded_track.track_number if choice.reference.embedded_track else None,
            "reference_language": choice.reference.embedded_track.language if choice.reference.embedded_track else "english",
            "reference_codec": choice.reference.embedded_track.codec_id if choice.reference.embedded_track else "text",
            "confidence": round(choice.result.confidence, 6),
            "global_offset_ms": choice.result.global_offset_ms,
            "median_error_ms": round(choice.result.median_error_ms, 2),
            "p90_error_ms": round(choice.result.p90_error_ms, 2),
            "overlap_ratio": round(choice.result.overlap_ratio, 6),
            "knots": choice.result.knots,
            "target_subsource_id": target_candidate.subtitle_id if target_candidate else None,
            "target_release_score": round(target_candidate.score, 3) if target_candidate else None,
            "target_rating": target_candidate.rating if target_candidate else None,
            "target_rating_votes": target_candidate.rating_votes if target_candidate else None,
            "target_downloads": target_candidate.download_count if target_candidate else None,
            "reference_subsource_id": reference_candidate.subtitle_id if reference_candidate else None,
            "target_owner": candidate_owner(target_candidate) if target_candidate else "local",
            "reference_owner": candidate_owner(reference_candidate) if reference_candidate else "embedded",
            "target_filename": choice.target.filename,
            "reference_filename": choice.reference.filename,
            "ads_removed": int(choice.target.ads_removed or 0),
            "reference_ads_removed": int(choice.reference.ads_removed or 0),
            "archive_policy": "a4k_archive_selector_safe_v3",
            "selection_policy": "release_family_cycle_v1",
            "audio_analysis": False,
            "local_reference_paths": list(self._current_local_reference_paths),
        }
        return {
            "family": family,
            "label": "%s • %s" % (self._family_label(family), target_short),
            "target_short": target_short,
            "target_label": choice.target.label,
            "target_release": target_release,
            "target_subsource_id": target_candidate.subtitle_id if target_candidate else None,
            "target_owner": candidate_owner(target_candidate) if target_candidate else "local",
            "target_filename": choice.target.filename,
            "reference_label": choice.reference.label,
            "reference_release": reference_release,
            "reference_subsource_id": reference_candidate.subtitle_id if reference_candidate else None,
            "reference_owner": candidate_owner(reference_candidate) if reference_candidate else "embedded",
            "reference_filename": choice.reference.filename,
            "language": "indonesian",
            "mode": "embedded_sync" if family == "embedded" else ("local_reference_sync" if family == "local" else "automatic"),
            "confidence": round(choice.result.confidence, 6),
            "global_offset_ms": choice.result.global_offset_ms,
            "p90_error_ms": round(choice.result.p90_error_ms, 2),
            "max_abs_correction_ms": max_abs,
            "correction_span_ms": correction_span,
            "runtime_score": round(0.55 * choice.reference.runtime_score + 0.45 * choice.target.runtime_score, 4),
            "ads_removed": int(choice.target.ads_removed or 0),
            "reference_ads_removed": int(choice.reference.ads_removed or 0),
            "risky": risky,
            "manifest": manifest,
            "_srt": render_srt(choice.result.cues),
        }

    def _raw_profile(self, target: TargetSource) -> Dict[str, Any]:
        candidate = target.candidate
        target_release = candidate.release_info if candidate else os.path.basename(target.filename) or target.label
        target_short = self._short_release(target_release)
        manifest = {
            "method": "original_timing_profile",
            "target": target.label,
            "reference": "Original subtitle timing",
            "reference_codec": "none",
            "confidence": None,
            "global_offset_ms": 0,
            "median_error_ms": None,
            "p90_error_ms": None,
            "overlap_ratio": None,
            "knots": [[0, 0]],
            "target_subsource_id": candidate.subtitle_id if candidate else None,
            "target_release_score": round(candidate.score, 3) if candidate else None,
            "target_rating": candidate.rating if candidate else None,
            "target_rating_votes": candidate.rating_votes if candidate else None,
            "target_downloads": candidate.download_count if candidate else None,
            "reference_subsource_id": None,
            "target_owner": candidate_owner(candidate) if candidate else "local",
            "target_filename": target.filename,
            "ads_removed": int(target.ads_removed or 0),
            "archive_policy": "a4k_archive_selector_safe_v3",
            "selection_policy": "release_family_cycle_v1",
            "audio_analysis": False,
            "local_reference_paths": list(self._current_local_reference_paths),
        }
        return {
            "family": "raw",
            "label": "Original • %s" % target_short,
            "target_short": target_short,
            "target_label": target.label,
            "target_release": target_release,
            "target_subsource_id": candidate.subtitle_id if candidate else None,
            "target_owner": candidate_owner(candidate) if candidate else "local",
            "target_filename": target.filename,
            "source_family": release_family(target_release),
            "language": "indonesian",
            "mode": "automatic_raw",
            "reference_label": "Original subtitle timing",
            "reference_release": "",
            "reference_subsource_id": None,
            "confidence": None,
            "global_offset_ms": 0,
            "p90_error_ms": None,
            "max_abs_correction_ms": 0,
            "correction_span_ms": 0,
            "runtime_score": round(target.runtime_score, 4),
            "ads_removed": int(target.ads_removed or 0),
            "risky": False,
            "manifest": manifest,
            "_srt": render_srt(target.cues),
        }

    def _apply_raw_targets(
        self,
        media: MediaContext,
        targets: Sequence[TargetSource],
        preference: Optional[Dict[str, Any]] = None,
        status: str = "automatic_raw",
        initial_index: int = 0,
    ) -> str:
        distinct: List[TargetSource] = []
        seen = set()
        for target in targets:
            key = (
                "subsource:%s" % target.candidate.subtitle_id
                if target.candidate else "local:%s" % (target.filename or target.label)
            )
            if key in seen:
                continue
            seen.add(key)
            distinct.append(target)

        # Keep the validated download order. For movies this maps directly to
        # profile-00, profile-01, and so on; TV candidates are already reduced
        # to one best result per release family.

        limit = max(1, min(setting_int("automatic_indonesian_profiles", 5), 8))
        profiles = [self._raw_profile(target) for target in distinct[:limit]]
        if not profiles:
            raise RuntimeError("tidak ada profil Indonesia RAW yang dapat dibuat")
        for profile in profiles:
            profile["mode"] = "automatic_raw"
            profile["cycle_enabled"] = True
            profile["risky"] = False
        for index, profile in enumerate(profiles):
            profile["variant_path"] = save_profile_variant(media, index, profile.pop("_srt"))
        cycle_indices = list(range(len(profiles)))
        session = {
            "version": 5,
            "profile_order": "indonesian_raw_ranked_v1",
            "active_index": max(0, min(int(initial_index), len(profiles) - 1)),
            "cycle_indices": cycle_indices,
            "changed_at": 0,
            "stable_play_seconds": 0.0,
            "alternatives_loaded": True,
            "profiles": profiles,
        }
        save_session(media, session)
        self._diagnostics["selected_profiles"] = [
            {
                "index": index, "family": "raw", "mode": "automatic_raw",
                "target_id": profile.get("target_subsource_id"),
                "reference_id": None, "risky": False, "cycle_enabled": True,
            }
            for index, profile in enumerate(profiles)
        ]
        self._save_diagnostics(media, status)
        output = activate_profile(self.player, media, session, session["active_index"], announce=True)
        self._resume_after_search(rewind=True)
        return output

    def _apply_manual_reference_choices(
        self,
        media: MediaContext,
        choices: Sequence[SyncChoice],
        reference_profile: Dict[str, Any],
        reference: ReferenceSource,
        preference: Optional[Dict[str, Any]] = None,
    ) -> str:
        # Keep one best result per Indonesian subtitle. All use the same
        # user-verified English clock, so family deduplication would hide useful
        # alternatives.
        distinct: List[Dict[str, Any]] = []
        seen_targets = set()
        for choice in choices:
            key = self._target_identity(choice)
            if key in seen_targets:
                continue
            seen_targets.add(key)
            profile = self._profile_from_choice(choice)
            profile.update({
                "mode": "synced_to_manual_reference",
                "language": "indonesian",
                "source_family": reference.family,
                "reference_owner": candidate_owner(reference.candidate) if reference.candidate else str(reference_profile.get("reference_owner") or ""),
                "reference_filename": reference.filename,
            })
            profile["manifest"]["method"] = "sync_to_user_verified_english_v1"
            profile["manifest"]["manual_reference_confirmed"] = True
            distinct.append(profile)

        safe = [profile for profile in distinct if not profile.get("risky")]
        risky = [profile for profile in distinct if profile.get("risky")]
        max_profiles = max(2, min(setting_int("max_sync_profiles", 8), 10))

        english = dict(reference_profile)
        english.update({
            "family": "english",
            "source_family": reference.family,
            "language": "english",
            "mode": "manual_reference_confirmed",
            "label": "English • %s • %s" % (reference.family, candidate_owner(reference.candidate) if reference.candidate else "reference"),
            "reference_label": reference.label,
            "reference_release": reference.candidate.release_info if reference.candidate else str(reference_profile.get("reference_release") or ""),
            "reference_subsource_id": reference.candidate.subtitle_id if reference.candidate else reference_profile.get("reference_subsource_id"),
            "reference_owner": candidate_owner(reference.candidate) if reference.candidate else str(reference_profile.get("reference_owner") or ""),
            "reference_filename": reference.filename,
            "target_label": "", "target_release": "", "target_subsource_id": None, "target_owner": "",
            "confidence": None, "global_offset_ms": 0, "p90_error_ms": None,
            "max_abs_correction_ms": 0, "correction_span_ms": 0,
            "runtime_score": round(reference.runtime_score, 4),
            "ads_removed": int(reference.ads_removed or 0),
            "risky": False, "cycle_enabled": True,
            "manifest": {
                "method": "manual_english_reference_confirmed",
                "reference": reference.label,
                "reference_subsource_id": reference.candidate.subtitle_id if reference.candidate else reference_profile.get("reference_subsource_id"),
                "reference_owner": candidate_owner(reference.candidate) if reference.candidate else str(reference_profile.get("reference_owner") or ""),
                "reference_filename": reference.filename,
                "ads_removed": int(reference.ads_removed or 0),
                "audio_analysis": False,
            },
            "_srt": render_srt(reference.cues),
        })

        # English original is 00. Because the user has verified that English
        # against the actual video, every synchronized Indonesian result may be
        # tested through F3/Back-Select, even when the correction is large. Risky remains
        # a warning flag and is not auto-saved.
        profiles = [english] + (safe + risky)[: max(0, max_profiles - 1)]
        for profile in profiles:
            profile["cycle_enabled"] = True
        cycle_indices = list(range(1, len(profiles))) + [0]
        initial_index = 1 if len(profiles) > 1 else 0
        for index, profile in enumerate(profiles):
            profile["variant_path"] = save_profile_variant(media, index, profile.pop("_srt"))
        session = {
            "version": 5,
            "profile_order": "verified_english_00_all_indonesian_testable_v2",
            "active_index": initial_index,
            "cycle_indices": cycle_indices,
            "changed_at": 0,
            "stable_play_seconds": 0.0,
            "alternatives_loaded": True,
            "profiles": profiles,
        }
        save_session(media, session)
        self._diagnostics["selected_profiles"] = [
            {
                "index": index, "mode": profile.get("mode"),
                "target_id": profile.get("target_subsource_id"),
                "reference_id": profile.get("reference_subsource_id"),
                "risky": bool(profile.get("risky")),
                "cycle_enabled": bool(profile.get("cycle_enabled")),
            }
            for index, profile in enumerate(profiles)
        ]
        self._save_diagnostics(media, "manual_reference_confirmed")
        output = activate_profile(self.player, media, session, initial_index, announce=True)
        if initial_index == 0:
            notify("NO INDONESIAN SUBTITLE FOUND", warning=True, timeout=7000)
        else:
            notify("TEST WITH F3 • SHIFT+F3 TO SAVE", timeout=8000)
        self._resume_after_search(rewind=False)
        return output

    def _apply_choices(
        self,
        media: MediaContext,
        choices: Sequence[SyncChoice],
        raw_target: Optional[TargetSource] = None,
        preference: Optional[Dict[str, Any]] = None,
    ) -> str:
        if not self._still_current(media):
            raise RuntimeError("playback changed before AutoSync result could be applied")

        synced_profiles: List[Dict[str, Any]] = []
        seen_profiles = set()
        for choice in choices:
            family = choice.reference.family or ("embedded" if choice.reference.embedded_track else "other")
            # With an embedded English clock, keep one result for every
            # Indonesian target. There is only one trusted release family, so
            # family-only deduplication would hide all but one alternative.
            if family == "embedded":
                key = (family, self._target_identity(choice))
            else:
                key = (family,)
            if key in seen_profiles:
                continue
            seen_profiles.add(key)
            synced_profiles.append(self._profile_from_choice(choice))

        if preference and synced_profiles:
            scores = [profile_preference_score(profile, preference) for profile in synced_profiles]
            best_index = max(range(len(scores)), key=lambda idx: scores[idx])
            if scores[best_index] >= 300.0:
                preferred_profile = synced_profiles.pop(best_index)
                synced_profiles.insert(0, preferred_profile)
                log(
                    "saved season profile selected as first synced profile family=%s target=%s score=%.1f"
                    % (preferred_profile.get("family"), preferred_profile.get("target_release"), scores[best_index]),
                    LOG_INFO,
                )

        safe_synced = [profile for profile in synced_profiles if not profile.get("risky")]
        risky_synced = [profile for profile in synced_profiles if profile.get("risky")]

        # Keep untouched RAW timing for every distinct Indonesian candidate that
        # reached synchronization. This prevents a correct CasStudio/Pahe source
        # from disappearing merely because another target won machine ranking.
        raw_targets: List[TargetSource] = []
        raw_seen = set()
        ordered_targets: List[TargetSource] = []
        if raw_target is not None:
            ordered_targets.append(raw_target)
        ordered_targets.extend(choice.target for choice in choices)
        for target in ordered_targets:
            if target.candidate:
                key = "subsource:%s" % target.candidate.subtitle_id
            else:
                key = "local:%s" % (target.filename or target.label)
            if key in raw_seen:
                continue
            raw_seen.add(key)
            raw_targets.append(target)
        raw_limit = max(1, min(setting_int("automatic_indonesian_profiles", 5), 8))
        raw_profiles = [self._raw_profile(target) for target in raw_targets[:raw_limit]]

        max_profiles = max(2, min(setting_int("max_sync_profiles", 8), 10))
        primary_raw = raw_profiles[:1]
        profiles = list(primary_raw)

        # Trusted embedded sync results are the main automatic choices. Keep as
        # many safe alternatives as possible, then untouched RAW fallbacks.
        room = max_profiles - len(profiles)
        safe_kept = safe_synced[:max(0, room)]
        profiles.extend(safe_kept)
        room = max_profiles - len(profiles)
        profiles.extend(raw_profiles[1:1 + max(0, room)])
        room = max_profiles - len(profiles)
        # Risky embedded results are retained only for diagnosis and are never
        # added to the user cycle.
        profiles.extend(risky_synced[:max(0, room)])
        if not profiles:
            profiles = (safe_synced + raw_profiles + risky_synced)[:max_profiles]
        if not profiles:
            raise RuntimeError("tidak ada profil sinkronisasi yang dapat dibuat")

        for profile in profiles:
            profile["cycle_enabled"] = not bool(profile.get("risky"))

        safe_sync_indices = [
            index for index, profile in enumerate(profiles)
            if profile.get("family") != "raw" and profile.get("cycle_enabled", True)
        ]
        raw_indices = [
            index for index, profile in enumerate(profiles)
            if profile.get("family") == "raw" and profile.get("cycle_enabled", True)
        ]
        cycle_indices = safe_sync_indices + raw_indices
        if not cycle_indices:
            cycle_indices = [
                index for index, profile in enumerate(profiles)
                if profile.get("cycle_enabled", True)
            ]
        initial_index = cycle_indices[0] if cycle_indices else 0

        for index, profile in enumerate(profiles):
            profile["variant_path"] = save_profile_variant(media, index, profile.pop("_srt"))

        session = {
            "version": 5,
            "profile_order": "embedded_sync_then_raw_risky_excluded_v1",
            "active_index": initial_index,
            "cycle_indices": cycle_indices,
            "changed_at": 0,
            "stable_play_seconds": 0.0,
            "alternatives_loaded": True,
            "profiles": profiles,
        }
        save_session(media, session)
        self._diagnostics["selected_profiles"] = [
            {
                "index": index, "family": profile.get("family"),
                "mode": profile.get("mode"),
                "target_id": profile.get("target_subsource_id"),
                "reference_id": profile.get("reference_subsource_id"),
                "risky": bool(profile.get("risky")),
                "cycle_enabled": bool(profile.get("cycle_enabled")),
            }
            for index, profile in enumerate(profiles)
        ]
        self._save_diagnostics(media, "profiles_applied")
        output_path = activate_profile(self.player, media, session, initial_index, announce=True)
        self._resume_after_search(rewind=True)
        return output_path


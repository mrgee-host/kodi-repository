# Smart Subtitle 0.1.36

Smart Subtitle automatically prepares Indonesian text subtitles, preserves timing and styling, cleans advertisements and fan credits, and supports manual alternatives through F3 or the controller Back/Select button. The SubSource API remains one of its providers.

Current package policy:
- Fresh-install baseline only.
- No schema, setting, file-layout, or old-version migration.
- Automatic pause intentionally keeps the Kodi OSD visible through KPM.
- Diagnostics are exported as `smart-subtitle-diagnostics-*.zip`.

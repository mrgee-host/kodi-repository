# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import re
from typing import Any, Dict, List, Optional, Sequence
from urllib.parse import unquote

import xbmc
import xbmcvfs

from .common import ADDON, LOG_DEBUG, LOG_INFO, LOG_WARNING, MediaContext, json_rpc, log, setting_bool


def _normalize_imdb(value: str) -> str:
    match = re.search(r"tt\d{5,12}", value or "", re.IGNORECASE)
    return match.group(0).lower() if match else ""


def _active_video_player_id() -> int:
    result = json_rpc("Player.GetActivePlayers")
    if isinstance(result, list):
        for item in result:
            if isinstance(item, dict) and item.get("type") == "video":
                try:
                    return int(item.get("playerid"))
                except Exception:
                    pass
    return 1


def _imdb_from_uniqueid(value: Any) -> str:
    if isinstance(value, dict):
        for key in ("imdb", "unknown"):
            imdb = _normalize_imdb(str(value.get(key) or ""))
            if imdb:
                return imdb
        for candidate in value.values():
            imdb = _normalize_imdb(str(candidate or ""))
            if imdb:
                return imdb
    return _normalize_imdb(str(value or ""))


def _video_info_tag_values(player: xbmc.Player) -> Dict[str, Any]:
    values: Dict[str, Any] = {}
    try:
        tag = player.getVideoInfoTag()
    except Exception:
        return values

    getters = {
        "title": "getTitle",
        "year": "getYear",
        "season": "getSeason",
        "episode": "getEpisode",
        "showtitle": "getTVShowTitle",
        "imdbnumber": "getIMDBNumber",
        "dbid": "getDbId",
        "mediatype": "getMediaType",
    }
    for key, name in getters.items():
        method = getattr(tag, name, None)
        if callable(method):
            try:
                values[key] = method()
            except Exception:
                pass

    get_unique = getattr(tag, "getUniqueID", None)
    if callable(get_unique):
        try:
            values["uniqueid_imdb"] = get_unique("imdb")
        except Exception:
            pass
    return values


def _as_int(value: Any, default: int = -1) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _episode_show_details(item: Dict[str, Any], tag_values: Dict[str, Any]) -> Dict[str, Any]:
    """Resolve the parent TV show, never confusing an episode IMDb with a show IMDb."""
    tvshow_id = _as_int(item.get("tvshowid"), -1)
    episode_id = _as_int(item.get("id"), -1)
    if episode_id < 0:
        episode_id = _as_int(tag_values.get("dbid"), -1)

    # Player.GetItem may expose only the episode database id. Ask Kodi for the
    # parent tvshowid before reading the show's unique IDs.
    if tvshow_id < 0 and episode_id >= 0:
        episode_result = json_rpc(
            "VideoLibrary.GetEpisodeDetails",
            {
                "episodeid": episode_id,
                "properties": ["tvshowid", "uniqueid", "season", "episode", "showtitle"],
            },
        )
        episode_details = episode_result.get("episodedetails", {}) if isinstance(episode_result, dict) else {}
        tvshow_id = _as_int(episode_details.get("tvshowid"), -1)

    result: Dict[str, Any] = {"tvshowid": tvshow_id, "imdb": "", "title": "", "year": 0}
    if tvshow_id < 0:
        return result

    tv_result = json_rpc(
        "VideoLibrary.GetTVShowDetails",
        {
            "tvshowid": tvshow_id,
            "properties": ["uniqueid", "title", "year"],
        },
    )
    details = tv_result.get("tvshowdetails", {}) if isinstance(tv_result, dict) else {}
    imdb = _imdb_from_uniqueid(details.get("uniqueid"))
    if not imdb:
        imdb = _normalize_imdb(str(details.get("imdbnumber") or ""))
    result.update(
        {
            "imdb": imdb,
            "title": str(details.get("title") or ""),
            "year": _as_int(details.get("year"), 0),
        }
    )
    return result


def _movie_library_imdb(item: Dict[str, Any], tag_values: Dict[str, Any]) -> str:
    movie_id = _as_int(item.get("id"), -1)
    if movie_id < 0:
        movie_id = _as_int(tag_values.get("dbid"), -1)
    if movie_id < 0:
        return ""
    movie_result = json_rpc(
        "VideoLibrary.GetMovieDetails",
        {"movieid": movie_id, "properties": ["uniqueid"]},
    )
    details = movie_result.get("moviedetails", {}) if isinstance(movie_result, dict) else {}
    imdb = _imdb_from_uniqueid(details.get("uniqueid"))
    if not imdb:
        imdb = _normalize_imdb(str(details.get("imdbnumber") or ""))
    return imdb



_DEFAULT_INDONESIAN_PATH_KEYWORDS = (
    "indonesia",
    "indonesian",
    "film indonesia",
    "film indo",
    "movie indonesia",
    "movie indo",
    "series indonesia",
    "series indo",
    "tv indonesia",
    "tv indo",
    "drama indonesia",
    "sinetron",
    "lokal indonesia",
)


def _normalized_language(value: Any) -> str:
    text = unquote(str(value or "")).strip().lower()
    text = re.sub(r"[\[\](){}/_.-]+", " ", text)
    return " ".join(text.split())


def _looks_indonesian_language(value: Any) -> bool:
    text = _normalized_language(value)
    if not text:
        return False
    if text in {"id", "ind", "indo", "indonesian", "bahasa indonesia", "bahasa indo"}:
        return True
    tokens = set(text.split())
    if "indonesian" in tokens:
        return True
    if "bahasa" in tokens and ("indonesia" in tokens or "indo" in tokens):
        return True
    return False


def _country_is_indonesia(value: Any) -> bool:
    values: Sequence[Any]
    if isinstance(value, (list, tuple, set)):
        values = list(value)
    else:
        values = [value]
    for item in values:
        text = _normalized_language(item)
        if text in {"indonesia", "indonesian"} or "indonesia" in text.split():
            return True
    return False


def _configured_indonesian_path_keywords() -> List[str]:
    raw = ADDON.getSetting("indonesian_path_keywords") or ""
    values = [item.strip().lower() for item in re.split(r"[|,;\n]+", raw) if item.strip()]
    return values or list(_DEFAULT_INDONESIAN_PATH_KEYWORDS)


def _path_matches_indonesian(path: str) -> bool:
    decoded = unquote(str(path or "")).replace("\\", "/").lower()
    searchable = " ".join(token for token in re.split(r"[^a-z0-9]+", decoded) if token)
    padded = " %s " % searchable
    for keyword in _configured_indonesian_path_keywords():
        normalized = " ".join(token for token in re.split(r"[^a-z0-9]+", keyword.lower()) if token)
        if normalized and (" %s " % normalized) in padded:
            return True
    return False


def _current_audio_details(player: xbmc.Player) -> Dict[str, Any]:
    details: Dict[str, Any] = {}
    result = json_rpc(
        "Player.GetProperties",
        {
            "playerid": _active_video_player_id(),
            "properties": ["currentaudiostream", "audiostreams"],
        },
    )
    current = result.get("currentaudiostream") if isinstance(result, dict) else None
    streams = result.get("audiostreams") if isinstance(result, dict) else None
    if isinstance(current, dict):
        details.update(current)
    if isinstance(streams, list):
        details["all_streams"] = streams

    # Info labels are useful on builds/skins where JSON-RPC omits language.
    if not details.get("language"):
        for label in ("VideoPlayer.AudioLanguage", "Player.AudioLanguage", "ListItem.AudioLanguage"):
            value = xbmc.getInfoLabel(label)
            if value:
                details["language"] = value
                break
    if not details.get("name"):
        for label in ("VideoPlayer.AudioStream", "VideoPlayer.AudioCodec"):
            value = xbmc.getInfoLabel(label)
            if value:
                details["name"] = value
                break

    # Last fallback: when the file has exactly one named audio stream, that
    # stream is necessarily current. Do not use this fallback for multi-audio
    # files because an optional Indonesian dub should not suppress subtitles
    # while the user is listening to another language.
    if not details.get("language") and not details.get("name"):
        try:
            available = list(player.getAvailableAudioStreams() or [])
        except Exception:
            available = []
        if len(available) == 1:
            details["name"] = available[0]
    return details


def _library_country(media: MediaContext) -> Any:
    if media.media_type == "movie" and media.library_id > 0:
        result = json_rpc(
            "VideoLibrary.GetMovieDetails",
            {"movieid": media.library_id, "properties": ["country"]},
        )
        details = result.get("moviedetails", {}) if isinstance(result, dict) else {}
        return details.get("country")
    if media.media_type == "episode":
        tvshow_id = media.tvshow_id
        if tvshow_id <= 0 and media.library_id > 0:
            result = json_rpc(
                "VideoLibrary.GetEpisodeDetails",
                {"episodeid": media.library_id, "properties": ["tvshowid"]},
            )
            details = result.get("episodedetails", {}) if isinstance(result, dict) else {}
            tvshow_id = _as_int(details.get("tvshowid"), -1)
        if tvshow_id > 0:
            result = json_rpc(
                "VideoLibrary.GetTVShowDetails",
                {"tvshowid": tvshow_id, "properties": ["country"]},
            )
            details = result.get("tvshowdetails", {}) if isinstance(result, dict) else {}
            return details.get("country")
    return None


def automatic_skip_reason(player: xbmc.Player, media: MediaContext) -> str:
    """Return a stable reason when automatic subtitle work must not start.

    This gate affects only the background onAVStarted workflow. Kodi's manual
    subtitle-search entry remains available when the user explicitly opens it.
    """
    if setting_bool("auto_library_only", True):
        if media.library_id <= 0 or media.media_type not in {"movie", "episode"}:
            return "not_in_kodi_library"

    if not setting_bool("skip_indonesian_content", True):
        return ""

    audio = _current_audio_details(player)
    if _looks_indonesian_language(audio.get("language")) or _looks_indonesian_language(audio.get("name")):
        return "current_audio_indonesian"

    if _country_is_indonesia(_library_country(media)):
        return "library_country_indonesia"

    if _path_matches_indonesian(media.path):
        return "path_marked_indonesian"

    return ""

def get_media_context(player: xbmc.Player) -> Optional[MediaContext]:
    try:
        path = player.getPlayingFile()
    except Exception:
        path = ""
    if not path or path.lower().startswith(("plugin://", "pvr://", "http://", "https://", "rtmp://", "rtsp://")):
        log("unsupported playback path: %s" % path, LOG_DEBUG)
        return None

    player_id = _active_video_player_id()
    # Only request fields accepted by Player.GetItem/List.Fields.All on Kodi 22.
    # The previous build requested `movieid`, which is not a valid property and
    # caused Kodi to reject the whole call before returning unique IDs.
    result = json_rpc(
        "Player.GetItem",
        {
            "playerid": player_id,
            "properties": [
                "title", "year", "season", "episode", "showtitle", "tvshowid",
                "file", "uniqueid", "duration", "runtime"
            ],
        },
    )
    item = result.get("item", {}) if isinstance(result, dict) else {}
    tag_values = _video_info_tag_values(player)

    title = item.get("title") or tag_values.get("title") or os.path.splitext(os.path.basename(path))[0]
    show_title = item.get("showtitle") or tag_values.get("showtitle") or ""
    try:
        season = int(item.get("season") if item.get("season") is not None else tag_values.get("season") or 0)
    except Exception:
        season = 0
    try:
        episode = int(item.get("episode") if item.get("episode") is not None else tag_values.get("episode") or 0)
    except Exception:
        episode = 0

    item_type = str(item.get("type") or tag_values.get("mediatype") or "").lower()
    is_episode = item_type == "episode" or bool(show_title and season >= 0 and episode >= 0)
    if not item_type:
        item_type = "episode" if is_episode else "movie" if item.get("id") not in (None, -1) else "unknown"

    # Player/GetVideoInfoTag normally expose the currently playing item's ID.
    # For an episode that is the *episode* IMDb, not the parent TV-show IMDb.
    item_imdb = _imdb_from_uniqueid(item.get("uniqueid"))
    if not item_imdb:
        item_imdb = _normalize_imdb(str(tag_values.get("uniqueid_imdb") or tag_values.get("imdbnumber") or ""))

    show_details: Dict[str, Any] = {}
    episode_imdb = ""
    show_year = 0
    tvshow_id = -1
    if is_episode:
        episode_imdb = item_imdb
        show_details = _episode_show_details(item, tag_values)
        imdb = str(show_details.get("imdb") or "")
        tvshow_id = _as_int(show_details.get("tvshowid"), -1)
        show_year = _as_int(show_details.get("year"), 0)
        if not show_title:
            show_title = str(show_details.get("title") or "")

        # Do not reuse VideoPlayer.IMDBNumber here: Kodi usually fills it with
        # the episode IMDb. SubSource's TV search expects the parent series ID.
        if not imdb:
            for label in ("VideoPlayer.TVShowUniqueID(imdb)", "ListItem.TVShowUniqueID(imdb)"):
                imdb = _normalize_imdb(xbmc.getInfoLabel(label))
                if imdb:
                    break
    else:
        imdb = item_imdb or _movie_library_imdb(item, tag_values)
        if not imdb:
            for label in (
                "VideoPlayer.UniqueID(imdb)",
                "VideoPlayer.IMDBNumber",
                "ListItem.UniqueID(imdb)",
                "ListItem.IMDBNumber",
            ):
                imdb = _normalize_imdb(xbmc.getInfoLabel(label))
                if imdb:
                    break

    duration_seconds = 0.0
    try:
        duration_seconds = float(player.getTotalTime())
    except Exception:
        duration_seconds = 0.0
    if duration_seconds <= 0:
        duration = item.get("duration")
        if isinstance(duration, dict):
            duration_seconds = (
                int(duration.get("hours", 0)) * 3600
                + int(duration.get("minutes", 0)) * 60
                + int(duration.get("seconds", 0))
            )
        elif item.get("runtime"):
            try:
                duration_seconds = float(item.get("runtime"))
            except Exception:
                pass

    try:
        year = int(item.get("year") if item.get("year") is not None else tag_values.get("year") or 0)
    except Exception:
        year = 0

    context = MediaContext(
        path=path,
        title=str(title or ""),
        year=year,
        imdb_id=imdb,
        is_episode=is_episode,
        show_title=str(show_title or ""),
        season=season,
        episode=episode,
        duration_ms=int(duration_seconds * 1000),
        filename=os.path.basename(path),
        media_type=item_type,
        library_id=_as_int(item.get("id"), _as_int(tag_values.get("dbid"), -1)),
        episode_imdb_id=episode_imdb,
        show_year=show_year,
        tvshow_id=tvshow_id,
    )
    log(
        "media context: type=%s title=%s show=%s S%02dE%02d imdb=%s episode_imdb=%s tvshowid=%s"
        % (
            context.media_type,
            context.title,
            context.show_title,
            context.season,
            context.episode,
            context.imdb_id or "none",
            context.episode_imdb_id or "none",
            context.tvshow_id,
        ),
        LOG_DEBUG,
    )
    return context


def get_available_subtitle_streams(player: xbmc.Player) -> List[str]:
    try:
        return list(player.getAvailableSubtitleStreams() or [])
    except Exception as exc:
        log("getAvailableSubtitleStreams failed: %s" % exc, LOG_WARNING)
        return []


def select_embedded_indonesian(player: xbmc.Player, track_name: str = "", preferred_order: int = -1) -> bool:
    streams = get_available_subtitle_streams(player)
    if not streams:
        return False

    bad = ("forced", "commentary", "director", "signs", "songs", "foreign")
    target_tokens = ("indonesian", "bahasa indonesia", "ind", "[id]", "(id)")
    best_index = None
    best_score = -999
    wanted = (track_name or "").lower()

    for idx, name in enumerate(streams):
        lower = (name or "").lower()
        score = 0
        if any(token in lower for token in target_tokens):
            score += 100
        if wanted and wanted in lower:
            score += 40
        if idx == preferred_order:
            score += 15
        if any(token in lower for token in bad):
            score -= 100
        if score > best_score:
            best_score = score
            best_index = idx

    if best_index is None or best_score < 50:
        return False
    try:
        player.setSubtitleStream(best_index)
        player.showSubtitles(True)
        log("selected embedded Indonesian subtitle stream %s: %s" % (best_index, streams[best_index]))
        return True
    except Exception as exc:
        log("failed selecting embedded subtitle stream: %s" % exc, LOG_WARNING)
        return False


def apply_external_subtitle(player: xbmc.Player, path: str) -> bool:
    try:
        player.setSubtitles(path)
        player.showSubtitles(True)
        log("applied external subtitle: %s" % path)
        return True
    except Exception as exc:
        log("setSubtitles failed: %s" % exc, LOG_WARNING)
        return False


def stat_signature(path: str) -> Dict[str, int]:
    try:
        stat = xbmcvfs.Stat(path)
        return {"size": int(stat.st_size()), "mtime": int(stat.st_mtime())}
    except Exception:
        return {"size": 0, "mtime": 0}

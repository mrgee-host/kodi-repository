service.subtitles.subsource.autosync 0.1.25 - R4

MrGee Kodi Family R4 runtime and consistency fixes.

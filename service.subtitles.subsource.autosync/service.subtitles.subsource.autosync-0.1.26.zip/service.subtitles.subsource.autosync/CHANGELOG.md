## 0.1.26
- Local Windows sidecars now use native file I/O for temporary writes, SHA-256 verification, atomic replacement, rollback, and retry.
- Kodi VFS remains reserved for smb://, nfs:// and special:// paths.
- Expanded always-on cleaner coverage for spaced `Alih Bahasa :`, `Penyelaras`, timing credits and TWDIS signatures.
- Bumped the cleanup policy so older unclean profiles are regenerated.
- Removed legacy imdbnumber requests and added Kodi 22 invalid-property retry for VideoLibrary details.

## 0.1.22
- Replaced configurable `.id.<suffix>.srt` output with one canonical sidecar: `<video>.id.srt`.
- Removed the obsolete output filename suffix setting and its diagnostic field.
- Sidecar writes now use a validated temporary file and an atomic local replace where supported.
- The original `.id.srt` is backed up once inside the add-on profile before the first replacement.
- Successfully written canonical sidecars remove prior `.id.autosync.srt`, configured legacy suffix files, and the previous session sidecar.
- Added a one-time startup migration for legacy sidecars recorded in existing manifests.
- Internal F3 profile variants remain in add-on data; only the currently active Indonesian result is left beside the video.

## 0.1.21
- Rewrote every on-screen notification in compact English and enforced a 65-character display limit.
- Notifications mention only F3/Shift+F3; controller R1 support remains functional but is no longer shown in toast text.
- Renamed active profile notices to `SUBTITLE <position>/<total> • <family> • <owner>`.
- Merged embedded and local direct-subtitle notices into one `SUBTITLE READY` flow with `F3 FOR ALTERNATIVES`.
- Cleaning counts now use one consistent label: `<count> ADS REMOVED`. The count includes removed ads, websites, fan credits, social contacts, donations, and watermarks.
- Manual and automatic saved-source notices retain both release family and owner.
- Raw exceptions are mapped to short user-facing reasons while full errors remain in Kodi logs and diagnosis exports.
- Tightened season-pack numeric fallback so a pack with explicit conflicting season metadata cannot be selected for the wrong season.

## 0.1.20
- Added an always-on subtitle ad/credit cleaner for every text path: automatic, manual, local sidecar, embedded MKV, RAW, synced, season reuse, and English references.
- Cleaning removes known advertising domains, gambling cards, donation/contact promotions, translator/uploader/resync credits, and animated progressive watermarks.
- Closed captions, dialogue in brackets, HTML/ASS styling tags, positions, and cue timing are preserved; there is intentionally no cleanup setting.
- Added a structured `resources/data/cleanup_rules.txt` rule file loaded once into memory. No cleanup database, remote rule download, or folder polling is used.
- Cleaning works per line where possible, preserving dialogue/title text that shares a cue with a watermark. Short proven ad/credit cards are removed as whole cues.
- Embedded S_TEXT/UTF8 and S_TEXT/ASS/SSA payloads are now extracted from MKV blocks, cleaned, rendered to an external SRT, and applied instead of bypassing cleaning through the internal track.
- Added iterative detection for animated credits/domains split across successive cues and font/color tags.
- Cleanup events and removed-text samples are included in diagnosis exports together with the exact rules file.
- Bumped the manifest policy so profiles generated before always-on cleaning are not reused.

## 0.1.19
- Replaced the custom ZIP episode selector with an a4kSubtitles-compatible season/episode parser and numeric fallback.
- ZIP member selection now recognizes loose names such as `S7 eps 01`, legacy separators, episode ranges, and final standalone episode numbers.
- Multi-file archives no longer depend on the API release title containing a season marker; the archive's own episode sequence can prove the pack.
- Kept stricter safety than a4k's first-file fallback: ambiguous multi-file archives are rejected instead of silently installing the wrong episode.
- Added legacy ZIP filename decoding compatible with a4k's CP437/UTF-8 handling and expanded supported text extensions.
- Manual result labels are now shown as `SUBTITLE TITLE (OWNER)` while ID, family, rating, and downloads remain internal metadata.
- Error messages now distinguish a successful ZIP download from an episode-selection failure.

## 0.1.18
- Automatic background subtitle work now runs only for movies and episodes registered in Kodi's video library. Standalone local clips are ignored silently.
- Indonesian-language movies and series are skipped when the current audio is Indonesian, Kodi country metadata is Indonesia, or the normalized video path matches configurable Indonesian keywords.
- Manual Kodi subtitle search remains available even when automatic playback is skipped.
- Added General settings for the library-only gate, Indonesian-content gate, and path keywords.

## 0.1.17
- Added an automatic Indonesian candidate-selection setting: global ranked/filter order or balanced release-family round-robin.
- The selected mode now also controls F3 alternative expansion and Indonesian candidates synchronized to a verified English reference.
- Season fast-path reuse remains direct and does not broaden until F3/R1 asks for alternatives.

# Changelog

## 0.1.16
- Scans every matching text subtitle beside the video and in `Subs`/`Subtitles`, not only embedded MKV tracks.
- Embedded or local Indonesian text wins over learned season sources.
- Matching local English text can be used as an exact-video synchronization reference.
- A one-profile season/local fast path now expands automatically when F3/R1 is pressed, then cycles the newly downloaded Indonesian alternatives.
- Verified manual-English season references remain reusable when expanding alternatives.
- One-off subtitle changes are stored as episode overrides; a different source is promoted to the season default only after two consecutive episodes.
- Bumped manifest policy so older sessions cannot hide newly added local sidecars.

## 0.1.15
- Automatic online-English reference search removed.
- Embedded Indonesian text is used directly.
- Embedded English text from the same MKV is the only automatic sync reference.
- Without embedded English text, top Indonesian candidates are kept untouched and cycled with F3/R1.
- Proven TV-season sources are retried directly before any broad search.
- Manual English confirmation now exposes every synchronized Indonesian result for testing, including large-correction warnings, and requires a second hold to save.
- Manual selection invalidates older background automatic work.
- Restored all settings labels and added a visible Export Diagnosis button.
- Old manifests are invalidated by the new reference policy.

# Changelog

## 0.1.14
- Manual Indonesian downloads now use their original timing immediately; no AutoSync is applied.
- Manual English results are listed in the Kodi subtitle search. They are previewed untouched and can be confirmed with hold R1 / Shift+F3.
- Confirming a manual English reference synchronizes Indonesian candidates specifically to that user-verified reference.
- Manual Indonesian and confirmed English-reference metadata are remembered per TV season and the matching episode member is reused next episode.
- Added a dedicated SubRip release family and multiple English references per family; generic Other now tests more alternatives.
- Automatic profile sets keep RAW timing for up to three distinct Indonesian candidates, preventing valid releases such as CasStudio from disappearing after ranking.
- Risky profiles remain excluded from F3/R1 cycling.
- Compact notifications now show safe-cycle position, release family, and owner/release group instead of the full subtitle filename.
- Running the add-on exports a diagnostic ZIP containing session, manifest, candidate matrix, profiles, keymap, sanitized settings, and filtered Kodi log.
- Bumped manifest reference policy to invalidate older profile layouts.

## 0.1.13
- Added safe profile cycling with F3/R1 and hold R1 pinning.
- Risky profiles are excluded from cycling.

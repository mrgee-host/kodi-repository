# -*- coding: utf-8 -*-
from __future__ import annotations

import hashlib
import json
import os
import time
from typing import Any, Dict, List, Optional

import xbmc
import xbmcvfs

from .common import (
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARNING,
    NOTIFICATION_LIMIT,
    MediaContext,
    PROFILE_SESSION_DIR,
    SEASON_PROFILE_DIR,
    STATE_DIR,
    compact_label,
    log,
    notify,
    read_text,
    setting_bool,
    setting_int,
    write_text,
)
from .kodi_runtime import apply_external_subtitle, get_media_context, subtitle_stream_snapshot, subtitle_stream_changed
from .release_match import infer_release_owner, release_similarity
from .storage import media_key, save_manifest, save_output


def _read_json(path: str) -> Optional[Dict[str, Any]]:
    if not path or not xbmcvfs.exists(path):
        return None
    try:
        value = json.loads(read_text(path))
        return value if isinstance(value, dict) else None
    except Exception as exc:
        log("profile JSON read failed %s: %s" % (path, exc), LOG_WARNING)
        return None


def _write_json(path: str, payload: Dict[str, Any]) -> None:
    write_text(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))


def session_path(media: MediaContext) -> str:
    return os.path.join(PROFILE_SESSION_DIR, media_key(media) + ".json")


def load_session(media: MediaContext) -> Optional[Dict[str, Any]]:
    payload = _read_json(session_path(media))
    if not payload:
        try:
            _dirs, names = xbmcvfs.listdir(PROFILE_SESSION_DIR)
        except Exception:
            names = []
        wanted = os.path.normcase(os.path.normpath(str(media.path or '')))
        for name in names:
            if not name.lower().endswith('.json'):
                continue
            candidate = _read_json(os.path.join(PROFILE_SESSION_DIR, name))
            if not candidate:
                continue
            got = os.path.normcase(os.path.normpath(str(candidate.get('video_path') or '')))
            if got == wanted:
                payload = candidate
                break
    if not payload:
        return None
    if os.path.normcase(os.path.normpath(str(payload.get("video_path") or ''))) != os.path.normcase(os.path.normpath(str(media.path or ''))):
        return None
    profiles = payload.get("profiles")
    if not isinstance(profiles, list) or not profiles:
        return None
    return payload


def save_session(media: MediaContext, payload: Dict[str, Any]) -> str:
    payload = dict(payload)
    payload.setdefault("version", 2)
    payload["video_path"] = media.path
    payload["show_title"] = media.show_title
    payload["season"] = media.season
    payload["episode"] = media.episode
    payload["updated_at"] = int(time.time())
    path = session_path(media)
    _write_json(path, payload)
    try:
        import xbmcgui
        home = xbmcgui.Window(10000)
        home.setProperty('SubSource.ActiveSessionPath', path)
        home.setProperty('SubSource.ActiveVideoPath', media.path)
    except Exception:
        pass
    return path


def _season_identity(media: MediaContext) -> str:
    show = (media.show_title or media.title or media.imdb_id or media.path).strip().lower()
    raw = "%s|%s|%s" % (media.imdb_id, show, media.season)
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()


def season_preference_path(media: MediaContext) -> str:
    return os.path.join(SEASON_PROFILE_DIR, _season_identity(media) + ".json")


def load_season_preference(media: MediaContext) -> Optional[Dict[str, Any]]:
    if not media.is_episode:
        return None
    payload = _read_json(season_preference_path(media))
    if not payload:
        return None
    if int(payload.get("season", -999)) != int(media.season):
        return None
    overrides = payload.get("episode_overrides") or {}
    override = overrides.get(str(int(media.episode))) if isinstance(overrides, dict) else None
    if isinstance(override, dict):
        merged = dict(payload)
        merged.update(override)
        merged["_preference_scope"] = "episode"
        return merged
    payload["_preference_scope"] = "season"
    return payload


def _profile_preference_payload(media: MediaContext, profile: Dict[str, Any], source: str) -> Dict[str, Any]:
    return {
        "saved_from_episode": media.episode,
        "saved_at": int(time.time()),
        "saved_by": source,
        "family": profile.get("source_family") or profile.get("family") or "other",
        "mode": profile.get("mode") or "automatic",
        "language": profile.get("language") or "indonesian",
        "target_subsource_id": profile.get("target_subsource_id"),
        "target_release": profile.get("target_release") or profile.get("target_label") or "",
        "target_owner": profile.get("target_owner") or "",
        "target_filename": profile.get("target_filename") or "",
        "reference_subsource_id": profile.get("reference_subsource_id"),
        "reference_release": profile.get("reference_release") or profile.get("reference_label") or "",
        "reference_owner": profile.get("reference_owner") or "",
        "reference_filename": profile.get("reference_filename") or "",
        "target_label": profile.get("target_label") or "",
        "reference_label": profile.get("reference_label") or "",
    }


def _preference_fingerprint(payload: Dict[str, Any]) -> str:
    parts = (
        payload.get("mode") or "",
        payload.get("family") or "",
        payload.get("target_subsource_id") or "",
        payload.get("target_owner") or "",
        payload.get("target_release") or "",
        payload.get("reference_subsource_id") or "",
        payload.get("reference_owner") or "",
        payload.get("reference_release") or "",
    )
    return "|".join(str(value).strip().lower() for value in parts)


def save_season_preference(media: MediaContext, profile: Dict[str, Any], source: str) -> str:
    if not media.is_episode:
        return ""
    path = season_preference_path(media)
    current = _read_json(path) or {}
    selected = _profile_preference_payload(media, profile, source)
    selected_fp = _preference_fingerprint(selected)
    current_fp = _preference_fingerprint(current) if current else ""

    base = dict(current) if current else {
        "version": 2,
        "show_title": media.show_title,
        "show_imdb_id": media.imdb_id,
        "season": media.season,
        "episode_overrides": {},
    }
    base.setdefault("version", 2)
    base.setdefault("show_title", media.show_title)
    base.setdefault("show_imdb_id", media.imdb_id)
    base["season"] = media.season
    overrides = base.get("episode_overrides")
    if not isinstance(overrides, dict):
        overrides = {}
    base["episode_overrides"] = overrides

    # First proven source becomes the season default. Reconfirming the same
    # source refreshes it. A different source on a single episode is stored as
    # an episode override so one odd release does not poison the next episode.
    promoted = False
    if not current_fp or selected_fp == current_fp:
        preserved_overrides = dict(overrides)
        base.update(selected)
        base["episode_overrides"] = preserved_overrides
        base.pop("pending_switch", None)
    else:
        overrides[str(int(media.episode))] = dict(selected)
        pending = base.get("pending_switch") if isinstance(base.get("pending_switch"), dict) else {}
        same_pending = str(pending.get("fingerprint") or "") == selected_fp
        consecutive = abs(int(pending.get("episode", -999)) - int(media.episode)) == 1
        if same_pending and consecutive:
            preserved_overrides = dict(overrides)
            base.update(selected)
            base["episode_overrides"] = preserved_overrides
            base.pop("pending_switch", None)
            promoted = True
        else:
            base["pending_switch"] = {
                "fingerprint": selected_fp,
                "episode": int(media.episode),
                "saved_at": int(time.time()),
            }

    _write_json(path, base)
    scope = "season-promoted" if promoted else ("season" if not current_fp or selected_fp == current_fp else "episode-override")
    log(
        "profile preference saved show=%s season=%s episode=%s scope=%s family=%s target=%s source=%s"
        % (media.show_title, media.season, media.episode, scope, selected["family"], selected["target_release"], source),
        LOG_INFO,
    )
    return path


def preference_bonus(candidate_id: str, release: str, preference: Optional[Dict[str, Any]], kind: str) -> float:
    if not preference:
        return 0.0
    id_key = "%s_subsource_id" % kind
    release_key = "%s_release" % kind
    preferred_id = str(preference.get(id_key) or "")
    preferred_release = str(preference.get(release_key) or "")
    bonus = 0.0
    if preferred_id and str(candidate_id or "") == preferred_id:
        bonus += 1000.0
    similarity = release_similarity(release or "", preferred_release)
    bonus += 180.0 * similarity
    return bonus


def profile_preference_score(profile: Dict[str, Any], preference: Optional[Dict[str, Any]]) -> float:
    if not preference:
        return 0.0
    score = 0.0
    if profile.get("family") == preference.get("family"):
        score += 400.0
    if profile.get("target_subsource_id") and str(profile.get("target_subsource_id")) == str(preference.get("target_subsource_id") or ""):
        score += 800.0
    score += 180.0 * release_similarity(
        str(profile.get("target_release") or profile.get("target_label") or ""),
        str(preference.get("target_release") or ""),
    )
    if profile.get("reference_subsource_id") and str(profile.get("reference_subsource_id")) == str(preference.get("reference_subsource_id") or ""):
        score += 500.0
    score += 120.0 * release_similarity(
        str(profile.get("reference_release") or profile.get("reference_label") or ""),
        str(preference.get("reference_release") or ""),
    )
    return score


def _manifest_details(profile: Dict[str, Any], session: Dict[str, Any]) -> Dict[str, Any]:
    details = dict(profile.get("manifest") or {})
    details.update(
        {
            "profile_system": "release_family_cycle_v1",
            "profile_index": int(session.get("active_index", 0)),
            "profile_count": len(session.get("profiles") or []),
            "profile_family": profile.get("family") or "other",
            "profile_label": profile.get("label") or "",
        }
    )
    return details


def _safe_cycle_indices(session: Dict[str, Any]) -> List[int]:
    """Return the explicit user-cycle order.

    Automatic risky profiles stay excluded. A result synchronized to an
    English subtitle that the user verified against the actual video may be
    tested despite a large correction, but it is still marked risky and is not
    auto-saved.
    """
    profiles: List[Dict[str, Any]] = list(session.get("profiles") or [])

    def allowed(profile: Dict[str, Any]) -> bool:
        if not profile.get("cycle_enabled", True):
            return False
        if not profile.get("risky"):
            return True
        return profile.get("mode") == "synced_to_manual_reference"

    stored = session.get("cycle_indices")
    indices: List[int] = []
    if isinstance(stored, list):
        for value in stored:
            try:
                index = int(value)
            except Exception:
                continue
            if 0 <= index < len(profiles) and allowed(profiles[index]) and index not in indices:
                indices.append(index)
    if indices:
        return indices

    synced = [
        index for index, profile in enumerate(profiles)
        if profile.get("family") != "raw" and allowed(profile)
    ]
    raw = [
        index for index, profile in enumerate(profiles)
        if profile.get("family") == "raw" and allowed(profile)
    ]
    return synced + raw




def _family_display(profile: Dict[str, Any]) -> str:
    family = str(profile.get("source_family") or profile.get("family") or "other")
    return {
        "raw": "RAW", "english": "ENGLISH", "embedded": "EMBEDDED",
        "local": "LOCAL", "webdl": "WEB-DL", "webrip": "WEBRIP",
        "bluray": "BLURAY", "dvd": "DVD", "hdtv": "HDTV",
        "remux": "REMUX", "subrip": "SUB RIP", "other": "OTHER",
    }.get(family.lower(), family.upper())


def _owner_display(profile: Dict[str, Any]) -> str:
    owner = str(profile.get("target_owner") or profile.get("reference_owner") or "").strip()
    if owner:
        return owner.upper()
    release = str(profile.get("target_release") or profile.get("reference_release") or "")
    fallback_id = profile.get("target_subsource_id") or profile.get("reference_subsource_id") or ""
    return infer_release_owner(release, "ID %s" % fallback_id if fallback_id else "UNKNOWN").upper()


def _source_message(prefix: str, profile: Dict[str, Any], suffix: str = "") -> str:
    family = _family_display(profile)
    head = "%s • %s" % (prefix, family)
    tail = suffix or ""
    available = NOTIFICATION_LIMIT - len(head) - len(tail) - 3
    owner = compact_label(_owner_display(profile), max(3, available), "UNKNOWN")
    return "%s • %s%s" % (head, owner, tail)


def activate_profile(
    player: xbmc.Player,
    media: MediaContext,
    session: Dict[str, Any],
    index: int,
    announce: bool = True,
) -> str:
    profiles: List[Dict[str, Any]] = list(session.get("profiles") or [])
    if not profiles:
        raise RuntimeError("profil AutoSync belum tersedia")
    index = int(index) % len(profiles)
    profile = profiles[index]
    variant_path = str(profile.get("variant_path") or "")
    if not variant_path or not xbmcvfs.exists(variant_path):
        raise RuntimeError("file profil AutoSync tidak ditemukan")

    # The immutable, verified profile is the only path presented to Kodi.
    # Do not mutate session state or the canonical sidecar until Kodi confirms
    # that a real subtitle stream was created.
    if not apply_external_subtitle(player, variant_path):
        raise RuntimeError("Kodi menolak subtitle profil")

    sidecar_path = ""
    if not str(profile.get("language") or "indonesian").lower().startswith("en"):
        try:
            sidecar_path = save_output(media, read_text(variant_path))
        except Exception as exc:
            log("subtitle active but canonical sidecar save failed: %s" % exc, LOG_WARNING)

    session["active_index"] = index
    session["changed_at"] = time.time()
    session["stable_play_seconds"] = 0.0
    session["autosaved_index"] = None
    session["active_output_path"] = variant_path
    session["sidecar_output_path"] = sidecar_path
    session["last_apply_confirmed"] = True
    save_session(media, session)
    details = _manifest_details(profile, session)
    details["sidecar_output_path"] = sidecar_path
    details["active_profile_path"] = variant_path
    details["kodi_stream_confirmed"] = True
    save_manifest(media, variant_path, details)
    if announce:
        cycle = _safe_cycle_indices(session)
        if index in cycle:
            position = cycle.index(index) + 1
            total = len(cycle)
        else:
            position = index + 1
            total = len(profiles)
        mode = str(profile.get("mode") or "")
        ads_removed = max(0, int(profile.get("ads_removed") or 0))
        if mode == "manual_reference_preview":
            message = _source_message("ENGLISH", profile, " • SHIFT+F3 IF SYNCED")
        else:
            suffix = " • %d ADS REMOVED" % ads_removed if ads_removed else ""
            message = _source_message("SUBTITLE %d/%d" % (position, max(1, total)), profile, suffix)
        notify(message, warning=bool(profile.get("risky")), timeout=6000)
    log(
        "profile activated and Kodi-confirmed index=%02d/%02d family=%s target=%s reference=%s"
        % (index, max(0, len(profiles) - 1), profile.get("family"), profile.get("target_label"), profile.get("reference_label")),
        LOG_INFO,
    )
    return variant_path



def cycle_profile_count(session: Dict[str, Any]) -> int:
    return len(_safe_cycle_indices(session))

def cycle_profile(player: xbmc.Player, media: MediaContext) -> str:
    session = load_session(media)
    if not session:
        raise RuntimeError("belum ada kumpulan profil untuk video ini")
    profiles = session.get("profiles") or []
    cycle_indices = _safe_cycle_indices(session)
    if len(cycle_indices) < 2:
        raise RuntimeError("tidak ada alternatif profil aman")
    current = int(session.get("active_index", cycle_indices[0]))
    try:
        position = cycle_indices.index(current)
        next_index = cycle_indices[(position + 1) % len(cycle_indices)]
    except ValueError:
        next_index = cycle_indices[0]
    session["cycle_indices"] = cycle_indices
    return activate_profile(player, media, session, next_index, announce=True)



def movie_preference_path(media: MediaContext) -> str:
    folder = os.path.join(os.path.dirname(SEASON_PROFILE_DIR), "movie-profile-preferences")
    xbmcvfs.mkdirs(folder)
    key = hashlib.sha1(media_key(media).encode("utf-8", "ignore")).hexdigest()
    return os.path.join(folder, key + ".json")


def save_movie_preference(media: MediaContext, profile: Dict[str, Any], source: str) -> str:
    payload = _profile_preference_payload(media, profile, source)
    payload["scope"] = "movie"
    payload["video_path"] = getattr(media, "video_path", "") or ""
    path = movie_preference_path(media)
    _write_json(path, payload)
    return path


def save_media_preference(media: MediaContext, profile: Dict[str, Any], source: str) -> str:
    if getattr(media, "is_episode", False):
        return save_season_preference(media, profile, source)
    return save_movie_preference(media, profile, source)

def pin_active_profile(media: MediaContext) -> bool:
    session = load_session(media)
    if not session:
        return False
    profiles = session.get("profiles") or []
    if not profiles:
        return False
    index = int(session.get("active_index", 0)) % len(profiles)
    profile = profiles[index]
    if profile.get("risky") and profile.get("mode") != "synced_to_manual_reference":
        notify("UNSAFE SUBTITLE CANNOT BE SAVED", warning=True)
        return False
    if not save_media_preference(media, profile, "manual_pin"):
        return False
    session["pinned_index"] = index
    save_session(media, session)
    notify(_source_message("SUBTITLE SOURCE SAVED", profile))
    return True


class ProfileStabilityMonitor:
    def __init__(self, player: xbmc.Player):
        self.player = player
        self._session_path = ""
        self._active_index = -1
        self._last_position: Optional[float] = None
        self._stable_seconds = 0.0

    def _reset(self, path: str = "", index: int = -1, position: Optional[float] = None) -> None:
        self._session_path = path
        self._active_index = index
        self._last_position = position
        self._stable_seconds = 0.0

    def tick(self) -> None:
        if not setting_bool("auto_save_stable_profile", True):
            return
        try:
            if not self.player.isPlayingVideo():
                self._reset()
                return
        except Exception:
            self._reset()
            return

        from .kodi_runtime import get_media_context

        media = get_media_context(self.player)
        if not media or not media.is_episode:
            self._reset()
            return
        session = load_session(media)
        if not session:
            self._reset()
            return
        path = session_path(media)
        profiles = session.get("profiles") or []
        if not profiles:
            self._reset()
            return
        index = int(session.get("active_index", 0)) % len(profiles)
        try:
            position = float(self.player.getTime())
        except Exception:
            return

        if path != self._session_path or index != self._active_index:
            self._reset(path, index, position)
            return

        if session.get("autosaved_index") == index:
            self._last_position = position
            return

        try:
            paused = bool(xbmc.getCondVisibility("Player.Paused"))
        except Exception:
            paused = False
        if self._last_position is not None and not paused:
            delta = position - self._last_position
            # Normal playback advances roughly one second per tick. Seeks and
            # rewinds are deliberately not counted as stable viewing time.
            if 0.0 < delta <= 4.0:
                self._stable_seconds += delta
        self._last_position = position

        required_seconds = max(60, setting_int("stable_profile_minutes", 10) * 60)
        min_progress = max(1, min(90, setting_int("stable_profile_min_progress", 15))) / 100.0
        try:
            total = float(self.player.getTotalTime())
        except Exception:
            total = 0.0
        progress = position / total if total > 0 else 0.0
        if self._stable_seconds < required_seconds or progress < min_progress:
            return

        profile = profiles[index]
        if profile.get("risky") and not setting_bool("allow_large_correction_auto_save", False):
            log("stable profile not auto-saved because correction is marked risky", LOG_DEBUG)
            return
        if not save_season_preference(media, profile, "stable_playback"):
            return
        session["autosaved_index"] = index
        session["stable_play_seconds"] = round(self._stable_seconds, 1)
        save_session(media, session)
        notify(
            _source_message("SUBTITLE SOURCE AUTO-SAVED", profile),
            timeout=5000,
        )


def install_default_keymap() -> None:
    if not setting_bool("install_default_f3_keymap", True):
        return
    keymap_dir = xbmcvfs.translatePath("special://profile/keymaps")
    xbmcvfs.mkdirs(keymap_dir)
    path = os.path.join(keymap_dir, "subsource_autosync.xml")
    action_next = "RunScript(special://home/addons/service.subtitles.subsource.autosync/profile_action.py,next)"
    action_pin = "RunScript(special://home/addons/service.subtitles.subsource.autosync/profile_action.py,pin)"
    content = """<?xml version="1.0" encoding="UTF-8"?>
<!-- Smart Subtitle default keymap v3.
     Keyboard: F3 next, Shift+F3 save.
     Controller: R1/right bumper next, hold R1 800 ms save. -->
<keymap>
  <FullscreenVideo>
    <keyboard>
      <f3>%s</f3>
      <f3 mod="shift">%s</f3>
    </keyboard>
    <joystick profile="game.controller.default">
      <rightbumper>%s</rightbumper>
      <rightbumper holdtime="800">%s</rightbumper>
    </joystick>
  </FullscreenVideo>
  <VideoOSD>
    <keyboard>
      <f3>%s</f3>
      <f3 mod="shift">%s</f3>
    </keyboard>
    <joystick profile="game.controller.default">
      <rightbumper>%s</rightbumper>
      <rightbumper holdtime="800">%s</rightbumper>
    </joystick>
  </VideoOSD>
</keymap>
""" % (action_next, action_pin, action_next, action_pin, action_next, action_pin, action_next, action_pin)

    if xbmcvfs.exists(path):
        return
    write_text(path, content)
    try:
        xbmc.executebuiltin("ReloadKeymaps")
    except Exception:
        pass
    log("default F3/R1 profile keymap installed: %s" % path, LOG_INFO)


class ManualSubtitleMonitor:
    def __init__(self, player: xbmc.Player):
        self.player = player
        self.path = os.path.join(STATE_DIR, "manual_subtitle_pending.json")

    def tick(self) -> None:
        if not xbmcvfs.exists(self.path):
            return
        pending = _read_json(self.path) or {}
        created = float(pending.get("created_at") or 0.0)
        if created and time.time() - created > 45.0:
            pending["status"] = "expired_without_kodi_confirmation"
            _write_json(os.path.join(STATE_DIR, "last_manual_subtitle_result.json"), pending)
            xbmcvfs.delete(self.path)
            log("manual subtitle confirmation expired", LOG_WARNING)
            return
        try:
            media = get_media_context(self.player)
        except Exception:
            return
        if os.path.normcase(os.path.normpath(str(media.path or ""))) != os.path.normcase(os.path.normpath(str(pending.get("video_path") or ""))):
            return
        before = pending.get("before") if isinstance(pending.get("before"), dict) else {}
        after = subtitle_stream_snapshot(self.player)
        variant = str(pending.get("variant_path") or "")
        if not subtitle_stream_changed(before, after, variant):
            return
        profile = pending.get("profile") if isinstance(pending.get("profile"), dict) else {}
        session = load_session(media) or {"profiles": [profile], "active_index": 0}
        sidecar = ""
        english = str(pending.get("language") or "").lower().startswith("en")
        if not english:
            try:
                sidecar = save_output(media, read_text(variant))
            except Exception as exc:
                log("manual subtitle confirmed but sidecar save failed: %s" % exc, LOG_WARNING)
        session.update({
            "active_index": 0, "active_output_path": variant, "sidecar_output_path": sidecar,
            "pending_manual_confirmation": False, "last_apply_confirmed": True,
            "changed_at": time.time(), "stable_play_seconds": 0.0,
        })
        save_session(media, session)
        details = _manifest_details(profile, session)
        details.update({"sidecar_output_path": sidecar, "active_profile_path": variant, "kodi_stream_confirmed": True, "manual_kodi_owned": True})
        save_manifest(media, variant, details)
        if media.is_episode and not english:
            save_season_preference(media, profile, "manual_original")
        pending.update({"status": "kodi_stream_confirmed", "confirmed_at": time.time(), "after": after, "sidecar_output_path": sidecar})
        _write_json(os.path.join(STATE_DIR, "last_manual_subtitle_result.json"), pending)
        xbmcvfs.delete(self.path)
        ads = int(pending.get("ads_removed") or 0)
        suffix = " • %d ADS REMOVED" % ads if ads else ""
        notify(_source_message("ENGLISH" if english else "SUBTITLE 1/1", profile, suffix), timeout=6000)
        log("manual subtitle stream confirmed by Kodi: %s" % variant, LOG_INFO)

# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import json
import time
from typing import Dict, List, Optional
from urllib.parse import parse_qs, urlencode

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

from .common import (
    ADDON, ADDON_ID, LOG_INFO, LOG_WARNING, STATE_DIR, MediaContext, SubtitleCandidate,
    failure_message, log, notify, setting_bool, setting_int, write_text,
)
from .core import AutoSyncWorkflow, PAUSE_WINDOW_PROPERTY, ReferenceSource, TargetSource
from .diagnostics_store import save_snapshot
from .kodi_runtime import get_media_context
from .profile_store import (
    activate_profile, load_season_preference, load_session, save_season_preference, save_session,
)
from .release_match import arrange_candidates_for_auto, candidate_owner, rank_candidates, release_family, trusted_source
from .storage import save_profile_variant
from .subtitle_io import parse_subtitle_file, parse_subtitle_text_with_report, render_srt
from .subsource_api import SubSourceClient, SubSourceError


def _first(params: Dict[str, List[str]], key: str, default: str = "") -> str:
    values = params.get(key) or []
    return str(values[0]) if values else default


def _as_int(value: str, default: int = 0) -> int:
    try:
        return int(value)
    except Exception:
        return default


def _as_float(value: str, default: float = 0.0) -> float:
    try:
        return float(value)
    except Exception:
        return default


def _media_from_params(params: Dict[str, List[str]]) -> Optional[MediaContext]:
    path = _first(params, "file_original_path") or _first(params, "filename")
    title = _first(params, "title")
    show_title = _first(params, "tvshow")
    season = _as_int(_first(params, "season"), 0)
    episode = _as_int(_first(params, "episode"), 0)
    imdb = _first(params, "imdb") or _first(params, "imdbid")
    if imdb and imdb.isdigit():
        imdb = "tt%s" % imdb
    is_episode = bool(show_title or season or episode)
    if not (path or title or show_title or imdb):
        return None
    return MediaContext(
        path=path,
        title=title or os.path.splitext(os.path.basename(path))[0],
        year=_as_int(_first(params, "year"), 0),
        imdb_id=imdb,
        is_episode=is_episode,
        show_title=show_title,
        season=season,
        episode=episode,
        filename=os.path.basename(path),
        media_type="episode" if is_episode else "movie",
    )


def _current_media(params: Dict[str, List[str]]) -> Optional[MediaContext]:
    player = xbmc.Player()
    media = get_media_context(player)
    if media:
        search_string = _first(params, "searchstring")
        if search_string:
            if media.is_episode:
                media.show_title = search_string
            else:
                media.title = search_string
            media.imdb_id = ""
        return media
    return _media_from_params(params)


def _decode(payload: bytes) -> str:
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return payload.decode(encoding)
        except UnicodeDecodeError:
            continue
    return payload.decode("utf-8", "replace")


def _candidate_from_params(params: Dict[str, List[str]]) -> SubtitleCandidate:
    return SubtitleCandidate(
        subtitle_id=_first(params, "id"),
        language=_first(params, "language", "indonesian"),
        release_info=_first(params, "release"),
        rating=_as_float(_first(params, "rating"), 0.0),
        rating_votes=_as_int(_first(params, "votes"), 0),
        download_count=_as_int(_first(params, "downloads"), 0),
        hearing_impaired=_first(params, "hi") == "1",
        link=_first(params, "link"),
        score=_as_float(_first(params, "score"), 0.0),
        owner=_first(params, "owner"),
    )


def _resume_if_auto_paused() -> None:
    try:
        window = xbmcgui.Window(10000)
        if window.getProperty(PAUSE_WINDOW_PROPERTY) != "1":
            return
        window.clearProperty(PAUSE_WINDOW_PROPERTY)
        if xbmc.getCondVisibility("Player.Paused"):
            xbmc.Player().pause()
    except Exception as exc:
        log("manual result could not resume playback: %s" % exc, LOG_WARNING)


def _end(handle: int, succeeded: bool = True) -> None:
    try:
        xbmcplugin.endOfDirectory(handle, succeeded=succeeded)
    except TypeError:
        xbmcplugin.endOfDirectory(handle)


def _kodi_rating(candidate: SubtitleCandidate) -> str:
    try:
        value = max(0.0, min(10.0, float(candidate.rating or 0.0))) / 2.0
    except Exception:
        value = 0.0
    rounded = round(value, 1)
    return str(int(rounded)) if float(rounded).is_integer() else ("%.1f" % rounded)


def _result_item(handle: int, base_url: str, candidate: SubtitleCandidate, movie_id: str) -> None:
    language = (candidate.language or "").lower()
    is_english = language.startswith("en") or "english" in language
    owner = candidate_owner(candidate)
    release = (candidate.release_info or "Subtitle %s" % candidate.subtitle_id).strip()
    # Keep ID/family/downloads as hidden query metadata, but show the same clean
    # human-facing shape as the SubSource website: TITLE (OWNER).
    display_owner = owner.strip()
    fallback_owner = "ID %s" % candidate.subtitle_id if candidate.subtitle_id else "ID"
    if display_owner.upper() == fallback_owner.upper():
        display_owner = ""
    label2 = "%s (%s)" % (release, display_owner) if display_owner else release
    item = xbmcgui.ListItem(label="English" if is_english else "Indonesian", label2=label2)
    try:
        item.setProperty("sync", "false")
        item.setProperty("hearing_imp", "true" if candidate.hearing_impaired else "false")
        item.setProperty("language", "en" if is_english else "id")
        # Kodi's subtitle dialog interprets icon as a 0-5 rating and thumb as
        # the ISO language code. This is the same metadata contract used by
        # a4kSubtitles, so AF3 can draw filled stars and the Indonesian flag.
        item.setArt({"icon": _kodi_rating(candidate), "thumb": "en" if is_english else "id"})
    except Exception:
        pass
    query = {
        "action": "download",
        "id": candidate.subtitle_id,
        "language": candidate.language,
        "release": candidate.release_info,
        "owner": owner,
        "rating": str(candidate.rating),
        "votes": str(candidate.rating_votes),
        "downloads": str(candidate.download_count),
        "hi": "1" if candidate.hearing_impaired else "0",
        "link": candidate.link,
        "score": str(candidate.score),
        "movie_id": movie_id,
    }
    xbmcplugin.addDirectoryItem(handle, "%s?%s" % (base_url, urlencode(query)), item, isFolder=False)


def _search(handle: int, base_url: str, params: Dict[str, List[str]]) -> None:
    api_key = ADDON.getSetting("subsource_api_key").strip()
    if not api_key:
        notify("ADD SUBSOURCE API KEY IN SETTINGS", warning=True)
        _end(handle, False)
        return
    media = _current_media(params)
    if not media:
        notify("VIDEO INFO NOT AVAILABLE", warning=True)
        _end(handle, False)
        return
    client = SubSourceClient(api_key)
    try:
        movie_id = client.resolve_movie_id(media)
        indonesian = rank_candidates(
            client.list_subtitles(movie_id, "indonesian"), media,
            prefer_non_sdh=setting_bool("prefer_non_sdh", True),
        )
        english = rank_candidates(
            client.list_subtitles(movie_id, "english"), media,
            prefer_non_sdh=setting_bool("prefer_non_sdh", True),
        )
    except SubSourceError as exc:
        notify(failure_message("SUBSOURCE SEARCH FAILED", exc), warning=True)
        _end(handle, False)
        return

    limit = max(10, min(setting_int("manual_results", 40), 100))
    log(
        "manual OSD results Indonesian=%d English=%d shown_each=%d trusted_top=%s"
        % (len(indonesian), len(english), limit, [trusted_source(item) for item in indonesian[:5]]), LOG_INFO,
    )
    try:
        xbmcplugin.setContent(handle, "files")
    except Exception:
        pass
    for candidate in indonesian[:limit]:
        _result_item(handle, base_url, candidate, movie_id)
    for candidate in english[:limit]:
        _result_item(handle, base_url, candidate, movie_id)
    _end(handle, True)


def _manual_profile(candidate: SubtitleCandidate, filename: str, cues, english: bool, ads_removed: int = 0) -> Dict:
    owner = candidate_owner(candidate)
    source_family = release_family(candidate.release_info)
    if english:
        return {
            "family": "english",
            "source_family": source_family,
            "language": "english",
            "mode": "manual_reference_preview",
            "label": "English • %s • %s" % (source_family, owner),
            "reference_label": "Manual English [%s]: %s" % (candidate.subtitle_id, candidate.release_info),
            "reference_release": candidate.release_info,
            "reference_subsource_id": candidate.subtitle_id,
            "reference_owner": owner,
            "reference_filename": filename,
            "target_label": "",
            "target_release": "",
            "target_subsource_id": None,
            "target_owner": "",
            "confidence": None,
            "global_offset_ms": 0,
            "p90_error_ms": None,
            "max_abs_correction_ms": 0,
            "correction_span_ms": 0,
            "runtime_score": 0.0,
            "ads_removed": int(ads_removed or 0),
            "risky": False,
            "cycle_enabled": True,
            "manifest": {
                "method": "manual_english_reference_preview",
                "reference_language": "english",
                "reference_subsource_id": candidate.subtitle_id,
                "reference": candidate.release_info,
                "reference_owner": owner,
                "reference_filename": filename,
                "ads_removed": int(ads_removed or 0),
                "audio_analysis": False,
            },
            "_srt": render_srt(cues),
        }
    return {
        "family": "raw",
        "source_family": source_family,
        "language": "indonesian",
        "mode": "manual_original",
        "label": "RAW • %s • %s" % (source_family, owner),
        "target_label": "Manual Indonesian [%s]: %s" % (candidate.subtitle_id, candidate.release_info),
        "target_release": candidate.release_info,
        "target_subsource_id": candidate.subtitle_id,
        "target_owner": owner,
        "target_filename": filename,
        "reference_label": "Original subtitle timing",
        "reference_release": "",
        "reference_subsource_id": None,
        "reference_owner": "",
        "confidence": None,
        "global_offset_ms": 0,
        "p90_error_ms": None,
        "max_abs_correction_ms": 0,
        "correction_span_ms": 0,
        "runtime_score": 0.0,
        "ads_removed": int(ads_removed or 0),
        "risky": False,
        "cycle_enabled": True,
        "manifest": {
            "method": "manual_indonesian_original",
            "target_subsource_id": candidate.subtitle_id,
            "target": candidate.release_info,
            "target_owner": owner,
            "target_filename": filename,
            "ads_removed": int(ads_removed or 0),
            "audio_analysis": False,
        },
        "_srt": render_srt(cues),
    }


def _manual_pending_path() -> str:
    return os.path.join(STATE_DIR, "manual_subtitle_pending.json")


def apply_manual_candidate(player: xbmc.Player, media: MediaContext, candidate: SubtitleCandidate, filename: str, cues, ads_removed: int = 0) -> str:
    # Manual OSD has one owner: Kodi. Prepare an immutable cleaned subtitle and
    # return it to the subtitle dialog. The background service finalizes the
    # session and canonical sidecar only after Kodi exposes a new stream.
    english = (candidate.language or "").lower().startswith("en") or "english" in (candidate.language or "").lower()
    profile = _manual_profile(candidate, filename, cues, english, ads_removed=ads_removed)
    profile["variant_path"] = save_profile_variant(media, 0, profile.pop("_srt"))
    session = {
        "version": 7, "profile_order": "manual_kodi_owned_v1", "active_index": 0,
        "cycle_indices": [0], "changed_at": 0, "stable_play_seconds": 0.0,
        "profiles": [profile], "pending_manual_confirmation": True,
    }
    save_session(media, session)
    try:
        from .kodi_runtime import subtitle_stream_snapshot
        before = subtitle_stream_snapshot(player)
    except Exception:
        before = {}
    pending = {
        "version": 1, "created_at": time.time(), "video_path": media.path,
        "title": media.title, "show_title": media.show_title, "season": media.season,
        "episode": media.episode, "language": "english" if english else "indonesian",
        "variant_path": profile["variant_path"], "profile": profile, "before": before,
        "subtitle_id": candidate.subtitle_id, "release": candidate.release_info,
        "owner": candidate_owner(candidate), "member": filename, "cue_count": len(cues),
        "ads_removed": int(ads_removed or 0),
    }
    write_text(_manual_pending_path(), json.dumps(pending, ensure_ascii=False, indent=2, sort_keys=True))
    save_snapshot(media, {
        "status": "manual_waiting_for_kodi",
        "manual_selection": {
            "language": pending["language"], "subtitle_id": candidate.subtitle_id,
            "release": candidate.release_info, "owner": pending["owner"],
            "member": filename, "cue_count": len(cues), "ads_removed": int(ads_removed or 0),
        },
    })
    return profile["variant_path"]



def confirm_manual_reference(player: xbmc.Player, media: MediaContext) -> bool:
    session = load_session(media)
    if not session:
        return False
    profiles = session.get("profiles") or []
    if not profiles:
        return False
    index = int(session.get("active_index", 0)) % len(profiles)
    profile = profiles[index]
    if profile.get("mode") != "manual_reference_preview":
        return False
    path = str(profile.get("variant_path") or "")
    reference_cues = parse_subtitle_file(path)
    if len(reference_cues) < 20:
        raise RuntimeError("referensi Inggris manual tidak dapat dibaca")

    api_key = ADDON.getSetting("subsource_api_key").strip()
    client = SubSourceClient(api_key)
    movie_id = client.resolve_movie_id(media)
    reference_candidate = SubtitleCandidate(
        subtitle_id=str(profile.get("reference_subsource_id") or ""),
        language="english",
        release_info=str(profile.get("reference_release") or ""),
        owner=str(profile.get("reference_owner") or ""),
    )
    reference = ReferenceSource(
        label=str(profile.get("reference_label") or "Manual English"),
        cues=reference_cues,
        candidate=reference_candidate,
        filename=str(profile.get("reference_filename") or ""),
        family=str(profile.get("source_family") or release_family(reference_candidate.release_info)),
        runtime_score=AutoSyncWorkflow._runtime_score(reference_cues, media),
        ads_removed=int(profile.get("ads_removed") or 0),
    )

    workflow = AutoSyncWorkflow(player)
    candidates = rank_candidates(
        client.list_subtitles(movie_id, "indonesian"), media,
        prefer_non_sdh=setting_bool("prefer_non_sdh", True),
    )
    preference = load_season_preference(media)
    preferred_id = ""
    if preference and preference.get("target_subsource_id"):
        preferred_id = str(preference.get("target_subsource_id"))
    mode = "tv-family-best" if media.is_episode else "movie-community-ranked"
    candidates = arrange_candidates_for_auto(candidates, media, mode=mode, preferred_id=preferred_id)
    max_valid = max(3, setting_int("max_candidates", 10))
    attempt_limit = min(len(candidates), max(30, max_valid * 5), 50)
    targets: List[TargetSource] = []
    cursor = 0
    while len(targets) < max_valid and cursor < attempt_limit:
        workers = max(1, min(setting_int("parallel_downloads", 3), 4))
        chunk = candidates[cursor : min(attempt_limit, cursor + workers)]
        cursor += len(chunk)
        targets.extend(workflow._download_indonesian_chunk(client, chunk, media, workers))
        if not chunk:
            break
    choices = workflow._rank_sync_choices(targets, [reference]) if targets else []
    workflow._apply_manual_reference_choices(media, choices, profile, reference, preference)
    return True


def _download(handle: int, params: Dict[str, List[str]]) -> None:
    media = _current_media(params)
    candidate = _candidate_from_params(params)
    api_key = ADDON.getSetting("subsource_api_key").strip()
    if not media or not candidate.subtitle_id or not api_key:
        notify("SUBTITLE DATA IS INCOMPLETE", warning=True)
        _end(handle, False)
        return
    player = xbmc.Player()
    client = SubSourceClient(api_key)
    try:
        downloaded = client.download_and_select(candidate, media)
        cues, cleanup_report = parse_subtitle_text_with_report(
            _decode(downloaded.payload), downloaded.filename
        )
        minimum = 20 if (candidate.language or "").lower().startswith("en") else 8
        if len(cues) < minimum:
            raise ValueError("subtitle hanya memiliki %d cue" % len(cues))
        output_path = apply_manual_candidate(
            player, media, candidate, downloaded.filename, cues,
            ads_removed=int(cleanup_report.removed_lines or 0),
        )
        item = xbmcgui.ListItem(label=output_path)
        xbmcplugin.addDirectoryItem(handle, output_path, item, isFolder=False)
        _end(handle, True)
        _resume_if_auto_paused()
        log(
            "manual subtitle returned to Kodi original_timing cleaned_ads=true language=%s id=%s member=%s output=%s"
            % (candidate.language, candidate.subtitle_id, downloaded.filename, output_path),
            LOG_INFO,
        )
    except Exception as exc:
        log("manual subtitle download failed: %s" % exc, LOG_WARNING)
        notify(failure_message("SUBTITLE DOWNLOAD FAILED", exc), warning=True)
        _end(handle, False)


def run(argv: List[str]) -> None:
    try:
        handle = int(argv[1])
    except Exception:
        handle = -1
    base_url = argv[0] if argv else "plugin://%s/" % ADDON_ID
    raw_query = argv[2][1:] if len(argv) > 2 and argv[2].startswith("?") else (argv[2] if len(argv) > 2 else "")
    params = parse_qs(raw_query, keep_blank_values=True)
    action = _first(params, "action", "search").lower()
    if action in ("search", "manualsearch"):
        _search(handle, base_url, params)
    elif action == "download":
        _download(handle, params)
    else:
        log("unsupported subtitle action: %s" % action, LOG_WARNING)
        _end(handle, False)

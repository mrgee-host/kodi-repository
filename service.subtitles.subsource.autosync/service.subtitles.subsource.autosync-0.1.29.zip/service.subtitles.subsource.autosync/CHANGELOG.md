## 0.1.29

- Kodi-confirmed subtitle activation for automatic, F3, and manual OSD flows.
- Immutable profile apply, delayed canonical sidecar commit, and expanded diagnostics.

# Changelog

## 0.1.28

- Fresh-install baseline.
- Writes canonical `<video>.id.srt` sidecars directly with atomic replacement.
- Removes startup sidecar renaming, manifest-key conversion, runtime-layout movement, and keymap-version conversion.
- Keeps current F3 alternatives, subtitle cleanup, Kodi 22 JSON-RPC compatibility, diagnostics, and session behavior.

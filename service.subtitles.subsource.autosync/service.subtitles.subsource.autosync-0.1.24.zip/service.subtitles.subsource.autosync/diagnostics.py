# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import sys
import traceback

import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon("service.subtitles.subsource.autosync")
ADDON_PATH = ADDON.getAddonInfo("path")
if ADDON_PATH and ADDON_PATH not in sys.path:
    sys.path.insert(0, ADDON_PATH)

from resources.lib.common import LOG_WARNING, failure_message, log, notify
from resources.lib.diagnostics_store import export_diagnostics
from resources.lib.kodi_runtime import get_media_context


def main() -> None:
    try:
        media = get_media_context(xbmc.Player())
        path = export_diagnostics(media)
        notify("DIAGNOSTICS EXPORTED - %s" % os.path.basename(path), timeout=9000)
    except Exception as exc:
        log("diagnostic export failed: %s\n%s" % (exc, traceback.format_exc()), LOG_WARNING)
        notify(failure_message("DIAGNOSTICS EXPORT FAILED", exc), warning=True, timeout=7000)


if __name__ == "__main__":
    main()

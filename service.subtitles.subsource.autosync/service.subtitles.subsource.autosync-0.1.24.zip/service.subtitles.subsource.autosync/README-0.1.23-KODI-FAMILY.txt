SubSource AutoSync 0.1.23
- Notification bodies are uppercase and limited to 58 characters.
- Diagnostics ZIP stays in addon_data root, is validated first, then replaces every older canonical or legacy diagnostics ZIP.
- ZIP layout includes manifest.json and runtime/diagnostics/session-manifest.json.
- Generated diagnostics/state/export material moved under runtime/; cached subtitle work stays under cache/.
- User-facing diagnostics action is consistently named Export diagnostics ZIP.

SubSource AutoSync 0.1.24
- Stable sessions use normalized playing file path.
- Local sidecars use byte hash verification and rollback before replace.
- Profile filenames include .id so Kodi does not show UNK.
- Kodi loads the canonical sidecar after a successful save.
- Legacy migration seeds local episodes from Kodi library.
- Notification maximum remains 58 characters.

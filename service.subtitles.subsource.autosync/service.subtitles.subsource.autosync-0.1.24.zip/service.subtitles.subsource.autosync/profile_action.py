# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import sys
import traceback

import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon("service.subtitles.subsource.autosync")
ADDON_PATH = ADDON.getAddonInfo("path")
if ADDON_PATH and ADDON_PATH not in sys.path:
    sys.path.insert(0, ADDON_PATH)

from resources.lib.common import LOG_WARNING, failure_message, log, notify
from resources.lib.kodi_runtime import get_media_context
from resources.lib.profile_store import cycle_profile, cycle_profile_count, load_session, pin_active_profile
from resources.lib.manual_service import confirm_manual_reference
from resources.lib.core import AutoSyncWorkflow
from resources.lib.diagnostics_store import export_diagnostics


def _wait_for_media(player: xbmc.Player, attempts: int = 10, delay_ms: int = 150):
    """Wait briefly until a separate RunScript invocation sees VideoPlayer metadata."""
    for _ in range(max(1, attempts)):
        try:
            if player.isPlayingVideo():
                media = get_media_context(player)
                if media:
                    return media
        except Exception:
            pass
        xbmc.sleep(max(1, delay_ms))
    return None


def main() -> None:
    action = (sys.argv[1] if len(sys.argv) > 1 else "next").strip().lower()
    player = xbmc.Player()
    media = _wait_for_media(player)
    if not media:
        notify("NO ACTIVE VIDEO", warning=True)
        return
    try:
        if action in ("export", "diagnostics", "diagnosis"):
            path = export_diagnostics(media)
            notify("DIAGNOSTICS EXPORTED - %s" % os.path.basename(path), timeout=9000)
        elif action in ("pin", "save", "keep"):
            session = load_session(media) or {}
            profiles = session.get("profiles") or []
            index = int(session.get("active_index", 0)) % len(profiles) if profiles else -1
            active = profiles[index] if index >= 0 else {}
            if active.get("mode") == "manual_reference_preview":
                notify("SYNCING INDONESIAN SUBTITLES TO ENGLISH", timeout=5000)
                if not confirm_manual_reference(player, media):
                    raise RuntimeError("referensi Inggris manual belum tersedia")
            elif not pin_active_profile(media):
                raise RuntimeError("profil aktif belum tersedia")
        else:
            session = load_session(media) or {}
            profiles = session.get("profiles") or []
            active_index = int(session.get("active_index", 0)) % len(profiles) if profiles else -1
            active = profiles[active_index] if active_index >= 0 else {}
            if active.get("mode") == "manual_reference_preview":
                notify("ENGLISH PREVIEW • SHIFT+F3 WHEN SYNCED", timeout=6000)
                return
            if cycle_profile_count(session) < 2:
                if session.get("alternatives_loaded"):
                    raise RuntimeError("tidak ada alternatif profil lain")
                if not AutoSyncWorkflow(player).expand_alternatives(media):
                    raise RuntimeError("alternatif subtitle belum tersedia")
            else:
                cycle_profile(player, media)
    except Exception as exc:
        log("profile action failed: %s\n%s" % (exc, traceback.format_exc()), LOG_WARNING)
        notify(failure_message("SUBTITLE ACTION FAILED", exc), warning=True)


if __name__ == "__main__":
    main()

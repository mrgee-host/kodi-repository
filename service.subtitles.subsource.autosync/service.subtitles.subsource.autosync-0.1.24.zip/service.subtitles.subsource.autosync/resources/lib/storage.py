# -*- coding: utf-8 -*-
from __future__ import annotations

import hashlib
import json
import os
import re
import xml.etree.ElementTree as ET
from typing import Any, Dict, List, Optional, Tuple

import xbmcvfs
import xbmc

from .common import (
    ADDON,
    CACHE_DIR,
    MIGRATION_DIR,
    PROFILE,
    MANIFEST_DIR,
    PROFILE_SESSION_DIR,
    PROFILE_VARIANT_DIR,
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARNING,
    MediaContext,
    log,
    read_bytes,
    read_text,
    safe_filename,
    setting_bool,
    write_bytes,
    write_text,
)
from .kodi_runtime import stat_signature

SUB_EXTENSIONS = (".srt", ".ass", ".ssa", ".vtt", ".sub", ".smi")
REFERENCE_POLICY = "always_clean_ads_credits_v6"


def _normal_media_path(path: str) -> str:
    value = os.path.normpath(str(path or '').strip())
    return os.path.normcase(value)

def media_key(media: MediaContext) -> str:
    # Stable across separate RunScript invocations where IMDb/season metadata
    # can appear a few frames later than the playing file path.
    raw = _normal_media_path(media.path)
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()


def manifest_path(media: MediaContext) -> str:
    return os.path.join(MANIFEST_DIR, media_key(media) + ".json")


def load_manifest(media: MediaContext) -> Optional[Dict[str, Any]]:
    path = manifest_path(media)
    if not xbmcvfs.exists(path):
        # Backward-compatible lookup for manifests written by the old
        # path+IMDb+season+episode key.
        _, names = _listdir(MANIFEST_DIR)
        for name in names:
            if not name.lower().endswith('.json'):
                continue
            candidate = os.path.join(MANIFEST_DIR, name)
            try:
                probe = json.loads(read_text(candidate))
                if _normal_media_path(probe.get('video_path') or '') == _normal_media_path(media.path):
                    path = candidate
                    break
            except Exception:
                continue
    if not xbmcvfs.exists(path):
        return None
    try:
        payload = json.loads(read_text(path))
    except Exception as exc:
        log("manifest read failed: %s" % exc, LOG_WARNING)
        return None
    if _normal_media_path(payload.get("video_path") or '') != _normal_media_path(media.path):
        return None
    # Invalidate results made by the former PGS/SUP reference experiments.
    if payload.get("reference_policy") != REFERENCE_POLICY:
        return None
    current = stat_signature(media.path)
    saved = payload.get("video_signature") or {}
    if saved.get("size") and current.get("size") and int(saved["size"]) != int(current["size"]):
        return None
    if saved.get("mtime") and current.get("mtime") and int(saved["mtime"]) != int(current["mtime"]):
        return None
    output = payload.get("output_path") or ""
    if not output or not xbmcvfs.exists(output):
        return None
    return payload


def save_manifest(media: MediaContext, output_path: str, details: Dict[str, Any]) -> str:
    payload = {
        "version": 1,
        "video_path": media.path,
        "video_signature": stat_signature(media.path),
        "imdb_id": media.imdb_id,
        "season": media.season,
        "episode": media.episode,
        "output_path": output_path,
        "reference_policy": REFERENCE_POLICY,
    }
    payload.update(details)
    path = manifest_path(media)
    write_text(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
    return path


def _listdir(path: str) -> Tuple[List[str], List[str]]:
    # xbmcvfs.listdir logs an ERROR before raising when a directory is absent.
    # Check first so optional Subs/Subtitles folders stay silent.
    try:
        if not path or not xbmcvfs.exists(path):
            return [], []
        dirs, files = xbmcvfs.listdir(path)
        return list(dirs), list(files)
    except Exception:
        return [], []


def _normalised_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (value or "").lower())


def _subtitle_matches_video(media: MediaContext, filename: str) -> bool:
    lower = filename.lower()
    if not lower.endswith(SUB_EXTENSIONS):
        return False
    if ".autosync." in lower:
        return False

    base = os.path.splitext(filename)[0]
    stem_norm = _normalised_name(media.stem)
    base_norm = _normalised_name(base)
    if not stem_norm or not base_norm:
        return False
    if base_norm.startswith(stem_norm) or stem_norm.startswith(base_norm):
        return True

    # Renamed episode files and release-named sidecars often share only the
    # show title plus SxxExx. Require both to avoid grabbing another episode's
    # subtitle from the same season folder.
    if media.is_episode and media.episode_tag:
        episode_norm = _normalised_name(media.episode_tag)
        if episode_norm and episode_norm in base_norm:
            show_tokens = [token for token in re.split(r"[^a-z0-9]+", (media.show_title or media.title).lower()) if len(token) >= 3]
            if not show_tokens:
                return True
            hits = sum(1 for token in show_tokens if token in base.lower())
            return hits >= max(1, min(2, len(show_tokens)))
    return False


def find_local_subtitles(media: MediaContext) -> List[str]:
    """Return every readable text-subtitle candidate belonging to this video.

    The same folder is scanned first, followed by conventional Subs and
    Subtitles subfolders. Generated AutoSync outputs are excluded so stale
    results can never be fed back as fresh input.
    """
    video_dir = os.path.dirname(media.path)
    candidates: List[str] = []
    search_dirs = [video_dir, os.path.join(video_dir, "Subs"), os.path.join(video_dir, "Subtitles")]
    for directory in search_dirs:
        _, files = _listdir(directory)
        for filename in files:
            if _subtitle_matches_video(media, filename):
                candidates.append(os.path.join(directory, filename))
    return list(dict.fromkeys(candidates))


def _is_indonesian_name(stem: str, filename: str) -> bool:
    lower = filename.lower()
    if not lower.endswith(SUB_EXTENSIONS):
        return False
    base = os.path.splitext(lower)[0]
    stem_lower = stem.lower()
    if not (base.startswith(stem_lower) or stem_lower.startswith(base.split(".")[0])):
        return False
    tokens = re.split(r"[. _\-\[\]()]+", base)
    return any(token in ("id", "ind", "indo", "indonesia", "indonesian", "bahasa", "bahasaindonesia") for token in tokens)


def find_local_indonesian(media: MediaContext) -> List[str]:
    # Backward-compatible filename-only helper. Runtime classification in
    # local_scan.py also inspects subtitle text when the filename is untagged.
    return [path for path in find_local_subtitles(media) if _is_indonesian_name(media.stem, os.path.basename(path))]


ORIGINAL_BACKUP_DIR = os.path.join(CACHE_DIR, "originals")
CANONICAL_SIDECAR_MIGRATION = os.path.join(MIGRATION_DIR, "canonical-id-sidecar-v2.done")


def _canonical_filename(media: MediaContext) -> str:
    return "%s.id.srt" % media.stem


def _video_sidecar_path(media: MediaContext) -> str:
    return os.path.join(os.path.dirname(media.path), _canonical_filename(media))


def _candidate_output_path(media: MediaContext) -> str:
    filename = _canonical_filename(media)
    if setting_bool("save_next_to_video", True):
        video_dir = os.path.dirname(media.path)
        if video_dir and not video_dir.lower().startswith(("plugin://", "pvr://", "http://", "https://")):
            return os.path.join(video_dir, filename)
    cache_name = "%s-%s" % (media_key(media), filename)
    return os.path.join(CACHE_DIR, safe_filename(cache_name))


def _delete_quietly(path: str) -> None:
    if not path:
        return
    try:
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
    except Exception as exc:
        log("cannot remove obsolete subtitle sidecar %s: %s" % (path, exc), LOG_WARNING)


def _backup_original_once(media: MediaContext, destination: str) -> str:
    if not xbmcvfs.exists(destination):
        return ""
    xbmcvfs.mkdirs(ORIGINAL_BACKUP_DIR)
    backup = os.path.join(ORIGINAL_BACKUP_DIR, "%s.id.original.srt" % media_key(media))
    if xbmcvfs.exists(backup):
        return backup
    try:
        write_bytes(backup, read_bytes(destination))
        log("original Indonesian sidecar backed up: %s" % backup, LOG_INFO)
        return backup
    except Exception as exc:
        log("cannot back up original Indonesian sidecar %s: %s" % (destination, exc), LOG_WARNING)
        return ""


def _is_plain_local_path(path: str) -> bool:
    lower = (path or "").lower()
    return bool(path) and "://" not in lower and not lower.startswith("special://")


def _subtitle_bytes(srt_text: str) -> bytes:
    text = str(srt_text or '').replace('\r\n', '\n').replace('\r', '\n')
    if text and not text.endswith('\n'):
        text += '\n'
    return text.encode('utf-8')


def _file_sha256(path: str) -> str:
    return hashlib.sha256(read_bytes(path)).hexdigest() if xbmcvfs.exists(path) else ''


def _write_canonical_sidecar(media: MediaContext, destination: str, srt_text: str) -> None:
    temp = destination + '.autosync.tmp'
    rollback = destination + '.autosync.rollback'
    payload = _subtitle_bytes(srt_text)
    expected = hashlib.sha256(payload).hexdigest()
    _delete_quietly(temp)
    _delete_quietly(rollback)
    write_bytes(temp, payload)
    if not xbmcvfs.exists(temp) or _file_sha256(temp) != expected:
        _delete_quietly(temp)
        raise RuntimeError('temporary subtitle verification failed')

    _backup_original_once(media, destination)
    had_destination = xbmcvfs.exists(destination)
    if had_destination:
        if not xbmcvfs.copy(destination, rollback):
            _delete_quietly(temp)
            raise RuntimeError('could not create rollback subtitle')

    try:
        if _is_plain_local_path(destination):
            os.replace(temp, destination)
        else:
            if had_destination and not xbmcvfs.delete(destination):
                raise RuntimeError('could not replace existing subtitle')
            if not xbmcvfs.rename(temp, destination):
                raise RuntimeError('could not rename temporary subtitle')
        if not xbmcvfs.exists(destination) or _file_sha256(destination) != expected:
            raise RuntimeError('canonical subtitle verification failed')
        _delete_quietly(rollback)
    except Exception:
        _delete_quietly(destination)
        if xbmcvfs.exists(rollback):
            xbmcvfs.rename(rollback, destination)
        _delete_quietly(temp)
        raise


def _legacy_configured_suffix() -> str:
    values: List[str] = []
    try:
        values.append(ADDON.getSetting("output_suffix") or "")
    except Exception:
        pass
    settings_path = os.path.join(PROFILE, "settings.xml")
    try:
        if xbmcvfs.exists(settings_path):
            root = ET.fromstring(read_text(settings_path))
            for node in root.iter("setting"):
                if node.get("id") == "output_suffix":
                    values.append(node.get("value") or (node.text or ""))
    except Exception as exc:
        log("legacy suffix setting could not be read: %s" % exc, LOG_DEBUG)
    for value in values:
        value = safe_filename(value.strip(), "") if value and value.strip() else ""
        if value and value.lower() != "id":
            return value
    return ""


def _legacy_sidecar_paths(media: MediaContext, extra_paths: Optional[List[str]] = None) -> List[str]:
    video_dir = os.path.dirname(media.path)
    paths = [
        os.path.join(video_dir, "%s.id.autosync.srt" % media.stem),
        os.path.join(video_dir, "%s.autosync.srt" % media.stem),
    ]
    suffix = _legacy_configured_suffix()
    if suffix:
        paths.append(os.path.join(video_dir, "%s.%s.srt" % (media.stem, suffix)))
    for path in extra_paths or []:
        if not path:
            continue
        try:
            same_dir = os.path.normcase(os.path.dirname(path)) == os.path.normcase(video_dir)
            matching_name = os.path.basename(path).lower().startswith(media.stem.lower() + ".")
            if same_dir and matching_name and path.lower().endswith(".srt"):
                paths.append(path)
        except Exception:
            continue
    return list(dict.fromkeys(paths))


def _remove_legacy_sidecars(media: MediaContext, keep: str, extra_paths: Optional[List[str]] = None) -> None:
    keep_norm = os.path.normcase(keep)
    for path in _legacy_sidecar_paths(media, extra_paths):
        if os.path.normcase(path) != keep_norm:
            _delete_quietly(path)


def save_output(media: MediaContext, srt_text: str, legacy_paths: Optional[List[str]] = None) -> str:
    preferred = _candidate_output_path(media)
    try:
        _write_canonical_sidecar(media, preferred, srt_text)
        if os.path.normcase(os.path.dirname(preferred)) == os.path.normcase(os.path.dirname(media.path)):
            _remove_legacy_sidecars(media, preferred, legacy_paths)
        return preferred
    except Exception as exc:
        log("cannot save beside video, falling back to profile: %s" % exc, LOG_WARNING)
    fallback = os.path.join(CACHE_DIR, "%s.id.srt" % media_key(media))
    _write_canonical_sidecar(media, fallback, srt_text)
    return fallback


def migrate_legacy_sidecars() -> Dict[str, int]:
    result = {"migrated": 0, "failed": 0, "skipped": 0}
    if not setting_bool("save_next_to_video", True):
        result["skipped"] += 1
        return result
    if xbmcvfs.exists(CANONICAL_SIDECAR_MIGRATION):
        return result
    xbmcvfs.mkdirs(MIGRATION_DIR)
    # Seed manifests for local movies/episodes so legacy files are migrated even
    # when an earlier AutoSync run never wrote a manifest.
    try:
        request = {'jsonrpc':'2.0','id':1,'method':'VideoLibrary.GetEpisodes',
                   'params':{'properties':['file','title','season','episode','imdbnumber']}}
        response = json.loads(xbmc.executeJSONRPC(json.dumps(request)))
        for item in ((response.get('result') or {}).get('episodes') or []):
            video_path = str(item.get('file') or '')
            if not video_path or '://' in video_path:
                continue
            media = MediaContext(path=video_path, title=str(item.get('title') or ''),
                                 imdb_id=str(item.get('imdbnumber') or ''), is_episode=True,
                                 season=int(item.get('season') or 0), episode=int(item.get('episode') or 0))
            legacy = next((p for p in _legacy_sidecar_paths(media) if xbmcvfs.exists(p)), '')
            if legacy:
                save_manifest(media, legacy, {'sidecar_output_path': legacy, 'migration_seed': True})
    except Exception as exc:
        log('library sidecar migration seed failed: %s' % exc, LOG_WARNING)
    _, files = _listdir(MANIFEST_DIR)
    for filename in files:
        if not filename.lower().endswith(".json"):
            continue
        manifest_file = os.path.join(MANIFEST_DIR, filename)
        try:
            payload = json.loads(read_text(manifest_file))
            video_path = str(payload.get("video_path") or "")
            if not video_path or video_path.lower().startswith(("plugin://", "pvr://", "http://", "https://")):
                result["skipped"] += 1
                continue
            media = MediaContext(
                path=video_path,
                title=os.path.splitext(os.path.basename(video_path))[0],
                imdb_id=str(payload.get("imdb_id") or ""),
                is_episode=bool(int(payload.get("season") or 0) or int(payload.get("episode") or 0)),
                season=int(payload.get("season") or 0),
                episode=int(payload.get("episode") or 0),
            )
            canonical = _video_sidecar_path(media)
            recorded = str(payload.get("sidecar_output_path") or "")
            candidates = []
            if recorded:
                candidates.append(recorded)
            candidates.extend(_legacy_sidecar_paths(media))
            source = next(
                (path for path in candidates if path and os.path.normcase(path) != os.path.normcase(canonical) and xbmcvfs.exists(path)),
                "",
            )
            if not source:
                result["skipped"] += 1
                continue
            _write_canonical_sidecar(media, canonical, read_text(source))
            _remove_legacy_sidecars(media, canonical, candidates)
            payload["sidecar_output_path"] = canonical
            write_text(manifest_file, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
            session_file = os.path.join(PROFILE_SESSION_DIR, os.path.splitext(filename)[0] + ".json")
            if xbmcvfs.exists(session_file):
                session = json.loads(read_text(session_file))
                session["sidecar_output_path"] = canonical
                write_text(session_file, json.dumps(session, ensure_ascii=False, indent=2, sort_keys=True))
            result["migrated"] += 1
        except Exception as exc:
            result["failed"] += 1
            log("legacy subtitle sidecar migration failed file=%s error=%s" % (filename, exc), LOG_WARNING)
    if result["failed"] == 0:
        write_text(CANONICAL_SIDECAR_MIGRATION, json.dumps(result, sort_keys=True))
    log("legacy subtitle sidecar migration result=%s" % result, LOG_INFO)
    return result


def save_profile_variant(media: MediaContext, profile_index: int, srt_text: str) -> str:
    directory = os.path.join(PROFILE_VARIANT_DIR, media_key(media))
    xbmcvfs.mkdirs(directory)
    path = os.path.join(directory, "profile-%02d.id.srt" % int(profile_index))
    write_text(path, srt_text)
    return path

# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import socket
from dataclasses import dataclass
from typing import Any, Dict, List, Optional, Tuple
from urllib.error import HTTPError, URLError
from urllib.parse import urlencode
from urllib.request import Request, urlopen

from .common import (
    LOG_DEBUG,
    MediaContext,
    SubtitleCandidate,
    log,
    norm_tokens,
)
from .subtitle_io import looks_like_subtitle
from .zip_select import parse_season_episode, select_zip_member

BASE_URL = "https://api.subsource.net/api/v1"
USER_AGENT = "SubSource-AutoSync-Kodi/0.1.24"
MAX_DOWNLOAD_BYTES = 30 * 1024 * 1024


class SubSourceError(RuntimeError):
    pass


@dataclass
class DownloadedSubtitle:
    filename: str
    payload: bytes
    container: str
    selection_reason: str = ""


class SubSourceClient:
    def __init__(self, api_key: str, timeout: int = 30):
        self.api_key = (api_key or "").strip()
        self.timeout = timeout
        if not self.api_key:
            raise SubSourceError("SubSource API key is empty")

    def _request(self, path: str, params: Optional[Dict[str, Any]] = None, binary: bool = False) -> Any:
        url = BASE_URL + path
        if params:
            url += "?" + urlencode(params)
        request = Request(
            url,
            headers={"X-API-Key": self.api_key, "User-Agent": USER_AGENT, "Accept": "*/*"},
            method="GET",
        )
        try:
            with urlopen(request, timeout=self.timeout) as response:
                if binary:
                    chunks = []
                    total = 0
                    while True:
                        chunk = response.read(128 * 1024)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > MAX_DOWNLOAD_BYTES:
                            raise SubSourceError("subtitle download exceeds size limit")
                        chunks.append(chunk)
                    return b"".join(chunks)
                payload = response.read().decode("utf-8", "replace")
                return json.loads(payload)
        except HTTPError as exc:
            detail = ""
            try:
                detail = exc.read().decode("utf-8", "replace")[:500]
            except Exception:
                pass
            raise SubSourceError("SubSource HTTP %s: %s" % (exc.code, detail or exc.reason))
        except (URLError, socket.timeout) as exc:
            raise SubSourceError("SubSource network error: %s" % exc)
        except ValueError as exc:
            raise SubSourceError("SubSource returned invalid JSON: %s" % exc)

    @staticmethod
    def _data(response: Any) -> List[Dict[str, Any]]:
        if not isinstance(response, dict):
            return []
        if response.get("success") is False or "error" in response:
            raise SubSourceError(str(response.get("message") or response.get("error") or "SubSource request failed"))
        data = response.get("data", [])
        return data if isinstance(data, list) else []

    @staticmethod
    def _int_or_none(value: Any) -> Optional[int]:
        try:
            return int(value)
        except Exception:
            return None

    @staticmethod
    def _float_or_zero(value: Any) -> float:
        try:
            return float(value)
        except Exception:
            return 0.0

    @staticmethod
    def _row_title(row: Dict[str, Any]) -> str:
        for key in ("title", "name", "movieName", "fullName"):
            value = row.get(key)
            if value:
                return str(value)
        return ""

    @staticmethod
    def _normalized_key(value: str) -> str:
        return "".join(ch for ch in str(value).lower() if ch.isalnum())

    @classmethod
    def _find_number(cls, value: Any, wanted_keys: Tuple[str, ...], depth: int = 0) -> Optional[float]:
        if depth > 3:
            return None
        wanted = {cls._normalized_key(key) for key in wanted_keys}
        if isinstance(value, dict):
            for key, child in value.items():
                if cls._normalized_key(key) in wanted:
                    try:
                        return float(child)
                    except Exception:
                        pass
            for child in value.values():
                if isinstance(child, (dict, list)):
                    found = cls._find_number(child, wanted_keys, depth + 1)
                    if found is not None:
                        return found
        elif isinstance(value, list):
            for child in value:
                found = cls._find_number(child, wanted_keys, depth + 1)
                if found is not None:
                    return found
        return None

    @classmethod
    def _parse_rating(cls, row: Dict[str, Any]) -> Tuple[float, int]:
        rating_obj = row.get("rating")
        rating = 0.0
        votes = 0
        if isinstance(rating_obj, dict):
            raw_rating = cls._find_number(
                rating_obj,
                ("value", "average", "avg", "score", "rating", "total"),
            )
            raw_votes = cls._find_number(
                rating_obj,
                ("votes", "voteCount", "count", "users", "userCount", "ratedBy", "totalVotes"),
            )
            rating = float(raw_rating or 0.0)
            votes = max(0, int(raw_votes or 0))
        elif rating_obj is not None:
            rating = cls._float_or_zero(rating_obj)

        # Keep only a plausible 0-10 average. If the API ever returns a sum,
        # normalize it when an exposed vote count makes that unambiguous.
        if rating > 10.0 and votes > 0 and rating / votes <= 10.0:
            rating = rating / votes
        if rating < 0.0 or rating > 10.0:
            rating = 0.0
        return rating, votes

    @classmethod
    def _parse_owner(cls, row: Dict[str, Any]) -> str:
        wanted = {"owner", "uploader", "username", "user", "author", "contributor", "uploadedby", "userdisplayname"}

        def walk(value: Any, depth: int = 0) -> str:
            if depth > 4:
                return ""
            if isinstance(value, dict):
                for key, child in value.items():
                    normalized = cls._normalized_key(key)
                    if normalized in wanted:
                        if isinstance(child, str) and child.strip():
                            return child.strip()
                        if isinstance(child, dict):
                            for name_key in ("name", "username", "displayName", "title"):
                                name = child.get(name_key)
                                if isinstance(name, str) and name.strip():
                                    return name.strip()
                for child in value.values():
                    if isinstance(child, (dict, list)):
                        found = walk(child, depth + 1)
                        if found:
                            return found
            elif isinstance(value, list):
                for child in value:
                    found = walk(child, depth + 1)
                    if found:
                        return found
            return ""

        return walk(row)

    @classmethod
    def _parse_download_count(cls, row: Dict[str, Any]) -> int:
        value = cls._find_number(
            row,
            (
                "downloads",
                "downloadCount",
                "downloadsCount",
                "downloaded",
                "totalDownloads",
                "downloadTotal",
            ),
        )
        return max(0, int(value or 0))

    def _select_search_row(self, rows: List[Dict[str, Any]], media: MediaContext) -> Optional[Dict[str, Any]]:
        if not rows:
            return None
        if media.is_episode:
            season_rows = [row for row in rows if self._int_or_none(row.get("season")) == media.season]
            if not season_rows:
                return None
            wanted_title = set(norm_tokens(media.show_title))
            wanted_imdb = (media.imdb_id or "").lower()

            def score(row: Dict[str, Any]) -> float:
                value = 0.0
                row_imdb = str(row.get("imdbId") or "").lower()
                if wanted_imdb and row_imdb == wanted_imdb:
                    value += 100.0
                row_title = set(norm_tokens(self._row_title(row)))
                if wanted_title and row_title:
                    value += 40.0 * (len(wanted_title & row_title) / float(len(wanted_title | row_title)))
                row_year = self._int_or_none(row.get("year"))
                if media.show_year and row_year == media.show_year:
                    value += 15.0
                return value

            return max(season_rows, key=score)

        wanted_imdb = (media.imdb_id or "").lower()
        for row in rows:
            row_imdb = str(row.get("imdbId") or "").lower()
            if wanted_imdb and row_imdb == wanted_imdb:
                return row
        return rows[0]

    def resolve_movie_id(self, media: MediaContext) -> str:
        searches: List[Tuple[str, Dict[str, Any]]] = []
        if media.imdb_id:
            searches.append(("imdb", {"searchType": "imdb", "imdb": media.imdb_id}))

        if media.is_episode and media.show_title:
            params: Dict[str, Any] = {
                "searchType": "text",
                "q": media.show_title,
                "type": "tvseries",
            }
            if media.show_year:
                params["year"] = media.show_year
            searches.append(("text", params))
        elif not media.imdb_id and media.title:
            params = {"searchType": "text", "q": media.title, "type": "movie"}
            if media.year:
                params["year"] = media.year
            searches.append(("text", params))

        if not searches:
            raise SubSourceError("IMDb/title identity is missing from Kodi metadata")

        available_seasons = set()
        for strategy, params in searches:
            response = self._request("/movies/search", params)
            rows = self._data(response)
            for row in rows:
                season = self._int_or_none(row.get("season"))
                if season is not None:
                    available_seasons.add(season)
            selected = self._select_search_row(rows, media)
            if not selected:
                continue
            movie_id = selected.get("movieId")
            if movie_id is None:
                continue
            log(
                "SubSource identity resolved via %s: movieId=%s season=%s"
                % (strategy, movie_id, selected.get("season")),
                LOG_DEBUG,
            )
            return str(movie_id)

        if media.is_episode:
            seasons = ", ".join(str(value) for value in sorted(available_seasons)) or "none"
            raise SubSourceError(
                "SubSource has no matching %s season %s entry (available seasons: %s)"
                % (media.show_title or media.imdb_id or "series", media.season, seasons)
            )
        raise SubSourceError("IMDb %s was not found on SubSource" % (media.imdb_id or media.title))

    def list_subtitles(self, movie_id: str, language: str) -> List[SubtitleCandidate]:
        response = self._request(
            "/subtitles",
            {"movieId": movie_id, "language": language},
        )
        rows = self._data(response)
        result: List[SubtitleCandidate] = []
        for row in rows:
            subtitle_id = row.get("subtitleId")
            if subtitle_id is None:
                continue
            release_info = row.get("releaseInfo") or ""
            if isinstance(release_info, list):
                release_info = " | ".join(str(part) for part in release_info if part)
            rating, votes = self._parse_rating(row)
            downloads = self._parse_download_count(row)
            result.append(
                SubtitleCandidate(
                    subtitle_id=str(subtitle_id),
                    language=str(row.get("language") or language),
                    release_info=str(release_info),
                    rating=rating,
                    rating_votes=votes,
                    download_count=downloads,
                    hearing_impaired=bool(row.get("hearingImpaired")),
                    link=str(row.get("link") or ""),
                    raw=row,
                    owner=self._parse_owner(row),
                )
            )
        return result

    def download(self, candidate: SubtitleCandidate) -> bytes:
        subtitle_id = candidate.subtitle_id
        if candidate.link:
            tail = candidate.link.rstrip("/").split("/")[-1]
            if tail:
                subtitle_id = tail
        return self._request("/subtitles/%s/download" % subtitle_id, binary=True)

    def download_and_select(self, candidate: SubtitleCandidate, media: MediaContext) -> DownloadedSubtitle:
        payload = self.download(candidate)
        if payload.startswith(b"PK\x03\x04") or payload.startswith(b"PK\x05\x06") or payload.startswith(b"PK\x07\x08"):
            selection = select_zip_member(payload, media, candidate)
            return DownloadedSubtitle(
                filename=selection.filename,
                payload=selection.payload,
                container="zip",
                selection_reason=selection.selection_reason,
            )
        if looks_like_subtitle(payload):
            if media.is_episode:
                season, episode = parse_season_episode(candidate.release_info)
                if season != media.season or episode != media.episode:
                    raise SubSourceError(
                        "direct subtitle text does not prove requested %s" % media.episode_tag
                    )
            filename = candidate.release_info or (media.episode_tag if media.is_episode else media.stem)
            if not os.path.splitext(filename)[1]:
                filename += ".srt"
            return DownloadedSubtitle(
                filename=filename,
                payload=payload,
                container="text",
                selection_reason="direct exact subtitle text",
            )
        raise SubSourceError("download is neither a supported ZIP nor a subtitle text file")

# SubSource AutoSync

## Automatic flow

1. Reuse a proven movie/season source when available, then parse and clean the selected episode member.
2. Extract embedded Indonesian text, remove ads/credits, render a cleaned external SRT, and apply it.
3. When usable embedded/local English text exists for the same video, clean it as a reference, synchronize ranked Indonesian candidates, and prepare F3/R1 profiles.
4. When no trusted English text exists, clean the top Indonesian candidates while retaining their original timing and cycle them with F3/R1.
5. PGS/SUP, VobSub, DVB and other image subtitles are ignored. Online English is never selected automatically.

## Manual flow

- Selecting Indonesian keeps its original timing, removes ads/credits, and records its metadata.
- Selecting English keeps its original timing, removes ads/credits, and applies it for visual verification. Hold R1 or press Shift+F3 to confirm it, synchronize Indonesian candidates, and test the results. Hold again on the correct Indonesian result to save it for the season.

## Controls

- F3 or controller R1: next profile.
- Shift+F3 or hold R1 for 800 ms: confirm/save.
- Settings > Tools > Export diagnostics ZIP.

A stable profile can also be learned after the configured playback duration.


## Local subtitle priority (0.1.16)
The add-on scans matching text subtitles beside the video and in `Subs`/`Subtitles`. Embedded/local Indonesian text is used directly. Embedded/local English text is a trusted reference. A learned one-profile season fast path stays quick, but pressing F3/R1 expands it into fresh Indonesian alternatives.


### Indonesian candidate order
- Movie results use one deterministic order for manual search and automatic profiles: rated results first, then trusted Indonesian subtitle makers, then latest uploads, then download count.
- Trusted makers are detected from Owner, Release Name, and Caption: IDFL, Pein Akatsuki, Sebuah Dongeng, Lebah Ganteng, Ibra Official, Toon21, and Fathur.
- TV episodes validate season/episode identity, group candidates by release family, and automatically keep one best BluRay, WEB-DL, WEBRip, HDTV, DVD, Remux, SubRip, and Other result.
- Source, codec, resolution, streaming-service, and edition matching are not used for clean movie filenames such as `Title [Year].mkv`.

## Automatic playback gate
- Background AutoSync runs only for Kodi-library movies and episodes by default.
- Standalone local clips are ignored silently; manual subtitle search is still available.
- Indonesian content is skipped when the current audio, Kodi country metadata, or configured path keywords identify it as Indonesian.


## ZIP archive selection

Episode member selection uses an a4kSubtitles-compatible parser for common and loose naming styles, including `SxxExx`, `7x03`, `S7 eps 01`, episode ranges, and final standalone episode numbers. Multi-file archives retain an extra safety guard: when the requested episode cannot be proven, the add-on reports an ambiguous archive instead of silently installing the first file.

## Always-on ad and credit cleaning (0.1.20)

Every parsed text subtitle passes through the same cleaner, including automatic and manual SubSource downloads, local sidecars, embedded MKV text, RAW profiles, synchronized profiles, and reused season sources. There is no user setting and no background folder polling.

The cleaner removes known subtitle/ad domains, gambling and commercial cards, donation/contact promotions, translator/uploader/resync credits, and progressive animated watermarks. It never removes closed-caption brackets or HTML/ASS styling tags as a formatting operation, and it never changes cue timing. Detection uses a tag-stripped copy while surviving text keeps its original tags.

Rules are stored in `resources/data/cleanup_rules.txt`, loaded once into memory, and organized as domains, credit phrases, promotional phrases, gambling phrases, signatures, contact hints, and allow-listed official title phrases. A database is not used. Diagnostics exports include cleanup events, removed-text samples, and the exact rules file.
## Canonical Indonesian sidecar

When storage beside the video is enabled, the active Indonesian result is always written as `<video>.id.srt`. The former configurable `.id.autosync.srt` suffix is no longer used. Internal F3 alternatives and the first overwritten original are kept under the add-on profile.


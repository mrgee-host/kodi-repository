## 0.1.31

- Added strict movie source-family blocks: all BluRay results first, then Remux, WEB-DL, WEBRip, HDTV, DVD, HDRip, SubRip, and Other.
- Existing rating, trusted-maker, latest, and download ranking now applies only inside the same movie source family.
- Manual movie results and automatic movie profiles keep the same order.
- TV episode one-best-per-family behavior is unchanged.

## 0.1.30

- Subtitle search results now use Kodi's native subtitle metadata contract: Indonesian/English ISO language thumbnails for flags and a 0-5 icon rating for filled stars.
- Replaced release-name scoring with community-first ranking for clean movie filenames: rated results, trusted Indonesian subtitle makers, latest upload, then download count.
- Trusted-source detection reads Owner, Release Name, and Caption and recognizes IDFL, Pein Akatsuki, Sebuah Dongeng, Lebah Ganteng, Ibra Official, Toon21, and Fathur.
- Movie automatic profile downloads preserve the same ordering shown in manual search.
- TV episode automatic downloads keep only one best result per release family while retaining season/episode validation.
- Existing subtitle cleaning, immutable profile application, stream verification, F3 cycling, season preference, diagnostics, and Kodi 22 fixes remain intact.

## 0.1.29

- Kodi-confirmed subtitle activation for automatic, F3, and manual OSD flows.
- Immutable profile apply, delayed canonical sidecar commit, and expanded diagnostics.

# Changelog

## 0.1.28

- Fresh-install baseline.
- Writes canonical `<video>.id.srt` sidecars directly with atomic replacement.
- Removes startup sidecar renaming, manifest-key conversion, runtime-layout movement, and keymap-version conversion.
- Keeps current F3 alternatives, subtitle cleanup, Kodi 22 JSON-RPC compatibility, diagnostics, and session behavior.

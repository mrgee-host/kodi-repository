SubSource AutoSync 0.1.30

Manual result metadata
- thumb=id/en for Kodi language flags
- icon=SubSource rating converted from 0-10 to Kodi 0-5 stars

Movie order
1. Rated results: rating, votes, trusted maker, latest, downloads
2. Unrated trusted makers: latest, downloads
3. Remaining results: latest, downloads

Trusted makers are detected from Owner, Release Name, and Caption:
IDFL; Pein Akatsuki; Sebuah Dongeng; Lebah Ganteng; Ibra Official; Toon21; Fathur.

TV automatic candidates
- season/episode validation remains active
- one best candidate per release family
- each family winner uses the same community ranking

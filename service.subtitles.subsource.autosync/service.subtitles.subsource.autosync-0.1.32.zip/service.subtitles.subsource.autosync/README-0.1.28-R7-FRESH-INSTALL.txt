SubSource AutoSync 0.1.28 - R7 Fresh-Install Baseline

- Writes the canonical <video>.id.srt sidecar directly.
- Does not scan or rename old .id.autosync sidecars, old manifest keys, old runtime
  layouts, or old keymap versions.
- Keeps current subtitle matching, ad/credit cleanup, sync profiles, F3 controls,
  atomic sidecar replacement, diagnostics, and Kodi 22 compatibility.
- Uses the new Smart Subtitle icon supplied for the MrGee family.

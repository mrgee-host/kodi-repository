SubSource AutoSync 0.1.31

Movie results now use strict source-family blocks:
1. BluRay / BDRip / BRRip / UHD BluRay
2. Remux
3. WEB-DL
4. WEBRip
5. HDTV
6. DVD
7. HDRip
8. SubRip
9. Other

All candidates in the current family are exhausted before the next family.
Inside each family the existing order remains: rated, rating, votes, trusted maker, latest, downloads.
Manual movie results and automatic movie profile-00, profile-01, and onward use the same order.
TV series behavior is unchanged: season/episode validation and one best candidate per release family.

SubSource AutoSync 0.1.29

Kodi must confirm a real subtitle stream before the add-on marks a profile active.
Manual OSD download is returned to Kodi without a second self-apply.
Canonical <video>.id.srt is committed only after successful activation.

# Third-party notices

The archive season/episode parsing strategy in `resources/lib/zip_select.py`
was adapted from **a4kSubtitles**, copyright its contributors, distributed
under the MIT License:

https://github.com/a4k-openproject/a4kSubtitles

Permission is hereby granted, free of charge, to any person obtaining a copy of
this software and associated documentation files (the "Software"), to deal in
the Software without restriction, including without limitation the rights to
use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of
the Software, and to permit persons to whom the Software is furnished to do so,
subject to inclusion of the original copyright and permission notice.

# -*- coding: utf-8 -*-
from __future__ import annotations

import hashlib
import json
import os
import re
from typing import Any, Dict, List, Optional, Tuple

import xbmcvfs

from .common import (
    ADDON,
    CACHE_DIR,
    MANIFEST_DIR,
    PROFILE_VARIANT_DIR,
    LOG_DEBUG,
    LOG_WARNING,
    MediaContext,
    log,
    read_text,
    safe_filename,
    setting_bool,
    write_text,
)
from .kodi_runtime import stat_signature

SUB_EXTENSIONS = (".srt", ".ass", ".ssa", ".vtt", ".sub", ".smi")
REFERENCE_POLICY = "always_clean_ads_credits_v6"


def media_key(media: MediaContext) -> str:
    raw = "%s|%s|%s|%s" % (media.path, media.imdb_id, media.season, media.episode)
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()


def manifest_path(media: MediaContext) -> str:
    return os.path.join(MANIFEST_DIR, media_key(media) + ".json")


def load_manifest(media: MediaContext) -> Optional[Dict[str, Any]]:
    path = manifest_path(media)
    if not xbmcvfs.exists(path):
        return None
    try:
        payload = json.loads(read_text(path))
    except Exception as exc:
        log("manifest read failed: %s" % exc, LOG_WARNING)
        return None
    if payload.get("video_path") != media.path or payload.get("imdb_id") != media.imdb_id:
        return None
    # Invalidate results made by the former PGS/SUP reference experiments.
    if payload.get("reference_policy") != REFERENCE_POLICY:
        return None
    current = stat_signature(media.path)
    saved = payload.get("video_signature") or {}
    if saved.get("size") and current.get("size") and int(saved["size"]) != int(current["size"]):
        return None
    if saved.get("mtime") and current.get("mtime") and int(saved["mtime"]) != int(current["mtime"]):
        return None
    output = payload.get("output_path") or ""
    if not output or not xbmcvfs.exists(output):
        return None
    return payload


def save_manifest(media: MediaContext, output_path: str, details: Dict[str, Any]) -> str:
    payload = {
        "version": 1,
        "video_path": media.path,
        "video_signature": stat_signature(media.path),
        "imdb_id": media.imdb_id,
        "season": media.season,
        "episode": media.episode,
        "output_path": output_path,
        "reference_policy": REFERENCE_POLICY,
    }
    payload.update(details)
    path = manifest_path(media)
    write_text(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
    return path


def _listdir(path: str) -> Tuple[List[str], List[str]]:
    # xbmcvfs.listdir logs an ERROR before raising when a directory is absent.
    # Check first so optional Subs/Subtitles folders stay silent.
    try:
        if not path or not xbmcvfs.exists(path):
            return [], []
        dirs, files = xbmcvfs.listdir(path)
        return list(dirs), list(files)
    except Exception:
        return [], []


def _normalised_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (value or "").lower())


def _subtitle_matches_video(media: MediaContext, filename: str) -> bool:
    lower = filename.lower()
    if not lower.endswith(SUB_EXTENSIONS):
        return False
    if ".autosync." in lower:
        return False

    base = os.path.splitext(filename)[0]
    stem_norm = _normalised_name(media.stem)
    base_norm = _normalised_name(base)
    if not stem_norm or not base_norm:
        return False
    if base_norm.startswith(stem_norm) or stem_norm.startswith(base_norm):
        return True

    # Renamed episode files and release-named sidecars often share only the
    # show title plus SxxExx. Require both to avoid grabbing another episode's
    # subtitle from the same season folder.
    if media.is_episode and media.episode_tag:
        episode_norm = _normalised_name(media.episode_tag)
        if episode_norm and episode_norm in base_norm:
            show_tokens = [token for token in re.split(r"[^a-z0-9]+", (media.show_title or media.title).lower()) if len(token) >= 3]
            if not show_tokens:
                return True
            hits = sum(1 for token in show_tokens if token in base.lower())
            return hits >= max(1, min(2, len(show_tokens)))
    return False


def find_local_subtitles(media: MediaContext) -> List[str]:
    """Return every readable text-subtitle candidate belonging to this video.

    The same folder is scanned first, followed by conventional Subs and
    Subtitles subfolders. Generated AutoSync outputs are excluded so stale
    results can never be fed back as fresh input.
    """
    video_dir = os.path.dirname(media.path)
    candidates: List[str] = []
    search_dirs = [video_dir, os.path.join(video_dir, "Subs"), os.path.join(video_dir, "Subtitles")]
    for directory in search_dirs:
        _, files = _listdir(directory)
        for filename in files:
            if _subtitle_matches_video(media, filename):
                candidates.append(os.path.join(directory, filename))
    return list(dict.fromkeys(candidates))


def _is_indonesian_name(stem: str, filename: str) -> bool:
    lower = filename.lower()
    if not lower.endswith(SUB_EXTENSIONS):
        return False
    base = os.path.splitext(lower)[0]
    stem_lower = stem.lower()
    if not (base.startswith(stem_lower) or stem_lower.startswith(base.split(".")[0])):
        return False
    tokens = re.split(r"[. _\-\[\]()]+", base)
    return any(token in ("id", "ind", "indo", "indonesia", "indonesian", "bahasa", "bahasaindonesia") for token in tokens)


def find_local_indonesian(media: MediaContext) -> List[str]:
    # Backward-compatible filename-only helper. Runtime classification in
    # local_scan.py also inspects subtitle text when the filename is untagged.
    return [path for path in find_local_subtitles(media) if _is_indonesian_name(media.stem, os.path.basename(path))]


def _candidate_output_path(media: MediaContext) -> str:
    suffix = safe_filename(ADDON.getSetting("output_suffix") or "id.autosync", "id.autosync")
    filename = "%s.%s.srt" % (media.stem, suffix)
    if setting_bool("save_next_to_video", True):
        video_dir = os.path.dirname(media.path)
        if video_dir and not video_dir.lower().startswith(("plugin://", "pvr://", "http://", "https://")):
            return os.path.join(video_dir, filename)
    cache_name = "%s-%s" % (media_key(media), filename)
    return os.path.join(CACHE_DIR, safe_filename(cache_name))


def save_output(media: MediaContext, srt_text: str) -> str:
    preferred = _candidate_output_path(media)
    try:
        write_text(preferred, srt_text)
        if xbmcvfs.exists(preferred):
            return preferred
    except Exception as exc:
        log("cannot save beside video, falling back to profile: %s" % exc, LOG_WARNING)
    fallback = os.path.join(CACHE_DIR, "%s.id.autosync.srt" % media_key(media))
    write_text(fallback, srt_text)
    return fallback


def save_profile_variant(media: MediaContext, profile_index: int, srt_text: str) -> str:
    directory = os.path.join(PROFILE_VARIANT_DIR, media_key(media))
    xbmcvfs.mkdirs(directory)
    path = os.path.join(directory, "profile-%02d.srt" % int(profile_index))
    write_text(path, srt_text)
    return path

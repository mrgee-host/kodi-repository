# -*- coding: utf-8 -*-
from __future__ import annotations

import math
import re
from typing import Iterable, List, Set

from .common import MediaContext, SubtitleCandidate, norm_tokens
from .zip_select import parse_season_episode, parse_season_only

SOURCE_GROUPS = {
    "web": {"web", "webdl", "webrip", "webcap"},
    "bluray": {"bluray", "bdrip", "brrip", "bdremux", "remux", "uhdbluray", "uhd"},
    "hdtv": {"hdtv", "pdtv"},
    "dvd": {"dvd", "dvdrip", "dvd5", "dvd9"},
}
CODEC_GROUPS = {
    "h264": {"x264", "h264", "avc", "264"},
    "h265": {"x265", "h265", "hevc", "265"},
    "av1": {"av1"},
}
SERVICE_TOKENS = {"nf", "netflix", "amzn", "amazon", "dsnp", "disney", "hmax", "max", "atvp", "apple", "hulu", "pcok", "paramount"}
EDITION_TOKENS = {"extended", "theatrical", "directors", "director", "cut", "imax", "remastered", "uncut", "redux"}
RESOLUTION_TOKENS = {"720p", "1080p", "2160p", "4k"}
NOISE = {"subtitle", "subtitles", "sub", "subs", "indonesian", "english", "srt", "ass", "ssa", "complete", "season", "episode"}


def _group(tokens: Set[str], groups) -> str:
    for name, values in groups.items():
        if tokens & values:
            return name
    return ""


def _rating_bonus(candidate: SubtitleCandidate) -> float:
    rating = max(0.0, min(10.0, float(candidate.rating or 0.0)))
    votes = max(0, int(candidate.rating_votes or 0))
    if rating <= 0:
        return 0.0
    if votes > 0:
        trust = min(1.0, math.log10(votes + 1.0) / 1.5)
        return 8.0 * (rating / 10.0) * trust
    # A score with no exposed vote count is weak evidence, not zero evidence.
    return 2.0 * (rating / 10.0)


def _download_bonus(candidate: SubtitleCandidate) -> float:
    downloads = max(0, int(candidate.download_count or 0))
    if downloads <= 0:
        return 0.0
    # Logarithmic on purpose: 10k downloads should not bulldoze a better release.
    return min(6.0, 1.5 * math.log10(downloads + 1.0))



RELEASE_FAMILY_ORDER = ("webdl", "webrip", "bluray", "dvd", "hdtv", "remux", "subrip", "other")

def release_family(value: str) -> str:
    tokens = set(norm_tokens(value))
    compact = re.sub(r"[^a-z0-9]+", "", (value or "").lower())
    if "subrip" in compact or ({"sub", "rip"} <= tokens):
        return "subrip"
    if tokens & {"remux", "bdremux"}:
        return "remux"
    if tokens & {"webdl", "web-dl"}:
        return "webdl"
    if tokens & {"webrip", "webcap", "web"}:
        return "webrip"
    if tokens & {"bluray", "bdrip", "brrip", "uhdbluray", "uhd"}:
        return "bluray"
    if tokens & {"dvd", "dvdrip", "dvd5", "dvd9"}:
        return "dvd"
    if tokens & {"hdtv", "pdtv"}:
        return "hdtv"
    return "other"

def release_similarity(left: str, right: str) -> float:
    a = set(norm_tokens(left)) - NOISE
    b = set(norm_tokens(right)) - NOISE
    if not a or not b:
        return 0.0
    return len(a & b) / float(len(a | b))


def score_candidate(candidate: SubtitleCandidate, media: MediaContext, prefer_non_sdh: bool = True) -> float:
    media_tokens = set(norm_tokens(media.filename)) - NOISE
    release_tokens = set(norm_tokens(candidate.release_info)) - NOISE
    score = 0.0

    # IMDb already constrains the title. For episodes, exact episode releases
    # come first, then verified matching-season packs, then unknown names.
    if media.is_episode:
        season, episode = parse_season_episode(candidate.release_info)
        season_only = parse_season_only(candidate.release_info)
        if season == media.season and episode == media.episode:
            score += 48.0
        elif season_only == media.season and episode is None:
            score += 30.0
        elif season is not None and episode is not None:
            score -= 250.0
        elif season_only is not None and season_only != media.season:
            score -= 180.0

    overlap = media_tokens & release_tokens
    score += min(35.0, 2.5 * len(overlap))

    media_source = _group(media_tokens, SOURCE_GROUPS)
    release_source = _group(release_tokens, SOURCE_GROUPS)
    if media_source and release_source:
        score += 22 if media_source == release_source else -18

    media_codec = _group(media_tokens, CODEC_GROUPS)
    release_codec = _group(release_tokens, CODEC_GROUPS)
    if media_codec and release_codec:
        score += 8 if media_codec == release_codec else -4

    media_res = media_tokens & RESOLUTION_TOKENS
    release_res = release_tokens & RESOLUTION_TOKENS
    if media_res and release_res:
        score += 8 if media_res & release_res else -5

    media_service = media_tokens & SERVICE_TOKENS
    release_service = release_tokens & SERVICE_TOKENS
    if media_service and release_service:
        score += 10 if media_service & release_service else -6

    media_edition = media_tokens & EDITION_TOKENS
    release_edition = release_tokens & EDITION_TOKENS
    if media_edition or release_edition:
        if media_edition and release_edition and media_edition & release_edition:
            score += 18
        elif media_edition != release_edition:
            score -= 35

    candidate.popularity_score = _rating_bonus(candidate) + _download_bonus(candidate)
    score += candidate.popularity_score

    if prefer_non_sdh and candidate.hearing_impaired:
        score -= 7
    if any(token in release_tokens for token in ("forced", "foreign", "commentary")):
        score -= 150
    return score


def rank_candidates(candidates: Iterable[SubtitleCandidate], media: MediaContext, prefer_non_sdh: bool = True) -> List[SubtitleCandidate]:
    ranked = list(candidates)
    for candidate in ranked:
        candidate.score = score_candidate(candidate, media, prefer_non_sdh)
    ranked.sort(
        key=lambda item: (
            item.score,
            item.download_count,
            item.rating_votes,
            item.rating,
        ),
        reverse=True,
    )
    return ranked



def arrange_candidates_for_auto(
    candidates: Iterable[SubtitleCandidate],
    media: MediaContext,
    mode: str = "ranked",
    preferred_id: str = "",
) -> List[SubtitleCandidate]:
    """Arrange already-ranked Indonesian candidates for automatic download.

    ranked: preserve the global score/filter order.
    family: round-robin across release families, preferring a saved target
    family and the source family inferred from the video filename.
    """
    ranked = list(candidates)
    if (mode or "ranked").strip().lower() != "family" or len(ranked) <= 1:
        return ranked

    grouped = {family: [] for family in RELEASE_FAMILY_ORDER}
    for candidate in ranked:
        grouped.setdefault(release_family(candidate.release_info), []).append(candidate)

    family_order: List[str] = []

    def add_family(family: str) -> None:
        if family and grouped.get(family) and family not in family_order:
            family_order.append(family)

    if preferred_id:
        preferred = next((item for item in ranked if str(item.subtitle_id) == str(preferred_id)), None)
        if preferred is not None:
            add_family(release_family(preferred.release_info))

    media_family = release_family(media.filename)
    if media_family != "other":
        add_family(media_family)
    for family in RELEASE_FAMILY_ORDER:
        add_family(family)
    for family in grouped:
        add_family(family)

    arranged: List[SubtitleCandidate] = []
    indexes = {family: 0 for family in family_order}
    while len(arranged) < len(ranked):
        advanced = False
        for family in family_order:
            index = indexes[family]
            items = grouped.get(family) or []
            if index >= len(items):
                continue
            arranged.append(items[index])
            indexes[family] = index + 1
            advanced = True
        if not advanced:
            break
    return arranged

def infer_release_owner(release: str, fallback: str = "") -> str:
    """Best-effort release-group label used only for compact UI text."""
    text = " ".join((release or "").split())
    if not text:
        return fallback
    patterns = (
        r"(?i)\bby[ .:_-]+([A-Za-z0-9][A-Za-z0-9._-]{1,30})\b",
        r"(?i)\buntuk[ .:_-]+([A-Za-z0-9][A-Za-z0-9._-]{1,30})\b",
        r"(?i)\b(pahe\.in)\b",
    )
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(1).strip(" ._-:/")
    # Scene/release groups often trail a hyphen after codec/source metadata.
    tail = re.search(r"-([A-Za-z][A-Za-z0-9._]{2,24})(?:\s*(?:\||$))", text)
    if tail:
        token = tail.group(1).strip(" ._-")
        if token.lower() not in {"web", "webdl", "webrip", "bluray", "hdtv", "dvdrip", "complete"}:
            return token
    return fallback


def candidate_owner(candidate: SubtitleCandidate, fallback_prefix: str = "ID") -> str:
    owner = (getattr(candidate, "owner", "") or "").strip()
    if owner:
        return owner
    fallback = "%s %s" % (fallback_prefix, candidate.subtitle_id) if candidate.subtitle_id else fallback_prefix
    return infer_release_owner(candidate.release_info, fallback)

# -*- coding: utf-8 -*-
from __future__ import annotations

import io
import os
import re
import zipfile
from dataclasses import dataclass
from typing import Dict, List, Optional, Sequence, Tuple

from .common import MediaContext, SubtitleCandidate, norm_tokens

# The archive parser and numeric episode fallback intentionally follow the
# battle-tested a4kSubtitles approach (MIT licensed), with stricter guards added
# here so a multi-file archive can never silently fall back to the wrong episode.
SUPPORTED_EXTENSIONS = (".srt", ".sub", ".smi", ".ssa", ".aqt", ".jss", ".ass", ".rt", ".vtt")
MAX_MEMBER_SIZE = 12 * 1024 * 1024
MAX_ARCHIVE_MEMBERS = 5000
ZIP_UTF8_FLAG = 0x800
TECHNICAL_NUMBERS = {264, 265, 480, 576, 720, 1080, 2160}


@dataclass
class ZipSelection:
    filename: str
    payload: bytes
    exact_episode: bool = False
    selection_reason: str = ""


@dataclass(frozen=True)
class ArchiveEpisodeMeta:
    season: Optional[int]
    episode: Optional[int]
    episodes_range: Tuple[int, ...] = ()
    used_fallback: bool = False


def _safe_int(value: object) -> Optional[int]:
    try:
        number = int(str(value).lstrip("0") or "0")
    except Exception:
        return None
    return number if 0 <= number < 100000 else None


def extract_season_episode_a4k(value: str, episode_fallback: bool = False) -> ArchiveEpisodeMeta:
    """Parse season/episode using the same broad strategy as a4kSubtitles.

    The parser recognizes explicit E/EP/Episode and S/Season markers, common
    Sxx-Exx variants, episode ranges, then optionally falls back to the final
    standalone numeric token. Dates are removed before parsing.
    """
    filename = (value or "").lower().replace("\\", "/")
    episode_pattern = r"(?:e|ep.?|episode.?)(\d{1,5})(?:v\d?)?"
    season_pattern = r"(?:s|season.?)(\d{1,5})"
    combined_pattern = r"\b(?:s|season)(\d{1,5})\s?[x|\-|\_|\s]\s?[a-z]?(\d{1,5})(?:v\d?)?\b"
    range_pattern = r"\b(?:.{1,4}e|ep|eps|episodes|\s)?(\d{1,5}?)(?:v.?)?\s?[\-|\~]\s?(\d{1,5})(?:v.?)?\b"
    date_pattern = r"\b(\d{2,4}-\d{1,2}-\d{2,4})\b"

    filename = re.sub(date_pattern, "", filename)
    season_match = re.search(season_pattern, filename, re.IGNORECASE)
    episode_match = re.search(episode_pattern, filename, re.IGNORECASE)
    combined_match = re.search(combined_pattern, filename, re.IGNORECASE)
    # Keep a4k's parser as the base, then cover two widespread forms that its
    # current combined regex does not parse directly: 7x03 and S7 - 03.
    bare_x_match = re.search(r"(?<!\d)0*(\d{1,3})\s*x\s*0*(\d{1,3})(?!\d)", filename, re.IGNORECASE)
    loose_season_episode = re.search(
        r"(?<![a-z0-9])s(?:eason)?[ ._\-]*0*(\d{1,3})[ ._\-]+(?:e|ep|eps|episode|episodes)?[ ._\-]*0*(\d{1,3})(?!\d)",
        filename,
        re.IGNORECASE,
    )
    range_matches = re.findall(range_pattern, filename, re.IGNORECASE)

    season_raw = season_match.group(1) if season_match else None
    episode_raw = episode_match.group(1) if episode_match else None
    if combined_match:
        season_raw = season_raw or combined_match.group(1)
        episode_raw = episode_raw or combined_match.group(2)
    if bare_x_match:
        season_raw = season_raw or bare_x_match.group(1)
        episode_raw = episode_raw or bare_x_match.group(2)
    if loose_season_episode:
        season_raw = season_raw or loose_season_episode.group(1)
        episode_raw = episode_raw or loose_season_episode.group(2)

    episodes_range: Tuple[int, ...] = ()
    if range_matches:
        start, end = map(int, range_matches[-1])
        if 0 < start <= end < 1000:
            # Inclusive here. It is only diagnostic/selection metadata.
            episodes_range = tuple(range(start, end + 1))

    used_fallback = False
    if episode_fallback and not episode_raw:
        fallback_pattern = re.compile(r"\bE?P?(\d{1,5})v?\d?\b", re.IGNORECASE)
        normalized = re.sub(
            r"[\s\.\:\;\(\)\[\]\{\}\\/\&\'\`\#\@\=\$\?\!\%\+\-\_\*\^]",
            " ",
            filename,
        )
        fallback_matches = fallback_pattern.findall(normalized)
        plausible: List[str] = []
        for raw in fallback_matches:
            number = _safe_int(raw)
            if number is None or number <= 0 or number >= 1000:
                continue
            if number in TECHNICAL_NUMBERS or 1900 <= number <= 2099:
                continue
            plausible.append(raw)
        if plausible:
            episode_raw = plausible[-1]
            used_fallback = True

    season = _safe_int(season_raw) if season_raw else None
    episode = _safe_int(episode_raw) if episode_raw else None
    if season is not None and not (0 <= season < 1000):
        season = None
    if episode is not None and not (0 < episode < 1000):
        episode = None
    return ArchiveEpisodeMeta(season, episode, episodes_range, used_fallback)


def parse_season_episode(value: str) -> Tuple[Optional[int], Optional[int]]:
    """Strict public parser used for API release metadata and direct text."""
    text = (value or "").lower().replace("\\", "/")
    patterns = (
        r"(?<![a-z0-9])s(?:eason)?[ ._\-]*0*(\d{1,3})[ ._\-]*(?:e|ep|eps|episode|episodes)[ ._\-]*0*(\d{1,3})(?!\d)",
        r"(?<!\d)0*(\d{1,3})x0*(\d{1,3})(?!\d)",
        r"season[ ._\-]*0*(\d{1,3})[ ._\-]*(?:episode|episodes|eps|ep|e)[ ._\-]*0*(\d{1,3})(?!\d)",
    )
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            return int(match.group(1)), int(match.group(2))
    meta = extract_season_episode_a4k(text, episode_fallback=False)
    return meta.season, meta.episode


def parse_season_only(value: str) -> Optional[int]:
    season, _episode = parse_season_episode(value)
    if season is not None:
        return season
    text = (value or "").lower().replace("\\", "/")
    patterns = (
        r"(?<![a-z0-9])s[ ._\-]*0*(\d{1,3})(?![a-z0-9])",
        r"(?<![a-z0-9])season[ ._\-]*0*(\d{1,3})(?!\d)",
        r"(?<![a-z0-9])complete[ ._\-]*season[ ._\-]*0*(\d{1,3})(?!\d)",
    )
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            number = int(match.group(1))
            if 0 <= number < 1000:
                return number
    return None


def parse_episode_only(value: str) -> Optional[int]:
    text = os.path.basename((value or "").lower())
    patterns = (
        r"(?<![a-z0-9])(?:episode|episodes|eps|ep|e)[ ._\-]*0*(\d{1,3})(?!\d)",
        r"^(?:episode[ ._\-]*)?0*(\d{1,3})(?:\.[a-z0-9]+)?$",
    )
    for pattern in patterns:
        match = re.search(pattern, text, re.IGNORECASE)
        if match:
            number = int(match.group(1))
            if 0 < number < 1000 and number not in TECHNICAL_NUMBERS:
                return number
    return None


def parse_episode_numeric_fallback(value: str) -> Optional[int]:
    return extract_season_episode_a4k(value, episode_fallback=True).episode


def is_matching_season_pack(release_info: str, season: int) -> bool:
    parsed = parse_season_only(release_info)
    if parsed != season:
        return False
    lower = (release_info or "").lower()
    tokens = set(norm_tokens(release_info))
    return bool(
        "season" in tokens
        or "complete" in tokens
        or "pack" in tokens
        or re.search(r"\b0?1[ ._\-]*(?:to|through|thru|\-)[ ._\-]*\d{1,2}\b", lower)
        or re.search(r"\bepisodes?\b", lower)
        or re.search(r"\beps?\b", lower)
        or re.search(r"(?<![a-z0-9])s[ ._\-]*0*%d(?![a-z0-9])" % season, lower)
    )


def _decoded_zip_name(info: zipfile.ZipInfo) -> str:
    """Mirror a4k's cp437-to-UTF8 fallback for legacy ZIP filename flags."""
    name = (info.filename or "").replace("\\", "/")
    if info.flag_bits & ZIP_UTF8_FLAG:
        return name
    try:
        return name.encode("cp437").decode("utf-8").replace("\\", "/")
    except (UnicodeEncodeError, UnicodeDecodeError):
        return name


def _extension_score(name: str) -> int:
    ext = os.path.splitext(name.lower())[1]
    priorities = {
        ".srt": 30, ".ass": 24, ".ssa": 20, ".vtt": 18,
        ".smi": 14, ".sub": 12, ".aqt": 10, ".jss": 9, ".rt": 8,
    }
    return priorities.get(ext, 0)


def _name_score(name: str, media: MediaContext, candidate: SubtitleCandidate) -> float:
    lower = name.lower()
    score = float(_extension_score(name))
    if any(token in lower for token in ("forced", "foreign", "signs", "songs", "commentary")):
        score -= 200
    if candidate.hearing_impaired and any(token in lower for token in ("sdh", "hi", "hearing")):
        score += 3
    media_tokens = set(norm_tokens(media.filename))
    release_tokens = set(norm_tokens(candidate.release_info))
    member_tokens = set(norm_tokens(name))
    score += 2.0 * len(member_tokens & media_tokens)
    score += 1.0 * len(member_tokens & release_tokens)
    return score


def _eligible_infos(archive: zipfile.ZipFile) -> List[zipfile.ZipInfo]:
    infos = archive.infolist()
    if len(infos) > MAX_ARCHIVE_MEMBERS:
        raise ValueError("ZIP has too many members")
    result: List[zipfile.ZipInfo] = []
    for info in infos:
        name = _decoded_zip_name(info)
        if info.is_dir() or not name.lower().endswith(SUPPORTED_EXTENSIONS):
            continue
        if info.file_size <= 0 or info.file_size > MAX_MEMBER_SIZE:
            continue
        result.append(info)
    return result


def _verified_episode_sequence(infos: Sequence[zipfile.ZipInfo]) -> Dict[int, List[zipfile.ZipInfo]]:
    """Verify a multi-file archive's a4k-style episode numbering sequence."""
    mapping: Dict[int, List[zipfile.ZipInfo]] = {}
    parsed_members = 0
    for info in infos:
        meta = extract_season_episode_a4k(_decoded_zip_name(info), episode_fallback=True)
        if meta.episode is not None:
            parsed_members += 1
            mapping.setdefault(meta.episode, []).append(info)

    if len(mapping) < 3:
        return {}
    if parsed_members < max(3, int(len(infos) * 0.60)):
        return {}
    ordered = sorted(mapping)
    if ordered[0] <= 0 or ordered[-1] > 99:
        return {}
    span = ordered[-1] - ordered[0] + 1
    if span > max(30, len(ordered) * 3):
        return {}
    if float(len(ordered)) / float(span) < 0.55:
        return {}
    return mapping


def _archive_seasons(infos: Sequence[zipfile.ZipInfo]) -> set:
    seasons = set()
    for info in infos:
        meta = extract_season_episode_a4k(_decoded_zip_name(info), episode_fallback=False)
        if meta.season is not None:
            seasons.add(meta.season)
    return seasons


def _sort_matches(
    infos: Sequence[zipfile.ZipInfo], media: MediaContext, candidate: SubtitleCandidate
) -> List[zipfile.ZipInfo]:
    return sorted(infos, key=lambda item: _name_score(_decoded_zip_name(item), media, candidate), reverse=True)


def _available_episode_summary(infos: Sequence[zipfile.ZipInfo]) -> str:
    available = []
    for info in infos:
        meta = extract_season_episode_a4k(_decoded_zip_name(info), episode_fallback=True)
        if meta.season is not None and meta.episode is not None:
            available.append("S%02dE%02d" % (meta.season, meta.episode))
        elif meta.episode is not None:
            available.append("E%02d" % meta.episode)
    return ", ".join(sorted(set(available))[:30])


def select_zip_member(payload: bytes, media: MediaContext, candidate: SubtitleCandidate) -> ZipSelection:
    try:
        archive = zipfile.ZipFile(io.BytesIO(payload), "r")
    except (zipfile.BadZipFile, OSError) as exc:
        raise ValueError("downloaded archive is not a readable ZIP: %s" % exc)

    with archive:
        infos = _eligible_infos(archive)
        if not infos:
            raise ValueError("ZIP contains no supported subtitle text files")

        selected: Optional[zipfile.ZipInfo] = None
        exact_episode = False
        reason = ""

        if media.is_episode:
            sequence = _verified_episode_sequence(infos)
            seasons = _archive_seasons(infos)
            release_season, release_episode = parse_season_episode(candidate.release_info)

            strong_matches: List[zipfile.ZipInfo] = []
            seasonless_matches: List[zipfile.ZipInfo] = []
            for info in infos:
                meta = extract_season_episode_a4k(_decoded_zip_name(info), episode_fallback=True)
                if meta.episode != media.episode:
                    continue
                if meta.season == media.season:
                    strong_matches.append(info)
                elif meta.season is None:
                    seasonless_matches.append(info)

            if strong_matches:
                selected = _sort_matches(strong_matches, media, candidate)[0]
                exact_episode = True
                selected_meta = extract_season_episode_a4k(_decoded_zip_name(selected), episode_fallback=True)
                reason = (
                    "a4k-compatible exact S%02dE%02d member%s"
                    % (media.season, media.episode, " using numeric fallback" if selected_meta.used_fallback else "")
                )
            elif seasonless_matches:
                # Accept episode-only names only when the archive itself proves a
                # sequence, the API release proves the season, or it is one file.
                archive_proves_season = (
                    (len(seasons) == 1 and media.season in seasons)
                    or media.episode in sequence
                    or release_season == media.season
                    or len(infos) == 1
                )
                if archive_proves_season:
                    selected = _sort_matches(seasonless_matches, media, candidate)[0]
                    exact_episode = True
                    reason = "a4k-compatible episode match inside verified archive"

            if selected is None and media.episode in sequence:
                # This is the safe equivalent of a4k's final numeric fallback.
                # It does not depend on the API release title saying "Season".
                selected = _sort_matches(sequence[media.episode], media, candidate)[0]
                exact_episode = True
                reason = "a4k-compatible numeric episode in verified archive sequence"

            if selected is None and len(infos) == 1:
                single = infos[0]
                meta = extract_season_episode_a4k(_decoded_zip_name(single), episode_fallback=True)
                conflicting_member = (
                    (meta.season is not None and meta.season != media.season)
                    or (meta.episode is not None and meta.episode != media.episode)
                )
                conflicting_release = (
                    (release_season is not None and release_season != media.season)
                    or (release_episode is not None and release_episode != media.episode)
                )
                if not conflicting_member and not conflicting_release:
                    selected = single
                    exact_episode = bool(meta.episode == media.episode or release_episode == media.episode)
                    reason = "single subtitle member fallback with no conflicting episode"

            if selected is None:
                available = _available_episode_summary(infos)
                suffix = " Available: %s" % available if available else ""
                raise ValueError(
                    "ZIP downloaded and contains %d subtitle file(s), but %s could not be selected.%s"
                    % (len(infos), media.episode_tag, suffix)
                )
        else:
            selected = _sort_matches(infos, media, candidate)[0]
            reason = "highest-ranked movie subtitle member"

        member_name = _decoded_zip_name(selected)
        member_payload = archive.read(selected)
        if len(member_payload) > MAX_MEMBER_SIZE:
            raise ValueError("selected ZIP member is too large")
        return ZipSelection(
            member_name,
            member_payload,
            exact_episode=exact_episode,
            selection_reason=reason,
        )

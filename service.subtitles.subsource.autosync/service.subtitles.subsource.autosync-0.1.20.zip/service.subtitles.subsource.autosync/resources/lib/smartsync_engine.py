# -*- coding: utf-8 -*-
from __future__ import annotations

import bisect
import math
from typing import Iterable, List, Sequence, Set, Tuple

from .common import Cue, SyncResult, percentile


def _usable(cues: Iterable[Cue]) -> List[Cue]:
    result = []
    for cue in cues:
        normalized = cue.normalized()
        if normalized.end_ms <= normalized.start_ms:
            continue
        result.append(normalized)
    return sorted(result, key=lambda item: (item.start_ms, item.end_ms))


def _occupancy(cues: Sequence[Cue], bin_ms: int, start_ms: int = 0, end_ms: int = 0) -> Set[int]:
    occupied: Set[int] = set()
    for cue in cues:
        if end_ms and cue.start_ms > end_ms:
            break
        if cue.end_ms < start_ms:
            continue
        left = max(cue.start_ms, start_ms) if start_ms else cue.start_ms
        right = min(cue.end_ms, end_ms) if end_ms else cue.end_ms
        if right <= left:
            continue
        first = int(left // bin_ms)
        last = int(max(left, right - 1) // bin_ms)
        # Long decorative or malformed events should not dominate correlation.
        if last - first > 120:
            last = first + 120
        occupied.update(range(first, last + 1))
    return occupied


def _shift_score(target_bins: Set[int], reference_bins: Set[int], shift_bins: int) -> float:
    if not target_bins or not reference_bins:
        return 0.0
    hits = sum(1 for value in target_bins if value + shift_bins in reference_bins)
    precision = hits / float(len(target_bins))
    recall = hits / float(len(reference_bins))
    if precision + recall <= 0:
        return 0.0
    return 2.0 * precision * recall / (precision + recall)


def _best_shift(target_bins: Set[int], reference_bins: Set[int], low: int, high: int) -> Tuple[int, float]:
    best_shift = low
    best_score = -1.0
    for shift in range(low, high + 1):
        score = _shift_score(target_bins, reference_bins, shift)
        if score > best_score:
            best_shift, best_score = shift, score
    return best_shift, max(0.0, best_score)


def estimate_global_offset(target: Sequence[Cue], reference: Sequence[Cue], max_offset_ms: int = 600000) -> Tuple[int, float]:
    coarse_bin = 1000
    target_coarse = _occupancy(target, coarse_bin)
    reference_coarse = _occupancy(reference, coarse_bin)
    max_bins = int(max_offset_ms // coarse_bin)
    coarse_shift, coarse_score = _best_shift(target_coarse, reference_coarse, -max_bins, max_bins)

    fine_bin = 100
    target_fine = _occupancy(target, fine_bin)
    reference_fine = _occupancy(reference, fine_bin)
    center = coarse_shift * (coarse_bin // fine_bin)
    fine_shift, fine_score = _best_shift(target_fine, reference_fine, center - 15, center + 15)
    return int(fine_shift * fine_bin), max(coarse_score, fine_score)


def _window_shift(
    target: Sequence[Cue],
    reference_bins: Set[int],
    center_ms: int,
    global_offset_ms: int,
    bin_ms: int = 250,
    window_ms: int = 360000,
    local_range_ms: int = 30000,
) -> Tuple[int, float]:
    left = max(0, center_ms - window_ms // 2)
    right = center_ms + window_ms // 2
    target_bins = _occupancy(target, bin_ms, left, right)
    if len(target_bins) < 12:
        return global_offset_ms, 0.0
    base = int(round(global_offset_ms / float(bin_ms)))
    radius = int(local_range_ms // bin_ms)
    shift, score = _best_shift(target_bins, reference_bins, base - radius, base + radius)
    return int(shift * bin_ms), score


def _smooth_knots(knots: List[Tuple[int, int, float]], global_offset_ms: int) -> List[Tuple[int, int]]:
    if not knots:
        return [(0, global_offset_ms)]
    valid_indices = [idx for idx, item in enumerate(knots) if item[2] >= 0.12]
    filled_offsets: List[int] = []
    for idx, (_, offset, score) in enumerate(knots):
        if score >= 0.12:
            filled_offsets.append(offset)
            continue
        if not valid_indices:
            filled_offsets.append(global_offset_ms)
            continue
        left = max((v for v in valid_indices if v < idx), default=None)
        right = min((v for v in valid_indices if v > idx), default=None)
        if left is not None and right is not None:
            left_t, left_o, _ = knots[left]
            right_t, right_o, _ = knots[right]
            ratio = (knots[idx][0] - left_t) / float(max(1, right_t - left_t))
            filled_offsets.append(int(round(left_o + (right_o - left_o) * ratio)))
        elif left is not None:
            filled_offsets.append(knots[left][1])
        elif right is not None:
            filled_offsets.append(knots[right][1])
        else:
            filled_offsets.append(global_offset_ms)

    smoothed: List[Tuple[int, int]] = []
    for idx, (time_ms, _, _) in enumerate(knots):
        neighborhood = filled_offsets[max(0, idx - 1) : min(len(filled_offsets), idx + 2)]
        median = int(percentile(neighborhood, 0.5))
        # Prevent a single weak window from bending the whole timeline wildly.
        median = max(global_offset_ms - 30000, min(global_offset_ms + 30000, median))
        smoothed.append((time_ms, median))
    if smoothed[0][0] > 0:
        smoothed.insert(0, (0, smoothed[0][1]))
    return smoothed


def build_knots(target: Sequence[Cue], reference: Sequence[Cue], global_offset_ms: int) -> List[Tuple[int, int]]:
    duration = max(target[-1].end_ms if target else 0, reference[-1].end_ms if reference else 0)
    if duration <= 0:
        return [(0, global_offset_ms)]
    bin_ms = 250
    reference_bins = _occupancy(reference, bin_ms)
    step_ms = 180000
    centers = list(range(0, duration + step_ms, step_ms))
    raw: List[Tuple[int, int, float]] = []
    for center in centers:
        shift, score = _window_shift(target, reference_bins, center, global_offset_ms, bin_ms=bin_ms)
        raw.append((center, shift, score))
    return _smooth_knots(raw, global_offset_ms)


def _offset_at(time_ms: int, knots: Sequence[Tuple[int, int]]) -> int:
    if not knots:
        return 0
    if time_ms <= knots[0][0]:
        return knots[0][1]
    if time_ms >= knots[-1][0]:
        return knots[-1][1]
    times = [item[0] for item in knots]
    index = bisect.bisect_right(times, time_ms)
    left_t, left_o = knots[index - 1]
    right_t, right_o = knots[index]
    if right_t <= left_t:
        return left_o
    ratio = (time_ms - left_t) / float(right_t - left_t)
    return int(round(left_o + (right_o - left_o) * ratio))


def apply_knots(target: Sequence[Cue], knots: Sequence[Tuple[int, int]]) -> List[Cue]:
    output: List[Cue] = []
    previous_start = -1
    for cue in target:
        middle = (cue.start_ms + cue.end_ms) // 2
        offset = _offset_at(middle, knots)
        start = max(0, cue.start_ms + offset)
        end = max(start + 80, cue.end_ms + offset)
        if previous_start >= 0 and start < previous_start:
            delta = previous_start - start
            start += delta
            end += delta
        output.append(Cue(start, end, cue.text))
        previous_start = start
    return output


def evaluate_sync(synced: Sequence[Cue], reference: Sequence[Cue], knots: Sequence[Tuple[int, int]]) -> Tuple[float, float, float, float]:
    if not synced or not reference:
        return 0.0, 999999.0, 999999.0, 0.0
    bin_ms = 250
    target_bins = _occupancy(synced, bin_ms)
    reference_bins = _occupancy(reference, bin_ms)
    intersection = len(target_bins & reference_bins)
    overlap = (2.0 * intersection / float(len(target_bins) + len(reference_bins))) if target_bins and reference_bins else 0.0

    ref_starts = [cue.start_ms for cue in reference]
    errors: List[float] = []
    matches = 0
    for cue in synced:
        pos = bisect.bisect_left(ref_starts, cue.start_ms)
        nearest = []
        if pos < len(ref_starts):
            nearest.append(abs(ref_starts[pos] - cue.start_ms))
        if pos > 0:
            nearest.append(abs(ref_starts[pos - 1] - cue.start_ms))
        if not nearest:
            continue
        error = min(nearest)
        errors.append(float(error))
        if error <= 1400:
            matches += 1
    median_error = percentile(errors, 0.5) if errors else 999999.0
    p90_error = percentile(errors, 0.9) if errors else 999999.0
    match_ratio = matches / float(len(synced)) if synced else 0.0

    error_factor = max(0.0, 1.0 - min(1.0, median_error / 2200.0))
    tail_factor = max(0.0, 1.0 - min(1.0, p90_error / 6000.0))
    confidence = 0.48 * overlap + 0.28 * match_ratio + 0.14 * error_factor + 0.10 * tail_factor

    if len(knots) > 1:
        jumps = [abs(knots[i][1] - knots[i - 1][1]) for i in range(1, len(knots))]
        large_jump_ratio = sum(1 for jump in jumps if jump > 7000) / float(len(jumps))
        confidence *= max(0.55, 1.0 - 0.45 * large_jump_ratio)
    return max(0.0, min(1.0, confidence)), median_error, p90_error, overlap


def synchronize(target_cues: Iterable[Cue], reference_cues: Iterable[Cue]) -> SyncResult:
    target = _usable(target_cues)
    reference = _usable(reference_cues)
    if len(target) < 8:
        raise ValueError("target subtitle has too few cues")
    if len(reference) < 8:
        raise ValueError("reference subtitle has too few cues")
    global_offset, _ = estimate_global_offset(target, reference)
    knots = build_knots(target, reference, global_offset)
    synced = apply_knots(target, knots)
    confidence, median_error, p90_error, overlap = evaluate_sync(synced, reference, knots)
    return SyncResult(
        cues=synced,
        confidence=confidence,
        global_offset_ms=global_offset,
        median_error_ms=median_error,
        p90_error_ms=p90_error,
        overlap_ratio=overlap,
        knots=list(knots),
    )

# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import threading
import time
from typing import Any, Dict, List

from .common import DIAGNOSTIC_DIR, LOG_INFO, LOG_WARNING, log, read_text, write_text
from .cleanup_engine import CleanupReport

_AUDIT_PATH = os.path.join(DIAGNOSTIC_DIR, "cleanup-events.json")
_LOCK = threading.Lock()
_MAX_EVENTS = 250


def _load_events() -> List[Dict[str, Any]]:
    try:
        payload = json.loads(read_text(_AUDIT_PATH))
        return payload if isinstance(payload, list) else []
    except Exception:
        return []


def record_cleanup_report(report: CleanupReport) -> None:
    if not report or not report.changed:
        return
    event = report.as_dict()
    event["timestamp"] = int(time.time())
    log(
        "subtitle cleanup source=%s cues=%d->%d deleted=%d modified=%d lines=%d reasons=%s"
        % (
            report.source,
            report.original_cues,
            report.final_cues,
            report.deleted_cues,
            report.modified_cues,
            report.removed_lines,
            sorted(report.reason_counts.items(), key=lambda item: (-item[1], item[0]))[:8],
        ),
        LOG_INFO,
    )
    try:
        with _LOCK:
            events = _load_events()
            events.append(event)
            write_text(_AUDIT_PATH, json.dumps(events[-_MAX_EVENTS:], ensure_ascii=False, indent=2, sort_keys=True))
    except Exception as exc:
        log("subtitle cleanup audit write failed: %s" % exc, LOG_WARNING)


def audit_path() -> str:
    return _AUDIT_PATH

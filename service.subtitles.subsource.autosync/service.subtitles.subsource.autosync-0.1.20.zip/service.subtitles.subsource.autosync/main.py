# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import sys

import xbmcaddon

ADDON = xbmcaddon.Addon("service.subtitles.subsource.autosync")
ADDON_PATH = ADDON.getAddonInfo("path")
if ADDON_PATH not in sys.path:
    sys.path.insert(0, ADDON_PATH)

from resources.lib.manual_service import run


if __name__ == "__main__":
    run(sys.argv)

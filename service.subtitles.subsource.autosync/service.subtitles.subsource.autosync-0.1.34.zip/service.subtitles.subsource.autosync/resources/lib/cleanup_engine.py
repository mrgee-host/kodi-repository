# -*- coding: utf-8 -*-
from __future__ import annotations

import html
import os
import re
import unicodedata
from collections import Counter
from dataclasses import dataclass, field
from typing import Dict, Iterable, List, Sequence, Tuple

_HTML_TAG_RE = re.compile(r"<[^>]*>")
_ASS_TAG_RE = re.compile(r"\{\\[^}]*\}")
_ZERO_WIDTH_RE = re.compile(r"[\u200b-\u200f\u2060\ufeff]")
_SPACE_RE = re.compile(r"\s+")
_URL_RE = re.compile(
    r"(?i)(?:https?://|www\.)[^\s<>]+|"
    r"\b[a-z0-9][a-z0-9.-]{1,100}\.(?:com|net|org|info|id|me|us|co|tv|io|biz|xyz|top|site|online|club|cc|ru|uk|de|pl|cz|sk|rs|hr|ba|mk|gr|ro|si|at|hu|ua|it|es|nl|be)(?:/[^\s<>]*)?"
)
_EMAIL_RE = re.compile(r"(?i)\b[\w.+-]+@[\w.-]+\.[a-z]{2,}\b")
_SOCIAL_HANDLE_RE = re.compile(r"(?<!\w)@[a-z0-9_\.]{3,}", re.I)
_SOCIAL_LABEL_RE = re.compile(
    r"(?i)(?<!\w)(?:ig|instagram|fb|facebook|telegram|tiktok|twitter|whatsapp)"
    r"\s*(?::|=|-|@)\s*[a-z0-9_.]{3,}"
)
_ORDERED_GAMBLING_RE = re.compile(
    r"(?i)(?<!\w)agen(?:\s+[a-z0-9]+){0,4}\s+bola(?:\s+[a-z0-9]+){0,4}\s+terpercaya(?!\w)"
)
_PHONE_RE = re.compile(r"(?<!\d)(?:\+?\d[\d\s().-]{6,}\d)(?!\d)")
_SEPARATOR_RE = re.compile(r"^[\s\-_=*#~<>|/:.]+$")
_WORD_RE = re.compile(r"[a-z0-9]+", re.I)
_TWD_SANCTUARY_RE = re.compile(r"(?i)(?<!\w)perlindungan(?!\w)")


@dataclass(frozen=True)
class CleanupRules:
    domains: Tuple[str, ...] = ()
    credits: Tuple[str, ...] = ()
    promos: Tuple[str, ...] = ()
    gambling: Tuple[str, ...] = ()
    signatures: Tuple[str, ...] = ()
    contacts: Tuple[str, ...] = ()
    allow: Tuple[str, ...] = ()


@dataclass
class CleanupReport:
    source: str = ""
    original_cues: int = 0
    final_cues: int = 0
    deleted_cues: int = 0
    modified_cues: int = 0
    removed_lines: int = 0
    reason_counts: Dict[str, int] = field(default_factory=dict)
    samples: List[Dict[str, object]] = field(default_factory=list)

    @property
    def changed(self) -> bool:
        return bool(self.deleted_cues or self.modified_cues or self.removed_lines)

    def as_dict(self) -> Dict[str, object]:
        return {
            "source": self.source,
            "original_cues": self.original_cues,
            "final_cues": self.final_cues,
            "deleted_cues": self.deleted_cues,
            "modified_cues": self.modified_cues,
            "removed_lines": self.removed_lines,
            "reason_counts": dict(sorted(self.reason_counts.items())),
            "samples": list(self.samples),
        }


_RULES_CACHE: Dict[str, Tuple[float, CleanupRules]] = {}
_PATTERN_CACHE: Dict[Tuple[Tuple[str, ...], bool, bool], object] = {}


def _rules_path() -> str:
    return os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "data", "cleanup_rules.txt"))


def load_rules(path: str = "") -> CleanupRules:
    path = path or _rules_path()
    try:
        stamp = os.path.getmtime(path)
    except OSError:
        stamp = 0.0
    cached = _RULES_CACHE.get(path)
    if cached and cached[0] == stamp:
        return cached[1]

    sections: Dict[str, List[str]] = {}
    current = ""
    try:
        with open(path, "r", encoding="utf-8-sig") as handle:
            lines = handle.readlines()
    except OSError:
        lines = []
    for raw in lines:
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.startswith("[") and line.endswith("]"):
            current = line[1:-1].strip().upper()
            sections.setdefault(current, [])
            continue
        if current:
            sections.setdefault(current, []).append(_normalise_rule(line))

    rules = CleanupRules(
        domains=tuple(_unique(sections.get("DOMAIN", []))),
        credits=tuple(_unique(sections.get("CREDIT", []))),
        promos=tuple(_unique(sections.get("PROMO", []))),
        gambling=tuple(_unique(sections.get("GAMBLING", []))),
        signatures=tuple(_unique(sections.get("SIGNATURE", []))),
        contacts=tuple(_unique(sections.get("CONTACT", []))),
        allow=tuple(_unique(sections.get("ALLOW", []))),
    )
    _RULES_CACHE[path] = (stamp, rules)
    return rules


def _unique(values: Iterable[str]) -> List[str]:
    seen = set()
    output = []
    for value in values:
        value = value.strip()
        if value and value not in seen:
            seen.add(value)
            output.append(value)
    return output


def _normalise_rule(value: str) -> str:
    return _SPACE_RE.sub(" ", unicodedata.normalize("NFKC", value).casefold()).strip()


def detection_text(value: str) -> str:
    """Create a tag-free matching copy without changing the displayed text."""
    value = html.unescape(value or "")
    value = value.replace("\\N", "\n").replace("\\n", "\n")
    value = _ASS_TAG_RE.sub("", value)
    value = _HTML_TAG_RE.sub("", value)
    value = _ZERO_WIDTH_RE.sub("", value)
    value = unicodedata.normalize("NFKC", value).casefold()
    return _SPACE_RE.sub(" ", value).strip()


def _compact(value: str) -> str:
    # Useful for domains split by styling, spaces or punctuation.
    return re.sub(r"[^a-z0-9@.]", "", value.casefold())


def _rule_pattern(values: Sequence[str], compact: bool = False, boundary: bool = False):
    key_values = tuple(values)
    key = (key_values, bool(compact), bool(boundary))
    cached = _PATTERN_CACHE.get(key)
    if cached is not None:
        return cached
    prepared = []
    for value in key_values:
        token = _compact(value) if compact else value
        if token and (not compact or len(token) >= 5):
            prepared.append(token)
    prepared = sorted(set(prepared), key=lambda item: (-len(item), item))
    if prepared:
        parts = []
        for item in prepared:
            escaped = re.escape(item)
            if boundary and not compact and item[:1].isalnum() and item[-1:].isalnum():
                escaped = r"(?<!\w)" + escaped + r"(?!\w)"
            parts.append(escaped)
        pattern = re.compile("|".join(parts), re.I)
    else:
        pattern = None
    _PATTERN_CACHE[key] = pattern
    return pattern


def _contains_rule(
    text: str,
    compact: str,
    values: Sequence[str],
    allow_compact: bool = False,
    boundary: bool = False,
) -> str:
    pattern = _rule_pattern(values, compact=False, boundary=boundary)
    if pattern is not None:
        match = pattern.search(text)
        if match:
            return match.group(0).casefold()
    if allow_compact:
        compact_pattern = _rule_pattern(values, compact=True, boundary=False)
        if compact_pattern is not None:
            match = compact_pattern.search(compact)
            if match:
                return match.group(0).casefold()
    return ""


def _domain_labels(value: str) -> Tuple[str, ...]:
    value = detection_text(value)
    value = re.sub(r"(?i)^https?://", "", value)
    value = value.split("/", 1)[0].split(":", 1)[0].strip(". ")
    labels = []
    for label in value.split("."):
        label = re.sub(r"[^a-z0-9-]", "", label.casefold())
        if not label or len(label) < 4 or label in {
            "www", "blogspot", "wordpress", "tumblr", "github", "pages",
            "com", "net", "org", "info", "online", "site", "club",
        }:
            continue
        labels.append(label)
    return tuple(labels)


def _known_domain_stems(domains: Sequence[str]) -> Tuple[str, ...]:
    stems = set()
    for domain in domains:
        stems.update(_domain_labels(domain))
    return tuple(sorted(stems, key=lambda item: (-len(item), item)))


def _domain_stem_hit(text: str, domains: Sequence[str]) -> str:
    known = set(_known_domain_stems(domains))
    if not known:
        return ""
    for candidate in _URL_RE.findall(text or ""):
        for label in _domain_labels(candidate):
            if label in known:
                return label
    return ""


def _ordered_gambling_hit(text: str) -> str:
    match = _ORDERED_GAMBLING_RE.search(text or "")
    return detection_text(match.group(0)) if match else ""


def _signature_exact_compact(signature: str, compact: str) -> bool:
    return bool(signature and compact and compact == _compact(signature))


def _mostly_machine_text(text: str) -> bool:
    words = _WORD_RE.findall(text)
    if not words:
        return True
    urlish = bool(_URL_RE.search(text) or _EMAIL_RE.search(text) or _SOCIAL_HANDLE_RE.search(text))
    if urlish and len(words) <= 16:
        return True
    punctuation = len(re.findall(r"[^\w\s]", text))
    return len(words) <= 5 and punctuation >= 2


def _natural_dialogue(text: str) -> bool:
    words = _WORD_RE.findall(text)
    if not words:
        return False
    single_letters = sum(1 for word in words if len(word) == 1)
    if single_letters >= 4 and single_letters >= len(words) * 0.35:
        return False
    if len(words) >= 10 and not (_URL_RE.search(text) or _EMAIL_RE.search(text)):
        return True
    return bool(re.search(r"[.!?…][\"'’)]?$", text.strip())) and len(words) >= 6


def _allowlisted(text: str, rules: CleanupRules) -> bool:
    if not text:
        return False
    return any(text == item or text.startswith(item + " ") for item in rules.allow)


def _media_title_key(value: str) -> str:
    value = detection_text(value or "")
    value = re.sub(r"\s*\((?:19|20)\d{2}\)\s*$", "", value).strip()
    return value


def _apply_show_replacements(text: str, media_title: str) -> Tuple[str, int]:
    # Deliberately exact: this must not affect Fear TWD or other spin-offs.
    if _media_title_key(media_title) != "the walking dead":
        return text, 0
    return _TWD_SANCTUARY_RE.subn("Sanctuary", text or "")


def _source_title(source: str) -> str:
    name = os.path.basename(source or "")
    # Peel common subtitle/profile extensions and language/output suffixes.
    for _ in range(3):
        stem, ext = os.path.splitext(name)
        if ext.lower() in (".srt", ".ass", ".ssa", ".vtt", ".sub", ".smi", ".txt"):
            name = stem
        else:
            break
    name = re.sub(r"(?i)\.(?:id|ind|indo|indonesian|en|eng|english|autosync)$", "", name)
    name = re.sub(r"(?i)\bS\d{1,2}E\d{1,3}\b|\b\d{1,2}x\d{1,3}\b", " ", name)
    name = re.sub(r"[\[(]?(?:19|20)\d{2}[\])]?$", " ", name)
    name = re.sub(r"[._-]+", " ", name)
    return detection_text(name)


def _is_source_title(text: str, source_title: str) -> bool:
    if not text or not source_title:
        return False
    clean = text.strip(" -_=*#~<>|/:.[]()")
    if clean == source_title:
        return True
    source_words = _WORD_RE.findall(source_title)
    clean_words = _WORD_RE.findall(clean)
    return bool(source_words) and clean_words == source_words


def _line_reasons(
    text: str,
    compact: str,
    rules: CleanupRules,
    near_edge: bool,
    cue_context_strong: bool,
    source_title: str = "",
) -> List[str]:
    if not text or _SEPARATOR_RE.match(text):
        return []
    if _allowlisted(text, rules) or _is_source_title(text, source_title):
        return []

    reasons: List[str] = []
    domain = _contains_rule(text, compact, rules.domains, allow_compact=True)
    domain_stem = _domain_stem_hit(text, rules.domains)
    credit = _contains_rule(text, compact, rules.credits, boundary=True)
    promo = _contains_rule(text, compact, rules.promos, boundary=True)
    gambling = _contains_rule(text, compact, rules.gambling, boundary=True)
    ordered_gambling = _ordered_gambling_hit(text)
    signature = _contains_rule(text, compact, rules.signatures, allow_compact=True)
    contact = _contains_rule(text, compact, rules.contacts, boundary=True)

    if domain:
        reasons.append("domain:%s" % domain)
    elif domain_stem:
        reasons.append("domain-stem:%s" % domain_stem)
    if credit:
        reasons.append("credit:%s" % credit)
    if promo:
        reasons.append("promo:%s" % promo)
    if gambling:
        reasons.append("gambling:%s" % gambling)
    elif ordered_gambling:
        reasons.append("gambling-ordered:%s" % ordered_gambling)

    has_url = bool(_URL_RE.search(text))
    has_email = bool(_EMAIL_RE.search(text))
    has_handle = bool(_SOCIAL_HANDLE_RE.search(text))
    has_social_label = bool(_SOCIAL_LABEL_RE.search(text))
    has_phone = bool(_PHONE_RE.search(text))

    if has_email and (credit or promo or contact or cue_context_strong or (near_edge and _mostly_machine_text(text))):
        reasons.append("contact:email")
    if has_handle and (promo or contact or cue_context_strong or near_edge):
        reasons.append("contact:social")
    if has_social_label:
        reasons.append("contact:social-label")
    if has_phone and (contact or promo or gambling or cue_context_strong):
        reasons.append("contact:phone")
    if has_url and not domain and (credit or promo or gambling or contact):
        reasons.append("url:context")
    elif has_url and not domain and near_edge and _mostly_machine_text(text) and not _natural_dialogue(text):
        reasons.append("url:edge")

    # Signatures are intentionally conservative. A name alone is removed only
    # when the cue is already proven to be promotional/credit material, or when
    # it is a short isolated title-card-like signature at the subtitle edges.
    if signature and (
        _signature_exact_compact(signature, compact)
        or ((cue_context_strong or near_edge) and len(_WORD_RE.findall(text)) <= 8)
    ) and not _natural_dialogue(text):
        reasons.append("signature:%s" % signature)

    return _unique(reasons)


def _similar_ad_animation(current: str, neighbour: str) -> bool:
    a = _compact(current)
    b = _compact(neighbour)
    if len(a) < 5 or len(b) < 5:
        return False
    if a in b or b in a:
        return min(len(a), len(b)) >= 5
    prefix = 0
    for left, right in zip(a, b):
        if left != right:
            break
        prefix += 1
    return prefix >= 8 and prefix >= int(min(len(a), len(b)) * 0.65)


def clean_cues(cues: Sequence[object], source: str = "", media_title: str = "") -> Tuple[List[object], CleanupReport]:
    """Remove only ad/watermark/translator-credit material.

    Cue timing and the original text of surviving lines are retained. Closed
    captions and styling tags are never removed as a cleanup operation.
    """
    rules = load_rules()
    source_title = _source_title(source)
    items = list(cues or [])
    report = CleanupReport(source=source or "", original_cues=len(items))
    if not items:
        return [], report

    analysed = []
    strong_flags: List[bool] = []
    count = len(items)
    edge_size = min(8, max(2, count // 50 + 2))

    for index, cue in enumerate(items):
        raw_text = str(getattr(cue, "text", "") or "")
        raw_lines = raw_text.replace("\\N", "\n").replace("\\n", "\n").split("\n")
        detection_lines = [detection_text(line) for line in raw_lines]
        cue_text = detection_text("\n".join(raw_lines))
        cue_compact = _compact(cue_text)
        near_edge = index < edge_size or index >= count - edge_size
        signature_hit = _contains_rule(cue_text, cue_compact, rules.signatures, allow_compact=True)
        strong = bool(
            _contains_rule(cue_text, cue_compact, rules.domains, allow_compact=True)
            or _domain_stem_hit(cue_text, rules.domains)
            or _contains_rule(cue_text, cue_compact, rules.credits, boundary=True)
            or _contains_rule(cue_text, cue_compact, rules.promos, boundary=True)
            or _contains_rule(cue_text, cue_compact, rules.gambling, boundary=True)
            or _ordered_gambling_hit(cue_text)
            or _SOCIAL_LABEL_RE.search(cue_text)
            or (signature_hit and (
                _signature_exact_compact(signature_hit, cue_compact)
                or (near_edge and len(_WORD_RE.findall(cue_text)) <= 14)
            ))
        )
        analysed.append((cue, raw_lines, detection_lines, cue_text, cue_compact, near_edge))
        strong_flags.append(strong)

    # Propagate through short animated watermark sequences. A cue must be very
    # close in time and textually a prefix/suffix variant of a proven junk cue.
    propagated = [False] * count
    # Iterate so a long progressive animation can be reached through a chain
    # of neighbouring prefixes instead of requiring every frame to sit within
    # two cues of the final complete credit/domain.
    for _pass in range(8):
        changed = False
        for index in range(count):
            if strong_flags[index] or propagated[index]:
                continue
            cue = items[index]
            cue_text = analysed[index][3]
            if _natural_dialogue(cue_text) or len(cue_text) > 180:
                continue
            for neighbour_index in range(max(0, index - 2), min(count, index + 3)):
                if neighbour_index == index or not (strong_flags[neighbour_index] or propagated[neighbour_index]):
                    continue
                neighbour = items[neighbour_index]
                gap = max(
                    0,
                    int(getattr(cue, "start_ms", 0)) - int(getattr(neighbour, "end_ms", 0)),
                    int(getattr(neighbour, "start_ms", 0)) - int(getattr(cue, "end_ms", 0)),
                )
                if gap <= 3500 and _similar_ad_animation(cue_text, analysed[neighbour_index][3]):
                    propagated[index] = True
                    changed = True
                    break
        if not changed:
            break

    output: List[object] = []
    reasons_counter: Counter = Counter()
    for index, (cue, raw_lines, detection_lines, cue_text, cue_compact, near_edge) in enumerate(analysed):
        cue_context_strong = strong_flags[index] or propagated[index]
        total_words = len(_WORD_RE.findall(cue_text))
        cue_reasons: List[str] = []
        if propagated[index]:
            cue_reasons.append("animation:adjacent-junk")

        for detection in detection_lines:
            cue_reasons.extend(_line_reasons(
                detection, _compact(detection), rules, near_edge, cue_context_strong, source_title
            ))
        cue_reasons = _unique(cue_reasons)

        # Advertisement/credit cards are usually short and wholly synthetic.
        # Remove the whole cue only when strong evidence exists and the cue is
        # compact. Longer mixed cues are cleaned line by line to retain dialogue.
        has_promo_card = any(reason.startswith(("promo:", "gambling:")) for reason in cue_reasons)
        has_credit_card = any(reason.startswith("credit:") for reason in cue_reasons)
        has_signature_card = any(reason.startswith("signature:") for reason in cue_reasons)
        has_edge_contact_card = any(reason.startswith(("url:edge", "contact:")) for reason in cue_reasons)
        whole_cue = bool(cue_reasons) and (
            propagated[index]
            or (has_promo_card and total_words <= 55 and not _natural_dialogue(cue_text))
            or (has_credit_card and total_words <= 35 and (near_edge or not _natural_dialogue(cue_text)))
            or (has_signature_card and near_edge and total_words <= 20)
            or (has_edge_contact_card and near_edge and total_words <= 30 and not _natural_dialogue(cue_text))
        )

        removed: List[Tuple[str, List[str]]] = []
        kept_lines: List[str] = []
        for raw_line, detection in zip(raw_lines, detection_lines):
            line_reasons = _line_reasons(
                detection,
                _compact(detection),
                rules,
                near_edge,
                cue_context_strong,
                source_title,
            )
            if whole_cue and not line_reasons:
                # Keep a known title card or an unmistakably natural dialogue
                # line even when it shares a cue with an ad/credit line.
                if _is_source_title(detection, source_title) or _allowlisted(detection, rules) or _natural_dialogue(detection):
                    kept_lines.append(raw_line)
                elif raw_line.strip():
                    removed.append((raw_line, cue_reasons))
            elif line_reasons:
                removed.append((raw_line, line_reasons))
            else:
                kept_lines.append(raw_line)

        # Trim only empty physical lines created by removal. Do not alter tags,
        # CC markers, spacing inside surviving lines, or cue timing.
        while kept_lines and not kept_lines[0].strip():
            kept_lines.pop(0)
        while kept_lines and not kept_lines[-1].strip():
            kept_lines.pop()
        new_text = "\n".join(kept_lines).strip()
        replaced_from = new_text
        new_text, replacement_count = _apply_show_replacements(new_text, media_title)
        if replacement_count:
            reasons_counter["replacement:twd-sanctuary"] += replacement_count
            if len(report.samples) < 80:
                report.samples.append({
                    "start_ms": int(getattr(cue, "start_ms", 0)),
                    "end_ms": int(getattr(cue, "end_ms", 0)),
                    "replaced": replaced_from[:500],
                    "kept": new_text[:500],
                    "reasons": ["replacement:twd-sanctuary"],
                })

        if removed:
            report.removed_lines += len(removed)
            for _line, line_reasons in removed:
                for reason in line_reasons:
                    reasons_counter[reason] += 1
            if len(report.samples) < 80:
                report.samples.append({
                    "start_ms": int(getattr(cue, "start_ms", 0)),
                    "end_ms": int(getattr(cue, "end_ms", 0)),
                    "removed": [line for line, _ in removed][:8],
                    "kept": new_text[:500],
                    "reasons": _unique([reason for _, rs in removed for reason in rs]),
                })

        if not new_text:
            if removed:
                report.deleted_cues += 1
                continue
            # Preserve pre-existing empty/whitespace cues as the renderer did.
            new_text = str(getattr(cue, "text", "") or "")

        old_text = str(getattr(cue, "text", "") or "")
        if new_text != old_text:
            report.modified_cues += 1
            try:
                output.append(type(cue)(int(getattr(cue, "start_ms")), int(getattr(cue, "end_ms")), new_text))
            except Exception:
                setattr(cue, "text", new_text)
                output.append(cue)
        else:
            output.append(cue)

    report.final_cues = len(output)
    report.reason_counts = dict(reasons_counter)
    return output, report

# -*- coding: utf-8 -*-
from __future__ import annotations

import io
import os
import struct
from typing import BinaryIO, Dict, Iterable, List, Optional, Tuple

import xbmcvfs

from .common import Cue, LOG_DEBUG, LOG_INFO, LOG_WARNING, SubtitleTrack, log
from .cleanup_engine import clean_cues
from .cleanup_audit import record_cleanup_report

# Matroska element IDs used by this lightweight timeline reader.
ID_SEGMENT = 0x18538067
ID_INFO = 0x1549A966
ID_TIMECODE_SCALE = 0x2AD7B1
ID_DURATION = 0x4489
ID_TRACKS = 0x1654AE6B
ID_TRACK_ENTRY = 0xAE
ID_TRACK_NUMBER = 0xD7
ID_TRACK_TYPE = 0x83
ID_CODEC_ID = 0x86
ID_LANGUAGE = 0x22B59C
ID_LANGUAGE_IETF = 0x22B59D
ID_TRACK_NAME = 0x536E
ID_FLAG_DEFAULT = 0x88
ID_FLAG_FORCED = 0x55AA
ID_FLAG_HEARING_IMPAIRED = 0x55AB
ID_DEFAULT_DURATION = 0x23E383
ID_CLUSTER = 0x1F43B675
ID_CLUSTER_TIMECODE = 0xE7
ID_SIMPLE_BLOCK = 0xA3
ID_BLOCK_GROUP = 0xA0
ID_BLOCK = 0xA1
ID_BLOCK_DURATION = 0x9B

TRACK_TYPE_SUBTITLE = 0x11


def is_text_subtitle_codec(codec_id: str) -> bool:
    """Return True only for subtitle codecs that carry real text cues.

    Image codecs such as PGS/SUP, VobSub and DVB subtitles are deliberately
    excluded. They are not parsed, ranked, or used as timing references.
    """
    return (codec_id or "").upper().startswith("S_TEXT")


class VFSReader:
    def __init__(self, path: str):
        self.path = path
        self.local = not path.lower().startswith(("smb://", "nfs://", "ftp://", "upnp://")) and os.path.exists(path)
        if self.local:
            self.handle = open(path, "rb")
            self._size = os.path.getsize(path)
        else:
            self.handle = xbmcvfs.File(path)
            try:
                self._size = int(self.handle.size())
            except Exception:
                self._size = 0

    def read(self, size: int) -> bytes:
        if size <= 0:
            return b""
        if self.local:
            return self.handle.read(size)
        data = self.handle.readBytes(size)
        if isinstance(data, str):
            return data.encode("latin-1", "ignore")
        return bytes(data)

    def seek(self, offset: int, whence: int = 0) -> int:
        if self.local:
            return self.handle.seek(offset, whence)
        return int(self.handle.seek(offset, whence))

    def tell(self) -> int:
        if self.local:
            return int(self.handle.tell())
        return int(self.handle.seek(0, 1))

    @property
    def size(self) -> int:
        return self._size

    def close(self) -> None:
        self.handle.close()

    def __enter__(self) -> "VFSReader":
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        self.close()


def _read_vint(reader: VFSReader, keep_marker: bool = False) -> Tuple[Optional[int], int]:
    first_raw = reader.read(1)
    if not first_raw:
        return None, 0
    first = first_raw[0]
    mask = 0x80
    length = 1
    while length <= 8 and not (first & mask):
        mask >>= 1
        length += 1
    if length > 8:
        raise ValueError("invalid EBML variable integer")
    rest = reader.read(length - 1)
    if len(rest) != length - 1:
        raise EOFError("truncated EBML variable integer")
    value = first if keep_marker else first & (mask - 1)
    for byte in rest:
        value = (value << 8) | byte
    if not keep_marker:
        unknown = (1 << (7 * length)) - 1
        if value == unknown:
            return None, length
    return value, length


def _read_header(reader: VFSReader) -> Optional[Tuple[int, Optional[int], int, Optional[int]]]:
    start = reader.tell()
    element_id, id_len = _read_vint(reader, keep_marker=True)
    if element_id is None or id_len == 0:
        return None
    size, _ = _read_vint(reader, keep_marker=False)
    data_pos = reader.tell()
    end = data_pos + size if size is not None else None
    return int(element_id), size, data_pos, end


def _read_uint(reader: VFSReader, size: int) -> int:
    payload = reader.read(size)
    if len(payload) != size:
        raise EOFError("truncated uint")
    value = 0
    for byte in payload:
        value = (value << 8) | byte
    return value


def _read_float(reader: VFSReader, size: int) -> float:
    payload = reader.read(size)
    if size == 4:
        return float(struct.unpack(">f", payload)[0])
    if size == 8:
        return float(struct.unpack(">d", payload)[0])
    return 0.0


def _read_string(reader: VFSReader, size: int) -> str:
    return reader.read(size).rstrip(b"\x00").decode("utf-8", "replace").strip()


def _skip_to(reader: VFSReader, end: Optional[int], fallback_size: Optional[int] = None) -> None:
    if end is not None:
        reader.seek(end)
    elif fallback_size:
        reader.seek(fallback_size, 1)


def _normalize_language(value: str) -> str:
    token = (value or "und").lower().replace("_", "-")
    primary = token.split("-", 1)[0]
    aliases = {
        "ind": "id", "ina": "id", "id": "id",
        "eng": "en", "en": "en",
        "spa": "es", "fre": "fr", "fra": "fr", "ger": "de", "deu": "de",
        "jpn": "ja", "kor": "ko", "chi": "zh", "zho": "zh", "ara": "ar",
    }
    return aliases.get(primary, primary or "und")


def _parse_info(reader: VFSReader, end: int) -> Tuple[int, float]:
    scale = 1000000  # nanoseconds, Matroska default
    duration_units = 0.0
    while reader.tell() < end:
        header = _read_header(reader)
        if not header:
            break
        element_id, size, _, child_end = header
        if size is None:
            break
        if element_id == ID_TIMECODE_SCALE:
            scale = _read_uint(reader, size)
        elif element_id == ID_DURATION:
            duration_units = _read_float(reader, size)
        else:
            _skip_to(reader, child_end)
    reader.seek(end)
    return scale, duration_units


def _parse_track_entry(reader: VFSReader, end: int, order: int) -> Tuple[Optional[SubtitleTrack], int]:
    values = {
        "number": 0,
        "type": 0,
        "codec": "",
        "language": "und",
        "name": "",
        "default": False,
        "forced": False,
        "hearing": False,
        "default_duration": 0,
    }
    while reader.tell() < end:
        header = _read_header(reader)
        if not header:
            break
        element_id, size, _, child_end = header
        if size is None:
            break
        if element_id == ID_TRACK_NUMBER:
            values["number"] = _read_uint(reader, size)
        elif element_id == ID_TRACK_TYPE:
            values["type"] = _read_uint(reader, size)
        elif element_id == ID_CODEC_ID:
            values["codec"] = _read_string(reader, size)
        elif element_id in (ID_LANGUAGE, ID_LANGUAGE_IETF):
            language = _read_string(reader, size)
            if language:
                values["language"] = language
        elif element_id == ID_TRACK_NAME:
            values["name"] = _read_string(reader, size)
        elif element_id == ID_FLAG_DEFAULT:
            values["default"] = bool(_read_uint(reader, size))
        elif element_id == ID_FLAG_FORCED:
            values["forced"] = bool(_read_uint(reader, size))
        elif element_id == ID_FLAG_HEARING_IMPAIRED:
            values["hearing"] = bool(_read_uint(reader, size))
        elif element_id == ID_DEFAULT_DURATION:
            values["default_duration"] = _read_uint(reader, size)
        else:
            _skip_to(reader, child_end)
    reader.seek(end)
    if values["type"] != TRACK_TYPE_SUBTITLE or not values["number"]:
        return None, int(values["default_duration"])
    track = SubtitleTrack(
        track_number=int(values["number"]),
        codec_id=str(values["codec"]),
        language=_normalize_language(str(values["language"])),
        name=str(values["name"]),
        forced=bool(values["forced"]),
        default=bool(values["default"]),
        hearing_impaired=bool(values["hearing"]),
        order=order,
    )
    return track, int(values["default_duration"])


def _parse_tracks(reader: VFSReader, end: int) -> Tuple[Dict[int, SubtitleTrack], Dict[int, int]]:
    tracks: Dict[int, SubtitleTrack] = {}
    defaults: Dict[int, int] = {}
    order = 0
    while reader.tell() < end:
        header = _read_header(reader)
        if not header:
            break
        element_id, size, _, child_end = header
        if size is None:
            break
        if element_id == ID_TRACK_ENTRY and child_end is not None:
            track, default_duration = _parse_track_entry(reader, child_end, order)
            if track:
                tracks[track.track_number] = track
                defaults[track.track_number] = default_duration
                order += 1
        else:
            _skip_to(reader, child_end)
    reader.seek(end)
    return tracks, defaults


def _parse_block_header(reader: VFSReader, size: int) -> Tuple[int, int, int, int]:
    start = reader.tell()
    track_number, track_len = _read_vint(reader, keep_marker=False)
    if track_number is None:
        raise ValueError("unknown block track")
    raw = reader.read(3)
    if len(raw) != 3:
        raise EOFError("truncated block header")
    relative = struct.unpack(">h", raw[:2])[0]
    flags = raw[2]
    consumed = reader.tell() - start
    payload_size = max(0, size - consumed)
    return int(track_number), int(relative), int(flags), int(payload_size)


def _split_laced_payload(payload: bytes, flags: int) -> List[bytes]:
    """Split common Matroska lacing modes used by Block/SimpleBlock."""
    lacing = (int(flags) & 0x06) >> 1
    if not lacing:
        return [payload]
    if not payload:
        return []
    frame_count = int(payload[0]) + 1
    data = payload[1:]
    if frame_count <= 1:
        return [data]
    if lacing == 2:  # fixed-size
        if len(data) % frame_count:
            return []
        size = len(data) // frame_count
        return [data[index * size : (index + 1) * size] for index in range(frame_count)]
    if lacing == 1:  # Xiph
        sizes: List[int] = []
        cursor = 0
        for _ in range(frame_count - 1):
            value = 0
            while cursor < len(data):
                byte = data[cursor]
                cursor += 1
                value += byte
                if byte != 255:
                    break
            else:
                return []
            sizes.append(value)
        frames: List[bytes] = []
        for size in sizes:
            if cursor + size > len(data):
                return []
            frames.append(data[cursor : cursor + size])
            cursor += size
        frames.append(data[cursor:])
        return frames
    # EBML lacing is exceptionally uncommon for text subtitle blocks. Refuse
    # it instead of decoding a wrong frame boundary and corrupting cue text.
    return []


def _decode_text_payload(track: SubtitleTrack, payload: bytes, flags: int) -> str:
    frames = _split_laced_payload(payload, flags)
    if not frames:
        return ""
    output: List[str] = []
    codec = (track.codec_id or "").upper()
    for frame in frames:
        text = frame.rstrip(b"\x00").decode("utf-8", "replace")
        text = text.replace("\r\n", "\n").replace("\r", "\n").strip()
        if not text:
            continue
        if codec in ("S_TEXT/ASS", "S_TEXT/SSA"):
            # Matroska stores ASS/SSA event payload without the Dialogue prefix:
            # ReadOrder, Layer, Style, Name, Margins, Effect, Text.
            parts = text.split(",", 8)
            if len(parts) == 9:
                text = parts[-1]
        output.append(text)
    return "\n".join(part for part in output if part).strip()


def _add_block_cue(
    tracks: Dict[int, SubtitleTrack],
    track_number: int,
    cluster_timecode: int,
    relative_timecode: int,
    scale_ns: int,
    duration_units: Optional[int],
    default_duration_ns: int,
    text: str,
) -> None:
    track = tracks.get(track_number)
    if not track or not is_text_subtitle_codec(track.codec_id) or not (text or "").strip():
        return
    start_units = cluster_timecode + relative_timecode
    start_ms = int(start_units * scale_ns / 1000000.0)
    if duration_units is not None and duration_units > 0:
        duration_ms = max(80, int(duration_units * scale_ns / 1000000.0))
    elif default_duration_ns > 0:
        duration_ms = max(80, int(default_duration_ns / 1000000.0))
    else:
        duration_ms = 2000
    track.cues.append(Cue(start_ms, start_ms + duration_ms, text))


def _parse_block_group(
    reader: VFSReader,
    end: int,
    cluster_timecode: int,
    scale_ns: int,
    tracks: Dict[int, SubtitleTrack],
    defaults: Dict[int, int],
) -> None:
    block_info: Optional[Tuple[int, int, str]] = None
    duration_units: Optional[int] = None
    while reader.tell() < end:
        header = _read_header(reader)
        if not header:
            break
        element_id, size, _, child_end = header
        if size is None:
            break
        if element_id == ID_BLOCK:
            block_start = reader.tell()
            try:
                track_number, relative, flags, payload_size = _parse_block_header(reader, size)
                track = tracks.get(track_number)
                if track and is_text_subtitle_codec(track.codec_id):
                    payload = reader.read(payload_size)
                    text = _decode_text_payload(track, payload, flags)
                else:
                    text = ""
                block_info = (track_number, relative, text)
            except Exception:
                block_info = None
            reader.seek(block_start + size)
        elif element_id == ID_BLOCK_DURATION:
            duration_units = _read_uint(reader, size)
        else:
            _skip_to(reader, child_end)
    reader.seek(end)
    if block_info:
        track_number, relative, text = block_info
        _add_block_cue(
            tracks,
            track_number,
            cluster_timecode,
            relative,
            scale_ns,
            duration_units,
            defaults.get(track_number, 0),
            text,
        )


def _parse_cluster(
    reader: VFSReader,
    end: int,
    scale_ns: int,
    tracks: Dict[int, SubtitleTrack],
    defaults: Dict[int, int],
) -> None:
    cluster_timecode = 0
    while reader.tell() < end:
        header = _read_header(reader)
        if not header:
            break
        element_id, size, data_pos, child_end = header
        if size is None:
            break
        if element_id == ID_CLUSTER_TIMECODE:
            cluster_timecode = _read_uint(reader, size)
        elif element_id == ID_SIMPLE_BLOCK:
            try:
                track_number, relative, flags, payload_size = _parse_block_header(reader, size)
                track = tracks.get(track_number)
                if track and is_text_subtitle_codec(track.codec_id):
                    payload = reader.read(payload_size)
                    text = _decode_text_payload(track, payload, flags)
                else:
                    text = ""
                _add_block_cue(
                    tracks,
                    track_number,
                    cluster_timecode,
                    relative,
                    scale_ns,
                    None,
                    defaults.get(track_number, 0),
                    text,
                )
            except Exception:
                pass
            reader.seek(data_pos + size)
        elif element_id == ID_BLOCK_GROUP and child_end is not None:
            _parse_block_group(reader, child_end, cluster_timecode, scale_ns, tracks, defaults)
        else:
            _skip_to(reader, child_end)
    reader.seek(end)


def _fix_unknown_durations(track: SubtitleTrack, media_duration_ms: int = 0) -> None:
    cues = sorted(track.cues, key=lambda cue: (cue.start_ms, cue.end_ms))
    deduped: List[Cue] = []
    seen = set()
    for cue in cues:
        key = (cue.start_ms, cue.end_ms)
        if key in seen:
            continue
        seen.add(key)
        deduped.append(cue)
    for idx, cue in enumerate(deduped):
        if cue.end_ms - cue.start_ms == 2000 and idx + 1 < len(deduped):
            next_start = deduped[idx + 1].start_ms
            if cue.start_ms + 80 < next_start < cue.start_ms + 12000:
                cue.end_ms = max(cue.start_ms + 80, next_start - 40)
        if media_duration_ms and cue.end_ms > media_duration_ms + 60000:
            cue.end_ms = min(cue.end_ms, media_duration_ms)
    track.cues = [cue.normalized() for cue in deduped if cue.start_ms >= 0]


def read_mkv_subtitle_tracks(path: str, media_duration_ms: int = 0, media_title: str = "") -> List[SubtitleTrack]:
    if os.path.splitext(path.lower())[1] not in (".mkv", ".mka", ".webm"):
        return []
    tracks: Dict[int, SubtitleTrack] = {}
    defaults: Dict[int, int] = {}
    scale_ns = 1000000
    duration_units = 0.0
    pending_clusters: List[Tuple[int, int]] = []

    try:
        with VFSReader(path) as reader:
            file_end = reader.size or (1 << 63) - 1
            segment_end = file_end
            while reader.tell() < file_end:
                header = _read_header(reader)
                if not header:
                    break
                element_id, size, _, end = header
                if element_id == ID_SEGMENT:
                    segment_end = end if end is not None else file_end
                    break
                _skip_to(reader, end, size)

            while reader.tell() < segment_end:
                header = _read_header(reader)
                if not header:
                    break
                element_id, size, data_pos, end = header
                if size is None or end is None:
                    break
                if element_id == ID_INFO:
                    scale_ns, duration_units = _parse_info(reader, end)
                elif element_id == ID_TRACKS:
                    tracks, defaults = _parse_tracks(reader, end)
                elif element_id == ID_CLUSTER:
                    if tracks:
                        _parse_cluster(reader, end, scale_ns, tracks, defaults)
                    else:
                        pending_clusters.append((data_pos, end))
                        reader.seek(end)
                else:
                    reader.seek(end)

            if tracks and pending_clusters:
                for start, end in pending_clusters:
                    reader.seek(start)
                    _parse_cluster(reader, end, scale_ns, tracks, defaults)
    except Exception as exc:
        log("Matroska subtitle timeline parse failed for %s: %s" % (path, exc), LOG_WARNING)
        return []

    detected_duration_ms = media_duration_ms
    if not detected_duration_ms and duration_units:
        detected_duration_ms = int(duration_units * scale_ns / 1000000.0)
    for track in tracks.values():
        _fix_unknown_durations(track, detected_duration_ms)
        if is_text_subtitle_codec(track.codec_id) and track.cues:
            cleaned, report = clean_cues(
                track.cues,
                source="%s#embedded-track-%s" % (path, track.track_number),
                media_title=media_title,
            )
            track.cues = list(cleaned)
            track.ads_removed = int(report.removed_lines or 0)
            record_cleanup_report(report)
    result = sorted(tracks.values(), key=lambda track: track.order)
    text_tracks = [
        "%s:%s:%s cues=%s" % (t.track_number, t.language, t.codec_id, t.cue_count)
        for t in result if is_text_subtitle_codec(t.codec_id)
    ]
    ignored_image_tracks = [
        "%s:%s:%s" % (t.track_number, t.language, t.codec_id)
        for t in result if not is_text_subtitle_codec(t.codec_id)
    ]
    log("embedded text subtitle references: %s" % text_tracks, LOG_INFO)
    if ignored_image_tracks:
        log("embedded image subtitle tracks ignored: %s" % ignored_image_tracks, LOG_INFO)
    return result


def _name_is_bad(name: str) -> bool:
    lower = (name or "").lower()
    return any(token in lower for token in ("commentary", "director", "cast", "trivia", "signs", "songs", "foreign parts", "forced"))


def is_full_dialogue_track(track: SubtitleTrack, media_duration_ms: int = 0) -> bool:
    if track.forced or _name_is_bad(track.name):
        return False
    minimum_cues = 35 if media_duration_ms and media_duration_ms < 3600000 else 70
    if track.cue_count < minimum_cues:
        return False
    if media_duration_ms > 0:
        coverage = track.coverage_ms / float(media_duration_ms)
        if coverage < 0.35:
            return False
    return True


def rank_reference_tracks(tracks: Iterable[SubtitleTrack], media_duration_ms: int = 0) -> List[SubtitleTrack]:
    ranked = []
    for track in tracks:
        if not is_text_subtitle_codec(track.codec_id):
            continue
        if not is_full_dialogue_track(track, media_duration_ms):
            continue
        score = 0.0
        name_lower = track.name.lower()
        if track.language == "en" or "english" in name_lower:
            score += 60
        elif track.language != "und":
            score += 15
        # Only real text subtitle codecs reach this point.
        score += 4
        if track.default:
            score += 4
        if track.hearing_impaired or "sdh" in track.name.lower() or "hi" == track.name.lower().strip():
            score -= 8
        score += min(20.0, track.cue_count / 100.0)
        ranked.append((score, track))
    ranked.sort(key=lambda pair: pair[0], reverse=True)
    return [track for _, track in ranked]


def find_indonesian_embedded(tracks: Iterable[SubtitleTrack], media_duration_ms: int = 0) -> Optional[SubtitleTrack]:
    candidates = [
        track for track in tracks
        if is_text_subtitle_codec(track.codec_id) and (
            track.language == "id"
            or "indonesian" in track.name.lower()
            or "bahasa indonesia" in track.name.lower()
        ) and is_full_dialogue_track(track, media_duration_ms)
    ]
    if not candidates:
        return None
    candidates.sort(
        key=lambda track: (
            0 if track.hearing_impaired else 1,
            1 if track.codec_id.startswith("S_TEXT") else 0,
            track.cue_count,
        ),
        reverse=True,
    )
    return candidates[0]

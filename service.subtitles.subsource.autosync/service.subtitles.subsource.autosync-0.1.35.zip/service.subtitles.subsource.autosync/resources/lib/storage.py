# -*- coding: utf-8 -*-
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import time
import xml.etree.ElementTree as ET
from typing import Any, Dict, List, Optional, Tuple

import xbmcvfs
import xbmc

from .common import (
    ADDON,
    CACHE_DIR,
    PROFILE,
    MANIFEST_DIR,
    PROFILE_SESSION_DIR,
    PROFILE_VARIANT_DIR,
    LOG_DEBUG,
    LOG_INFO,
    LOG_WARNING,
    MediaContext,
    log,
    read_bytes,
    read_text,
    safe_filename,
    setting_bool,
    write_bytes,
    write_text,
)
from .kodi_runtime import stat_signature

SUB_EXTENSIONS = (".srt", ".ass", ".ssa", ".vtt", ".sub", ".smi")
REFERENCE_POLICY = "always_clean_ads_credits_v7"


def _normal_media_path(path: str) -> str:
    value = os.path.normpath(str(path or '').strip())
    return os.path.normcase(value)

def media_key(media: MediaContext) -> str:
    # Stable across separate RunScript invocations where IMDb/season metadata
    # can appear a few frames later than the playing file path.
    raw = _normal_media_path(media.path)
    return hashlib.sha1(raw.encode("utf-8", "ignore")).hexdigest()


def manifest_path(media: MediaContext) -> str:
    return os.path.join(MANIFEST_DIR, media_key(media) + ".json")


def load_manifest(media: MediaContext) -> Optional[Dict[str, Any]]:
    path = manifest_path(media)
    if not xbmcvfs.exists(path):
        return None
    try:
        payload = json.loads(read_text(path))
    except Exception as exc:
        log("manifest read failed: %s" % exc, LOG_WARNING)
        return None
    if _normal_media_path(payload.get("video_path") or '') != _normal_media_path(media.path):
        return None
    # The current reference policy must match before cached output is reused.
    if payload.get("reference_policy") != REFERENCE_POLICY:
        return None
    current = stat_signature(media.path)
    saved = payload.get("video_signature") or {}
    if saved.get("size") and current.get("size") and int(saved["size"]) != int(current["size"]):
        return None
    if saved.get("mtime") and current.get("mtime") and int(saved["mtime"]) != int(current["mtime"]):
        return None
    output = payload.get("output_path") or ""
    if not output or not xbmcvfs.exists(output):
        return None
    return payload


def save_manifest(media: MediaContext, output_path: str, details: Dict[str, Any]) -> str:
    payload = {
        "version": 1,
        "video_path": media.path,
        "video_signature": stat_signature(media.path),
        "imdb_id": media.imdb_id,
        "season": media.season,
        "episode": media.episode,
        "output_path": output_path,
        "reference_policy": REFERENCE_POLICY,
    }
    payload.update(details)
    path = manifest_path(media)
    write_text(path, json.dumps(payload, ensure_ascii=False, indent=2, sort_keys=True))
    return path


def _listdir(path: str) -> Tuple[List[str], List[str]]:
    # xbmcvfs.listdir logs an ERROR before raising when a directory is absent.
    # Check first so optional Subs/Subtitles folders stay silent.
    try:
        if not path or not xbmcvfs.exists(path):
            return [], []
        dirs, files = xbmcvfs.listdir(path)
        return list(dirs), list(files)
    except Exception:
        return [], []


def _normalised_name(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", (value or "").lower())


def _subtitle_matches_video(media: MediaContext, filename: str) -> bool:
    lower = filename.lower()
    if not lower.endswith(SUB_EXTENSIONS):
        return False
    base = os.path.splitext(filename)[0]
    stem_norm = _normalised_name(media.stem)
    base_norm = _normalised_name(base)
    if not stem_norm or not base_norm:
        return False
    if base_norm.startswith(stem_norm) or stem_norm.startswith(base_norm):
        return True

    # Renamed episode files and release-named sidecars often share only the
    # show title plus SxxExx. Require both to avoid grabbing another episode's
    # subtitle from the same season folder.
    if media.is_episode and media.episode_tag:
        episode_norm = _normalised_name(media.episode_tag)
        if episode_norm and episode_norm in base_norm:
            show_tokens = [token for token in re.split(r"[^a-z0-9]+", (media.show_title or media.title).lower()) if len(token) >= 3]
            if not show_tokens:
                return True
            hits = sum(1 for token in show_tokens if token in base.lower())
            return hits >= max(1, min(2, len(show_tokens)))
    return False


def find_local_subtitles(media: MediaContext) -> List[str]:
    """Return every readable text-subtitle candidate belonging to this video.

    The same folder is scanned first, followed by conventional Subs and
    Subtitles subfolders. Generated AutoSync outputs are excluded so stale
    results can never be fed back as fresh input.
    """
    video_dir = os.path.dirname(media.path)
    candidates: List[str] = []
    search_dirs = [video_dir, os.path.join(video_dir, "Subs"), os.path.join(video_dir, "Subtitles")]
    for directory in search_dirs:
        _, files = _listdir(directory)
        for filename in files:
            if _subtitle_matches_video(media, filename):
                candidates.append(os.path.join(directory, filename))
    return list(dict.fromkeys(candidates))


def _is_indonesian_name(stem: str, filename: str) -> bool:
    lower = filename.lower()
    if not lower.endswith(SUB_EXTENSIONS):
        return False
    base = os.path.splitext(lower)[0]
    stem_lower = stem.lower()
    if not (base.startswith(stem_lower) or stem_lower.startswith(base.split(".")[0])):
        return False
    tokens = re.split(r"[. _\-\[\]()]+", base)
    return any(token in ("id", "ind", "indo", "indonesia", "indonesian", "bahasa", "bahasaindonesia") for token in tokens)


ORIGINAL_BACKUP_DIR = os.path.join(CACHE_DIR, "originals")


def _canonical_filename(media: MediaContext) -> str:
    return "%s.id.srt" % media.stem


def _video_sidecar_path(media: MediaContext) -> str:
    return os.path.join(os.path.dirname(media.path), _canonical_filename(media))


def _candidate_output_path(media: MediaContext) -> str:
    filename = _canonical_filename(media)
    if setting_bool("save_next_to_video", True):
        video_dir = os.path.dirname(media.path)
        if video_dir and not video_dir.lower().startswith(("plugin://", "pvr://", "http://", "https://")):
            return os.path.join(video_dir, filename)
    cache_name = "%s-%s" % (media_key(media), filename)
    return os.path.join(CACHE_DIR, safe_filename(cache_name))


def _delete_quietly(path: str) -> None:
    if not path:
        return
    try:
        if xbmcvfs.exists(path):
            xbmcvfs.delete(path)
    except Exception as exc:
        log("cannot remove obsolete subtitle sidecar %s: %s" % (path, exc), LOG_WARNING)


def _backup_original_once(media: MediaContext, destination: str) -> str:
    if not xbmcvfs.exists(destination):
        return ""
    xbmcvfs.mkdirs(ORIGINAL_BACKUP_DIR)
    backup = os.path.join(ORIGINAL_BACKUP_DIR, "%s.id.original.srt" % media_key(media))
    if xbmcvfs.exists(backup):
        return backup
    try:
        write_bytes(backup, read_bytes(destination))
        log("original Indonesian sidecar backed up: %s" % backup, LOG_INFO)
        return backup
    except Exception as exc:
        log("cannot back up original Indonesian sidecar %s: %s" % (destination, exc), LOG_WARNING)
        return ""


def _is_plain_local_path(path: str) -> bool:
    lower = (path or "").lower()
    return bool(path) and "://" not in lower and not lower.startswith("special://")


def _subtitle_bytes(srt_text: str) -> bytes:
    text = str(srt_text or '').replace('\r\n', '\n').replace('\r', '\n')
    if text and not text.endswith('\n'):
        text += '\n'
    return text.encode('utf-8')


def _file_sha256(path: str, native: bool = False) -> str:
    try:
        if native:
            if not os.path.isfile(path):
                return ''
            digest = hashlib.sha256()
            with open(path, 'rb') as handle:
                for chunk in iter(lambda: handle.read(1024 * 1024), b''):
                    digest.update(chunk)
            return digest.hexdigest()
        return hashlib.sha256(read_bytes(path)).hexdigest() if xbmcvfs.exists(path) else ''
    except Exception:
        return ''


def _native_verify_sha256(path: str, expected: str, attempts: int = 6, delay: float = 0.075) -> bool:
    for index in range(max(1, int(attempts or 1))):
        if os.path.isfile(path) and _file_sha256(path, native=True) == expected:
            return True
        if index + 1 < attempts:
            time.sleep(delay)
    return False


def _native_delete_quietly(path: str) -> None:
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass


def _write_canonical_sidecar(media: MediaContext, destination: str, srt_text: str) -> None:
    temp = destination + '.autosync.tmp'
    rollback = destination + '.autosync.rollback'
    payload = _subtitle_bytes(srt_text)
    expected = hashlib.sha256(payload).hexdigest()
    local = _is_plain_local_path(destination)

    if local:
        parent = os.path.dirname(destination)
        if parent:
            os.makedirs(parent, exist_ok=True)
        _native_delete_quietly(temp)
        _native_delete_quietly(rollback)
        with open(temp, 'wb') as handle:
            handle.write(payload)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
        if not _native_verify_sha256(temp, expected):
            _native_delete_quietly(temp)
            raise RuntimeError('temporary subtitle verification failed')

        _backup_original_once(media, destination)
        had_destination = os.path.isfile(destination)
        if had_destination:
            try:
                shutil.copy2(destination, rollback)
            except OSError as exc:
                _native_delete_quietly(temp)
                raise RuntimeError('could not create rollback subtitle: %s' % exc)
        try:
            os.replace(temp, destination)
            if not _native_verify_sha256(destination, expected):
                raise RuntimeError('canonical subtitle verification failed')
            _native_delete_quietly(rollback)
            return
        except Exception:
            _native_delete_quietly(destination)
            if os.path.isfile(rollback):
                os.replace(rollback, destination)
            _native_delete_quietly(temp)
            raise

    # VFS path (smb://, nfs://, special://): retain Kodi-native operations.
    _delete_quietly(temp)
    _delete_quietly(rollback)
    write_bytes(temp, payload)
    if not xbmcvfs.exists(temp) or _file_sha256(temp) != expected:
        _delete_quietly(temp)
        raise RuntimeError('temporary subtitle verification failed')
    _backup_original_once(media, destination)
    had_destination = xbmcvfs.exists(destination)
    if had_destination and not xbmcvfs.copy(destination, rollback):
        _delete_quietly(temp)
        raise RuntimeError('could not create rollback subtitle')
    try:
        if had_destination and not xbmcvfs.delete(destination):
            raise RuntimeError('could not replace existing subtitle')
        if not xbmcvfs.rename(temp, destination):
            raise RuntimeError('could not rename temporary subtitle')
        if not xbmcvfs.exists(destination) or _file_sha256(destination) != expected:
            raise RuntimeError('canonical subtitle verification failed')
        _delete_quietly(rollback)
    except Exception:
        _delete_quietly(destination)
        if xbmcvfs.exists(rollback):
            xbmcvfs.rename(rollback, destination)
        _delete_quietly(temp)
        raise





def save_output(media: MediaContext, srt_text: str) -> str:
    preferred = _candidate_output_path(media)
    try:
        _write_canonical_sidecar(media, preferred, srt_text)
        return preferred
    except Exception as exc:
        log("cannot save beside video, falling back to profile: %s" % exc, LOG_WARNING)
    fallback = os.path.join(CACHE_DIR, "%s.id.srt" % media_key(media))
    _write_canonical_sidecar(media, fallback, srt_text)
    return fallback



def _validate_srt_payload(payload: bytes) -> Dict[str, Any]:
    text = payload.decode("utf-8-sig", "replace").replace("\r\n", "\n").replace("\r", "\n")
    timing = re.compile(r"(?m)^\s*(\d{1,2}):([0-5]\d):([0-5]\d)[,.](\d{3})\s*-->\s*(\d{1,2}):([0-5]\d):([0-5]\d)[,.](\d{3})")
    matches = list(timing.finditer(text))
    cue_count = len(matches)
    valid = cue_count >= 1 and "-->" in text
    return {"valid": bool(valid), "cue_count": cue_count, "size": len(payload), "sha256": hashlib.sha256(payload).hexdigest()}


def validate_subtitle_file(path: str, minimum_cues: int = 1) -> Dict[str, Any]:
    try:
        payload = read_bytes(path)
        result = _validate_srt_payload(payload)
        result["path"] = path
        result["valid"] = bool(result.get("valid") and int(result.get("cue_count") or 0) >= int(minimum_cues))
        return result
    except Exception as exc:
        return {"path": path, "valid": False, "cue_count": 0, "size": 0, "sha256": "", "error": str(exc)}


def _atomic_profile_write(path: str, srt_text: str) -> None:
    payload = _subtitle_bytes(srt_text)
    expected = hashlib.sha256(payload).hexdigest()
    temp = path + ".tmp"
    if _is_plain_local_path(path):
        parent = os.path.dirname(path)
        if parent:
            os.makedirs(parent, exist_ok=True)
        _native_delete_quietly(temp)
        with open(temp, "wb") as handle:
            handle.write(payload)
            handle.flush()
            try:
                os.fsync(handle.fileno())
            except OSError:
                pass
        if not _native_verify_sha256(temp, expected):
            _native_delete_quietly(temp)
            raise RuntimeError("profile temporary subtitle verification failed")
        os.replace(temp, path)
        if not _native_verify_sha256(path, expected):
            raise RuntimeError("profile subtitle verification failed")
        return
    _delete_quietly(temp)
    write_bytes(temp, payload)
    if not xbmcvfs.exists(temp) or _file_sha256(temp) != expected:
        _delete_quietly(temp)
        raise RuntimeError("profile temporary subtitle verification failed")
    if xbmcvfs.exists(path) and not xbmcvfs.delete(path):
        _delete_quietly(temp)
        raise RuntimeError("could not replace profile subtitle")
    if not xbmcvfs.rename(temp, path):
        _delete_quietly(temp)
        raise RuntimeError("could not commit profile subtitle")
    if not xbmcvfs.exists(path) or _file_sha256(path) != expected:
        raise RuntimeError("profile subtitle verification failed")


def save_profile_variant(media: MediaContext, profile_index: int, srt_text: str) -> str:
    directory = os.path.join(PROFILE_VARIANT_DIR, media_key(media))
    xbmcvfs.mkdirs(directory)
    path = os.path.join(directory, "profile-%02d.id.srt" % int(profile_index))
    _atomic_profile_write(path, srt_text)
    result = validate_subtitle_file(path, minimum_cues=1)
    if not result.get("valid"):
        raise RuntimeError("profile subtitle verification failed: %s" % (result.get("error") or "invalid SRT"))
    return path

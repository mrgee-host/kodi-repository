# -*- coding: utf-8 -*-
from __future__ import annotations

import re
from typing import Iterable, List, Set, Tuple

from .common import MediaContext, SubtitleCandidate, norm_tokens
from .zip_select import parse_season_episode, parse_season_only

# Release families serve two distinct purposes:
# - movies: a strict source-family block order, with every BluRay candidate
#   exhausted before the next source family;
# - TV episodes: one best candidate per family after season/episode validation.
RELEASE_FAMILY_ORDER = ("webdl", "webrip", "bluray", "dvd", "hdtv", "remux", "subrip", "other")
MOVIE_RELEASE_FAMILY_ORDER = (
    "bluray", "remux", "webdl", "webrip", "hdtv", "dvd", "hdrip", "subrip", "other",
)
MOVIE_RELEASE_FAMILY_PRIORITY = {
    family: len(MOVIE_RELEASE_FAMILY_ORDER) - index
    for index, family in enumerate(MOVIE_RELEASE_FAMILY_ORDER)
}

TRUSTED_SOURCE_ALIASES = (
    ("IDFL", ("idfl",)),
    ("Pein Akatsuki", ("peinakatsuki",)),
    ("Sebuah Dongeng", ("sebuahdongeng", "sebuahdongengcom", "dongengcom")),
    ("Lebah Ganteng", ("lebahganteng",)),
    ("Ibra Official", ("ibraofficial",)),
    ("Toon21", ("toon21",)),
    ("Fathur", ("fathur",)),
)

FORBIDDEN_RESULT_TOKENS = {"forced", "commentary", "foreignonly", "foreign"}


def _compact(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "", str(value or "").lower())


def release_family(value: str) -> str:
    text = str(value or "")
    tokens = set(norm_tokens(text))
    compact = _compact(text)
    if "subrip" in compact or ({"sub", "rip"} <= tokens):
        return "subrip"
    if "remux" in compact or "bdremux" in compact:
        return "remux"
    if "webdl" in compact:
        return "webdl"
    if "webrip" in compact or "webcap" in compact or "web" in tokens:
        return "webrip"
    if any(token in compact for token in ("bluray", "bdrip", "brrip", "uhdbluray")):
        return "bluray"
    if any(token in compact for token in ("dvdrip", "dvd5", "dvd9")) or "dvd" in tokens:
        return "dvd"
    if "hdtv" in compact or "pdtv" in compact:
        return "hdtv"
    if any(token in compact for token in ("hdrip", "hd-rip", "hd_rip")):
        return "hdrip"
    return "other"


def release_similarity(left: str, right: str) -> float:
    """Compatibility helper retained for callers outside the ranking path."""
    noise = {"subtitle", "subtitles", "sub", "subs", "indonesian", "english", "srt", "ass", "ssa"}
    a = set(norm_tokens(left)) - noise
    b = set(norm_tokens(right)) - noise
    if not a or not b:
        return 0.0
    return len(a & b) / float(len(a | b))


def trusted_source(candidate: SubtitleCandidate) -> str:
    # Source credit can live in Owner, Release Name, or Caption. Combining all
    # three catches resync uploads that explicitly credit the original maker.
    combined = " ".join(
        str(value or "")
        for value in (
            getattr(candidate, "owner", ""),
            getattr(candidate, "release_info", ""),
            getattr(candidate, "caption", ""),
        )
    )
    compact = _compact(combined)
    for canonical, aliases in TRUSTED_SOURCE_ALIASES:
        if any(alias in compact for alias in aliases):
            return canonical
    return ""


def _subtitle_numeric_id(candidate: SubtitleCandidate) -> int:
    digits = re.sub(r"\D+", "", str(candidate.subtitle_id or ""))
    try:
        return int(digits) if digits else 0
    except Exception:
        return 0


def _latest_key(candidate: SubtitleCandidate) -> Tuple[int, int, int]:
    uploaded = max(0, int(getattr(candidate, "uploaded_at", 0) or 0))
    # A real API timestamp is stronger than an ID fallback. When dates are not
    # exposed at all, newer numeric subtitle IDs provide a stable approximation.
    return (1 if uploaded else 0, uploaded, _subtitle_numeric_id(candidate))


def _episode_compatibility(candidate: SubtitleCandidate, media: MediaContext) -> int:
    if not media.is_episode:
        return 0
    season, episode = parse_season_episode(candidate.release_info)
    season_only = parse_season_only(candidate.release_info)
    if season == media.season and episode == media.episode:
        return 2
    if season_only == media.season and episode is None:
        return 1
    if season is not None and episode is not None:
        return -1
    if season_only is not None and season_only != media.season:
        return -1
    return 0


def _is_forbidden(candidate: SubtitleCandidate) -> bool:
    compact = _compact("%s %s" % (candidate.release_info, getattr(candidate, "caption", "")))
    return any(token in compact for token in FORBIDDEN_RESULT_TOKENS)


def community_sort_key(
    candidate: SubtitleCandidate,
    media: MediaContext,
    prefer_non_sdh: bool = True,
) -> Tuple:
    rating = max(0.0, min(10.0, float(candidate.rating or 0.0)))
    votes = max(0, int(candidate.rating_votes or 0))
    downloads = max(0, int(candidate.download_count or 0))
    trusted = trusted_source(candidate)
    has_rating = rating > 0.0
    group = 3 if has_rating else (2 if trusted else 1)
    latest_known, uploaded, fallback_id = _latest_key(candidate)
    episode_match = _episode_compatibility(candidate, media)
    non_sdh = 1 if (prefer_non_sdh and not candidate.hearing_impaired) else 0

    # Movies use an absolute release-family block order first:
    # every BluRay result, then Remux, WEB-DL, WEBRip, HDTV, DVD, HDRip,
    # SubRip, and Other. Community quality only sorts inside that family.
    # TV episodes keep the community ranking here, then automatic profiles
    # retain one best result per release family.
    family_priority = 0
    if not media.is_episode:
        family_priority = MOVIE_RELEASE_FAMILY_PRIORITY.get(
            release_family(candidate.release_info),
            MOVIE_RELEASE_FAMILY_PRIORITY["other"],
        )

    return (
        family_priority,
        group,
        rating if has_rating else 0.0,
        votes if has_rating else 0,
        1 if trusted else 0,
        latest_known,
        uploaded,
        fallback_id,
        downloads,
        episode_match,
        non_sdh,
    )


def score_candidate(candidate: SubtitleCandidate, media: MediaContext, prefer_non_sdh: bool = True) -> float:
    key = community_sort_key(candidate, media, prefer_non_sdh)
    family_priority, group, rating, votes, trusted, has_date, uploaded, fallback_id, downloads, episode_match, non_sdh = key
    # Numeric score is retained for diagnostics and existing downstream
    # tie-breakers. Actual ordering always uses community_sort_key directly.
    candidate.popularity_score = float(downloads)
    candidate.score = (
        float(family_priority) * 100_000_000.0
        + float(group) * 1_000_000.0
        + float(rating) * 10_000.0
        + min(float(votes), 9999.0)
        + float(trusted) * 500.0
        + float(has_date) * 100.0
        + float(episode_match) * 10.0
        + float(non_sdh)
    )
    return candidate.score


def rank_candidates(
    candidates: Iterable[SubtitleCandidate],
    media: MediaContext,
    prefer_non_sdh: bool = True,
) -> List[SubtitleCandidate]:
    ranked: List[SubtitleCandidate] = []
    for candidate in candidates:
        if _is_forbidden(candidate):
            continue
        if media.is_episode and _episode_compatibility(candidate, media) < 0:
            continue
        score_candidate(candidate, media, prefer_non_sdh)
        ranked.append(candidate)
    ranked.sort(key=lambda item: community_sort_key(item, media, prefer_non_sdh), reverse=True)
    # Preserve the exact community order for existing downstream tie-breakers
    # that compare candidate.score after synchronization quality is otherwise
    # equal. Higher score means earlier in this final ranked list.
    total = len(ranked)
    for index, candidate in enumerate(ranked):
        candidate.score = float(total - index)
    return ranked


def arrange_candidates_for_auto(
    candidates: Iterable[SubtitleCandidate],
    media: MediaContext,
    mode: str = "ranked",
    preferred_id: str = "",
) -> List[SubtitleCandidate]:
    """Use one deterministic ordering for manual results and automatic profiles.

    Movies preserve the exact ranked order: profile-00 is the first valid
    downloaded result, profile-01 the next, and so on.

    TV episodes keep at most one best candidate per release family (BluRay,
    WEB-DL, WEBRip, HDTV, DVD, Remux, SubRip, Other). Because candidates arrive
    already ranked, the first candidate seen in a family is that family's best.
    """
    ranked = list(candidates)
    if not media.is_episode:
        return ranked

    arranged: List[SubtitleCandidate] = []
    seen_families = set()
    for candidate in ranked:
        family = release_family(candidate.release_info)
        if family in seen_families:
            continue
        seen_families.add(family)
        arranged.append(candidate)
    return arranged


def infer_release_owner(release: str, fallback: str = "") -> str:
    """Best-effort release-group label used only for compact UI text."""
    text = " ".join((release or "").split())
    if not text:
        return fallback
    patterns = (
        r"(?i)\bby[ .:_-]+([A-Za-z0-9][A-Za-z0-9._-]{1,30})\b",
        r"(?i)\buntuk[ .:_-]+([A-Za-z0-9][A-Za-z0-9._-]{1,30})\b",
        r"(?i)\b(pahe\.in)\b",
    )
    for pattern in patterns:
        match = re.search(pattern, text)
        if match:
            return match.group(1).strip(" ._-:/")
    tail = re.search(r"-([A-Za-z][A-Za-z0-9._]{2,24})(?:\s*(?:\||$))", text)
    if tail:
        token = tail.group(1).strip(" ._-")
        if token.lower() not in {"web", "webdl", "webrip", "bluray", "hdtv", "dvdrip", "complete"}:
            return token
    return fallback


def candidate_owner(candidate: SubtitleCandidate, fallback_prefix: str = "ID") -> str:
    owner = (getattr(candidate, "owner", "") or "").strip()
    if owner:
        return owner
    fallback = "%s %s" % (fallback_prefix, candidate.subtitle_id) if candidate.subtitle_id else fallback_prefix
    return infer_release_owner(candidate.release_info, fallback)

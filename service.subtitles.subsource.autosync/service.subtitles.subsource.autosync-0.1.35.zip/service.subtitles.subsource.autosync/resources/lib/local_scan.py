# -*- coding: utf-8 -*-
from __future__ import annotations

import os
import re
from dataclasses import dataclass
from typing import List

from .common import Cue, LOG_INFO, LOG_WARNING, MediaContext, log
from .storage import find_local_subtitles
from .subtitle_io import parse_subtitle_file_with_report


@dataclass
class LocalSubtitle:
    path: str
    cues: List[Cue]
    language: str = "und"
    ads_removed: int = 0


_INDONESIAN_FILENAME_TOKENS = {
    "id", "ind", "indo", "indonesia", "indonesian", "bahasa", "bahasaindonesia",
}
_ENGLISH_FILENAME_TOKENS = {"en", "eng", "english"}

_INDONESIAN_WORDS = {
    "aku", "anda", "apa", "akan", "ada", "adalah", "bisa", "dalam", "dan", "dari",
    "dengan", "dia", "ini", "itu", "jangan", "jika", "kami", "kamu", "karena", "kau",
    "kita", "mereka", "mungkin", "saya", "sekarang", "sudah", "tidak", "untuk", "yang",
}
_ENGLISH_WORDS = {
    "a", "about", "and", "are", "because", "can", "do", "for", "from", "have", "he",
    "i", "in", "is", "it", "me", "my", "not", "of", "on", "she", "that", "the", "they",
    "this", "to", "we", "what", "with", "you", "your",
}


def _filename_language(path: str) -> str:
    base = os.path.splitext(os.path.basename(path).lower())[0]
    tokens = set(token for token in re.split(r"[. _\-\[\]()]+", base) if token)
    if tokens & _INDONESIAN_FILENAME_TOKENS:
        return "id"
    if tokens & _ENGLISH_FILENAME_TOKENS:
        return "en"
    return "und"


def _content_language(cues: List[Cue]) -> str:
    # This is deliberately conservative. It is only used when the filename has
    # no language marker, and prevents a plain English sidecar from being
    # mistaken for Indonesian merely because it sits beside the video.
    text = " ".join(cue.text for cue in cues[:220]).lower()
    text = re.sub(r"\{[^}]*\}|<[^>]+>", " ", text)
    words = re.findall(r"[a-z]+", text)
    if not words:
        return "und"
    id_score = sum(1 for word in words if word in _INDONESIAN_WORDS)
    en_score = sum(1 for word in words if word in _ENGLISH_WORDS)
    if id_score >= 8 and id_score >= en_score * 1.35:
        return "id"
    if en_score >= 8 and en_score >= id_score * 1.35:
        return "en"
    return "und"


def load_local_subtitles(media: MediaContext) -> List[LocalSubtitle]:
    result: List[LocalSubtitle] = []
    for path in find_local_subtitles(media):
        try:
            cues, cleanup_report = parse_subtitle_file_with_report(path, media.show_title or media.title)
            if len(cues) < 8:
                log("local subtitle ignored because cue count is too small path=%s cues=%d" % (path, len(cues)), LOG_WARNING)
                continue
            language = _filename_language(path)
            if language == "und":
                language = _content_language(cues)
            result.append(LocalSubtitle(
                path=path, cues=cues, language=language,
                ads_removed=int(cleanup_report.removed_lines or 0),
            ))
            log(
                "local text subtitle detected language=%s cues=%d path=%s"
                % (language, len(cues), path),
                LOG_INFO,
            )
        except Exception as exc:
            log("failed reading local subtitle %s: %s" % (path, exc), LOG_WARNING)
    return result


def load_local_targets(media: MediaContext) -> List[LocalSubtitle]:
    return [item for item in load_local_subtitles(media) if item.language == "id"]


def load_local_references(media: MediaContext) -> List[LocalSubtitle]:
    return [item for item in load_local_subtitles(media) if item.language == "en"]

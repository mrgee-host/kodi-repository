# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import time
import zipfile
from typing import Any, Dict, Optional

import xbmcvfs

from .common import (
    ADDON,
    ADDON_ID,
    DIAGNOSTIC_DIR,
    EXPORT_DIR,
    MANIFEST_DIR,
    MediaContext,
    PROFILE_SESSION_DIR,
    PROFILE_VARIANT_DIR,
    SEASON_PROFILE_DIR,
    log,
    read_bytes,
    read_text,
    write_text,
    LOG_INFO,
    LOG_WARNING,
)
from .storage import media_key
from .cleanup_audit import audit_path as cleanup_audit_path


def snapshot_path(media: MediaContext) -> str:
    return os.path.join(DIAGNOSTIC_DIR, media_key(media) + ".json")


def save_snapshot(media: MediaContext, payload: Dict[str, Any]) -> str:
    data = dict(payload or {})
    data.update(
        {
            "version": 1,
            "video_path": media.path,
            "title": media.title,
            "show_title": media.show_title,
            "season": media.season,
            "episode": media.episode,
            "updated_at": int(time.time()),
        }
    )
    path = snapshot_path(media)
    write_text(path, json.dumps(data, ensure_ascii=False, indent=2, sort_keys=True))
    return path


def _safe_json(path: str) -> Dict[str, Any]:
    try:
        data = json.loads(read_text(path))
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _latest_file(directory: str, suffix: str = ".json") -> str:
    try:
        _dirs, files = xbmcvfs.listdir(directory)
    except Exception:
        return ""
    candidates = []
    for name in files:
        if suffix and not name.lower().endswith(suffix):
            continue
        path = os.path.join(directory, name)
        try:
            stamp = os.path.getmtime(path)
        except Exception:
            stamp = 0
        candidates.append((stamp, path))
    return max(candidates, default=(0, ""))[1]


def _add_path(zf: zipfile.ZipFile, path: str, arcname: str) -> bool:
    if not path or not xbmcvfs.exists(path):
        return False
    try:
        zf.writestr(arcname, read_bytes(path))
        return True
    except Exception as exc:
        log("diagnostic export skipped %s: %s" % (path, exc), LOG_WARNING)
        return False


def _filtered_log() -> str:
    path = xbmcvfs.translatePath("special://logpath/kodi.log")
    if not path or not xbmcvfs.exists(path):
        return ""
    try:
        text = read_text(path)
    except Exception:
        return ""
    lines = text.splitlines()
    kept = [line for line in lines if ADDON_ID in line or "Smart Subtitle" in line]
    return "\n".join(kept[-8000:]) + ("\n" if kept else "")


def _settings_sanitized() -> Dict[str, Any]:
    keys = (
        "enabled", "notifications", "open_manual_on_failure", "pause_episode_until_ready",
        "max_candidates", "initial_candidates", "parallel_downloads", "accept_confidence",
        "max_auto_offset_ms", "max_auto_p90_ms", "prefer_non_sdh", "playback_delay_seconds",
        "automatic_indonesian_profiles", "automatic_candidate_mode", "max_sync_profiles", "install_default_f3_keymap",
        "auto_save_stable_profile", "stable_profile_minutes", "stable_profile_min_progress",
        "allow_large_correction_auto_save", "manual_results", "save_next_to_video",
        "debug_logging",
    )
    return {key: ADDON.getSetting(key) for key in keys}


def export_diagnostics(media: Optional[MediaContext] = None) -> str:
    session_file = os.path.join(PROFILE_SESSION_DIR, media_key(media) + ".json") if media else _latest_file(PROFILE_SESSION_DIR)
    session = _safe_json(session_file) if session_file else {}
    key = os.path.splitext(os.path.basename(session_file))[0] if session_file else ""
    if media:
        key = media_key(media)
    if not key:
        raise RuntimeError("belum ada sesi subtitle yang dapat diekspor")

    manifest_file = os.path.join(MANIFEST_DIR, key + ".json")
    diagnostic_file = os.path.join(DIAGNOSTIC_DIR, key + ".json")
    profile_dir = os.path.join(PROFILE_VARIANT_DIR, key)

    season_file = ""
    if media:
        from .profile_store import season_preference_path
        season_file = season_preference_path(media)
    elif session.get("show_title") and int(session.get("season") or 0) >= 0:
        # Find the newest season profile. The session still records exact title/season in summary.
        season_file = _latest_file(SEASON_PROFILE_DIR)

    stamp = time.strftime("%Y%m%d-%H%M%S")
    filename = "smart-subtitle-diagnostics-%s.zip" % stamp
    profile_root = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    output = os.path.join(profile_root, filename)
    xbmcvfs.mkdirs(profile_root)
    temp_output = output + ".tmp"

    profiles = session.get("profiles") or []
    safe_count = sum(1 for item in profiles if not item.get("risky"))
    risky_count = sum(1 for item in profiles if item.get("risky"))
    active = int(session.get("active_index") or 0) if profiles else -1
    active_profile = profiles[active] if 0 <= active < len(profiles) else {}
    canonical_path = str(session.get("sidecar_output_path") or "")
    active_profile_path = str(session.get("active_output_path") or (active_profile.get("variant_path") if isinstance(active_profile, dict) else "") or "")
    last_apply_file = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), "runtime", "state", "last_subtitle_apply.json")
    manual_pending_file = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), "runtime", "state", "manual_subtitle_pending.json")
    manual_result_file = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), "runtime", "state", "last_manual_subtitle_result.json")

    summary = [
        "Smart Subtitle Diagnostics",
        "Generated: %s" % time.strftime("%Y-%m-%d %H:%M:%S"),
        "Video: %s" % (session.get("video_path") or (media.path if media else "")),
        "Show: %s" % (session.get("show_title") or ""),
        "Season/Episode: %s/%s" % (session.get("season"), session.get("episode")),
        "Profiles: %d safe=%d risky=%d" % (len(profiles), safe_count, risky_count),
        "Active index: %s" % active,
        "Active mode: %s" % (active_profile.get("mode") or "automatic"),
        "Active family: %s" % (active_profile.get("source_family") or active_profile.get("family") or ""),
        "Active owner: %s" % (active_profile.get("target_owner") or active_profile.get("reference_owner") or ""),
        "Active target: %s" % (active_profile.get("target_release") or ""),
        "Active reference: %s" % (active_profile.get("reference_release") or ""),
    ]

    with zipfile.ZipFile(temp_output, "w", compression=zipfile.ZIP_DEFLATED) as zf:
        zf.writestr("manifest.json", json.dumps({"addon_id": ADDON_ID, "addon_name": "Smart Subtitle", "addon_version": ADDON.getAddonInfo("version"), "created_at": time.strftime("%Y-%m-%d %H:%M:%S"), "zip_layout": "runtime-v1"}, ensure_ascii=False, indent=2) + "\n")
        zf.writestr("summary.txt", "\n".join(summary) + "\n")
        _add_path(zf, session_file, "profile-session.json")
        _add_path(zf, manifest_file, "runtime/diagnostics/session-manifest.json")
        _add_path(zf, diagnostic_file, "candidate-matrix.json")
        _add_path(zf, canonical_path, "active/canonical-sidecar.id.srt")
        _add_path(zf, active_profile_path, "active/active-profile.id.srt")
        _add_path(zf, last_apply_file, "active/last-subtitle-apply.json")
        _add_path(zf, manual_pending_file, "active/manual-subtitle-pending.json")
        _add_path(zf, manual_result_file, "active/last-manual-subtitle-result.json")
        _add_path(zf, season_file, "season-profile.json")
        keymap = xbmcvfs.translatePath("special://profile/keymaps/subsource_autosync.xml")
        _add_path(zf, keymap, "keymap.xml")
        zf.writestr("settings-sanitized.json", json.dumps(_settings_sanitized(), ensure_ascii=False, indent=2, sort_keys=True))
        _add_path(zf, cleanup_audit_path(), "cleanup/cleanup-events.json")
        cleanup_rules = os.path.normpath(os.path.join(os.path.dirname(__file__), "..", "data", "cleanup_rules.txt"))
        _add_path(zf, cleanup_rules, "cleanup/cleanup-rules.txt")
        addon_log = _filtered_log()
        if addon_log:
            zf.writestr("kodi-addon.log", addon_log)
        try:
            _dirs, files = xbmcvfs.listdir(profile_dir)
        except Exception:
            files = []
        for name in sorted(files):
            if name.lower().endswith((".srt", ".ass", ".ssa", ".vtt")):
                _add_path(zf, os.path.join(profile_dir, name), "profiles/%s" % name)

    with zipfile.ZipFile(temp_output, "r") as test_zf:
        bad = test_zf.testzip()
        if bad:
            raise RuntimeError("diagnostic ZIP validation failed at %s" % bad)
    try:
        _dirs, _files = xbmcvfs.listdir(profile_root)
        for old_name in _files:
            is_diag = old_name.startswith("smart-subtitle-diagnostics-")
            if is_diag and old_name.endswith(".zip"):
                xbmcvfs.delete(os.path.join(profile_root, old_name))
    except Exception:
        pass
    os.replace(temp_output, output)
    log("diagnostic export created: %s" % output, LOG_INFO)
    return output

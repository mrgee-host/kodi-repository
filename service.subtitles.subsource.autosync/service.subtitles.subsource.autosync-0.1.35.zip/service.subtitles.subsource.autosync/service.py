# -*- coding: utf-8 -*-
from __future__ import annotations

import sys
import threading
import time

import xbmc
import xbmcaddon

ADDON = xbmcaddon.Addon("service.subtitles.subsource.autosync")
ADDON_PATH = ADDON.getAddonInfo("path")
if ADDON_PATH not in sys.path:
    sys.path.insert(0, ADDON_PATH)

from resources.lib.common import LOG_DEBUG, log, setting_int
from resources.lib.core import AutoSyncWorkflow
from resources.lib.profile_store import ManualSubtitleMonitor, ProfileStabilityMonitor, install_default_keymap


class AutoSyncPlayer(xbmc.Player):
    _guard_lock = threading.Lock()
    _last_path = ""
    _last_run_at = 0.0

    def onAVStarted(self):
        # v0.1.11 keeps the v0.1.5 startup behavior and starts immediately by default. The setting remains available
        # for devices whose metadata appears a little late.
        delay = max(0, setting_int("playback_delay_seconds", 0))
        if delay:
            xbmc.sleep(delay * 1000)
        if not self.isPlayingVideo():
            return
        try:
            path = self.getPlayingFile()
        except Exception:
            path = ""
        now = time.monotonic()
        with self._guard_lock:
            if path and path == self._last_path and now - self._last_run_at < 12.0:
                log("duplicate onAVStarted ignored for %s" % path, LOG_DEBUG)
                return
            self._last_path = path
            self._last_run_at = now
        AutoSyncWorkflow(self).run()


if __name__ == "__main__":
    player = AutoSyncPlayer()
    monitor = xbmc.Monitor()
    stability = ProfileStabilityMonitor(player)
    manual_monitor = ManualSubtitleMonitor(player)
    install_default_keymap()
    log("Smart Subtitle service started", LOG_DEBUG)
    while not monitor.abortRequested():
        stability.tick()
        manual_monitor.tick()
        if monitor.waitForAbort(1.0):
            break
    log("Smart Subtitle service stopped", LOG_DEBUG)

# -*- coding: utf-8 -*-
from __future__ import annotations

import html
import os
import re
from typing import Iterable, List, Optional, Tuple

from .common import Cue, LOG_WARNING, log, read_text
from .cleanup_engine import CleanupReport, clean_cues
from .cleanup_audit import record_cleanup_report

_TIME_SRT = re.compile(r"(?P<h>\d{1,3}):(?P<m>\d{2}):(?P<s>\d{2})[,.](?P<ms>\d{1,3})")
_TIME_ASS = re.compile(r"(?P<h>\d{1,2}):(?P<m>\d{2}):(?P<s>\d{2})[.](?P<cs>\d{1,2})")
_TIME_VTT = re.compile(r"(?:(?P<h>\d{1,3}):)?(?P<m>\d{2}):(?P<s>\d{2})[.](?P<ms>\d{1,3})")


def _ms_from_match(match: re.Match, centiseconds: bool = False) -> int:
    h = int(match.groupdict().get("h") or 0)
    m = int(match.group("m"))
    s = int(match.group("s"))
    if centiseconds:
        ms = int((match.groupdict().get("cs") or "0").ljust(2, "0")[:2]) * 10
    else:
        ms = int((match.groupdict().get("ms") or "0").ljust(3, "0")[:3])
    return ((h * 60 + m) * 60 + s) * 1000 + ms


def _clean_text(text: str) -> str:
    """Return plain text for formats that cannot preserve styling safely."""
    text = text.replace("\\N", "\n").replace("\\n", "\n")
    text = re.sub(r"\{[^}]*\}", "", text)
    text = re.sub(r"<[^>]+>", "", text)
    return html.unescape(text).strip()


def _display_text(text: str) -> str:
    """Preserve SRT/ASS styling while normalising line breaks only."""
    return text.replace("\\N", "\n").replace("\\n", "\n").strip()


def parse_srt(text: str) -> List[Cue]:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n").strip("\ufeff\n ")
    blocks = re.split(r"\n\s*\n", normalized)
    cues: List[Cue] = []
    for block in blocks:
        lines = [line.rstrip() for line in block.split("\n")]
        if not lines:
            continue
        timing_index = 0
        if "-->" not in lines[0] and len(lines) > 1:
            timing_index = 1
        if timing_index >= len(lines) or "-->" not in lines[timing_index]:
            continue
        left, right = [part.strip() for part in lines[timing_index].split("-->", 1)]
        m1 = _TIME_SRT.search(left)
        m2 = _TIME_SRT.search(right)
        if not m1 or not m2:
            continue
        start = _ms_from_match(m1)
        end = _ms_from_match(m2)
        body = _display_text("\n".join(lines[timing_index + 1 :]))
        cues.append(Cue(start, max(start + 80, end), body))
    return cues


def parse_vtt(text: str) -> List[Cue]:
    normalized = text.replace("\r\n", "\n").replace("\r", "\n").strip("\ufeff\n ")
    if normalized.startswith("WEBVTT"):
        normalized = normalized.split("\n", 1)[1] if "\n" in normalized else ""
    blocks = re.split(r"\n\s*\n", normalized)
    cues: List[Cue] = []
    for block in blocks:
        lines = [line.rstrip() for line in block.split("\n")]
        timing_index = next((i for i, line in enumerate(lines[:3]) if "-->" in line), -1)
        if timing_index < 0:
            continue
        left, right = [part.strip() for part in lines[timing_index].split("-->", 1)]
        m1 = _TIME_VTT.search(left)
        m2 = _TIME_VTT.search(right)
        if not m1 or not m2:
            continue
        start = _ms_from_match(m1)
        end = _ms_from_match(m2)
        body = _display_text("\n".join(lines[timing_index + 1 :]))
        cues.append(Cue(start, max(start + 80, end), body))
    return cues


def parse_ass(text: str) -> List[Cue]:
    cues: List[Cue] = []
    in_events = False
    format_fields: List[str] = []
    for raw_line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        line = raw_line.strip("\ufeff")
        if line.strip().lower() == "[events]":
            in_events = True
            continue
        if line.startswith("[") and line.endswith("]") and line.strip().lower() != "[events]":
            in_events = False
        if not in_events:
            continue
        if line.lower().startswith("format:"):
            format_fields = [part.strip().lower() for part in line.split(":", 1)[1].split(",")]
            continue
        if not line.lower().startswith("dialogue:"):
            continue
        payload = line.split(":", 1)[1].lstrip()
        split_count = max(9, len(format_fields) - 1) if format_fields else 9
        parts = payload.split(",", split_count)
        if len(parts) < 3:
            continue
        if format_fields and len(parts) >= len(format_fields):
            mapping = dict(zip(format_fields, parts))
            start_raw = mapping.get("start", "")
            end_raw = mapping.get("end", "")
            body = mapping.get("text", parts[-1])
        else:
            start_raw = parts[1] if len(parts) > 2 else ""
            end_raw = parts[2] if len(parts) > 3 else ""
            body = parts[-1]
        m1 = _TIME_ASS.search(start_raw)
        m2 = _TIME_ASS.search(end_raw)
        if not m1 or not m2:
            continue
        start = _ms_from_match(m1, centiseconds=True)
        end = _ms_from_match(m2, centiseconds=True)
        cues.append(Cue(start, max(start + 80, end), _display_text(body)))
    return cues


def parse_microdvd(text: str, fps: float = 23.976) -> List[Cue]:
    cues: List[Cue] = []
    pattern = re.compile(r"^\{(\d+)\}\{(\d+)\}(.*)$")
    for line in text.replace("\r\n", "\n").replace("\r", "\n").split("\n"):
        match = pattern.match(line.strip())
        if not match:
            continue
        start_frame, end_frame = int(match.group(1)), int(match.group(2))
        body = _display_text(match.group(3).replace("|", "\n"))
        start = int(start_frame * 1000.0 / fps)
        end = int(end_frame * 1000.0 / fps)
        cues.append(Cue(start, max(start + 80, end), body))
    return cues


def parse_subtitle_text_with_report(text: str, filename: str = "") -> Tuple[List[Cue], CleanupReport]:
    ext = os.path.splitext(filename.lower())[1]
    parsers = []
    if ext in (".ass", ".ssa"):
        parsers = [parse_ass, parse_srt, parse_vtt]
    elif ext == ".vtt":
        parsers = [parse_vtt, parse_srt, parse_ass]
    elif ext == ".sub":
        parsers = [parse_microdvd, parse_srt, parse_ass]
    else:
        parsers = [parse_srt, parse_ass, parse_vtt, parse_microdvd]
    for parser in parsers:
        try:
            cues = parser(text)
            if cues:
                normalized = sorted((cue.normalized() for cue in cues), key=lambda cue: (cue.start_ms, cue.end_ms))
                cleaned, report = clean_cues(normalized, source=filename or parser.__name__)
                record_cleanup_report(report)
                result = sorted((cue.normalized() for cue in cleaned), key=lambda cue: (cue.start_ms, cue.end_ms))
                return result, report
        except Exception as exc:
            log("subtitle parser %s failed for %s: %s" % (parser.__name__, filename, exc), LOG_WARNING)
    return [], CleanupReport(source=filename or "unknown")


def parse_subtitle_text(text: str, filename: str = "") -> List[Cue]:
    cues, _report = parse_subtitle_text_with_report(text, filename)
    return cues


def parse_subtitle_file_with_report(path: str) -> Tuple[List[Cue], CleanupReport]:
    return parse_subtitle_text_with_report(read_text(path), path)


def parse_subtitle_file(path: str) -> List[Cue]:
    cues, _report = parse_subtitle_file_with_report(path)
    return cues


def _fmt_srt(ms: int) -> str:
    ms = max(0, int(ms))
    hours, rem = divmod(ms, 3600000)
    minutes, rem = divmod(rem, 60000)
    seconds, millis = divmod(rem, 1000)
    return "%02d:%02d:%02d,%03d" % (hours, minutes, seconds, millis)


def render_srt(cues: Iterable[Cue]) -> str:
    lines: List[str] = []
    last_end = 0
    index = 1
    for cue in sorted(cues, key=lambda item: (item.start_ms, item.end_ms)):
        normalized = cue.normalized()
        start = max(normalized.start_ms, last_end if normalized.start_ms < last_end - 5000 else normalized.start_ms)
        end = max(start + 80, normalized.end_ms)
        body = normalized.text.strip() or " "
        lines.extend([str(index), "%s --> %s" % (_fmt_srt(start), _fmt_srt(end)), body, ""])
        index += 1
        last_end = end
    return "\ufeff" + "\n".join(lines)


def looks_like_subtitle(payload: bytes) -> bool:
    head = payload[:8192].decode("utf-8", "ignore").lower()
    return "-->" in head or "[events]" in head or bool(re.search(r"\{\d+\}\{\d+\}", head))

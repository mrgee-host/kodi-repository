# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass, field
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon("service.subtitles.subsource.autosync")
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
TEMP_DIR = os.path.join(PROFILE, "temp")
CACHE_DIR = os.path.join(PROFILE, "subtitles")
MANIFEST_DIR = os.path.join(PROFILE, "manifests")
PROFILE_SESSION_DIR = os.path.join(PROFILE, "profile_sessions")
SEASON_PROFILE_DIR = os.path.join(PROFILE, "season_profiles")
PROFILE_VARIANT_DIR = os.path.join(CACHE_DIR, "profiles")
DIAGNOSTIC_DIR = os.path.join(PROFILE, "diagnostics")
EXPORT_DIR = os.path.join(PROFILE, "exports")

for _path in (PROFILE, TEMP_DIR, CACHE_DIR, MANIFEST_DIR, PROFILE_SESSION_DIR, SEASON_PROFILE_DIR, PROFILE_VARIANT_DIR, DIAGNOSTIC_DIR, EXPORT_DIR):
    try:
        xbmcvfs.mkdirs(_path)
    except Exception:
        pass

LOG_DEBUG = getattr(xbmc, "LOGDEBUG", 0)
LOG_INFO = getattr(xbmc, "LOGINFO", 1)
LOG_WARNING = getattr(xbmc, "LOGWARNING", 2)
LOG_ERROR = getattr(xbmc, "LOGERROR", 4)


def setting_bool(key: str, default: bool = False) -> bool:
    value = ADDON.getSetting(key)
    if value == "":
        return default
    return value.lower() == "true"


def setting_int(key: str, default: int) -> int:
    try:
        return int(ADDON.getSetting(key))
    except Exception:
        return default


def setting_float(key: str, default: float) -> float:
    try:
        return float(ADDON.getSetting(key))
    except Exception:
        return default


def log(message: str, level: int = LOG_INFO) -> None:
    if level == LOG_DEBUG and not setting_bool("debug_logging", False):
        return
    try:
        xbmc.log("[%s] %s" % (ADDON_ID, message), level)
    except Exception:
        pass


NOTIFICATION_LIMIT = 65


def compact_label(value: object, limit: int = 18, fallback: str = "") -> str:
    text = re.sub(r"\s+", " ", str(value or fallback)).strip()
    if len(text) <= max(1, int(limit)):
        return text
    return text[: max(1, int(limit)) - 1].rstrip() + "…"


def compact_notification(message: object, limit: int = NOTIFICATION_LIMIT) -> str:
    text = re.sub(r"\s+", " ", str(message or "")).strip()
    if len(text) <= max(1, int(limit)):
        return text
    return text[: max(1, int(limit)) - 1].rstrip(" •") + "…"


def notification_reason(error: object) -> str:
    text = str(error or "").strip().lower()
    checks = (
        (("401", "unauthorized", "invalid api", "api key"), "UNAUTHORIZED"),
        (("timeout", "timed out"), "REQUEST TIMED OUT"),
        (("503", "522", "service unavailable", "temporarily unavailable"), "SERVICE UNAVAILABLE"),
        (("404",), "HTTP 404"),
        (("connection", "network", "dns", "name resolution", "remote disconnected"), "NETWORK ERROR"),
        (("requested s", "episode file", "not found in zip", "not found in archive", "could not be selected"), "EPISODE FILE MISSING"),
        (("bad zip", "invalid zip", "invalid archive", "readable zip", "archive is empty", "no supported subtitle", "no subtitle files"), "INVALID ARCHIVE"),
        (("too few cue", "could not be read", "cannot be read", "tidak dapat dibaca", "subtitle hanya memiliki", "parser", "decode"), "FILE READ ERROR"),
        (("playback changed",), "PLAYBACK CHANGED"),
        (("kodi", "rejected subtitle", "menolak subtitle"), "KODI REJECTED SUBTITLE"),
        (("no alternative", "tidak ada alternatif", "alternatif subtitle", "all alternatives", "semua alternatif"), "NO ALTERNATIVES"),
        (("metadata", "imdb", "video info", "judul serial tidak tersedia"), "VIDEO INFO NOT AVAILABLE"),
        (("permission", "access denied", "denied"), "ACCESS DENIED"),
        (("write", "disk full", "read-only"), "WRITE ERROR"),
        (("file missing", "file not found", "file profil", "tidak ditemukan"), "FILE MISSING"),
        (("no session", "belum ada kumpulan", "profil aktif belum", "referensi inggris manual belum"), "NO SESSION"),
        (("no result", "not found", "tidak ditemukan"), "NO RESULTS"),
    )
    for needles, label in checks:
        if any(needle in text for needle in needles):
            return label
    return "UNKNOWN ERROR"


def failure_message(prefix: str, error: object) -> str:
    return compact_notification("%s • %s" % (prefix, notification_reason(error)))


def notify(message: str, warning: bool = False, timeout: int = 4500) -> None:
    if not setting_bool("notifications", True):
        return
    message = compact_notification(message)
    icon = getattr(xbmcgui, "NOTIFICATION_WARNING", "") if warning else getattr(xbmcgui, "NOTIFICATION_INFO", "")
    try:
        xbmcgui.Dialog().notification(ADDON_NAME, message, icon, timeout)
    except Exception:
        log("notification failed: %s" % message, LOG_WARNING)


def json_rpc(method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        payload["params"] = params
    try:
        response = xbmc.executeJSONRPC(json.dumps(payload))
        parsed = json.loads(response)
        if "error" in parsed:
            log("JSON-RPC %s error: %s" % (method, parsed["error"]), LOG_WARNING)
        return parsed.get("result", {})
    except Exception as exc:
        log("JSON-RPC %s failed: %s" % (method, exc), LOG_WARNING)
        return {}


def read_bytes(path: str) -> bytes:
    handle = xbmcvfs.File(path)
    try:
        data = handle.readBytes()
        if isinstance(data, str):
            return data.encode("latin-1", "ignore")
        return bytes(data)
    finally:
        handle.close()


def write_bytes(path: str, payload: bytes) -> None:
    parent = os.path.dirname(path)
    if parent:
        xbmcvfs.mkdirs(parent)
    handle = xbmcvfs.File(path, "w")
    try:
        try:
            handle.write(payload)
        except TypeError:
            handle.write(payload.decode("latin-1"))
    finally:
        handle.close()


def write_text(path: str, text: str) -> None:
    parent = os.path.dirname(path)
    if parent:
        xbmcvfs.mkdirs(parent)
    handle = xbmcvfs.File(path, "w")
    try:
        handle.write(text)
    finally:
        handle.close()


def read_text(path: str) -> str:
    raw = read_bytes(path)
    for encoding in ("utf-8-sig", "utf-8", "cp1252", "latin-1"):
        try:
            return raw.decode(encoding)
        except UnicodeDecodeError:
            continue
    return raw.decode("utf-8", "replace")


def safe_filename(value: str, fallback: str = "subtitle") -> str:
    value = re.sub(r'[\\/*?:"<>|]+', "_", value or "")
    value = re.sub(r"\s+", " ", value).strip().strip(".")
    return value or fallback


def norm_tokens(value: str) -> List[str]:
    text = (value or "").lower()
    text = text.replace("web-dl", "webdl").replace("web dl", "webdl")
    text = text.replace("blu-ray", "bluray").replace("blu ray", "bluray")
    text = text.replace("h.265", "h265").replace("h.264", "h264")
    return [token for token in re.split(r"[^a-z0-9]+", text) if token]


@dataclass
class Cue:
    start_ms: int
    end_ms: int
    text: str = ""

    def normalized(self) -> "Cue":
        start = max(0, int(self.start_ms))
        end = max(start + 80, int(self.end_ms))
        return Cue(start, end, self.text)


@dataclass
class MediaContext:
    path: str
    title: str
    year: int = 0
    imdb_id: str = ""
    is_episode: bool = False
    show_title: str = ""
    season: int = 0
    episode: int = 0
    duration_ms: int = 0
    filename: str = ""
    media_type: str = "unknown"
    library_id: int = -1
    episode_imdb_id: str = ""
    show_year: int = 0
    tvshow_id: int = -1

    @property
    def stem(self) -> str:
        return os.path.splitext(os.path.basename(self.path))[0]

    @property
    def episode_tag(self) -> str:
        if not self.is_episode:
            return ""
        return "S%02dE%02d" % (self.season, self.episode)


@dataclass
class SubtitleTrack:
    track_number: int
    codec_id: str = ""
    language: str = "und"
    name: str = ""
    forced: bool = False
    default: bool = False
    hearing_impaired: bool = False
    order: int = 0
    cues: List[Cue] = field(default_factory=list)
    ads_removed: int = 0

    @property
    def cue_count(self) -> int:
        return len(self.cues)

    @property
    def coverage_ms(self) -> int:
        if not self.cues:
            return 0
        return max(c.end_ms for c in self.cues) - min(c.start_ms for c in self.cues)


@dataclass
class SubtitleCandidate:
    subtitle_id: str
    language: str
    release_info: str
    rating: float = 0.0
    rating_votes: int = 0
    download_count: int = 0
    hearing_impaired: bool = False
    link: str = ""
    raw: Dict[str, Any] = field(default_factory=dict)
    owner: str = ""
    score: float = 0.0
    popularity_score: float = 0.0


@dataclass
class SyncResult:
    cues: List[Cue]
    confidence: float
    global_offset_ms: int
    median_error_ms: float
    p90_error_ms: float
    overlap_ratio: float
    knots: List[Tuple[int, int]] = field(default_factory=list)


def percentile(values: Sequence[float], pct: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(float(v) for v in values)
    if len(ordered) == 1:
        return ordered[0]
    idx = (len(ordered) - 1) * pct
    lo = int(idx)
    hi = min(len(ordered) - 1, lo + 1)
    frac = idx - lo
    return ordered[lo] * (1.0 - frac) + ordered[hi] * frac


def now_ts() -> int:
    return int(time.time())

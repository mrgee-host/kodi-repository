# -*- coding: utf-8 -*-
import os
import sqlite3
import time
import traceback

import xbmc
import xbmcgui
import xbmcvfs


ADDON_NAME = "AKL Texture Cache Cleaner"


def log(msg):
    xbmc.log("[{}] {}".format(ADDON_NAME, msg), xbmc.LOGINFO)


def translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return xbmc.translatePath(path)


def dialog_ok(message):
    # Kodi 22 alpha wrapper in this setup accepts only 2 args.
    try:
        xbmcgui.Dialog().ok(ADDON_NAME, message)
    except Exception:
        xbmcgui.Dialog().notification(ADDON_NAME, message, xbmcgui.NOTIFICATION_INFO, 6000)


def dialog_yesno(message):
    # Use only 2 args to avoid Kodi 22 alpha wrapper mismatch.
    return xbmcgui.Dialog().yesno(ADDON_NAME, message)


def find_latest_textures_db():
    db_dir = translate("special://profile/Database/")
    if not os.path.isdir(db_dir):
        return None
    candidates = []
    for name in os.listdir(db_dir):
        n = name.lower()
        if n.startswith("textures") and n.endswith(".db"):
            full = os.path.join(db_dir, name)
            try:
                candidates.append((os.path.getmtime(full), full))
            except Exception:
                pass
    if not candidates:
        return None
    candidates.sort(reverse=True)
    return candidates[0][1]


def is_akl_asset_url(url):
    if not url:
        return False
    u = str(url).replace("\\", "/").lower()
    needles = [
        "plugin.program.akl/asset-art",
        "plugin.program.akl%2fasset-art",
        "addon_data/plugin.program.akl/asset-art",
        "addon_data%2fplugin.program.akl%2fasset-art",
    ]
    return any(n in u for n in needles)


def delete_thumb(cachedurl):
    if not cachedurl:
        return False
    cachedurl = str(cachedurl).replace("\\", "/").lstrip("/")
    thumb_path = os.path.join(translate("special://profile/Thumbnails/"), *cachedurl.split("/"))
    try:
        if xbmcvfs.exists(thumb_path):
            return bool(xbmcvfs.delete(thumb_path))
        if os.path.exists(thumb_path):
            os.remove(thumb_path)
            return True
    except Exception:
        log("Failed deleting thumb: {}".format(thumb_path))
    return False


def clean():
    db_path = find_latest_textures_db()
    if not db_path:
        dialog_ok("Textures DB tidak ditemukan.")
        return

    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, "Scanning AKL texture cache...")

    backup_path = db_path + ".akl-cleaner-bak-" + time.strftime("%Y%m%d-%H%M%S")
    try:
        xbmcvfs.copy(db_path, backup_path)
    except Exception:
        log("Backup failed: {}".format(backup_path))

    con = None
    found = []
    deleted_files = 0

    try:
        con = sqlite3.connect(db_path)
        cur = con.cursor()

        cur.execute("SELECT id, url, cachedurl FROM texture")
        rows = cur.fetchall()

        total = max(len(rows), 1)
        for idx, (tid, url, cachedurl) in enumerate(rows):
            if idx % 500 == 0:
                pct = int((idx / total) * 40)
                dialog.update(pct, "Scanning AKL texture cache...")
                if dialog.iscanceled():
                    dialog.close()
                    return
            if is_akl_asset_url(url):
                found.append((tid, url, cachedurl))

        if not found:
            dialog.close()
            dialog_ok("Cache AKL asset-art tidak ditemukan.\nKalau gambar belum berubah, restart Kodi.")
            return

        dialog.close()
        msg = "Ditemukan {} cache AKL asset-art.\n\nHapus cache AKL artwork saja?\nCache skin lain dilewati.".format(len(found))
        if not dialog_yesno(msg):
            return

        dialog = xbmcgui.DialogProgress()
        dialog.create(ADDON_NAME, "Deleting AKL texture cache...")

        cur.execute("BEGIN")
        total_found = max(len(found), 1)
        for idx, (tid, url, cachedurl) in enumerate(found):
            if idx % 50 == 0:
                pct = int((idx / total_found) * 95)
                dialog.update(pct, "Deleting AKL texture cache...")
                if dialog.iscanceled():
                    con.rollback()
                    dialog.close()
                    return

            if delete_thumb(cachedurl):
                deleted_files += 1

            try:
                cur.execute("DELETE FROM sizes WHERE idtexture=?", (tid,))
            except Exception:
                pass

            cur.execute("DELETE FROM texture WHERE id=?", (tid,))

        con.commit()

        try:
            cur.execute("VACUUM")
        except Exception:
            pass

        dialog.update(100, "Done")
        xbmc.sleep(300)
        dialog.close()

        dialog_ok("Cache AKL dihapus: {}\nFile thumbnail dihapus: {}\n\nRestart Kodi lalu AKL Rebuild views.".format(len(found), deleted_files))

        try:
            xbmc.executebuiltin("ReloadSkin()")
        except Exception:
            pass

    except Exception as exc:
        try:
            if con:
                con.rollback()
        except Exception:
            pass
        try:
            dialog.close()
        except Exception:
            pass
        log(traceback.format_exc())
        dialog_ok("Gagal membersihkan cache.\n{}".format(str(exc)))
    finally:
        try:
            if con:
                con.close()
        except Exception:
            pass


if __name__ == "__main__":
    clean()

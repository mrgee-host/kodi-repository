AKL Texture Cache Cleaner 1.0.5

Fix:
- Kodi 22 alpha wrapper in this setup accepts Dialog.ok/update with fewer args.
- v1.0.5 uses only safe 2-arg dialog calls.
- v1.0.4 likely already deleted cache, then crashed only on final OK dialog.

Filter:
plugin.program.akl/asset-art

Does not touch:
- Arctic Fuse blur cache
- skin cache
- full Thumbnails folder
- akl.db
- artwork source files

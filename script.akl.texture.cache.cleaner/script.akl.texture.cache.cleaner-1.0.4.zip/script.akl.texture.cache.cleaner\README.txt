AKL Texture Cache Cleaner 1.0.4

Fix dari kodi.log:
- Kodi 22 Python wrapper di build user hanya menerima DialogProgress.update(percent, message).
- v1.0.3 masih memanggil update(percent, message, detail), sehingga error:
  TypeError: function takes at most 2 arguments (3 given)

v1.0.4:
- semua progress update dibuat 2 argumen saja
- semua Dialog.ok dibuat 2 argumen saja

Filter tetap hanya:
plugin.program.akl/asset-art

Tidak menyentuh:
- Arctic Fuse blur cache
- cache skin lain
- seluruh folder Thumbnails
- akl.db
- file artwork asli

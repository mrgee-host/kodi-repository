# -*- coding: utf-8 -*-
import os
import sqlite3
import time
import traceback

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs


ADDON_NAME = "AKL Texture Cache Cleaner"


def log(msg):
    xbmc.log("[{}] {}".format(ADDON_NAME, msg), xbmc.LOGINFO)


def translate(path):
    try:
        return xbmcvfs.translatePath(path)
    except Exception:
        return xbmc.translatePath(path)


def find_latest_textures_db():
    db_dir = translate("special://profile/Database/")
    if not os.path.isdir(db_dir):
        return None

    candidates = []
    for name in os.listdir(db_dir):
        lower = name.lower()
        if lower.startswith("textures") and lower.endswith(".db"):
            full = os.path.join(db_dir, name)
            try:
                candidates.append((os.path.getmtime(full), full))
            except Exception:
                pass

    if not candidates:
        return None

    candidates.sort(reverse=True)
    return candidates[0][1]


def is_akl_asset_url(url):
    if not url:
        return False

    u = str(url).replace("\\", "/").lower()

    needles = [
        "plugin.program.akl/asset-art",
        "plugin.program.akl%2fasset-art",
        "addon_data/plugin.program.akl/asset-art",
        "addon_data%2fplugin.program.akl%2fasset-art",
    ]

    return any(n in u for n in needles)


def delete_thumb(cachedurl):
    if not cachedurl:
        return False

    cachedurl = str(cachedurl).replace("\\", "/").lstrip("/")
    thumb_path = os.path.join(translate("special://profile/Thumbnails/"), *cachedurl.split("/"))

    deleted = False
    try:
        if xbmcvfs.exists(thumb_path):
            deleted = xbmcvfs.delete(thumb_path)
        elif os.path.exists(thumb_path):
            os.remove(thumb_path)
            deleted = True
    except Exception:
        log("Failed deleting thumb: {}".format(thumb_path))

    return deleted


def clean():
    db_path = find_latest_textures_db()
    if not db_path:
        xbmcgui.Dialog().ok(ADDON_NAME, "Textures DB tidak ditemukan.")
        return

    dialog = xbmcgui.DialogProgress()
    dialog.create(ADDON_NAME, "Mencari cache artwork AKL...")

    backup_path = db_path + ".akl-cleaner-bak-" + time.strftime("%Y%m%d-%H%M%S")
    try:
        xbmcvfs.copy(db_path, backup_path)
    except Exception:
        # Continue. Delete query is still safe/filtered.
        log("Backup failed: {}".format(backup_path))

    found = []
    deleted_files = 0

    con = sqlite3.connect(db_path)
    try:
        cur = con.cursor()
        cur.execute("SELECT id, url, cachedurl FROM texture")
        rows = cur.fetchall()

        for idx, row in enumerate(rows):
            if idx % 500 == 0:
                pct = int((idx / max(len(rows), 1)) * 50)
                dialog.update(pct, "Scanning Textures DB...")
                if dialog.iscanceled():
                    return

            tid, url, cachedurl = row
            if is_akl_asset_url(url):
                found.append((tid, url, cachedurl))

        if not found:
            dialog.close()
            xbmcgui.Dialog().ok(
                ADDON_NAME,
                "Cache AKL asset-art tidak ditemukan.\\nKalau gambar belum berubah, restart Kodi."
            )
            return

        msg = "Ditemukan {} cache AKL asset-art.\\n\\nHanya cache AKL artwork yang dihapus. Cache skin lain dilewati.".format(len(found))
        confirm = xbmcgui.Dialog().yesno(
            ADDON_NAME,
            msg,
            nolabel="Batal",
            yeslabel="Hapus"
        )
        if not confirm:
            dialog.close()
            return

        cur.execute("BEGIN")
        for idx, (tid, url, cachedurl) in enumerate(found):
            pct = 50 + int((idx / max(len(found), 1)) * 45)
            dialog.update(pct, "Deleting AKL texture cache...")
            if dialog.iscanceled():
                con.rollback()
                return

            if delete_thumb(cachedurl):
                deleted_files += 1

            # Some Kodi versions have sizes.idtexture.
            try:
                cur.execute("DELETE FROM sizes WHERE idtexture=?", (tid,))
            except Exception:
                pass

            cur.execute("DELETE FROM texture WHERE id=?", (tid,))

        con.commit()
        try:
            cur.execute("VACUUM")
        except Exception:
            pass

    except Exception as exc:
        try:
            con.rollback()
        except Exception:
            pass
        dialog.close()
        log(traceback.format_exc())
        xbmcgui.Dialog().ok(ADDON_NAME, "Gagal membersihkan cache.\n{}".format(str(exc)))
        return
    finally:
        try:
            con.close()
        except Exception:
            pass

    dialog.update(100, "Done")
    xbmc.sleep(300)
    dialog.close()

    xbmcgui.Dialog().ok(
        ADDON_NAME,
        "Selesai.",
        "Cache AKL dihapus: {}".format(len(found)),
        "File thumbnail dihapus: {}".format(deleted_files),
        "Restart Kodi lalu AKL Rebuild views."
    )

    try:
        xbmc.executebuiltin("ReloadSkin()")
    except Exception:
        pass


if __name__ == "__main__":
    clean()

# -*- coding: utf-8 -*-
import xbmcaddon
import xbmcgui

from . import log
from . import settings
from lib import artworkdb
from lib.libs import mediatypes
from .cache import ArtworkCache
from .kodi_library import (
    current_item,
    get_movie_set_details,
    get_movie_sets,
    refresh_container,
    resolve_set_id,
    set_movie_poster,
    set_movieset_poster,
)
from .matcher import match_movie
from .models import ApplyReport, SearchPage
from .tpdb_client import (
    TPDbAuthenticationError,
    TPDbClient,
    TPDbError,
    TPDbVerificationRequired,
    normalize_posters_url,
)
from .ui import choose_poster, choose_search_page, confirm_set_preview, input_password, input_text, notify, ok, progress


def _handle_errors(function):
    try:
        return function()
    except TPDbVerificationRequired as exc:
        log.warning(str(exc))
        ok("TPDb verification required", str(exc) + "\n\nOpen Settings > Advanced and enter a manual Cookie header if needed.")
    except TPDbAuthenticationError as exc:
        log.warning(str(exc))
        ok("TPDb login", str(exc))
    except TPDbError as exc:
        log.error(str(exc))
        ok("TPDb error", str(exc))
    except Exception as exc:
        log.error("Unexpected error: {!r}".format(exc))
        ok("TPDb Artwork Picker", "Unexpected error: {}".format(exc))


def _setting_bool(addon, setting_id, default=False):
    return settings.get_bool(setting_id, default, addon=addon)


def _mirror_tpdb_poster_03311(mediatype, dbid, title, path):
    """Mirror an explicitly selected TPDb poster into LAC's artwork cache.

    This is a direct write-through for the TPDb context workflow only.  It does
    not scan, migrate, repair, or rewrite unrelated cache rows.
    """
    if not dbid or mediatype not in (mediatypes.MOVIE, mediatypes.MOVIESET):
        return
    artworkdb.set_artwork_for_key(
        mediatype, int(dbid), title or '', 'poster', path or '', 'TPDb',
        'MANUAL' if path else 'MISSING',
        'Selected from TPDb poster picker' if path else 'Removed by TPDb poster picker',
    )


def _resolve_artwork(client, poster):
    """Return artwork URL/path for Kodi.

    Preview cards intentionally use TPDb's optimized public thumbnails so the
    picker remains responsive.  Library artwork must not use those thumbnails:
    when TPDb exposes an asset ID, store its remote full-size ``view`` endpoint
    in Kodi's art table instead.  Fall back to the optimized thumbnail only for
    unusual cards without an asset ID, and finally to a local download if no
    usable remote URL exists.
    """
    addon = xbmcaddon.Addon()
    use_remote = _setting_bool(addon, "use_remote_art", True)
    if use_remote and poster.asset_id:
        view_url = "https://theposterdb.com/index.php/api/assets/{}/view".format(poster.asset_id)
        log.info("using TPDb full-size remote artwork URL {}".format(view_url))
        return view_url
    if use_remote and poster.thumb_url:
        log.warning("TPDb asset ID unavailable; using optimized remote thumbnail {}".format(poster.thumb_url))
        return poster.thumb_url
    if use_remote:
        log.warning("remote artwork URL unavailable; falling back to local cache")
    return ArtworkCache().store_asset(client, poster)


def run_login():
    _handle_errors(_run_login)


def _run_login():
    addon = xbmcaddon.Addon()
    identity = settings.get_text("tpdb_email", addon=addon).strip()
    password = settings.get_text("tpdb_password", addon=addon)
    if not identity:
        identity = input_text("TPDb email / username")
    if not identity:
        return
    if not password:
        password = input_password("TPDb password")
    if not password:
        return
    remember = _setting_bool(addon, "remember_password", False)
    client = TPDbClient()
    client.login(identity, password, remember=remember)
    settings.set_text("tpdb_email", identity, addon=addon)
    if remember:
        settings.set_text("tpdb_password", password, addon=addon)
    else:
        settings.set_text("tpdb_password", "", addon=addon)
    ok(
        "TPDb login",
        "Login successful. The session cookie was saved to the Kodi profile. The password was {}saved.".format("" if remember else "not "),
    )


def run_test_session():
    _handle_errors(_run_test_session)


def _run_test_session():
    client = TPDbClient()
    if client.test_saved_session():
        ok("TPDb session", "The saved TPDb login session is active.")
    else:
        ok("TPDb session", "No active saved TPDb login session was found. Run Login / refresh TPDb session.")


def run_clear_session():
    _handle_errors(_run_clear_session)


def run_clear_art_cache():
    _handle_errors(_run_clear_art_cache)


def _run_clear_session():
    addon = xbmcaddon.Addon()
    client = TPDbClient()
    client.clear_saved_session()
    settings.set_text("tpdb_password", "", addon=addon)
    ok("TPDb session", "The saved TPDb session cookie and stored password were cleared.")


def _run_clear_art_cache():
    answer = xbmcgui.Dialog().yesno(
        "TPDb Artwork Picker",
        "Delete all artwork files from the add-on local cache?\n\n"
        "Do this only after old artwork has been reapplied in remote mode. "
        "Library artwork that still points to those local files will break if the cache is cleared too early.",
    )
    if not answer:
        return
    removed = ArtworkCache().clear()
    ok("TPDb Artwork Picker", "The add-on local artwork cache was cleared. Deleted items: {}".format(removed))


def run_auto_context():
    _handle_errors(_run_auto_context)


def _run_auto_context():
    item = current_item()
    dbtype = (item.get("dbtype") or "").lower()
    title = item.get("title") or ""
    dbid = int(item.get("dbid") or 0)

    if dbtype == "movie":
        _choose_and_apply_movie(dbid, title, item.get("year"))
        return

    if dbtype in ("set", "movieset"):
        setid = resolve_set_id(dbid, title)
        if setid:
            _choose_and_apply_set(setid, title)
            return

    # Some skins do not populate the media type for movie sets. Match the title
    # against Kodi movie sets without relying on an ambiguous item DBID.
    setid = resolve_set_id(0, title)
    if setid:
        _choose_and_apply_set(setid, title)
        return

    choice = xbmcgui.Dialog().select(
        "TPDb Artwork Picker",
        ["Choose movie poster", "Apply collection set", "Cancel"],
    )
    if choice == 0:
        _choose_and_apply_movie(dbid if dbtype == "movie" else 0, title, item.get("year"))
    elif choice == 1:
        _choose_and_apply_set(0, title)

def run_movie_context():
    _handle_errors(_run_movie_context)


def _run_movie_context():
    item = current_item()
    if item["dbtype"] != "movie" or not item["dbid"]:
        ok("TPDb Artwork Picker", "Choose a movie that is already in the Kodi library.")
        return
    _choose_and_apply_movie(item["dbid"], item["title"], item["year"])


def run_set_context():
    _handle_errors(_run_set_context)


def _run_set_context():
    item = current_item()
    setid = resolve_set_id(item["dbid"], item["title"])
    if not setid:
        ok("TPDb Artwork Picker", "The Kodi movie set could not be identified. Try running the add-on from the Movie sets view.")
        return
    _choose_and_apply_set(setid, item["title"])



def run_choose_library_set():
    _handle_errors(_run_choose_library_set)


def _run_choose_library_set():
    sets = get_movie_sets()
    if not sets:
        ok("TPDb Artwork Picker", "The Kodi library does not contain any movie sets.")
        return
    items = [xbmcgui.ListItem(label=item.get("title", "Movie set")) for item in sets]
    selected = xbmcgui.Dialog().select("Choose Kodi movie set", items, useDetails=True)
    if selected < 0:
        return
    item = sets[selected]
    _choose_and_apply_set(int(item.get("setid")), item.get("title", ""))

def run_manual_movie():
    _handle_errors(_run_manual_movie)


def _run_manual_movie():
    title = input_text("Movie title")
    if not title:
        return
    year = input_text("Year (optional)")
    _choose_and_apply_movie(0, title, year)


def run_manual_set():
    _handle_errors(_run_manual_set)


def _run_manual_set():
    title = input_text("Collection title")
    if not title:
        return
    _choose_and_apply_set(0, title)


def _choose_and_apply_movie(movieid, title, year):
    client = TPDbClient()
    pages = client.search_pages("{} ({})".format(title, year) if year else title, "movies")
    page = choose_search_page(pages, "Choose TPDb movie page")
    if not page:
        ok("TPDb Artwork Picker", "No matching TPDb movie page was found.")
        return
    posters = client.get_page_posters(page.url)
    poster = choose_poster(posters, "Choose TPDb poster")
    if not poster:
        return
    if not movieid:
        ok("TPDb Artwork Picker", "Manual mode is preview-only. Run the add-on from a library movie context menu to apply a poster.")
        return
    path = _resolve_artwork(client, poster)
    set_movie_poster(movieid, path)
    _mirror_tpdb_poster_03311(mediatypes.MOVIE, movieid, title, path)
    refresh_container()
    notify("TPDb Artwork Picker", "Poster applied: {}".format(title))


def _choose_and_apply_set(setid, title):
    client = TPDbClient()
    pages = client.search_pages(title, "collections")
    if not pages:
        direct = normalize_posters_url(input_text("TPDb collection URL (/posters/<id>)"))
        if direct:
            pages = [SearchPage(url=direct, label=direct)]
    while True:
        page = choose_search_page(pages, "Choose a TPDb collection", compact=True)
        if not page:
            return
        covers = [poster for poster in client.get_page_posters(page.url) if poster.set_id]
        if not covers:
            ok("TPDb Artwork Picker", "This TPDb collection does not contain any poster sets to choose from.")
            if len(pages) == 1:
                return
            continue
        while True:
            cover = choose_poster(covers, "Choose a poster set", set_mode=True)
            if not cover:
                break
            set_posters = client.get_set_posters(cover.set_id)
            if not set_posters:
                ok("TPDb Artwork Picker", "This TPDb poster set is empty or could not be loaded.")
                continue
            decision = confirm_set_preview(cover, set_posters)
            if decision == "apply":
                break
            # BACK from the preview returns to the poster-set list only.
            # The workflow stays open so another set can be inspected without
            # restarting the collection search.
        else:
            continue
        if cover and set_posters and decision == "apply":
            break
        if len(pages) == 1:
            return
    if not setid:
        ok("TPDb Artwork Picker", "Manual mode is preview-only. Run the add-on from a library movie-set context menu to apply artwork.")
        return

    kodi_set = get_movie_set_details(setid)
    movies = kodi_set.get("movies", [])
    report = ApplyReport()
    used = set()
    progress_dialog = progress("Applying TPDb set", title)
    try:
        set_path = _resolve_artwork(client, cover)
        set_movieset_poster(setid, set_path)
        _mirror_tpdb_poster_03311(
            mediatypes.MOVIESET, setid, kodi_set.get("title") or title, set_path
        )
        report.success.append("{} [Collection]".format(title))
        total = max(1, len(movies))
        for index, movie in enumerate(movies):
            if progress_dialog.iscanceled():
                report.skipped.append("Cancelled by user")
                break
            progress_dialog.update(int(index * 100 / total), movie.get("title", ""))
            poster = match_movie(movie, set_posters, used)
            if not poster:
                report.skipped.append("{} [{}]: matching poster not found".format(movie.get("title", ""), movie.get("year", "")))
                continue
            try:
                path = _resolve_artwork(client, poster)
                set_movie_poster(movie.get("movieid"), path)
                _mirror_tpdb_poster_03311(
                    mediatypes.MOVIE, movie.get("movieid"), movie.get("title", ""), path
                )
                used.add(poster.asset_id)
                report.success.append("{} [{}]".format(movie.get("title", ""), movie.get("year", "")))
            except Exception as exc:
                report.failed.append("{}: {}".format(movie.get("title", ""), exc))
    finally:
        progress_dialog.close()
    refresh_container()
    ok("TPDb Poster Set Report", report.text())

import re
import xbmc
import xbmcgui

from lib.libs import mediatypes
from lib.libs.addonsettings import settings
from lib.libs.pykodi import localize as L

SEASON_NUMBER = 32002
SPECIALS = 20381
UNKNOWN_SOURCE = 32000
CHOOSE_TYPE_HEADER = 32050
CHOOSE_ART_HEADER = 32051
REFRESH_ITEM = 32409
AVAILABLE_COUNT = 32006

def prompt_for_artwork(mediatype, medialabel, availableart, monitor, show_refresh=None):
    if not availableart:
        return None, None

    arttypes = []
    for arttype, artlist in availableart.items():
        if arttype.startswith('season.-1.'):
            # Ignore 'all' seasons artwork, as I can't set artwork for it with JSON
            continue
        label = arttype if not arttype.startswith('season.') else get_seasonlabel(arttype)
        for image in artlist:
            if image.get('existing'):
                arttypes.append({'arttype': arttype, 'label': label, 'count': len(artlist), 'url': image['url']})
                break
        if arttype not in (at['arttype'] for at in arttypes):
            arttypes.append({'arttype': arttype, 'label': label, 'count': len(artlist)})
    arttypes.sort(key=lambda art: sort_arttype(art['arttype']))
    if show_refresh is None:
        show_refresh = mediatype in mediatypes.require_manualid
    typeselectwindow = ArtworkTypeSelector('DialogSelect.xml', settings.addon_path, arttypes=arttypes,
        medialabel=medialabel, show_refresh=bool(show_refresh))
    selectedarttype = None
    selectedart = None
    typelist = [at['arttype'] for at in arttypes]
    while selectedart is None and not monitor.abortRequested():
        # The loop shows the first window if viewer backs out of the second
        selectedarttype = typeselectwindow.prompt()
        if selectedarttype not in typelist:
            return selectedarttype, None
        if not selectedarttype:
            break
        multi = mediatypes.get_artinfo(mediatype, selectedarttype)['multiselect']
        artselectwindow = ArtworkSelector('DialogSelect.xml', settings.addon_path, artlist=availableart[selectedarttype],
            arttype=selectedarttype, medialabel=medialabel, multi=multi)
        selectedart = artselectwindow.prompt()
    return selectedarttype, selectedart

class ArtworkTypeSelector(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, **kwargs):
        super(ArtworkTypeSelector, self).__init__()
        self.arttypes = kwargs.get('arttypes')
        self.medialabel = kwargs.get('medialabel')
        self.show_refresh = kwargs.get('show_refresh')
        self.guilist = None
        self.selected = None

    def prompt(self):
        self.doModal()
        return self.selected

    def onInit(self):
        # This is called every time the window is shown
        if not self.selected:
            self.getControl(1).setLabel("Library Artwork Curator: " + L(CHOOSE_TYPE_HEADER).format(self.medialabel))
            self.getControl(3).setVisible(False)
            self.getControl(5).setVisible(self.show_refresh)
            self.getControl(5).setLabel(L(REFRESH_ITEM))
            self.guilist = self.getControl(6)
            for arttype in self.arttypes:
                listitem = xbmcgui.ListItem(arttype['label'])
                summary = L(AVAILABLE_COUNT).format(arttype['count'])
                listitem.setLabel2(summary)
                # DEPRECATED: Above Krypton and higher (only), below Jarvis and lower (only)
                listitem.setProperty('Addon.Summary', summary)
                listitem.setPath(arttype['arttype'])
                if arttype.get('url'):
                    #xbmc.log(str(arttype)+'artwork_selection_===>PHIL', level=xbmc.LOGINFO)
                    try:
                        listitem.setIconImage(arttype['url'])
                    # DEPRECATED: Above is deprecated in Jarvis, but still works through Krypton (at least)
                    except:
                        listitem.setArt({'icon': arttype['url']})
                self.guilist.addItem(listitem)
        else:
            self.selected = None
        self.setFocus(self.guilist)

    def onClick(self, controlid):
        if controlid == 5:
            self.selected = "!!-Refresh"
            self.close()
        elif controlid == 6:
            item = self.guilist.getSelectedItem()
            #xbmc.log(str(item.getPath())+'===>PHIL', level=xbmc.LOGINFO)
            try:
                self.selected = item.getfilename()
            except:
                self.selected = item.getPath()
            self.close()
        elif controlid == 7:
            self.close()

class ArtworkSelector(xbmcgui.WindowXMLDialog):
    LOAD_MORE_PATH = 'lac://load-more-candidates'
    BROWSE_LOCAL_PATH = 'lac://browse-local-art'

    def __init__(self, *args, **kwargs):
        super(ArtworkSelector, self).__init__()
        self.arttype = kwargs.get('arttype')
        if self.arttype.startswith('season.'):
            if '.0.' in self.arttype:
                self.arttype = 'specials ' + self.arttype.rsplit('.', 1)[1]
            else:
                self.arttype = self.arttype.replace('.', ' ')
        self.medialabel = kwargs.get('medialabel')
        self.multi = kwargs.get('multi', False)
        self.artlist = list(kwargs.get('artlist') or [])
        self.guilist = None
        self.selected = None
        try:
            self.page_size = int(getattr(settings, 'select_candidates_per_provider', 50) or 50)
        except (TypeError, ValueError):
            self.page_size = 50
        if self.page_size < 1:
            self.page_size = 50
        self.provider_limits = {}

    def prompt(self):
        """Returns a single url if not multi,
            else a tuple with item 0 a list of added urls, 1 a list of removed urls,
            None if cancelled"""
        self.doModal()
        return self.selected

    def _provider_text(self, image):
        provider = image.get('provider')
        provider = getattr(provider, 'display', provider)
        if isinstance(provider, int):
            provider = L(provider)
        return provider or 'Unknown provider'

    def _provider_key(self, image):
        provider = image.get('provider')
        return str(getattr(provider, 'sort', None) or getattr(provider, 'display', None) or provider or 'unknown')

    def _visible_images(self):
        if not self.provider_limits:
            keys = []
            for image in self.artlist:
                if image.get('existing') or image.get('manual_current') or image.get('local_art'):
                    continue
                key = self._provider_key(image)
                if key not in keys:
                    keys.append(key)
            for key in keys:
                self.provider_limits[key] = self.page_size
        counts = {}
        visible = []
        hidden = 0
        for image in self.artlist:
            if image.get('existing') or image.get('manual_current') or image.get('local_art'):
                visible.append(image)
                continue
            key = self._provider_key(image)
            counts[key] = counts.get(key, 0) + 1
            if counts[key] <= self.provider_limits.get(key, self.page_size):
                visible.append(image)
            else:
                hidden += 1
        return visible, hidden

    def _make_item(self, image):
        if image.get('local_art'):
            listitem = xbmcgui.ListItem('Local art')
            summary = image.get('local_name') or ''
            listitem.setLabel2(summary)
            listitem.setProperty('Addon.Summary', summary)
            try:
                listitem.setIconImage(image.get('preview') or image.get('url') or '')
            except Exception:
                listitem.setArt({'icon': image.get('preview') or image.get('url') or ''})
            listitem.setPath(image.get('url') or '')
            if self._is_selected_url(image.get('url'), image.get('existing')):
                listitem.select(True)
            return listitem
        provider = self._provider_text(image)
        secondprovider = image.get('second provider')
        if secondprovider:
            if isinstance(secondprovider, int):
                secondprovider = L(secondprovider)
            provider = '{0}, {1}'.format(provider, secondprovider)
        title = image.get('title')
        if not title and 'subtype' in image:
            title = image['subtype'].display
        language = xbmc.convertLanguage(image['language'], xbmc.ENGLISH_NAME) if image.get('language') else None
        if not title:
            title = language
        if title and len(title) < 20 and not secondprovider:
            label = '{0} from {1}'.format(title, provider)
            summary = language if language and language != title else ''
        else:
            label = provider
            if language and language != title:
                title = language + ' ' + title
            summary = title if title else ''
        rating = image.get('rating')
        size = image.get('size')
        if (rating or size) and summary:
            summary += '\n'
        if size:
            summary += image['size'].display
        if rating and size:
            summary += '   '
        if rating:
            summary += image['rating'].display
        listitem = xbmcgui.ListItem(label)
        listitem.setLabel2(summary)
        listitem.setProperty('Addon.Summary', summary)
        try:
            listitem.setIconImage(image['preview'])
        except:
            listitem.setArt({'icon': image['preview']})
        listitem.setPath(image['url'])
        if self._is_selected_url(image.get('url'), image.get('existing')):
            listitem.select(True)
        return listitem

    def _make_browse_local_item(self):
        item = xbmcgui.ListItem('Browse...')
        item.setLabel2('Choose a local image file')
        item.setProperty('Addon.Summary', 'Choose a local image file')
        item.setPath(self.BROWSE_LOCAL_PATH)
        try:
            item.setIconImage('DefaultFolder.png')
        except Exception:
            item.setArt({'icon': 'DefaultFolder.png'})
        return item

    def _browse_local_art(self):
        try:
            path = xbmcgui.Dialog().browseSingle(
                2, 'Choose local artwork', '', '.jpg|.jpeg|.png|.webp|.bmp',
                True, False, '')
        except Exception:
            path = ''
        return path or ''

    def _make_load_more_item(self, hidden):
        label = 'Load more candidates ({0} hidden)'.format(hidden)
        item = xbmcgui.ListItem(label)
        item.setLabel2('Shows the next {0} candidates from each provider'.format(self.page_size))
        item.setProperty('Addon.Summary', 'Shows the next {0} candidates from each provider'.format(self.page_size))
        item.setPath(self.LOAD_MORE_PATH)
        return item

    def _is_selected_url(self, url, existing=False):
        selected = bool(existing)
        if self.multi and self.selected:
            added, removed = self.selected
            if url in added:
                selected = True
            if url in removed:
                selected = False
        return selected

    def _rebuild_list(self):
        try:
            self.guilist.reset()
        except Exception:
            pass
        visible, hidden = self._visible_images()
        local_images = [image for image in visible if image.get('local_art')]
        other_images = [image for image in visible if not image.get('local_art')]
        for image in local_images:
            self.guilist.addItem(self._make_item(image))
        # Deliberately no 'No art' action. Browse is always available; Local art
        # exists only when a real file was discovered in Kodi's MSIF.
        self.guilist.addItem(self._make_browse_local_item())
        for image in other_images:
            self.guilist.addItem(self._make_item(image))
        if hidden:
            self.guilist.addItem(self._make_load_more_item(hidden))

    def _load_more(self):
        keys = set()
        for image in self.artlist:
            if image.get('existing') or image.get('manual_current') or image.get('local_art'):
                continue
            keys.add(self._provider_key(image))
        for key in keys:
            self.provider_limits[key] = self.provider_limits.get(key, self.page_size) + self.page_size
        self._rebuild_list()
        self.setFocus(self.guilist)

    def onInit(self):
        self.getControl(1).setLabel("Library Artwork Curator: " + L(CHOOSE_ART_HEADER).format(self.arttype, self.medialabel))
        self.getControl(3).setVisible(False)
        self.getControl(5).setVisible(self.multi)
        self.getControl(5).setLabel('$LOCALIZE[186]')
        self.guilist = self.getControl(6)
        self._rebuild_list()
        self.setFocus(self.guilist)

    def _selected_path(self, item):
        try:
            return item.getfilename()
        except:
            return item.getPath()

    def onClick(self, controlid):
        if controlid == 6:
            item = self.guilist.getSelectedItem()
            path = self._selected_path(item)
            if path == self.LOAD_MORE_PATH:
                self._load_more()
                return
            if path == self.BROWSE_LOCAL_PATH:
                path = self._browse_local_art()
                if not path:
                    return
                if self.multi:
                    if self.selected is None:
                        self.selected = ([], [])
                    if path not in self.selected[0]:
                        self.selected[0].append(path)
                    if path in self.selected[1]:
                        self.selected[1].remove(path)
                    self.close()
                else:
                    self.selected = path
                    self.close()
                return
            if self.multi:
                if self.selected is None:
                    self.selected = ([], [])
                self.toggleitemlists(path, item.isSelected())
                item.select(not item.isSelected())
            else:
                self.selected = path
                self.close()
        elif controlid == 5:
            if self.multi and self.selected is None:
                self.selected = ([], [])
            self.close()
        elif controlid == 7:
            self.selected = None
            self.close()

    def toggleitemlists(self, filename, selected):
        removefrom = self.selected[0] if selected else self.selected[1]
        appendto = self.selected[1] if selected else self.selected[0]
        if filename in removefrom:
            removefrom.remove(filename)
        else:
            appendto.append(filename)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_PREVIOUS_MENU):
            self.selected = None
            self.close()

def get_seasonlabel(arttype):
    season = arttype.split('.')
    if season[1] == '0':
        return '{0}: {1}'.format(L(SPECIALS), season[2])
    elif season[1] != '-1':
        return '{0}: {1}'.format(L(SEASON_NUMBER).format(season[1]), season[2])

def sort_arttype(arttype, naturalsortresplit=re.compile('([0-9]+)')):
    # Manual Select Artwork order. Keep this aligned with the visible Artwork
    # types ON/OFF settings: poster, fanart, clearlogo, clearart, discart, then
    # the remaining types. Season-prefixed entries still group by season first.
    preferred_order = {
        'poster': 0,
        'fanart': 1,
        'clearlogo': 2,
        'clearart': 3,
        'discart': 4,
        'landscape': 5,
        'thumb': 6,
        'keyart': 7,
        'banner': 8,
        'logo': 9,
        'characterart': 10,
    }
    value = arttype
    result = []
    if arttype.startswith('season.0'):
        result.append(u'\u9999')
        value = arttype.rsplit('.', 1)[-1]
    elif arttype.startswith('season.'):
        result.append(u'\u9998')
        value = arttype.rsplit('.', 1)[-1]
    base = value.rstrip('0123456789')
    result.append(preferred_order.get(base, 999))
    result.extend(int(text) if text.isdigit() else text.lower() for text in re.split(naturalsortresplit, arttype))
    return result

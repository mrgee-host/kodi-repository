import xbmc
import os
import glob
import sqlite3
import xbmcvfs
from itertools import chain
from lib.libs import mediatypes, pykodi
from lib.libs.pykodi import json, log

typemap = {
    mediatypes.MOVIE: ('Movie', ['art', 'imdbnumber', 'file', 'premiered', 'uniqueid', 'setid'], None),
    mediatypes.MOVIESET: ('MovieSet', ['art'], {'movies': {'properties': ['art', 'file']}}),
    mediatypes.TVSHOW: ('TVShow', ['art', 'imdbnumber', 'season', 'file', 'premiered', 'uniqueid'], None),
    mediatypes.EPISODE: ('Episode', ['art', 'uniqueid', 'tvshowid', 'season', 'episode', 'file', 'showtitle'], None),
    mediatypes.SEASON: ('Season', ['season', 'art', 'tvshowid', 'showtitle'], None),
}

def get_setting_value(settingid, default=''):
    request = get_base_json_request('Settings.GetSettingValue')
    request['params']['setting'] = settingid
    result = pykodi.execute_jsonrpc(request)
    if check_json_result(result, 'value', request):
        return result['result'].get('value', default)
    return default


def get_item_details(dbid, mediatype):
    mapped = typemap[mediatype]
    request = get_base_json_request('VideoLibrary.Get{0}Details'.format(mapped[0]))
    request['params'][mediatype + 'id'] = dbid
    request['params']['properties'] = mapped[1]
    if mapped[2]:
        request['params'].update(mapped[2])
    result = pykodi.execute_jsonrpc(request)
    key = mediatype + 'details'
    if check_json_result(result, key, request):
        return result['result'][key]

def get_item_list(mediatype, extraparams=None, overrideprops=None):
    request, result = _inner_get_item_list(mediatype, extraparams, overrideprops)
    key = mediatype + 's'
    return result['result'][key] if check_json_result(result, key, request) else []

def _inner_get_item_list(mediatype, extraparams=None, overrideprops=None):
    mapped = typemap[mediatype]
    request = get_base_json_request('VideoLibrary.Get{0}s'.format(mapped[0]))
    request['params']['sort'] = {'method': 'sorttitle', 'order': 'ascending'}
    request['params']['properties'] = mapped[1] if overrideprops is None else overrideprops
    if extraparams:
        request['params'].update(extraparams)
    return request, pykodi.execute_jsonrpc(request)

def gen_chunked_item_list(mediatype, extraparams=None, overrideprops=None, chunksize=1000):
    if mediatype == mediatypes.EPISODE:
        chunksize *= 4
    params = dict(extraparams or {})
    total, start = None, 0
    while total is None or start < total:
        params['limits'] = {'start': start, 'end': start + chunksize}
        request, result = _inner_get_item_list(mediatype, params, overrideprops)
        key = mediatype + 's'
        if not check_json_result(result, key, request):
            break
        limits = result['result']['limits']
        total, start = limits['total'], limits['end']
        yield result['result'][key]

def get_tvshows(moreprops=False, includeprops=True):
    request = get_base_json_request('VideoLibrary.GetTVShows')
    if includeprops:
        request['params']['properties'] = typemap[mediatypes.TVSHOW][1] + (['year', 'plot'] if moreprops else [])
    request['params']['sort'] = {'method': 'sorttitle', 'order': 'ascending'}
    result = pykodi.execute_jsonrpc(request)
    return result['result']['tvshows'] if check_json_result(result, 'tvshows', request) else []

def get_episodes(tvshow_id=None, limit=None):
    params = {'sort': {'method': 'dateadded', 'order': 'descending'}}
    if tvshow_id:
        params['tvshowid'] = tvshow_id
    if limit:
        params['limits'] = {'end': limit}
    return get_item_list(mediatypes.EPISODE, params, typemap[mediatypes.EPISODE][1])

def get_seasons(tvshow_id=-1):
    request = get_base_json_request('VideoLibrary.GetSeasons')
    if tvshow_id != -1:
        request['params']['tvshowid'] = tvshow_id
    request['params']['properties'] = typemap[mediatypes.SEASON][1]
    result = pykodi.execute_jsonrpc(request)
    return result['result']['seasons'] if check_json_result(result, 'seasons', request) else []

def set_item_details(dbid, mediatype, **details):
    mapped = typemap[mediatype]
    request = get_base_json_request('VideoLibrary.Set{0}Details'.format(mapped[0]))
    request['params'] = details
    request['params'][mediatype + 'id'] = dbid
    result = pykodi.execute_jsonrpc(request)
    if not check_json_result(result, 'OK', request):
        log(result)

def get_textures(url=None):
    request = get_base_json_request('Textures.GetTextures')
    request['params']['properties'] = ['url']
    if url is not None:
        request['params']['filter'] = {'field': 'url', 'operator': 'is', 'value': url}
    result = pykodi.execute_jsonrpc(request)
    return result['result']['textures'] if check_json_result(result, 'textures', request) else []

def remove_texture(textureid):
    request = get_base_json_request('Textures.RemoveTexture')
    request['params']['textureid'] = textureid
    result = pykodi.execute_jsonrpc(request)
    if not check_json_result(result, 'OK', request):
        log(result)

def remove_texture_byurl(url):
    for texture in get_textures(url):
        remove_texture(texture['textureid'])

def get_base_json_request(method):
    return {'jsonrpc': '2.0', 'method': method, 'params': {}, 'id': 1}

def check_json_result(result, result_key, request):
    if 'error' in result:
        raise JSONException(request, result)
    return 'result' in result and (not result_key or result_key in result['result'])

class JSONException(Exception):
    def __init__(self, request, result):
        self.json_request = request
        self.json_result = result
        super(JSONException, self).__init__('JSON-RPC error. Request: {0} Result: {1}'.format(json.dumps(request), json.dumps(result)))


# Read the canonical episode file directly from MyVideos when JSON-RPC is incomplete.
def get_episode_file_from_database(episodeid):
    try:
        database_dir = xbmcvfs.translatePath('special://database')
        candidates = glob.glob(os.path.join(database_dir, 'MyVideos*.db'))
        if not candidates:
            return ''
        db_path = max(candidates, key=lambda value: os.path.getmtime(value))
        conn = sqlite3.connect('file:{0}?mode=ro'.format(db_path.replace('\\', '/')), uri=True)
        try:
            row = conn.execute("""
                SELECT COALESCE(p.strPath,''), COALESCE(f.strFilename,'')
                  FROM episode e
                  JOIN files f ON f.idFile=e.idFile
                  JOIN path p ON p.idPath=f.idPath
                 WHERE e.idEpisode=?
                 LIMIT 1
            """, (int(episodeid),)).fetchone()
        finally:
            conn.close()
        if not row:
            return ''
        return os.path.normpath(os.path.join(row[0], row[1]))
    except Exception as exc:
        log('Episode canonical file lookup failed for {0}: {1}'.format(episodeid, exc), xbmc.LOGWARNING)
        return ''

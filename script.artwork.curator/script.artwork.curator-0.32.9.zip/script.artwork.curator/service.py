import xbmc
import xbmcgui
import traceback
import time
from itertools import chain

from lib.artworkprocessor import ArtworkProcessor
from lib.libs import mediainfo as info, mediatypes, pykodi, quickjson
from lib.libs.addonsettings import settings
from lib import runtrace, artworkdb
from lib.libs.pykodi import log, json

STATUS_IDLE = 'idle'
STATUS_SIGNALLED = 'signalled'
STATUS_PROCESSING = 'processing'
addon = pykodi.get_main_addon()

class ArtworkService(xbmc.Monitor):
    """Video-library listener only. AudioLibrary notifications are intentionally ignored."""
    def __init__(self):
        super(ArtworkService, self).__init__()
        self.abort = False
        self.processor = ArtworkProcessor(self)
        self.processaftersettings = False
        self.recentvideos = {'movie': [], 'tvshow': [], 'episode': []}
        self.stoppeditems = set()
        self._signal = None
        self._status = None
        self._last_videoupdate = addon.get_setting('last_videoupdate') or '0'
        self.status = STATUS_IDLE

    @property
    def scanning(self):
        return pykodi.get_conditional('Library.IsScanningVideo')

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, value):
        self._status = value
        self.abort = False
        pykodi.execute_builtin('SetProperty(ArtworkCurator.Status, {0}, Home)'.format(value))
        pykodi.execute_builtin('SetProperty(LibraryArtworkCurator.Status, {0}, Home)'.format(value))
        pykodi.execute_builtin('SetProperty(script.artwork.curator.Status, {0}, Home)'.format(value))

    @property
    def signal(self):
        return self._signal

    @signal.setter
    def signal(self, value):
        self._signal = value
        self.status = STATUS_SIGNALLED if value else STATUS_IDLE

    @property
    def last_videoupdate(self):
        return self._last_videoupdate

    @last_videoupdate.setter
    def last_videoupdate(self, value):
        addon.set_setting('last_videoupdate', value)
        self._last_videoupdate = value

    def reset_recent(self):
        self.recentvideos = {'movie': [], 'tvshow': [], 'episode': []}

    def run(self):
        while not self.really_waitforabort(5):
            if self.scanning or not self.signal:
                continue
            signal = self.signal
            self._signal = None
            if signal == 'recentvideos':
                self.signal = 'recentvideos_really'
                continue
            if self._needs_lrs_lock_wait(signal) and not self._wait_for_shared_lrs_lock(signal):
                self.signal = signal
                self.really_waitforabort(5)
                continue
            self.status = STATUS_PROCESSING
            with runtrace.run_context('service.signal.' + str(signal), signal=signal):
                try:
                    if signal == 'allvideos':
                        self.notify_finished(self.process_allvideos())
                    elif signal == 'allvideos_manual':
                        self.notify_finished(self.process_allvideos(force_progress=True))
                    elif signal == 'refreshall_manual':
                        self.notify_finished(self.process_allvideos(force_progress=True, refresh_all=True))
                    elif signal == 'newvideos':
                        self.notify_finished(self.process_recentvideos(refresh_all=True))
                    elif signal == 'newvideos_manual':
                        self.notify_finished(self.process_recentvideos(force_progress=True, notify_empty=True, refresh_all=True))
                    elif signal == 'oldvideos':
                        runtrace.event('service', 'oldvideos ignored; processeditems.db workflow removed')
                        self.notify_finished(True)
                    elif signal == 'oldvideos_manual':
                        runtrace.event('service', 'oldvideos manual ignored; processeditems.db workflow removed')
                        self.notify_finished(True)
                    elif signal == 'recentvideos_really':
                        self.notify_finished(self.process_recentvideos(refresh_all=True), auto=True)
                except Exception as ex:
                    runtrace.error('Recovered unexpected Library Artwork Curator service error', ex, signal=signal)
                    log('Recovered unexpected Library Artwork Curator service error', xbmc.LOGERROR)
                    log(traceback.format_exc(), xbmc.LOGERROR)
                    try:
                        self.processor.close_progress()
                        self.processor.set_idle_inhibition(False)
                        self.processor.notify_warning('Processing stopped. Check kodi.log.', 'Error', True)
                    except Exception as inner:
                        runtrace.error('Service cleanup after error failed', inner, signal=signal)
                        log(traceback.format_exc(), xbmc.LOGWARNING)
                finally:
                    self.status = STATUS_IDLE

    def abortRequested(self):
        return self.waitForAbort(0.0001)

    def waitForAbort(self, timeout=0):
        return self.abort or super(ArtworkService, self).waitForAbort(timeout)

    def really_waitforabort(self, timeout=0):
        return super(ArtworkService, self).waitForAbort(timeout)

    def onNotification(self, sender, method, data):
        runtrace.event('notification', 'received', sender=sender, method=method, data=str(data)[:600])
        if method.startswith('Other.') and sender != 'script.artwork.curator:control':
            return
        if method == 'Other.CancelCurrent':
            if self.status == STATUS_PROCESSING:
                self.abort = True
            elif self.signal:
                self.signal = None
                self.processor.close_progress()
        elif method == 'Other.ProcessNewVideos':
            self.signal = 'recentvideos'
        elif method == 'Other.ProcessNewVideosManual':
            self.signal = 'newvideos_manual'
        elif method == 'Other.ProcessNewAndOldVideos':
            self.signal = 'oldvideos'
        elif method == 'Other.ProcessNewAndOldVideosManual':
            self.signal = 'oldvideos_manual'
        elif method == 'Other.ProcessAllVideos':
            self.signal = 'allvideos'
        elif method == 'Other.ProcessAllVideosManual':
            self.signal = 'allvideos_manual'
        elif method == 'Other.ProcessRefreshAllArtworkManual':
            self.signal = 'refreshall_manual'
        elif method == 'Other.ProcessAfterSettings':
            self.processaftersettings = True
        elif method == 'VideoLibrary.OnScanStarted' and settings.enableservice and self.status == STATUS_PROCESSING:
            self.abort = True
        elif method == 'VideoLibrary.OnScanFinished' and settings.enableservice:
            total_recent = sum(len(values) for values in self.recentvideos.values())
            scan_old = settings.enable_olditem_updates and get_date() > self.last_videoupdate
            if total_recent:
                log('Auto fill artwork queued after VideoLibrary.OnScanFinished for {0} new item(s)'.format(total_recent), xbmc.LOGINFO)
                self.signal = 'recentvideos_really'
            elif scan_old:
                log('Automatic older-item update skipped; processeditems workflow removed', xbmc.LOGINFO)
            else:
                runtrace.event('service', 'auto scan finished silent; no queued new video item IDs')
        elif method == 'VideoLibrary.OnUpdate' and settings.enableservice:
            try:
                payload = json.loads(data)
            except Exception:
                return
            if self.watchitem(payload):
                item = payload['item']
                if mediatypes.disabled(item['type']):
                    runtrace.event('service', 'ignore OnUpdate scope disabled', mediatype=item['type'], dbid=item['id'])
                    return
                if item['id'] not in self.recentvideos[item['type']]:
                    self.recentvideos[item['type']].append(item['id'])
                log('Automatic new-item ID queued in memory after VideoLibrary.OnUpdate: {0}:{1}'.format(
                    item['type'], item['id']), xbmc.LOGINFO)
                if not self.scanning:
                    # Memory queue only. If another Library Artwork Curator job is
                    # currently running, keep the IDs queued and process them after
                    # the current job finishes; never start a second worker.
                    self.signal = 'recentvideos'

    def onSettingsChanged(self):
        settings.update_settings()
        mediatypes.update_settings()
        if self.processaftersettings:
            self.processaftersettings = False
            self.signal = 'newvideos'

    def watchitem(self, payload):
        item = payload.get('item', {})
        return item.get('id') not in (None, -1) and item.get('type') in self.recentvideos and 'playcount' not in payload

    def _needs_lrs_lock_wait(self, signal):
        return signal in ('recentvideos', 'recentvideos_really', 'newvideos', 'newvideos_manual')

    def _lrs_lock_state(self):
        window = xbmcgui.Window(10000)
        names = (
            'LibraryRatingsScraper.Status',
            'LibraryRatingsScraper.Busy',
            'LibraryRatingsScraper.Lock',
            'LRS.Status',
            'LRS.Busy',
            'LRS.Lock',
            'script.library.ratings.scraper.Status',
            'script.library.ratings.scraper.Busy',
            'script.library.ratings.scraper.Lock',
        )
        for name in names:
            value = (window.getProperty(name) or '').strip()
            if value and value.lower() not in ('idle', 'finished', 'done', 'false', '0', 'none'):
                return name, value
        return '', ''

    def _wait_for_shared_lrs_lock(self, signal, timeout=180):
        name, value = self._lrs_lock_state()
        if not name:
            return True
        runtrace.event('service', 'waiting for LRS shared lock', signal=signal, property=name, value=value, timeout=timeout)
        waited = 0
        while waited < timeout and not self.really_waitforabort(1):
            name, value = self._lrs_lock_state()
            if not name:
                runtrace.event('service', 'LRS shared lock released', waited=waited)
                return True
            waited += 1
        runtrace.event('service', 'LRS shared lock still active; auto work remains queued', signal=signal, property=name, value=value, waited=waited)
        return False

    def _sort_mediaitems(self, items):
        order = {mediatypes.MOVIESET: 0, mediatypes.MOVIE: 1, mediatypes.TVSHOW: 2, mediatypes.SEASON: 3, mediatypes.EPISODE: 4}

        def key(item):
            label = (getattr(item, 'label', '') or '').lower()
            show = (getattr(item, 'showtitle', '') or '').lower()
            season = int(getattr(item, 'season', 0) or 0)
            episode = int(getattr(item, 'episode', 0) or 0)
            if item.mediatype == mediatypes.EPISODE:
                return (order.get(item.mediatype, 99), show or label, season, episode, label)
            if item.mediatype == mediatypes.SEASON:
                return (order.get(item.mediatype, 99), show or label, season, label)
            return (order.get(item.mediatype, 99), label)
        return sorted(items, key=key)

    def _dedupe_mediaitems(self, items):
        result, seen = [], set()
        for item in items:
            key = '{0}:{1}'.format(item.mediatype, item.dbid)
            if key in seen:
                continue
            seen.add(key)
            result.append(item)
        return result

    def process_allvideos(self, shouldinclude_fn=None, foreground=False, force_progress=False, refresh_all=False):
        timer = __import__('time').time()
        shouldinclude_fn = shouldinclude_fn or (lambda dbid, mediatype, label: True)
        items = []
        counts = {}

        def add_items(mediatype, rows, idkey):
            before = len(items)
            for row in rows:
                if shouldinclude_fn(row[idkey], mediatype, row.get('label', '')):
                    items.append(info.MediaItem(row))
            counts[mediatype] = len(items) - before

        if not mediatypes.disabled(mediatypes.MOVIESET):
            add_items(mediatypes.MOVIESET, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIESET)), 'setid')
        if not mediatypes.disabled(mediatypes.MOVIE):
            add_items(mediatypes.MOVIE, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)), 'movieid')
        if not mediatypes.disabled(mediatypes.TVSHOW):
            add_items(mediatypes.TVSHOW, quickjson.get_tvshows(), 'tvshowid')
        if not mediatypes.disabled(mediatypes.SEASON):
            add_items(mediatypes.SEASON, quickjson.get_seasons(), 'seasonid')
        if not mediatypes.disabled(mediatypes.EPISODE):
            add_items(mediatypes.EPISODE, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)), 'episodeid')
        items = self._sort_mediaitems(self._dedupe_mediaitems(items))
        runtrace.event('service', 'process_allvideos collected items', total=len(items), counts=counts, order='set,movie,tvshow,season,episode', elapsed_ms=int((__import__('time').time() - timer) * 1000))
        self.reset_recent()
        return self.processor.process_medialist(items, foreground=foreground, force_progress=force_progress, refresh_all=refresh_all)

    def process_recentvideos(self, force_progress=False, notify_empty=False, refresh_all=False):
        runtrace.event('service', 'process_recentvideos start', recent=self.recentvideos)
        items, seen_sets, seen_shows, seen_seasons = [], set(), set(), set()
        merged = {'movie': [], 'tvshow': [], 'episode': []}
        for mediatype in merged:
            merged[mediatype].extend(self.recentvideos.get(mediatype, []))

        for mediatype in ('movie', 'tvshow', 'episode'):
            for dbid in merged.get(mediatype, []):
                row = quickjson.get_item_details(dbid, mediatype)
                if not row:
                    continue
                if mediatype == 'movie' and row.get('setid') and row['setid'] not in seen_sets and not mediatypes.disabled(mediatypes.MOVIESET):
                    seen_sets.add(row['setid'])
                    setrow = quickjson.get_item_details(row['setid'], mediatypes.MOVIESET)
                    if setrow:
                        items.append(info.MediaItem(setrow))
                if mediatype == 'episode' and row.get('tvshowid') not in seen_shows and not mediatypes.disabled(mediatypes.TVSHOW):
                    seen_shows.add(row.get('tvshowid'))
                    showrow = quickjson.get_item_details(row['tvshowid'], mediatypes.TVSHOW)
                    if showrow:
                        items.append(info.MediaItem(showrow))
                if mediatype == 'episode' and not mediatypes.disabled(mediatypes.SEASON):
                    season_key = (row.get('tvshowid'), row.get('season'))
                    if season_key not in seen_seasons:
                        seen_seasons.add(season_key)
                        for seasonrow in quickjson.get_seasons(row.get('tvshowid')):
                            if int(seasonrow.get('season') or 0) == int(row.get('season') or 0):
                                items.append(info.MediaItem(seasonrow))
                                break
                items.append(info.MediaItem(row))

        self.reset_recent()
        items = self._sort_mediaitems(self._dedupe_mediaitems(items))
        runtrace.event('service', 'process_recentvideos collected items', total=len(items), queue_mode='memory', order='set,movie,tvshow,season,episode')
        if items:
            return self.processor.process_medialist(items, alwaysnotify=True, force_progress=force_progress, refresh_all=refresh_all)
        if notify_empty:
            runtrace.event('service', 'manual queue empty; no notification shown')
        return True

    def notify_finished(self, success, auto=False):
        summary = getattr(self.processor, 'last_summary', {}) or {}
        if success:
            pykodi.execute_builtin('NotifyAll(script.artwork.curator, OnVideoProcessingFinished)')
            if auto and int(summary.get('total') or 0) > 0:
                message = 'AUTO FILL ARTWORK FINISHED - {0} ITEMS - {1} ARTWORK - {2} ERRORS'.format(
                    int(summary.get('total') or 0),
                    int(summary.get('updated_artwork') or 0),
                    int(summary.get('errors') or 0),
                )
                xbmcgui.Dialog().notification('Library Artwork Curator', message, xbmcgui.NOTIFICATION_INFO, 7000)
        else:
            self.processor.close_progress()
            if auto and int(summary.get('total') or 0) > 0:
                xbmcgui.Dialog().notification('Library Artwork Curator', 'AUTO FILL ARTWORK ABORTED - {0} ITEMS'.format(int(summary.get('total') or 0)), xbmcgui.NOTIFICATION_WARNING, 7000)


def get_date():
    return pykodi.get_infolabel('System.Date(yyyy-mm-dd)')

if __name__ == '__main__':
    log('Video-only remote Library Artwork Curator service started', xbmc.LOGINFO)
    ArtworkService().run()
    log('Video-only remote Library Artwork Curator service stopped', xbmc.LOGINFO)

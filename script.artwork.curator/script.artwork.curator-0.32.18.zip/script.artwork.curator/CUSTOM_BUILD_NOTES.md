# Library Artwork Curator 0.32.18

- Strict auto fanart minimum resolution.
- No fallback to below-minimum fanart during auto Refresh/Fill.
- Fanart limit is maximum, not mandatory fill count.
- Empty fanart slots are marked N/A in AC DB and managed Kodi fanart leftovers are cleared during Refresh All.
- Addon id remains script.artwork.curator.

import xbmc
import xbmcgui
import xbmcvfs
import traceback
import time
import os
import threading
from itertools import chain

from lib.artworkprocessor import ArtworkProcessor, add_art_to_library
from lib.libs import mediainfo as info, mediatypes, pykodi, quickjson
from lib.libs.addonsettings import settings
from lib import runtrace, artworkdb, indonesian_collection, thailand_collection, cleaner
from lib.libs.pykodi import log, json

STATUS_IDLE = 'idle'
STATUS_SIGNALLED = 'signalled'
STATUS_PROCESSING = 'processing'
SERVICE_WAIT_ACTIVE_SECONDS = 0.20
SERVICE_WAIT_MID_SECONDS = 1.00
SERVICE_WAIT_DEEP_IDLE_SECONDS = 5.00
addon = pykodi.get_main_addon()
AUTO_QUIET_DELAY_SECONDS = 3
AUTO_SCAN_RETRY_SECONDS = 2.0
AUTO_SCAN_MAX_ATTEMPTS = 10
AUTO_SCAN_LOCK_RETRY_SECONDS = 5.0
AUTO_SCAN_LRS_START_GRACE_SECONDS = 4.0
AUTO_SCAN_LOCK_STALE_SECONDS = 180
AUTO_SCAN_LOCK_OWNER = 'script.artwork.curator'
_AUTO_LOCK_LAST_WAIT_LOG = 0.0
_AUTO_LOCK_HEARTBEAT_STOP = None
_AUTO_LOCK_HEARTBEAT_THREAD = None
AUTO_SCAN_LOCK_TITLE = 'Library Artwork Curator'


def _translate_path(value):
    result = xbmcvfs.translatePath(value)
    if isinstance(result, bytes):
        result = result.decode('utf-8', 'replace')
    return result


def _shared_auto_scan_lock_file():
    # Same physical file used by Library Ratings Scraper v1.5.3+:
    # special://profile/addon_data/.kodi-auto-scan.lock
    profile = _translate_path(addon.datapath)
    parent = os.path.dirname(profile.rstrip('/\\'))
    return os.path.join(parent, '.kodi-auto-scan.lock')


def _shared_auto_scan_lock_payload():
    return {
        'addon': AUTO_SCAN_LOCK_OWNER,
        'title': AUTO_SCAN_LOCK_TITLE,
        'created_at': time.strftime('%Y-%m-%dT%H:%M:%S'),
        'pid': os.getpid(),
    }


def _read_shared_auto_scan_lock():
    try:
        with open(_shared_auto_scan_lock_file(), 'r', encoding='utf-8') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def _shared_auto_scan_lock_is_stale():
    try:
        return (time.time() - os.path.getmtime(_shared_auto_scan_lock_file())) > AUTO_SCAN_LOCK_STALE_SECONDS
    except Exception:
        return True


def _touch_shared_auto_scan_lock():
    try:
        lockfile = _shared_auto_scan_lock_file()
        lock = _read_shared_auto_scan_lock()
        if (str(lock.get('addon') or '') == AUTO_SCAN_LOCK_OWNER
                and int(lock.get('pid') or 0) == os.getpid()
                and os.path.exists(lockfile)):
            os.utime(lockfile, None)
            return True
    except Exception:
        pass
    return False


def _start_shared_auto_scan_lock_heartbeat():
    global _AUTO_LOCK_HEARTBEAT_STOP, _AUTO_LOCK_HEARTBEAT_THREAD
    if _AUTO_LOCK_HEARTBEAT_THREAD is not None and _AUTO_LOCK_HEARTBEAT_THREAD.is_alive():
        return
    stop = threading.Event()
    _AUTO_LOCK_HEARTBEAT_STOP = stop

    def _worker():
        while not stop.wait(30.0):
            _touch_shared_auto_scan_lock()

    thread = threading.Thread(target=_worker, name='LACSharedLockHeartbeat')
    thread.daemon = True
    _AUTO_LOCK_HEARTBEAT_THREAD = thread
    thread.start()


def _stop_shared_auto_scan_lock_heartbeat():
    global _AUTO_LOCK_HEARTBEAT_STOP, _AUTO_LOCK_HEARTBEAT_THREAD
    stop = _AUTO_LOCK_HEARTBEAT_STOP
    _AUTO_LOCK_HEARTBEAT_STOP = None
    if stop is not None:
        try:
            stop.set()
        except Exception:
            pass
    _AUTO_LOCK_HEARTBEAT_THREAD = None


def _acquire_shared_auto_scan_lock():
    try:
        lockfile = _shared_auto_scan_lock_file()
        os.makedirs(os.path.dirname(lockfile), exist_ok=True)
        if os.path.exists(lockfile):
            lock = _read_shared_auto_scan_lock()
            owner = str(lock.get('addon') or '')
            if owner == AUTO_SCAN_LOCK_OWNER:
                if int(lock.get('pid') or 0) == os.getpid():
                    try:
                        os.utime(lockfile, None)
                    except Exception:
                        pass
                    _start_shared_auto_scan_lock_heartbeat()
                    return True
                try:
                    os.remove(lockfile)
                    runtrace.event('service', 'removed stale LAC lock from previous service instance', owner=owner)
                except Exception:
                    return False
            if not _shared_auto_scan_lock_is_stale():
                global _AUTO_LOCK_LAST_WAIT_LOG
                if time.time() - float(_AUTO_LOCK_LAST_WAIT_LOG or 0.0) >= 60.0:
                    _AUTO_LOCK_LAST_WAIT_LOG = time.time()
                    runtrace.event('service', 'auto fill waiting for shared auto-scan lock',
                                   owner=owner or 'another addon', lock=lock)
                return False
            try:
                os.remove(lockfile)
                runtrace.event('service', 'removed stale shared auto-scan lock', owner=owner or 'unknown')
            except Exception as ex:
                runtrace.error('remove stale shared auto-scan lock failed', ex, owner=owner or 'unknown')
                return False
        temp = lockfile + '.tmp'
        with open(temp, 'w', encoding='utf-8') as handle:
            json.dump(_shared_auto_scan_lock_payload(), handle, ensure_ascii=False, indent=2, sort_keys=True)
        os.replace(temp, lockfile)
        runtrace.event('service', 'auto fill acquired shared auto-scan lock', lockfile=lockfile)
        _start_shared_auto_scan_lock_heartbeat()
        return True
    except Exception as ex:
        # Never break artwork auto-scan only because the shared lock cannot be written.
        runtrace.error('auto fill shared auto-scan lock acquire failed; continuing unlocked', ex)
        return True


def _release_shared_auto_scan_lock():
    _stop_shared_auto_scan_lock_heartbeat()
    try:
        lockfile = _shared_auto_scan_lock_file()
        lock = _read_shared_auto_scan_lock()
        owner = str(lock.get('addon') or '')
        if not lock or owner == AUTO_SCAN_LOCK_OWNER:
            if os.path.exists(lockfile):
                os.remove(lockfile)
                runtrace.event('service', 'auto fill released shared auto-scan lock')
    except Exception as ex:
        runtrace.error('auto fill shared auto-scan lock release failed', ex)


def _family_notify_03252(message, level=xbmcgui.NOTIFICATION_INFO, duration=7000, *args, **kwargs):
    text = ' '.join(str(message or '').strip().split()).upper().rstrip()
    text = re.sub(r'\bHANDED OFF\b', 'MIGRATED', text)
    text = re.sub(r'\bHANDOFF\b', 'MIGRATED', text)
    parts = text.split(' - ') if text else []
    if len(parts) > 1:
        text = ' - '.join([parts[0]] + [part for part in parts[1:] if not re.match(r'^0(?:\s+|$)', part)])
    elif text and re.match(r'^0(?:\s+|$)', text):
        return
    if len(text) > 58:
        parts = text.split(' - ')
        protected = ('ERROR', 'FAILED', 'UPDATED', 'ARTWORK', 'ITEM', 'CACHED', 'MOVED', 'MIGRATED', 'SCRAPED', 'N/A')
        if len(parts) > 1 and any(token in ' - '.join(parts[1:]) for token in protected):
            suffix = ' - ' + ' - '.join(parts[1:])
            budget = max(4, 58 - len(suffix))
            action = parts[0]
            if len(action) > budget:
                action = action[:max(1, budget - 3)].rstrip() + '...'
            text = (action + suffix)[:58].rstrip()
        else:
            raw = text[:55].rstrip()
            text = (raw.rsplit(' ', 1)[0] if ' ' in raw else raw) + '...'
    if text:
        xbmcgui.Dialog().notification('Library Artwork Curator', text, level, int(duration))


class ArtworkService(xbmc.Monitor):
    """Video-library listener only. AudioLibrary notifications are intentionally ignored."""
    def __init__(self):
        super(ArtworkService, self).__init__()
        self.abort = False
        self.processor = ArtworkProcessor(self)
        self.processaftersettings = False
        self.recentvideos = {'movie': [], 'tvshow': [], 'episode': []}
        self.stoppeditems = set()
        self._signal = None
        self._status = None
        self._scan_snapshot = None
        self._scan_identity_snapshot = []
        # Runtime-only journal of DBIDs Kodi explicitly reports with added=true
        # during the current video scan. This is used only when ScanStarted was
        # missed; it is never a generic cache-miss detector.
        self._scan_added_candidates = {'movie': set(), 'tvshow': set(), 'episode': set()}
        self._last_auto_handed_off = 0
        self._last_auto_scrape_targets = 0
        self._clean_snapshot = None
        self._auto_scan_pending = None
        self._last_scan_started_at = 0.0
        self._last_scan_finished_at = 0.0
        self._late_scan_snapshot_active = False
        self._indonesian_collection_sync_due = (
            time.time() + 6.0
            if getattr(settings, 'indonesian_collection_sync', True)
            else 0.0
        )
        self._indonesian_collection_sync_reason = 'service-startup'
        self._thailand_collection_sync_due = (
            time.time() + 6.5
            if getattr(settings, 'thailand_collection_sync', True)
            else 0.0
        )
        self._thailand_collection_sync_reason = 'service-startup'
        self.status = STATUS_IDLE
        # Release a stale LAC-owned shared lock after a crashed/restarted service.
        _release_shared_auto_scan_lock()
        # Kodi can begin its startup library scan before login services are
        # constructed. Capture a late baseline immediately so items added after
        # this point still participate in exact DBID handoff.
        try:
            if settings.enableservice and self.scanning:
                self._handle_video_scan_started('late-service-start')
                self._late_scan_snapshot_active = True
                runtrace.event('service', 'late-start scan snapshot captured while Kodi was already scanning')
        except Exception as ex:
            runtrace.error('late-start scan snapshot failed', ex)

    @property
    def scanning(self):
        return pykodi.get_conditional('Library.IsScanningVideo')

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, value):
        self._status = value
        self.abort = False
        pykodi.execute_builtin('SetProperty(ArtworkCurator.Status, {0}, Home)'.format(value))
        pykodi.execute_builtin('SetProperty(LibraryArtworkCurator.Status, {0}, Home)'.format(value))
        pykodi.execute_builtin('SetProperty(script.artwork.curator.Status, {0}, Home)'.format(value))

    @property
    def signal(self):
        return self._signal

    @signal.setter
    def signal(self, value):
        self._signal = value
        # Do not clobber PROCESSING while auto-scan queues work in memory.
        # The current job must finish first; the queued signal will be handled
        # by the main loop afterwards.
        if self._status != STATUS_PROCESSING:
            self.status = STATUS_SIGNALLED if value else STATUS_IDLE

    def reset_recent(self):
        self.recentvideos = {'movie': [], 'tvshow': [], 'episode': []}

    def _service_wait_seconds(self):
        try:
            if not settings.enableservice:
                return SERVICE_WAIT_DEEP_IDLE_SECONDS
        except Exception:
            pass
        try:
            if self.signal or self._auto_scan_pending or self._indonesian_collection_sync_due or self._thailand_collection_sync_due:
                return SERVICE_WAIT_ACTIVE_SECONDS
            if self.scanning or self.status == STATUS_SIGNALLED:
                return SERVICE_WAIT_MID_SECONDS
        except Exception:
            pass
        return SERVICE_WAIT_MID_SECONDS

    def run(self):
        # LRS-style single service loop: Kodi scan callbacks only create a pending
        # auto job. The loop consumes that pending job directly when idle instead
        # of routing it through signal -> quiet delay -> RUN START. Manual signals
        # keep priority.
        while not self.really_waitforabort(self._service_wait_seconds()):
            signal = self.signal
            if not signal:
                self._consume_indonesian_collection_sync()
                self._consume_thailand_collection_sync()
                self._consume_auto_scan_job_lrs_style()
                continue
            if self.scanning:
                continue
            self._signal = None
            try:
                if signal == 'recentvideos':
                    self.signal = 'recentvideos_really'
                    continue
                if self._needs_lrs_lock_wait(signal) and not self._wait_for_shared_lrs_lock(signal):
                    self.signal = signal
                    self.really_waitforabort(SERVICE_WAIT_DEEP_IDLE_SECONDS)
                    continue
                if signal == 'recentvideos_really' and not self._wait_for_quiet_auto_start(signal):
                    runtrace.event('service', 'auto fill quiet delay cancelled before processing', signal=signal)
                    self.status = STATUS_IDLE
                    continue
                self.status = STATUS_PROCESSING
                runtrace.event('service', 'service signal entering processing', signal=signal, recent=self.recentvideos)
                with runtrace.run_context('service.signal.' + str(signal), signal=signal):
                    try:
                        if signal == 'allvideos':
                            self.notify_finished(self.process_allvideos())
                        elif signal == 'allvideos_manual':
                            self.notify_finished(self.process_allvideos(force_progress=True))
                        elif signal == 'refreshall_manual':
                            self.notify_finished(self.process_allvideos(force_progress=True, refresh_all=True))
                        elif signal == 'newvideos':
                            self.notify_finished(self.process_recentvideos(refresh_all=False))
                        elif signal == 'newvideos_manual':
                            self.notify_finished(self.process_recentvideos(force_progress=True, notify_empty=True, refresh_all=False))
                        elif signal == 'recentvideos_really':
                            self.notify_finished(self.process_recentvideos(refresh_all=False, auto=True, force_progress=True), auto=True)
                    except Exception as ex:
                        runtrace.error('Recovered unexpected Library Artwork Curator service error', ex, signal=signal)
                        log('Recovered unexpected Library Artwork Curator service error', xbmc.LOGERROR)
                        log(traceback.format_exc(), xbmc.LOGERROR)
                        try:
                            self.processor.close_progress()
                            self.processor.set_idle_inhibition(False)
                            self.processor.notify_warning('Processing stopped. Check kodi.log.', 'Error', True)
                        except Exception as inner:
                            runtrace.error('Service cleanup after error failed', inner, signal=signal)
                            log(traceback.format_exc(), xbmc.LOGWARNING)
                    finally:
                        self.status = STATUS_IDLE
            except Exception as ex:
                runtrace.error('Recovered pre-run Library Artwork Curator service error', ex, signal=signal)
                log('Recovered pre-run Library Artwork Curator service error', xbmc.LOGERROR)
                log(traceback.format_exc(), xbmc.LOGERROR)
                try:
                    self.processor.close_progress()
                    self.processor.set_idle_inhibition(False)
                    self.status = STATUS_IDLE
                except Exception as inner:
                    runtrace.error('Service pre-run cleanup failed', inner, signal=signal)

    def abortRequested(self):
        return self.waitForAbort(0.0001)

    def waitForAbort(self, timeout=0):
        return self.abort or super(ArtworkService, self).waitForAbort(timeout)

    def really_waitforabort(self, timeout=0):
        return super(ArtworkService, self).waitForAbort(timeout)

    def onNotification(self, sender, method, data):
        runtrace.event('notification', 'received', sender=sender, method=method, data=str(data)[:600])
        if method.startswith('Other.') and sender != 'script.artwork.curator:control':
            return
        if method == 'Other.CancelCurrent':
            if self.status == STATUS_PROCESSING:
                self.abort = True
            elif self._auto_scan_pending:
                pending = self._auto_scan_pending
                self._auto_scan_pending = None
                _release_shared_auto_scan_lock()
                self.reset_recent()
                self.status = STATUS_IDLE
                self.abort = True
                runtrace.event('service', 'cancelled pending LRS-style auto scan before processing', pending=pending)
                self.processor.close_progress()
            elif self.status == STATUS_SIGNALLED or self.signal:
                # Covers both queued work that has not been consumed yet and the
                # quiet-delay gap after the run loop has consumed _signal but has
                # not entered PROCESSING. The previous build did not cancel that
                # gap because self.signal was already None while Status still read
                # signalled.
                queued_signal = self.signal
                self.signal = None
                self.abort = True
                runtrace.event('service', 'cancelled signalled auto queue before processing', signal=queued_signal)
                self.processor.close_progress()
        elif method == 'Other.ProcessNewVideos':
            self.signal = 'recentvideos'
        elif method == 'Other.ProcessNewVideosManual':
            self.signal = 'newvideos_manual'
        elif method == 'Other.ProcessAllVideos':
            self.signal = 'allvideos'
        elif method == 'Other.ProcessAllVideosManual':
            self.signal = 'allvideos_manual'
        elif method == 'Other.ProcessRefreshAllArtworkManual':
            self.signal = 'refreshall_manual'
        elif method == 'Other.ProcessAfterSettings':
            self.processaftersettings = True
        elif method == 'VideoLibrary.OnScanStarted' and settings.enableservice:
            self._handle_video_scan_started('notification')
        elif method == 'VideoLibrary.OnScanFinished' and settings.enableservice:
            self._handle_video_scan_finished('notification')
        elif method == 'VideoLibrary.OnCleanStarted' and settings.enableservice:
            self._clean_snapshot = self._snapshot_library_item_keys()
            runtrace.event('service', 'Kodi clean library started; clean snapshot saved', count=len(self._clean_snapshot or []))
        elif method == 'VideoLibrary.OnCleanFinished' and settings.enableservice:
            self._cleanup_after_kodi_clean()
        elif method == 'VideoLibrary.OnRemove' and settings.enableservice:
            # Safety net for libraries/skins that emit OnRemove without the
            # paired CleanStarted/CleanFinished notifications. Snapshot cleanup
            # remains the main LRS-style clean flow.
            try:
                payload = json.loads(data)
                item = payload.get('item') or payload
                mediatype, dbid = item.get('type'), item.get('id')
                if mediatype in (mediatypes.MOVIESET, mediatypes.MOVIE, mediatypes.TVSHOW, mediatypes.SEASON, mediatypes.EPISODE) and dbid not in (None, -1):
                    key = '{0}:{1}'.format(mediatype, int(dbid))
                    if self._clean_snapshot is not None or self.scanning or self._scan_snapshot is not None or self._auto_scan_pending:
                        # Do not erase the old DBID while a scan/clean transaction
                        # can still replace it with the same media under a new
                        # DBID. ScanFinished or CleanFinished first attempts a
                        # conservative one-to-one handoff.
                        runtrace.event('service', 'Kodi OnRemove deferred for active DBID handoff window', item_key=key,
                                       scanning=bool(self.scanning), clean_active=self._clean_snapshot is not None)
                    else:
                        result = artworkdb.delete_item_keys([key])
                        runtrace.event('service', 'Kodi OnRemove cleaned exact item cache row', item_key=key, result=result)
            except Exception as ex:
                runtrace.error('Kodi OnRemove cleanup failed', ex, data=str(data)[:300])
        elif method == 'VideoLibrary.OnUpdate' and settings.enableservice:
            try:
                payload = json.loads(data or '{}') if not isinstance(data, dict) else data
                item = payload.get('item') or {}
                mediatype = str(item.get('type') or '')
                dbid = item.get('id')
                if bool(payload.get('added')) and mediatype in self._scan_added_candidates and dbid not in (None, -1):
                    self._scan_added_candidates[mediatype].add(int(dbid))
                    runtrace.event('service', 'journaled Kodi added candidate for scan recovery', mediatype=mediatype, dbid=int(dbid))
                else:
                    runtrace.event('service', 'VideoLibrary.OnUpdate ignored for new-item detection; not an added candidate')
            except Exception as ex:
                runtrace.error('VideoLibrary.OnUpdate candidate journal failed', ex, data=str(data)[:300])

    def onScanStarted(self, library):  # pylint: disable=invalid-name
        if str(library or "").lower() in ("video", "") and settings.enableservice:
            self._handle_video_scan_started('callback')

    def onScanFinished(self, library):  # pylint: disable=invalid-name
        if str(library or "").lower() in ("video", "") and settings.enableservice:
            self._handle_video_scan_finished('callback')

    def _handle_video_scan_started(self, source):
        now = time.time()
        if source != 'late-service-start' and self._late_scan_snapshot_active and self._scan_snapshot is not None and self.scanning:
            runtrace.event('service', 'duplicate scan-start ignored after late-start snapshot', source=source)
            return
        if now - self._last_scan_started_at < 0.50:
            runtrace.event('service', 'duplicate scan-start callback ignored', source=source)
            return
        self._last_scan_started_at = now
        self._scan_snapshot = self._snapshot_library_ids()
        self._scan_identity_snapshot = self._snapshot_library_identities_03250()
        self._scan_added_candidates = {'movie': set(), 'tvshow': set(), 'episode': set()}
        self._auto_scan_pending = None
        self.reset_recent()
        runtrace.event('service', 'Kodi scan started; LRS-style snapshot saved', source=source, counts={k: len(v) for k, v in self._scan_snapshot.items()} if self._scan_snapshot else {})

    def _handle_video_scan_finished(self, source):
        now = time.time()
        if now - self._last_scan_finished_at < 0.50:
            runtrace.event('service', 'duplicate scan-finish callback ignored', source=source)
            return
        self._last_scan_finished_at = now
        self._late_scan_snapshot_active = False
        before = {k: sorted(v) for k, v in self._scan_snapshot.items()} if self._scan_snapshot is not None else None
        self._auto_scan_pending = {
            'before': before,
            'before_identity': list(self._scan_identity_snapshot or []),
            'candidate_ids': dict((k, sorted(v)) for k, v in self._scan_added_candidates.items()),
            # Give LRS a short first chance to acquire its own shared lock.
            # After that LAC participates in the same lock instead of racing it.
            'next_at': time.time() + AUTO_SCAN_LRS_START_GRACE_SECONDS,
            'attempts': 0,
            'lock_waits': 0,
            'source': source,
            'detection_mode': 'snapshot' if before is not None else 'added-journal',
        }
        self._scan_snapshot = None
        self._scan_identity_snapshot = []
        self._scan_added_candidates = {'movie': set(), 'tvshow': set(), 'episode': set()}
        runtrace.event('service', 'auto fill pending immediately after video library scan',
                       source=source,
                       detection_mode=self._auto_scan_pending.get('detection_mode'),
                       start_grace_seconds=AUTO_SCAN_LRS_START_GRACE_SECONDS,
                       counts={k: len(v) for k, v in (before or {}).items()},
)
        log('Auto fill artwork queued immediately after VideoLibrary.OnScanFinished', xbmc.LOGINFO)
        self._schedule_indonesian_collection_sync('video-scan-finished', delay=1.0)
        self._schedule_thailand_collection_sync('video-scan-finished', delay=1.5)

    def _auto_added_from_pending(self, pending):
        raw_before = pending.get('before')
        candidate_ids = dict((k, set(v or [])) for k, v in (pending.get('candidate_ids') or {}).items())
        after = self._snapshot_library_ids()
        if raw_before is not None:
            before = {k: set(v or []) for k, v in (raw_before or {}).items()}
            if any(before.values()) and not any(after.values()):
                raise RuntimeError('Kodi library snapshot returned empty after scan; DB may still be busy')
            added = {'movie': [], 'tvshow': [], 'episode': []}
            for mediatype in ('movie', 'tvshow', 'episode'):
                added[mediatype] = sorted(after.get(mediatype, set()) - before.get(mediatype, set()))
            detection_mode = 'snapshot'
        else:
            # Recovery is deliberately narrow: only DBIDs Kodi itself marked
            # added=true during this scan are considered. Existing matching
            # cache rows are excluded, so this cannot turn every cache miss into
            # a false new item.
            added = {'movie': [], 'tvshow': [], 'episode': []}
            for mediatype in ('movie', 'tvshow', 'episode'):
                for dbid in sorted(after.get(mediatype, set()).intersection(candidate_ids.get(mediatype, set()))):
                    row = quickjson.get_item_details(dbid, mediatype)
                    if not row:
                        continue
                    mediaitem = info.MediaItem(row)
                    if artworkdb.has_library_item(mediatype, dbid):
                        if not artworkdb.cached_identity_mismatches([mediaitem]):
                            continue
                    added[mediatype].append(dbid)
            detection_mode = 'added-journal'
            if not any(added.values()):
                runtrace.event('service', 'auto fill skipped: no verified Kodi added candidates without scan snapshot')
        added, handed_off = self._handoff_added_items_03300(pending, added)
        total = sum(len(v) for v in added.values())
        pending['handed_off'] = handed_off
        pending['detection_mode'] = detection_mode
        runtrace.event('service', 'auto fill detection completed', detection_mode=detection_mode,
                       added=added, total=total, handed_off=handed_off)
        return added, total

    def _identity_dict_03250(self, mediaitem):
        ids = dict(getattr(mediaitem, 'uniqueids', {}) or {})
        return {
            'mediatype': str(getattr(mediaitem, 'mediatype', '') or ''),
            'dbid': int(getattr(mediaitem, 'dbid', 0) or 0),
            'show': ' '.join(str(getattr(mediaitem, 'showtitle', '') or '').lower().split()),
            'season': int(getattr(mediaitem, 'season', 0) or 0) if getattr(mediaitem, 'mediatype', '') == 'episode' else None,
            'episode': int(getattr(mediaitem, 'episode', 0) or 0) if getattr(mediaitem, 'mediatype', '') == 'episode' else None,
            'title': ' '.join(str(getattr(mediaitem, 'label', '') or '').lower().split()),
            'file': str(getattr(mediaitem, 'file', '') or '').replace('/', '\\').lower(),
            'ids': dict((str(k).lower(), str(v).lower()) for k, v in ids.items() if v not in (None, '')),
        }

    def _snapshot_library_identities_03250(self):
        rows = []
        try:
            if not mediatypes.disabled(mediatypes.MOVIE):
                rows.extend(self._identity_dict_03250(info.MediaItem(row)) for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)))
            if not mediatypes.disabled(mediatypes.TVSHOW):
                rows.extend(self._identity_dict_03250(info.MediaItem(row)) for row in quickjson.get_tvshows())
            if not mediatypes.disabled(mediatypes.EPISODE):
                rows.extend(self._identity_dict_03250(info.MediaItem(row)) for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)))
        except Exception as ex:
            runtrace.error('snapshot library identities failed', ex)
        return rows

    def _old_source_replaced_03300(self, old, current):
        old_file = str((old or {}).get('file') or '').strip()
        new_file = str((current or {}).get('file') or '').strip()
        old_norm = old_file.replace('/', '\\').rstrip('\\').lower()
        new_norm = new_file.replace('/', '\\').rstrip('\\').lower()
        if old_norm and new_norm and old_norm == new_norm:
            return True
        if not old_file:
            return True
        try:
            return not bool(xbmcvfs.exists(old_file))
        except Exception:
            return False

    def _identity_matches_handoff_03300(self, old, current):
        if old.get('mediatype') != current.get('mediatype'):
            return False
        common = set(old.get('ids') or {}).intersection(current.get('ids') or {})
        strong = False
        for provider in ('imdb', 'tmdb', 'tvdb'):
            if provider in common:
                if old['ids'].get(provider) != current['ids'].get(provider):
                    return False
                strong = True
        if current.get('mediatype') == 'episode':
            if old.get('show') and current.get('show') and old.get('show') != current.get('show'):
                return False
            if old.get('season') != current.get('season') or old.get('episode') != current.get('episode'):
                return False
            if strong:
                return True
            oldpath = str(old.get('file') or '').replace('/', '\\').rstrip('\\')
            newpath = str(current.get('file') or '').replace('/', '\\').rstrip('\\')
            oldbase = oldpath.rsplit('\\', 1)[-1].rsplit('.', 1)[0].lower()
            newbase = newpath.rsplit('\\', 1)[-1].rsplit('.', 1)[0].lower()
            return bool((oldbase and oldbase == newbase) or (old.get('show') and old.get('show') == current.get('show')))
        if strong:
            return True
        return bool(old.get('title') and old.get('title') == current.get('title'))

    def _handoff_added_items_03300(self, pending, added):
        before = list((pending or {}).get('before_identity') or [])
        if not before:
            before = list(artworkdb.cached_identity_rows() or [])
            runtrace.event('service', 'artwork handoff using current cache identities because scan-start identities were unavailable', count=len(before))
        handed_off = 0
        remaining = {'movie': [], 'tvshow': [], 'episode': []}
        plans = []

        # Build all candidate pairs first. If one old DBID appears as the only
        # candidate for multiple new DBIDs, the replacement is ambiguous and no
        # automatic transfer is allowed.
        for mediatype in ('movie', 'tvshow', 'episode'):
            for dbid in added.get(mediatype) or []:
                row = quickjson.get_item_details(dbid, mediatype)
                if not row:
                    remaining[mediatype].append(dbid)
                    continue
                mediaitem = info.MediaItem(row)
                current = self._identity_dict_03250(mediaitem)
                candidates = [old for old in before
                              if old.get('mediatype') == mediatype
                              and old.get('dbid') != dbid
                              and self._old_source_replaced_03300(old, current)
                              and self._identity_matches_handoff_03300(old, current)]
                if len(candidates) == 1:
                    plans.append((mediatype, dbid, mediaitem, candidates[0]))
                else:
                    remaining[mediatype].append(dbid)
                    if len(candidates) > 1:
                        runtrace.event('service', 'artwork handoff skipped: ambiguous old DBID candidates',
                                       mediatype=mediatype, dbid=dbid,
                                       candidates=[old.get('dbid') for old in candidates])

        old_counts = {}
        for mediatype, _dbid, _mediaitem, old in plans:
            old_key = (mediatype, int(old.get('dbid') or 0))
            old_counts[old_key] = old_counts.get(old_key, 0) + 1
        valid_plans = []
        for plan in plans:
            mediatype, dbid, _mediaitem, old = plan
            old_key = (mediatype, int(old.get('dbid') or 0))
            if old_counts.get(old_key, 0) == 1:
                valid_plans.append(plan)
            else:
                remaining[mediatype].append(dbid)
                runtrace.event('service', 'artwork handoff skipped: one old DBID matched multiple new items',
                               old_dbid=old_key[1], mediatype=mediatype)

        progress = None
        if valid_plans:
            try:
                progress = xbmcgui.DialogProgressBG()
                progress.create('Library Artwork Curator', 'MIGRATING ARTWORK - {0} ITEMS'.format(len(valid_plans)))
            except Exception:
                progress = None
        try:
            for index, (mediatype, dbid, mediaitem, old) in enumerate(valid_plans, 1):
                if progress is not None:
                    try:
                        line = '{0}/{1} {2} - MIGRATED'.format(index, len(valid_plans), self.processor._display_title(mediaitem))
                        progress.update(int(index * 100 / float(len(valid_plans) or 1)), 'Library Artwork Curator', self.processor._fit_line(line))
                    except Exception:
                        pass
                old_key = '{0}:{1}'.format(mediatype, int(old.get('dbid') or 0))
                result = artworkdb.handoff_item_key(old_key, mediaitem)
                if not result.get('handed_off'):
                    remaining[mediatype].append(dbid)
                    continue
                handed_off += 1
                art = result.get('art') or {}
                if art:
                    add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, art)
                    mediaitem.art.update(art)
                    self.processor.mark_reload_skin_art_03370(mediaitem.mediatype, art)
                # A complete handed_off cache never reaches providers. If enabled
                # artwork is still missing, keep the new DBID in the normal
                # missing-only queue so only those exact types are fetched.
                try:
                    _apply, _missing, search_targets, _existing = self.processor._db_first_plan(mediaitem)
                except Exception:
                    search_targets = []
                if search_targets:
                    remaining[mediatype].append(dbid)
                runtrace.event('service', 'handed_off artwork before provider lookup',
                               old_key=old_key, new_key=result.get('new_key'),
                               artwork=len(art), missing_after_handoff=search_targets)
        finally:
            if progress is not None:
                try:
                    progress.close()
                except Exception:
                    pass
        return remaining, handed_off

    def _schedule_indonesian_collection_sync(self, reason, delay=1.0):
        if not getattr(settings, 'indonesian_collection_sync', True):
            self._indonesian_collection_sync_due = 0.0
            self._indonesian_collection_sync_reason = ''
            return
        due = time.time() + max(0.0, float(delay or 0.0))
        current = float(self._indonesian_collection_sync_due or 0.0)
        if not current or due < current:
            self._indonesian_collection_sync_due = due
        self._indonesian_collection_sync_reason = str(reason or 'scheduled')
        runtrace.event(
            'service',
            'Indonesian collection sync scheduled',
            reason=self._indonesian_collection_sync_reason,
            delay_seconds=delay,
        )

    def _consume_indonesian_collection_sync(self):
        due = float(self._indonesian_collection_sync_due or 0.0)
        if not due or time.time() < due:
            return False
        if self.scanning or self.status == STATUS_PROCESSING or self.signal:
            return False

        reason = self._indonesian_collection_sync_reason or 'scheduled'
        self._indonesian_collection_sync_due = 0.0
        self._indonesian_collection_sync_reason = ''
        runtrace.event('service', 'Indonesian collection sync starting', reason=reason)
        try:
            result = indonesian_collection.sync(reason=reason, notify=False)
            runtrace.event(
                'service',
                'Indonesian collection sync finished',
                reason=reason,
                total=result.get('total', 0),
                changed=result.get('changed', 0),
                failed=result.get('failed', 0),
                success=result.get('success', False),
            )
        except Exception as ex:
            runtrace.error('Indonesian collection sync service error', ex, reason=reason)
        return True

    def _schedule_thailand_collection_sync(self, reason, delay=1.0):
        if not getattr(settings, 'thailand_collection_sync', True):
            self._thailand_collection_sync_due = 0.0
            self._thailand_collection_sync_reason = ''
            return
        due = time.time() + max(0.0, float(delay or 0.0))
        current = float(self._thailand_collection_sync_due or 0.0)
        if not current or due < current:
            self._thailand_collection_sync_due = due
        self._thailand_collection_sync_reason = str(reason or 'scheduled')
        runtrace.event(
            'service',
            'Thailand collection sync scheduled',
            reason=self._thailand_collection_sync_reason,
            delay_seconds=delay,
        )

    def _consume_thailand_collection_sync(self):
        due = float(self._thailand_collection_sync_due or 0.0)
        if not due or time.time() < due:
            return False
        if self.scanning or self.status == STATUS_PROCESSING or self.signal:
            return False

        reason = self._thailand_collection_sync_reason or 'scheduled'
        self._thailand_collection_sync_due = 0.0
        self._thailand_collection_sync_reason = ''
        runtrace.event('service', 'Thailand collection sync starting', reason=reason)
        try:
            result = thailand_collection.sync(reason=reason, notify=False)
            runtrace.event(
                'service',
                'Thailand collection sync finished',
                reason=reason,
                total=result.get('total', 0),
                changed=result.get('changed', 0),
                failed=result.get('failed', 0),
                success=result.get('success', False),
            )
        except Exception as ex:
            runtrace.error('Thailand collection sync service error', ex, reason=reason)
        return True

    def _consume_auto_scan_job_lrs_style(self):
        pending = self._auto_scan_pending
        if not pending:
            return False
        if time.time() < float(pending.get('next_at') or 0):
            return False

        # LRS-compatible shared auto-scan lock. This is deliberately checked
        # before new-item detection so LRS and LAC do not both open progress /
        # final notifications at the same time after the same Kodi scan.
        if not _acquire_shared_auto_scan_lock():
            pending['next_at'] = time.time() + AUTO_SCAN_LOCK_RETRY_SECONDS
            pending['lock_waits'] = int(pending.get('lock_waits') or 0) + 1
            self._auto_scan_pending = pending
            runtrace.event('service', 'LRS-style auto fill deferred by shared auto-scan lock',
                           lock_waits=pending.get('lock_waits'),
                           retry_seconds=AUTO_SCAN_LOCK_RETRY_SECONDS,
                           detection_mode=pending.get('detection_mode'))
            return False

        pending['attempts'] = int(pending.get('attempts') or 0) + 1
        try:
            added, total = self._auto_added_from_pending(pending)
        except Exception as ex:
            if pending['attempts'] < AUTO_SCAN_MAX_ATTEMPTS:
                pending['next_at'] = time.time() + AUTO_SCAN_RETRY_SECONDS
                self._auto_scan_pending = pending
                # Match LRS behavior: keep the shared lock while the post-scan DB
                # settles, so no other auto workflow starts in the gap.
                runtrace.event('service', 'auto fill waiting for Kodi library DB', attempts=pending['attempts'], error=str(ex))
                return False
            self._auto_scan_pending = None
            _release_shared_auto_scan_lock()
            runtrace.error('auto fill new-item detection failed', ex, pending=pending)
            return False

        self._auto_scan_pending = None
        self._last_auto_handed_off = int(pending.get('handed_off') or 0)
        if not total:
            self._last_auto_scrape_targets = 0
            handed_off = int(pending.get('handed_off') or 0)
            if handed_off:
                self.processor._finish_reload_skin_03370(aborted=False)
                try:
                    _family_notify_03252('ARTWORK MIGRATED - {0} ITEMS'.format(handed_off), xbmcgui.NOTIFICATION_INFO, 7000)
                except Exception:
                    pass
            _release_shared_auto_scan_lock()
            runtrace.event('service', 'auto fill skipped: no newly added video items found', attempts=pending.get('attempts'), added=added, handed_off=handed_off)
            return False

        self.recentvideos = {'movie': list(added.get('movie') or []), 'tvshow': list(added.get('tvshow') or []), 'episode': list(added.get('episode') or [])}
        self._last_auto_scrape_targets = int(total or 0)
        log('Auto fill artwork processing {0} new item(s) after VideoLibrary.OnScanFinished'.format(total), xbmc.LOGINFO)
        runtrace.event('service', 'LRS-style auto fill job starting', recent=self.recentvideos, total=total,
                       attempts=pending.get('attempts'), lock_waits=pending.get('lock_waits'))
        self.status = STATUS_PROCESSING
        with runtrace.run_context('service.auto_scan_lrs_style', recent=self.recentvideos, total=total):
            try:
                self.notify_finished(self.process_recentvideos(refresh_all=False, auto=True, force_progress=True), auto=True)
            except Exception as ex:  # pylint: disable=broad-except
                runtrace.error('Recovered LRS-style auto fill processing error', ex, recent=self.recentvideos)
                log('Recovered LRS-style auto fill processing error', xbmc.LOGERROR)
                log(traceback.format_exc(), xbmc.LOGERROR)
                try:
                    self.processor.close_progress()
                    self.processor.set_idle_inhibition(False)
                    self.processor.notify_warning('Auto fill stopped. Check kodi.log.', 'Error', True)
                except Exception as inner:
                    runtrace.error('LRS-style auto fill cleanup failed', inner)
            finally:
                _release_shared_auto_scan_lock()
                self.status = STATUS_IDLE
        return True

    def onSettingsChanged(self):
        settings.update_settings()
        self._schedule_indonesian_collection_sync('settings-changed', delay=1.0)
        self._schedule_thailand_collection_sync('settings-changed', delay=1.5)
        mediatypes.update_settings()
        if self.processaftersettings:
            self.processaftersettings = False
            self.signal = 'newvideos'

    def watchitem(self, payload):
        item = payload.get('item', {})
        return item.get('id') not in (None, -1) and item.get('type') in self.recentvideos and 'playcount' not in payload

    def _snapshot_library_item_keys(self):
        keys = set()
        try:
            if not mediatypes.disabled(mediatypes.MOVIESET):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIESET)):
                    dbid = row.get('setid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.MOVIESET, int(dbid)))
            if not mediatypes.disabled(mediatypes.MOVIE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)):
                    dbid = row.get('movieid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.MOVIE, int(dbid)))
            if not mediatypes.disabled(mediatypes.TVSHOW):
                for row in quickjson.get_tvshows():
                    dbid = row.get('tvshowid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.TVSHOW, int(dbid)))
            if not mediatypes.disabled(mediatypes.SEASON):
                for row in quickjson.get_seasons():
                    dbid = row.get('seasonid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.SEASON, int(dbid)))
            if not mediatypes.disabled(mediatypes.EPISODE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)):
                    dbid = row.get('episodeid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.EPISODE, int(dbid)))
        except Exception as ex:
            runtrace.error('snapshot library item keys failed', ex)
        return keys

    def _current_mediaitems_for_handoff_03340(self):
        items = []
        if not mediatypes.disabled(mediatypes.MOVIE):
            items.extend(info.MediaItem(row) for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)))
        if not mediatypes.disabled(mediatypes.TVSHOW):
            items.extend(info.MediaItem(row) for row in quickjson.get_tvshows())
        if not mediatypes.disabled(mediatypes.EPISODE):
            items.extend(info.MediaItem(row) for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)))
        return items

    def _clean_time_handoff_salvage_03340(self, current_keys):
        stats = {'handed_off': 0, 'rows': [], 'ambiguous': 0}
        try:
            cached = list(artworkdb.cached_identity_rows() or [])
            current_items = self._current_mediaitems_for_handoff_03340()
            cached_keys = set(row.get('item_key') for row in cached if row.get('item_key'))
            old_rows = [row for row in cached if row.get('item_key') not in current_keys]
            new_items = [item for item in current_items
                         if '{0}:{1}'.format(item.mediatype, item.dbid) not in cached_keys]
            plans = []
            for mediaitem in new_items:
                current = self._identity_dict_03250(mediaitem)
                matches = [old for old in old_rows
                           if self._old_source_replaced_03300(old, current)
                           and self._identity_matches_handoff_03300(old, current)]
                if len(matches) == 1:
                    plans.append((mediaitem, matches[0]))
                elif len(matches) > 1:
                    stats['ambiguous'] += 1
                    runtrace.event('service', 'clean-time artwork handoff skipped: ambiguous old DBIDs',
                                   new_key='{0}:{1}'.format(mediaitem.mediatype, mediaitem.dbid),
                                   candidates=[row.get('item_key') for row in matches])
            old_use = {}
            for _mediaitem, old in plans:
                old_use[old.get('item_key')] = old_use.get(old.get('item_key'), 0) + 1
            for mediaitem, old in plans:
                old_key = old.get('item_key')
                if old_use.get(old_key) != 1:
                    stats['ambiguous'] += 1
                    continue
                result = artworkdb.handoff_item_key(old_key, mediaitem)
                if not result.get('handed_off'):
                    continue
                art = result.get('art') or {}
                if art:
                    add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, art)
                    mediaitem.art.update(art)
                    self.processor.mark_reload_skin_art_03370(mediaitem.mediatype, art)
                stats['rows'].append({'old_key': old_key, 'new_key': result.get('new_key'),
                                      'title': self.processor._display_title(mediaitem)})
            stats['handed_off'] = len(stats['rows'])
            if stats['handed_off']:
                runtrace.event('service', 'clean-time artwork handoff salvage finished', **stats)
            return stats
        except Exception as ex:
            stats['error'] = str(ex)
            runtrace.error('clean-time artwork handoff salvage failed', ex)
            return stats

    def _cleanup_after_kodi_clean(self):
        before = self._clean_snapshot
        self._clean_snapshot = None
        after = self._snapshot_library_item_keys()
        if not after:
            runtrace.event('service', 'Kodi clean finished but current library snapshot is empty; cleanup deferred')
            return

        salvage = self._clean_time_handoff_salvage_03340(after)
        handed_old = set(row.get('old_key') for row in salvage.get('rows') or [] if row.get('old_key'))
        if before is None:
            # CleanStarted may be missed when the service starts late. The cache
            # itself is a safe pre-clean inventory at CleanFinished.
            before = artworkdb.cached_item_keys().union(handed_old)
            runtrace.event('service', 'Kodi clean finished without start snapshot; using cache inventory after handoff salvage', count=len(before))
        removed = sorted(set(before) - set(after) - handed_old)
        if not removed:
            if salvage.get('handed_off'):
                self.processor._finish_reload_skin_03370(aborted=False)
                try:
                    _family_notify_03252('ARTWORK MIGRATED - {0} ITEMS'.format(salvage.get('handed_off')), xbmcgui.NOTIFICATION_INFO, 7000)
                except Exception:
                    pass
            runtrace.event('service', 'Kodi clean finished; no stale cache rows after handoff salvage', salvage=salvage)
            return
        result = artworkdb.delete_item_keys(removed)
        self.processor._finish_reload_skin_03370(aborted=False)
        message = 'CLEAN LIBRARY ARTWORK FINISHED - {0} MIGRATED - {1} ITEMS REMOVED'.format(
            int(salvage.get('handed_off') or 0), result.get('items', 0))
        runtrace.event('service', 'Kodi clean library AC DB cleanup finished', removed_keys=len(removed), result=result, salvage=salvage)
        try:
            _family_notify_03252(message, xbmcgui.NOTIFICATION_INFO, 7000)
        except Exception:
            pass

    def _snapshot_library_ids(self):
        snapshot = {'movie': set(), 'tvshow': set(), 'episode': set()}
        try:
            if not mediatypes.disabled(mediatypes.MOVIE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)):
                    dbid = row.get('movieid')
                    if dbid not in (None, -1):
                        snapshot['movie'].add(int(dbid))
            if not mediatypes.disabled(mediatypes.TVSHOW):
                for row in quickjson.get_tvshows():
                    dbid = row.get('tvshowid')
                    if dbid not in (None, -1):
                        snapshot['tvshow'].add(int(dbid))
            if not mediatypes.disabled(mediatypes.EPISODE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)):
                    dbid = row.get('episodeid')
                    if dbid not in (None, -1):
                        snapshot['episode'].add(int(dbid))
        except Exception as ex:
            runtrace.error('snapshot library IDs failed', ex)
        return snapshot


    def _identity_reused_library_items(self):
        """Return DBIDs whose current Kodi identity conflicts with the LAC cache."""
        candidates = []
        try:
            if not mediatypes.disabled(mediatypes.MOVIE):
                candidates.extend(info.MediaItem(row) for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)))
            if not mediatypes.disabled(mediatypes.TVSHOW):
                candidates.extend(info.MediaItem(row) for row in quickjson.get_tvshows())
            if not mediatypes.disabled(mediatypes.EPISODE):
                candidates.extend(info.MediaItem(row) for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)))
        except Exception as ex:
            runtrace.error('build current identity list failed', ex)
            return {'movie': [], 'tvshow': [], 'episode': []}
        mismatches = artworkdb.cached_identity_mismatches(candidates)
        result = {'movie': [], 'tvshow': [], 'episode': []}
        for mediaitem in mismatches:
            mediatype = str(getattr(mediaitem, 'mediatype', '') or '')
            if mediatype in result:
                result[mediatype].append(int(mediaitem.dbid))
        if mismatches:
            runtrace.event('service', 'DBID identity reuse detected after scan',
                           movie=len(result['movie']), tvshow=len(result['tvshow']), episode=len(result['episode']))
        return result

    def _cached_artwork_item_keys(self):
        try:
            conn = artworkdb.connect()
            try:
                return set(row[0] for row in conn.execute('SELECT item_key FROM library_items'))
            finally:
                conn.close()
        except Exception as ex:
            runtrace.error('load cached artwork item keys failed', ex)
            return set()

    def _merge_scan_diff_into_recent(self):
        if self._scan_snapshot is None:
            # If the service starts while Kodi is already scanning, it can receive
            # OnScanFinished without the matching OnScanStarted snapshot. Treating
            # that as an empty snapshot falsely queues the entire library as new.
            runtrace.event('service', 'scan finished without start snapshot; auto diff skipped')
            return
        before = self._scan_snapshot
        after = self._snapshot_library_ids()
        self._scan_snapshot = None
        added = {}
        reused = self._identity_reused_library_items()
        for mediatype in ('movie', 'tvshow', 'episode'):
            numeric_new = set(after.get(mediatype, set()) - before.get(mediatype, set()))
            numeric_new.update(reused.get(mediatype) or ())
            added[mediatype] = sorted(numeric_new)
            for dbid in added[mediatype]:
                if dbid not in self.recentvideos[mediatype]:
                    self.recentvideos[mediatype].append(dbid)
        runtrace.event('service', 'scan snapshot diff merged into memory queue', added=added, recent=self.recentvideos)

    def _needs_lrs_lock_wait(self, signal):
        return signal in ('recentvideos', 'recentvideos_really', 'newvideos', 'newvideos_manual')

    def _wait_for_quiet_auto_start(self, signal):
        # Kodi does not expose a global notification queue API. This is a pragmatic
        # quiet-window delay after scan/LRS activity so Auto Fill progress does not
        # collide with LRS/Kodi toasts.
        #
        # Important: do not use Monitor.waitForAbort(0) as a polling check here.
        # In Kodi, timeout=0 can behave as an indefinite wait on some builds. That
        # was the remaining auto-scan bug: diagnostics stopped at
        # "auto fill quiet delay before starting" and never reached RUN START.
        delay = AUTO_QUIET_DELAY_SECONDS
        runtrace.event('service', 'auto fill quiet delay before starting', signal=signal, delay_seconds=delay)
        deadline = time.time() + delay
        while time.time() < deadline:
            if self.abort:
                runtrace.event('service', 'auto fill quiet delay cancelled by local abort', signal=signal)
                return False
            remaining = deadline - time.time()
            timeout = 0.1 if remaining > 0.1 else max(0.001, remaining)
            if self.really_waitforabort(timeout):
                runtrace.event('service', 'auto fill quiet delay cancelled by Kodi abort', signal=signal)
                return False
        if self.abort:
            runtrace.event('service', 'auto fill quiet delay cancelled by local abort', signal=signal)
            return False
        runtrace.event('service', 'auto fill quiet delay finished; starting processing', signal=signal)
        return True

    def _lrs_lock_state(self):
        window = xbmcgui.Window(10000)
        names = (
            'LibraryRatingsScraper.Status',
            'LibraryRatingsScraper.Busy',
            'LibraryRatingsScraper.Lock',
            'LRS.Status',
            'LRS.Busy',
            'LRS.Lock',
            'script.library.ratings.scraper.Status',
            'script.library.ratings.scraper.Busy',
            'script.library.ratings.scraper.Lock',
        )
        for name in names:
            value = (window.getProperty(name) or '').strip()
            if value and value.lower() not in ('idle', 'finished', 'done', 'false', '0', 'none'):
                return name, value
        return '', ''

    def _wait_for_shared_lrs_lock(self, signal, timeout=180):
        name, value = self._lrs_lock_state()
        if not name:
            return True
        runtrace.event('service', 'waiting for LRS shared lock', signal=signal, property=name, value=value, timeout=timeout)
        try:
            _family_notify_03252('WAITING FOR LRS', xbmcgui.NOTIFICATION_INFO, 5000)
        except Exception:
            pass
        waited = 0
        while waited < timeout and not self.really_waitforabort(1):
            name, value = self._lrs_lock_state()
            if not name:
                runtrace.event('service', 'LRS shared lock released', waited=waited)
                return True
            waited += 1
        runtrace.event('service', 'LRS shared lock still active; auto work remains queued', signal=signal, property=name, value=value, waited=waited)
        return False

    def _sort_mediaitems(self, items):
        order = {mediatypes.MOVIESET: 0, mediatypes.MOVIE: 1, mediatypes.TVSHOW: 2, mediatypes.SEASON: 3, mediatypes.EPISODE: 4}

        def key(item):
            label = (getattr(item, 'label', '') or '').lower()
            show = (getattr(item, 'showtitle', '') or '').lower()
            season = int(getattr(item, 'season', 0) or 0)
            episode = int(getattr(item, 'episode', 0) or 0)
            if item.mediatype == mediatypes.EPISODE:
                return (order.get(item.mediatype, 99), show or label, season, episode, label)
            if item.mediatype == mediatypes.SEASON:
                return (order.get(item.mediatype, 99), show or label, season, label)
            return (order.get(item.mediatype, 99), label)
        return sorted(items, key=key)

    def _dedupe_mediaitems(self, items):
        result, seen = [], set()
        for item in items:
            key = '{0}:{1}'.format(item.mediatype, item.dbid)
            if key in seen:
                continue
            seen.add(key)
            result.append(item)
        return result

    def _fill_missing_candidates_03250(self, items, progress=None, start_percent=20, end_percent=99):
        candidates = []
        skipped = 0
        total = len(items or [])
        cancelled = False
        span = max(0, int(end_percent) - int(start_percent))
        try:
            artworkdb.begin_preflight_snapshot_03252()
        except Exception as ex:
            runtrace.error('preflight snapshot failed; using direct DB reads', ex)
        for index, mediaitem in enumerate(items or [], 1):
            if self.abortRequested():
                cancelled = True
                runtrace.event('service', 'fill-missing candidate preflight cancelled',
                               checked=index - 1, library_items=total,
                               candidates=len(candidates), skipped_final=skipped)
                break
            if progress is not None and (index == 1 or index % 25 == 0 or index == total):
                try:
                    percent = int(start_percent) + int(index * span / float(total or 1))
                    progress.update(min(int(end_percent), percent),
                                    'Library Artwork Curator',
                                    'CHECKING ARTWORK DB')
                except Exception:
                    pass
            try:
                plan = self.processor._db_first_preflight(mediaitem)
                if plan is None:
                    candidates.append(mediaitem)
                    continue
                db_apply, _missing_exact, search_targets, _existing = plan
                if db_apply or search_targets:
                    candidates.append(mediaitem)
                else:
                    skipped += 1
            except Exception as ex:
                # Conservative fallback: an unreadable DB-first row must still be
                # processed normally rather than silently omitted.
                candidates.append(mediaitem)
                runtrace.error('fill-missing candidate preflight failed; item retained', ex,
                               mediatype=getattr(mediaitem, 'mediatype', ''),
                               dbid=getattr(mediaitem, 'dbid', ''))
        try:
            artworkdb.end_preflight_snapshot_03252()
        except Exception:
            pass
        runtrace.event('service', 'fill-missing candidate preflight finished',
                       library_items=total, candidates=len(candidates),
                       skipped_final=skipped, cancelled=cancelled)
        return candidates, cancelled

    def process_allvideos(self, shouldinclude_fn=None, foreground=False, force_progress=False, refresh_all=False):
        timer = __import__('time').time()
        shouldinclude_fn = shouldinclude_fn or (lambda dbid, mediatype, label: True)
        items = []
        counts = {}
        preflight_progress = None

        if force_progress and not refresh_all:
            try:
                preflight_progress = xbmcgui.DialogProgressBG()
                preflight_progress.create('Library Artwork Curator', '')
                preflight_progress.update(0, 'Library Artwork Curator', 'READING KODI LIBRARY')
            except Exception:
                preflight_progress = None

        def preflight_update(percent, message):
            if preflight_progress is not None:
                try:
                    preflight_progress.update(int(percent), 'Library Artwork Curator', message)
                except Exception:
                    pass

        def add_items(mediatype, rows, idkey):
            before = len(items)
            for row in rows:
                if self.abortRequested():
                    return False
                if shouldinclude_fn(row[idkey], mediatype, row.get('label', '')):
                    items.append(info.MediaItem(row))
            counts[mediatype] = len(items) - before
            return True

        try:
            if not mediatypes.disabled(mediatypes.MOVIESET):
                if not add_items(mediatypes.MOVIESET, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIESET)), 'setid'):
                    return False
            preflight_update(4, 'READING MOVIE SETS')
            if not mediatypes.disabled(mediatypes.MOVIE):
                if not add_items(mediatypes.MOVIE, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)), 'movieid'):
                    return False
            preflight_update(8, 'READING MOVIES')
            if not mediatypes.disabled(mediatypes.TVSHOW):
                if not add_items(mediatypes.TVSHOW, quickjson.get_tvshows(), 'tvshowid'):
                    return False
            preflight_update(12, 'READING TV SHOWS')
            if not mediatypes.disabled(mediatypes.SEASON):
                if not add_items(mediatypes.SEASON, quickjson.get_seasons(), 'seasonid'):
                    return False
            preflight_update(16, 'READING SEASONS')
            if not mediatypes.disabled(mediatypes.EPISODE):
                if not add_items(mediatypes.EPISODE, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)), 'episodeid'):
                    return False
            preflight_update(20, 'CHECKING ARTWORK DB')

            items = self._sort_mediaitems(self._dedupe_mediaitems(items))
            library_total = len(items)
            if not refresh_all:
                items, cancelled = self._fill_missing_candidates_03250(
                    items, progress=preflight_progress, start_percent=20, end_percent=99)
                if cancelled or self.abortRequested():
                    runtrace.event('service', 'process_allvideos aborted during preflight',
                                   library_total=library_total, candidates=len(items))
                    try:
                        _family_notify_03252('FILL MISSING ARTWORK ABORTED', xbmcgui.NOTIFICATION_WARNING, 6000)
                    except Exception:
                        pass
                    self.reset_recent()
                    return False
                preflight_update(100, 'FOUND {0} ARTWORK ITEMS'.format(len(items)))
            runtrace.event('service', 'process_allvideos collected items', total=len(items), library_total=library_total, counts=counts, order='set,movie,tvshow,season,episode', elapsed_ms=int((__import__('time').time() - timer) * 1000))
            self.reset_recent()
        finally:
            if preflight_progress is not None:
                try:
                    preflight_progress.close()
                except Exception:
                    pass
        return self.processor.process_medialist(items, foreground=foreground, force_progress=force_progress, refresh_all=refresh_all)

    def process_recentvideos(self, force_progress=False, notify_empty=False, refresh_all=False, auto=False):
        runtrace.event('service', 'process_recentvideos start', recent=self.recentvideos)
        items, seen_sets, seen_shows, seen_seasons = [], set(), set(), set()
        merged = {'movie': [], 'tvshow': [], 'episode': []}
        for mediatype in merged:
            merged[mediatype].extend(self.recentvideos.get(mediatype, []))

        for mediatype in ('movie', 'tvshow', 'episode'):
            for dbid in merged.get(mediatype, []):
                row = quickjson.get_item_details(dbid, mediatype)
                if not row:
                    continue
                if mediatype == 'movie' and row.get('setid') and row['setid'] not in seen_sets and not mediatypes.disabled(mediatypes.MOVIESET):
                    seen_sets.add(row['setid'])
                    setrow = quickjson.get_item_details(row['setid'], mediatypes.MOVIESET)
                    if setrow:
                        items.append(info.MediaItem(setrow))
                if mediatype == 'episode' and row.get('tvshowid') not in seen_shows and not mediatypes.disabled(mediatypes.TVSHOW):
                    seen_shows.add(row.get('tvshowid'))
                    showrow = quickjson.get_item_details(row['tvshowid'], mediatypes.TVSHOW)
                    if showrow:
                        items.append(info.MediaItem(showrow))
                if mediatype == 'episode' and not mediatypes.disabled(mediatypes.SEASON):
                    season_key = (row.get('tvshowid'), row.get('season'))
                    if season_key not in seen_seasons:
                        seen_seasons.add(season_key)
                        for seasonrow in quickjson.get_seasons(row.get('tvshowid')):
                            if int(seasonrow.get('season') or 0) == int(row.get('season') or 0):
                                items.append(info.MediaItem(seasonrow))
                                break
                items.append(info.MediaItem(row))

        self.reset_recent()
        items = self._sort_mediaitems(self._dedupe_mediaitems(items))
        runtrace.event('service', 'process_recentvideos collected items', total=len(items), queue_mode='memory', order='set,movie,tvshow,season,episode')
        if items:
            if auto:
                try:
                    _family_notify_03252('AUTO FILL ARTWORK STARTED - {0} ITEM{1}'.format(len(items), '' if len(items) == 1 else 'S'), xbmcgui.NOTIFICATION_INFO, 4000)
                except Exception:
                    pass
            return self.processor.process_medialist(items, alwaysnotify=True, force_progress=force_progress, refresh_all=refresh_all, suppress_final=auto)
        if notify_empty:
            runtrace.event('service', 'manual queue empty; no notification shown')
        return True

    def notify_finished(self, success, auto=False):
        summary = getattr(self.processor, 'last_summary', {}) or {}
        if success:
            pykodi.execute_builtin('NotifyAll(script.artwork.curator, OnVideoProcessingFinished)')
            if auto and int(summary.get('total') or 0) > 0:
                handed_off = int(getattr(self, '_last_auto_handed_off', 0) or 0)
                scraped = int(getattr(self, '_last_auto_scrape_targets', 0) or 0)
                message = 'AUTO ARTWORK - {0} MIGRATED - {1} SCRAPED - {2} ARTWORK - {3} ERRORS'.format(
                    handed_off,
                    scraped,
                    int(summary.get('updated_artwork') or 0),
                    int(summary.get('errors') or 0),
                )
                self._last_auto_handed_off = 0
                self._last_auto_scrape_targets = 0
                _family_notify_03252(message, xbmcgui.NOTIFICATION_INFO, 7000)
        else:
            self.processor.close_progress()
            if auto and int(summary.get('total') or 0) > 0:
                _family_notify_03252('AUTO FILL ARTWORK ABORTED - {0} ITEMS'.format(int(summary.get('total') or 0)), xbmcgui.NOTIFICATION_WARNING, 7000)


if __name__ == '__main__':
    log('Video-only remote Library Artwork Curator service started v{0}'.format(addon.getAddonInfo('version')), xbmc.LOGINFO)
    try:
        ArtworkService().run()
    finally:
        _release_shared_auto_scan_lock()
        log('Video-only remote Library Artwork Curator service stopped', xbmc.LOGINFO)

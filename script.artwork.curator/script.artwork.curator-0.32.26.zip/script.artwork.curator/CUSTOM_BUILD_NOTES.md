# Library Artwork Curator 0.32.26

Custom fixes in this build:

- Select artwork now pages large candidate lists inside the candidate dialog.
  - The first page shows up to 50 candidates per provider by default.
  - A `Load more candidates` row reveals the next page from each provider.
  - Current/manual artwork still stays visible and selected when applicable.
  - Provider freedom is preserved: TMDb, fanart.tv, and TheTVDB are still available when they have candidates.
- Added visible setting: **Select artwork candidates per provider page**.
- Diagnostics/status summaries now ignore legacy `season fanart` / `episode fanart` rows because those are no longer managed targets.
- Kept season model from 0.32.25:
  - direct season artwork is canonical;
  - `season.N.*` on the TV show remains a compatibility mirror.
- Kept defaults for stable full-library refresh:
  - detailed per-item reports default OFF;
  - expert context diagnostics default OFF.

# Library Artwork Curator 0.32.25

Custom fixes in this build:

- Select artwork provider visibility hotfix: compact filtering keeps top candidates from every provider and labels current-only artwork with inferred source.

# Library Artwork Curator 0.32.24

Custom fixes in this build:

- Added context menu action: **Refresh all artwork for this item**. It runs Refresh All behavior for only the focused library item, while keeping manual/protected artwork safe.
- Select artwork keeps provider freedom, but now defaults to a compact high-quality list:
  - if enough high-quality candidates exist, lower-resolution candidates are hidden;
  - if enough preferred-language candidates exist, other-language candidates are hidden;
  - current/manual artwork remains visible even when it is low resolution or outside the preferred language.
- Added visible Select artwork settings for compact candidate filtering.
- Reordered the Artwork types ON/OFF settings and Select artwork type dialog order to: poster, fanart, clearlogo, clearart, discart, then landscape/thumb/keyart/banner/logo/character art.

# Library Artwork Curator 0.32.23

Custom fixes in this build:

- Auto provider flow is now lazy for normal automatic jobs:
  - Fetch TMDb first.
  - If all enabled targets have enough strong candidates, stop.
  - Fetch fanart.tv only for targets that still lack strong candidates.
  - Fetch TheTVDB only for remaining TV/season targets.
- Fanart completeness respects the configured fanart slot count. Example: if TMDb has 3 strong fanarts and the limit is 5, fanart.tv is fetched only to fill the remaining slots.
- Select artwork remains full/manual: it still fetches provider candidates so the user can freely choose from TMDb, fanart.tv, and TheTVDB candidates.
- Dry run is now an expert context option, hidden by default, with capped candidate output to avoid huge diagnostics files.
- Main LAC context menu is moved to the root context menu to work on episodes when the skin/Kodi does not expose Manage.
- Season cache model is fixed toward direct-season canonical rows with season.N compatibility mirrors. Existing tvshow season.N rows are mirrored to direct season rows when TV shows are processed.
- Provider request retry/timeout defaults are reduced to prevent long UI stalls from slow fallback providers.

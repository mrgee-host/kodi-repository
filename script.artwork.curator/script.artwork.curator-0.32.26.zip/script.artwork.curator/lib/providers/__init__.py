from lib.libs import mediatypes
from lib.providers.base import ProviderError
from lib.providers.fanarttv import FanartTVSeriesProvider, FanartTVMovieProvider, FanartTVMovieSetProvider
from lib.providers.themoviedb import TheMovieDBMovieProvider, TheMovieDBTVProvider, TheMovieDBEpisodeProvider, TheMovieDBMovieSetProvider, TheMovieDBSearch
from lib.providers.thetvdbv2 import TheTVDBProvider

# Remote-only video providers. Local filesystem, NFO, music, and music-video providers
# are intentionally excluded from the runtime registry.
external = {
    mediatypes.TVSHOW: (TheMovieDBTVProvider(), FanartTVSeriesProvider(), TheTVDBProvider()),
    mediatypes.MOVIE: (TheMovieDBMovieProvider(), FanartTVMovieProvider()),
    mediatypes.MOVIESET: (TheMovieDBMovieSetProvider(), FanartTVMovieSetProvider()),
    mediatypes.EPISODE: (TheMovieDBEpisodeProvider(),),
}
forced = {mediatype: () for mediatype in external}
_tmdbsearch = TheMovieDBSearch()
search = {mediatypes.MOVIESET: _tmdbsearch, mediatypes.TVSHOW: _tmdbsearch}
del _tmdbsearch

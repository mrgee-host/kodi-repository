from lib.libs import pykodi

TVSHOW = 'tvshow'
MOVIE = 'movie'
EPISODE = 'episode'
SEASON = 'season'
MOVIESET = 'set'

# Video-only fork: intentionally no music, music video, artist, album, or song types.
audiotypes = ()
require_manualid = (MOVIESET,)

PREFERRED_SOURCE_SHARED = {'0': None, '1': 'fanart.tv'}
PREFERRED_SOURCE_MEDIA = {
    'tvshows': ('themoviedb.org', (TVSHOW, SEASON, EPISODE)),
    'movies': ('themoviedb.org', (MOVIE, MOVIESET)),
}

# Strict default provider preference used when no explicit source override is selected.
# This mirrors the remote refresh script: TMDb official/images first, then fanart.tv,
# and TheTVDB as a TV fallback.
PROVIDER_PRIORITY = {
    'themoviedb.org': 30,
    'fanart.tv': 20,
    'thetvdb.com': 10,
}

addon = pykodi.get_main_addon()

def get_artinfo(mediatype, arttype):
    mediatype, arttype = hack_mediaarttype(mediatype, arttype)
    return artinfo[mediatype].get(arttype, default_artinfo)

def hack_mediaarttype(mediatype, arttype):
    if arttype.startswith('season.'):
        return SEASON, arttype.rsplit('.', 1)[1]
    return mediatype, arttype

def _art(limit=1, multiselect=False, limit_setting=False):
    return {'autolimit': limit, 'multiselect': multiselect, 'limit_setting': limit_setting, 'download': False}

default_artinfo = _art(0)
artinfo = {
    TVSHOW: {
        'poster': _art(1, False, True),
        'fanart': _art(10, True, True),
        'landscape': _art(),
        'banner': _art(),
        'thumb': _art(),
        'clearlogo': _art(1, False, True),
        'logo': _art(),
        'clearart': _art(1, False, True),
        'keyart': _art(1, False, True),
        'characterart': _art(1, False, True),
    },
    MOVIE: {
        'poster': _art(1, False, True),
        'fanart': _art(10, True, True),
        'landscape': _art(),
        'banner': _art(),
        'thumb': _art(),
        'clearlogo': _art(1, False, True),
        'logo': _art(),
        'clearart': _art(1, False, True),
        'keyart': _art(1, False, True),
        'discart': _art(),
        'characterart': _art(1, False, True),
    },
    MOVIESET: {
        'poster': _art(1, False, True),
        'fanart': _art(10, True, True),
        'landscape': _art(),
        'banner': _art(),
        'thumb': _art(),
        'clearlogo': _art(1, False, True),
        'logo': _art(),
        'clearart': _art(1, False, True),
        'keyart': _art(1, False, True),
        'discart': _art(),
    },
    SEASON: {
        'poster': _art(),
        'banner': _art(),
        'landscape': _art(),
        'thumb': _art(),
        'keyart': _art(),
    },
    EPISODE: {
        'thumb': _art(),
        'landscape': _art(),
    },
}

central_directories = {MOVIESET: False}
togenerate = dict((mediatype, False) for mediatype in artinfo)
preferred = dict((mediatype, None) for mediatype in artinfo)
onlyfs = dict((mediatype, False) for mediatype in artinfo)
othertypes = dict((mediatype, []) for mediatype in artinfo)
download_arttypes = dict((mediatype, []) for mediatype in artinfo)

ARTTYPE_SETTINGS = {
    'poster': 'arttype_poster',
    'fanart': 'arttype_fanart',
    'keyart': 'arttype_keyart',
    'banner': 'arttype_banner',
    'clearlogo': 'arttype_clearlogo',
    'logo': 'arttype_logo',
    'landscape': 'arttype_landscape',
    'thumb': 'arttype_thumb',
    'clearart': 'arttype_clearart',
    'discart': 'arttype_discart',
    'characterart': 'arttype_characterart',
}

SCOPE_SETTINGS = {
    MOVIE: 'include_movies',
    MOVIESET: 'include_movie_sets',
    TVSHOW: 'include_tvshows',
    SEASON: 'include_seasons',
    EPISODE: 'include_episodes',
}
arttype_settingskeys = [mtype + '.' + atype + ('_limit' if cfg.get('limit_setting') else '')
    for mtype, types in artinfo.items() for atype, cfg in types.items()]

def scope_enabled(mediatype):
    settingid = SCOPE_SETTINGS.get(mediatype)
    if not settingid:
        return True
    value = addon.get_setting(settingid)
    if value == '':
        return True
    return bool(value)


def arttype_enabled(arttype):
    basetype, index = _split_arttype(arttype)
    if basetype == 'fanart' and index > 0:
        value = addon.get_setting('arttype_extrafanart')
        return True if value == '' else bool(value)
    settingid = ARTTYPE_SETTINGS.get(basetype)
    if not settingid:
        return True
    value = addon.get_setting(settingid)
    if value == '':
        return True
    return bool(value)


def disabled(mediatype):
    if not scope_enabled(mediatype):
        return True
    return not any(iter_every_arttype(mediatype)) and not generatethumb(mediatype)

def iter_every_arttype(mediatype):
    for arttype, cfg in artinfo[mediatype].items():
        if not cfg['autolimit'] or not arttype_enabled(arttype):
            continue
        if arttype_enabled(arttype):
            yield arttype
        if cfg['autolimit'] > 1:
            for num in range(1, cfg['autolimit']):
                exact = arttype + str(num)
                if arttype_enabled(exact):
                    yield exact
    for arttype in othertypes[mediatype]:
        yield arttype

def downloadartwork(mediatype, arttype):
    return False

def downloadanyartwork(mediatype):
    return False

def _split_arttype(arttype):
    basetype = arttype.rstrip('0123456789')
    idx = 0 if basetype == arttype else int(arttype.replace(basetype, ''))
    return basetype, idx

def generatethumb(mediatype):
    return togenerate.get(mediatype, False)

def haspreferred_source(mediatype):
    return bool(preferred.get(mediatype))

def ispreferred_source(mediatype, provider):
    return provider == preferred.get(mediatype, '')

def provider_priority(provider):
    return PROVIDER_PRIORITY.get(provider, 0)

def only_filesystem(mediatype):
    # Remote-only fork deliberately never uses filesystem-only mode.
    return False

def update_settings():
    always_multiple_selection = addon.get_setting('always_multiple_selection')
    if not always_multiple_selection:
        _set_allmulti(False)
    for settingid in arttype_settingskeys:
        splitsetting = settingid.split('.')
        cfg = artinfo[splitsetting[0]][splitsetting[1].split('_')[0]]
        raw = addon.get_setting(settingid)
        if raw == '':
            continue
        try:
            cfg['autolimit'], cfg['multiselect'] = _get_autolimit_from_setting(settingid)
        except (TypeError, ValueError):
            pass
    if always_multiple_selection:
        _set_allmulti(True)
    for mediatype in artinfo:
        raw = addon.get_setting(mediatype + '.othertypes')
        othertypes[mediatype] = [t.strip() for t in raw.split(',') if t.strip()] if raw else []
        download_arttypes[mediatype] = []
        for cfg in artinfo[mediatype].values():
            cfg['download'] = False
    central_directories[MOVIESET] = False
    for mediatype in (EPISODE, MOVIE):
        togenerate[mediatype] = addon.get_setting('{0}.thumb_generate'.format(mediatype))
    for media, config in PREFERRED_SOURCE_MEDIA.items():
        result = addon.get_setting('preferredsource_' + media)
        for mediatype in config[1]:
            if result == '1':
                preferred[mediatype] = 'fanart.tv'
            elif result == '2':
                preferred[mediatype] = config[0]
            else:
                preferred[mediatype] = None
            onlyfs[mediatype] = False

def _get_autolimit_from_setting(settingid):
    result = addon.get_setting(settingid)
    if settingid.endswith('_limit'):
        result = int(result)
        return result, result > 1
    return (1 if result else 0), False

def _set_allmulti(always_multi):
    for typeinfo in artinfo.values():
        for cfg in typeinfo.values():
            cfg['multiselect'] = always_multi

update_settings()

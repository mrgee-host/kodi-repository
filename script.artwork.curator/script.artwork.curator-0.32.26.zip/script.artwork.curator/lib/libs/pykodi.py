import collections
import glob
import shutil
import sqlite3
import xml.etree.ElementTree as ET
try:
    from collections.abc import Mapping as ABCMapping, Sequence as ABCSequence
except ImportError:
    from collections import Mapping as ABCMapping, Sequence as ABCSequence
import os
import re
import sys
import time
import urllib
import xbmc
import xbmcaddon
import xbmcvfs
from datetime import datetime

import sys
if sys.version_info[0] >= 3:
    unicode = bytes
    basestring = bytes

from urllib.parse import quote_plus, quote, unquote

oldpython = sys.version_info < (2, 7)
if oldpython:
    import simplejson as json
else:
    import json

try:
    datetime.strptime('2112-04-01', '%Y-%m-%d')
except TypeError:
    pass

_log_level_tag_lookup = {
    xbmc.LOGDEBUG: 'D',
    xbmc.LOGINFO: 'I'
}

_log_scrub_strings = {}

ADDONID = 'script.artwork.curator'

LEGACY_ADDONID = 'script.artwork.beef'
LEGACY_MIGRATION_MARKER = '.legacy-profile-imported-v1'


def _fs_path(value):
    """Translate Kodi special:// paths to a normal local path safely."""
    result = xbmcvfs.translatePath(value)
    if isinstance(result, bytes):
        result = result.decode('utf-8', 'replace')
    return result


def _merge_settings_xml(source, destination):
    """Keep new-ID settings, but copy missing legacy values such as API keys."""
    if not os.path.isfile(source):
        return
    if not os.path.isfile(destination):
        shutil.copy2(source, destination)
        return
    try:
        source_tree = ET.parse(source)
        destination_tree = ET.parse(destination)
        source_root = source_tree.getroot()
        destination_root = destination_tree.getroot()
        current = dict((node.get('id'), node) for node in destination_root.findall('setting'))
        changed = False
        for oldnode in source_root.findall('setting'):
            settingid = oldnode.get('id')
            if not settingid:
                continue
            if settingid not in current:
                destination_root.append(oldnode)
                changed = True
                continue
            newnode = current[settingid]
            newvalue = (newnode.text or '').strip()
            oldvalue = (oldnode.text or '').strip()
            if not newvalue and oldvalue:
                newnode.text = oldnode.text
                changed = True
        if changed:
            destination_tree.write(destination, encoding='utf-8', xml_declaration=True)
    except Exception:
        # Settings migration must never block add-on startup.
        pass


def _merge_processeditems(source, destination):
    """Preserve incremental scan state after the add-on ID rename."""
    if not os.path.isfile(source):
        return
    if not os.path.isfile(destination):
        shutil.copy2(source, destination)
        return
    try:
        source_db = sqlite3.connect(source)
        destination_db = sqlite3.connect(destination)
        try:
            source_has = source_db.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='processeditems'"
            ).fetchone()
            destination_has = destination_db.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='processeditems'"
            ).fetchone()
            if not source_has:
                return
            if not destination_has:
                destination_db.close()
                source_db.close()
                shutil.copy2(source, destination)
                return
            rows = source_db.execute(
                "SELECT mediaid, mediatype, medialabel, nextdate, data FROM processeditems"
            ).fetchall()
            with destination_db:
                destination_db.executemany(
                    """INSERT OR IGNORE INTO processeditems
                    (mediaid, mediatype, medialabel, nextdate, data)
                    VALUES (?, ?, ?, ?, ?)""",
                    rows,
                )
        finally:
            try:
                source_db.close()
            except Exception:
                pass
            try:
                destination_db.close()
            except Exception:
                pass
    except Exception:
        # Processed-state migration is helpful, but startup remains safe if it fails.
        pass


def _merge_reports(source_dir, destination_dir):
    """Bring old-ID summary reports into the renamed add-on profile."""
    for source in sorted(glob.glob(os.path.join(source_dir, 'artwork-report*.txt'))):
        destination = os.path.join(destination_dir, os.path.basename(source))
        try:
            if not os.path.isfile(destination):
                shutil.copy2(source, destination)
                continue
            source_text = open(source, 'r', encoding='utf-8', errors='replace').read()
            destination_text = open(destination, 'r', encoding='utf-8', errors='replace').read()
            if source_text and source_text not in destination_text:
                with open(destination, 'a', encoding='utf-8') as handle:
                    handle.write('\n== Imported report from legacy add-on ID ==\n')
                    handle.write(source_text)
                    if not source_text.endswith('\n'):
                        handle.write('\n')
        except Exception:
            pass


def migrate_legacy_profile():
    """One-time migration after changing script.artwork.beef to script.artwork.curator."""
    source_dir = _fs_path('special://profile/addon_data/{0}/'.format(LEGACY_ADDONID))
    destination_dir = _fs_path('special://profile/addon_data/{0}/'.format(ADDONID))
    marker = os.path.join(destination_dir, LEGACY_MIGRATION_MARKER)

    if not os.path.isdir(source_dir):
        return
    if not os.path.isdir(destination_dir):
        try:
            os.makedirs(destination_dir)
        except OSError:
            pass
    if os.path.isfile(marker):
        return

    _merge_settings_xml(
        os.path.join(source_dir, 'settings.xml'),
        os.path.join(destination_dir, 'settings.xml'),
    )
    # 0.32.5 DB-first build does not migrate legacy processeditems.db.
    _merge_reports(source_dir, destination_dir)

    try:
        with open(marker, 'w', encoding='utf-8') as handle:
            handle.write('Imported legacy Artwork Beef profile data.\n')
    except Exception:
        pass


migrate_legacy_profile()

thumbnailimages = ('image://video@',)
remoteimages = ('http',)
embeddedimages = ('image://video_', 'image://music')
notimagefiles = remoteimages + thumbnailimages + embeddedimages

_main_addon = None
def get_main_addon():
    global _main_addon
    if not _main_addon:
        _main_addon = Addon()
    return _main_addon

_watch_addon = None
def is_addon_watched():
    global _watch_addon
    if _watch_addon is None:
        if not get_conditional('System.HasAddon(script.module.devhelper)'):
            _watch_addon = False
        else:
            devhelper = Addon('script.module.devhelper')
            if devhelper.get_setting('watchalladdons'):
                _watch_addon = True
            else:
                _watch_addon = ADDONID in devhelper.get_setting('watchaddons_list')

    return _watch_addon

_kodiversion = None
def get_kodi_version():
    global _kodiversion
    if _kodiversion is None:
        _kodiversion = int(get_infolabel('System.BuildVersion').split('.')[0])
    return _kodiversion

def localize(messageid):
    if isinstance(messageid, basestring):
        result = messageid
    elif messageid >= 32000 and messageid < 33000:
        result = get_main_addon().getLocalizedString(messageid)
    else:
        result = xbmc.getLocalizedString(messageid)
    try:
        return result.encode('utf-8') if isinstance(result, unicode) else result
    except:
        return result

def get_conditional(conditional):
    return xbmc.getCondVisibility(conditional)

def get_infolabel(infolabel):
    return xbmc.getInfoLabel(infolabel)

def execute_builtin(builtin_command):
    xbmc.executebuiltin(builtin_command)

def datetime_now():
    try:
        return datetime.now()
    except ImportError:
        xbmc.sleep(50)
        return datetime_now()

def datetime_strptime(date_string, format_string):
    try:
        return datetime.strptime(date_string, format_string)
    except TypeError:
        try:
            return datetime(*(time.strptime(date_string, format_string)[0:6]))
        except ImportError:
            xbmc.sleep(50)
            return datetime_strptime(date_string, format_string)

def execute_jsonrpc(jsonrpc_command):
    if isinstance(jsonrpc_command, dict):
        try:
            jsonrpc_command = json.dumps(jsonrpc_command)
        except UnicodeDecodeError:
            jsonrpc_command = json.dumps(jsonrpc_command, ensure_ascii=False)

    json_result = xbmc.executeJSONRPC(jsonrpc_command)
    try:
        return json.loads(json_result, cls=UTF8JSONDecoder)
    except UnicodeDecodeError:
        return json.loads(json_result.decode('utf-8', 'replace'), cls=UTF8JSONDecoder)

def log(message, level=xbmc.LOGDEBUG, tag=None):
    if is_addon_watched() and level < xbmc.LOGINFO:
        # Messages from this add-on are being watched, elevate to NOTICE so Kodi logs it
        level_tag = _log_level_tag_lookup[level] + ': ' if level in _log_level_tag_lookup else ''
        level = xbmc.LOGINFO
    else:
        level_tag = ''

    if isinstance(message, (dict, list)) and len(message) > 300:
        message = str(message)
    elif isinstance(message, unicode):
        message = message.encode('utf-8')
    elif not isinstance(message, str):
        message = json.dumps(message, cls=UTF8PrettyJSONEncoder)

    addontag = ADDONID if not tag else ADDONID + ':' + tag
    file_message = '%s[%s] %s' % (level_tag, addontag, scrub_message(message))
    xbmc.log(file_message, level)

def scrub_message(message):
    for string in _log_scrub_strings.values():
        message = message.replace(string,'XXXXX')
    return message

def set_log_scrubstring(key, string):
    if string and len(string) > 4:
        _log_scrub_strings[key] = string
    elif key in _log_scrub_strings:
        del _log_scrub_strings[key]

def get_language(language_format=xbmc.ENGLISH_NAME, region=False):
    language = xbmc.getLanguage(language_format, region)
    if not language or region and language.startswith('-'):
        engname = xbmc.getLanguage(xbmc.ENGLISH_NAME)
        regiontag = language
        if ' (' in engname:
            language = engname[:engname.rfind(' (')]
        if language_format != xbmc.ENGLISH_NAME:
            language = xbmc.convertLanguage(language, language_format) + regiontag
    return language

def unquoteimage(imagestring):
    # extracted thumbnail images need to keep their 'image://' encoding
    if imagestring.startswith('image://') and not imagestring.startswith(('image://video', 'image://music')):
        return unquote(imagestring[8:-1])
    return imagestring

def quoteimage(imagestring):
    if imagestring.startswith('image://'):
        return imagestring
    # Kodi goes lowercase and doesn't encode some chars
    result = 'image://{0}/'.format(quote(imagestring, '()!'))
    result = re.sub(r'%[0-9A-F]{2}', lambda mo: mo.group().lower(), result)
    return result


def quote_video_thumbnail(filepath):
    """Return Kodi's generated thumbnail image URL for a video file path.

    Kodi exposes video-frame thumbnails through the special image://video@.../
    URL scheme.  This does not write a local image file; it lets Kodi generate
    and cache a frame when the image is requested.
    """
    if not filepath:
        return ''
    if filepath.startswith('image://video@'):
        return filepath
    result = 'image://video@{0}/'.format(quote(filepath, '()!'))
    return re.sub(r'%[0-9A-F]{2}', lambda mo: mo.group().lower(), result)

def unquotearchive(filepath):
    # DEPRECATED: Krypton and below need this, Leia changed archive support to be a standard file path
    if not filepath or not filepath.startswith(('rar://', 'zip://')):
        return filepath
    result = filepath[6:].split('/', 1)[0]
    return unquote(result)

def get_command(*first_arg_keys):
    command = {}
    start = len(first_arg_keys) if first_arg_keys else 1
    for x in range(start, len(sys.argv)):
        arg = sys.argv[x].split("=")
        command[arg[0].strip().lower()] = arg[1].strip() if len(arg) > 1 else True

    if first_arg_keys:
        for i, argkey in enumerate(first_arg_keys, 1):
            if len(sys.argv) <= i:
                break
            command[argkey] = sys.argv[i]
    return command

def get_busydialog():
    return DialogBusy()

class Addon(xbmcaddon.Addon):
    def __init__(self, *args, **kwargs):
        super(Addon, self).__init__()
        self.addonid = self.getAddonInfo('id')
        self.version = self.getAddonInfo('version')
        self.path = self.getAddonInfo('path')
        self.datapath = self.getAddonInfo('profile') # WARN: This can change if Kodi profile changes
        #self.resourcespath = os.path.join('/home/pi/.kodi/addons/script.artwork.curator/resources')
        #xbmc.log(str(self.resourcespath)+'===>PHIL', level=xbmc.LOGINFO)
        try:
            self.resourcespath = os.path.join(xbmcvfs.translatePath(self.path).decode('utf-8'), u'resources')
        except:
            self.resourcespath = os.path.join(xbmcvfs.translatePath(self.path), u'resources')
        if not os.path.isdir(self.resourcespath):
            self.resourcespath = None

    def get_setting(self, settingid):
        result = self.getSetting(settingid)
        if result == 'true':
            result = True
        elif result == 'false':
            result = False
        elif settingid.endswith('_list'):
            result = [addon.strip() for addon in result.split('|')]
            if len(result) == 1 and not result[0]:
                result = []
        return result

    def set_setting(self, settingid, value):
        if settingid.endswith('_list') and not isinstance(value, basestring) \
        and isinstance(value, ABCSequence):
            value = '|'.join(value)
        elif isinstance(value, bool):
            value = 'true' if value else 'false'
        elif not isinstance(value, basestring):
            value = str(value)
        self.setSetting(settingid, value)

class ObjectJSONEncoder(json.JSONEncoder):
    # Will still flop on circular objects
    def __init__(self, *args, **kwargs):
        kwargs['skipkeys'] = True
        super(ObjectJSONEncoder, self).__init__(*args, **kwargs)

    def default(self, obj):
        # Called for objects that aren't directly JSON serializable
        if isinstance(obj, ABCMapping):
            return dict((key, obj[key]) for key in obj.keys())
        if isinstance(obj, ABCSequence):
            return list(obj)
        if callable(obj):
            return str(obj)
        try:
            result = dict(obj.__dict__)
            result['* objecttype'] = str(type(obj))
            return result
        except AttributeError:
            pass # obj has no __dict__ attribute
        result = {'* dir': dir(obj)}
        result['* objecttype'] = str(type(obj))
        return result

class UTF8PrettyJSONEncoder(ObjectJSONEncoder):
    def __init__(self, *args, **kwargs):
        kwargs['ensure_ascii'] = False
        kwargs['indent'] = 2
        kwargs['separators'] = (',', ': ')
        super(UTF8PrettyJSONEncoder, self).__init__(*args, **kwargs)

    def iterencode(self, obj, _one_shot=False):
        for result in super(UTF8PrettyJSONEncoder, self).iterencode(obj, _one_shot):
            if isinstance(result, unicode):
                result = result.encode('utf-8')
            yield result

class UTF8JSONDecoder(json.JSONDecoder):
    def raw_decode(self, s, idx=0):
        args = (s,) if oldpython else (s, idx)
        result, end = super(UTF8JSONDecoder, self).raw_decode(*args)
        result = self._json_unicode_to_str(result)
        return result, end

    def _json_unicode_to_str(self, jsoninput):
        if isinstance(jsoninput, dict):
            return dict((self._json_unicode_to_str(key), self._json_unicode_to_str(value)) for key, value in jsoninput.items())
        elif isinstance(jsoninput, list):
            return [self._json_unicode_to_str(item) for item in jsoninput]
        elif isinstance(jsoninput, unicode):
            return jsoninput.encode('utf-8')
        else:
            return jsoninput

class DialogBusy(object):
    def __init__(self):
        self.visible = False
        window = 'busydialognocancel' if get_kodi_version() >= 18 else 'busydialog'
        self._activate = 'ActivateWindow({0})'.format(window)
        self._close = 'Dialog.Close({0})'.format(window)

    def create(self):
        xbmc.executebuiltin(self._activate)
        self.visible = True

    def close(self):
        xbmc.executebuiltin(self._close)
        self.visible = False

    def __del__(self):
        if self.visible:
            try:
                xbmc.executebuiltin(self._close)
            except AttributeError:
                pass

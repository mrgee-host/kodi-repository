# v0.32.17 Select artwork order fix

- Keeps Select artwork candidate order aligned with auto/Refresh All sorting.
- Does not prepend selected/current fanart entries to the top.
- Marks matching provider candidates as selected where they naturally appear.
- Keeps current-only art at the bottom only when the URL no longer exists in provider candidates.
- No DB migration and no bundled DB changes.

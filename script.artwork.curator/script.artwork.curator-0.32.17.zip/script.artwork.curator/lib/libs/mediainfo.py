import re
import xbmc

from lib.libs import mediatypes, pykodi, quickjson, utils
from lib import artworkdb
from lib.libs.addonsettings import settings
from lib.libs.mediatypes import _split_arttype as split_arttype
from lib.libs.pykodi import log, unquoteimage, unquotearchive, localize as L

CANT_FIND_MOVIESET = 32032

INDO_PATH_MARKERS = (
    'indonesian movies [collection]',
    'indonesian movies (collection)',
    'indonesian movies collection',
)
PROTECTED_CUSTOM_SETS = {
    'indonesian movies collection',
    'thailand movies collection',
    'animation short films collection',
}

# Video-only fork. Evaluation order matters because episodes and seasons also contain tvshowid.
idmap = (
    ('episodeid', mediatypes.EPISODE),
    ('seasonid', mediatypes.SEASON),
    ('tvshowid', mediatypes.TVSHOW),
    ('movieid', mediatypes.MOVIE),
    ('setid', mediatypes.MOVIESET),
)

class MediaItem(object):
    def __init__(self, jsondata):
        self.label = jsondata.get('label', '')
        self.file = unquotearchive(jsondata.get('file'))
        self.premiered = jsondata.get('premiered')
        self.sourcemedia = _get_sourcemedia(self.file)
        self.mediatype, self.dbid = get_mediatype_id(jsondata)
        self.skip_artwork = []
        self.art = get_own_artwork(jsondata)
        self.uniqueids = _get_uniqueids(jsondata, self.mediatype)

        self.seasons = {}
        self.movies = []
        if self.mediatype in (mediatypes.EPISODE, mediatypes.SEASON):
            self.tvshowid = jsondata['tvshowid']
            self.showtitle = jsondata.get('showtitle', '')
            self.season = int(jsondata.get('season') or 0)
            self.label = (self.showtitle + ' - ' + self.label).strip(' -')
        if self.mediatype == mediatypes.EPISODE:
            self.episode = int(jsondata.get('episode') or 0)
        elif self.mediatype == mediatypes.TVSHOW:
            self.season = int(jsondata.get('season') or 0)
        elif self.mediatype == mediatypes.MOVIESET:
            self.movies = jsondata.get('movies', [])
            if self.movies:
                add_movieset_movies(self)

        self.availableart = {}
        self.missingart = []
        self.selectedart = {}
        self.forcedart = {}
        self.updatedart = []
        self.downloadedart = {}
        self.error = None
        self.missingid = False
        self.borked_filename = bool(self.file and '\ufffd' in self.file)

    @property
    def indonesia_hint(self):
        # Indonesian language override is intentionally limited to movies only.
        # Sets, TV shows, seasons, and episodes follow the common language flow.
        return self.mediatype == mediatypes.MOVIE and path_is_indonesian(self.file)

    @property
    def protected_custom_set(self):
        return self.mediatype == mediatypes.MOVIESET and self.label.strip().lower() in PROTECTED_CUSTOM_SETS


def path_is_indonesian(path):
    if str(settings.indonesian_movie_mode) == '0':
        return False
    value = (path or '').replace('/', '\\').lower()
    markers = settings.indonesian_movie_path_markers or INDO_PATH_MARKERS
    return any(marker in value for marker in markers)


def preferred_languages(mediaitem, configured_languages=()):
    """Return strict language fallback order for automatic selection.

    Indonesian movies: id -> en -> no language.
    All other media: configured language/Kodi language -> en -> no language.
    """
    result = []
    if mediaitem.indonesia_hint:
        result.extend(('id', 'en', None))
    else:
        for language in configured_languages or ():
            language = language or None
            if language not in result:
                result.append(language)
        if 'en' not in result:
            result.append('en')
        if None not in result:
            result.append(None)
    return tuple(result)


def is_known_mediatype(jsondata):
    return any(key in jsondata for key, _ in idmap)


def get_mediatype_id(jsondata):
    for key, value in idmap:
        if key in jsondata:
            return value, jsondata[key]
    raise ValueError('Unknown media type')


def get_own_artwork(jsondata):
    return dict((arttype.lower(), unquoteimage(url)) for arttype, url in jsondata.get('art', {}).items()
        if '.' not in arttype)


def has_generated_thumbnail(jsondata):
    return jsondata.get('art', {}).get('thumb', '').startswith(pykodi.thumbnailimages)


def item_has_generated_thumbnail(mediaitem):
    return mediaitem.art.get('thumb', '').startswith(pykodi.thumbnailimages)


def has_art_todownload(artmap, mediatype):
    # Remote-only fork never writes supporting files to media folders.
    return False


def arttype_matches_base(arttype, basetype):
    return re.match(r'^{0}\d*$'.format(re.escape(basetype)), arttype) is not None


def iter_urls_for_arttype(art, arttype):
    for exact in sorted(art, key=utils.natural_sort):
        if arttype_matches_base(exact, arttype):
            yield art[exact]


def iter_base_arttypes(artkeys):
    usedtypes = set()
    for arttype in sorted(artkeys, key=utils.natural_sort):
        basetype = get_basetype(arttype)
        if basetype not in usedtypes:
            yield basetype
            usedtypes.add(basetype)


def fill_multiart(original_art, basetype, artchanges=((), ())):
    """Rebuild fanart/fanart1/fanart2... continuously from selected remote URLs."""
    result = dict(original_art)
    additions, removals = artchanges
    removals = set(removals or ())
    collected = []
    for arttype in sorted(result, key=utils.natural_sort):
        url = result.get(arttype)
        if arttype_matches_base(arttype, basetype) and url and url not in removals:
            if url not in collected:
                collected.append(url)
    for url in additions or ():
        if url and url not in collected:
            collected.append(url)
    for arttype in list(result):
        if arttype_matches_base(arttype, basetype):
            result[arttype] = None
    for index, url in enumerate(collected):
        result[format_arttype(basetype, index)] = url
    return result


def iter_missing_arttypes(mediaitem, existingart):
    fromtypes = [key for key, url in existingart.items() if url]
    for arttype, artcfg in mediatypes.artinfo[mediaitem.mediatype].items():
        if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
            continue
        if artcfg['autolimit'] == 1:
            if arttype not in fromtypes:
                yield arttype
        else:
            count = sum(1 for key in fromtypes if arttype_matches_base(key, arttype))
            if count < artcfg['autolimit'] and not artworkdb.is_na(mediaitem.mediatype, mediaitem.dbid, arttype):
                yield arttype

    if mediaitem.mediatype == mediatypes.TVSHOW and not mediatypes.disabled(mediatypes.SEASON):
        for season in mediaitem.seasons:
            for arttype, artcfg in mediatypes.artinfo[mediatypes.SEASON].items():
                exact = '{0}.{1}.{2}'.format(mediatypes.SEASON, season, arttype)
                if artcfg['autolimit'] and mediatypes.arttype_enabled(arttype) and exact not in fromtypes and not artworkdb.is_na(mediaitem.mediatype, mediaitem.dbid, exact):
                    yield exact

    for arttype in mediatypes.othertypes[mediaitem.mediatype]:
        if arttype not in mediaitem.skip_artwork and arttype not in fromtypes:
            yield arttype


def keep_arttype(mediatype, arttype, arturl):
    mediatype, arttype = mediatypes.hack_mediaarttype(mediatype, arttype)
    if arttype == 'thumb' and mediatypes.generatethumb(mediatype) and (arturl or '').startswith(pykodi.thumbnailimages):
        return True
    return arttype in mediatypes.iter_every_arttype(mediatype)


def get_basetype(arttype):
    return arttype.rstrip('0123456789')


def format_arttype(basetype, index):
    return '{0}{1}'.format(basetype, index if index else '')


def update_art_in_library(mediatype, dbid, updatedart):
    if updatedart:
        quickjson.set_item_details(dbid, mediatype, art=updatedart)


def remove_local_from_texturecache(urls, include_generated=False):
    # Retained for context cleanup compatibility. Only non-remote URLs are removed.
    exclude = pykodi.remoteimages if include_generated else pykodi.notimagefiles
    for url in urls:
        if url and not url.startswith(exclude):
            quickjson.remove_texture_byurl(url)


def add_additional_iteminfo(mediaitem, processed, search=None):
    """Add seasons, usable remote IDs, and collection matching data."""
    search_provider = search.get(mediaitem.mediatype) if search else None
    if mediaitem.mediatype == mediatypes.TVSHOW:
        if not mediatypes.disabled(mediatypes.SEASON) and not mediaitem.seasons:
            mediaitem.seasons, seasonart = _get_seasons_artwork(quickjson.get_seasons(mediaitem.dbid))
            mediaitem.art.update(seasonart)
        if search_provider and 'tvdb' not in mediaitem.uniqueids:
            found = search_provider.get_more_uniqueids(mediaitem.uniqueids, mediaitem.mediatype)
            if found.get('tvdb'):
                mediaitem.uniqueids['tvdb'] = found['tvdb']
    elif mediaitem.mediatype == mediatypes.SEASON:
        series = quickjson.get_item_details(mediaitem.tvshowid, mediatypes.TVSHOW)
        mediaitem.file = series.get('file')
        mediaitem.uniqueids.update(_get_uniqueids(series, mediatypes.TVSHOW))
        tmdbid = mediaitem.uniqueids.get('tmdb') or mediaitem.uniqueids.get('unknown')
        if tmdbid:
            mediaitem.uniqueids['tmdbseason'] = '{0}/{1}'.format(tmdbid, mediaitem.season)
    elif mediaitem.mediatype == mediatypes.EPISODE:
        series = quickjson.get_item_details(mediaitem.tvshowid, mediatypes.TVSHOW)
        mediaitem.file = series.get('file') or mediaitem.file
        seriesids = _get_uniqueids(series, mediatypes.TVSHOW)
        tmdbid = seriesids.get('tmdb') or seriesids.get('unknown')
        if tmdbid:
            mediaitem.uniqueids['tmdbse'] = '{0}/{1}/{2}'.format(tmdbid, mediaitem.season, mediaitem.episode)
        tvdbid = seriesids.get('tvdb')
        if tvdbid:
            mediaitem.uniqueids.setdefault('tvdbse', '{0}/{1}/{2}'.format(tvdbid, mediaitem.season, mediaitem.episode))
    elif mediaitem.mediatype == mediatypes.MOVIESET:
        if mediaitem.protected_custom_set:
            # Never infer and overwrite manual collection artwork.
            return
        if not mediaitem.uniqueids.get('tmdb'):
            uniqueid = processed.get_data(mediaitem.dbid, mediaitem.mediatype, mediaitem.label)
            if search_provider and not uniqueid:
                results = search_provider.search(mediaitem.label, mediaitem.mediatype)
                if results:
                    exact = next((row for row in results if row['label'].lower() == mediaitem.label.lower()), results[0])
                    uniqueid = exact['uniqueids'].get('tmdb')
                processed.set_data(mediaitem.dbid, mediatypes.MOVIESET, mediaitem.label, uniqueid)
            if uniqueid:
                mediaitem.uniqueids['tmdb'] = uniqueid
            else:
                mediaitem.error = L(CANT_FIND_MOVIESET)
                log("Could not find set '{0}' on TheMovieDB".format(mediaitem.label), xbmc.LOGINFO)
        if not processed.exists(mediaitem.dbid, mediaitem.mediatype, mediaitem.label):
            _remove_set_movieposters(mediaitem)


def add_movieset_movies(mediaitem):
    if not mediaitem.movies:
        mediaitem.movies = quickjson.get_item_details(mediaitem.dbid, mediatypes.MOVIESET).get('movies', [])
    for movie in mediaitem.movies:
        movie['art'] = get_own_artwork(movie)


def _get_seasons_artwork(seasons):
    resultseasons, resultart = {}, {}
    for season in seasons:
        seasonnum = int(season.get('season') or 0)
        resultseasons[seasonnum] = season['seasonid']
        for arttype, url in season.get('art', {}).items():
            if not arttype.lower().startswith(('tvshow.', 'season.')):
                resultart['season.{0}.{1}'.format(seasonnum, arttype.lower())] = unquoteimage(url)
    return resultseasons, resultart


def _remove_set_movieposters(mediaitem):
    add_movieset_movies(mediaitem)
    if any(movie.get('art') == mediaitem.art for movie in mediaitem.movies):
        mediaitem.art = {}


def _get_uniqueids(jsondata, mediatype):
    uniqueids = dict((key, str(value)) for key, value in (jsondata.get('uniqueid') or {}).items() if value)
    imdb = jsondata.get('imdbnumber')
    if imdb and str(imdb).startswith('tt'):
        uniqueids.setdefault('imdb', str(imdb))
    if '/' in uniqueids.get('tvdb', ''):
        uniqueids['tvdbse'] = uniqueids.pop('tvdb')
    unknown = uniqueids.get('unknown')
    if unknown:
        if unknown.startswith('tt'):
            uniqueids.setdefault('imdb', unknown)
        elif mediatype in (mediatypes.TVSHOW, mediatypes.EPISODE):
            uniqueids.setdefault(settings.default_tvidsource, unknown)
    return uniqueids


def _get_sourcemedia(path):
    value = (path or '').lower()
    if 'bluray' in value or 'blu-ray' in value or 'bdmv' in value:
        return 'bluray'
    if 'dvd' in value or 'video_ts' in value:
        return 'dvd'
    if '3d' in value:
        return '3d'
    return 'unknown'

_tvshow_cache = None

def get_cached_tvshows():
    global _tvshow_cache
    if _tvshow_cache is None:
        _tvshow_cache = quickjson.get_tvshows()
    return _tvshow_cache


def get_cached_tvshow(dbid):
    return next((row for row in get_cached_tvshows() if row['tvshowid'] == dbid), {})


def clear_cache():
    global _tvshow_cache
    _tvshow_cache = None

import json as _json
import os
import time
import traceback
from contextlib import contextmanager
from urllib.parse import urlencode, urlsplit, urlunsplit, parse_qsl

import xbmc
import xbmcvfs

try:
    import xbmcaddon
except Exception:
    xbmcaddon = None

ADDON_ID = 'script.artwork.curator'
MAX_LOG_BYTES = 6 * 1024 * 1024
SENSITIVE_KEYS = ('api_key', 'apikey', 'key', 'token', 'password', 'secret', 'authorization')

_active = []
_run_id = None
_run_name = None
_run_start = None
_counters = {}


def _translate(path):
    value = xbmcvfs.translatePath(path)
    if isinstance(value, bytes):
        value = value.decode('utf-8', 'replace')
    return value


def profile_dir():
    path = _translate('special://profile/addon_data/%s/' % ADDON_ID)
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except Exception:
            pass
    return path


def diagnostics_dir():
    # Historical function name; runtime trace files belong to runtime/logs.
    path = os.path.join(profile_dir(), 'runtime', 'logs')
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except Exception:
            pass
    return path


def _canonical_name(name):
    if name in ('runtime-debug.log', 'runtime-items.log', 'runtime-selection.log', 'runtime-provider.log', 'runtime-cache.log', 'runtime-menu.log', 'runtime-service.log'):
        return 'runtime.log'
    if name == 'runtime-performance.csv':
        return 'performance.csv'
    if name == 'runtime-errors.log':
        return 'errors.log'
    return name


def log_path(name):
    return os.path.join(diagnostics_dir(), _canonical_name(name))


def _rotate(path):
    try:
        if os.path.isfile(path) and os.path.getsize(path) > MAX_LOG_BYTES:
            old = path + '.old'
            if os.path.exists(old):
                os.remove(old)
            os.rename(path, old)
    except Exception:
        pass


def _write(name, line):
    try:
        path = log_path(name)
        _rotate(path)
        with open(path, 'a', encoding='utf-8') as handle:
            handle.write(line.rstrip('\n') + '\n')
    except Exception:
        try:
            xbmc.log('[Library Artwork Curator][runtrace] write failed: %s' % traceback.format_exc(), xbmc.LOGWARNING)
        except Exception:
            pass


def _now():
    return time.strftime('%Y-%m-%d %H:%M:%S')


def _elapsed_ms(start):
    return int((time.time() - start) * 1000)


def _safe(value, maximum=500):
    try:
        text = str(value)
    except Exception:
        text = repr(value)
    text = text.replace('\r', ' ').replace('\n', ' ')
    if len(text) > maximum:
        text = text[:maximum] + '...'
    return text


def _redact_pairs(pairs):
    result = []
    for key, value in pairs:
        lk = str(key).lower()
        if any(word in lk for word in SENSITIVE_KEYS):
            value = '<redacted>'
        result.append((key, value))
    return result


def sanitize_url(url):
    try:
        parts = urlsplit(url or '')
        query = urlencode(_redact_pairs(parse_qsl(parts.query, keep_blank_values=True)))
        hostname = parts.hostname or ''
        if ':' in hostname and not hostname.startswith('['):
            hostname = '[%s]' % hostname
        try:
            port = parts.port
        except Exception:
            port = None
        host = hostname + (':%s' % port if port is not None else '')
        if parts.username is not None or parts.password is not None:
            host = '<redacted>@' + host
        return urlunsplit((parts.scheme, host, parts.path, query, parts.fragment))
    except Exception:
        return re.sub(r'(?i)(https?://)([^/\s@]+)@', r'\1<redacted>@', _safe(url))


def redact_dict(data):
    result = {}
    for key, value in (data or {}).items():
        lk = str(key).lower()
        result[key] = '<redacted>' if any(word in lk for word in SENSITIVE_KEYS) else value
    return result


def _fields(**fields):
    bits = []
    for key in sorted(fields):
        value = fields[key]
        if value is None:
            continue
        bits.append('%s=%s' % (key, _safe(value)))
    return ' | '.join(bits)


def _counter(name, amount=1):
    _counters[name] = _counters.get(name, 0) + amount


def addon_version():
    try:
        return xbmcaddon.Addon(ADDON_ID).getAddonInfo('version') if xbmcaddon else '<unknown>'
    except Exception:
        return '<unknown>'


def reset_runtime_logs():
    for name in runtime_log_names():
        try:
            with open(log_path(name), 'w', encoding='utf-8') as handle:
                handle.write('')
        except Exception:
            pass


def runtime_log_names():
    return ['runtime.log', 'performance.csv', 'errors.log']


def begin(name, **context):
    global _run_id, _run_name, _run_start, _counters
    _run_id = time.strftime('%Y%m%d-%H%M%S')
    _run_name = name
    _run_start = time.time()
    _counters = {}
    _active[:] = [name]
    line = '=' * 96
    _write('runtime-debug.log', line)
    _write('runtime-debug.log', '%s | RUN START | id=%s | name=%s | addon=%s | %s' % (
        _now(), _run_id, _safe(name), addon_version(), _fields(**context)))
    # Write the CSV header once per file. Older builds appended a header for
    # every run, making diagnostics hard to read.
    try:
        perf_path = log_path('runtime-performance.csv')
        if not os.path.isfile(perf_path) or os.path.getsize(perf_path) == 0:
            _write('runtime-performance.csv', 'time,run_id,run_name,phase,elapsed_ms,details')
    except Exception:
        _write('runtime-performance.csv', 'time,run_id,run_name,phase,elapsed_ms,details')
    try:
        xbmc.log('[Library Artwork Curator][runtrace] RUN START %s %s' % (_run_id, name), xbmc.LOGINFO)
    except Exception:
        pass


def end(success=True, **context):
    global _run_id, _run_name, _run_start
    duration = _elapsed_ms(_run_start or time.time())
    counters = ','.join('%s=%s' % (k, v) for k, v in sorted(_counters.items()))
    _write('runtime-debug.log', '%s | RUN END | id=%s | name=%s | success=%s | elapsed_ms=%s | counters=%s | %s' % (
        _now(), _run_id or '-', _safe(_run_name), success, duration, counters, _fields(**context)))
    perf('run.total', duration, success=success, counters=counters)
    try:
        xbmc.log('[Library Artwork Curator][runtrace] RUN END %s success=%s elapsed_ms=%s' % (_run_id, success, duration), xbmc.LOGINFO)
    except Exception:
        pass
    _active[:] = []
    _run_id = None
    _run_name = None
    _run_start = None


@contextmanager
def run_context(name, **context):
    already_active = bool(_active)
    if already_active:
        event('run', 'nested-start', name=name, **context)
        start = time.time()
        try:
            yield
            perf('nested.%s' % name, _elapsed_ms(start), success=True)
            event('run', 'nested-end', name=name, success=True)
        except Exception as ex:
            error('nested run failed', ex, name=name)
            perf('nested.%s' % name, _elapsed_ms(start), success=False)
            raise
    else:
        begin(name, **context)
        try:
            yield
            end(True)
        except Exception as ex:
            error('run failed', ex, name=name)
            end(False, error=repr(ex))
            raise


def event(category, message, **fields):
    _counter('event.%s' % category)
    text = '%s | %s | %s | run=%s | %s' % (_now(), category.upper(), _safe(message), _run_id or '-', _fields(**fields))
    _write('runtime-debug.log', text)
    # Menu/service aliases currently resolve to the same physical runtime.log.
    # Write a second copy only if a future layout gives them distinct files.
    alias = None
    if category in ('menu', 'dialog'):
        alias = 'runtime-menu.log'
    elif category in ('service', 'notification'):
        alias = 'runtime-service.log'
    if alias and os.path.abspath(log_path(alias)) != os.path.abspath(log_path('runtime-debug.log')):
        _write(alias, text)


def perf(phase, elapsed_ms, **fields):
    details = _fields(**fields)
    line = '%s,%s,%s,%s,%s,%s' % (
        _now(), _run_id or '-', _safe(_run_name), _safe(phase), int(elapsed_ms), _json.dumps(details, ensure_ascii=False))
    _write('runtime-performance.csv', line)


@contextmanager
def timed(phase, **fields):
    start = time.time()
    try:
        yield
        perf(phase, _elapsed_ms(start), success=True, **fields)
    except Exception as ex:
        perf(phase, _elapsed_ms(start), success=False, error=repr(ex), **fields)
        error('timed block failed', ex, phase=phase, **fields)
        raise


def error(message, ex=None, **fields):
    _counter('errors')
    text = '%s | ERROR | %s | run=%s | %s' % (_now(), _safe(message), _run_id or '-', _fields(**fields))
    _write('runtime-errors.log', text)
    if ex is not None:
        _write('runtime-errors.log', traceback.format_exc())
    _write('runtime-debug.log', text)


def item_status(action, mediaitem, arttypes=(), stage=None, percent=None):
    try:
        _counter('item_status.%s' % action)
        arttext = ','.join(str(x) for x in (arttypes or ()))
        line = '%s | run=%s | action=%s | type=%s | dbid=%s | label=%s | stage=%s | percent=%s | arttypes=%s' % (
            _now(), _run_id or '-', _safe(action), getattr(mediaitem, 'mediatype', '-'), getattr(mediaitem, 'dbid', '-'),
            _safe(getattr(mediaitem, 'label', '-')), stage, percent, _safe(arttext, 400))
        _write('runtime-items.log', line)
    except Exception:
        pass


def item_result(mediaitem, elapsed_ms, updatedart=None, error_text=None, services_hit=None, **extra):
    try:
        updatedart = updatedart or []
        if updatedart:
            _counter('items.updated')
            _counter('art.updated', len(updatedart))
        if error_text:
            _counter('items.error')
        else:
            _counter('items.processed')
        extras = _fields(**extra) if extra else ''
        line = '%s | run=%s | result | type=%s | dbid=%s | label=%s | elapsed_ms=%s | updated=%s | services_hit=%s | error=%s%s%s' % (
            _now(), _run_id or '-', getattr(mediaitem, 'mediatype', '-'), getattr(mediaitem, 'dbid', '-'),
            _safe(getattr(mediaitem, 'label', '-')), int(elapsed_ms), ','.join(updatedart), services_hit, _safe(error_text or ''),
            ' | ' if extras else '', extras)
        _write('runtime-items.log', line)
        perf('item.%s' % getattr(mediaitem, 'mediatype', 'unknown'), elapsed_ms,
             dbid=getattr(mediaitem, 'dbid', '-'), label=getattr(mediaitem, 'label', '-'), updated=len(updatedart), error=bool(error_text))
    except Exception:
        pass


def _candidate_line(index, candidate):
    provider = candidate.get('provider')
    provider_display = getattr(provider, 'display', None) or getattr(provider, 'sort', None) or provider
    rating = candidate.get('rating')
    size = candidate.get('size')
    return '    [{0}] provider={1} lang={2} size={3} rating={4} unrated={5} details_primary={6} gallery_order={7} url={8}'.format(
        index,
        _safe(provider_display, 80),
        candidate.get('language'),
        _safe(getattr(size, 'display', size), 80),
        _safe(getattr(rating, 'display', rating), 80),
        bool(candidate.get('rating_unrated')),
        bool(candidate.get('details_primary') or candidate.get('localized_primary')),
        candidate.get('gallery_order'),
        _safe(sanitize_url(candidate.get('url')), 300))


def selection(mediaitem, mediatype, artkey, candidates, usable, chosen=None, existing_count=0):
    try:
        _counter('selection.%s' % artkey)
        label = getattr(mediaitem, 'label', '-') if mediaitem is not None else '-'
        dbid = getattr(mediaitem, 'dbid', '-') if mediaitem is not None else '-'
        header = '%s | run=%s | type=%s | dbid=%s | label=%s | art=%s | candidates=%s | usable=%s | existing=%s | chosen=%s' % (
            _now(), _run_id or '-', mediatype, dbid, _safe(label), artkey,
            len(candidates or []), len(usable or []), existing_count, _safe(chosen or '-'))
        _write('runtime-selection.log', header)
        for idx, candidate in enumerate((candidates or [])[:12], 1):
            _write('runtime-selection.log', _candidate_line(idx, candidate))
        if len(candidates or []) > 12:
            _write('runtime-selection.log', '    ... %s more candidate(s)' % (len(candidates) - 12))
    except Exception:
        pass


def provider_request(provider, url, params=None, status=None, elapsed_ms=None, size=None, error_text=None):
    try:
        _counter('provider.requests')
        if error_text:
            _counter('provider.errors')
        sanitized = sanitize_url(url)
        redacted_params = redact_dict(params or {})
        line = '%s | run=%s | provider=%s | status=%s | elapsed_ms=%s | bytes=%s | error=%s | url=%s | params=%s' % (
            _now(), _run_id or '-', _safe(provider), status, elapsed_ms, size, _safe(error_text or ''), sanitized, _safe(redacted_params, 400))
        _write('runtime-provider.log', line)
        if elapsed_ms is not None:
            perf('provider.%s' % _safe(provider, 80), elapsed_ms, status=status, bytes=size, error=bool(error_text))
    except Exception:
        pass


def provider_summary(provider, mediatype=None, types=None, images=None, elapsed_ms=None, error_text=None):
    try:
        counts = {}
        for key, value in (images or {}).items():
            try:
                counts[key] = len(value or [])
            except Exception:
                counts[key] = '?'
        line = '%s | run=%s | provider-summary=%s | mediatype=%s | requested=%s | elapsed_ms=%s | counts=%s | error=%s' % (
            _now(), _run_id or '-', _safe(provider), mediatype, _safe(types), elapsed_ms, _safe(counts, 600), _safe(error_text or ''))
        _write('runtime-provider.log', line)
    except Exception:
        pass


def cache_event(message, **fields):
    text = '%s | run=%s | %s | %s' % (_now(), _run_id or '-', _safe(message), _fields(**fields))
    _write('runtime-cache.log', text)


def snapshot_runtime_state():
    rows = []
    rows.append('active_run_id=%s' % (_run_id or '-'))
    rows.append('active_run_name=%s' % (_run_name or '-'))
    rows.append('active_stack=%s' % _active)
    rows.append('counters=%s' % _counters)
    return '\n'.join(rows) + '\n'

import json
import os
import re
import time
import traceback
import zipfile

import xbmc
import xbmcgui
import xbmcvfs

from lib.libs import mediatypes, mediainfo as info, quickjson
from lib.libs.addonsettings import settings
from lib.libs.pykodi import log
from lib import runtrace, artworkdb, indonesian_collection, thailand_collection

DIAG_PREFIX = 'lac-diagnostics-'
SENSITIVE_KEYWORDS = ('apikey', 'api_key', 'token', 'password', 'secret', 'client', 'email', 'authorization')
OBSOLETE_SETTINGS = ('actor_thumb_cache',)


def _is_diagnostics_zip_name(filename):
    name = (filename or '').lower()
    return name.startswith(DIAG_PREFIX) and (name.endswith('.zip') or name.endswith('.zip.tmp') or name.endswith('.tmp'))


def _delete_old_diagnostics_zips(profile, keep=None):
    removed = []
    try:
        keep = os.path.abspath(keep) if keep else None
        for filename in os.listdir(profile):
            if not _is_diagnostics_zip_name(filename):
                continue
            path = os.path.abspath(os.path.join(profile, filename))
            if keep and path == keep:
                continue
            try:
                os.remove(path)
                removed.append(filename)
            except Exception as ex:
                log('Failed to remove old diagnostics ZIP {0}: {1!r}'.format(filename, ex), xbmc.LOGWARNING, 'diagnostics')
    except Exception:
        pass
    return removed


def _translate(path):
    value = xbmcvfs.translatePath(path)
    if isinstance(value, bytes):
        value = value.decode('utf-8', 'replace')
    return value


def _profile_dir():
    path = _translate('special://profile/addon_data/script.artwork.curator/')
    os.makedirs(path, exist_ok=True)
    return path


def _diagnostics_dir():
    path = os.path.join(_profile_dir(), 'runtime', 'diagnostics')
    os.makedirs(path, exist_ok=True)
    return path


def _runtime_dir(name):
    path = os.path.join(_profile_dir(), 'runtime', name)
    os.makedirs(path, exist_ok=True)
    return path


def _reports_dir():
    return _runtime_dir('reports')


def _logs_dir():
    return _runtime_dir('logs')


def _state_dir():
    return _runtime_dir('state')


def _exports_dir():
    return _runtime_dir('exports')


def _safe_read(path, max_bytes=None):
    try:
        if not path or not os.path.isfile(path):
            return ''
        with open(path, 'rb') as handle:
            data = handle.read(max_bytes or -1)
        return data.decode('utf-8', 'replace')
    except Exception as ex:
        return 'READ ERROR: {0}'.format(repr(ex))


TEXT_EXTENSIONS = ('.xml', '.json', '.txt', '.log', '.csv', '.md', '.old')


def _redact_text(text):
    safe = str(text or '')
    names = r'(?:api[_-]?key|apikey|token|password|secret|client[_-]?(?:id|key|secret)|email|authorization)'
    # Basic-auth userinfo, including Kodi JSON-RPC URLs.
    safe = re.sub(r'(?i)(https?://)([^/\s@]+)@', r'\1<redacted>@', safe)
    # Authorization headers.
    safe = re.sub(r'(?i)(authorization\s*[:=]\s*)(?:basic|bearer)\s+[^\s,;]+', r'\1<redacted>', safe)
    # Kodi settings XML and ordinary XML secret nodes.
    safe = re.sub(
        r'(?is)(<setting\s+id=["\']' + names + r'["\'][^>]*>)(.*?)(</setting>)',
        lambda match: match.group(1) + ('<redacted>' if match.group(2).strip() else '') + match.group(3),
        safe,
    )
    # JSON and quoted key/value forms, such as "password":"value".
    safe = re.sub(
        r'(?i)(["\']?' + names + r'["\']?\s*[:=]\s*["\'])(.*?)(["\'])',
        lambda match: match.group(1) + ('<redacted>' if match.group(2) else '') + match.group(3),
        safe,
    )
    # Unquoted key/value forms used by logs and text snapshots.
    safe = re.sub(
        r'(?i)(\b' + names + r'\b\s*[:=]\s*)([^\s,;}\]]+)',
        lambda match: match.group(1) + ('<redacted>' if match.group(2) else ''),
        safe,
    )
    # Query strings in provider and Kodi URLs.
    safe = re.sub(
        r'(?i)([?&]' + names + r'=)([^&\s]+)',
        lambda match: match.group(1) + ('<redacted>' if match.group(2) else ''),
        safe,
    )
    return safe


def _is_text_path(path):
    return str(path or '').lower().endswith(TEXT_EXTENSIONS)


def _write_text(zf, name, text):
    zf.writestr(name, _redact_text(text))


def _copy_if_exists(zf, source, dest, max_bytes=None, redact=None):
    try:
        if not source or not os.path.isfile(source):
            return False
        redact = _is_text_path(source) if redact is None else bool(redact)
        if max_bytes or redact:
            text = _safe_read(source, max_bytes=max_bytes)
            zf.writestr(dest, _redact_text(text) if redact else text)
        else:
            zf.write(source, dest)
        return True
    except Exception as ex:
        zf.writestr(dest + '.ERROR.txt', _redact_text(repr(ex)))
        return False


def _redact_value(setting_id, value):
    sid = (setting_id or '').lower()
    if any(word in sid for word in SENSITIVE_KEYWORDS):
        return '<redacted>' if value else ''
    return value or ''


def _settings_snapshot():
    try:
        profile_settings = os.path.join(_profile_dir(), 'settings.xml')
        if not os.path.isfile(profile_settings):
            return '<settings note="settings.xml not found in add-on profile" />\n'
        import xml.etree.ElementTree as ET
        tree = ET.parse(profile_settings)
        root = tree.getroot()
        for node in list(root.findall('setting')):
            sid = node.get('id') or ''
            if sid in OBSOLETE_SETTINGS:
                root.remove(node)
                continue
            node.text = _redact_value(sid, node.text)
        try:
            ET.indent(tree, space='  ')
        except Exception:
            pass
        return ET.tostring(root, encoding='unicode') + '\n'
    except Exception:
        return '<settings-error>\n{0}\n</settings-error>\n'.format(_redact_text(traceback.format_exc()))


def _environment_snapshot():
    rows = []
    rows.append('Library Artwork Curator diagnostics')
    rows.append('=' * 72)
    rows.append('Created epoch: {0}'.format(int(time.time())))
    rows.append('Addon profile: {0}'.format(_profile_dir()))
    rows.append('Addon version: {0}'.format(_addon_version()))
    labels = [
        ('Kodi version', 'System.BuildVersion'),
        ('Kodi date', 'System.Date(yyyy-mm-dd)'),
        ('Kodi time', 'System.Time'),
        ('Profile', 'System.ProfileName'),
        ('Language', 'System.Language'),
        ('Screen resolution', 'System.ScreenResolution'),
        ('Current skin', 'Skin.CurrentTheme'),
    ]
    for title, label in labels:
        try:
            rows.append('{0}: {1}'.format(title, xbmc.getInfoLabel(label)))
        except Exception:
            rows.append('{0}: <error>'.format(title))
    rows.append('')
    rows.append('Privacy: credentials, URL userinfo, and account email are redacted from text diagnostics.')
    rows.append('Note: raw kodi.log may contain local paths and remote image URLs.')
    return '\n'.join(rows) + '\n'


def _addon_version():
    try:
        import xbmcaddon
        return xbmcaddon.Addon('script.artwork.curator').getAddonInfo('version')
    except Exception:
        return '<unknown>'


def _indonesian_movie_snapshot():
    rows = ['Indonesian movie artwork snapshot', '=' * 72]
    total = included = 0
    try:
        if mediatypes.disabled(mediatypes.MOVIE):
            rows.append('Movie media type disabled in settings.')
            return '\n'.join(rows) + '\n'
        for row in quickjson.get_item_list(mediatypes.MOVIE):
            total += 1
            mediaitem = info.MediaItem(row)
            if not mediaitem.indonesia_hint:
                continue
            included += 1
            rows.append('')
            rows.append('movie:{0} | {1}'.format(mediaitem.dbid, mediaitem.label))
            rows.append('file: {0}'.format(mediaitem.file or '-'))
            rows.append('uniqueids: {0}'.format(mediaitem.uniqueids))
            for key in sorted(mediaitem.art):
                url = mediaitem.art.get(key)
                if url:
                    rows.append('art.{0}: {1}'.format(key, url))
        rows.insert(2, 'Scanned movies: {0}'.format(total))
        rows.insert(3, 'Included Indonesian movies: {0}'.format(included))
    except Exception:
        rows.append('SNAPSHOT ERROR:')
        rows.append(traceback.format_exc())
    return '\n'.join(rows) + '\n'


def _filtered_kodi_logs():
    logpath = _translate('special://logpath/')
    candidates = [os.path.join(logpath, 'kodi.log'), os.path.join(logpath, 'kodi.old.log')]
    patterns = re.compile(r'(Library Artwork Curator|script\.artwork\.curator|indorefresh|diagnostics|ArtworkProcessor|TMDb|fanart\.tv|TheTVDB|ERROR|WARNING|Traceback)', re.I)
    blocks = []
    for source in candidates:
        blocks.append('\n\n## {0}\n'.format(os.path.basename(source)))
        text = _safe_read(source, max_bytes=3_000_000)
        kept = [line for line in text.splitlines() if patterns.search(line)]
        blocks.extend(kept[-2500:] if kept else ['<no matching diagnostic lines>'])
    return _redact_text('\n'.join(blocks) + '\n')


def _profile_file_list():
    profile = _profile_dir()
    rows = []
    try:
        for filename in sorted(os.listdir(profile)):
            if _is_diagnostics_zip_name(filename):
                continue
            path = os.path.join(profile, filename)
            if os.path.isfile(path):
                rows.append('{0}\t{1} bytes'.format(filename, os.path.getsize(path)))
            elif os.path.isdir(path):
                rows.append('{0}/\t<dir>'.format(filename))
    except Exception:
        rows.append(traceback.format_exc())
    return '\n'.join(rows) + '\n'

def export():
    profile = _profile_dir()
    stamp = time.strftime('%Y%m%d-%H%M%S')
    zip_name = DIAG_PREFIX + stamp + '.zip'
    zip_path = os.path.join(profile, zip_name)
    tmp_path = zip_path + '.tmp'
    copied = []
    section_errors = []
    archive_names = set()

    def write_unique(zf, name, value):
        if name in archive_names:
            return False
        _write_text(zf, name, value)
        archive_names.add(name)
        return True

    def safe_section(zf, name, producer):
        try:
            value = producer() if callable(producer) else producer
            return write_unique(zf, name, value)
        except Exception as ex:
            section_errors.append('{0}: {1!r}'.format(name, ex))
            write_unique(zf, name + '.ERROR.txt', traceback.format_exc())
            return False

    def copy_unique(zf, source, dest, max_bytes=None, redact=None):
        if dest in archive_names:
            return False
        ok = _copy_if_exists(zf, source, dest, max_bytes=max_bytes, redact=redact)
        if ok:
            archive_names.add(dest)
        return ok

    try:
        try:
            artworkdb.checkpoint()
        except Exception:
            pass
        for folder in (_diagnostics_dir(), _reports_dir(), _logs_dir(), _state_dir(), _exports_dir()):
            os.makedirs(folder, exist_ok=True)
        if os.path.isfile(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass

        with zipfile.ZipFile(tmp_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            safe_section(zf, 'manifest.json', lambda: json.dumps({
                'addon_id': 'script.artwork.curator',
                'addon_name': 'Library Artwork Curator',
                'addon_version': _addon_version(),
                'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
                'zip_layout': 'runtime-v1',
                'redaction': 'credentials-url-userinfo-email',
            }, indent=2) + '\n')
            safe_section(zf, 'summary/environment.txt', _environment_snapshot)
            safe_section(zf, 'summary/runtime-state.txt', runtrace.snapshot_runtime_state)
            safe_section(zf, 'summary/artwork-cache-db-summary.txt', artworkdb.summary_text)
            safe_section(zf, 'summary/settings.xml', _settings_snapshot)
            safe_section(zf, 'summary/profile-files.txt', _profile_file_list)
            safe_section(zf, 'summary/indonesian-movie-artwork-snapshot.txt', _indonesian_movie_snapshot)
            safe_section(zf, 'summary/indonesian-movie-collection-state.txt', indonesian_collection.snapshot_text)
            safe_section(zf, 'runtime/reports/indonesian-collection-sync.txt', indonesian_collection.read_report)
            safe_section(zf, 'summary/thailand-movie-collection-state.txt', thailand_collection.snapshot_text)
            safe_section(zf, 'runtime/reports/thailand-collection-sync.txt', thailand_collection.read_report)
            safe_section(zf, 'logs/kodi-artwork-curator-filtered.log', _filtered_kodi_logs)

            logpath = _translate('special://logpath/')
            for src, dest in (
                (os.path.join(logpath, 'kodi.log'), 'logs/kodi.log'),
                (os.path.join(logpath, 'kodi.old.log'), 'logs/kodi.old.log'),
            ):
                if copy_unique(zf, src, dest, max_bytes=5_000_000, redact=True):
                    copied.append(dest)

            # Main database stays at profile root and remains binary/unmodified.
            db_source = os.path.join(profile, 'artwork-cache.db')
            if copy_unique(zf, db_source, 'profile/artwork-cache.db', redact=False):
                copied.append('profile/artwork-cache.db')

            runtime_groups = (
                (_state_dir(), 'runtime/state'),
                (_reports_dir(), 'runtime/reports'),
                (_logs_dir(), 'runtime/logs'),
                (_exports_dir(), 'runtime/exports'),
            )
            for folder, archive_base in runtime_groups:
                for filename in sorted(os.listdir(folder)) if os.path.isdir(folder) else []:
                    if _is_diagnostics_zip_name(filename) or filename.lower().endswith(('.zip', '.zip.tmp')):
                        continue
                    src = os.path.join(folder, filename)
                    if not os.path.isfile(src):
                        continue
                    dest = archive_base + '/' + filename
                    max_bytes = 5_000_000 if _is_text_path(filename) else None
                    if copy_unique(zf, src, dest, max_bytes=max_bytes):
                        copied.append(dest)

            addon_base = _translate('special://home/addons/script.artwork.curator/')
            for filename in ('addon.xml', 'CUSTOM_BUILD_NOTES.md', 'changelog.txt'):
                copy_unique(zf, os.path.join(addon_base, filename), 'addon/' + filename)

            if section_errors:
                write_unique(zf, 'summary/diagnostics-errors.txt', '\n'.join(section_errors) + '\n')
            write_unique(zf, 'summary/included-files.txt', '\n'.join(copied) + '\n')

        # Validate first, publish the replacement, then remove older exports.
        # This ordering preserves the last good ZIP if validation or rename fails.
        with zipfile.ZipFile(tmp_path, 'r') as test_zf:
            bad = test_zf.testzip()
            if bad:
                raise RuntimeError('Diagnostics ZIP validation failed at {0}'.format(bad))
            names = test_zf.namelist()
            if len(names) != len(set(names)):
                raise RuntimeError('Diagnostics ZIP contains duplicate archive names')
        os.replace(tmp_path, zip_path)
        removed = _delete_old_diagnostics_zips(profile, keep=zip_path)
        for folder in (_diagnostics_dir(), _reports_dir(), _logs_dir(), _exports_dir()):
            try:
                for existing_name in os.listdir(folder):
                    if not _is_diagnostics_zip_name(existing_name):
                        continue
                    existing_path = os.path.join(folder, existing_name)
                    if os.path.abspath(existing_path) == os.path.abspath(zip_path):
                        continue
                    os.remove(existing_path)
                    removed.append(existing_path)
            except Exception as ex:
                log('Diagnostics ZIP cleanup failed in {0}: {1!r}'.format(folder, ex), xbmc.LOGWARNING, 'diagnostics')
        runtrace.event('diagnostics', 'old diagnostics zips removed', removed=len(removed))
        log('Diagnostics exported: {0}'.format(zip_path), xbmc.LOGINFO, 'diagnostics')
        xbmcgui.Dialog().notification(
            'Library Artwork Curator',
            ('DIAGNOSTICS EXPORTED - {0}'.format(os.path.basename(zip_path)))[:58].upper(),
            xbmcgui.NOTIFICATION_INFO,
            7000,
        )
        return zip_path
    except Exception as ex:
        try:
            if os.path.isfile(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        try:
            fallback = os.path.join(profile, DIAG_PREFIX + stamp + '-FAILED.zip')
            with zipfile.ZipFile(fallback, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
                _write_text(zf, 'summary/export-failed.txt', traceback.format_exc())
                _write_text(zf, 'summary/environment.txt', _environment_snapshot())
            zip_path = fallback
        except Exception:
            pass
        log('Diagnostics export failed: {0}'.format(repr(ex)), xbmc.LOGERROR, 'diagnostics')
        log(traceback.format_exc(), xbmc.LOGERROR, 'diagnostics')
        xbmcgui.Dialog().notification(
            'Library Artwork Curator',
            'DIAGNOSTICS EXPORT FAILED - CHECK KODI.LOG',
            xbmcgui.NOTIFICATION_ERROR,
            8000,
        )
        return zip_path if os.path.isfile(zip_path) else None


import sys
import xbmc
import xbmcgui

from lib.artworkprocessor import ArtworkProcessor
from lib.libs import mediatypes, quickjson
from lib import runtrace
from lib.familyui import notify

VIDEO_TYPES = (mediatypes.MOVIE, mediatypes.MOVIESET, mediatypes.TVSHOW, mediatypes.SEASON, mediatypes.EPISODE)
TYPE_ALIASES = {
    'movieset': mediatypes.MOVIESET,
    'movie set': mediatypes.MOVIESET,
    'set': mediatypes.MOVIESET,
    'movies': mediatypes.MOVIE,
    'movie': mediatypes.MOVIE,
    'tvshows': mediatypes.TVSHOW,
    'tvshow': mediatypes.TVSHOW,
    'show': mediatypes.TVSHOW,
    'series': mediatypes.TVSHOW,
    'season': mediatypes.SEASON,
    'episode': mediatypes.EPISODE,
}



def _is_game_context():
    for label in (
        'ListItem.Property(lrs_game)',
        'ListItem.Property(library_ratings_type)',
        'ListItem.Property(MediaType)',
        'ListItem.Property(DBTYPE)',
        'ListItem.DBTYPE',
    ):
        value = (_info(label) or '').strip().lower()
        if value in ('true', '1', 'yes', 'game', 'games'):
            return True
    return False

def main(mode):
    listitem = getattr(sys, 'listitem', None)
    with runtrace.run_context('context.{0}'.format(mode)):
        if _is_game_context():
            notify('GAME ARTWORK IS MANAGED BY STEAM LIBRARY', xbmcgui.NOTIFICATION_WARNING, 4500)
            return
        mediatype = get_mediatype(listitem)
        dbid = get_dbid(listitem)
        runtrace.event('context', 'initial item', mode=mode, mediatype=mediatype, dbid=dbid,
                       label=_info('ListItem.Title') or _info('ListItem.Label'), path=_info('ListItem.FileNameAndPath'))
        if not dbid or mediatype not in VIDEO_TYPES:
            mediatype, dbid = resolve_library_item(listitem, mediatype, dbid)
            runtrace.event('context', 'resolved item', mode=mode, mediatype=mediatype, dbid=dbid)
        if dbid and mediatype in VIDEO_TYPES:
            ArtworkProcessor().process_item(mediatype, int(dbid), mode)
        else:
            notify('UNSUPPORTED KODI VIDEO-LIBRARY ITEM', xbmcgui.NOTIFICATION_WARNING, 6500)


def _info(label):
    try:
        return xbmc.getInfoLabel(label) or ''
    except Exception:
        return ''


def _normalize_type(value):
    value = (value or '').strip().lower()
    return TYPE_ALIASES.get(value, value or '')


def get_mediatype(listitem):
    for getter in (
        lambda: listitem.getVideoInfoTag().getMediaType(),
        lambda: _info('ListItem.DBTYPE'),
        lambda: _info('ListItem.Property(DBTYPE)'),
        lambda: _info('ListItem.Property(MediaType)'),
    ):
        try:
            value = _normalize_type(getter())
            if value:
                return value
        except Exception:
            pass
    return ''


def get_dbid(listitem):
    for getter in (
        lambda: listitem.getVideoInfoTag().getDbId(),
        lambda: _info('ListItem.DBID'),
        lambda: _info('ListItem.Property(DBID)'),
        lambda: _info('ListItem.Property(dbid)'),
        lambda: _info('ListItem.Property(movieid)'),
        lambda: _info('ListItem.Property(tvshowid)'),
        lambda: _info('ListItem.Property(seasonid)'),
        lambda: _info('ListItem.Property(episodeid)'),
        lambda: _info('ListItem.Property(setid)'),
    ):
        try:
            value = getter()
            if value is None or value == '':
                continue
            return int(value)
        except Exception:
            pass
    return None


def _unique_ids_from_context(listitem):
    result = {}
    # Common Kodi info labels and common TMDbHelper/skin properties.
    labels = {
        'tmdb': ('ListItem.UniqueID(tmdb)', 'ListItem.Property(tmdb_id)', 'ListItem.Property(tmdb)', 'ListItem.Property(TMDB_ID)'),
        'imdb': ('ListItem.UniqueID(imdb)', 'ListItem.IMDBNumber', 'ListItem.Property(imdb_id)', 'ListItem.Property(imdb)', 'ListItem.Property(IMDBNumber)'),
        'tvdb': ('ListItem.UniqueID(tvdb)', 'ListItem.Property(tvdb_id)', 'ListItem.Property(tvdb)'),
    }
    for key, candidates in labels.items():
        for label in candidates:
            value = _info(label).strip()
            if value and value not in ('0', 'None'):
                result[key] = value
                break
    try:
        tag = listitem.getVideoInfoTag()
        ids = tag.getUniqueIDs()
        if ids:
            for key, value in ids.items():
                if value and key not in result:
                    result[key.lower()] = str(value)
    except Exception:
        pass
    return result


def _title_year_path_from_context():
    title = (_info('ListItem.Title') or _info('ListItem.Label') or '').strip()
    year = (_info('ListItem.Year') or _info('ListItem.Premiered')[:4] or '').strip()
    path = (_info('ListItem.FileNameAndPath') or _info('ListItem.FilenameAndPath') or _info('ListItem.Path') or '').strip()
    return title, year, path


def _row_matches_uniqueids(row, wanted):
    ids = row.get('uniqueid') or {}
    if row.get('imdbnumber') and 'imdb' not in ids:
        ids['imdb'] = row.get('imdbnumber')
    ids = dict((str(k).lower(), str(v)) for k, v in ids.items() if v)
    for key, value in (wanted or {}).items():
        if not value:
            continue
        if ids.get(key) == str(value):
            return True
    return False


def _row_title(row):
    return (row.get('label') or row.get('title') or '').strip().lower()


def _row_year(row):
    value = row.get('year') or row.get('premiered') or row.get('firstaired') or ''
    return str(value)[:4]


def _iter_rows_for_type(mediatype):
    props = list(quickjson.typemap[mediatype][1])
    # Keep fallback properties conservative; Kodi rejects invalid JSON-RPC
    # properties on some media types. The default row label is enough for
    # title matching on sets/seasons/episodes.
    if mediatype in (mediatypes.MOVIE, mediatypes.TVSHOW):
        for extra in ('year', 'title', 'sorttitle'):
            if extra not in props:
                props.append(extra)
    return quickjson.get_item_list(mediatype, overrideprops=props)


def resolve_library_item(listitem, mediatype=None, dbid=None):
    mediatype = _normalize_type(mediatype) or ''
    if dbid and mediatype in VIDEO_TYPES:
        return mediatype, dbid

    uniqueids = _unique_ids_from_context(listitem)
    title, year, path = _title_year_path_from_context()
    title_l = title.lower()
    path_l = path.lower()

    candidate_types = [mediatype] if mediatype in VIDEO_TYPES else []
    for mtype in (mediatypes.MOVIE, mediatypes.TVSHOW, mediatypes.EPISODE, mediatypes.SEASON, mediatypes.MOVIESET):
        if mtype not in candidate_types:
            candidate_types.append(mtype)

    # Unique ID is the safest fallback for plugin/widget items.
    for mtype in candidate_types:
        try:
            for row in _iter_rows_for_type(mtype):
                if _row_matches_uniqueids(row, uniqueids):
                    return mtype, row.get(mtype + 'id')
        except Exception as ex:
            runtrace.error('context uniqueid resolve failed', ex, mediatype=mtype)

    # File/path fallback for native library-like widgets.
    if path_l:
        for mtype in candidate_types:
            try:
                for row in _iter_rows_for_type(mtype):
                    row_path = str(row.get('file') or '').lower()
                    if row_path and row_path == path_l:
                        return mtype, row.get(mtype + 'id')
            except Exception as ex:
                runtrace.error('context path resolve failed', ex, mediatype=mtype)

    # Title/year fallback. This is intentionally last because titles are not unique.
    if title_l:
        for mtype in candidate_types:
            try:
                matches = []
                for row in _iter_rows_for_type(mtype):
                    if _row_title(row) != title_l:
                        continue
                    if year and _row_year(row) and _row_year(row) != str(year)[:4]:
                        continue
                    matches.append(row)
                if len(matches) == 1:
                    return mtype, matches[0].get(mtype + 'id')
            except Exception as ex:
                runtrace.error('context title resolve failed', ex, mediatype=mtype)

    return mediatype, dbid


if __name__ == '__main__':
    main('auto')

# Library Artwork Curator 0.33.4

MrGee Kodi Family R8 active-handoff recovery baseline.

- Fresh installations create the final database schema directly.
- Startup auto-fill uses the exact Kodi scan DBID delta; if ScanStarted was missed, only Kodi `added=true` DBIDs from that same scan are accepted as recovery candidates.
- When the same media is replaced and receives a new DBID, active DBID handoff preserves valid artwork without provider scraping.
- Provider fallback, identity validation, online-first episode thumbnails, local-video thumbnail fallback, atomic writes, reports, and diagnostics remain active.
- Historical schema migrations, title-specific repairs, collision-repair jobs, and generic cache-miss fallback detection are not included.
- Clean Library performs strong one-to-one DBID handoff salvage before stale rows are deleted.

Library Artwork Curator 0.33.4

Runtime handoff recovery update:
- Late-start snapshot during an already-running Kodi video scan.
- OnUpdate added=true candidate journal only when ScanStarted was missed.
- OnRemove rows are preserved during scan/clean handoff windows.
- CleanFinished salvage moves matching artwork before stale cleanup.
- No legacy schema migration or title-specific repair was restored.

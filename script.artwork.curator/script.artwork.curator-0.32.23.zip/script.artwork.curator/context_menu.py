import sys
import xbmcgui

import context
from lib import runtrace
from lib.libs.addonsettings import addon

BASE_ACTIONS = [
    ('auto', 'Add missing artwork'),
    ('gui', 'Select artwork'),
]
EXPERT_ACTIONS = [
    ('dryrun', 'Dry run artwork selection'),
]


def _actions():
    actions = list(BASE_ACTIONS)
    if addon.get_setting('show_expert_context'):
        actions.extend(EXPERT_ACTIONS)
    return actions


def main():
    with runtrace.run_context('context.menu'):
        actions = _actions()
        labels = [label for _mode, label in actions]
        selected = xbmcgui.Dialog().select('Library Artwork Curator', labels)
        if selected < 0:
            runtrace.event('context', 'submenu cancelled')
            return
        mode = actions[selected][0]
        runtrace.event('context', 'submenu selected', mode=mode, label=actions[selected][1])
        context.main(mode)


if __name__ == '__main__':
    main()

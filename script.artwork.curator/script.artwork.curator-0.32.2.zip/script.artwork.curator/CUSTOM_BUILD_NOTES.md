# Artwork Curator — Custom Beta 0.29.1

## Scope
This custom Kodi add-on handles only video-library artwork:
- movies
- movie sets / collections
- TV shows
- seasons
- episodes

Music, music-video, artist, album, song, TheAudioDB, filesystem-art, NFO-art, media-folder download, and legacy `extrafanart` runtime workflows are excluded.

## Remote-only behavior
Artwork is stored as remote URLs in Kodi's video library. The add-on does not create `poster.jpg`, `fanart.jpg`, `fanart1.jpg`, `clearlogo.png`, or `extrafanart` folders beside media files.

Kodi's internal texture cache is still used. Enable Kodi's web server / HTTP remote-control option before using the cache menu actions.

## Existing manually selected artwork
The normal **Add missing remote artwork** action keeps an existing remote URL for a filled slot. This includes extensionless remote asset URLs used by some poster services. Existing entries are cleared only when they are raw local paths, empty values, or explicit SVG URLs. Manual selection can still replace an artwork slot intentionally.

## Provider order
- Movie: TMDb, fanart.tv
- Movie set: TMDb, fanart.tv
- TV show: TMDb, fanart.tv, TheTVDB
- Season: TMDb, fanart.tv, TheTVDB through TV-show processing
- Episode: TMDb

## Language selection
- Indonesian media: `id -> en -> no language`
- Other media: configured language -> Kodi interface language -> `en -> no language`

Indonesian media are detected from configured Indonesian folder markers and the protected Indonesian custom movie set.

## Cache actions
The executable menu includes:
- Cache missing remote artwork
- Prune obsolete Artwork Curator remote cache
- Force recache all video artwork

## Protected custom collections
These manually curated collections are not automatically matched and overwritten:
- Indonesian Movies Collection
- Thailand Movies Collection
- Animation Short Films Collection

## Beta limitation
Actor thumbnails are intentionally not rewritten by this beta. The previous standalone script updated them directly in SQLite; this add-on runs while Kodi is open and does not include a safe JSON-RPC actor-art writer yet.

## Validation performed outside Kodi
- Python source compilation
- XML parsing for `addon.xml` and `resources/settings.xml`
- stubbed Kodi module imports for entry points and processor initialization
- provider-registry audit
- local/SVG cleaner behavior
- `fanart`, `fanart1`, `fanart2` continuity behavior
- TMDb Indonesian image-language query behavior
- incremental processed-state behavior
- remote texture-cache URL request simulation

This is a beta build. Back up the Kodi profile and test on a small subset before processing the full library.


## v0.29.2 progress dialogs
Manual all-library artwork scans use a foreground progress bar. Cache missing, prune cache, and force recache also display a foreground progress bar with cancellation. Automatic processing after a Kodi library update remains background progress so it does not interrupt normal use.


## v0.29.3 compact Kodi progress
Manual scans now force the original Artwork Curator DialogProgressBG-style persistent notification, with current item and percentage. Cache maintenance commands use the same compact Kodi background progress notification. Automatic library-update processing continues to respect the configured progress-display preference.


## 0.29.4 progress detail
The compact Kodi background notification now exposes the active stage and artwork types. Examples: `Artwork Curator: CARI REMOTE · poster, fanart`, `Artwork Curator: TAMBAH LIBRARY · clearlogo`, and `Artwork Curator: CACHE DOWNLOAD · fanart3`.


## 0.29.5 compact one-word progress labels
Progress actions use normal capitalization and exactly one word. Examples: `Artwork Curator: Cek · poster`, `Artwork Curator: Cari · fanart`, `Artwork Curator: Tambah · clearlogo`, and `Artwork Curator: Download · fanart3`.


## 0.29.6 English one-word progress labels
Progress actions are English, use normal capitalization, and remain exactly one word. Examples: `Artwork Curator: Checking · poster`, `Artwork Curator: Searching · fanart`, `Artwork Curator: Adding · clearlogo`, and `Artwork Curator: Downloading · fanart3`.


## 0.29.7 faster bulk scans
`Add missing remote artwork` now focuses on provider lookup and URL assignment. Immediate texture-cache downloading is OFF by default through the new `Precache during artwork scan` setting. Run `Cache missing remote artwork` separately after a bulk scan when cache warming is needed. Batch cache warming uses four bounded workers, reuses one texture index, and avoids unbounded threads.


## 0.29.8 episode artwork simplification
Episodes now use only `thumb` and `landscape`, both sourced from the TMDb still image. Episode `fanart` and `fanart#` are no longer requested or assigned. Existing legacy episode fanart references are cleared when episodes are processed in the next normal scan. Movie, set, TV-show, and season fanart remain unchanged.


## 0.30.1 add-on ID change
The internal Kodi add-on ID is now `script.artwork.curator` and the package folder inside the ZIP matches that new ID. Because Kodi treats this as a different add-on, uninstall the previous custom build that still used the old ID before installing 0.30.1.


## 0.30.2 legacy profile migration
On first startup, Artwork Curator imports legacy profile data from `special://profile/addon_data/script.artwork.beef/` into `special://profile/addon_data/script.artwork.curator/`. This includes prior `artwork-report*.txt` files, `processeditems.db`, and missing values from `settings.xml`. The migration is one-time and does not overwrite newer non-empty settings.


## 0.30.3 stability guard
Long-running artwork scans now call Kodi's `InhibitScreensaver(true)` and `InhibitIdleShutdown(true)` built-ins, then release both states in `finally` blocks. Per-item exceptions are logged and skipped so one malformed item does not abort an entire library scan. The service dispatcher also logs and recovers unexpected Python exceptions.


## 0.30.4 Indonesian refresh tool
A new manual command, `Refresh Indonesian artwork`, scans Indonesian library items only. It re-queries providers with the Indonesian language priority (`id`, then `en`, then no language), refreshes curator-managed remote artwork, and preserves TPDb or other manually chosen non-curator URLs. The tool also refreshes season artwork when processing Indonesian TV shows.


## 0.30.5 latest-run report fix
Every completed run now writes `artwork-last-run-summary.txt` in the add-on profile. The in-app report viewer reads that dedicated summary first, then appends the rolling history. This keeps the visible report aligned with the final notification count.


## 0.30.6 auto-run, report, and poster-quality fixes
Automatic new-video processing is enabled once after upgrade. The user can disable it later from General settings. Latest-run reports now use `xbmcvfs.File`, which is safer for Kodi profile paths. Poster selection now rejects posters below the configured minimum height (default 1000px), and TMDb details-endpoint posters can no longer bypass that filter.


## 0.30.7 TMDb poster-gallery ordering
Automatic poster selection now respects the order returned by the TMDb `/images` gallery inside the selected language/provider group. The details-endpoint `poster_path` is no longer injected ahead of gallery candidates; it is used only when the gallery contains no poster rows. Minimum poster-height filtering still applies.


## 0.30.8 localized Indonesian primary poster
For Indonesian media, Artwork Curator requests the TMDb details endpoint with `language=id-ID` and promotes its `poster_path` as the main poster. When that poster is also present in `/images`, the existing row is reused so its real dimensions and rating remain available to quality filters. The `/images` gallery remains the source for fallback posters and additional artwork.


## 0.30.9 Indonesian refresh diagnostics
Every `Refresh Indonesian artwork` run now overwrites `indonesian-refresh-debug.txt` in the add-on profile. The main menu includes `Show Indonesian refresh log`. The log records scan inclusion, file path, TMDb IDs, current poster, candidate posters with quality metadata, selected poster, applied update, and the poster URL read back from Kodi after JSON-RPC update. The path detector also accepts `Indonesian Movies (Collection)`.


## 0.30.10 debug append fix
`xbmcvfs.File(..., "a")` did not reliably append on the target Kodi portable setup. The Indonesian refresh logger now translates the Kodi profile path and uses normal Python append mode, closing the file after every log line.


## 0.30.11 refresh confirmation dialog fix
The TPDb preservation note was accidentally passed as the `nolabel` argument of `xbmcgui.Dialog().yesno()`. It now appears in the body text, while the buttons are `Refresh` and `Cancel`.


## 0.30.12 poster rating-filter fix
Poster candidates no longer use the generic minimum-rating threshold. TMDb poster vote scores are often sparse and caused correctly localized posters to be rejected while unrated posters received a neutral default score and survived. Posters are now selected using language priority, localized-primary promotion, gallery order, and minimum height. Other artwork types keep the minimum-rating filter.


## 0.30.13 unrated artwork fallback
`Not rated` artwork is no longer treated as if it had a neutral rating of 5. TMDb, fanart.tv, and TheTVDB rows now carry an explicit `rating_unrated` flag. For non-poster artwork, rated candidates that pass the configured threshold are selected first. Unrated rows are used only if no viable rated candidate remains; for multi-fanart slots, this naturally fills rated rows first and then uses unrated fallbacks for any remaining slots. Poster selection remains independent from votes.


## 0.30.14 rating tiers
For non-poster artwork, `Not rated` is now always the final fallback. Explicitly rated artwork remains eligible even when its score is below the preferred minimum. The minimum-rating setting now defines a preferred tier rather than a hard rejection rule. Selection order is: rated at or above the preference, rated below the preference, then unrated.


## 0.30.15 deterministic provider-index ordering
Artwork ratings and likes are now informational only. Automatic selection no longer filters or reorders candidates by rating. Inside each language/provider group, the provider API response index is preserved. Language priority, provider priority, localized Indonesian primary-poster promotion, title-free fanart preference, and minimum resolution checks remain active. The visible minimum-rating slider was removed.


## 0.30.16 movie-only Indonesian specialization
Indonesian handling now applies only to movies stored under an Indonesian Movies collection folder. Movie sets, TV shows, seasons, and episodes follow the common language flow. TMDb details are requested in an explicit chain: preferred/configured language, then English, then raw details. `/images` remains the indexed source for extra artwork and provider fallbacks. The manual command is now `Refresh Indonesian movie artwork` and scans movies only.


## 0.30.17 diagnostics export
The main menu now includes `Export diagnostics`. It creates `artwork-curator-diagnostics-YYYYMMDD-HHMMSS.zip` in the add-on profile folder. The ZIP contains Kodi logs, filtered Artwork Curator log lines, redacted settings, latest reports, Indonesian refresh debug logs, processed-items state, and a current Indonesian movie artwork snapshot for analysis.


## 0.30.18 runtime debug logs
A new `lib/runtrace.py` runtime logger records menu actions, service signals, provider calls, item progress, selection decisions, cache operations, errors, and performance timings. The diagnostics ZIP now includes the runtime logs and a runtime-state snapshot. API keys and sensitive request parameters are redacted. Logs rotate automatically when they exceed the size limit.


## 0.31.0 LRS-style core beta
This build starts the LRS-style architecture. Automatic new-library processing uses queued Kodi OnUpdate DBIDs and no longer falls back to scanning the full library after every scan. Scope toggles control Movies, Movie sets, TV shows, Seasons, and Episodes. Normal scans ignore the legacy Kodi `icon` slot; a dedicated `Clean legacy icon artwork` menu removes all icon slots only when explicitly requested. `artwork-cache.db` stores run history, item snapshots, artwork slots, and maintenance events. Indonesian movie detection is configurable via settings. Actor thumbnail cache remains OFF by default and is not part of normal scans.


## 0.32.0 LRS-style menu/db beta
Main menus were reduced to LRS-style actions. Queued new items now refresh enabled artwork for queued DBIDs instead of missing-only. Missing-only runs write N/A slot state to artwork-cache.db so unavailable artwork is not retried every run. Global artwork-type toggles were added. Texture cache tools live in a submenu and prune is restricted to known movie/TV/season/episode artwork. Identify unmatched movie sets was removed from menus.


## 0.32.1 LRS-style hotfix
This hotfix repairs the internal artwork-cache.db schema and makes database access non-fatal. Existing broken 0.32.0 databases are repaired in place by creating missing tables before indexes. Diagnostics export now continues even when one section fails. Queued new library items are persisted and only cleared after successful processing. Clean legacy icon artwork intentionally scans every video icon slot and no longer follows library scope settings.


## 0.32.2 LRS-style polish hotfix
Notifications now follow the LRS `{processed}/{total} TITLE - PHASE` format. Heavy Refresh all shows a confirmation dialog. Clean legacy icon skips Kodi default fallback icons. Cache/prune progress tries to show the related item title. Texture-cache collection deduplicates URLs and prune includes movie sets while still protecting blur/skin/addon/resource caches. Settings are simplified and artwork type toggles are in the user-requested order.

import os
import sqlite3
import time
import traceback

import xbmcvfs

from lib.libs import pykodi
from lib import runtrace

ADDON_ID = 'script.artwork.curator'
DB_NAME = 'artwork-cache.db'
SCHEMA_VERSION = 3


def _translate(path):
    value = xbmcvfs.translatePath(path)
    if isinstance(value, bytes):
        value = value.decode('utf-8', 'replace')
    return value


def profile_dir():
    path = _translate('special://profile/addon_data/%s/' % ADDON_ID)
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except Exception:
            pass
    return path


def db_path():
    return os.path.join(profile_dir(), DB_NAME)


def _now():
    return int(time.time())


def elapsed_text(ms):
    try:
        ms = int(ms or 0)
    except Exception:
        ms = 0
    if ms < 1000:
        return '%d ms' % ms
    seconds = int(round(ms / 1000.0))
    if seconds < 60:
        return '%ds' % seconds
    minutes, seconds = divmod(seconds, 60)
    if minutes < 60:
        return '%dm %02ds' % (minutes, seconds)
    hours, minutes = divmod(minutes, 60)
    return '%dh %02dm %02ds' % (hours, minutes, seconds)


def _item_key(mediatype, dbid):
    return '%s:%s' % (mediatype, dbid)


def is_default_icon_url(url):
    lower = (url or '').lower()
    return 'defaultvideo.png' in lower or 'defaultplaylist.png' in lower or 'defaultfolder.png' in lower


def _log_error(message, ex=None, **kwargs):
    try:
        if ex is not None:
            runtrace.error(message, ex, **kwargs)
        else:
            runtrace.event('artworkdb', message, **kwargs)
    except Exception:
        pass


def _addon_version():
    try:
        return pykodi.get_main_addon().version
    except Exception:
        return '<unknown>'


def _repair_corrupt_db(path, ex):
    try:
        if os.path.isfile(path):
            backup = path + '.broken-' + time.strftime('%Y%m%d-%H%M%S')
            os.replace(path, backup)
            _log_error('Renamed broken artwork-cache.db', ex, backup=backup)
            for suffix in ('-wal', '-shm'):
                sidecar = path + suffix
                if os.path.exists(sidecar):
                    try:
                        os.remove(sidecar)
                    except Exception:
                        pass
    except Exception as inner:
        _log_error('Could not rename broken artwork-cache.db', inner)


def connect():
    path = db_path()
    try:
        conn = sqlite3.connect(path)
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA synchronous=NORMAL')
        init(conn)
        return conn
    except sqlite3.DatabaseError as ex:
        try:
            conn.close()
        except Exception:
            pass
        _repair_corrupt_db(path, ex)
        conn = sqlite3.connect(path)
        conn.execute('PRAGMA journal_mode=WAL')
        conn.execute('PRAGMA synchronous=NORMAL')
        init(conn)
        return conn


def init(conn=None):
    own = conn is None
    conn = conn or sqlite3.connect(db_path())
    try:
        conn.executescript('''
        CREATE TABLE IF NOT EXISTS metadata (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS runs (
            run_id TEXT PRIMARY KEY,
            action TEXT,
            started_at INTEGER,
            finished_at INTEGER,
            status TEXT,
            total_items INTEGER DEFAULT 0,
            updated_items INTEGER DEFAULT 0,
            updated_artwork INTEGER DEFAULT 0,
            errors INTEGER DEFAULT 0,
            elapsed_ms INTEGER DEFAULT 0,
            notes TEXT
        );
        CREATE TABLE IF NOT EXISTS library_items (
            item_key TEXT PRIMARY KEY,
            media_type TEXT,
            dbid INTEGER,
            title TEXT,
            show_title TEXT,
            season INTEGER,
            episode INTEGER,
            file TEXT,
            uniqueids TEXT,
            last_seen_at INTEGER,
            last_processed_at INTEGER,
            status TEXT,
            error TEXT
        );
        CREATE TABLE IF NOT EXISTS artwork_slots (
            item_key TEXT,
            art_type TEXT,
            url TEXT,
            is_icon INTEGER DEFAULT 0,
            updated_at INTEGER,
            PRIMARY KEY (item_key, art_type)
        );
        CREATE TABLE IF NOT EXISTS artwork_status (
            item_key TEXT,
            art_type TEXT,
            status TEXT,
            reason TEXT,
            updated_at INTEGER,
            PRIMARY KEY (item_key, art_type)
        );
        CREATE TABLE IF NOT EXISTS queued_items (
            item_key TEXT PRIMARY KEY,
            media_type TEXT,
            dbid INTEGER,
            queued_at INTEGER,
            source TEXT
        );
        CREATE TABLE IF NOT EXISTS run_items (
            run_id TEXT,
            item_key TEXT,
            media_type TEXT,
            dbid INTEGER,
            title TEXT,
            status TEXT,
            updated_arttypes TEXT,
            elapsed_ms INTEGER DEFAULT 0,
            error TEXT,
            PRIMARY KEY (run_id, item_key)
        );
        CREATE TABLE IF NOT EXISTS maintenance_events (
            event_id INTEGER PRIMARY KEY AUTOINCREMENT,
            run_id TEXT,
            action TEXT,
            media_type TEXT,
            dbid INTEGER,
            title TEXT,
            art_type TEXT,
            old_url TEXT,
            status TEXT,
            created_at INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_library_items_type_dbid ON library_items(media_type, dbid);
        CREATE INDEX IF NOT EXISTS idx_artwork_slots_type ON artwork_slots(art_type);
        CREATE INDEX IF NOT EXISTS idx_artwork_status_status ON artwork_status(status);
        CREATE INDEX IF NOT EXISTS idx_queued_items_type_dbid ON queued_items(media_type, dbid);
        CREATE INDEX IF NOT EXISTS idx_run_items_run ON run_items(run_id);
        CREATE INDEX IF NOT EXISTS idx_maintenance_action ON maintenance_events(action);
        ''')

        # Lightweight schema upgrades for 0.32.2. ALTER failures are ignored so old/new DBs both work.
        for statement in (
            "ALTER TABLE runs ADD COLUMN elapsed_text TEXT",
            "ALTER TABLE run_items ADD COLUMN elapsed_text TEXT",
            "ALTER TABLE run_items ADD COLUMN parent_title TEXT",
            "ALTER TABLE run_items ADD COLUMN season INTEGER",
            "ALTER TABLE run_items ADD COLUMN episode INTEGER",
            "ALTER TABLE run_items ADD COLUMN display_title TEXT",
            "ALTER TABLE artwork_slots ADD COLUMN title TEXT",
            "ALTER TABLE artwork_slots ADD COLUMN parent_title TEXT",
            "ALTER TABLE artwork_slots ADD COLUMN season INTEGER",
            "ALTER TABLE artwork_slots ADD COLUMN episode INTEGER",
            "ALTER TABLE artwork_slots ADD COLUMN display_title TEXT",
            "ALTER TABLE artwork_status ADD COLUMN title TEXT",
            "ALTER TABLE artwork_status ADD COLUMN parent_title TEXT",
            "ALTER TABLE artwork_status ADD COLUMN season INTEGER",
            "ALTER TABLE artwork_status ADD COLUMN episode INTEGER",
            "ALTER TABLE artwork_status ADD COLUMN display_title TEXT",
            "ALTER TABLE queued_items ADD COLUMN title TEXT",
            "ALTER TABLE queued_items ADD COLUMN parent_title TEXT",
            "ALTER TABLE queued_items ADD COLUMN season INTEGER",
            "ALTER TABLE queued_items ADD COLUMN episode INTEGER",
            "ALTER TABLE queued_items ADD COLUMN display_title TEXT"
        ):
            try:
                conn.execute(statement)
            except Exception:
                pass
        conn.execute('INSERT OR REPLACE INTO metadata(key, value) VALUES(?, ?)', ('schema_version', str(SCHEMA_VERSION)))
        conn.execute('INSERT OR REPLACE INTO metadata(key, value) VALUES(?, ?)', ('addon_version', _addon_version()))
        conn.commit()
    finally:
        if own:
            conn.close()


def ensure():
    try:
        init()
        return True
    except Exception as ex:
        _log_error('artwork-cache.db ensure failed', ex)
        return False


def display_title_for_item(mediaitem):
    title = getattr(mediaitem, 'label', '') or ''
    show = getattr(mediaitem, 'showtitle', '') or ''
    season = getattr(mediaitem, 'season', None)
    episode = getattr(mediaitem, 'episode', None)
    if getattr(mediaitem, 'mediatype', '') == 'episode':
        try:
            return '%s - S%02dE%02d - %s' % (title, int(season or 0), int(episode or 0), show)
        except Exception:
            return '%s - %s' % (title, show) if show else title
    if getattr(mediaitem, 'mediatype', '') == 'season' and show:
        return '%s - %s' % (title, show)
    return title


def _jsonish(value):
    try:
        import json
        return json.dumps(value or {}, sort_keys=True)
    except Exception:
        return repr(value)


def begin_run(action, total_items=0, notes=''):
    try:
        run_id = time.strftime('%Y%m%d-%H%M%S') + '-' + action.replace(' ', '_').replace('.', '_')[:40]
        conn = connect()
        try:
            conn.execute('INSERT OR REPLACE INTO runs(run_id, action, started_at, status, total_items, notes) VALUES(?, ?, ?, ?, ?, ?)',
                         (run_id, action, _now(), 'running', int(total_items or 0), notes or ''))
            conn.commit()
        finally:
            conn.close()
        return run_id
    except Exception as ex:
        _log_error('artwork-cache.db begin_run failed', ex, action=action)
        return None


def finish_run(run_id, status='finished', updated_items=0, updated_artwork=0, errors=0, elapsed_ms=0, notes=''):
    if not run_id:
        return
    try:
        conn = connect()
        try:
            conn.execute("""UPDATE runs SET finished_at=?, status=?, updated_items=?, updated_artwork=?, errors=?, elapsed_ms=?, elapsed_text=?, notes=COALESCE(NULLIF(?, ''), notes) WHERE run_id=?""",
                         (_now(), status, int(updated_items or 0), int(updated_artwork or 0), int(errors or 0), int(elapsed_ms or 0), elapsed_text(elapsed_ms), notes or '', run_id))
            conn.commit()
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db finish_run failed', ex, run_id=run_id)


def record_item(mediaitem, run_id=None, status='processed', updatedart=None, elapsed_ms=0, error=None):
    try:
        conn = connect()
        item_key = _item_key(mediaitem.mediatype, mediaitem.dbid)
        now = _now()
        updatedart = list(updatedart or getattr(mediaitem, 'updatedart', []) or [])
        with conn:
            conn.execute("""INSERT OR REPLACE INTO library_items(item_key, media_type, dbid, title, show_title, season, episode, file, uniqueids, last_seen_at, last_processed_at, status, error) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                         (item_key, mediaitem.mediatype, int(mediaitem.dbid), getattr(mediaitem, 'label', ''), getattr(mediaitem, 'showtitle', ''), getattr(mediaitem, 'season', None), getattr(mediaitem, 'episode', None), getattr(mediaitem, 'file', '') or '', _jsonish(getattr(mediaitem, 'uniqueids', {})), now, now, status, error or getattr(mediaitem, 'error', None)))
            display_title = display_title_for_item(mediaitem)
            for art_type, url in sorted((getattr(mediaitem, 'art', {}) or {}).items()):
                if url and not (art_type == 'icon' and is_default_icon_url(url)):
                    conn.execute('INSERT OR REPLACE INTO artwork_slots(item_key, art_type, url, is_icon, updated_at) VALUES (?, ?, ?, ?, ?)',
                                 (item_key, art_type, url, 1 if art_type == 'icon' else 0, now))
                    try:
                        conn.execute('UPDATE artwork_slots SET title=?, parent_title=?, season=?, episode=?, display_title=? WHERE item_key=? AND art_type=?',
                                     (getattr(mediaitem, 'label', ''), getattr(mediaitem, 'showtitle', ''), getattr(mediaitem, 'season', None), getattr(mediaitem, 'episode', None), display_title, item_key, art_type))
                    except Exception:
                        pass
            if run_id:
                conn.execute('INSERT OR REPLACE INTO run_items(run_id, item_key, media_type, dbid, title, status, updated_arttypes, elapsed_ms, error) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                             (run_id, item_key, mediaitem.mediatype, int(mediaitem.dbid), getattr(mediaitem, 'label', ''), status, ','.join(updatedart), int(elapsed_ms or 0), error or getattr(mediaitem, 'error', None)))
                try:
                    conn.execute('UPDATE run_items SET elapsed_text=?, parent_title=?, season=?, episode=?, display_title=? WHERE run_id=? AND item_key=?',
                                 (elapsed_text(elapsed_ms), getattr(mediaitem, 'showtitle', ''), getattr(mediaitem, 'season', None), getattr(mediaitem, 'episode', None), display_title, run_id, item_key))
                except Exception:
                    pass
    except Exception as ex:
        _log_error('artwork-cache.db record_item failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''))


def record_maintenance(run_id, action, mediatype, dbid, title, art_type, old_url, status='updated'):
    try:
        conn = connect()
        with conn:
            conn.execute('INSERT INTO maintenance_events(run_id, action, media_type, dbid, title, art_type, old_url, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)',
                         (run_id, action, mediatype, int(dbid), title or '', art_type, old_url or '', status, _now()))
    except Exception as ex:
        _log_error('artwork-cache.db record_maintenance failed', ex, action=action, mediatype=mediatype, dbid=dbid)


def queue_item(mediatype, dbid, source='kodi'):
    try:
        conn = connect()
        try:
            with conn:
                conn.execute('INSERT OR REPLACE INTO queued_items(item_key, media_type, dbid, queued_at, source) VALUES(?, ?, ?, ?, ?)',
                             (_item_key(mediatype, dbid), mediatype, int(dbid), _now(), source or 'kodi'))
        finally:
            conn.close()
        return True
    except Exception as ex:
        _log_error('artwork-cache.db queue_item failed', ex, mediatype=mediatype, dbid=dbid)
        return False


def get_queued_items(media_types=None):
    try:
        conn = connect()
        try:
            params = []
            where = ''
            if media_types:
                placeholders = ','.join('?' for _ in media_types)
                where = ' WHERE media_type IN (%s)' % placeholders
                params = list(media_types)
            return [(row[0], row[1]) for row in conn.execute('SELECT media_type, dbid FROM queued_items%s ORDER BY queued_at ASC' % where, params)]
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db get_queued_items failed', ex)
        return []


def clear_queued_items(rows):
    if not rows:
        return 0
    try:
        conn = connect()
        count = 0
        try:
            with conn:
                for mediatype, dbid in rows:
                    cur = conn.execute('DELETE FROM queued_items WHERE item_key=?', (_item_key(mediatype, dbid),))
                    count += cur.rowcount
            return count
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db clear_queued_items failed', ex)
        return 0


def pop_queued_items(media_types=None):
    rows = get_queued_items(media_types)
    clear_queued_items(rows)
    return rows


def queued_count():
    try:
        conn = connect()
        try:
            return conn.execute('SELECT COUNT(*) FROM queued_items').fetchone()[0]
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db queued_count failed', ex)
        return 0


def mark_art_status_item(mediaitem, art_type, status, reason=''):
    try:
        mark_art_status(mediaitem.mediatype, mediaitem.dbid, art_type, status, reason)
        conn = connect()
        try:
            with conn:
                conn.execute('UPDATE artwork_status SET title=?, parent_title=?, season=?, episode=?, display_title=? WHERE item_key=? AND art_type=?',
                             (getattr(mediaitem, 'label', ''), getattr(mediaitem, 'showtitle', ''), getattr(mediaitem, 'season', None), getattr(mediaitem, 'episode', None), display_title_for_item(mediaitem), _item_key(mediaitem.mediatype, mediaitem.dbid), art_type))
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db mark_art_status_item failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''), art_type=art_type)


def mark_art_status(mediatype, dbid, art_type, status, reason=''):
    try:
        conn = connect()
        try:
            with conn:
                conn.execute('INSERT OR REPLACE INTO artwork_status(item_key, art_type, status, reason, updated_at) VALUES(?, ?, ?, ?, ?)',
                             (_item_key(mediatype, dbid), art_type, status, reason or '', _now()))
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db mark_art_status failed', ex, mediatype=mediatype, dbid=dbid, art_type=art_type)


def is_na(mediatype, dbid, art_type):
    try:
        conn = connect()
        try:
            row = conn.execute('SELECT status FROM artwork_status WHERE item_key=? AND art_type=?', (_item_key(mediatype, dbid), art_type)).fetchone()
            return bool(row and row[0] == 'N/A')
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db is_na failed', ex, mediatype=mediatype, dbid=dbid, art_type=art_type)
        return False


def reset_na():
    try:
        conn = connect()
        try:
            with conn:
                cur = conn.execute("DELETE FROM artwork_status WHERE status='N/A'")
                return cur.rowcount
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db reset_na failed', ex)
        return 0


def known_artwork_urls(media_types=None):
    try:
        conn = connect()
        try:
            params = []
            where = "WHERE url IS NOT NULL AND url != ''"
            if media_types:
                placeholders = ','.join('?' for _ in media_types)
                where += ' AND item_key IN (SELECT item_key FROM library_items WHERE media_type IN (%s))' % placeholders
                params = list(media_types)
            return set(row[0] for row in conn.execute('SELECT DISTINCT url FROM artwork_slots ' + where, params) if row[0])
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db known_artwork_urls failed', ex)
        return set()


def summary_text():
    rows = ['Artwork Curator cache DB summary', '=' * 72, 'path: %s' % db_path()]
    try:
        ensure()
        conn = connect()
        try:
            for table in ('metadata', 'runs', 'library_items', 'artwork_slots', 'artwork_status', 'queued_items', 'run_items', 'maintenance_events'):
                try:
                    count = conn.execute('SELECT COUNT(*) FROM %s' % table).fetchone()[0]
                    rows.append('%s: %s' % (table, count))
                except Exception as table_ex:
                    rows.append('%s: ERROR %r' % (table, table_ex))
            rows.append('')
            rows.append('Recent runs:')
            try:
                for row in conn.execute("SELECT run_id, action, status, total_items, updated_items, updated_artwork, errors, COALESCE(elapsed_text, elapsed_ms || ' ms') FROM runs ORDER BY started_at DESC LIMIT 20"):
                    rows.append('%s | %s | %s | total=%s updated_items=%s artwork=%s errors=%s elapsed=%s' % row)
            except Exception:
                rows.append('Recent runs query failed:')
                rows.append(traceback.format_exc())
        finally:
            conn.close()
    except Exception:
        rows.append('DB SUMMARY ERROR:')
        rows.append(traceback.format_exc())
    return '\n'.join(rows) + '\n'



def cleanup_retention(keep_runs=30):
    try:
        conn = connect()
        try:
            rows = conn.execute('SELECT run_id FROM runs ORDER BY started_at DESC LIMIT -1 OFFSET ?', (int(keep_runs),)).fetchall()
            old_ids = [row[0] for row in rows]
            if not old_ids:
                return 0
            with conn:
                for run_id in old_ids:
                    conn.execute('DELETE FROM run_items WHERE run_id=?', (run_id,))
                    conn.execute('DELETE FROM maintenance_events WHERE run_id=?', (run_id,))
                    conn.execute('DELETE FROM runs WHERE run_id=?', (run_id,))
            try:
                conn.execute('VACUUM')
            except Exception:
                pass
            return len(old_ids)
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db cleanup_retention failed', ex)
        return 0

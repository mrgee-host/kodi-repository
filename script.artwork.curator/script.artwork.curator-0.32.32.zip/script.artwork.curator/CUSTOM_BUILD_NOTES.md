# Library Artwork Curator 0.32.32 custom build

- Adds a dedicated actor cache last-run summary report so actor cache status can be proven with exact totals.
- Uses FileManager cache stats for actor cache notifications: found, cacheable, already cached, pending, cached, failed, skipped.
- Cleans reporting so artwork-report.txt no longer accumulates repeated version headers across several add-on versions.
- Prevents repeated performance.csv headers across multiple runs.

# Library Artwork Curator 0.32.30 custom build notes

## v0.32.32 - Auto scan processing reliability fix

- Fixes auto-fill queue that could stop after `auto fill quiet delay before starting` without producing `RUN START service.signal.recentvideos_really`.
- The quiet delay now uses short `xbmc.sleep(100)` slices and explicitly logs `auto fill quiet delay finished; starting processing`.
- Service pre-run setup is now protected by error recovery so a failure before `run_context` is logged and status returns to idle instead of staying signalled.
- `CancelCurrent` now also cancels the signalled/quiet-delay gap, where `_signal` has already been consumed but processing has not started.


## 0.32.30
- Removed Cache actor thumbnails from Settings; actor caching is no longer a setting toggle.
- Added a dedicated Cache actor thumbnails run that reads actor thumb URLs from Kodi's active MyVideos database and caches missing actor images with progress.
- Diagnostics skips the obsolete actor_thumb_cache setting if it remains in the user's profile settings.xml from older builds.

# Library Artwork Curator 0.32.29 custom build notes

## 0.32.29
- Cache missing artwork now skips generated `image://video@...` thumbs that point to `.strm` files or folder paths.
- These entries were not cacheable through Kodi's `/image/` endpoint and kept returning as pending after a large cache run.
- Real local video-file generated thumbs remain eligible; remote TMDb/fanart.tv/TheTVDB artwork is unchanged.

# Library Artwork Curator 0.32.28 custom build notes

## 0.32.28
- Cache missing artwork now shows visible progress for actual pending downloads when more than one URL needs caching.
- The progress dialog shows `N/TOTAL CACHING ARTWORK - TITLE · arttype` instead of sitting at the fixed 55% caching stage.
- Progress is based on missing/pending cache work only, not all 18k+ library artwork URLs already present in Kodi's texture cache.

# Library Artwork Curator 0.32.27

Custom fixes in this build:

- Added global poster fallback matching the existing one-image fallback behavior for sparse artwork:
  - preferred/high-quality posters still win first;
  - if no poster meets the configured minimum height, LAC keeps exactly one best language-acceptable fallback poster;
  - no new setting is added.
- Cache/status summaries now hide internal `tvshow season.N.*` mirror rows because direct season artwork is the canonical data shown in Kodi/AF3.
- Generated video thumb fallback is unchanged and remains one global setting.

# Library Artwork Curator 0.32.26

Custom fixes in this build:

- Select artwork now pages large candidate lists inside the candidate dialog.
  - The first page shows up to 50 candidates per provider by default.
  - A `Load more candidates` row reveals the next page from each provider.
  - Current/manual artwork still stays visible and selected when applicable.
  - Provider freedom is preserved: TMDb, fanart.tv, and TheTVDB are still available when they have candidates.
- Added visible setting: **Select artwork candidates per provider page**.
- Diagnostics/status summaries now ignore legacy `season fanart` / `episode fanart` rows because those are no longer managed targets.
- Kept season model from 0.32.25:
  - direct season artwork is canonical;
  - `season.N.*` on the TV show remains a compatibility mirror.
- Kept defaults for stable full-library refresh:
  - detailed per-item reports default OFF;
  - expert context diagnostics default OFF.

# Library Artwork Curator 0.32.25

Custom fixes in this build:

- Select artwork provider visibility hotfix: compact filtering keeps top candidates from every provider and labels current-only artwork with inferred source.

# Library Artwork Curator 0.32.24

Custom fixes in this build:

- Added context menu action: **Refresh all artwork for this item**. It runs Refresh All behavior for only the focused library item, while keeping manual/protected artwork safe.
- Select artwork keeps provider freedom, but now defaults to a compact high-quality list:
  - if enough high-quality candidates exist, lower-resolution candidates are hidden;
  - if enough preferred-language candidates exist, other-language candidates are hidden;
  - current/manual artwork remains visible even when it is low resolution or outside the preferred language.
- Added visible Select artwork settings for compact candidate filtering.
- Reordered the Artwork types ON/OFF settings and Select artwork type dialog order to: poster, fanart, clearlogo, clearart, discart, then landscape/thumb/keyart/banner/logo/character art.

# Library Artwork Curator 0.32.23

Custom fixes in this build:

- Auto provider flow is now lazy for normal automatic jobs:
  - Fetch TMDb first.
  - If all enabled targets have enough strong candidates, stop.
  - Fetch fanart.tv only for targets that still lack strong candidates.
  - Fetch TheTVDB only for remaining TV/season targets.
- Fanart completeness respects the configured fanart slot count. Example: if TMDb has 3 strong fanarts and the limit is 5, fanart.tv is fetched only to fill the remaining slots.
- Select artwork remains full/manual: it still fetches provider candidates so the user can freely choose from TMDb, fanart.tv, and TheTVDB candidates.
- Dry run is now an expert context option, hidden by default, with capped candidate output to avoid huge diagnostics files.
- Main LAC context menu is moved to the root context menu to work on episodes when the skin/Kodi does not expose Manage.
- Season cache model is fixed toward direct-season canonical rows with season.N compatibility mirrors. Existing tvshow season.N rows are mirrored to direct season rows when TV shows are processed.
- Provider request retry/timeout defaults are reduced to prevent long UI stalls from slow fallback providers.

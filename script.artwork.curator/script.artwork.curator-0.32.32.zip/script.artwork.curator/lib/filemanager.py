from urllib.parse import quote, unquote
import os
from concurrent.futures import ThreadPoolExecutor, as_completed
import time
import xbmc

from lib.libs import pykodi, quickjson
from lib import runtrace
from lib.libs.addonsettings import settings
from lib.libs.pykodi import localize as L, log
from lib.libs.webhelper import Getter, GetterError

CANT_CONTACT_PROVIDER = 32034
HTTP_ERROR = 32035
REMOTE_CONTROL_REQUIRED = 32039



def _is_uncacheable_generated_video_thumb(url):
    """Return True for generated video thumbs Kodi cannot reliably cache.

    Kodi's /image endpoint can cache image://video@ URLs for real local video
    files, but STRM entries and folder paths return instant retry/no-status
    failures and keep showing up as missing on every Cache Artwork pass.
    """
    if not url or not url.lower().startswith('image://video@'):
        return False
    raw = url[len('image://video@'):]
    # Kodi image URLs normally end with a trailing slash after the encoded path.
    raw = raw.rstrip('/')
    decoded = unquote(raw)
    if decoded.endswith(('/', '\\')):
        return True
    path = decoded.rstrip('/\\')
    if not path:
        return True
    _, ext = os.path.splitext(path)
    ext = (ext or '').lower()
    if not ext:
        return True
    if ext == '.strm':
        return True
    return False

class FileManager(object):
    """Remote-only texture-cache helper.

    This fork deliberately does not write poster.jpg, fanart.jpg, extrafanart,
    or any other artwork file beside the media files.
    """
    def __init__(self, debug=False, bigcache=False):
        self.getter = Getter()
        self.getter.session.headers['User-Agent'] = settings.useragent
        self.size = 0
        self.debug = debug
        self.last_cache_stats = {}
        self.alreadycached = [] if bigcache else None
        self._build_imagecachebase()

    def _build_imagecachebase(self):
        result = pykodi.execute_jsonrpc({'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettings',
            'params': {'filter': {'category': 'control', 'section': 'services'}}})
        port, username, password, secure, enabled = 80, '', '', False, True
        values = result.get('result', {}).get('settings')
        if not values:
            enabled = False
        else:
            for setting in values:
                sid, value = setting.get('id'), setting.get('value')
                if sid == 'services.webserver' and not value:
                    enabled = False
                elif sid == 'services.webserverusername':
                    username = value
                elif sid == 'services.webserverport':
                    port = value
                elif sid == 'services.webserverpassword':
                    password = value
                elif sid == 'services.webserverssl' and value:
                    secure = True
        auth = '{0}:{1}@'.format(username, password) if username and password else ''
        self.imagecachebase = '{0}://{1}localhost:{2}/image/'.format('https' if secure else 'http', auth, port) if enabled else None
        if not enabled:
            log(L(REMOTE_CONTROL_REQUIRED), xbmc.LOGWARNING)

    def downloadfor(self, mediaitem, allartwork=True):
        return False, ''

    def remove_deselected_files(self, mediaitem, assignedart=False):
        return

    def set_bigcache(self):
        if self.alreadycached is None:
            self.alreadycached = []

    def cachefor(self, artmap, multiplethreads=False, progress_callback=None, cancel_callback=None, progress_total='checked'):
        timer = time.time()
        runtrace.cache_event('cachefor start', artmap_count=len(artmap or {}), multiplethreads=multiplethreads, debug=self.debug, imagecachebase=bool(self.imagecachebase))
        """Cache remote URLs through Kodi's internal /image endpoint.

        Progress is reported against every checked URL, not only URLs that are
        missing from Kodi's texture cache. This keeps the UI honest when most or
        all artwork is already cached: the counter can still move from 1/total
        to total/total instead of sticking at 0/total and then finishing.
        """
        if not self.imagecachebase or self.debug:
            self.last_cache_stats = {
                'total': 0, 'cacheable': 0, 'checked': 0, 'already_cached': 0,
                'pending': 0, 'cached': 0, 'failed': 0, 'skipped_generated': 0,
                'skipped_uncacheable': 0, 'elapsed_ms': int((time.time() - timer) * 1000),
                'reason': 'no imagecachebase or debug',
            }
            runtrace.cache_event('cachefor skipped', reason='no imagecachebase or debug', imagecachebase=bool(self.imagecachebase), debug=self.debug)
            return 0

        urls = []
        skipped_generated = 0
        skipped_uncacheable = 0
        total_input = len(set((artmap or {}).values()))
        for url in artmap.values():
            if not url or not url.startswith(('http://', 'https://', 'image://')):
                skipped_uncacheable += 1
                continue
            if _is_uncacheable_generated_video_thumb(url):
                skipped_generated += 1
                continue
            if url not in urls:
                urls.append(url)
        if skipped_generated:
            runtrace.cache_event('cachefor skipped generated video thumbs', skipped=skipped_generated)
        if not urls:
            self.last_cache_stats = {
                'total': total_input, 'cacheable': 0, 'checked': 0, 'already_cached': 0,
                'pending': 0, 'cached': 0, 'failed': 0, 'skipped_generated': skipped_generated,
                'skipped_uncacheable': skipped_uncacheable, 'elapsed_ms': int((time.time() - timer) * 1000),
                'reason': 'no cacheable remote urls',
            }
            runtrace.cache_event('cachefor skipped', reason='no cacheable remote urls', skipped_generated=skipped_generated, skipped_uncacheable=skipped_uncacheable)
            return 0

        if self.alreadycached is not None:
            if not self.alreadycached:
                self.alreadycached = [pykodi.unquoteimage(texture['url']) for texture in quickjson.get_textures()]
            already = set(self.alreadycached)
        else:
            already = set(pykodi.unquoteimage(texture['url']) for texture in quickjson.get_textures())

        pending = [path for path in urls if path not in already]
        total_urls = len(urls)
        already_cached_count = total_urls - len(pending)

        def emit(done, total, path, stage='checked'):
            if progress_callback:
                try:
                    progress_callback(done, total, path, stage)
                except TypeError:
                    progress_callback(done, total, path)

        checked = 0
        pending_done = 0
        pending_total = len(pending)
        pending_progress = progress_total == 'pending'
        # Count already-cached URLs as checked too for normal checked-progress
        # callers. For explicit cache runs, use pending-progress so the UI shows
        # 1/N, 2/N... for the actual missing artwork being cached instead of
        # sticking around the stage percent while Kodi downloads.
        for path in urls:
            if cancel_callback and cancel_callback():
                runtrace.cache_event('cachefor cancelled during already-cached check', checked=checked, total=total_urls)
                return 0
            if path in already:
                checked += 1
                if not pending_progress:
                    emit(checked, total_urls, path, 'checked')

        if not pending:
            elapsed = int((time.time() - timer) * 1000)
            self.last_cache_stats = {
                'total': total_input, 'cacheable': total_urls, 'checked': checked,
                'already_cached': already_cached_count, 'pending': 0, 'cached': 0,
                'failed': 0, 'skipped_generated': skipped_generated,
                'skipped_uncacheable': skipped_uncacheable, 'elapsed_ms': elapsed, 'reason': 'complete',
            }
            runtrace.cache_event('cachefor complete', pending=0, checked=checked, total=total_urls, cached=0, failed=0, already_cached=already_cached_count, skipped_generated=skipped_generated, skipped_uncacheable=skipped_uncacheable, elapsed_ms=elapsed)
            return 0

        def fetch(path):
            if cancel_callback and cancel_callback():
                return path, False
            try:
                response, _ = self.doget(
                    self.imagecachebase + quote(pykodi.quoteimage(path), ''),
                    stream=True,
                )
                if not response:
                    return path, False
                for _ in response.iter_content(chunk_size=8192):
                    pass
                response.close()
                return path, True
            except Exception:
                return path, False

        count = 0
        failed = 0

        if multiplethreads and len(pending) > 1:
            executor = ThreadPoolExecutor(max_workers=min(4, len(pending)))
            futures = {executor.submit(fetch, path): path for path in pending}
            try:
                for future in as_completed(futures):
                    path = futures[future]
                    try:
                        _, success = future.result()
                    except Exception:
                        success = False
                    checked += 1
                    pending_done += 1
                    if success:
                        count += 1
                        if self.alreadycached is not None:
                            self.alreadycached.append(path)
                    else:
                        failed += 1
                    if pending_progress:
                        emit(pending_done, pending_total, path, 'cached')
                    else:
                        emit(checked, total_urls, path, 'checked')
                    if cancel_callback and cancel_callback():
                        for remaining in futures:
                            remaining.cancel()
                        break
            finally:
                executor.shutdown(wait=True)
        else:
            for path in pending:
                if cancel_callback and cancel_callback():
                    break
                _, success = fetch(path)
                checked += 1
                pending_done += 1
                if success:
                    count += 1
                    if self.alreadycached is not None:
                        self.alreadycached.append(path)
                else:
                    failed += 1
                if pending_progress:
                    emit(pending_done, pending_total, path, 'cached')
                else:
                    emit(checked, total_urls, path, 'checked')

        elapsed = int((time.time() - timer) * 1000)
        self.last_cache_stats = {
            'total': total_input, 'cacheable': total_urls, 'checked': checked,
            'already_cached': already_cached_count, 'pending': len(pending), 'cached': count,
            'failed': failed, 'skipped_generated': skipped_generated,
            'skipped_uncacheable': skipped_uncacheable, 'elapsed_ms': elapsed, 'reason': 'complete',
        }
        runtrace.cache_event('cachefor complete', pending=len(pending), checked=checked, total=total_urls, cached=count, failed=failed, already_cached=already_cached_count, skipped_generated=skipped_generated, skipped_uncacheable=skipped_uncacheable, elapsed_ms=elapsed)
        return count

    def doget(self, url, **kwargs):
        timer = time.time()
        try:
            result = self.getter(url, **kwargs)
            status = getattr(result, 'status_code', None) if result is not None else None
            runtrace.cache_event('image request', status=status, elapsed_ms=int((time.time() - timer) * 1000), url=runtrace.sanitize_url(url))
            return result, None
        except GetterError as ex:
            runtrace.cache_event('image request error', status=getattr(getattr(ex, 'response', None), 'status_code', None), elapsed_ms=int((time.time() - timer) * 1000), error=ex.message, url=runtrace.sanitize_url(url))
            message = L(CANT_CONTACT_PROVIDER) if ex.connection_error else L(HTTP_ERROR).format(ex.message) + '\n' + url
            return None, message

class FileError(Exception):
    def __init__(self, message, cause=None):
        super(FileError, self).__init__(message)
        self.cause = cause
        self.message = message

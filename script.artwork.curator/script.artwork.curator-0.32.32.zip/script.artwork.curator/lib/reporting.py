import os
import xbmc
import xbmcvfs

from lib.libs import mediatypes
from lib.libs import pykodi
from lib.libs.addonsettings import settings
from lib.libs.mediainfo import get_basetype
from lib.libs.pykodi import localize as L, log

import sys
if sys.version_info[0] >= 3:
    unicode = bytes
    basestring = bytes


# TODO: Failed movie set matching, missing or updated uniqueid, processeditems label mismatch

REPORT_NAME = 'artwork-report'
REPORT_SIZE = 100000
REPORT_COUNT = 2
LAST_RUN_NAME = 'artwork-last-run-summary.txt'
PER_ITEM_MULT = 5

PROCESSING_AUTOMATICALLY = 32800
PROCESSING_MANUALLY = 32801
PROCESSING = 32802
PROCESSING_FINISHED = 32803
PROCESSING_ABORTED = 32804
NO_ITEMS = 32805
ITEM_COUNT = 32806
PROCESSED_COUNT = 32807
NO_UPDATES = 32808
UPDATE_COUNT = 32809
NO_MISSING_ARTWORK = 32810
MISSING_LABEL = 32811
UPDATED_LABEL = 32812
ERROR_MESSAGE = 32813
ERRORS_MESSAGE = 32814
RUNNING_VERSION = 32815
DOWNLOAD_COUNT = 32816
NO_IDS_MESSAGE = 32030

debug = False
_current_run_started = ''

def report_startup():
    """Reset the human report to the current add-on session.

    Older builds appended a new version header every time the add-on changed
    version, which made artwork-report.txt look like several unrelated reports
    glued together. The detailed latest run lives in artwork-last-run-summary.txt;
    this report is now a short current-session/history file, so one version
    header is enough.
    """
    if not xbmcvfs.exists(_diag_path()):
        xbmcvfs.mkdir(_diag_path())
    try:
        with open(xbmcvfs.translatePath(_get_filepath()), 'w', encoding='utf-8') as reportfile:
            newline = str(str("= ") + str(L(RUNNING_VERSION))).format(settings.useragent)
            write(reportfile, newline.encode("ascii", "ignore").decode())
            finish_chunk(reportfile)
    except Exception as ex:
        log('Could not reset artwork report: {0}'.format(repr(ex)), xbmc.LOGWARNING, 'reporting')

def report_start(medialist):
    global _current_run_started
    _current_run_started = get_datetime()
    if debug:
        return
    with _get_file() as reportfile:
        write(reportfile, "== {0}: ".format(_current_run_started) + L(PROCESSING_AUTOMATICALLY))
        if not medialist:
            write(reportfile, L(NO_ITEMS))
            write(reportfile, '')
            return
        mediatypecount = {}
        for item in medialist:
            mediatypecount[item.mediatype] = mediatypecount.get(item.mediatype, 0) + 1

        write(reportfile, L(ITEM_COUNT).format(len(medialist)) + " - " +
            ', '.join('{0}: {1}'.format(mt, mediatypecount[mt]) for mt in mediatypecount))

def report_end(medialist, abortedcount, downloaded_size):
    if debug:
        return

    arttypecount, mediatypecount = {}, {}
    total = 0
    downloaded = 0
    errorcount = 0
    updateditems = 0
    for item in medialist:
        mediatypecount[item.mediatype] = mediatypecount.get(item.mediatype, 0) + 1
        if item.updatedart:
            updateditems += 1
        for arttype in item.updatedart:
            arttype = get_basetype(arttype)
            arttypecount[arttype] = arttypecount.get(arttype, 0) + 1
            total += 1
        if item.error:
            errorcount += 1
        downloaded += len(item.downloadedart)

    _write_last_run_summary(
        medialist=medialist,
        abortedcount=abortedcount,
        updateditems=updateditems,
        total=total,
        arttypecount=arttypecount,
        mediatypecount=mediatypecount,
        downloaded=downloaded,
        downloaded_size=downloaded_size,
        errorcount=errorcount,
    )

    # Keep the original rolling history as a secondary section.
    if len(medialist) <= 1:
        if _should_rotate():
            _rotate_file()
        return
    with _get_file() as reportfile:
        write(reportfile, get_datetime() + ': ' + L(PROCESSING_ABORTED if abortedcount else PROCESSING_FINISHED))
        if abortedcount:
            write(reportfile, L(PROCESSED_COUNT).format(abortedcount))
        if downloaded:
            write(reportfile, L(DOWNLOAD_COUNT).format(downloaded)
                + ' - {0:0.2f}MB'.format(downloaded_size / 1000000.00))
        if not total:
            write(reportfile, L(NO_UPDATES))
        else:
            write(reportfile, L(UPDATE_COUNT).format(total) + ' - ' +
                ', '.join('{0}: {1}'.format(at, arttypecount[at]) for at in sorted(arttypecount)))
        if errorcount:
            write(reportfile, L(ERRORS_MESSAGE))
        finish_chunk(reportfile)
    if _should_rotate():
        _rotate_file()

def report_item(mediaitem, forcedreport=False, manual=False, downloaded_size=0):
    if debug or not forcedreport and not settings.report_peritem:
        return
    with _get_file() as reportfile:
        itemtitle = "{0} '{1}'".format(mediaitem.mediatype, mediaitem.label) if mediaitem.mediatype != mediatypes.EPISODE \
            else "{0} '{1}' of '{2}'".format(mediaitem.mediatype, mediaitem.label, mediaitem.showtitle)
        message = "== {0}: ".format(get_datetime()) if forcedreport else ""
        message += L(PROCESSING_MANUALLY if manual else PROCESSING)
        try:
            write(reportfile, message.format(itemtitle))
        except UnicodeEncodeError:
            itemtitle = itemtitle.encode("ascii", "ignore")
            itemtitle = itemtitle.decode()
            write(reportfile, message.format(itemtitle))
        message = L(NO_IDS_MESSAGE) if mediaitem.missingid \
            else L(MISSING_LABEL).format(', '.join(mediaitem.missingart)) if mediaitem.missingart \
            else L(NO_MISSING_ARTWORK)
        write(reportfile, message)

        if mediaitem.downloadedart:
            message = L(DOWNLOAD_COUNT).format(len(mediaitem.downloadedart))
            if downloaded_size:
                message += ' - {0:0.2f}MB'.format(downloaded_size / 1000000.00)
            write(reportfile, message)
        if mediaitem.updatedart:
            write(reportfile, L(UPDATED_LABEL).format(', '.join(mediaitem.updatedart)))
        elif manual or mediaitem.missingart:
            write(reportfile, L(NO_UPDATES))

        if mediaitem.error:
            write(reportfile, L(ERROR_MESSAGE).format(pykodi.scrub_message(mediaitem.error)))
        if forcedreport:
            finish_chunk(reportfile)
    if forcedreport and _should_rotate():
        _rotate_file()

def get_datetime():
    return pykodi.get_infolabel('System.Date(yyyy-mm-dd)') + ' ' + pykodi.get_infolabel('System.Time(hh:mm:ss xx)')

def write(reportfile, line):
    try: reportfile.write(line + '\n')
    except: reportfile.write(line.encode("ascii", "ignore").decode() + '\n')

def finish_chunk(reportfile):
    reportfile.write('\n')

def _diag_path():
    path = getattr(settings, 'diagnostics_path', settings.datapath.rstrip('/\\') + '/diagnostics/')
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdir(path)
    return path


def _get_last_run_filepath():
    return _diag_path().rstrip('/\\') + '/' + LAST_RUN_NAME


def _write_last_run_summary(medialist, abortedcount, updateditems, total, arttypecount,
        mediatypecount, downloaded, downloaded_size, errorcount):
    """Persist a human-readable report for the most recent completed run."""
    try:
        if not xbmcvfs.exists(settings.datapath):
            xbmcvfs.mkdir(settings.datapath)
        filepath = _get_last_run_filepath()
        lines = [
            'Library Artwork Curator - latest run',
            '=' * 44,
            'Started : {0}'.format(_current_run_started or '-'),
            'Finished: {0}'.format(get_datetime()),
            'Status  : {0}'.format('aborted' if abortedcount else 'finished'),
            '',
            'Items scanned  : {0}'.format(len(medialist)),
            'Items updated  : {0}'.format(updateditems),
            'Artwork updated: {0}'.format(total),
            'Errors         : {0}'.format(errorcount),
            'Cached during scan: {0} ({1:0.2f} MB)'.format(downloaded, downloaded_size / 1000000.00),
            '',
            'Items by media type',
        ]
        if mediatypecount:
            lines.extend('  {0}: {1}'.format(key, mediatypecount[key]) for key in sorted(mediatypecount))
        else:
            lines.append('  none')
        lines.extend(['', 'Artwork by type'])
        if arttypecount:
            lines.extend('  {0}: {1}'.format(key, arttypecount[key]) for key in sorted(arttypecount))
        else:
            lines.append('  none')
        lines.append('')
        handle = xbmcvfs.File(filepath, 'w')
        try:
            handle.write('\n'.join(lines))
        finally:
            handle.close()
        log('Latest run report written: {0}'.format(filepath), xbmc.LOGINFO, 'reporting')
    except Exception as ex:
        log('Could not write latest run report: {0}'.format(repr(ex)), xbmc.LOGWARNING, 'reporting')


def _read_last_run_summary():
    try:
        filepath = _get_last_run_filepath()
        if not xbmcvfs.exists(filepath):
            return ''
        handle = xbmcvfs.File(filepath, 'r')
        try:
            return handle.read().strip()
        finally:
            handle.close()
    except Exception as ex:
        log('Could not read latest run report: {0}'.format(repr(ex)), xbmc.LOGWARNING, 'reporting')
        return ''


def get_latest_report():
    latest = _read_last_run_summary()
    if not _exists():
        return latest or 'No artwork report has been written yet.'
    result = []
    with _get_file(True) as reportfile:
        inserti = 0
        for line in reportfile.readlines():
            result.insert(inserti, line)
            if line == '\n':
                inserti = 0
            else:
                inserti += 1
    history = ''.join(result).strip()
    if latest and history:
        return latest + '\n\n' + ('-' * 44) + '\nHistory\n' + ('-' * 44) + '\n' + history
    return latest or history or 'No artwork report has been written yet.'

def _should_rotate():
    if not _exists():
        return False
    return xbmcvfs.Stat(_get_filepath()).st_size() > _get_maxsize()

def _get_maxsize():
    mult = PER_ITEM_MULT if settings.report_peritem else 1
    return REPORT_SIZE * mult

def _rotate_file():
    newdate = ndate = pykodi.get_infolabel('System.Date(yyyy-mm-dd)')
    count = 0
    while _exists(newdate):
        count += 1
        newdate = ndate + '.' + str(count)
    if not xbmcvfs.copy(_get_filepath(), _get_filepath(newdate)):
        log("Could not copy latest report to new filename", xbmc.LOGWARNING, 'reporting')
        return False
    if not xbmcvfs.delete(_get_filepath()):
        log("Could not delete old copy of latest report", xbmc.LOGWARNING, 'reporting')
        return False

    # delete old reports
    _, files = xbmcvfs.listdir(_diag_path())
    reportfiles = sorted(f[:-4] for f in files if f.startswith(REPORT_NAME))
    while len(reportfiles) > REPORT_COUNT:
        filename = reportfiles[0] + '.txt'
        if not xbmcvfs.delete(_diag_path().rstrip('/\\') + '/' + filename):
            log("Could not delete old report '{0}'".format(filename), xbmc.LOGWARNING, 'reporting')
            return False
        del reportfiles[0]
    report_startup()
    return True

def _get_file(readonly=False):
    #xbmc.log(str(_get_filepath())+'artwork_beef_reporting.py===>PHIL', level=xbmc.LOGINFO)
    return open(xbmcvfs.translatePath(_get_filepath()), 'r' if readonly else 'a+')
    #try:
    #    return open(xbmcvfs.translatePath(_get_filepath()), 'r' if readonly else 'a+')
    #except:
    #    return open(str(_get_filepath()).replace('special://profile/','/home/pi/.kodi/userdata/'), 'r' if readonly else 'a+')

def _exists(filetag=''):
    return xbmcvfs.exists(_get_filepath(filetag))

def _get_filepath(filetag=''):
    return _diag_path().rstrip('/\\') + '/' + REPORT_NAME + ('.' + filetag if filetag else '') + '.txt'

report_startup()

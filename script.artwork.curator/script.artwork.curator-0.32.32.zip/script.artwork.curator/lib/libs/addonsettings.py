import xbmc
from lib.libs import pykodi
try:
    import projectkeys
except ImportError:
    projectkeys = None

addon = pykodi.get_main_addon()
DEFAULT_IMAGESIZE = '1'
AVAILABLE_IMAGESIZES = {'0': (10000, 10000, 600), '1': (1920, 1080, 600), '2': (1280, 720, 480)}
FANART_MINIMUM_RESOLUTIONS = {'0': (0, 0), '1': (1280, 720), '2': (1920, 1080), '3': (3840, 2160)}
PROGRESS_DISPLAY_FULLPROGRESS = '0'
PROGRESS_DISPLAY_WARNINGSERRORS = '1'
PROGRESS_DISPLAY_NONE = '2'
EXCLUSION_PATH_TYPE_FOLDER = '0'
EXCLUSION_PATH_TYPE_PREFIX = '1'
EXCLUSION_PATH_TYPE_REGEX = '2'

class Settings(object):
    def __init__(self):
        self.addon_path = addon.path
        self.datapath = addon.datapath
        self.diagnostics_path = addon.datapath.rstrip('/\\') + '/diagnostics/'
        self._autoadd_episodes = ()
        self.update_settings()
        self.update_useragent()

    def update_useragent(self):
        self.useragent = 'ArtworkCurator/{0} '.format(pykodi.get_main_addon().version) + xbmc.getUserAgent()

    def update_settings(self):
        # Enable automatic new-video processing once after installing 0.30.6.
        # The visible setting remains user-controllable afterwards.
        if not addon.get_setting('auto_service_initialized_0306'):
            addon.set_setting('enableservice', True)
            addon.set_setting('auto_service_initialized_0306', True)
        self._autoadd_episodes = addon.get_setting('autoaddepisodes_list') if (addon.get_setting('episode.thumb') or addon.get_setting('episode.landscape')) else ()
        self.enableservice = addon.get_setting('enableservice')
        self.enable_olditem_updates = addon.get_setting('enable_olditem_updates')
        self.include_mediatypes = {
            'movie': addon.get_setting('include_movies'),
            'set': addon.get_setting('include_movie_sets'),
            'tvshow': addon.get_setting('include_tvshows'),
            'season': addon.get_setting('include_seasons'),
            'episode': addon.get_setting('include_episodes'),
        }
        self.indonesian_movie_mode = addon.get_setting('indonesian_movie_mode') or '1'
        raw_markers = addon.get_setting('indonesian_movie_path_markers') or ''
        self.indonesian_movie_path_markers = tuple(
            marker.strip().lower() for marker in raw_markers.replace('\n', '|').replace(',', '|').split('|')
            if marker.strip()
        )
        self.titlefree_fanart = addon.get_setting('titlefree_fanart')
        self.titlefree_poster = addon.get_setting('titlefree_poster')
        # When remote providers have no movie/episode thumb, keep the library useful
        # by asking Kodi to generate a video thumbnail from the file path.
        value = addon.get_setting('use_generated_video_thumb')
        self.use_generated_video_thumb = True if value == '' else bool(value)
        self.setartwork_fromparent = False
        self.setartwork_subdirs = True
        self.identify_alternatives = False
        self.report_peritem = addon.get_setting('report_peritem')
        self.fanarttv_clientkey = ''
        self.default_tvidsource = addon.get_setting('default_tvidsource') or 'tmdb'
        self.progressdisplay = addon.get_setting('progress_display') or PROGRESS_DISPLAY_FULLPROGRESS
        self.final_notification = addon.get_setting('final_notification')
        self.remove_deselected_files = False
        self.recycle_removed = False
        self.cache_remote_video_artwork = addon.get_setting('precache_during_scan')
        self.clean_imageurls = True
        self.use_tmdb_keyart = True
        self.remote_only_mode = True

        language_map = {
            '0': None, '': None, 'None': None, 'Auto': None, 'Default': None, 'Default (Kodi)': None,
            '1': 'en', '2': 'id', '3': 'ja', '4': 'ko', '5': 'zh',
            '6': 'th', '7': 'hi', '8': 'fr', '9': 'es', '10': 'de',
            'en': 'en', 'id': 'id', 'ja': 'ja', 'ko': 'ko', 'zh': 'zh',
            'th': 'th', 'hi': 'hi', 'fr': 'fr', 'es': 'es', 'de': 'de',
        }
        self.language_override = language_map.get(addon.get_setting('language_override'), addon.get_setting('language_override') or None)
        # Hidden, always safe defaults. These remain true even when the settings are not shown.
        self.language_fallback_kodi = True
        self.language_fallback_en = True
        try:
            self.minimum_rating = int(addon.get_setting('minimum_rating'))
        except (TypeError, ValueError):
            self.minimum_rating = 5
        try:
            self.minimum_poster_height = int(addon.get_setting('minimum_poster_height') or 1000)
        except (TypeError, ValueError):
            self.minimum_poster_height = 1000
        sizesetting = addon.get_setting('preferredsize') or DEFAULT_IMAGESIZE
        if sizesetting not in AVAILABLE_IMAGESIZES:
            sizesetting = DEFAULT_IMAGESIZE
        self.preferredsize = AVAILABLE_IMAGESIZES[sizesetting][0:2]
        self.minimum_size = AVAILABLE_IMAGESIZES[sizesetting][2]
        fanart_minimum = addon.get_setting('minimum_fanart_resolution') or '2'
        if fanart_minimum not in FANART_MINIMUM_RESOLUTIONS:
            fanart_minimum = '2'
        self.minimum_fanart_resolution = FANART_MINIMUM_RESOLUTIONS[fanart_minimum]
        self.select_compact_candidates = addon.get_setting('select_compact_candidates')
        if self.select_compact_candidates == '':
            self.select_compact_candidates = True
        self.select_hide_lowres_when_enough_hd = addon.get_setting('select_hide_lowres_when_enough_hd')
        if self.select_hide_lowres_when_enough_hd == '':
            self.select_hide_lowres_when_enough_hd = True
        self.select_hide_other_languages_when_enough_preferred = addon.get_setting('select_hide_other_languages_when_enough_preferred')
        if self.select_hide_other_languages_when_enough_preferred == '':
            self.select_hide_other_languages_when_enough_preferred = True
        try:
            self.select_candidate_filter_threshold = int(addon.get_setting('select_candidate_filter_threshold') or 12)
        except (TypeError, ValueError):
            self.select_candidate_filter_threshold = 12
        try:
            self.select_candidates_per_provider = int(addon.get_setting('select_candidates_per_provider') or 50)
        except (TypeError, ValueError):
            self.select_candidates_per_provider = 50
        if self.select_candidates_per_provider < 1:
            self.select_candidates_per_provider = 50

        self.apiconfig = {}
        for provider in ('fanarttv', 'tvdb', 'tmdb'):
            key = (addon.get_setting('apikey.' + provider) or '').strip()
            self.apiconfig[provider] = {'apikey': key, 'apikey-builtin': not key,
                'enabled': addon.get_setting('apienabled.' + provider)}
            if not key and projectkeys:
                self.apiconfig[provider]['apikey'] = get_projectkey(provider)
            pykodi.set_log_scrubstring(provider + '-apikey', key)

        self.pathexclusion = []
        for index in range(1, 11):
            suffix = str(index)
            if not addon.get_setting('exclude.path.option_' + suffix):
                continue
            self.pathexclusion.append({
                'type': addon.get_setting('exclude.path.type_' + suffix),
                'folder': addon.get_setting('exclude.path.folder_' + suffix),
                'prefix': addon.get_setting('exclude.path.prefix_' + suffix),
                'regex': addon.get_setting('exclude.path.regex_' + suffix),
            })
        pykodi.set_log_scrubstring('fanarttv-client-apikey', self.fanarttv_clientkey)

    def get_apikey(self, provider):
        return self.apiconfig[provider]['apikey']

    def get_apienabled(self, provider):
        return self.apiconfig[provider]['enabled']

    def get_api_config(self, provider):
        return self.apiconfig[provider]

    @property
    def autoadd_episodes(self):
        return self._autoadd_episodes

    @autoadd_episodes.setter
    def autoadd_episodes(self, value):
        self._autoadd_episodes = value
        addon.set_setting('autoaddepisodes_list', value)

def get_projectkey(provider):
    if provider == 'fanarttv':
        return projectkeys.FANARTTV_PROJECTKEY
    if provider == 'tvdb':
        return projectkeys.THETVDB_PROJECTKEY
    if provider == 'tmdb':
        return projectkeys.TMDB_PROJECTKEY
    return ''

settings = Settings()

import xbmc
import xbmcgui
import traceback
import time
from itertools import chain

from lib.artworkprocessor import ArtworkProcessor
from lib.libs import mediainfo as info, mediatypes, pykodi, quickjson
from lib.libs.addonsettings import settings
from lib import runtrace, artworkdb
from lib.libs.pykodi import log, json

STATUS_IDLE = 'idle'
STATUS_SIGNALLED = 'signalled'
STATUS_PROCESSING = 'processing'
addon = pykodi.get_main_addon()
AUTO_QUIET_DELAY_SECONDS = 3

class ArtworkService(xbmc.Monitor):
    """Video-library listener only. AudioLibrary notifications are intentionally ignored."""
    def __init__(self):
        super(ArtworkService, self).__init__()
        self.abort = False
        self.processor = ArtworkProcessor(self)
        self.processaftersettings = False
        self.recentvideos = {'movie': [], 'tvshow': [], 'episode': []}
        self.stoppeditems = set()
        self._signal = None
        self._status = None
        self._last_videoupdate = addon.get_setting('last_videoupdate') or '0'
        self._scan_snapshot = None
        self._clean_snapshot = None
        self.status = STATUS_IDLE

    @property
    def scanning(self):
        return pykodi.get_conditional('Library.IsScanningVideo')

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, value):
        self._status = value
        self.abort = False
        pykodi.execute_builtin('SetProperty(ArtworkCurator.Status, {0}, Home)'.format(value))
        pykodi.execute_builtin('SetProperty(LibraryArtworkCurator.Status, {0}, Home)'.format(value))
        pykodi.execute_builtin('SetProperty(script.artwork.curator.Status, {0}, Home)'.format(value))

    @property
    def signal(self):
        return self._signal

    @signal.setter
    def signal(self, value):
        self._signal = value
        # Do not clobber PROCESSING while auto-scan queues work in memory.
        # The current job must finish first; the queued signal will be handled
        # by the main loop afterwards.
        if self._status != STATUS_PROCESSING:
            self.status = STATUS_SIGNALLED if value else STATUS_IDLE

    @property
    def last_videoupdate(self):
        return self._last_videoupdate

    @last_videoupdate.setter
    def last_videoupdate(self, value):
        addon.set_setting('last_videoupdate', value)
        self._last_videoupdate = value

    def reset_recent(self):
        self.recentvideos = {'movie': [], 'tvshow': [], 'episode': []}

    def run(self):
        while not self.really_waitforabort(5):
            if self.scanning or not self.signal:
                continue
            signal = self.signal
            self._signal = None
            try:
                if signal == 'recentvideos':
                    self.signal = 'recentvideos_really'
                    continue
                if self._needs_lrs_lock_wait(signal) and not self._wait_for_shared_lrs_lock(signal):
                    self.signal = signal
                    self.really_waitforabort(5)
                    continue
                if signal == 'recentvideos_really' and not self._wait_for_quiet_auto_start(signal):
                    runtrace.event('service', 'auto fill quiet delay cancelled before processing', signal=signal)
                    self.status = STATUS_IDLE
                    continue
                self.status = STATUS_PROCESSING
                runtrace.event('service', 'service signal entering processing', signal=signal, recent=self.recentvideos)
                with runtrace.run_context('service.signal.' + str(signal), signal=signal):
                    try:
                        if signal == 'allvideos':
                            self.notify_finished(self.process_allvideos())
                        elif signal == 'allvideos_manual':
                            self.notify_finished(self.process_allvideos(force_progress=True))
                        elif signal == 'refreshall_manual':
                            self.notify_finished(self.process_allvideos(force_progress=True, refresh_all=True))
                        elif signal == 'newvideos':
                            self.notify_finished(self.process_recentvideos(refresh_all=False))
                        elif signal == 'newvideos_manual':
                            self.notify_finished(self.process_recentvideos(force_progress=True, notify_empty=True, refresh_all=False))
                        elif signal == 'oldvideos':
                            runtrace.event('service', 'oldvideos ignored; processeditems.db workflow removed')
                            self.notify_finished(True)
                        elif signal == 'oldvideos_manual':
                            runtrace.event('service', 'oldvideos manual ignored; processeditems.db workflow removed')
                            self.notify_finished(True)
                        elif signal == 'recentvideos_really':
                            self.notify_finished(self.process_recentvideos(refresh_all=False, auto=True, force_progress=True), auto=True)
                    except Exception as ex:
                        runtrace.error('Recovered unexpected Library Artwork Curator service error', ex, signal=signal)
                        log('Recovered unexpected Library Artwork Curator service error', xbmc.LOGERROR)
                        log(traceback.format_exc(), xbmc.LOGERROR)
                        try:
                            self.processor.close_progress()
                            self.processor.set_idle_inhibition(False)
                            self.processor.notify_warning('Processing stopped. Check kodi.log.', 'Error', True)
                        except Exception as inner:
                            runtrace.error('Service cleanup after error failed', inner, signal=signal)
                            log(traceback.format_exc(), xbmc.LOGWARNING)
                    finally:
                        self.status = STATUS_IDLE
            except Exception as ex:
                # Also catch failures that occur before run_context starts (quiet wait,
                # Home property updates, or other pre-run setup). The previous build
                # could leave Status=signalled with no RUN START if this area failed.
                runtrace.error('Recovered pre-run Library Artwork Curator service error', ex, signal=signal)
                log('Recovered pre-run Library Artwork Curator service error', xbmc.LOGERROR)
                log(traceback.format_exc(), xbmc.LOGERROR)
                try:
                    self.processor.close_progress()
                    self.processor.set_idle_inhibition(False)
                    self.status = STATUS_IDLE
                except Exception as inner:
                    runtrace.error('Service pre-run cleanup failed', inner, signal=signal)

    def abortRequested(self):
        return self.waitForAbort(0.0001)

    def waitForAbort(self, timeout=0):
        return self.abort or super(ArtworkService, self).waitForAbort(timeout)

    def really_waitforabort(self, timeout=0):
        return super(ArtworkService, self).waitForAbort(timeout)

    def onNotification(self, sender, method, data):
        runtrace.event('notification', 'received', sender=sender, method=method, data=str(data)[:600])
        if method.startswith('Other.') and sender != 'script.artwork.curator:control':
            return
        if method == 'Other.CancelCurrent':
            if self.status == STATUS_PROCESSING:
                self.abort = True
            elif self.status == STATUS_SIGNALLED or self.signal:
                # Covers both queued work that has not been consumed yet and the
                # quiet-delay gap after the run loop has consumed _signal but has
                # not entered PROCESSING. The previous build did not cancel that
                # gap because self.signal was already None while Status still read
                # signalled.
                queued_signal = self.signal
                self.signal = None
                self.abort = True
                runtrace.event('service', 'cancelled signalled auto queue before processing', signal=queued_signal)
                self.processor.close_progress()
        elif method == 'Other.ProcessNewVideos':
            self.signal = 'recentvideos'
        elif method == 'Other.ProcessNewVideosManual':
            self.signal = 'newvideos_manual'
        elif method == 'Other.ProcessNewAndOldVideos':
            self.signal = 'oldvideos'
        elif method == 'Other.ProcessNewAndOldVideosManual':
            self.signal = 'oldvideos_manual'
        elif method == 'Other.ProcessAllVideos':
            self.signal = 'allvideos'
        elif method == 'Other.ProcessAllVideosManual':
            self.signal = 'allvideos_manual'
        elif method == 'Other.ProcessRefreshAllArtworkManual':
            self.signal = 'refreshall_manual'
        elif method == 'Other.ProcessAfterSettings':
            self.processaftersettings = True
        elif method == 'VideoLibrary.OnScanStarted' and settings.enableservice:
            self._scan_snapshot = self._snapshot_library_ids()
            self.reset_recent()
            runtrace.event('service', 'Kodi scan started; snapshot saved', counts={k: len(v) for k, v in self._scan_snapshot.items()} if self._scan_snapshot else {})
        elif method == 'VideoLibrary.OnScanFinished' and settings.enableservice:
            self._merge_scan_diff_into_recent()
            total_recent = sum(len(values) for values in self.recentvideos.values())
            scan_old = settings.enable_olditem_updates and get_date() > self.last_videoupdate
            if total_recent:
                log('Auto fill artwork queued after VideoLibrary.OnScanFinished for {0} new item(s)'.format(total_recent), xbmc.LOGINFO)
                runtrace.event('service', 'auto fill queued after scan finished', recent=self.recentvideos, total=total_recent)
                # No queued toast: wait for LRS/notification cooldown, then show the real Auto Fill progress.
                self.signal = 'recentvideos_really'
            elif scan_old:
                log('Automatic older-item update skipped; processeditems workflow removed', xbmc.LOGINFO)
            else:
                runtrace.event('service', 'auto scan finished silent; no new library items from snapshot diff')
        elif method == 'VideoLibrary.OnCleanStarted' and settings.enableservice:
            self._clean_snapshot = self._snapshot_library_item_keys()
            runtrace.event('service', 'Kodi clean library started; clean snapshot saved', count=len(self._clean_snapshot or []))
        elif method == 'VideoLibrary.OnCleanFinished' and settings.enableservice:
            self._cleanup_after_kodi_clean()
        elif method == 'VideoLibrary.OnRemove' and settings.enableservice:
            # Safety net for libraries/skins that emit OnRemove without the
            # paired CleanStarted/CleanFinished notifications. Snapshot cleanup
            # remains the main LRS-style clean flow.
            try:
                payload = json.loads(data)
                item = payload.get('item', {})
                mediatype, dbid = item.get('type'), item.get('id')
                if mediatype in (mediatypes.MOVIESET, mediatypes.MOVIE, mediatypes.TVSHOW, mediatypes.SEASON, mediatypes.EPISODE) and dbid not in (None, -1):
                    key = '{0}:{1}'.format(mediatype, int(dbid))
                    result = artworkdb.delete_item_keys([key])
                    runtrace.event('service', 'Kodi OnRemove cleaned exact item cache row', item_key=key, result=result)
            except Exception as ex:
                runtrace.error('Kodi OnRemove cleanup failed', ex, data=str(data)[:300])
        elif method == 'VideoLibrary.OnUpdate' and settings.enableservice:
            # Do not treat OnUpdate as a new-library trigger. Kodi sends this
            # after playback/resume/watched/bookmark/metadata changes for
            # existing items, so using it for auto-fill creates fake queues
            # like movie:1 / movie:3 and blocks manual context actions.
            try:
                payload = json.loads(data)
                item = payload.get('item', {})
                runtrace.event('service', 'ignore VideoLibrary.OnUpdate for auto-fill; scan snapshot diff is authoritative',
                               mediatype=item.get('type'), dbid=item.get('id'), payload=str(payload)[:300])
            except Exception as ex:
                runtrace.error('ignore OnUpdate payload parse failed', ex, data=str(data)[:300])

    def onSettingsChanged(self):
        settings.update_settings()
        mediatypes.update_settings()
        if self.processaftersettings:
            self.processaftersettings = False
            self.signal = 'newvideos'

    def watchitem(self, payload):
        item = payload.get('item', {})
        return item.get('id') not in (None, -1) and item.get('type') in self.recentvideos and 'playcount' not in payload

    def _snapshot_library_item_keys(self):
        keys = set()
        try:
            if not mediatypes.disabled(mediatypes.MOVIESET):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIESET)):
                    dbid = row.get('setid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.MOVIESET, int(dbid)))
            if not mediatypes.disabled(mediatypes.MOVIE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)):
                    dbid = row.get('movieid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.MOVIE, int(dbid)))
            if not mediatypes.disabled(mediatypes.TVSHOW):
                for row in quickjson.get_tvshows():
                    dbid = row.get('tvshowid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.TVSHOW, int(dbid)))
            if not mediatypes.disabled(mediatypes.SEASON):
                for row in quickjson.get_seasons():
                    dbid = row.get('seasonid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.SEASON, int(dbid)))
            if not mediatypes.disabled(mediatypes.EPISODE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)):
                    dbid = row.get('episodeid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.EPISODE, int(dbid)))
        except Exception as ex:
            runtrace.error('snapshot library item keys failed', ex)
        return keys

    def _cleanup_after_kodi_clean(self):
        before = self._clean_snapshot
        self._clean_snapshot = None
        if before is None:
            # CleanFinished without CleanStarted: still safe, but we cannot know
            # removals without comparing to the DB. Keep it silent and logged.
            runtrace.event('service', 'Kodi clean finished without prior snapshot; no AC DB cleanup performed')
            return
        after = self._snapshot_library_item_keys()
        removed = sorted(before - after)
        if not removed:
            runtrace.event('service', 'Kodi clean finished; no removed library item keys')
            return
        result = artworkdb.delete_item_keys(removed)
        message = 'CLEAN LIBRARY ARTWORK FINISHED - {0} ITEMS - {1} ARTWORK ROWS REMOVED'.format(result.get('items', 0), result.get('artwork', 0))
        runtrace.event('service', 'Kodi clean library AC DB cleanup finished', removed_keys=len(removed), result=result)
        try:
            xbmcgui.Dialog().notification('Library Artwork Curator', message, xbmcgui.NOTIFICATION_INFO, 7000)
        except Exception:
            pass

    def _snapshot_library_ids(self):
        snapshot = {'movie': set(), 'tvshow': set(), 'episode': set()}
        try:
            if not mediatypes.disabled(mediatypes.MOVIE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)):
                    dbid = row.get('movieid')
                    if dbid not in (None, -1):
                        snapshot['movie'].add(int(dbid))
            if not mediatypes.disabled(mediatypes.TVSHOW):
                for row in quickjson.get_tvshows():
                    dbid = row.get('tvshowid')
                    if dbid not in (None, -1):
                        snapshot['tvshow'].add(int(dbid))
            if not mediatypes.disabled(mediatypes.EPISODE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)):
                    dbid = row.get('episodeid')
                    if dbid not in (None, -1):
                        snapshot['episode'].add(int(dbid))
        except Exception as ex:
            runtrace.error('snapshot library IDs failed', ex)
        return snapshot

    def _merge_scan_diff_into_recent(self):
        before = self._scan_snapshot or {'movie': set(), 'tvshow': set(), 'episode': set()}
        after = self._snapshot_library_ids()
        self._scan_snapshot = None
        added = {}
        for mediatype in ('movie', 'tvshow', 'episode'):
            added[mediatype] = sorted(after.get(mediatype, set()) - before.get(mediatype, set()))
            for dbid in added[mediatype]:
                if dbid not in self.recentvideos[mediatype]:
                    self.recentvideos[mediatype].append(dbid)
        runtrace.event('service', 'scan snapshot diff merged into memory queue', added=added, recent=self.recentvideos)

    def _needs_lrs_lock_wait(self, signal):
        return signal in ('recentvideos', 'recentvideos_really', 'newvideos', 'newvideos_manual')

    def _wait_for_quiet_auto_start(self, signal):
        # Kodi does not expose a global notification queue API. This is a pragmatic
        # quiet-window delay after scan/LRS activity so Auto Fill progress does not
        # collide with LRS/Kodi toasts. Use short xbmc.sleep() slices instead of a
        # second-level Monitor.waitForAbort() loop so the service cannot get stuck
        # between "queued" and RUN START on some Kodi builds.
        delay = AUTO_QUIET_DELAY_SECONDS
        runtrace.event('service', 'auto fill quiet delay before starting', signal=signal, delay_seconds=delay)
        deadline = time.time() + delay
        while time.time() < deadline:
            if self.really_waitforabort(0) or self.abort:
                return False
            xbmc.sleep(100)
        if self.really_waitforabort(0) or self.abort:
            return False
        runtrace.event('service', 'auto fill quiet delay finished; starting processing', signal=signal)
        return True

    def _lrs_lock_state(self):
        window = xbmcgui.Window(10000)
        names = (
            'LibraryRatingsScraper.Status',
            'LibraryRatingsScraper.Busy',
            'LibraryRatingsScraper.Lock',
            'LRS.Status',
            'LRS.Busy',
            'LRS.Lock',
            'script.library.ratings.scraper.Status',
            'script.library.ratings.scraper.Busy',
            'script.library.ratings.scraper.Lock',
        )
        for name in names:
            value = (window.getProperty(name) or '').strip()
            if value and value.lower() not in ('idle', 'finished', 'done', 'false', '0', 'none'):
                return name, value
        return '', ''

    def _wait_for_shared_lrs_lock(self, signal, timeout=180):
        name, value = self._lrs_lock_state()
        if not name:
            return True
        runtrace.event('service', 'waiting for LRS shared lock', signal=signal, property=name, value=value, timeout=timeout)
        try:
            xbmcgui.Dialog().notification('Library Artwork Curator', 'WAITING FOR LRS', xbmcgui.NOTIFICATION_INFO, 5000)
        except Exception:
            pass
        waited = 0
        while waited < timeout and not self.really_waitforabort(1):
            name, value = self._lrs_lock_state()
            if not name:
                runtrace.event('service', 'LRS shared lock released', waited=waited)
                return True
            waited += 1
        runtrace.event('service', 'LRS shared lock still active; auto work remains queued', signal=signal, property=name, value=value, waited=waited)
        return False

    def _sort_mediaitems(self, items):
        order = {mediatypes.MOVIESET: 0, mediatypes.MOVIE: 1, mediatypes.TVSHOW: 2, mediatypes.SEASON: 3, mediatypes.EPISODE: 4}

        def key(item):
            label = (getattr(item, 'label', '') or '').lower()
            show = (getattr(item, 'showtitle', '') or '').lower()
            season = int(getattr(item, 'season', 0) or 0)
            episode = int(getattr(item, 'episode', 0) or 0)
            if item.mediatype == mediatypes.EPISODE:
                return (order.get(item.mediatype, 99), show or label, season, episode, label)
            if item.mediatype == mediatypes.SEASON:
                return (order.get(item.mediatype, 99), show or label, season, label)
            return (order.get(item.mediatype, 99), label)
        return sorted(items, key=key)

    def _dedupe_mediaitems(self, items):
        result, seen = [], set()
        for item in items:
            key = '{0}:{1}'.format(item.mediatype, item.dbid)
            if key in seen:
                continue
            seen.add(key)
            result.append(item)
        return result

    def process_allvideos(self, shouldinclude_fn=None, foreground=False, force_progress=False, refresh_all=False):
        timer = __import__('time').time()
        shouldinclude_fn = shouldinclude_fn or (lambda dbid, mediatype, label: True)
        items = []
        counts = {}

        def add_items(mediatype, rows, idkey):
            before = len(items)
            for row in rows:
                if shouldinclude_fn(row[idkey], mediatype, row.get('label', '')):
                    items.append(info.MediaItem(row))
            counts[mediatype] = len(items) - before

        if not mediatypes.disabled(mediatypes.MOVIESET):
            add_items(mediatypes.MOVIESET, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIESET)), 'setid')
        if not mediatypes.disabled(mediatypes.MOVIE):
            add_items(mediatypes.MOVIE, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)), 'movieid')
        if not mediatypes.disabled(mediatypes.TVSHOW):
            add_items(mediatypes.TVSHOW, quickjson.get_tvshows(), 'tvshowid')
        if not mediatypes.disabled(mediatypes.SEASON):
            add_items(mediatypes.SEASON, quickjson.get_seasons(), 'seasonid')
        if not mediatypes.disabled(mediatypes.EPISODE):
            add_items(mediatypes.EPISODE, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)), 'episodeid')
        items = self._sort_mediaitems(self._dedupe_mediaitems(items))
        runtrace.event('service', 'process_allvideos collected items', total=len(items), counts=counts, order='set,movie,tvshow,season,episode', elapsed_ms=int((__import__('time').time() - timer) * 1000))
        self.reset_recent()
        return self.processor.process_medialist(items, foreground=foreground, force_progress=force_progress, refresh_all=refresh_all)

    def process_recentvideos(self, force_progress=False, notify_empty=False, refresh_all=False, auto=False):
        runtrace.event('service', 'process_recentvideos start', recent=self.recentvideos)
        items, seen_sets, seen_shows, seen_seasons = [], set(), set(), set()
        merged = {'movie': [], 'tvshow': [], 'episode': []}
        for mediatype in merged:
            merged[mediatype].extend(self.recentvideos.get(mediatype, []))

        for mediatype in ('movie', 'tvshow', 'episode'):
            for dbid in merged.get(mediatype, []):
                row = quickjson.get_item_details(dbid, mediatype)
                if not row:
                    continue
                if mediatype == 'movie' and row.get('setid') and row['setid'] not in seen_sets and not mediatypes.disabled(mediatypes.MOVIESET):
                    seen_sets.add(row['setid'])
                    setrow = quickjson.get_item_details(row['setid'], mediatypes.MOVIESET)
                    if setrow:
                        items.append(info.MediaItem(setrow))
                if mediatype == 'episode' and row.get('tvshowid') not in seen_shows and not mediatypes.disabled(mediatypes.TVSHOW):
                    seen_shows.add(row.get('tvshowid'))
                    showrow = quickjson.get_item_details(row['tvshowid'], mediatypes.TVSHOW)
                    if showrow:
                        items.append(info.MediaItem(showrow))
                if mediatype == 'episode' and not mediatypes.disabled(mediatypes.SEASON):
                    season_key = (row.get('tvshowid'), row.get('season'))
                    if season_key not in seen_seasons:
                        seen_seasons.add(season_key)
                        for seasonrow in quickjson.get_seasons(row.get('tvshowid')):
                            if int(seasonrow.get('season') or 0) == int(row.get('season') or 0):
                                items.append(info.MediaItem(seasonrow))
                                break
                items.append(info.MediaItem(row))

        self.reset_recent()
        items = self._sort_mediaitems(self._dedupe_mediaitems(items))
        runtrace.event('service', 'process_recentvideos collected items', total=len(items), queue_mode='memory', order='set,movie,tvshow,season,episode')
        if items:
            if auto:
                try:
                    xbmcgui.Dialog().notification('Library Artwork Curator', 'AUTO FILL ARTWORK STARTED - {0} ITEM{1}'.format(len(items), '' if len(items) == 1 else 'S'), xbmcgui.NOTIFICATION_INFO, 4000)
                except Exception:
                    pass
            return self.processor.process_medialist(items, alwaysnotify=True, force_progress=force_progress, refresh_all=refresh_all, suppress_final=auto)
        if notify_empty:
            runtrace.event('service', 'manual queue empty; no notification shown')
        return True

    def notify_finished(self, success, auto=False):
        summary = getattr(self.processor, 'last_summary', {}) or {}
        if success:
            pykodi.execute_builtin('NotifyAll(script.artwork.curator, OnVideoProcessingFinished)')
            if auto and int(summary.get('total') or 0) > 0:
                message = 'AUTO FILL ARTWORK FINISHED - {0} ITEMS - {1} ARTWORK - {2} ERRORS'.format(
                    int(summary.get('total') or 0),
                    int(summary.get('updated_artwork') or 0),
                    int(summary.get('errors') or 0),
                )
                xbmcgui.Dialog().notification('Library Artwork Curator', message, xbmcgui.NOTIFICATION_INFO, 7000)
        else:
            self.processor.close_progress()
            if auto and int(summary.get('total') or 0) > 0:
                xbmcgui.Dialog().notification('Library Artwork Curator', 'AUTO FILL ARTWORK ABORTED - {0} ITEMS'.format(int(summary.get('total') or 0)), xbmcgui.NOTIFICATION_WARNING, 7000)


def get_date():
    return pykodi.get_infolabel('System.Date(yyyy-mm-dd)')

if __name__ == '__main__':
    log('Video-only remote Library Artwork Curator service started', xbmc.LOGINFO)
    ArtworkService().run()
    log('Video-only remote Library Artwork Curator service stopped', xbmc.LOGINFO)

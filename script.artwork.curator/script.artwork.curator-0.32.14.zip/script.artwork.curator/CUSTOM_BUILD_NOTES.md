# Library Artwork Curator 0.32.13

- Context menu fixed: actions are now registered at the root `kodi.core.main` menu with loose visibility, so the menu can show from library views, hubs, and widgets.
- Context resolver improved: DBID is preferred, then DBTYPE is normalized (`movieset` -> `set`), then Kodi info labels / unique IDs / title-year / file path are used to resolve the item back to the Kodi library.
- Added `Library Artwork Curator: Dry run artwork selection`.
- Dry run performs the Refresh All selection path for the focused item only: provider fetch + selection + update plan. It does not write Kodi artwork, does not update `artwork-cache.db`, and does not cache textures.
- Dry-run diagnostic files:
  - `diagnostics/dry-run-artwork-selection-last.txt`
  - `diagnostics/dry-run-artwork-selection.txt`
- Diagnostics ZIP automatically includes those files because it includes the full diagnostics folder.

Addon ID remains `script.artwork.curator`. Visible name remains `Library Artwork Curator`.

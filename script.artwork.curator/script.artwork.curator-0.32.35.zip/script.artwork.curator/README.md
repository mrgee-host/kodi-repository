# Library Artwork Curator 0.32.35 custom build

Auto scan now uses the same structural flow as Library Ratings Scraper: scan snapshot -> pending auto job -> service loop consume -> retry DB busy -> direct processing.

# Library Artwork Curator — custom Kodi 22 beta 0.29.1

Video-only remote artwork fork based on Library Artwork Curator.

## Included media types

- Movies
- Movie sets / collections
- TV shows
- Seasons
- Episodes

Music videos, artists, albums, songs, local artwork downloads, media-folder supporting files, and legacy `extrafanart` directories are deliberately removed.

## Remote providers

- The Movie Database (primary)
- fanart.tv (fallback and extra artwork types)
- TheTVDB (TV fallback)

## Custom rules

- Artwork remains a remote URL in the Kodi video library.
- Kodi texture cache may be preloaded from the add-on menu or automatically for newly assigned art.
- Indonesian media prioritize `id`, then `en`, then no-language artwork.
- Other media use the configured/Kodi language, then `en`, then no-language artwork.
- SVG and raw local artwork paths are cleared during processing. Existing manually selected HTTP/HTTPS URLs are preserved, including extensionless poster-service asset URLs.
- Multiple backdrops are assigned as `fanart`, `fanart1`, `fanart2`, and so on.
- Protected custom sets are not overwritten automatically:
  - Indonesian Movies Collection
  - Thailand Movies Collection
  - Animation Short Films Collection

## Install and test

Install the ZIP from Kodi using **Install from zip file**. This is a beta build: first test on a copy of the Kodi profile and a small library subset. Enable Kodi web server / remote control via HTTP if using the cache menu actions.

## Beta limitation

Actor thumbnails are intentionally not rewritten by this beta build. The previous standalone database script updated actor thumbnails directly in SQLite, but this add-on runs while Kodi is open. A safe JSON-RPC actor-art update path is not included yet.

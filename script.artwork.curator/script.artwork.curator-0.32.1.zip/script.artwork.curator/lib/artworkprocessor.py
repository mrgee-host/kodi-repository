import os
import random
import re
import traceback
import xbmc
import xbmcgui
from datetime import timedelta

from lib import cleaner, reporting, refreshdebug, runtrace, artworkdb
from lib.artworkselection import prompt_for_artwork
from lib.filemanager import FileManager
from lib.gatherer import Gatherer
from lib.libs import mediainfo as info, mediatypes, pykodi, quickjson
from lib.libs.addonsettings import (settings, PROGRESS_DISPLAY_FULLPROGRESS,
    PROGRESS_DISPLAY_NONE, EXCLUSION_PATH_TYPE_FOLDER, EXCLUSION_PATH_TYPE_PREFIX,
    EXCLUSION_PATH_TYPE_REGEX)
from lib.libs.processeditems import ProcessedItems
from lib.libs.pykodi import datetime_now, localize as L, log
from lib.libs.utils import SortedDisplay, natural_sort, get_simpledict_updates
from lib.providers import search

MODE_AUTO = 'auto'
MODE_GUI = 'gui'
MODE_DEBUG = 'debug'
THROTTLE_TIME = 0.02

SOMETHING_MISSING = 32001
FINAL_MESSAGE = 32019
ADDING_ARTWORK_MESSAGE = 32020
NOT_AVAILABLE_MESSAGE = 32021
ARTWORK_UPDATED_MESSAGE = 32022
NO_ARTWORK_UPDATED_MESSAGE = 32023
NOT_SUPPORTED_MESSAGE = 32025
CURRENT_ART = 13512
ENTER_COLLECTION_NAME = 32057
NO_IDS_MESSAGE = 32030
FILENAME_ENCODING_ERROR = 32040

CURATOR_REMOTE_HOST_MARKERS = ('image.tmdb.org', 'fanart.tv', 'thetvdb.com')

class ArtworkProcessor(object):
    """Video-only, remote-only artwork processor.

    This fork intentionally has no music library, music-video, NFO, filesystem-art,
    artwork download, or extrafanart-folder workflow.
    """
    def __init__(self, monitor=None):
        self.monitor = monitor or xbmc.Monitor()
        self.autolanguages = ()
        self.current_languages = ()
        self.progress = None
        self.progress_foreground = False
        self.cancelled = False
        self.visible = False
        self.processed = ProcessedItems()
        self.gatherer = None
        self.downloader = None
        self.chunkcount = 1
        self.currentchunk = 0
        self.current_item_index = 0
        self.current_item_total = 1
        self.debug = False
        self.idle_inhibited = False
        self.refresh_indonesian = False
        self.db_run_id = None
        self.refresh_all_artwork = False
        settings.update_settings()
        mediatypes.update_settings()

    def create_progress(self, foreground=False, force=False):
        if not self.visible and (force or settings.progressdisplay == PROGRESS_DISPLAY_FULLPROGRESS):
            self.progress_foreground = bool(foreground)
            self.progress = xbmcgui.DialogProgress() if foreground else xbmcgui.DialogProgressBG()
            if foreground:
                self.progress.create('Artwork Curator', L(ADDING_ARTWORK_MESSAGE))
            else:
                self.progress.create('Artwork Curator: ' + L(ADDING_ARTWORK_MESSAGE), '')
            self.visible = True

    def update_progress(self, percent, message, heading=None):
        if self.chunkcount > 1:
            onechunk = 100 / float(self.chunkcount)
            percent = int(onechunk * self.currentchunk + percent / float(self.chunkcount))
        if self.visible:
            if self.progress_foreground:
                try:
                    self.progress.update(percent, message)
                except TypeError:
                    self.progress.update(percent, heading or '', message)
                if self.progress.iscanceled():
                    self.cancelled = True
            else:
                self.progress.update(percent, heading or '', message)

    @staticmethod
    def _compact_arttypes(arttypes, maximum=4):
        clean = []
        for arttype in arttypes or ():
            value = str(arttype or '').strip()
            if value and value not in clean:
                clean.append(value)
        if not clean:
            return ''
        shown = clean[:maximum]
        result = ', '.join(shown)
        if len(clean) > maximum:
            result += ' +{0}'.format(len(clean) - maximum)
        return result

    def item_status(self, action, mediaitem, arttypes=(), stage=0.0):
        total = float(self.current_item_total or 1)
        percent = int(((self.current_item_index + max(0.0, min(0.99, stage))) * 100) / total)
        types = self._compact_arttypes(arttypes)
        heading = 'Artwork Curator: {0}'.format(action)
        if types:
            heading += ' · ' + types
        runtrace.item_status(action, mediaitem, arttypes, stage=stage, percent=percent)
        self.update_progress(percent, mediaitem.label, heading)

    def finalupdate(self, header, message):
        if settings.final_notification:
            xbmcgui.Dialog().notification('Artwork Curator: ' + header, message, '-', 8000)
        elif self.visible:
            self.update_progress(100, message, header)

    def close_progress(self):
        if self.visible:
            self.progress.close()
            self.progress = None
            self.progress_foreground = False
            self.visible = False

    def notify_warning(self, message, header=None, error=False):
        if settings.progressdisplay != PROGRESS_DISPLAY_NONE:
            xbmcgui.Dialog().notification('Artwork Curator: ' + (header or 'Warning'), message,
                xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_WARNING)

    def set_idle_inhibition(self, enabled):
        """Keep long artwork jobs from launching a screensaver or idle shutdown."""
        enabled = bool(enabled)
        if self.idle_inhibited == enabled:
            return
        state = 'true' if enabled else 'false'
        try:
            pykodi.execute_builtin('InhibitScreensaver({0})'.format(state))
            pykodi.execute_builtin('InhibitIdleShutdown({0})'.format(state))
            self.idle_inhibited = enabled
            log('Idle inhibition {0}'.format('enabled' if enabled else 'disabled'), xbmc.LOGINFO)
        except Exception:
            log('Could not change Kodi idle inhibition state', xbmc.LOGWARNING)
            log(traceback.format_exc(), xbmc.LOGWARNING)

    def init_run(self, show_progress=False, chunkcount=1, foreground=False, force_progress=False):
        runtrace.event('processor', 'init_run', show_progress=show_progress, chunkcount=chunkcount, foreground=foreground, force_progress=force_progress)
        self.set_idle_inhibition(True)
        self.setlanguages()
        self.gatherer = Gatherer(self.monitor, self.autolanguages)
        self.downloader = FileManager(self.debug, True)
        self.chunkcount = chunkcount
        self.currentchunk = 0
        self.cancelled = False
        if show_progress:
            self.create_progress(foreground, force_progress)

    def set_debug(self, debug):
        if self.downloader:
            self.downloader.debug = debug
        reporting.debug = debug
        self.debug = debug

    def finish_run(self):
        runtrace.event('processor', 'finish_run')
        try:
            info.clear_cache()
            self.downloader = None
            self.set_debug(False)
            self.close_progress()
        finally:
            self.set_idle_inhibition(False)

    @property
    def processor_busy(self):
        return pykodi.get_conditional('![String.IsEqual(Window(Home).Property(ArtworkCurator.Status),idle)]')

    def process_item(self, mediatype, dbid, mode):
        if mediatype not in mediatypes.artinfo:
            xbmcgui.Dialog().notification('Artwork Curator', L(NOT_SUPPORTED_MESSAGE).format(mediatype), '-', 6500)
            return
        if self.processor_busy:
            return
        self.init_run()
        if mode == MODE_DEBUG:
            self.set_debug(True)
            mode = MODE_AUTO
        busy = None
        if mode == MODE_GUI:
            busy = pykodi.get_busydialog()
            busy.create()
        try:
            mediaitem = info.MediaItem(quickjson.get_item_details(dbid, mediatype))
            info.add_additional_iteminfo(mediaitem, self.processed, search)
            if mediatype in mediatypes.require_manualid and not mediaitem.uniqueids and mode == MODE_GUI:
                self.manual_id(mediaitem)
                info.add_additional_iteminfo(mediaitem, self.processed, search)
            if mode == MODE_GUI:
                self._manual_item_process(mediaitem, busy)
            else:
                self.process_medialist([mediaitem], True, already_initialized=True)
        finally:
            if busy:
                try:
                    busy.close()
                except Exception:
                    pass
            if mode == MODE_GUI:
                self.finish_run()

    def _manual_item_process(self, mediaitem, busy):
        self._process_item(mediaitem, skipexisting=False)
        if busy:
            busy.close()
        availableart = dict(mediaitem.availableart)
        tag_forcedandexisting_art(availableart, {}, mediaitem.art)
        if not availableart:
            xbmcgui.Dialog().notification(L(NOT_AVAILABLE_MESSAGE), L(SOMETHING_MISSING) + ' ' + L(FINAL_MESSAGE), '-', 8000)
            return
        arttype, selected = prompt_for_artwork(mediaitem.mediatype, mediaitem.label, availableart, self.monitor)
        if arttype == '!!-Refresh' and mediaitem.mediatype == mediatypes.MOVIESET:
            self.processed.set_data(mediaitem.dbid, mediaitem.mediatype, mediaitem.label, None)
            if self.manual_id(mediaitem):
                mediaitem.uniqueids = {}
                info.add_additional_iteminfo(mediaitem, self.processed, search)
                if busy:
                    busy.create()
                self._manual_item_process(mediaitem, busy)
            return
        if not arttype or selected is None:
            return
        if mediatypes.get_artinfo(mediaitem.mediatype, arttype)['multiselect']:
            changed = info.fill_multiart(mediaitem.art, arttype, selected)
            toset = get_simpledict_updates(mediaitem.art, changed)
        else:
            toset = {arttype: selected}
        if toset:
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, toset)
            mediaitem.updatedart = list(toset)
            self.cache_remote(mediaitem, toset)
            reporting.report_item(mediaitem, True, True, self.downloader.size)
            notifycount(len(toset))

    def process_medialist(self, medialist, alwaysnotify=False, already_initialized=False, foreground=False, force_progress=False, refresh_indonesian=False, refresh_all=False):
        timer = __import__('time').time()
        runtrace.event('processor', 'process_medialist start', total=len(medialist or []), alwaysnotify=alwaysnotify, already_initialized=already_initialized, refresh_indonesian=refresh_indonesian, refresh_all=refresh_all)
        previous_refresh = self.refresh_indonesian
        previous_refresh_all = self.refresh_all_artwork
        self.refresh_indonesian = bool(refresh_indonesian)
        self.refresh_all_artwork = bool(refresh_all)
        self.db_run_id = artworkdb.begin_run(
            'refresh_indonesian' if refresh_indonesian else ('refresh_all' if refresh_all else 'scrape_missing'),
            total_items=len(medialist or []),
            notes='force_progress={0};foreground={1};refresh_all={2}'.format(force_progress, foreground, refresh_all)
        )
        if not already_initialized:
            self.init_run(True, 1, foreground, force_progress)
        elif self.gatherer is None:
            self.init_run(True, 1, foreground, force_progress)
        try:
            reporting.report_start(medialist)
            aborted, updateditems, artcount = self._process_chunk(medialist)
            reporting.report_end(medialist, updateditems if aborted else 0, self.downloader.size)
            if artcount or alwaysnotify:
                self.finalupdate(*finalmessages(artcount))
            runtrace.event('processor', 'process_medialist end', aborted=aborted, updateditems=updateditems, artcount=artcount, elapsed_ms=int((__import__('time').time() - timer) * 1000))
            return not aborted
        finally:
            elapsed_ms = int((__import__('time').time() - timer) * 1000)
            try:
                artworkdb.finish_run(
                    self.db_run_id,
                    status='aborted' if self.cancelled else 'finished',
                    updated_items=locals().get('updateditems', 0),
                    updated_artwork=locals().get('artcount', 0),
                    errors=0,
                    elapsed_ms=elapsed_ms
                )
            except Exception as db_ex:
                runtrace.error('artwork-cache.db finish_run failed', db_ex)
            runtrace.perf('processor.process_medialist', elapsed_ms, total=len(medialist or []), refresh_indonesian=refresh_indonesian)
            self.refresh_indonesian = previous_refresh
            self.refresh_all_artwork = previous_refresh_all
            self.db_run_id = None
            self.finish_run()

    def process_chunkedlist(self, chunkedlist, chunkcount, alwaysnotify=False):
        self.init_run(True, chunkcount)
        aborted, total = False, 0
        try:
            for index, medialist in enumerate(chunkedlist):
                self.currentchunk = index
                if self.monitor.abortRequested() or medialist is False:
                    aborted = True
                    break
                reporting.report_start(medialist)
                this_aborted, updateditems, artcount = self._process_chunk(medialist)
                total += artcount
                reporting.report_end(medialist, updateditems if this_aborted else 0, self.downloader.size)
                self.downloader.size = 0
                if this_aborted:
                    aborted = True
                    break
            if total or alwaysnotify:
                self.finalupdate(*finalmessages(total))
            return not aborted
        finally:
            self.finish_run()

    def _process_chunk(self, medialist):
        updateditems, artcount = 0, 0
        total = len(medialist)
        for index, mediaitem in enumerate(medialist):
            item_timer = __import__('time').time()
            services_hit = None
            if self.monitor.abortRequested() or self.cancelled:
                return True, updateditems, artcount
            self.current_item_index = index
            self.current_item_total = total or 1
            self.item_status('Checking', mediaitem, (), 0.00)
            if is_excluded(mediaitem):
                self.item_status('Skipping', mediaitem, (), 0.98)
                runtrace.item_result(mediaitem, int((__import__('time').time() - item_timer) * 1000), updatedart=[], error_text='excluded')
                continue
            try:
                self.item_status('Reading', mediaitem, (), 0.08)
                info.add_additional_iteminfo(mediaitem, self.processed, search)
                services_hit = self._process_item(mediaitem, skipexisting=not self.refresh_all_artwork, refresh_existing=self.refresh_all_artwork)

                # Record successful scans so automatic "new videos" processing stays incremental.
                self.processed.set_nextdate(
                    mediaitem.dbid, mediaitem.mediatype, mediaitem.label,
                    datetime_now() + timedelta(days=plus_some(224, 32)))
                if mediaitem.mediatype == mediatypes.TVSHOW:
                    self.processed.set_data(
                        mediaitem.dbid, mediaitem.mediatype, mediaitem.label, mediaitem.season)
                if mediaitem.updatedart:
                    updateditems += 1
                    artcount += len(mediaitem.updatedart)
                reporting.report_item(mediaitem)
                elapsed_item_ms = int((__import__('time').time() - item_timer) * 1000)
                artworkdb.record_item(mediaitem, self.db_run_id, status='processed', updatedart=mediaitem.updatedart, elapsed_ms=elapsed_item_ms)
                runtrace.item_result(mediaitem, elapsed_item_ms, updatedart=mediaitem.updatedart, services_hit=services_hit)
            except Exception as ex:
                # A broken provider response or malformed library item must not stop
                # the full-library run. Keep going and write the traceback to kodi.log.
                mediaitem.error = '{0}: {1}'.format(type(ex).__name__, ex)
                self.item_status('Error', mediaitem, (), 0.98)
                log('Recovered item error: {0} [{1}:{2}]'.format(
                    mediaitem.label, mediaitem.mediatype, mediaitem.dbid), xbmc.LOGERROR)
                log(traceback.format_exc(), xbmc.LOGERROR)
                elapsed_item_ms = int((__import__('time').time() - item_timer) * 1000)
                artworkdb.record_item(mediaitem, self.db_run_id, status='error', updatedart=getattr(mediaitem, 'updatedart', []), elapsed_ms=elapsed_item_ms, error=mediaitem.error)
                runtrace.item_result(mediaitem, elapsed_item_ms, updatedart=getattr(mediaitem, 'updatedart', []), error_text=mediaitem.error, services_hit=services_hit)
                try:
                    reporting.report_item(mediaitem, forcedreport=True)
                except Exception as report_ex:
                    runtrace.error('Could not write recovered item error to report', report_ex, mediatype=mediaitem.mediatype, dbid=mediaitem.dbid)
                    log('Could not write recovered item error to report', xbmc.LOGWARNING)
                    log(traceback.format_exc(), xbmc.LOGWARNING)
            xbmc.sleep(int(THROTTLE_TIME * 1000))
        return False, updateditems, artcount

    def _process_item(self, mediaitem, skipexisting=True, refresh_existing=False):
        existing_before = [arttype for arttype, url in mediaitem.art.items() if url]
        self.item_status('Checking', mediaitem, existing_before, 0.12)

        cleaned = cleaner.clean_artwork(mediaitem)
        cleanchanges = get_simpledict_updates(mediaitem.art, cleaned)
        if cleanchanges:
            self.item_status('Cleaning', mediaitem, cleanchanges.keys(), 0.18)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, cleanchanges)
            mediaitem.art.update(cleanchanges)

        mediaitem.missingart = list(info.iter_missing_arttypes(mediaitem, mediaitem.art))
        mediaitem.missingid = not bool(mediaitem.uniqueids)
        if mediaitem.missingid:
            self.item_status('Skipping', mediaitem, mediaitem.missingart, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False
        if mediaitem.protected_custom_set:
            self.item_status('Skipping', mediaitem, (), 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False
        if refresh_existing:
            return self._process_refresh_all_item(mediaitem, cleanchanges, existing_before)
        if self.refresh_indonesian and mediaitem.indonesia_hint:
            return self._process_indonesian_refresh(mediaitem, cleanchanges, existing_before)
        if not mediaitem.missingart:
            self.item_status('Skipping', mediaitem, existing_before, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False

        self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
        self.gatherer.set_languages(self.current_languages)
        self.item_status('Searching', mediaitem, mediaitem.missingart, 0.30)
        services_hit, error = self.gatherer.getartwork(mediaitem, skipexisting=skipexisting)
        if error:
            mediaitem.error = '{0}: {1}'.format(error['providername'], error['message'])
        self.item_status('Selecting', mediaitem, mediaitem.missingart, 0.60)
        selected = self.get_top_missing_art(info.iter_missing_arttypes(mediaitem, mediaitem.art),
            mediaitem.mediatype, mediaitem.art, mediaitem.availableart, mediaitem=mediaitem)
        if selected:
            self.item_status('Adding', mediaitem, selected.keys(), 0.72)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, selected)
            mediaitem.art.update(selected)
        else:
            self.item_status('Missing', mediaitem, mediaitem.missingart, 0.88)
        self._mark_missing_na(mediaitem, mediaitem.missingart, selected)
        combined = dict(cleanchanges)
        combined.update(selected)
        mediaitem.updatedart = list(combined)
        self.cache_remote(mediaitem, selected)
        self.item_status('Done', mediaitem, combined.keys(), 0.98)
        return services_hit

    def _is_curator_managed_url(self, url):
        lower = (url or '').lower()
        return lower.startswith(('http://', 'https://')) and any(marker in lower for marker in CURATOR_REMOTE_HOST_MARKERS)

    def _existing_artwork_is_manual(self, url):
        return bool(url) and not self._is_curator_managed_url(url) and not url.startswith('image://')

    def _iter_refresh_targets(self, mediaitem):
        targets = []

        def add_target(exacttype, current_url=None):
            if current_url and self._existing_artwork_is_manual(current_url):
                return
            if exacttype not in targets:
                targets.append(exacttype)

        for arttype, artcfg in mediatypes.artinfo[mediaitem.mediatype].items():
            if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                continue
            if artcfg['multiselect']:
                existing_urls = [
                    url for key, url in mediaitem.art.items()
                    if info.arttype_matches_base(key, arttype) and url
                ]
                if existing_urls and any(self._existing_artwork_is_manual(url) for url in existing_urls):
                    continue
                add_target(arttype)
            else:
                add_target(arttype, mediaitem.art.get(arttype))

        if mediaitem.mediatype == mediatypes.TVSHOW:
            for season in mediaitem.seasons:
                for arttype, artcfg in mediatypes.artinfo[mediatypes.SEASON].items():
                    if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                        continue
                    exact = '{0}.{1}.{2}'.format(mediatypes.SEASON, season, arttype)
                    add_target(exact, mediaitem.art.get(exact))

        for arttype in mediatypes.othertypes[mediaitem.mediatype]:
            current = mediaitem.art.get(arttype)
            if current and self._existing_artwork_is_manual(current):
                continue
            if arttype not in mediaitem.skip_artwork and arttype not in targets:
                targets.append(arttype)

        return targets

    def _existing_art_for_refresh(self, mediaitem, targets):
        result = dict(mediaitem.art)
        for target in targets:
            itemtype, artkey = mediatypes.hack_mediaarttype(mediaitem.mediatype, target)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            if cfg['multiselect']:
                for key in list(result):
                    if info.arttype_matches_base(key, target):
                        result[key] = None
            else:
                result[target] = None
        return result

    def _build_refresh_updates(self, mediaitem, selected, targets):
        updates = {}
        selected = selected or {}
        for target in targets:
            itemtype, artkey = mediatypes.hack_mediaarttype(mediaitem.mediatype, target)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            if cfg['multiselect']:
                chosen_urls = [
                    url for exact, url in sorted(selected.items(), key=lambda pair: pair[0])
                    if info.arttype_matches_base(exact, target) and url
                ]
                if not chosen_urls:
                    continue
                existing_urls = [
                    url for key, url in mediaitem.art.items()
                    if info.arttype_matches_base(key, target) and url
                ]
                rebuilt = info.fill_multiart(mediaitem.art, target, (chosen_urls, existing_urls))
                updates.update(get_simpledict_updates(mediaitem.art, rebuilt))
            else:
                chosen = selected.get(target)
                if chosen and chosen != mediaitem.art.get(target):
                    updates[target] = chosen
        return updates

    def _debug_indonesian_poster(self, mediaitem, refresh_targets, selected=None, refresh_updates=None, phase=''):
        current_poster = mediaitem.art.get('poster')
        refreshdebug.write('')
        refreshdebug.write('ITEM {0}:{1} | {2} | phase={3}'.format(
            mediaitem.mediatype, mediaitem.dbid, mediaitem.label, phase))
        refreshdebug.write('  file={0}'.format(mediaitem.file or '-'))
        refreshdebug.write('  indonesia_hint={0}'.format(bool(mediaitem.indonesia_hint)))
        refreshdebug.write('  uniqueids={0}'.format(mediaitem.uniqueids))
        refreshdebug.write('  languages={0}'.format(self.current_languages))
        refreshdebug.write('  current poster={0}'.format(current_poster or '-'))
        refreshdebug.write('  refresh targets={0}'.format(refresh_targets))
        candidates = mediaitem.availableart.get('poster', [])
        refreshdebug.write('  poster candidates={0}'.format(len(candidates)))
        for index, candidate in enumerate(candidates[:30], 1):
            refreshdebug.write(refreshdebug.format_candidate(index, candidate))
        if len(candidates) > 30:
            refreshdebug.write('    ... {0} more candidate(s) omitted'.format(len(candidates) - 30))
        if selected is not None:
            refreshdebug.write('  selected poster={0}'.format(selected.get('poster') or '-'))
        if refresh_updates is not None:
            refreshdebug.write('  poster update={0}'.format(refresh_updates.get('poster') or '-'))

    def _verify_indonesian_poster_update(self, mediaitem, expected_url):
        if not expected_url or mediaitem.mediatype != mediatypes.MOVIE:
            return
        try:
            verify = quickjson.get_item_details(mediaitem.dbid, mediaitem.mediatype) or {}
            actual = info.get_own_artwork(verify).get('poster')
            refreshdebug.important(
                'VERIFY {0}:{1} | {2} | expected={3} | actual={4} | match={5}'.format(
                    mediaitem.mediatype, mediaitem.dbid, mediaitem.label,
                    expected_url, actual or '-', actual == expected_url
                )
            )
        except Exception as ex:
            refreshdebug.important(
                'VERIFY ERROR {0}:{1} | {2} | {3}'.format(
                    mediaitem.mediatype, mediaitem.dbid, mediaitem.label, repr(ex)
                )
            )


    def _mark_missing_na(self, mediaitem, requested, selected):
        selected = selected or {}
        for requested_art in requested or ():
            found = False
            for exact, url in selected.items():
                if url and info.arttype_matches_base(exact, requested_art):
                    found = True
                    break
            artworkdb.mark_art_status(mediaitem.mediatype, mediaitem.dbid, requested_art, 'OK' if found else 'N/A', '' if found else 'No provider candidate selected')

    def _process_refresh_all_item(self, mediaitem, cleanchanges, existing_before):
        refresh_targets = self._iter_refresh_targets(mediaitem)
        if not refresh_targets:
            self.item_status('Skipping', mediaitem, existing_before, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False
        self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
        self.gatherer.set_languages(self.current_languages)
        self.item_status('Searching', mediaitem, refresh_targets, 0.30)
        services_hit, error = self.gatherer.getartwork(mediaitem, skipexisting=False)
        if error:
            mediaitem.error = '{0}: {1}'.format(error['providername'], error['message'])
        self.item_status('Selecting', mediaitem, refresh_targets, 0.60)
        selected = self.get_top_missing_art(
            refresh_targets,
            mediaitem.mediatype,
            self._existing_art_for_refresh(mediaitem, refresh_targets),
            mediaitem.availableart,
            mediaitem=mediaitem,
        )
        refresh_updates = self._build_refresh_updates(mediaitem, selected, refresh_targets)
        combined = dict(cleanchanges)
        combined.update(refresh_updates)
        if refresh_updates:
            self.item_status('Adding', mediaitem, refresh_updates.keys(), 0.72)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, refresh_updates)
            mediaitem.art.update(refresh_updates)
        self._mark_missing_na(mediaitem, refresh_targets, selected)
        mediaitem.updatedart = list(combined)
        self.cache_remote(mediaitem, refresh_updates)
        self.item_status('Done', mediaitem, combined.keys(), 0.98)
        return services_hit

    def _process_indonesian_refresh(self, mediaitem, cleanchanges, existing_before):
        refresh_targets = self._iter_refresh_targets(mediaitem)
        if not refresh_targets:
            self.item_status('Skipping', mediaitem, existing_before, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False

        self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
        self.gatherer.set_languages(self.current_languages)
        self.item_status('Searching', mediaitem, refresh_targets, 0.30)
        services_hit, error = self.gatherer.getartwork(mediaitem, skipexisting=False)
        if error:
            mediaitem.error = '{0}: {1}'.format(error['providername'], error['message'])
        self.item_status('Selecting', mediaitem, refresh_targets, 0.60)
        self._debug_indonesian_poster(mediaitem, refresh_targets, phase='after-gather')

        selected = self.get_top_missing_art(
            refresh_targets,
            mediaitem.mediatype,
            self._existing_art_for_refresh(mediaitem, refresh_targets),
            mediaitem.availableart,
            mediaitem=mediaitem,
        )
        refresh_updates = self._build_refresh_updates(mediaitem, selected, refresh_targets)
        self._debug_indonesian_poster(
            mediaitem, refresh_targets, selected=selected,
            refresh_updates=refresh_updates, phase='after-select')
        combined = dict(cleanchanges)
        combined.update(refresh_updates)
        if refresh_updates:
            self.item_status('Adding', mediaitem, refresh_updates.keys(), 0.72)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, refresh_updates)
            mediaitem.art.update(refresh_updates)
            self._verify_indonesian_poster_update(mediaitem, refresh_updates.get('poster'))
        else:
            self.item_status('Skipping', mediaitem, existing_before, 0.88)
        mediaitem.updatedart = list(combined)
        self.cache_remote(mediaitem, refresh_updates)
        self.item_status('Done', mediaitem, combined.keys(), 0.98)
        return services_hit

    def cache_remote(self, mediaitem, toset):
        if settings.cache_remote_video_artwork and self.downloader:
            artmap = dict(mediaitem.art)
            artmap.update(toset or {})
            urltypes = {}
            for arttype, url in artmap.items():
                if url:
                    urltypes.setdefault(url, []).append(arttype)
            self.item_status('Checking', mediaitem, (toset or {}).keys(), 0.80)

            def on_cache_progress(done, total, url):
                # Keep the compact BG progress notification informative while
                # Kodi fetches remote URLs into userdata/Thumbnails.
                self.item_status('Downloading', mediaitem, urltypes.get(url, ()), 0.82 + (0.15 * done / float(total or 1)))

            self.downloader.cachefor(artmap, progress_callback=on_cache_progress)

    def manual_id(self, mediaitem):
        if mediaitem.mediatype != mediatypes.MOVIESET:
            return False
        result = xbmcgui.Dialog().input(L(ENTER_COLLECTION_NAME), mediaitem.label)
        if not result:
            return False
        options = search[mediaitem.mediatype].search(result, mediaitem.mediatype)
        selected = xbmcgui.Dialog().select(mediaitem.label, [option['label'] for option in options])
        if selected < 0:
            return False
        tmdbid = options[selected]['uniqueids'].get('tmdb')
        if tmdbid:
            self.processed.set_data(mediaitem.dbid, mediaitem.mediatype, mediaitem.label, tmdbid)
        return bool(tmdbid)

    def setlanguages(self):
        languages = []
        if settings.language_override:
            languages.append(settings.language_override)
        if settings.language_fallback_kodi:
            language = pykodi.get_language(xbmc.ISO_639_1)
            if language not in languages:
                languages.append(language)
        if settings.language_fallback_en and 'en' not in languages:
            languages.append('en')
        if None not in languages:
            languages.append(None)
        self.autolanguages = tuple(languages)
        log('Working language filter: ' + repr(self.autolanguages))

    def get_top_missing_art(self, missingarts, mediatype, existingart, availableart, mediaitem=None):
        newartwork = {}
        for missingart in missingarts:
            candidates = availableart.get(missingart, [])
            if not candidates:
                continue
            itemtype, artkey = mediatypes.hack_mediaarttype(mediatype, missingart)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            if cfg['multiselect']:
                existingurls = [url for art, url in existingart.items()
                    if info.arttype_matches_base(art, missingart) and url]
                exactnames = [art for art, url in existingart.items()
                    if info.arttype_matches_base(art, missingart) and url]
                usable = [art for art in candidates if self._auto_filter(missingart, art, mediatype, candidates, existingurls)]
                selected_urls = []
                newindex = 0
                for index in range(cfg['autolimit']):
                    exact = info.format_arttype(missingart, index)
                    if exact in exactnames:
                        continue
                    if newindex >= len(usable):
                        break
                    newartwork[exact] = usable[newindex]['url']
                    selected_urls.append('{0}={1}'.format(exact, usable[newindex]['url']))
                    existingurls.append(usable[newindex]['url'])
                    newindex += 1
                runtrace.selection(mediaitem, mediatype, missingart, candidates, usable, chosen='; '.join(selected_urls), existing_count=len(exactnames))
            else:
                usable = [art for art in candidates if self._auto_filter(missingart, art, mediatype, candidates)]
                chosen = usable[0] if usable else None
                runtrace.selection(mediaitem, mediatype, missingart, candidates, usable, chosen=chosen.get('url') if chosen else None)
                if chosen:
                    newartwork[missingart] = chosen['url']
        return newartwork

    def _passes_size_filter(self, basearttype, art):
        if basearttype.endswith('fanart') and art.get('size', SortedDisplay(0, '')).sort < settings.minimum_size:
            return False
        if basearttype.endswith('poster') and art.get('size', SortedDisplay(0, '')).sort < settings.minimum_poster_height:
            return False
        return True

    def _candidate_has_acceptable_language(self, art):
        language = art.get('language')
        return language in self.current_languages or language is None


    def _auto_filter(self, basearttype, art, mediatype, availableart, ignoreurls=()):
        if art.get('url') in ignoreurls:
            return False
        if not self._passes_size_filter(basearttype, art):
            return False

        # Rating is intentionally informational only. Selection is deterministic:
        # language priority, provider priority, provider/API index order, and the
        # configured minimum resolution. This prevents sparse or missing votes
        # from reshuffling otherwise correct artwork.
        language = art.get('language')
        if language in self.current_languages:
            # Title-free artwork is preferred for fanart by the language sort above.
            return True
        # Last resort: allow no-language candidate only when no acceptable-language candidate exists.
        if language is None:
            return not any(candidate.get('language') in self.current_languages and candidate.get('url') not in ignoreurls
                for candidate in availableart)
        return False


def add_art_to_library(mediatype, seasons, dbid, selectedart):
    if not selectedart:
        return
    if mediatype == mediatypes.TVSHOW:
        for season, season_id in seasons.items():
            prefix = 'season.{0}.'.format(season)
            seasonart = dict((arttype[len(prefix):], url) for arttype, url in selectedart.items() if arttype.startswith(prefix))
            info.update_art_in_library(mediatypes.SEASON, season_id, seasonart)
        itemart = dict((arttype, url) for arttype, url in selectedart.items() if '.' not in arttype)
        info.update_art_in_library(mediatype, dbid, itemart)
    else:
        info.update_art_in_library(mediatype, dbid, selectedart)
    info.remove_local_from_texturecache(selectedart.values())


def finalmessages(count):
    return (L(ARTWORK_UPDATED_MESSAGE).format(count), L(FINAL_MESSAGE)) if count else \
        (L(NO_ARTWORK_UPDATED_MESSAGE), L(SOMETHING_MISSING) + ' ' + L(FINAL_MESSAGE))


def notifycount(count):
    header, message = finalmessages(count)
    xbmcgui.Dialog().notification('Artwork Curator: ' + header, message, '-', 8000)


def plus_some(start, rng):
    return start + random.randrange(-rng, rng + 1)


def is_excluded(mediaitem):
    if not mediaitem.file:
        return False
    for exclusion in settings.pathexclusion:
        if exclusion['type'] == EXCLUSION_PATH_TYPE_FOLDER:
            path_file = os.path.realpath(os.path.join(mediaitem.file, ''))
            path_excl = os.path.realpath(os.path.join(exclusion['folder'], ''))
            if os.path.commonprefix([path_file, path_excl]) == path_excl:
                return True
        elif exclusion['type'] == EXCLUSION_PATH_TYPE_PREFIX and mediaitem.file.startswith(exclusion['prefix']):
            return True
        elif exclusion['type'] == EXCLUSION_PATH_TYPE_REGEX and re.match(exclusion['regex'], mediaitem.file):
            return True
    return False


def tag_forcedandexisting_art(availableart, forcedart, existingart):
    typeinsert = {}
    for exacttype, existingurl in existingart.items():
        arttype = info.get_basetype(exacttype)
        if arttype not in availableart:
            availableart[arttype] = []
        match = next((available for available in availableart[arttype] if available.get('url') == existingurl), None)
        if match:
            match['preview'] = existingurl
            match['existing'] = True
            match.setdefault('title', exacttype)
        elif existingurl:
            typeinsert[arttype] = typeinsert.get(arttype, -1) + 1
            availableart[arttype].insert(typeinsert[arttype], {
                'url': existingurl, 'preview': existingurl, 'title': exacttype,
                'existing': True, 'provider': SortedDisplay('current', L(CURRENT_ART)),
                'rating': SortedDisplay(10, ''), 'size': SortedDisplay(10000, ''), 'language': None,
            })

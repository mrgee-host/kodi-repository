import traceback
import xbmc

from lib import providers
from lib.libs import mediatypes
from lib.libs.addonsettings import settings
from lib.libs.mediainfo import keep_arttype
from lib.libs.pykodi import localize as L, log
from lib.libs.utils import SortedDisplay
from lib.providers import ProviderError

MAX_ERRORS = 3
TOO_MANY_ERRORS = 32031

class Gatherer(object):
    def __init__(self, monitor, languages):
        self.monitor = monitor
        self.languages = tuple(languages or ())
        providers.base.languages = self.languages
        self.providererrors = {}

    def set_languages(self, languages):
        self.languages = tuple(languages or ())
        providers.base.languages = self.languages

    def getartwork(self, mediaitem, fsonly=False, skipexisting=True):
        services_hit, error = False, None
        mediaitem.forcedart = {}
        if mediaitem.protected_custom_set:
            mediaitem.availableart = {}
            return False, None
        if mediaitem.uniqueids:
            requested = mediaitem.missingart if skipexisting else None
            if not skipexisting or requested:
                mediaitem.availableart, error = self.get_external_artwork(
                    mediaitem.mediatype, mediaitem.seasons, mediaitem.uniqueids, requested)
                services_hit = True
        if 'keyart' in mediaitem.availableart and (settings.titlefree_poster or
                not mediatypes.get_artinfo(mediaitem.mediatype, 'keyart')['autolimit']):
            mediaitem.availableart.setdefault('poster', []).extend(mediaitem.availableart['keyart'])
        for arttype, imagelist in mediaitem.availableart.items():
            _sort_images(arttype, imagelist, mediaitem.sourcemedia, mediaitem.mediatype)
        return services_hit, error

    def get_external_artwork(self, mediatype, seasons, uniqueids, missing=None):
        images, error = {}, None
        for provider in providers.external.get(mediatype, ()):
            errcount = self.providererrors.get(provider.name, 0)
            if errcount >= MAX_ERRORS:
                continue
            try:
                providerimages = provider.get_images(uniqueids, missing)
                self.providererrors[provider.name] = 0
            except Exception as ex:
                errcount += 1
                self.providererrors[provider.name] = errcount
                if errcount == 1 or errcount == MAX_ERRORS:
                    error = {'providername': provider.name.display,
                             'message': getattr(ex, 'message', repr(ex)) if errcount == 1 else L(TOO_MANY_ERRORS)}
                if not isinstance(ex, ProviderError):
                    log('Error parsing provider response', xbmc.LOGWARNING)
                    log(traceback.format_exc(), xbmc.LOGWARNING)
                continue
            for arttype, artlist in providerimages.items():
                if arttype.startswith('season.'):
                    try:
                        if int(arttype.rsplit('.', 2)[1]) not in seasons:
                            continue
                    except ValueError:
                        continue
                images.setdefault(arttype, []).extend(artlist)
            if self.monitor.abortRequested():
                break
        return images, error


def _sort_images(basearttype, imagelist, mediasource, mediatype):
    # Keep the provider/API response index as the default order. Rating and
    # image dimensions remain available for diagnostics, but they do not reorder
    # candidates. Minimum-resolution filtering is applied later by ArtworkProcessor.
    if basearttype.endswith('poster'):
        # Preserve gallery order, except for the localized primary poster returned
        # by the id-ID details endpoint. It is explicitly promoted for Indonesian
        # media while still using the /images row for real size/rating metadata.
        imagelist.sort(key=lambda image: image.get('gallery_order', 999999))
        imagelist.sort(key=lambda image: bool(image.get('details_primary') or image.get('localized_primary')), reverse=True)
    imagelist.sort(key=lambda image: mediatypes.provider_priority(image['provider'][0]), reverse=True)
    if basearttype == 'discart' and mediasource != 'unknown':
        imagelist.sort(key=lambda image: image.get('subtype', SortedDisplay('', '')).sort != mediasource)
    imagelist.sort(key=lambda image: _imagelanguage_sort(image, basearttype))


def _size_sort(image):
    imagesplit = image.get('size', SortedDisplay(0, '')).display.split('x')
    if len(imagesplit) != 2:
        return image.get('size', SortedDisplay(0, '')).sort // 200
    try:
        imagesize = int(imagesplit[0]), int(imagesplit[1])
    except ValueError:
        return image.get('size', SortedDisplay(0, '')).sort // 200
    if imagesize[0] > settings.preferredsize[0]:
        shrink = settings.preferredsize[0] / float(imagesize[0])
        imagesize = settings.preferredsize[0], imagesize[1] * shrink
    if imagesize[1] > settings.preferredsize[1]:
        shrink = settings.preferredsize[1] / float(imagesize[1])
        imagesize = imagesize[0] * shrink, settings.preferredsize[1]
    return int(max(imagesize) // 200)


def _imagelanguage_sort(image, basearttype):
    language = image.get('language')
    languages = providers.base.languages
    if language in languages:
        primary = languages.index(language)
    else:
        primary = len(languages) + 1
    # Prefer title-free backdrops for fanart. For posters, language-specific title art wins
    # unless the user explicitly requests title-free posters.
    if language and basearttype.endswith('fanart') and settings.titlefree_fanart:
        primary += len(languages) + 1
    if language and basearttype.endswith('poster') and settings.titlefree_poster:
        primary += len(languages) + 1
    return primary, language or ''

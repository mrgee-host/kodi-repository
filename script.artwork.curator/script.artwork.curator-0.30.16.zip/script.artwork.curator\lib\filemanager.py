from urllib.parse import quote
from concurrent.futures import ThreadPoolExecutor, as_completed
import xbmc

from lib.libs import pykodi, quickjson
from lib.libs.addonsettings import settings
from lib.libs.pykodi import localize as L, log
from lib.libs.webhelper import Getter, GetterError

CANT_CONTACT_PROVIDER = 32034
HTTP_ERROR = 32035
REMOTE_CONTROL_REQUIRED = 32039

class FileManager(object):
    """Remote-only texture-cache helper.

    This fork deliberately does not write poster.jpg, fanart.jpg, extrafanart,
    or any other artwork file beside the media files.
    """
    def __init__(self, debug=False, bigcache=False):
        self.getter = Getter()
        self.getter.session.headers['User-Agent'] = settings.useragent
        self.size = 0
        self.debug = debug
        self.alreadycached = [] if bigcache else None
        self._build_imagecachebase()

    def _build_imagecachebase(self):
        result = pykodi.execute_jsonrpc({'jsonrpc': '2.0', 'id': 1, 'method': 'Settings.GetSettings',
            'params': {'filter': {'category': 'control', 'section': 'services'}}})
        port, username, password, secure, enabled = 80, '', '', False, True
        values = result.get('result', {}).get('settings')
        if not values:
            enabled = False
        else:
            for setting in values:
                sid, value = setting.get('id'), setting.get('value')
                if sid == 'services.webserver' and not value:
                    enabled = False
                elif sid == 'services.webserverusername':
                    username = value
                elif sid == 'services.webserverport':
                    port = value
                elif sid == 'services.webserverpassword':
                    password = value
                elif sid == 'services.webserverssl' and value:
                    secure = True
        auth = '{0}:{1}@'.format(username, password) if username and password else ''
        self.imagecachebase = '{0}://{1}localhost:{2}/image/'.format('https' if secure else 'http', auth, port) if enabled else None
        if not enabled:
            log(L(REMOTE_CONTROL_REQUIRED), xbmc.LOGWARNING)

    def downloadfor(self, mediaitem, allartwork=True):
        return False, ''

    def remove_deselected_files(self, mediaitem, assignedart=False):
        return

    def set_bigcache(self):
        if self.alreadycached is None:
            self.alreadycached = []

    def cachefor(self, artmap, multiplethreads=False, progress_callback=None, cancel_callback=None):
        """Cache remote URLs through Kodi's internal /image endpoint.

        Batch cache operations use a small fixed worker pool. This is noticeably
        faster than sequential downloads but avoids creating hundreds of threads
        or overwhelming Kodi's local web server.
        """
        if not self.imagecachebase or self.debug:
            return 0

        urls = []
        for url in artmap.values():
            if not url or not url.startswith(('http://', 'https://', 'image://')):
                continue
            if url not in urls:
                urls.append(url)
        if not urls:
            return 0

        if self.alreadycached is not None:
            if not self.alreadycached:
                self.alreadycached = [pykodi.unquoteimage(texture['url']) for texture in quickjson.get_textures()]
            already = set(self.alreadycached)
        else:
            already = set(pykodi.unquoteimage(texture['url']) for texture in quickjson.get_textures())

        pending = [path for path in urls if path not in already]
        total = len(pending)
        if not total:
            return 0

        def fetch(path):
            if cancel_callback and cancel_callback():
                return path, False
            try:
                response, _ = self.doget(
                    self.imagecachebase + quote(pykodi.quoteimage(path), ''),
                    stream=True,
                )
                if not response:
                    return path, False
                for _ in response.iter_content(chunk_size=8192):
                    pass
                response.close()
                return path, True
            except Exception:
                return path, False

        count = 0
        completed = 0

        if multiplethreads and total > 1:
            # Four workers are fast enough for Kodi's localhost image endpoint
            # without flooding it with one thread for every artwork URL.
            executor = ThreadPoolExecutor(max_workers=min(4, total))
            futures = {executor.submit(fetch, path): path for path in pending}
            try:
                for future in as_completed(futures):
                    path = futures[future]
                    try:
                        _, success = future.result()
                    except Exception:
                        success = False
                    completed += 1
                    if success:
                        count += 1
                        if self.alreadycached is not None:
                            self.alreadycached.append(path)
                    if progress_callback:
                        progress_callback(completed, total, path)
                    if cancel_callback and cancel_callback():
                        for remaining in futures:
                            remaining.cancel()
                        break
            finally:
                executor.shutdown(wait=True)
        else:
            for path in pending:
                if cancel_callback and cancel_callback():
                    break
                _, success = fetch(path)
                completed += 1
                if success:
                    count += 1
                    if self.alreadycached is not None:
                        self.alreadycached.append(path)
                if progress_callback:
                    progress_callback(completed, total, path)

        return count

    def doget(self, url, **kwargs):
        try:
            result = self.getter(url, **kwargs)
            return result, None
        except GetterError as ex:
            message = L(CANT_CONTACT_PROVIDER) if ex.connection_error else L(HTTP_ERROR).format(ex.message) + '\n' + url
            return None, message

class FileError(Exception):
    def __init__(self, message, cause=None):
        super(FileError, self).__init__(message)
        self.cause = cause
        self.message = message

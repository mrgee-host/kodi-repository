import xbmc
import traceback
from itertools import chain

from lib.artworkprocessor import ArtworkProcessor
from lib.libs import mediainfo as info, mediatypes, pykodi, quickjson
from lib.libs.addonsettings import settings
from lib.libs.processeditems import ProcessedItems
from lib import runtrace
from lib.libs.pykodi import log, json

STATUS_IDLE = 'idle'
STATUS_SIGNALLED = 'signalled'
STATUS_PROCESSING = 'processing'
addon = pykodi.get_main_addon()

class ArtworkService(xbmc.Monitor):
    """Video-library listener only. AudioLibrary notifications are intentionally ignored."""
    def __init__(self):
        super(ArtworkService, self).__init__()
        self.abort = False
        self.processor = ArtworkProcessor(self)
        self.processed = ProcessedItems()
        self.processaftersettings = False
        self.recentvideos = {'movie': [], 'tvshow': [], 'episode': []}
        self.stoppeditems = set()
        self._signal = None
        self._status = None
        self._last_videoupdate = addon.get_setting('last_videoupdate') or '0'
        self.status = STATUS_IDLE

    @property
    def scanning(self):
        return pykodi.get_conditional('Library.IsScanningVideo')

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, value):
        self._status = value
        self.abort = False
        pykodi.execute_builtin('SetProperty(ArtworkCurator.Status, {0}, Home)'.format(value))

    @property
    def signal(self):
        return self._signal

    @signal.setter
    def signal(self, value):
        self._signal = value
        self.status = STATUS_SIGNALLED if value else STATUS_IDLE

    @property
    def last_videoupdate(self):
        return self._last_videoupdate

    @last_videoupdate.setter
    def last_videoupdate(self, value):
        addon.set_setting('last_videoupdate', value)
        self._last_videoupdate = value

    def reset_recent(self):
        self.recentvideos = {'movie': [], 'tvshow': [], 'episode': []}

    def run(self):
        while not self.really_waitforabort(5):
            if self.scanning or not self.signal:
                continue
            signal = self.signal
            self._signal = None
            if signal == 'recentvideos':
                self.signal = 'recentvideos_really'
                continue
            self.status = STATUS_PROCESSING
            with runtrace.run_context('service.signal.' + str(signal), signal=signal):
                try:
                    if signal == 'allvideos':
                        self.notify_finished(self.process_allvideos())
                    elif signal == 'allvideos_manual':
                        self.notify_finished(self.process_allvideos(force_progress=True))
                    elif signal == 'newvideos':
                        self.notify_finished(self.process_allvideos(self.processed.does_not_exist))
                    elif signal == 'newvideos_manual':
                        self.notify_finished(self.process_recentvideos(force_progress=True, notify_empty=True))
                    elif signal == 'oldvideos':
                        successful = self.process_allvideos(self.processed.is_stale)
                        if successful:
                            self.last_videoupdate = get_date()
                        self.notify_finished(successful)
                    elif signal == 'oldvideos_manual':
                        successful = self.process_allvideos(self.processed.is_stale, force_progress=True)
                        if successful:
                            self.last_videoupdate = get_date()
                        self.notify_finished(successful)
                    elif signal == 'recentvideos_really':
                        self.process_recentvideos()
                except Exception as ex:
                    runtrace.error('Recovered unexpected Artwork Curator service error', ex, signal=signal)
                    log('Recovered unexpected Artwork Curator service error', xbmc.LOGERROR)
                    log(traceback.format_exc(), xbmc.LOGERROR)
                    try:
                        self.processor.close_progress()
                        self.processor.set_idle_inhibition(False)
                        self.processor.notify_warning('Processing stopped. Check kodi.log.', 'Error', True)
                    except Exception as inner:
                        runtrace.error('Service cleanup after error failed', inner, signal=signal)
                        log(traceback.format_exc(), xbmc.LOGWARNING)
                finally:
                    self.status = STATUS_IDLE

    def abortRequested(self):
        return self.waitForAbort(0.0001)

    def waitForAbort(self, timeout=0):
        return self.abort or super(ArtworkService, self).waitForAbort(timeout)

    def really_waitforabort(self, timeout=0):
        return super(ArtworkService, self).waitForAbort(timeout)

    def onNotification(self, sender, method, data):
        runtrace.event('notification', 'received', sender=sender, method=method, data=str(data)[:600])
        if method.startswith('Other.') and sender != 'script.artwork.curator:control':
            return
        if method == 'Other.CancelCurrent':
            if self.status == STATUS_PROCESSING:
                self.abort = True
            elif self.signal:
                self.signal = None
                self.processor.close_progress()
        elif method == 'Other.ProcessNewVideos':
            self.signal = 'newvideos'
        elif method == 'Other.ProcessNewVideosManual':
            self.signal = 'newvideos_manual'
        elif method == 'Other.ProcessNewAndOldVideos':
            self.signal = 'oldvideos'
        elif method == 'Other.ProcessNewAndOldVideosManual':
            self.signal = 'oldvideos_manual'
        elif method == 'Other.ProcessAllVideos':
            self.signal = 'allvideos'
        elif method == 'Other.ProcessAllVideosManual':
            self.signal = 'allvideos_manual'
        elif method == 'Other.ProcessAfterSettings':
            self.processaftersettings = True
        elif method == 'VideoLibrary.OnScanStarted' and settings.enableservice and self.status == STATUS_PROCESSING:
            self.abort = True
        elif method == 'VideoLibrary.OnScanFinished' and settings.enableservice:
            total_recent = sum(len(values) for values in self.recentvideos.values())
            scan_old = settings.enable_olditem_updates and get_date() > self.last_videoupdate
            if total_recent:
                log('Automatic processing queued after VideoLibrary.OnScanFinished for {0} queued new item(s)'.format(total_recent), xbmc.LOGINFO)
                self.signal = 'recentvideos_really'
            elif scan_old:
                log('Automatic older-item update queued after VideoLibrary.OnScanFinished', xbmc.LOGINFO)
                self.signal = 'oldvideos'
            else:
                log('Automatic processing skipped after VideoLibrary.OnScanFinished: no queued new video item IDs', xbmc.LOGINFO)
        elif method == 'VideoLibrary.OnUpdate' and settings.enableservice:
            try:
                payload = json.loads(data)
            except Exception:
                return
            if self.watchitem(payload):
                item = payload['item']
                if mediatypes.disabled(item['type']):
                    runtrace.event('service', 'ignore OnUpdate scope disabled', mediatype=item['type'], dbid=item['id'])
                    return
                if item['id'] not in self.recentvideos[item['type']]:
                    self.recentvideos[item['type']].append(item['id'])
                log('Automatic new-item ID queued after VideoLibrary.OnUpdate: {0}:{1}'.format(
                    item['type'], item['id']), xbmc.LOGINFO)
                if not self.scanning:
                    self.signal = 'recentvideos'

    def onSettingsChanged(self):
        settings.update_settings()
        mediatypes.update_settings()
        if self.processaftersettings:
            self.processaftersettings = False
            self.signal = 'newvideos'

    def watchitem(self, payload):
        item = payload.get('item', {})
        return item.get('id') not in (None, -1) and item.get('type') in self.recentvideos and 'playcount' not in payload

    def process_allvideos(self, shouldinclude_fn=None, foreground=False, force_progress=False):
        timer = __import__('time').time()
        shouldinclude_fn = shouldinclude_fn or (lambda dbid, mediatype, label: True)
        items = []
        counts = {}
        if not mediatypes.disabled(mediatypes.MOVIESET):
            before = len(items)
            items.extend(info.MediaItem(row) for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIESET))
                if shouldinclude_fn(row['setid'], mediatypes.MOVIESET, row['label']))
            counts[mediatypes.MOVIESET] = len(items) - before
        if not mediatypes.disabled(mediatypes.MOVIE):
            before = len(items)
            items.extend(info.MediaItem(row) for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE))
                if shouldinclude_fn(row['movieid'], mediatypes.MOVIE, row['label']))
            counts[mediatypes.MOVIE] = len(items) - before
        if not mediatypes.disabled(mediatypes.TVSHOW):
            before = len(items)
            items.extend(info.MediaItem(row) for row in quickjson.get_tvshows()
                if shouldinclude_fn(row['tvshowid'], mediatypes.TVSHOW, row['label']))
            counts[mediatypes.TVSHOW] = len(items) - before
        if not mediatypes.disabled(mediatypes.EPISODE):
            before = len(items)
            items.extend(info.MediaItem(row) for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE))
                if shouldinclude_fn(row['episodeid'], mediatypes.EPISODE, row['label']))
            counts[mediatypes.EPISODE] = len(items) - before
        runtrace.event('service', 'process_allvideos collected items', total=len(items), counts=counts, elapsed_ms=int((__import__('time').time() - timer) * 1000))
        self.reset_recent()
        return self.processor.process_medialist(items, foreground=foreground, force_progress=force_progress)

    def process_recentvideos(self, force_progress=False, notify_empty=False):
        runtrace.event('service', 'process_recentvideos start', recent=self.recentvideos)
        items, seen_sets, seen_shows = [], set(), set()
        for mediatype in ('movie', 'tvshow', 'episode'):
            for dbid in self.recentvideos[mediatype]:
                row = quickjson.get_item_details(dbid, mediatype)
                if not row:
                    continue
                if mediatype == 'movie' and row.get('setid') and row['setid'] not in seen_sets:
                    seen_sets.add(row['setid'])
                    setrow = quickjson.get_item_details(row['setid'], mediatypes.MOVIESET)
                    if setrow:
                        items.append(info.MediaItem(setrow))
                if mediatype == 'episode' and row.get('tvshowid') not in seen_shows:
                    seen_shows.add(row.get('tvshowid'))
                    showrow = quickjson.get_item_details(row['tvshowid'], mediatypes.TVSHOW)
                    if showrow:
                        items.append(info.MediaItem(showrow))
                items.append(info.MediaItem(row))
        self.reset_recent()
        runtrace.event('service', 'process_recentvideos collected items', total=len(items))
        if items:
            return self.processor.process_medialist(items, alwaysnotify=True, force_progress=force_progress)
        if notify_empty:
            self.processor.notify_warning('No queued new library items found.', 'Nothing to process')
        return True

    def notify_finished(self, success):
        if success:
            pykodi.execute_builtin('NotifyAll(script.artwork.curator, OnVideoProcessingFinished)')
        else:
            self.processor.close_progress()


def get_date():
    return pykodi.get_infolabel('System.Date(yyyy-mm-dd)')

if __name__ == '__main__':
    log('Video-only remote Artwork Curator service started', xbmc.LOGINFO)
    ArtworkService().run()
    log('Video-only remote Artwork Curator service stopped', xbmc.LOGINFO)

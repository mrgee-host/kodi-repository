
import os
import sqlite3
import time
import traceback

import xbmcvfs

from lib.libs import pykodi
from lib import runtrace

ADDON_ID = 'script.artwork.curator'
DB_NAME = 'artwork-cache.db'
SCHEMA_VERSION = 1

def _translate(path):
    value = xbmcvfs.translatePath(path)
    if isinstance(value, bytes):
        value = value.decode('utf-8', 'replace')
    return value

def profile_dir():
    path = _translate('special://profile/addon_data/%s/' % ADDON_ID)
    if not os.path.isdir(path):
        try: os.makedirs(path)
        except Exception: pass
    return path

def db_path():
    return os.path.join(profile_dir(), DB_NAME)

def connect():
    conn = sqlite3.connect(db_path())
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    init(conn)
    return conn

def init(conn=None):
    own = conn is None
    conn = conn or sqlite3.connect(db_path())
    try:
        conn.executescript('''
        CREATE TABLE IF NOT EXISTS metadata (key TEXT PRIMARY KEY, value TEXT);
        CREATE TABLE IF NOT EXISTS runs (
            run_id TEXT PRIMARY KEY, action TEXT, started_at INTEGER, finished_at INTEGER,
            status TEXT, total_items INTEGER DEFAULT 0, updated_items INTEGER DEFAULT 0,
            updated_artwork INTEGER DEFAULT 0, errors INTEGER DEFAULT 0, elapsed_ms INTEGER DEFAULT 0, notes TEXT
        );
        CREATE TABLE IF NOT EXISTS library_items (
            item_key TEXT PRIMARY KEY, media_type TEXT, dbid INTEGER, title TEXT, show_title TEXT,
            season INTEGER, episode INTEGER, file TEXT, uniqueids TEXT, last_seen_at INTEGER,
            last_processed_at INTEGER, status TEXT, error TEXT
        );
        CREATE TABLE IF NOT EXISTS artwork_slots (
            item_key TEXT, art_type TEXT, url TEXT, is_icon INTEGER DEFAULT 0, updated_at INTEGER,
            PRIMARY KEY (item_key, art_type)
        );
        CREATE TABLE IF NOT EXISTS run_items (
            run_id TEXT, item_key TEXT, media_type TEXT, dbid INTEGER, title TEXT, status TEXT,
            updated_arttypes TEXT, elapsed_ms INTEGER DEFAULT 0, error TEXT,
            PRIMARY KEY (run_id, item_key)
        );
        CREATE TABLE IF NOT EXISTS maintenance_events (
            event_id INTEGER PRIMARY KEY AUTOINCREMENT, run_id TEXT, action TEXT, media_type TEXT,
            dbid INTEGER, title TEXT, art_type TEXT, old_url TEXT, status TEXT, created_at INTEGER
        );
        CREATE INDEX IF NOT EXISTS idx_library_items_type_dbid ON library_items(media_type, dbid);
        CREATE INDEX IF NOT EXISTS idx_artwork_slots_type ON artwork_slots(art_type);
        CREATE INDEX IF NOT EXISTS idx_run_items_run ON run_items(run_id);
        CREATE INDEX IF NOT EXISTS idx_maintenance_action ON maintenance_events(action);
        ''')
        conn.execute('INSERT OR REPLACE INTO metadata(key, value) VALUES(?, ?)', ('schema_version', str(SCHEMA_VERSION)))
        conn.execute('INSERT OR REPLACE INTO metadata(key, value) VALUES(?, ?)', ('addon_version', pykodi.get_main_addon().version))
        conn.commit()
    finally:
        if own: conn.close()

def _now(): return int(time.time())
def _item_key(mediatype, dbid): return '%s:%s' % (mediatype, dbid)

def _jsonish(value):
    try:
        import json
        return json.dumps(value or {}, sort_keys=True)
    except Exception:
        return repr(value)

def begin_run(action, total_items=0, notes=''):
    init()
    run_id = time.strftime('%Y%m%d-%H%M%S') + '-' + action.replace(' ', '_').replace('.', '_')[:40]
    conn = connect()
    try:
        conn.execute('INSERT OR REPLACE INTO runs(run_id, action, started_at, status, total_items, notes) VALUES(?, ?, ?, ?, ?, ?)',
                     (run_id, action, _now(), 'running', int(total_items or 0), notes or ''))
        conn.commit()
    finally:
        conn.close()
    return run_id

def finish_run(run_id, status='finished', updated_items=0, updated_artwork=0, errors=0, elapsed_ms=0, notes=''):
    if not run_id: return
    conn = connect()
    try:
        conn.execute('''UPDATE runs SET finished_at=?, status=?, updated_items=?, updated_artwork=?, errors=?, elapsed_ms=?, notes=COALESCE(NULLIF(?, ''), notes) WHERE run_id=?''',
                     (_now(), status, int(updated_items or 0), int(updated_artwork or 0), int(errors or 0), int(elapsed_ms or 0), notes or '', run_id))
        conn.commit()
    finally:
        conn.close()

def record_item(mediaitem, run_id=None, status='processed', updatedart=None, elapsed_ms=0, error=None):
    try:
        conn = connect(); item_key = _item_key(mediaitem.mediatype, mediaitem.dbid); now = _now()
        updatedart = list(updatedart or getattr(mediaitem, 'updatedart', []) or [])
        with conn:
            conn.execute('''INSERT OR REPLACE INTO library_items(item_key, media_type, dbid, title, show_title, season, episode, file, uniqueids, last_seen_at, last_processed_at, status, error) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                         (item_key, mediaitem.mediatype, int(mediaitem.dbid), mediaitem.label, getattr(mediaitem, 'showtitle', ''), getattr(mediaitem, 'season', None), getattr(mediaitem, 'episode', None), mediaitem.file or '', _jsonish(getattr(mediaitem, 'uniqueids', {})), now, now, status, error or getattr(mediaitem, 'error', None)))
            for art_type, url in sorted((getattr(mediaitem, 'art', {}) or {}).items()):
                if url:
                    conn.execute('INSERT OR REPLACE INTO artwork_slots(item_key, art_type, url, is_icon, updated_at) VALUES (?, ?, ?, ?, ?)',
                                 (item_key, art_type, url, 1 if art_type == 'icon' else 0, now))
            if run_id:
                conn.execute('''INSERT OR REPLACE INTO run_items(run_id, item_key, media_type, dbid, title, status, updated_arttypes, elapsed_ms, error) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                             (run_id, item_key, mediaitem.mediatype, int(mediaitem.dbid), mediaitem.label, status, ','.join(updatedart), int(elapsed_ms or 0), error or getattr(mediaitem, 'error', None)))
    except Exception as ex:
        runtrace.error('artwork-cache.db record_item failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''))

def record_maintenance(run_id, action, mediatype, dbid, title, art_type, old_url, status='updated'):
    try:
        conn = connect()
        with conn:
            conn.execute('''INSERT INTO maintenance_events(run_id, action, media_type, dbid, title, art_type, old_url, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)''',
                         (run_id, action, mediatype, int(dbid), title or '', art_type, old_url or '', status, _now()))
    except Exception as ex:
        runtrace.error('artwork-cache.db record_maintenance failed', ex, action=action, mediatype=mediatype, dbid=dbid)

def summary_text():
    init(); conn = connect(); rows = ['Artwork Curator cache DB summary', '=' * 72, 'path: %s' % db_path()]
    try:
        for table in ('runs', 'library_items', 'artwork_slots', 'run_items', 'maintenance_events'):
            count = conn.execute('SELECT COUNT(*) FROM %s' % table).fetchone()[0]
            rows.append('%s: %s' % (table, count))
        rows.append(''); rows.append('Recent runs:')
        for row in conn.execute('SELECT run_id, action, status, total_items, updated_items, updated_artwork, errors, elapsed_ms FROM runs ORDER BY started_at DESC LIMIT 20'):
            rows.append('%s | %s | %s | total=%s updated_items=%s artwork=%s errors=%s elapsed_ms=%s' % row)
    except Exception:
        rows.append(traceback.format_exc())
    finally:
        conn.close()
    return '\n'.join(rows) + '\n'

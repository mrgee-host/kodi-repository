import os
import random
import re
import traceback
import xbmc
import xbmcgui
from datetime import timedelta

from lib import cleaner, reporting, refreshdebug, runtrace, artworkdb
from lib.artworkselection import prompt_for_artwork
from lib.filemanager import FileManager
from lib.gatherer import Gatherer
from lib.libs import mediainfo as info, mediatypes, pykodi, quickjson
from lib.libs.addonsettings import (settings, PROGRESS_DISPLAY_FULLPROGRESS,
    PROGRESS_DISPLAY_NONE, EXCLUSION_PATH_TYPE_FOLDER, EXCLUSION_PATH_TYPE_PREFIX,
    EXCLUSION_PATH_TYPE_REGEX)
from lib.libs.pykodi import datetime_now, localize as L, log
from lib.libs.utils import SortedDisplay, natural_sort, get_simpledict_updates
from lib.providers import search

MODE_AUTO = 'auto'
MODE_GUI = 'gui'
MODE_DEBUG = 'debug'
MODE_DRYRUN = 'dryrun'
MODE_REFRESHITEM = 'refreshitem'
THROTTLE_TIME = 0.02
DRYRUN_CANDIDATE_LIMIT = 30

SOMETHING_MISSING = 32001
FINAL_MESSAGE = 32019
ADDING_ARTWORK_MESSAGE = 32020
NOT_AVAILABLE_MESSAGE = 32021
ARTWORK_UPDATED_MESSAGE = 32022
NO_ARTWORK_UPDATED_MESSAGE = 32023
NOT_SUPPORTED_MESSAGE = 32025
CURRENT_ART = 13512
ENTER_COLLECTION_NAME = 32057
NO_IDS_MESSAGE = 32030
FILENAME_ENCODING_ERROR = 32040

CURATOR_REMOTE_HOST_MARKERS = ('image.tmdb.org', 'fanart.tv', 'thetvdb.com')

def _family_notify_03252(message, level=xbmcgui.NOTIFICATION_INFO, duration=7000, *args, **kwargs):
    text = ' '.join(str(message or '').strip().split()).upper().rstrip()
    text = re.sub(r'\bHANDED OFF\b', 'MIGRATED', text)
    text = re.sub(r'\bHANDOFF\b', 'MIGRATED', text)
    parts = text.split(' - ') if text else []
    if len(parts) > 1:
        text = ' - '.join([parts[0]] + [part for part in parts[1:] if not re.match(r'^0(?:\s+|$)', part)])
    elif text and re.match(r'^0(?:\s+|$)', text):
        return
    if len(text) > 58:
        parts = text.split(' - ')
        protected = ('ERROR', 'FAILED', 'UPDATED', 'ARTWORK', 'ITEM', 'CACHED', 'MOVED', 'MIGRATED', 'SCRAPED', 'N/A')
        if len(parts) > 1 and any(token in ' - '.join(parts[1:]) for token in protected):
            suffix = ' - ' + ' - '.join(parts[1:])
            budget = max(4, 58 - len(suffix))
            action = parts[0]
            if len(action) > budget:
                action = action[:max(1, budget - 3)].rstrip() + '...'
            text = (action + suffix)[:58].rstrip()
        else:
            raw = text[:55].rstrip()
            text = (raw.rsplit(' ', 1)[0] if ' ' in raw else raw) + '...'
    if text:
        xbmcgui.Dialog().notification('Library Artwork Curator', text, level, int(duration))


class ArtworkProcessor(object):
    """Video-only, remote-only artwork processor.

    This fork intentionally has no music library, music-video, NFO, filesystem-art,
    artwork download, or extrafanart-folder workflow.
    """
    def __init__(self, monitor=None):
        self.monitor = monitor or xbmc.Monitor()
        self.autolanguages = ()
        self.current_languages = ()
        self.progress = None
        self.progress_foreground = False
        self.cancelled = False
        self.visible = False
        self.processed = artworkdb.RunItemState()
        self.gatherer = None
        self.downloader = None
        self.chunkcount = 1
        self.currentchunk = 0
        self.current_item_index = 0
        self.current_item_total = 1
        self.debug = False
        self.idle_inhibited = False
        self.refresh_indonesian = False
        self.db_run_id = None
        self.refresh_all_artwork = False
        self.item_error_count = 0
        self._last_process_aborted = False
        self._reload_skin_pending = False
        self._reload_skin_arttypes = set()
        self.last_summary = {}
        settings.update_settings()
        mediatypes.update_settings()

    def create_progress(self, foreground=False, force=False):
        if not self.visible and (force or settings.progressdisplay == PROGRESS_DISPLAY_FULLPROGRESS):
            self.progress_foreground = bool(foreground)
            self.progress = xbmcgui.DialogProgress() if foreground else xbmcgui.DialogProgressBG()
            if foreground:
                self.progress.create('Library Artwork Curator', L(ADDING_ARTWORK_MESSAGE))
            else:
                self.progress.create('Library Artwork Curator', L(ADDING_ARTWORK_MESSAGE))
            self.visible = True

    def update_progress(self, percent, message, heading=None):
        if self.chunkcount > 1:
            onechunk = 100 / float(self.chunkcount)
            percent = int(onechunk * self.currentchunk + percent / float(self.chunkcount))
        if self.visible:
            if self.progress_foreground:
                try:
                    self.progress.update(percent, message)
                except TypeError:
                    self.progress.update(percent, heading or '', message)
                if self.progress.iscanceled():
                    self.cancelled = True
            else:
                self.progress.update(percent, heading or '', message)

    @staticmethod
    def _reload_skin_art_base_03370(art_type):
        tail = str(art_type or '').lower().split('.')[-1]
        return re.sub(r'\d+$', '', tail)

    def mark_reload_skin_art_03370(self, mediatype, artwork):
        if mediatype not in (mediatypes.MOVIE, mediatypes.TVSHOW):
            return
        for art_type, url in dict(artwork or {}).items():
            raw_type = str(art_type or '').strip().lower()
            # Direct movie/TV-show art only. Nested season.* artwork must not reload the skin.
            if not raw_type or '.' in raw_type:
                continue
            base = self._reload_skin_art_base_03370(raw_type)
            if url and base in ('landscape', 'thumb'):
                self._reload_skin_pending = True
                self._reload_skin_arttypes.add('{0}.{1}'.format(mediatype, base))

    def _finish_reload_skin_03370(self, aborted=False):
        pending = bool(self._reload_skin_pending)
        art_types = sorted(self._reload_skin_arttypes)
        self._reload_skin_pending = False
        self._reload_skin_arttypes = set()
        if aborted or not pending:
            return False
        try:
            xbmc.executebuiltin('ReloadSkin()')
            runtrace.event('processor', 'skin reloaded after new movie/tvshow landscape/thumb artwork', art_types=art_types)
            return True
        except Exception as ex:
            runtrace.error('ReloadSkin after movie/tvshow artwork update failed', ex, art_types=art_types)
            return False

    @staticmethod
    def _compact_arttypes(arttypes, maximum=4):
        order = ['poster', 'fanart', 'extrafanart', 'landscape', 'banner', 'thumb', 'clearlogo', 'logo', 'clearart', 'keyart', 'discart', 'characterart']
        clean = []
        for arttype in arttypes or ():
            value = str(arttype or '').strip()
            if not value:
                continue
            base = value.rstrip('0123456789')
            if base == 'fanart' and value != 'fanart':
                value = 'extrafanart'
            if value not in clean:
                clean.append(value)
        clean.sort(key=lambda value: order.index(value.rstrip('0123456789')) if value.rstrip('0123456789') in order else 99)
        if not clean:
            return ''
        shown = clean[:maximum]
        result = ','.join(v.upper() for v in shown)
        if len(clean) > maximum:
            result += ',+{0}'.format(len(clean) - maximum)
        return result

    def _display_title(self, mediaitem):
        title = (getattr(mediaitem, 'label', '') or '').upper()
        if mediaitem.mediatype == mediatypes.EPISODE:
            show = (getattr(mediaitem, 'showtitle', '') or '').upper()
            episode_title = title
            try:
                sx = 'S{0:02d}E{1:02d}'.format(int(mediaitem.season or 0), int(mediaitem.episode or 0))
                xx = '{0}X{1:02d}'.format(int(mediaitem.season or 0), int(mediaitem.episode or 0))
                episode_title = re.sub(r'^(?:' + re.escape(sx) + '|' + re.escape(xx) + r')\s*[.:-]?\s*', '', episode_title, flags=re.I).strip()
            except Exception:
                pass
            prefix = show + ' - '
            if show and episode_title.startswith(prefix):
                episode_title = episode_title[len(prefix):].strip()
            try:
                return '{0} - S{1:02d}E{2:02d} - {3}'.format(
                    episode_title or 'EPISODE', int(mediaitem.season or 0),
                    int(mediaitem.episode or 0), show or 'SERIES')
            except Exception:
                return episode_title or show or title
        if mediaitem.mediatype == mediatypes.SEASON and getattr(mediaitem, 'showtitle', ''):
            try:
                return '{0} - SEASON {1:02d}'.format(mediaitem.showtitle.upper(), int(getattr(mediaitem, 'season', 0) or 0))
            except Exception:
                return '{0} - {1}'.format(mediaitem.showtitle.upper(), title)
        return title

    def _phase_name(self, action):
        if self.refresh_indonesian:
            return 'INDONESIAN'
        if self.refresh_all_artwork:
            return 'REFRESH ARTWORK'
        mapping = {
            'Missing': 'FILL MISSING ARTWORK',
            'Adding': 'FILL MISSING ARTWORK',
            'Searching': 'FILL MISSING ARTWORK',
            'Selecting': 'FILL MISSING ARTWORK',
            'Checking': 'FILL MISSING ARTWORK',
            'Reading': 'FILL MISSING ARTWORK',
            'Done': 'FILL MISSING ARTWORK',
            'Skipping': 'FILL MISSING ARTWORK',
            'Applying': 'FILL MISSING ARTWORK',
            'Error': 'FILL MISSING ARTWORK',
            'Cleaning': 'CLEAN ARTWORK',
            'Downloading': 'CACHE',
        }
        return mapping.get(action, str(action or '').upper())

    def _word_ellipsis(self, value, limit):
        text = ' '.join(str(value or '').strip().split())
        limit = max(0, int(limit or 0))
        if len(text) <= limit:
            return text
        if limit <= 1:
            return '…'[:limit]
        raw = text[:limit - 1].rstrip()
        if ' ' in raw:
            candidate = raw.rsplit(' ', 1)[0].rstrip()
            if candidate:
                raw = candidate
        return raw + '…'

    def _fit_line(self, line, maxlen=58):
        line = ' '.join(str(line or '').strip().split()).upper()
        target = int(maxlen or 58)
        if len(line) <= target:
            return line.rstrip()
        match = re.match(r'^(\d+/\d+)\s+(.*?)\s+-\s+(S\d{2}E\d{2})\s+-\s+(.*?)(?:\s+-\s+(MIGRATED|CACHING))?$', line, re.I)
        if match:
            counter, episode_title, sxex, show, action = match.groups()
            suffix = (' - ' + action.upper()) if action else ''
            fixed = counter + '  - ' + sxex.upper() + ' - ' + show.upper() + suffix
            budget = target - len(fixed)
            if budget > 0:
                result = counter + ' ' + self._word_ellipsis(episode_title, budget) + ' - ' + sxex.upper() + ' - ' + show.upper() + suffix
                if len(result) <= target:
                    return result.rstrip()
            show_budget = target - len(counter + ' ' + sxex.upper() + ' - ' + suffix)
            return (counter + ' ' + sxex.upper() + ' - ' + self._word_ellipsis(show, show_budget) + suffix).rstrip()
        return self._word_ellipsis(line, target).rstrip()

    def item_status(self, action, mediaitem, arttypes=(), stage=0.0):
        total = float(self.current_item_total or 1)
        percent = int(((self.current_item_index + max(0.0, min(0.99, stage))) * 100) / total)
        final_action = ''
        action_text = str(action or '').upper()
        if action_text in ('HANDOFF', 'MIGRATED'):
            final_action = 'MIGRATED'
        elif action_text in ('DOWNLOADING', 'CACHING'):
            final_action = 'CACHING'
        line = '{0}/{1} {2}{3}'.format(
            self.current_item_index + 1, self.current_item_total or 1,
            self._display_title(mediaitem),
            (' - ' + final_action) if final_action else '',
        )
        line = self._fit_line(line, 58)
        runtrace.item_status(action, mediaitem, arttypes, stage=stage, percent=percent)
        self.update_progress(percent, line, 'Library Artwork Curator')

    def finalupdate(self, header, message):
        text = str(message or header or '')
        if header and message:
            text = '{0} - {1}'.format(header, message)
        if settings.final_notification:
            _family_notify_03252(text, xbmcgui.NOTIFICATION_INFO, 8000)
        elif self.visible:
            self.update_progress(100, self._fit_line(text, maxlen=58), 'Library Artwork Curator')

    def close_progress(self):
        if self.visible:
            self.progress.close()
            self.progress = None
            self.progress_foreground = False
            self.visible = False

    def notify_warning(self, message, header=None, error=False):
        if settings.progressdisplay != PROGRESS_DISPLAY_NONE:
            prefix = str(header or 'WARNING').upper().strip()
            _family_notify_03252('{0} - {1}'.format(prefix, message),
                xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_WARNING, 7000)

    def set_idle_inhibition(self, enabled):
        """Keep long artwork jobs from launching a screensaver or idle shutdown."""
        enabled = bool(enabled)
        if self.idle_inhibited == enabled:
            return
        state = 'true' if enabled else 'false'
        try:
            pykodi.execute_builtin('InhibitScreensaver({0})'.format(state))
            pykodi.execute_builtin('InhibitIdleShutdown({0})'.format(state))
            self.idle_inhibited = enabled
            log('Idle inhibition {0}'.format('enabled' if enabled else 'disabled'), xbmc.LOGINFO)
        except Exception:
            log('Could not change Kodi idle inhibition state', xbmc.LOGWARNING)
            log(traceback.format_exc(), xbmc.LOGWARNING)

    def init_run(self, show_progress=False, chunkcount=1, foreground=False, force_progress=False):
        runtrace.event('processor', 'init_run', show_progress=show_progress, chunkcount=chunkcount, foreground=foreground, force_progress=force_progress)
        self.set_idle_inhibition(True)
        self.setlanguages()
        self.gatherer = Gatherer(self.monitor, self.autolanguages)
        self.downloader = FileManager(self.debug, True)
        self.chunkcount = chunkcount
        self.currentchunk = 0
        self.cancelled = False
        self.item_error_count = 0
        self._last_process_aborted = False
        self.last_summary = {}
        if show_progress:
            self.create_progress(foreground, force_progress)

    def set_debug(self, debug):
        if self.downloader:
            self.downloader.debug = debug
        reporting.debug = debug
        self.debug = debug

    def finish_run(self):
        runtrace.event('processor', 'finish_run')
        try:
            info.clear_cache()
            self.downloader = None
            self.set_debug(False)
            self.close_progress()
        finally:
            self.set_idle_inhibition(False)

    @property
    def processor_busy(self):
        # Only a real processing worker is busy. A stale/signalled auto queue
        # must not block manual context actions or make the main menu show
        # Stop current process.
        return pykodi.get_conditional('String.IsEqual(Window(Home).Property(ArtworkCurator.Status),processing)')

    @property
    def processor_signalled(self):
        return pykodi.get_conditional('String.IsEqual(Window(Home).Property(ArtworkCurator.Status),signalled)')

    def _clear_signalled_auto_queue(self):
        if not self.processor_signalled:
            return
        runtrace.event('context', 'clearing signalled auto queue before manual context action')
        try:
            pykodi.execute_builtin('NotifyAll(script.artwork.curator:control, CancelCurrent)')
            xbmc.sleep(150)
        except Exception as ex:
            runtrace.error('failed to clear signalled auto queue', ex)
        # The service should clear the Home property. If the service is still
        # restarting, unblock the manual action locally as well.
        try:
            pykodi.execute_builtin('SetProperty(ArtworkCurator.Status, idle, Home)')
            pykodi.execute_builtin('SetProperty(LibraryArtworkCurator.Status, idle, Home)')
            pykodi.execute_builtin('SetProperty(script.artwork.curator.Status, idle, Home)')
        except Exception:
            pass

    def process_item(self, mediatype, dbid, mode):
        if mediatype not in mediatypes.artinfo:
            _family_notify_03252(L(NOT_SUPPORTED_MESSAGE).format(mediatype), '-', 6500)
            return
        if self.processor_busy:
            runtrace.event('context', 'manual context blocked by active processing worker', mediatype=mediatype, dbid=dbid, mode=mode)
            _family_notify_03252('ARTWORK PROCESS IS RUNNING - TRY AGAIN AFTER IT FINISHES', xbmcgui.NOTIFICATION_WARNING, 6500)
            return
        if mode in (MODE_GUI, MODE_DRYRUN, MODE_AUTO, MODE_REFRESHITEM):
            self._clear_signalled_auto_queue()
        self.init_run()
        if mode == MODE_DEBUG:
            self.set_debug(True)
            mode = MODE_AUTO
        busy = None
        if mode in (MODE_GUI, MODE_DRYRUN):
            busy = pykodi.get_busydialog()
            busy.create()
        try:
            mediaitem = info.MediaItem(quickjson.get_item_details(dbid, mediatype))
            info.add_additional_iteminfo(mediaitem, self.processed, search)
            if mediatype in mediatypes.require_manualid and not mediaitem.uniqueids and mode == MODE_GUI:
                self.manual_id(mediaitem)
                info.add_additional_iteminfo(mediaitem, self.processed, search)
            if mode == MODE_GUI:
                self._manual_item_process(mediaitem, busy)
            elif mode == MODE_DRYRUN:
                self._dry_run_item(mediaitem, busy)
            elif mode == MODE_REFRESHITEM:
                # Context action: rebuild all managed artwork for only the current
                # library item. This uses the same refresh-all selection rules but
                # keeps manual/protected artwork safe. Re-initialise the run with
                # visible progress because context actions should give immediate
                # feedback for a single item.
                self.finish_run()
                self.process_medialist([mediaitem], True, already_initialized=False, foreground=True, force_progress=True, refresh_all=True)
            else:
                self.process_medialist([mediaitem], True, already_initialized=True)
        finally:
            if busy:
                try:
                    busy.close()
                except Exception:
                    pass
            if mode in (MODE_GUI, MODE_DRYRUN):
                self.finish_run()
                if mode == MODE_GUI:
                    self._finish_reload_skin_03370(aborted=False)

    def _manual_item_process(self, mediaitem, busy):
        availableart = self._prepare_manual_selection_art(mediaitem, busy)
        if busy:
            busy.close()
        if not availableart:
            _family_notify_03252('NO ARTWORK AVAILABLE', xbmcgui.NOTIFICATION_WARNING, 7000)
            return
        arttype, selected = prompt_for_artwork(mediaitem.mediatype, mediaitem.label, availableart, self.monitor)
        if arttype == '!!-Refresh' and mediaitem.mediatype == mediatypes.MOVIESET:
            self.processed.set_data(mediaitem.dbid, mediaitem.mediatype, mediaitem.label, None)
            if self.manual_id(mediaitem):
                mediaitem.uniqueids = {}
                info.add_additional_iteminfo(mediaitem, self.processed, search)
                if busy:
                    busy.create()
                self._manual_item_process(mediaitem, busy)
            return
        if not arttype or selected is None:
            return
        if mediatypes.get_artinfo(mediaitem.mediatype, arttype)['multiselect']:
            changed = info.fill_multiart(mediaitem.art, arttype, selected)
            toset = get_simpledict_updates(mediaitem.art, changed)
        else:
            toset = {arttype: selected}
        if toset:
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, toset)
            mediaitem.art.update(toset)
            mediaitem.updatedart = list(toset)
            self._record_manual_selection(mediaitem, toset)
            self.cache_remote(mediaitem, toset)
            self.mark_reload_skin_art_03370(mediaitem.mediatype, toset)
            reporting.report_item(mediaitem, True, True, self.downloader.size)
            notifycount(len([url for url in toset.values() if url]))

    def _manual_select_targets(self, mediaitem):
        targets = []

        def add_target(exacttype):
            if exacttype == 'icon' or exacttype in targets:
                return
            targets.append(exacttype)

        for arttype, artcfg in mediatypes.artinfo[mediaitem.mediatype].items():
            if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                continue
            add_target(arttype)

        if mediaitem.mediatype == mediatypes.TVSHOW and self._tvshow_should_manage_season_art():
            for season in mediaitem.seasons:
                for arttype, artcfg in mediatypes.artinfo[mediatypes.SEASON].items():
                    if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                        continue
                    add_target('{0}.{1}.{2}'.format(mediatypes.SEASON, season, arttype))

        for arttype in mediatypes.othertypes[mediaitem.mediatype]:
            if arttype != 'icon' and arttype not in mediaitem.skip_artwork:
                add_target(arttype)
        return targets

    def _current_art_provider_label(self, url):
        label = L(CURRENT_ART)
        try:
            source = artworkdb.infer_source(url)
        except Exception:
            source = ''
        if source and source not in ('Existing', 'Remote'):
            label = '{0} ({1})'.format(label, source)
        return label

    def _current_art_entries_for_manual_select(self, mediaitem, targets):
        allowed = set(targets or [])
        allowed_bases = set(info.get_basetype(target) for target in allowed)
        entries = {}
        for exacttype in sorted((mediaitem.art or {}), key=natural_sort):
            url = mediaitem.art.get(exacttype)
            if not url or exacttype == 'icon' or artworkdb.is_default_icon_url(url):
                continue
            base = info.get_basetype(exacttype)
            if exacttype in allowed:
                target = exacttype
            elif base in allowed_bases:
                target = base
            else:
                continue
            entries.setdefault(target, []).append({
                'url': url,
                'preview': url,
                'title': exacttype,
                'existing': True,
                'manual_current': True,
                'provider': SortedDisplay('current', self._current_art_provider_label(url)),
                'rating': SortedDisplay(10, ''),
                'size': SortedDisplay(10000, ''),
                'language': None,
                'gallery_order': -1000,
            })
        return entries

    def _merge_current_and_provider_art(self, mediaitem, targets):
        current_entries = self._current_art_entries_for_manual_select(mediaitem, targets)
        allowed = set(targets or [])
        allowed_bases = set(info.get_basetype(target) for target in allowed)
        result = {}

        def merge_for_key(key, provider_list):
            # Keep provider order exactly as sorted by the auto-selection path.
            # Current URLs are only marked as selected at their natural provider
            # position; they are not pinned/prepended to the top of the dialog.
            current_list = list(current_entries.get(key, []) or [])
            current_by_url = {}
            for current in current_list:
                url = current.get('url')
                if url and url not in current_by_url:
                    current_by_url[url] = current

            merged = []
            seen = set()
            for image in list(provider_list or []):
                url = image.get('url')
                if not url or url in seen:
                    continue
                if url in current_by_url:
                    marked = dict(image)
                    marked['existing'] = True
                    marked['manual_current'] = current_by_url[url].get('manual_current', True)
                    marked['current_title'] = current_by_url[url].get('title')
                    merged.append(marked)
                else:
                    merged.append(image)
                seen.add(url)

            # If a current URL no longer exists in the provider candidate list,
            # show it after provider candidates as a Current-only fallback.
            for current in current_list:
                url = current.get('url')
                if url and url not in seen:
                    merged.append(current)
                    seen.add(url)
            return merged

        for target in targets:
            merged = merge_for_key(target, (mediaitem.availableart or {}).get(target, []))
            if merged:
                result[target] = merged

        # Keep any exact provider art that maps to an allowed base, but never expose icon.
        for key, artlist in (mediaitem.availableart or {}).items():
            if key == 'icon' or key in result:
                continue
            base = info.get_basetype(key)
            if key not in allowed and base not in allowed_bases:
                continue
            merged = merge_for_key(key, artlist)
            if merged:
                result[key] = merged
        return result

    def _manual_filter_minimum_resolution(self, target):
        base = info.get_basetype(target)
        if base.endswith('poster'):
            return (0, max(1080, int(getattr(settings, 'minimum_poster_height', 1000) or 1000)))
        if base.endswith('fanart') or base.endswith('landscape'):
            return (1920, 1080)
        if base.endswith('thumb'):
            return (1280, 720)
        return (0, 0)

    def _manual_candidate_is_high_quality(self, target, image):
        if image.get('existing') or image.get('manual_current'):
            return True
        min_width, min_height = self._manual_filter_minimum_resolution(target)
        if not min_width and not min_height:
            return True
        width, height = self._candidate_dimensions(image)
        if min_width and min_height:
            return width >= min_width and height >= min_height
        if min_height:
            try:
                sort_height = int(getattr(image.get('size'), 'sort', 0) or 0)
            except (TypeError, ValueError):
                sort_height = 0
            return sort_height >= min_height or height >= min_height
        return True

    def _manual_candidate_preferred_language(self, image):
        if image.get('existing') or image.get('manual_current'):
            return True
        return image.get('language') in self.current_languages

    def _manual_provider_key(self, image):
        provider = image.get('provider') if image else None
        key = getattr(provider, 'sort', None) or getattr(provider, 'display', None) or provider or ''
        return str(key)

    def _preserve_manual_provider_visibility(self, original, kept, max_per_provider=3):
        """Keep Select artwork compact without making providers vanish.

        Compact filtering may legitimately hide low-resolution or non-preferred
        language candidates, but the manual picker is also used for choosing a
        source. If TMDb/fanart.tv/TheTVDB had candidates before the compact
        filter, keep the first few from that provider even when they are below
        the compact threshold. Current/manual entries are handled separately.
        """
        result = list(kept or [])
        seen_urls = set(image.get('url') for image in result if image.get('url'))
        visible_providers = set(self._manual_provider_key(image) for image in result
            if not (image.get('existing') or image.get('manual_current')))
        original_providers = []
        by_provider = {}
        for image in original or []:
            if image.get('existing') or image.get('manual_current'):
                continue
            provider_key = self._manual_provider_key(image)
            if not provider_key:
                continue
            if provider_key not in by_provider:
                by_provider[provider_key] = []
                original_providers.append(provider_key)
            by_provider[provider_key].append(image)
        for provider_key in original_providers:
            if provider_key in visible_providers:
                continue
            added = 0
            for image in by_provider.get(provider_key, ()):  # keep provider order
                url = image.get('url')
                if not url or url in seen_urls:
                    continue
                result.append(image)
                seen_urls.add(url)
                added += 1
                if added >= max_per_provider:
                    break
        return result

    def _filter_manual_selection_candidates(self, mediaitem, availableart):
        if not getattr(settings, 'select_compact_candidates', True):
            return availableart
        threshold = max(1, int(getattr(settings, 'select_candidate_filter_threshold', 12) or 12))
        filtered = {}
        for target, artlist in (availableart or {}).items():
            items = list(artlist or [])
            if not items:
                continue
            kept = items
            if getattr(settings, 'select_hide_lowres_when_enough_hd', True):
                high_quality = [image for image in kept if self._manual_candidate_is_high_quality(target, image)]
                provider_high_quality = [image for image in high_quality if not (image.get('existing') or image.get('manual_current'))]
                if len(provider_high_quality) >= threshold:
                    kept = high_quality
            if getattr(settings, 'select_hide_other_languages_when_enough_preferred', True):
                preferred = [image for image in kept if self._manual_candidate_preferred_language(image)]
                provider_preferred = [image for image in preferred if not (image.get('existing') or image.get('manual_current'))]
                if len(provider_preferred) >= threshold:
                    kept = preferred
            kept = self._preserve_manual_provider_visibility(items, kept)
            if kept:
                filtered[target] = kept
            before_provider_count = len(set(self._manual_provider_key(image) for image in items if not (image.get('existing') or image.get('manual_current')) and self._manual_provider_key(image)))
            after_provider_count = len(set(self._manual_provider_key(image) for image in kept if not (image.get('existing') or image.get('manual_current')) and self._manual_provider_key(image)))
            runtrace.event('context_gui', 'manual candidate compact filter', mediatype=getattr(mediaitem, 'mediatype', ''),
                           dbid=getattr(mediaitem, 'dbid', ''), art_type=target, before=len(items), after=len(kept),
                           providers_before=before_provider_count, providers_after=after_provider_count, threshold=threshold)
        return filtered

    def _prepare_manual_selection_art(self, mediaitem, busy=None):
        previous_refresh = self.refresh_all_artwork
        self.refresh_all_artwork = True
        try:
            if mediaitem.missingid:
                runtrace.event('context_gui', 'item missing provider id', mediatype=mediaitem.mediatype, dbid=mediaitem.dbid, label=mediaitem.label)
            targets = self._manual_select_targets(mediaitem)
            self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
            self.gatherer.set_languages(self.current_languages)
            if busy:
                try:
                    busy.update(25, 'Fetching artwork providers')
                except Exception:
                    pass
            services_hit, error = self.gatherer.getartwork(mediaitem, skipexisting=False)
            if error:
                mediaitem.error = '{0}: {1}'.format(error.get('providername'), error.get('message'))
            availableart = self._merge_current_and_provider_art(mediaitem, targets)
            before_counts = dict((key, len(value or [])) for key, value in availableart.items())
            availableart = self._filter_manual_selection_candidates(mediaitem, availableart)
            runtrace.event('context_gui', 'manual selection candidates ready', mediatype=mediaitem.mediatype, dbid=mediaitem.dbid,
                           targets=len(targets), art_types=len(availableart), services_hit=services_hit,
                           counts=dict((key, len(value or [])) for key, value in availableart.items()), before_counts=before_counts)
            return availableart
        except Exception as ex:
            runtrace.error('manual selection candidate fetch failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''))
            return self._merge_current_and_provider_art(mediaitem, self._manual_select_targets(mediaitem))
        finally:
            self.refresh_all_artwork = previous_refresh

    def _record_manual_selection(self, mediaitem, toset):
        for art_type, url in (toset or {}).items():
            try:
                if art_type == 'icon' or artworkdb.is_default_icon_url(url):
                    continue
                if url:
                    artworkdb.set_artwork_item(mediaitem, art_type, url, artworkdb.infer_source(url), 'MANUAL', 'Selected from context menu')
                else:
                    artworkdb.set_artwork_item(mediaitem, art_type, '', '', 'MISSING', 'Removed from context menu')
            except Exception as ex:
                runtrace.error('manual selection DB record failed', ex, art_type=art_type)

    def process_medialist(self, medialist, alwaysnotify=False, already_initialized=False, foreground=False, force_progress=False, refresh_indonesian=False, refresh_all=False, suppress_final=False):
        timer = __import__('time').time()
        runtrace.event('processor', 'process_medialist start', total=len(medialist or []), alwaysnotify=alwaysnotify, already_initialized=already_initialized, refresh_indonesian=refresh_indonesian, refresh_all=refresh_all, suppress_final=suppress_final)
        previous_refresh = self.refresh_indonesian
        previous_refresh_all = self.refresh_all_artwork
        self.refresh_indonesian = bool(refresh_indonesian)
        self.refresh_all_artwork = bool(refresh_all)
        self.item_error_count = 0
        self.last_summary = {}
        self.db_run_id = artworkdb.begin_run(
            'refresh_indonesian' if refresh_indonesian else ('refresh_all' if refresh_all else 'scrape_missing'),
            total_items=len(medialist or []),
            notes='force_progress={0};foreground={1};refresh_all={2}'.format(force_progress, foreground, refresh_all)
        )
        if not already_initialized:
            self.init_run(True, 1, foreground, force_progress)
        elif self.gatherer is None:
            self.init_run(True, 1, foreground, force_progress)
        try:
            reporting.report_start(medialist)
            aborted, updateditems, artcount = self._process_chunk(medialist)
            reporting.set_active_error_count(self.item_error_count)
            reporting.report_end(medialist, updateditems if aborted else 0, self.downloader.size)
            action_label = 'REFRESH ARTWORK' if refresh_all else ('REFRESH INDONESIAN ARTWORK' if refresh_indonesian else 'FILL MISSING ARTWORK')
            status_label = 'ABORTED' if aborted else 'FINISHED'
            if not suppress_final:
                self.finalupdate(None, '{0} {1} - {2} ITEMS - {3} ARTWORK - {4} ERRORS'.format(
                    action_label, status_label, len(medialist or []), artcount, getattr(self, 'item_error_count', 0)))
            runtrace.event('processor', 'process_medialist end', aborted=aborted, updateditems=updateditems, artcount=artcount, elapsed_ms=int((__import__('time').time() - timer) * 1000))
            return not aborted
        finally:
            elapsed_ms = int((__import__('time').time() - timer) * 1000)
            try:
                aborted_state = bool(locals().get('aborted', False) or self.cancelled or getattr(self, '_last_process_aborted', False))
                self.last_summary = {
                    'total': len(medialist or []),
                    'updated_items': locals().get('updateditems', 0),
                    'updated_artwork': locals().get('artcount', 0),
                    'errors': getattr(self, 'item_error_count', 0),
                    'elapsed_ms': elapsed_ms,
                    'status': 'aborted' if aborted_state else 'finished',
                    'action': 'refresh_all' if refresh_all else ('refresh_indonesian' if refresh_indonesian else 'fill_missing'),
                }
                artworkdb.finish_run(
                    self.db_run_id,
                    status='aborted' if aborted_state else 'finished',
                    updated_items=locals().get('updateditems', 0),
                    updated_artwork=locals().get('artcount', 0),
                    errors=getattr(self, 'item_error_count', 0),
                    elapsed_ms=elapsed_ms
                )
            except Exception as db_ex:
                runtrace.error('artwork-cache.db finish_run failed', db_ex)
            artworkdb.cleanup_retention()
            runtrace.perf('processor.process_medialist', elapsed_ms, total=len(medialist or []), refresh_indonesian=refresh_indonesian)
            self.refresh_indonesian = previous_refresh
            self.refresh_all_artwork = previous_refresh_all
            self.db_run_id = None
            self.finish_run()
            self._finish_reload_skin_03370(aborted=aborted_state)

    def process_chunkedlist(self, chunkedlist, chunkcount, alwaysnotify=False):
        self.init_run(True, chunkcount)
        aborted, total = False, 0
        try:
            for index, medialist in enumerate(chunkedlist):
                self.currentchunk = index
                if self.monitor.abortRequested() or medialist is False:
                    aborted = True
                    break
                reporting.report_start(medialist)
                errors_before = self.item_error_count
                this_aborted, updateditems, artcount = self._process_chunk(medialist)
                total += artcount
                reporting.set_active_error_count(self.item_error_count - errors_before)
                reporting.report_end(medialist, updateditems if this_aborted else 0, self.downloader.size)
                self.downloader.size = 0
                if this_aborted:
                    aborted = True
                    break
            if total or alwaysnotify:
                self.finalupdate(*finalmessages(total))
            return not aborted
        finally:
            self.finish_run()
            self._finish_reload_skin_03370(aborted=aborted)

    def _ensure_db_first_local_details(self, mediaitem):
        """Populate only local Kodi details needed for DB-first planning.

        This intentionally avoids provider lookup. In particular it must not search
        TMDb collection IDs for movie sets that already have final DB rows.
        """
        try:
            if mediaitem.mediatype == mediatypes.TVSHOW and not mediaitem.seasons:
                seasons, seasonart = info._get_seasons_artwork(quickjson.get_seasons(mediaitem.dbid))
                mediaitem.seasons = seasons
                mediaitem.art.update(seasonart)
            if mediaitem.mediatype == mediatypes.TVSHOW:
                self._mirror_existing_tvshow_season_art(mediaitem)
        except Exception as ex:
            runtrace.error('DB-first local detail preload failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''))

    def _mirror_existing_tvshow_season_art(self, mediaitem):
        if mediaitem.mediatype != mediatypes.TVSHOW:
            return
        for art_type, url in sorted((mediaitem.art or {}).items(), key=lambda pair: natural_sort(pair[0])):
            if url and str(art_type).startswith('season.'):
                self._mirror_season_art_db(mediaitem, art_type, url, 'OK', 'Mirrored from existing Kodi season artwork')

    def _db_first_preflight(self, mediaitem):
        """Validate current identity and local paths/art, then plan DB-first."""
        if mediaitem.mediatype == mediatypes.EPISODE:
            resolved_file = quickjson.get_episode_file_from_database(mediaitem.dbid)
            if resolved_file:
                mediaitem.file = resolved_file
        validation = artworkdb.validate_db_first_identity(mediaitem)
        if validation.get('changed'):
            setattr(mediaitem, 'db_identity_validation', validation)
            runtrace.event('artworkdb', 'DB-first cache reopened after identity change',
                           mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''),
                           title=artworkdb.title_for_item(mediaitem), validation=validation)
        if self.refresh_all_artwork or self.refresh_indonesian:
            return None
        self._ensure_db_first_local_details(mediaitem)
        # Clean malformed image://video@folder values before the DB-first skip.
        cleaned = cleaner.clean_artwork(mediaitem)
        cleanchanges = get_simpledict_updates(mediaitem.art, cleaned)
        if cleanchanges:
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, cleanchanges)
            mediaitem.art.update(cleanchanges)
            for art_type, value in cleanchanges.items():
                if value is None:
                    artworkdb.mark_art_status_item(mediaitem, art_type, 'MISSING', 'Invalid local/generated artwork cleared')
        return self._db_first_plan(mediaitem)

    def _finish_db_first_skip(self, mediaitem, item_timer, db_apply):
        """Apply final DB artwork to Kodi if needed, then record a skipped/applied item."""
        updated = []
        if db_apply:
            self.item_status('Applying', mediaitem, db_apply.keys(), 0.20)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, db_apply)
            mediaitem.art.update(db_apply)
            updated = list(db_apply)
        mediaitem.updatedart = updated
        reporting.report_item(mediaitem)
        elapsed_item_ms = int((__import__('time').time() - item_timer) * 1000)
        status = 'applied' if updated else 'skipped'
        artworkdb.record_item(mediaitem, self.db_run_id, status=status, updatedart=updated, elapsed_ms=elapsed_item_ms)
        runtrace.item_result(mediaitem, elapsed_item_ms, updatedart=updated, services_hit=False, db_first='final_skip')

    def _process_chunk(self, medialist):
        updateditems, artcount = 0, 0
        total = len(medialist)
        for index, mediaitem in enumerate(medialist):
            item_timer = __import__('time').time()
            services_hit = None
            if self.monitor.abortRequested() or self.cancelled:
                return True, updateditems, artcount
            self.current_item_index = index
            self.current_item_total = total or 1
            self.item_status('Checking', mediaitem, (), 0.00)
            if is_excluded(mediaitem):
                self.item_status('Skipping', mediaitem, (), 0.98)
                runtrace.item_result(mediaitem, int((__import__('time').time() - item_timer) * 1000), updatedart=[], error_text='excluded')
                continue
            try:
                self.item_status('Reading', mediaitem, (), 0.08)
                preflight = self._db_first_preflight(mediaitem)
                if preflight is not None:
                    db_apply, db_missing_exact, db_search_targets, db_existing_for_selection = preflight
                    if not db_search_targets:
                        self._finish_db_first_skip(mediaitem, item_timer, db_apply)
                        if db_apply:
                            updateditems += 1
                            artcount += len(db_apply)
                            self.mark_reload_skin_art_03370(mediaitem.mediatype, db_apply)
                        continue
                info.add_additional_iteminfo(mediaitem, self.processed, search)
                if mediaitem.mediatype == mediatypes.TVSHOW:
                    self._mirror_existing_tvshow_season_art(mediaitem)
                services_hit = self._process_item(mediaitem, skipexisting=not self.refresh_all_artwork, refresh_existing=self.refresh_all_artwork)

                # Record successful scans so automatic "new videos" processing stays incremental.
                self.processed.set_nextdate(
                    mediaitem.dbid, mediaitem.mediatype, mediaitem.label,
                    datetime_now() + timedelta(days=plus_some(224, 32)))
                if mediaitem.mediatype == mediatypes.TVSHOW:
                    self.processed.set_data(
                        mediaitem.dbid, mediaitem.mediatype, mediaitem.label, mediaitem.season)
                if mediaitem.updatedart:
                    updateditems += 1
                    artcount += len(mediaitem.updatedart)
                    self.mark_reload_skin_art_03370(mediaitem.mediatype, dict((key, (mediaitem.art or {}).get(key)) for key in mediaitem.updatedart))
                reporting.report_item(mediaitem)
                elapsed_item_ms = int((__import__('time').time() - item_timer) * 1000)
                artworkdb.record_item(mediaitem, self.db_run_id, status='processed', updatedart=mediaitem.updatedart, elapsed_ms=elapsed_item_ms)
                runtrace.item_result(mediaitem, elapsed_item_ms, updatedart=mediaitem.updatedart, services_hit=services_hit)
            except Exception as ex:
                # A broken provider response or malformed library item must not stop
                # the full-library run. Keep going and write the traceback to kodi.log.
                mediaitem.error = '{0}: {1}'.format(type(ex).__name__, ex)
                self.item_error_count += 1
                self.item_status('Error', mediaitem, (), 0.98)
                log('Recovered item error: {0} [{1}:{2}]'.format(
                    mediaitem.label, mediaitem.mediatype, mediaitem.dbid), xbmc.LOGERROR)
                log(traceback.format_exc(), xbmc.LOGERROR)
                elapsed_item_ms = int((__import__('time').time() - item_timer) * 1000)
                artworkdb.record_item(mediaitem, self.db_run_id, status='error', updatedart=getattr(mediaitem, 'updatedart', []), elapsed_ms=elapsed_item_ms, error=mediaitem.error)
                runtrace.item_result(mediaitem, elapsed_item_ms, updatedart=getattr(mediaitem, 'updatedart', []), error_text=mediaitem.error, services_hit=services_hit)
                try:
                    reporting.report_item(mediaitem, forcedreport=True)
                except Exception as report_ex:
                    runtrace.error('Could not write recovered item error to report', report_ex, mediatype=mediaitem.mediatype, dbid=mediaitem.dbid)
                    log('Could not write recovered item error to report', xbmc.LOGWARNING)
                    log(traceback.format_exc(), xbmc.LOGWARNING)
            xbmc.sleep(int(THROTTLE_TIME * 1000))
        return False, updateditems, artcount


    def _tvshow_should_manage_season_art(self):
        """TV show pass only manages season.* art when season scope is disabled.

        When Include seasons is ON, direct season items are processed later in the
        normal refresh order. That direct season pass has the full TMDb ->
        fanart.tv -> TheTVDB selection path and should decide final season art.
        This avoids confusing TV-show-level season fallback choices overriding or
        duplicating direct season choices.
        """
        try:
            return not mediatypes.scope_enabled(mediatypes.SEASON)
        except Exception:
            return False

    def _enabled_db_arttypes(self, mediaitem):
        result = []
        for arttype, artcfg in mediatypes.artinfo[mediaitem.mediatype].items():
            if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                continue
            if artcfg['multiselect']:
                for index in range(int(artcfg['autolimit'] or 0)):
                    exact = info.format_arttype(arttype, index)
                    if exact not in result:
                        result.append(exact)
            elif arttype not in result:
                result.append(arttype)
        if mediaitem.mediatype == mediatypes.TVSHOW and self._tvshow_should_manage_season_art():
            for season in mediaitem.seasons:
                for arttype, artcfg in mediatypes.artinfo[mediatypes.SEASON].items():
                    if not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                        continue
                    exact = 'season.{0}.{1}'.format(season, arttype)
                    if exact not in result:
                        result.append(exact)
        for arttype in mediatypes.othertypes[mediaitem.mediatype]:
            if arttype not in mediaitem.skip_artwork and arttype not in result:
                result.append(arttype)
        return result

    def _db_first_plan(self, mediaitem):
        rows = artworkdb.get_artwork_rows(mediaitem)
        apply_from_db, missing_exact, search_targets = {}, [], []
        if mediaitem.protected_custom_set:
            for exact in self._enabled_db_arttypes(mediaitem):
                row = rows.get(exact)
                if artworkdb.should_search_row(row):
                    artworkdb.mark_art_status_item(mediaitem, exact, 'PROTECTED', 'Protected custom collection')
            return {}, [], [], dict(mediaitem.art)

        def supported_exact(exact):
            match = re.match(r'^season\.(-?\d+)\.', str(exact or ''))
            if mediaitem.mediatype != mediatypes.TVSHOW or not match:
                return True
            season_number = int(match.group(1))
            return season_number >= 0 and season_number in (mediaitem.seasons or {})
        for art_type, url in artworkdb.artwork_to_apply(mediaitem).items():
            if not supported_exact(art_type):
                artworkdb.mark_art_status_item(mediaitem, art_type, 'N/A', 'Kodi library has no matching season')
                continue
            if url and mediaitem.art.get(art_type) != url:
                apply_from_db[art_type] = url
        for exact in self._enabled_db_arttypes(mediaitem):
            if not supported_exact(exact):
                artworkdb.mark_art_status_item(mediaitem, exact, 'N/A', 'Kodi library has no matching season')
                continue
            row = rows.get(exact)
            if artworkdb.should_search_row(row):
                missing_exact.append(exact)
                itemtype, artkey = mediatypes.hack_mediaarttype(mediaitem.mediatype, exact)
                cfg = mediatypes.get_artinfo(itemtype, artkey)
                target = artkey if cfg.get('multiselect') else exact
                if target not in search_targets:
                    search_targets.append(target)
        existing_for_selection = dict(mediaitem.art)
        for exact in missing_exact:
            existing_for_selection[exact] = None
        return apply_from_db, missing_exact, search_targets, existing_for_selection

    def _process_item(self, mediaitem, skipexisting=True, refresh_existing=False):
        existing_before = [arttype for arttype, url in mediaitem.art.items() if url]
        self.item_status('Checking', mediaitem, existing_before, 0.12)

        cleaned = cleaner.clean_artwork(mediaitem)
        cleanchanges = get_simpledict_updates(mediaitem.art, cleaned)
        if cleanchanges:
            self.item_status('Cleaning', mediaitem, cleanchanges.keys(), 0.18)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, cleanchanges)
            mediaitem.art.update(cleanchanges)

        db_apply, db_missing_exact, db_search_targets, db_existing_for_selection = self._db_first_plan(mediaitem)
        if db_apply and not refresh_existing:
            self.item_status('Applying', mediaitem, db_apply.keys(), 0.20)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, db_apply)
            mediaitem.art.update(db_apply)
            cleanchanges.update(db_apply)

        # DB-first: Fill Missing follows artwork-cache.db status, not Kodi's current art table.
        mediaitem.missingart = list(db_search_targets if not refresh_existing and not self.refresh_indonesian else info.iter_missing_arttypes(mediaitem, mediaitem.art))
        mediaitem.db_missingart_exact = list(db_missing_exact)
        mediaitem.db_existing_for_selection = dict(db_existing_for_selection)

        # A completed TMDb collection-name search with no exact collection ID is
        # definitive for this library identity. Close enabled artwork slots as N/A
        # so the same movie set is not searched on every Fill Missing run.
        if (mediaitem.mediatype == mediatypes.MOVIESET and mediaitem.error
                and not mediaitem.uniqueids.get('tmdb')):
            self.item_status('Missing', mediaitem, mediaitem.missingart, 0.88)
            self._mark_missing_na(mediaitem, mediaitem.missingart, {})
            mediaitem.updatedart = list(cleanchanges)
            self.item_status('Done', mediaitem, (), 0.98)
            return False
        mediaitem.missingid = not bool(mediaitem.uniqueids)
        if mediaitem.missingid:
            self.item_status('Skipping', mediaitem, mediaitem.missingart, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False
        if mediaitem.protected_custom_set:
            for art_type in (getattr(mediaitem, 'db_missingart_exact', None) or mediaitem.missingart or ()):
                artworkdb.mark_art_status_item(mediaitem, art_type, 'PROTECTED', 'Protected custom collection')
            self.item_status('Skipping', mediaitem, (), 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False
        if refresh_existing:
            return self._process_refresh_all_item(mediaitem, cleanchanges, existing_before)
        if self.refresh_indonesian and mediaitem.indonesia_hint:
            return self._process_indonesian_refresh(mediaitem, cleanchanges, existing_before)
        if not mediaitem.missingart:
            self.item_status('Skipping', mediaitem, existing_before, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False

        self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
        self.gatherer.set_languages(self.current_languages)
        self.item_status('Searching', mediaitem, mediaitem.missingart, 0.30)
        services_hit, error = self._gather_artwork_lazy(mediaitem, mediaitem.missingart, getattr(mediaitem, 'db_existing_for_selection', mediaitem.art), skipexisting=skipexisting)
        if error:
            mediaitem.error = '{0}: {1}'.format(error['providername'], error['message'])
            if self._skip_item_on_primary_provider_error(mediaitem, error, 0.98):
                mediaitem.updatedart = list(cleanchanges)
                return services_hit
        self.item_status('Selecting', mediaitem, mediaitem.missingart, 0.60)
        selected = self.get_top_missing_art(mediaitem.missingart,
            mediaitem.mediatype, getattr(mediaitem, 'db_existing_for_selection', mediaitem.art), mediaitem.availableart, mediaitem=mediaitem)
        if selected:
            self.item_status('Adding', mediaitem, selected.keys(), 0.72)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, selected)
            mediaitem.art.update(selected)
        else:
            self.item_status('Missing', mediaitem, mediaitem.missingart, 0.88)
        self._mark_missing_na(mediaitem, mediaitem.missingart, selected)
        combined = dict(cleanchanges)
        combined.update(selected)
        mediaitem.updatedart = list(combined)
        self.cache_remote(mediaitem, selected)
        self.item_status('Done', mediaitem, combined.keys(), 0.98)
        return services_hit

    def _is_curator_managed_url(self, url):
        lower = (url or '').lower()
        return lower.startswith(('http://', 'https://')) and any(marker in lower for marker in CURATOR_REMOTE_HOST_MARKERS)

    def _existing_artwork_is_manual(self, url):
        return bool(url) and not self._is_curator_managed_url(url) and not url.startswith('image://')

    def _iter_refresh_targets(self, mediaitem):
        targets = []
        try:
            manual_rows = artworkdb.get_artwork_rows(mediaitem)
        except Exception:
            manual_rows = {}

        def is_db_manual(exacttype):
            row = manual_rows.get(exacttype)
            if row and (row.get('status') or '').upper() in ('MANUAL', 'PROTECTED'):
                return True
            base = info.get_basetype(exacttype)
            for key, value in (manual_rows or {}).items():
                if info.arttype_matches_base(key, base) and (value.get('status') or '').upper() in ('MANUAL', 'PROTECTED'):
                    return True
            return False

        def add_target(exacttype, current_url=None):
            if is_db_manual(exacttype):
                return
            if current_url and self._existing_artwork_is_manual(current_url):
                return
            if exacttype not in targets:
                targets.append(exacttype)

        for arttype, artcfg in mediatypes.artinfo[mediaitem.mediatype].items():
            if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                continue
            if artcfg['multiselect']:
                existing_urls = [
                    url for key, url in mediaitem.art.items()
                    if info.arttype_matches_base(key, arttype) and url
                ]
                if existing_urls and any(self._existing_artwork_is_manual(url) for url in existing_urls):
                    continue
                add_target(arttype)
            else:
                add_target(arttype, mediaitem.art.get(arttype))

        if mediaitem.mediatype == mediatypes.TVSHOW and self._tvshow_should_manage_season_art():
            for season in mediaitem.seasons:
                for arttype, artcfg in mediatypes.artinfo[mediatypes.SEASON].items():
                    if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                        continue
                    exact = '{0}.{1}.{2}'.format(mediatypes.SEASON, season, arttype)
                    add_target(exact, mediaitem.art.get(exact))

        for arttype in mediatypes.othertypes[mediaitem.mediatype]:
            current = mediaitem.art.get(arttype)
            if current and self._existing_artwork_is_manual(current):
                continue
            if arttype not in mediaitem.skip_artwork and arttype not in targets:
                targets.append(arttype)

        return targets

    def _existing_art_for_refresh(self, mediaitem, targets):
        result = dict(mediaitem.art)
        for target in targets:
            itemtype, artkey = mediatypes.hack_mediaarttype(mediaitem.mediatype, target)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            if cfg['multiselect']:
                for key in list(result):
                    if info.arttype_matches_base(key, target):
                        result[key] = None
            else:
                result[target] = None
        return result

    def _build_refresh_updates(self, mediaitem, selected, targets):
        updates = {}
        selected = selected or {}
        for target in targets:
            itemtype, artkey = mediatypes.hack_mediaarttype(mediaitem.mediatype, target)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            if cfg['multiselect']:
                chosen_urls = [
                    url for exact, url in sorted(selected.items(), key=lambda pair: pair[0])
                    if info.arttype_matches_base(exact, target) and url
                ]
                existing_urls = [
                    url for key, url in mediaitem.art.items()
                    if info.arttype_matches_base(key, target) and url
                ]
                # Refresh All is authoritative for managed multi-art slots. If the
                # strict auto rules only find 3 fanarts for a 5-slot limit, rebuild
                # to those 3 and clear the old extra managed slots instead of
                # keeping low-resolution leftovers. If no valid candidate remains,
                # clear the managed group and mark its slots N/A in the AC DB.
                rebuilt = info.fill_multiart(mediaitem.art, target, (chosen_urls, existing_urls))
                updates.update(get_simpledict_updates(mediaitem.art, rebuilt))
            else:
                chosen = selected.get(target)
                if chosen and chosen != mediaitem.art.get(target):
                    updates[target] = chosen
        return updates

    def _debug_indonesian_poster(self, mediaitem, refresh_targets, selected=None, refresh_updates=None, phase=''):
        current_poster = mediaitem.art.get('poster')
        refreshdebug.write('')
        refreshdebug.write('ITEM {0}:{1} | {2} | phase={3}'.format(
            mediaitem.mediatype, mediaitem.dbid, mediaitem.label, phase))
        refreshdebug.write('  file={0}'.format(mediaitem.file or '-'))
        refreshdebug.write('  indonesia_hint={0}'.format(bool(mediaitem.indonesia_hint)))
        refreshdebug.write('  uniqueids={0}'.format(mediaitem.uniqueids))
        refreshdebug.write('  languages={0}'.format(self.current_languages))
        refreshdebug.write('  current poster={0}'.format(current_poster or '-'))
        refreshdebug.write('  refresh targets={0}'.format(refresh_targets))
        candidates = mediaitem.availableart.get('poster', [])
        refreshdebug.write('  poster candidates={0}'.format(len(candidates)))
        for index, candidate in enumerate(candidates[:30], 1):
            refreshdebug.write(refreshdebug.format_candidate(index, candidate))
        if len(candidates) > 30:
            refreshdebug.write('    ... {0} more candidate(s) omitted'.format(len(candidates) - 30))
        if selected is not None:
            refreshdebug.write('  selected poster={0}'.format(selected.get('poster') or '-'))
        if refresh_updates is not None:
            refreshdebug.write('  poster update={0}'.format(refresh_updates.get('poster') or '-'))

    def _verify_indonesian_poster_update(self, mediaitem, expected_url):
        if not expected_url or mediaitem.mediatype != mediatypes.MOVIE:
            return
        try:
            verify = quickjson.get_item_details(mediaitem.dbid, mediaitem.mediatype) or {}
            actual = info.get_own_artwork(verify).get('poster')
            refreshdebug.important(
                'VERIFY {0}:{1} | {2} | expected={3} | actual={4} | match={5}'.format(
                    mediaitem.mediatype, mediaitem.dbid, mediaitem.label,
                    expected_url, actual or '-', actual == expected_url
                )
            )
        except Exception as ex:
            refreshdebug.important(
                'VERIFY ERROR {0}:{1} | {2} | {3}'.format(
                    mediaitem.mediatype, mediaitem.dbid, mediaitem.label, repr(ex)
                )
            )


    def _mark_missing_na(self, mediaitem, requested, selected):
        selected = selected or {}
        requested_exact = self._expand_requested_arttypes_for_db(mediaitem, requested or ())
        for exact, url in selected.items():
            if url:
                artworkdb.set_artwork_item(mediaitem, exact, url, artworkdb.infer_source(url), 'OK', '')
                self._mirror_season_art_db(mediaitem, exact, url, 'OK', '')
        for requested_art in requested_exact:
            if any(url and exact == requested_art for exact, url in selected.items()):
                continue
            artworkdb.set_artwork_item(mediaitem, requested_art, '', '', 'N/A', 'No provider candidate selected')
            self._mirror_season_art_db(mediaitem, requested_art, '', 'N/A', 'No provider candidate selected')

    def _mirror_season_art_db(self, mediaitem, art_type, url='', status='OK', reason=''):
        try:
            if mediaitem.mediatype == mediatypes.TVSHOW and str(art_type).startswith('season.'):
                parts = str(art_type).split('.', 2)
                if len(parts) != 3:
                    return
                season_number = int(parts[1])
                season_id = (mediaitem.seasons or {}).get(season_number)
                if not season_id:
                    return
                direct_type = parts[2]
                title = '{0} - Season {1}'.format(getattr(mediaitem, 'label', '') or '', season_number).strip(' -')
                artworkdb.set_artwork_for_key(mediatypes.SEASON, season_id, title, direct_type, url or '', artworkdb.infer_source(url), status, reason)
        except Exception as ex:
            runtrace.error('season artwork DB mirror failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''), art_type=art_type)

    def _remaining_strong_targets(self, targets, mediatype, existingart, availableart, mediaitem=None):
        remaining = []
        for target in targets or ():
            itemtype, artkey = mediatypes.hack_mediaarttype(mediatype, target)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            if not cfg.get('autolimit'):
                continue
            candidates = list((availableart or {}).get(target, []) or [])
            if cfg.get('multiselect'):
                existingurls = [url for art, url in (existingart or {}).items() if info.arttype_matches_base(art, target) and url]
                exactnames = [art for art, url in (existingart or {}).items() if info.arttype_matches_base(art, target) and url]
                required = max(0, int(cfg.get('autolimit') or 0) - len(exactnames))
                if required <= 0:
                    continue
                usable = self._auto_usable_candidates(target, candidates, mediatype, existingurls, allow_one_lowres_fallback=False)
                if len(usable) < required:
                    remaining.append(target)
            else:
                if (existingart or {}).get(target):
                    continue
                usable = self._auto_usable_candidates(target, candidates, mediatype, (), allow_one_lowres_fallback=False)
                if not usable:
                    remaining.append(target)
        return remaining

    def _gather_artwork_lazy(self, mediaitem, targets, existingart, skipexisting=True):
        # Auto/Refresh uses provider lazy fallback: TMDb first, fanart.tv only for
        # targets that still lack strong candidates, TheTVDB only as final TV fallback.
        def checkpoint(images):
            previous = getattr(mediaitem, 'availableart', {})
            try:
                mediaitem.availableart = images or {}
                try:
                    self.gatherer._sort_available_art(mediaitem)
                except Exception:
                    pass
                return self._remaining_strong_targets(targets, mediaitem.mediatype, existingart, mediaitem.availableart, mediaitem)
            finally:
                mediaitem.availableart = previous
        mediaitem.missingart = list(targets or ())
        return self.gatherer.getartwork(mediaitem, skipexisting=skipexisting, completion_callback=checkpoint)

    def _expand_requested_arttypes_for_db(self, mediaitem, requested):
        explicit = list(getattr(mediaitem, 'db_missingart_exact', None) or ())
        if explicit:
            return explicit
        expanded = []
        for requested_art in requested or ():
            itemtype, artkey = mediatypes.hack_mediaarttype(mediaitem.mediatype, requested_art)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            if cfg.get('multiselect') and cfg.get('autolimit'):
                for index in range(int(cfg['autolimit'])):
                    exact = info.format_arttype(requested_art, index)
                    if exact not in expanded:
                        expanded.append(exact)
            elif requested_art not in expanded:
                expanded.append(requested_art)
        return expanded

    def _process_refresh_all_item(self, mediaitem, cleanchanges, existing_before):
        refresh_targets = self._iter_refresh_targets(mediaitem)
        if not refresh_targets:
            self.item_status('Skipping', mediaitem, existing_before, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False
        self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
        self.gatherer.set_languages(self.current_languages)
        self.item_status('Searching', mediaitem, refresh_targets, 0.30)
        services_hit, error = self._gather_artwork_lazy(mediaitem, refresh_targets, self._existing_art_for_refresh(mediaitem, refresh_targets), skipexisting=True)
        if error:
            mediaitem.error = '{0}: {1}'.format(error['providername'], error['message'])
            if self._skip_item_on_primary_provider_error(mediaitem, error, 0.98):
                mediaitem.updatedart = list(cleanchanges)
                return services_hit
        self.item_status('Selecting', mediaitem, refresh_targets, 0.60)
        selected = self.get_top_missing_art(
            refresh_targets,
            mediaitem.mediatype,
            self._existing_art_for_refresh(mediaitem, refresh_targets),
            mediaitem.availableart,
            mediaitem=mediaitem,
        )
        refresh_updates = self._build_refresh_updates(mediaitem, selected, refresh_targets)
        combined = dict(cleanchanges)
        combined.update(refresh_updates)
        if refresh_updates:
            self.item_status('Adding', mediaitem, refresh_updates.keys(), 0.72)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, refresh_updates)
            mediaitem.art.update(refresh_updates)
        self._mark_missing_na(mediaitem, refresh_targets, selected)
        mediaitem.updatedart = list(combined)
        self.cache_remote(mediaitem, refresh_updates)
        self.item_status('Done', mediaitem, combined.keys(), 0.98)
        return services_hit

    def _process_indonesian_refresh(self, mediaitem, cleanchanges, existing_before):
        refresh_targets = self._iter_refresh_targets(mediaitem)
        if not refresh_targets:
            self.item_status('Skipping', mediaitem, existing_before, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False

        self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
        self.gatherer.set_languages(self.current_languages)
        self.item_status('Searching', mediaitem, refresh_targets, 0.30)
        services_hit, error = self._gather_artwork_lazy(mediaitem, refresh_targets, self._existing_art_for_refresh(mediaitem, refresh_targets), skipexisting=True)
        if error:
            mediaitem.error = '{0}: {1}'.format(error['providername'], error['message'])
            if self._skip_item_on_primary_provider_error(mediaitem, error, 0.98):
                mediaitem.updatedart = list(cleanchanges)
                return services_hit
        self.item_status('Selecting', mediaitem, refresh_targets, 0.60)
        self._debug_indonesian_poster(mediaitem, refresh_targets, phase='after-gather')

        selected = self.get_top_missing_art(
            refresh_targets,
            mediaitem.mediatype,
            self._existing_art_for_refresh(mediaitem, refresh_targets),
            mediaitem.availableart,
            mediaitem=mediaitem,
        )
        refresh_updates = self._build_refresh_updates(mediaitem, selected, refresh_targets)
        self._debug_indonesian_poster(
            mediaitem, refresh_targets, selected=selected,
            refresh_updates=refresh_updates, phase='after-select')
        combined = dict(cleanchanges)
        combined.update(refresh_updates)
        if refresh_updates:
            self.item_status('Adding', mediaitem, refresh_updates.keys(), 0.72)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, refresh_updates)
            mediaitem.art.update(refresh_updates)
            self._verify_indonesian_poster_update(mediaitem, refresh_updates.get('poster'))
        else:
            self.item_status('Skipping', mediaitem, existing_before, 0.88)
        mediaitem.updatedart = list(combined)
        self.cache_remote(mediaitem, refresh_updates)
        self.item_status('Done', mediaitem, combined.keys(), 0.98)
        return services_hit

    def cache_remote(self, mediaitem, toset):
        if settings.cache_remote_video_artwork and self.downloader:
            artmap = dict(mediaitem.art)
            artmap.update(toset or {})
            urltypes = {}
            for arttype, url in artmap.items():
                if url:
                    urltypes.setdefault(url, []).append(arttype)
            self.item_status('Checking', mediaitem, (toset or {}).keys(), 0.80)

            def on_cache_progress(done, total, url):
                # Keep the compact BG progress notification informative while
                # Kodi fetches remote URLs into userdata/Thumbnails.
                self.item_status('Downloading', mediaitem, urltypes.get(url, ()), 0.82 + (0.15 * done / float(total or 1)))

            self.downloader.cachefor(artmap, progress_callback=on_cache_progress)

    def _provider_display(self, image):
        provider = image.get('provider') if image else None
        return getattr(provider, 'display', None) or getattr(provider, 'sort', None) or provider or '-'

    def _display_field(self, value):
        return getattr(value, 'display', None) or getattr(value, 'sort', None) or value or '-'

    def _dryrun_candidate_line(self, prefix, index, image, selected_urls=None):
        selected_urls = selected_urls or set()
        url = image.get('url') or ''
        flags = []
        if url in selected_urls:
            flags.append('SELECTED')
        if image.get('existing'):
            flags.append('EXISTING')
        if image.get('details_primary') or image.get('localized_primary'):
            flags.append('PRIMARY')
        subtype = image.get('subtype')
        subtype = getattr(subtype, 'display', subtype) if subtype else ''
        title = image.get('title') or subtype or ''
        return '{prefix} #{idx:03d} {flags} provider={provider} lang={lang} size={size} rating={rating} gallery_order={order} title={title} preview={preview} url={url}'.format(
            prefix=prefix,
            idx=index,
            flags=('[{0}]'.format(','.join(flags)) if flags else ''),
            provider=self._provider_display(image),
            lang=image.get('language'),
            size=self._display_field(image.get('size')),
            rating=self._display_field(image.get('rating')),
            order=image.get('gallery_order'),
            title=title or '-',
            preview=image.get('preview') or '-',
            url=url or '-',
        )

    def _dryrun_log_paths(self):
        diagdir = runtrace.diagnostics_dir()
        return (
            os.path.join(diagdir, 'dry-run-artwork-selection-last.txt'),
            os.path.join(diagdir, 'dry-run-artwork-selection.txt'),
        )

    def _dryrun_write_logs(self, text):
        last_path, history_path = self._dryrun_log_paths()
        try:
            with open(last_path, 'w', encoding='utf-8') as handle:
                handle.write(text)
        except Exception as ex:
            runtrace.error('dry-run last log write failed', ex, path=last_path)
        try:
            with open(history_path, 'a', encoding='utf-8') as handle:
                handle.write('\n\n' + ('=' * 120) + '\n')
                handle.write(text)
        except Exception as ex:
            runtrace.error('dry-run history log write failed', ex, path=history_path)
        return last_path

    def _dryrun_selected_urls_for_target(self, selected, target):
        result = []
        for exact, url in sorted((selected or {}).items(), key=lambda pair: natural_sort(pair[0])):
            if url and info.arttype_matches_base(exact, target):
                result.append((exact, url))
        if not result and selected.get(target):
            result.append((target, selected.get(target)))
        return result

    def _dryrun_current_position_lines(self, target, current_pairs, usable, candidates):
        rows = []
        usable_pos = dict((image.get('url'), index) for index, image in enumerate(usable or (), 1) if image.get('url'))
        candidate_pos = dict((image.get('url'), index) for index, image in enumerate(candidates or (), 1) if image.get('url'))
        if not current_pairs:
            return ['  <none>']
        for key, url in current_pairs:
            if not url:
                rows.append('  {0}: empty'.format(key))
                continue
            uidx = usable_pos.get(url)
            cidx = candidate_pos.get(url)
            if uidx is not None:
                position = 'usable #{0}'.format(uidx)
            elif cidx is not None:
                position = 'provider #{0}, not usable after AC filter'.format(cidx)
            else:
                position = 'not in provider candidates'
            rows.append('  {0}: {1} | {2}'.format(key, position, url))
        return rows

    def _dryrun_selection_text(self, mediaitem, targets, selected, refresh_updates, services_hit=None, error=None):
        rows = []
        now = __import__('time').strftime('%Y-%m-%d %H:%M:%S')
        rows.append('Library Artwork Curator - Dry run artwork selection')
        rows.append('=' * 120)
        rows.append('Created: {0}'.format(now))
        rows.append('Addon mode: DRY RUN - NO KODI ART UPDATE, NO DB WRITE, NO TEXTURE CACHE')
        rows.append('Item: {0}:{1} | {2}'.format(mediaitem.mediatype, mediaitem.dbid, mediaitem.label))
        rows.append('File: {0}'.format(mediaitem.file or '-'))
        rows.append('Unique IDs: {0}'.format(mediaitem.uniqueids or {}))
        rows.append('Premiered: {0}'.format(mediaitem.premiered or '-'))
        rows.append('Indonesian hint: {0}'.format(bool(mediaitem.indonesia_hint)))
        rows.append('Protected custom set: {0}'.format(bool(mediaitem.protected_custom_set)))
        rows.append('Language order: {0}'.format(self.current_languages))
        rows.append('Refresh targets: {0}'.format(', '.join(targets) if targets else '-'))
        rows.append('Provider services hit: {0}'.format(services_hit))
        if error:
            rows.append('Provider error: {0}'.format(error))
        rows.append('')
        rows.append('Current Kodi artwork')
        rows.append('-' * 120)
        if mediaitem.art:
            for key in sorted(mediaitem.art, key=natural_sort):
                rows.append('{0}: {1}'.format(key, mediaitem.art.get(key) or '-'))
        else:
            rows.append('<none>')
        rows.append('')
        rows.append('Provider candidate counts')
        rows.append('-' * 120)
        counts = dict((key, len(value or [])) for key, value in sorted(mediaitem.availableart.items(), key=lambda pair: natural_sort(pair[0])))
        rows.append(str(counts))
        rows.append('')
        rows.append('Planned Kodi updates if this was Refresh all artwork')
        rows.append('-' * 120)
        if refresh_updates:
            for key in sorted(refresh_updates, key=natural_sort):
                rows.append('{0}: {1}'.format(key, refresh_updates.get(key) or '-'))
        else:
            rows.append('<no Kodi art changes planned>')
        rows.append('')
        existing_for_refresh = self._existing_art_for_refresh(mediaitem, targets)
        for target in targets:
            itemtype, artkey = mediatypes.hack_mediaarttype(mediaitem.mediatype, target)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            candidates = list(mediaitem.availableart.get(target, []) or [])
            selected_pairs = self._dryrun_selected_urls_for_target(selected, target)
            selected_urls = set(url for _, url in selected_pairs)
            rows.append('')
            rows.append('ART TYPE: {0}'.format(target))
            rows.append('=' * 120)
            rows.append('mediaitem type={0} effective type={1} artkey={2} multiselect={3} autolimit={4}'.format(
                mediaitem.mediatype, itemtype, artkey, bool(cfg.get('multiselect')), cfg.get('autolimit')))
            rows.append('current exact artwork:')
            current_pairs = []
            for key in sorted(mediaitem.art, key=natural_sort):
                if info.arttype_matches_base(key, target) or key == target:
                    current_pairs.append((key, mediaitem.art.get(key)))
                    rows.append('  {0}: {1}'.format(key, mediaitem.art.get(key) or '-'))
            if not current_pairs:
                rows.append('  <none>')
            if selected_pairs:
                rows.append('selected order:')
                for exact, url in selected_pairs:
                    rows.append('  {0}: {1}'.format(exact, url))
            else:
                rows.append('selected order: <none>')
            rows.append('')
            if cfg.get('multiselect'):
                existingurls = [url for art, url in existing_for_refresh.items() if info.arttype_matches_base(art, target) and url]
                candidates = self._ensure_generated_thumb_fallback(target, candidates, mediaitem.mediatype, mediaitem, existingurls)
                mediaitem.availableart[target] = candidates
                usable = self._auto_usable_candidates(target, candidates, mediaitem.mediatype, existingurls, allow_one_lowres_fallback=True)
            else:
                candidates = self._ensure_generated_thumb_fallback(target, candidates, mediaitem.mediatype, mediaitem, ())
                mediaitem.availableart[target] = candidates
                usable = self._auto_usable_candidates(target, candidates, mediaitem.mediatype, (), allow_one_lowres_fallback=True)
            rows.append('current artwork positions in this dry-run order:')
            for line in self._dryrun_current_position_lines(target, current_pairs, usable, candidates):
                rows.append(line)
            rows.append('')
            rows.append('usable candidates after AC filter: {0}/{1}'.format(len(usable), len(candidates)))
            rows.append('usable order:')
            if usable:
                for index, image in enumerate(usable[:DRYRUN_CANDIDATE_LIMIT], 1):
                    rows.append(self._dryrun_candidate_line('  usable', index, image, selected_urls))
                if len(usable) > DRYRUN_CANDIDATE_LIMIT:
                    rows.append('  ... {0} more usable candidate(s) omitted'.format(len(usable) - DRYRUN_CANDIDATE_LIMIT))
            else:
                rows.append('  <none>')
            rows.append('')
            rows.append('provider order before AC usable filter:')
            if candidates:
                for index, image in enumerate(candidates[:DRYRUN_CANDIDATE_LIMIT], 1):
                    rows.append(self._dryrun_candidate_line('  candidate', index, image, selected_urls))
                if len(candidates) > DRYRUN_CANDIDATE_LIMIT:
                    rows.append('  ... {0} more provider candidate(s) omitted'.format(len(candidates) - DRYRUN_CANDIDATE_LIMIT))
            else:
                rows.append('  <none>')
        rows.append('')
        rows.append('End dry run')
        rows.append('=' * 120)
        return '\n'.join(rows) + '\n'

    def _dry_run_item(self, mediaitem, busy=None):
        previous_refresh = self.refresh_all_artwork
        self.refresh_all_artwork = True
        services_hit = None
        error = None
        try:
            if busy:
                try:
                    busy.update(0, 'Dry run artwork selection')
                except Exception:
                    pass
            if mediaitem.missingid:
                runtrace.event('dryrun', 'item missing provider id', mediatype=mediaitem.mediatype, dbid=mediaitem.dbid, label=mediaitem.label)
            targets = self._iter_refresh_targets(mediaitem)
            self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
            self.gatherer.set_languages(self.current_languages)
            if busy:
                try:
                    busy.update(25, 'Fetching artwork providers')
                except Exception:
                    pass
            services_hit, error = self.gatherer.getartwork(mediaitem, skipexisting=False)
            if error:
                mediaitem.error = '{0}: {1}'.format(error.get('providername'), error.get('message'))
            if busy:
                try:
                    busy.update(70, 'Selecting artwork')
                except Exception:
                    pass
            selected = self.get_top_missing_art(
                targets,
                mediaitem.mediatype,
                self._existing_art_for_refresh(mediaitem, targets),
                mediaitem.availableart,
                mediaitem=mediaitem,
            )
            refresh_updates = self._build_refresh_updates(mediaitem, selected, targets)
            text = self._dryrun_selection_text(mediaitem, targets, selected, refresh_updates, services_hit=services_hit, error=mediaitem.error)
            path = self._dryrun_write_logs(text)
            runtrace.event('dryrun', 'finished', mediatype=mediaitem.mediatype, dbid=mediaitem.dbid, label=mediaitem.label,
                           targets=len(targets), planned_updates=len(refresh_updates), log=path)
            _family_notify_03252('DRY RUN FINISHED - CHECK DIAGNOSTICS LOG', xbmcgui.NOTIFICATION_INFO, 8000)
        except Exception as ex:
            runtrace.error('dry-run failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''))
            _family_notify_03252('DRY RUN FAILED - CHECK KODI.LOG', xbmcgui.NOTIFICATION_ERROR, 8000)
        finally:
            self.refresh_all_artwork = previous_refresh

    def manual_id(self, mediaitem):
        if mediaitem.mediatype != mediatypes.MOVIESET:
            return False
        result = xbmcgui.Dialog().input(L(ENTER_COLLECTION_NAME), mediaitem.label)
        if not result:
            return False
        options = search[mediaitem.mediatype].search(result, mediaitem.mediatype)
        selected = xbmcgui.Dialog().select(mediaitem.label, [option['label'] for option in options])
        if selected < 0:
            return False
        tmdbid = options[selected]['uniqueids'].get('tmdb')
        if tmdbid:
            self.processed.set_data(mediaitem.dbid, mediaitem.mediatype, mediaitem.label, tmdbid)
        return bool(tmdbid)

    def setlanguages(self):
        languages = []
        if settings.language_override:
            languages.append(settings.language_override)
        if settings.language_fallback_kodi:
            language = pykodi.get_language(xbmc.ISO_639_1)
            if language not in languages:
                languages.append(language)
        if settings.language_fallback_en and 'en' not in languages:
            languages.append('en')
        if None not in languages:
            languages.append(None)
        self.autolanguages = tuple(languages)
        log('Working language filter: ' + repr(self.autolanguages))

    def _primary_provider_error(self, error):
        if not error:
            return False
        provider = str(error.get('providername') or '').lower()
        message = str(error.get('message') or '').lower()
        return 'movie database' in provider or 'tmdb' in provider or 'themoviedb' in provider or 'the movie database' in message

    def _skip_item_on_primary_provider_error(self, mediaitem, error, stage=0.98):
        if not self._primary_provider_error(error):
            return False
        mediaitem.error = '{0}: {1}'.format(error.get('providername'), error.get('message'))
        self.item_error_count += 1
        self.item_status('Error', mediaitem, (), stage)
        runtrace.event('processor', 'skip item because primary provider failed',
                       mediatype=getattr(mediaitem, 'mediatype', ''),
                       dbid=getattr(mediaitem, 'dbid', ''),
                       label=getattr(mediaitem, 'label', ''),
                       error=mediaitem.error)
        return True

    def _can_use_generated_video_thumb(self, mediaitem):
        if not mediaitem or not getattr(settings, 'use_generated_video_thumb', True):
            return False
        if mediaitem.mediatype not in (mediatypes.MOVIE, mediatypes.EPISODE):
            return False
        path = getattr(mediaitem, 'file', '') or ''
        if not path:
            return False
        lower = path.lower()
        if lower.startswith(('http://', 'https://', 'plugin://', 'image://', 'upnp://')):
            return False
        if lower.endswith('.strm') or os.path.isdir(path) or not os.path.isfile(path):
            return False
        return True

    def _generated_video_thumb_candidate(self, mediaitem):
        if not self._can_use_generated_video_thumb(mediaitem):
            return None
        url = pykodi.quote_video_thumbnail(mediaitem.file)
        if not url:
            return None
        return {
            'url': url,
            'preview': url,
            'provider': SortedDisplay('kodi', 'Kodi generated'),
            'language': None,
            'rating': SortedDisplay(0, 'Generated from video'),
            'rating_unrated': True,
            'size': SortedDisplay(0, 'Generated video thumb'),
            'gallery_order': 999999,
            'title': 'Kodi generated video thumb',
            'generated_thumb': True,
        }

    def _ensure_generated_thumb_fallback(self, basearttype, candidates, mediatype, mediaitem, ignoreurls=()):
        if info.get_basetype(basearttype) != 'thumb':
            return candidates
        if not mediaitem or mediatype not in (mediatypes.MOVIE, mediatypes.EPISODE):
            return candidates
        # Remote provider candidates always win, including the single low-res
        # fallback rule. Generated video thumbs are only used when no remote thumb
        # candidate is usable at all.
        remote_usable = self._auto_usable_candidates(basearttype, candidates, mediatype, ignoreurls, allow_one_lowres_fallback=True)
        if remote_usable:
            return candidates
        generated = self._generated_video_thumb_candidate(mediaitem)
        if not generated:
            return candidates
        if generated.get('url') in ignoreurls:
            return candidates
        if not any(art.get('url') == generated.get('url') for art in candidates):
            candidates = list(candidates or []) + [generated]
        return candidates

    def get_top_missing_art(self, missingarts, mediatype, existingart, availableart, mediaitem=None):
        newartwork = {}
        for missingart in missingarts:
            candidates = list(availableart.get(missingart, []) or [])
            itemtype, artkey = mediatypes.hack_mediaarttype(mediatype, missingart)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            if cfg['multiselect']:
                existingurls = [url for art, url in existingart.items()
                    if info.arttype_matches_base(art, missingart) and url]
                candidates = self._ensure_generated_thumb_fallback(missingart, candidates, mediatype, mediaitem, existingurls)
                availableart[missingart] = candidates
                if not candidates:
                    continue
                exactnames = [art for art, url in existingart.items()
                    if info.arttype_matches_base(art, missingart) and url]
                usable = self._auto_usable_candidates(missingart, candidates, mediatype, existingurls, allow_one_lowres_fallback=True)
                selected_urls = []
                newindex = 0
                for index in range(cfg['autolimit']):
                    exact = info.format_arttype(missingart, index)
                    if exact in exactnames:
                        continue
                    if newindex >= len(usable):
                        break
                    newartwork[exact] = usable[newindex]['url']
                    selected_urls.append('{0}={1}'.format(exact, usable[newindex]['url']))
                    existingurls.append(usable[newindex]['url'])
                    newindex += 1
                runtrace.selection(mediaitem, mediatype, missingart, candidates, usable, chosen='; '.join(selected_urls), existing_count=len(exactnames))
            else:
                candidates = self._ensure_generated_thumb_fallback(missingart, candidates, mediatype, mediaitem, ())
                availableart[missingart] = candidates
                if not candidates:
                    continue
                usable = self._auto_usable_candidates(missingart, candidates, mediatype, (), allow_one_lowres_fallback=True)
                chosen = usable[0] if usable else None
                runtrace.selection(mediaitem, mediatype, missingart, candidates, usable, chosen=chosen.get('url') if chosen else None)
                if chosen:
                    newartwork[missingart] = chosen['url']
        return newartwork


    def _allows_one_lowres_fallback(self, basearttype):
        base = info.get_basetype(basearttype)
        # Keep exactly one fallback image when a sparse provider has no candidate
        # meeting the preferred size threshold. Poster is included globally so
        # older/sparser movies still get a poster instead of ending as N/A; this
        # does not lower the preferred poster threshold when good posters exist.
        return (base.endswith('poster') or base.endswith('fanart')
            or base.endswith('landscape') or base.endswith('thumb'))

    def _passes_language_filter(self, basearttype, art, availableart, ignoreurls=()):
        language = art.get('language')
        if language in self.current_languages:
            return True
        if language is None:
            return not any(candidate.get('language') in self.current_languages and candidate.get('url') not in ignoreurls
                for candidate in availableart)
        return False

    def _auto_usable_candidates(self, basearttype, candidates, mediatype, ignoreurls=(), allow_one_lowres_fallback=True):
        preferred = [art for art in candidates if self._auto_filter(basearttype, art, mediatype, candidates, ignoreurls)]
        if preferred:
            return preferred
        if not allow_one_lowres_fallback or not self._allows_one_lowres_fallback(basearttype):
            return preferred
        fallback = []
        for art in candidates:
            if art.get('url') in ignoreurls:
                continue
            if not self._passes_language_filter(basearttype, art, candidates, ignoreurls):
                continue
            fallback.append(art)
        # If every candidate is below the preferred minimum, keep exactly one best
        # fallback instead of returning nothing. This preserves at least one usable
        # poster/background/landscape/thumb for sparse providers while still
        # preventing low-res extras from filling every fanart slot.
        return fallback[:1]

    def _passes_size_filter(self, basearttype, art):
        if basearttype.endswith('fanart') and not self._passes_minimum_resolution(art, getattr(settings, 'minimum_fanart_resolution', (1920, 1080))):
            return False
        if basearttype.endswith('landscape') and not self._passes_minimum_resolution(art, (1920, 1080)):
            return False
        if basearttype.endswith('thumb') and not self._passes_minimum_resolution(art, (1280, 720)):
            return False
        if basearttype.endswith('poster') and art.get('size', SortedDisplay(0, '')).sort < settings.minimum_poster_height:
            return False
        return True

    def _passes_minimum_resolution(self, art, minimum):
        min_width, min_height = minimum or (0, 0)
        if not min_width and not min_height:
            return True
        width, height = self._candidate_dimensions(art)
        if not width or not height:
            return False
        return width >= min_width and height >= min_height

    def _candidate_dimensions(self, art):
        size = art.get('size', SortedDisplay(0, ''))
        display = (getattr(size, 'display', '') or '').lower().replace('×', 'x')
        parts = display.split('x')
        if len(parts) == 2:
            try:
                return int(float(parts[0])), int(float(parts[1]))
            except (TypeError, ValueError):
                pass
        try:
            sortsize = int(getattr(size, 'sort', 0) or 0)
        except (TypeError, ValueError):
            sortsize = 0
        return sortsize, 0

    def _candidate_has_acceptable_language(self, art):
        language = art.get('language')
        return language in self.current_languages or language is None


    def _auto_filter(self, basearttype, art, mediatype, availableart, ignoreurls=()):
        if art.get('url') in ignoreurls:
            return False
        if not self._passes_size_filter(basearttype, art):
            return False

        # Rating is intentionally informational only. Selection is deterministic:
        # language priority, provider priority, provider/API index order, and the
        # configured minimum resolution. This prevents sparse or missing votes
        # from reshuffling otherwise correct artwork.
        return self._passes_language_filter(basearttype, art, availableart, ignoreurls)


def add_art_to_library(mediatype, seasons, dbid, selectedart):
    if not selectedart:
        return
    if mediatype == mediatypes.TVSHOW:
        for season, season_id in seasons.items():
            prefix = 'season.{0}.'.format(season)
            seasonart = dict((arttype[len(prefix):], url) for arttype, url in selectedart.items() if arttype.startswith(prefix))
            info.update_art_in_library(mediatypes.SEASON, season_id, seasonart)
        itemart = dict((arttype, url) for arttype, url in selectedart.items() if '.' not in arttype)
        info.update_art_in_library(mediatype, dbid, itemart)
    else:
        info.update_art_in_library(mediatype, dbid, selectedart)
    info.remove_local_from_texturecache(selectedart.values())


def finalmessages(count):
    count = int(count or 0)
    if count:
        return (None, 'CHANGE ARTWORK FINISHED - 1 ITEM - {0} ARTWORK UPDATED'.format(count))
    return (None, 'CHANGE ARTWORK FINISHED - 1 ITEM - 0 ARTWORK UPDATED')


def notifycount(count):
    _header, message = finalmessages(count)
    _family_notify_03252(message, xbmcgui.NOTIFICATION_INFO, 8000)


def plus_some(start, rng):
    return start + random.randrange(-rng, rng + 1)


def is_excluded(mediaitem):
    if not mediaitem.file:
        return False
    for exclusion in settings.pathexclusion:
        if exclusion['type'] == EXCLUSION_PATH_TYPE_FOLDER:
            path_file = os.path.realpath(os.path.join(mediaitem.file, ''))
            path_excl = os.path.realpath(os.path.join(exclusion['folder'], ''))
            if os.path.commonprefix([path_file, path_excl]) == path_excl:
                return True
        elif exclusion['type'] == EXCLUSION_PATH_TYPE_PREFIX and mediaitem.file.startswith(exclusion['prefix']):
            return True
        elif exclusion['type'] == EXCLUSION_PATH_TYPE_REGEX and re.match(exclusion['regex'], mediaitem.file):
            return True
    return False


def tag_forcedandexisting_art(availableart, forcedart, existingart):
    typeinsert = {}
    for exacttype, existingurl in existingart.items():
        arttype = info.get_basetype(exacttype)
        if arttype not in availableart:
            availableart[arttype] = []
        match = next((available for available in availableart[arttype] if available.get('url') == existingurl), None)
        if match:
            match['preview'] = existingurl
            match['existing'] = True
            match.setdefault('title', exacttype)
        elif existingurl:
            typeinsert[arttype] = typeinsert.get(arttype, -1) + 1
            availableart[arttype].insert(typeinsert[arttype], {
                'url': existingurl, 'preview': existingurl, 'title': exacttype,
                'existing': True, 'provider': SortedDisplay('current', L(CURRENT_ART)),
                'rating': SortedDisplay(10, ''), 'size': SortedDisplay(10000, ''), 'language': None,
            })

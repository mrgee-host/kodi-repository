# -*- coding: utf-8 -*-
from __future__ import absolute_import

import re
import xbmcgui

ADDON_NAME = 'Library Artwork Curator'
BODY_LIMIT = 58

def compact(value, limit=BODY_LIMIT):
    text = re.sub(r'\s+', ' ', str(value or '').strip()).upper().rstrip()
    text = re.sub(r'\bHANDED OFF\b', 'MIGRATED', text)
    text = re.sub(r'\bHANDOFF\b', 'MIGRATED', text)
    parts = text.split(' - ') if text else []
    if len(parts) > 1:
        text = ' - '.join([parts[0]] + [part for part in parts[1:] if not re.match(r'^0(?:\s+|$)', part)])
    elif text and re.match(r'^0(?:\s+|$)', text):
        return ''
    if len(text) <= int(limit):
        return text
    raw = text[:max(1, int(limit) - 1)].rstrip()
    if ' ' in raw:
        candidate = raw.rsplit(' ', 1)[0].rstrip()
        if candidate:
            raw = candidate
    return raw + '…'

def notify(message, level=xbmcgui.NOTIFICATION_INFO, duration=7000, title=ADDON_NAME):
    text = compact(message)
    if text:
        xbmcgui.Dialog().notification(str(title or ADDON_NAME), text, level, int(duration))

def show_report(title, body):
    text = str(body or '').strip()
    if len(text) <= 520 and len(text.splitlines()) <= 7:
        xbmcgui.Dialog().ok(str(title or ADDON_NAME), text or 'NO DETAILS')
    else:
        xbmcgui.Dialog().textviewer(str(title or ADDON_NAME), text)

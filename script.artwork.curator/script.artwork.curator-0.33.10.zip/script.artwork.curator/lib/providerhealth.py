import hashlib
import time
from urllib.parse import urlparse

import requests
from requests.exceptions import ConnectionError, RequestException, Timeout


class ProviderImageHostGuard(object):
    """Fail-fast guard for remote artwork image hosts.

    Provider APIs can remain online while their image CDN is unavailable. In that
    case the provider metadata is valid but every preview shown by Kodi is blank.
    This guard probes one preview URL per image host, removes candidates from a
    host that is unavailable, and shares a short cooldown through a Kodi window
    property so repeated context-menu actions do not hammer the same dead host.
    """

    DEFAULT_COOLDOWN_SECONDS = 300
    DEFAULT_TIMEOUT = (2, 4)
    PROPERTY_PREFIX = 'ArtworkCurator.ImageHostDown.'

    def __init__(self, user_agent='', window=None, session_factory=None,
            cooldown_seconds=None, timeout=None, now=None, log_callback=None,
            trace_callback=None):
        self.user_agent = str(user_agent or '')
        self.window = window
        self.session_factory = session_factory or requests.Session
        self.cooldown_seconds = int(cooldown_seconds or self.DEFAULT_COOLDOWN_SECONDS)
        self.timeout = timeout or self.DEFAULT_TIMEOUT
        self.now = now or time.time
        self.log_callback = log_callback
        self.trace_callback = trace_callback
        self._host_health = {}

    def _property_name(self, host):
        digest = hashlib.sha1(host.encode('utf-8')).hexdigest()[:16]
        return self.PROPERTY_PREFIX + digest

    def _shared_down(self, host):
        if self.window is None:
            return False
        prop = self._property_name(host)
        try:
            value = self.window.getProperty(prop)
            expiry = int(float(value or 0))
        except (TypeError, ValueError, AttributeError):
            expiry = 0
        now = int(self.now())
        if expiry > now:
            return True
        if expiry:
            try:
                self.window.clearProperty(prop)
            except AttributeError:
                try:
                    self.window.setProperty(prop, '')
                except Exception:
                    pass
        return False

    def _mark_shared_down(self, host):
        if self.window is None:
            return
        expiry = int(self.now()) + self.cooldown_seconds
        try:
            self.window.setProperty(self._property_name(host), str(expiry))
        except Exception:
            pass

    def _emit(self, provider_name, host, reason, cached=False):
        message = ('Artwork image host unavailable; provider candidates skipped: '
            'provider={0}; host={1}; reason={2}; cooldown={3}s{4}').format(
                provider_name, host, reason, self.cooldown_seconds,
                '; cached=yes' if cached else '')
        if self.log_callback:
            self.log_callback(message)
        if self.trace_callback:
            self.trace_callback(provider_name, host, reason, cached)

    def _probe(self, url):
        session = self.session_factory()
        response = None
        headers = {'Accept': 'image/*,*/*;q=0.8'}
        if self.user_agent:
            headers['User-Agent'] = self.user_agent
        try:
            response = session.get(url, headers=headers, stream=True,
                allow_redirects=True, timeout=self.timeout)
            status = int(getattr(response, 'status_code', 0) or 0)
            # 404/410 proves the host itself is reachable. The individual image
            # may be stale, but that must not disable every image from the host.
            if 200 <= status < 400 or status in (404, 410):
                return True, 'HTTP {0}'.format(status)
            if status in (401, 403, 407, 408, 425, 429) or status >= 500:
                return False, 'HTTP {0}'.format(status)
            # Other 4xx responses usually indicate a bad sample URL rather than
            # a dead CDN. Keep the provider to avoid a false global skip.
            return True, 'HTTP {0}'.format(status)
        except (Timeout, ConnectionError) as ex:
            return False, type(ex).__name__
        except RequestException as ex:
            return False, type(ex).__name__
        finally:
            if response is not None:
                try:
                    response.close()
                except Exception:
                    pass
            try:
                session.close()
            except Exception:
                pass

    def _host_status(self, host, sample_url, provider_name):
        cached = self._host_health.get(host)
        if cached is not None:
            return cached
        if self._shared_down(host):
            result = (False, 'shared cooldown')
            self._host_health[host] = result
            self._emit(provider_name, host, result[1], cached=True)
            return result
        healthy, reason = self._probe(sample_url)
        result = (healthy, reason)
        self._host_health[host] = result
        if not healthy:
            self._mark_shared_down(host)
            self._emit(provider_name, host, reason, cached=False)
        return result

    def filter_images(self, provider_name, providerimages):
        providerimages = providerimages or {}
        host_samples = {}
        for artlist in providerimages.values():
            for image in artlist or ():
                sample = image.get('preview') or image.get('url')
                host = urlparse(str(sample or '')).hostname
                if host and host not in host_samples:
                    host_samples[host] = sample

        if not host_samples:
            return providerimages

        down_hosts = set()
        for host, sample_url in host_samples.items():
            healthy, _reason = self._host_status(host, sample_url, provider_name)
            if not healthy:
                down_hosts.add(host)

        if not down_hosts:
            return providerimages

        filtered = {}
        for arttype, artlist in providerimages.items():
            kept = []
            for image in artlist or ():
                sample = image.get('preview') or image.get('url')
                host = urlparse(str(sample or '')).hostname
                if host in down_hosts:
                    continue
                kept.append(image)
            if kept:
                filtered[arttype] = kept
        return filtered

import traceback
import time
import xbmc
import xbmcgui

from lib import providers, runtrace
from lib.libs import mediatypes
from lib.libs.addonsettings import settings
from lib.libs.mediainfo import keep_arttype
from lib.libs.pykodi import localize as L, log
from lib.libs.utils import SortedDisplay
from lib.providers import ProviderError
from lib.providerhealth import ProviderImageHostGuard

MAX_ERRORS = 3
TOO_MANY_ERRORS = 32031

class Gatherer(object):
    def __init__(self, monitor, languages):
        self.monitor = monitor
        self.languages = tuple(languages or ())
        providers.base.languages = self.languages
        self.providererrors = {}
        try:
            home_window = xbmcgui.Window(10000)
        except Exception:
            home_window = None
        self.imagehostguard = ProviderImageHostGuard(
            user_agent=settings.useragent,
            window=home_window,
            log_callback=lambda message: log(message, xbmc.LOGWARNING),
            trace_callback=lambda provider_name, host, reason, cached: runtrace.event(
                'gatherer', 'image host unavailable; provider candidates skipped',
                provider=provider_name, host=host, reason=reason, cached=cached))

    def set_languages(self, languages):
        self.languages = tuple(languages or ())
        providers.base.languages = self.languages

    def _sort_available_art(self, mediaitem):
        for arttype, imagelist in (getattr(mediaitem, 'availableart', {}) or {}).items():
            _sort_images(arttype, imagelist, mediaitem.sourcemedia, mediaitem.mediatype)

    def getartwork(self, mediaitem, fsonly=False, skipexisting=True, completion_callback=None):
        timer = time.time()
        services_hit, error = False, None
        mediaitem.forcedart = {}
        if mediaitem.protected_custom_set:
            mediaitem.availableart = {}
            return False, None
        if mediaitem.uniqueids:
            requested = mediaitem.missingart if skipexisting else None
            if not skipexisting or requested:
                mediaitem.availableart, error = self.get_external_artwork(
                    mediaitem.mediatype, mediaitem.seasons, mediaitem.uniqueids, requested,
                    completion_callback=completion_callback, mediaitem=mediaitem)
                services_hit = True
        if 'keyart' in mediaitem.availableart and (settings.titlefree_poster or
                not mediatypes.get_artinfo(mediaitem.mediatype, 'keyart')['autolimit']):
            mediaitem.availableart.setdefault('poster', []).extend(mediaitem.availableart['keyart'])
        self._sort_available_art(mediaitem)
        counts = dict((key, len(value or [])) for key, value in mediaitem.availableart.items())
        runtrace.event('gatherer', 'getartwork complete', mediatype=mediaitem.mediatype, dbid=mediaitem.dbid, label=mediaitem.label, services_hit=services_hit, counts=counts, elapsed_ms=int((time.time() - timer) * 1000), error=error)
        return services_hit, error

    def get_external_artwork(self, mediatype, seasons, uniqueids, missing=None, completion_callback=None, mediaitem=None):
        if mediatype == mediatypes.SEASON:
            return self._get_direct_season_external_artwork(seasons, uniqueids, missing, completion_callback=completion_callback, mediaitem=mediaitem)
        images, error = {}, None
        remaining = list(missing or ()) if missing is not None else None
        for provider in providers.external.get(mediatype, ()):
            errcount = self.providererrors.get(provider.name, 0)
            if errcount >= MAX_ERRORS:
                continue
            try:
                provider_timer = time.time()
                request_types = remaining if remaining is not None else missing
                providerimages = provider.get_images(uniqueids, request_types)
                providerimages = self.imagehostguard.filter_images(provider.name.display, providerimages)
                runtrace.provider_summary(provider.name.display, mediatype=mediatype, types=request_types, images=providerimages, elapsed_ms=int((time.time() - provider_timer) * 1000))
                self.providererrors[provider.name] = 0
            except Exception as ex:
                runtrace.provider_summary(provider.name.display, mediatype=mediatype, types=missing, images={}, elapsed_ms=0, error_text=repr(ex))
                errcount += 1
                self.providererrors[provider.name] = errcount
                if errcount == 1 or errcount == MAX_ERRORS:
                    error = {'providername': provider.name.display,
                             'message': getattr(ex, 'message', repr(ex)) if errcount == 1 else L(TOO_MANY_ERRORS)}
                if not isinstance(ex, ProviderError):
                    log('Error parsing provider response', xbmc.LOGWARNING)
                    log(traceback.format_exc(), xbmc.LOGWARNING)
                continue
            for arttype, artlist in providerimages.items():
                if arttype.startswith('season.'):
                    try:
                        if int(arttype.rsplit('.', 2)[1]) not in seasons:
                            continue
                    except ValueError:
                        continue
                images.setdefault(arttype, []).extend(artlist)
            if completion_callback and remaining is not None:
                try:
                    remaining = list(completion_callback(images) or ())
                    runtrace.event('gatherer', 'lazy provider checkpoint', provider=provider.name.display, remaining=remaining)
                    if not remaining:
                        break
                except Exception as ex:
                    runtrace.error('lazy provider checkpoint failed', ex, provider=provider.name.display)
            if self.monitor.abortRequested():
                break
        return images, error

    def _season_number_from_context(self, seasons, uniqueids):
        for season in sorted((seasons or {}).keys()):
            try:
                return int(season)
            except (TypeError, ValueError):
                continue
        for key in ('tmdbseason', 'tvdbseason'):
            value = uniqueids.get(key) if uniqueids else None
            if value and '/' in str(value):
                try:
                    return int(str(value).split('/')[-1])
                except (TypeError, ValueError):
                    pass
        return None

    def _direct_season_requested_types(self, season, missing):
        direct = list(missing or ())
        if not direct:
            direct = [arttype for arttype, cfg in mediatypes.artinfo[mediatypes.SEASON].items() if cfg.get('autolimit')]
        requested = []
        for arttype in direct:
            # Direct season art uses normal art names, while TV providers expose
            # those candidates as season.<number>.<arttype>.
            base = str(arttype).rstrip('0123456789')
            exact = 'season.{0}.{1}'.format(season, base)
            if exact not in requested:
                requested.append(exact)
        return requested

    def _get_direct_season_external_artwork(self, seasons, uniqueids, missing=None, completion_callback=None, mediaitem=None):
        season = self._season_number_from_context(seasons, uniqueids)
        if season is None:
            runtrace.event('gatherer', 'direct season artwork skipped: no season number', uniqueids=uniqueids)
            return {}, None
        requested = self._direct_season_requested_types(season, missing)
        images, error = {}, None
        remaining = list(missing or ()) if missing is not None else None
        prefix = 'season.{0}.'.format(season)
        for provider in providers.external.get(mediatypes.TVSHOW, ()):
            errcount = self.providererrors.get(provider.name, 0)
            if errcount >= MAX_ERRORS:
                continue
            try:
                provider_timer = time.time()
                request_types = self._direct_season_requested_types(season, remaining) if remaining is not None else requested
                providerimages = provider.get_images(uniqueids, request_types)
                providerimages = self.imagehostguard.filter_images(provider.name.display, providerimages)
                runtrace.provider_summary(provider.name.display, mediatype=mediatypes.SEASON, types=request_types, images=providerimages, elapsed_ms=int((time.time() - provider_timer) * 1000))
                self.providererrors[provider.name] = 0
            except Exception as ex:
                runtrace.provider_summary(provider.name.display, mediatype=mediatypes.SEASON, types=requested, images={}, elapsed_ms=0, error_text=repr(ex))
                errcount += 1
                self.providererrors[provider.name] = errcount
                if errcount == 1 or errcount == MAX_ERRORS:
                    error = {'providername': provider.name.display, 'message': getattr(ex, 'message', repr(ex)) if errcount == 1 else L(TOO_MANY_ERRORS)}
                if not isinstance(ex, ProviderError):
                    log('Error parsing provider response', xbmc.LOGWARNING)
                    log(traceback.format_exc(), xbmc.LOGWARNING)
                continue
            for arttype, artlist in (providerimages or {}).items():
                if not arttype.startswith(prefix):
                    continue
                directtype = arttype[len(prefix):]
                images.setdefault(directtype, []).extend(artlist or [])
            if completion_callback and remaining is not None:
                try:
                    remaining = list(completion_callback(images) or ())
                    runtrace.event('gatherer', 'lazy direct-season provider checkpoint', provider=provider.name.display, remaining=remaining)
                    if not remaining:
                        break
                except Exception as ex:
                    runtrace.error('lazy direct-season provider checkpoint failed', ex, provider=provider.name.display)
            if self.monitor.abortRequested():
                break
        return images, error


def _sort_images(basearttype, imagelist, mediasource, mediatype):
    # Deterministic order. 0.32.16 keeps the user's requested Design B for
    # fanart-style images: language/title-free first, provider second,
    # resolution bucket third, and provider/API gallery order inside each bucket.
    # Stable sort calls are intentionally applied from least-significant to
    # most-significant priority.
    imagelist.sort(key=lambda image: image.get('gallery_order', 999999))
    if basearttype.endswith('poster'):
        # Preserve gallery order, except for the localized primary poster returned
        # by the id-ID details endpoint. It is explicitly promoted for Indonesian
        # media while still using the /images row for real size/rating metadata.
        imagelist.sort(key=lambda image: bool(image.get('details_primary') or image.get('localized_primary')), reverse=True)
    if _uses_resolution_bucket(basearttype):
        imagelist.sort(key=lambda image: _resolution_bucket_sort(image, basearttype, mediatype))
    imagelist.sort(key=lambda image: mediatypes.provider_priority(image['provider'][0]), reverse=True)
    if basearttype == 'discart' and mediasource != 'unknown':
        imagelist.sort(key=lambda image: image.get('subtype', SortedDisplay('', '')).sort != mediasource)
    imagelist.sort(key=lambda image: _imagelanguage_sort(image, basearttype))



def _uses_resolution_bucket(basearttype):
    return basearttype.endswith('fanart') or basearttype.endswith('landscape') or basearttype.endswith('thumb')


def _minimum_resolution_for_arttype(basearttype, mediatype):
    if basearttype.endswith('fanart'):
        return getattr(settings, 'minimum_fanart_resolution', (1920, 1080))
    if basearttype.endswith('landscape'):
        return (1920, 1080)
    if basearttype.endswith('thumb'):
        return (1280, 720)
    return (0, 0)


def _image_dimensions(image):
    size = image.get('size', SortedDisplay(0, ''))
    display = (getattr(size, 'display', '') or '').lower().replace('×', 'x')
    parts = display.split('x')
    if len(parts) == 2:
        try:
            return int(float(parts[0])), int(float(parts[1]))
        except (TypeError, ValueError):
            pass
    # Fallback for providers that only expose a single sortable dimension.
    try:
        sortsize = int(getattr(size, 'sort', 0) or 0)
    except (TypeError, ValueError):
        sortsize = 0
    return sortsize, 0


def _resolution_bucket_sort(image, basearttype, mediatype):
    min_width, min_height = _minimum_resolution_for_arttype(basearttype, mediatype)
    if not min_width and not min_height:
        bucket = 0
    else:
        width, height = _image_dimensions(image)
        if min_height:
            bucket = 0 if width >= min_width and height >= min_height else 1
        else:
            bucket = 0 if width >= min_width else 1
    # Within the same language/provider group, this only separates preferred
    # resolution from fallback resolution. The original provider/gallery order is
    # preserved inside each bucket.
    return bucket

def _size_sort(image):
    imagesplit = image.get('size', SortedDisplay(0, '')).display.split('x')
    if len(imagesplit) != 2:
        return image.get('size', SortedDisplay(0, '')).sort // 200
    try:
        imagesize = int(imagesplit[0]), int(imagesplit[1])
    except ValueError:
        return image.get('size', SortedDisplay(0, '')).sort // 200
    if imagesize[0] > settings.preferredsize[0]:
        shrink = settings.preferredsize[0] / float(imagesize[0])
        imagesize = settings.preferredsize[0], imagesize[1] * shrink
    if imagesize[1] > settings.preferredsize[1]:
        shrink = settings.preferredsize[1] / float(imagesize[1])
        imagesize = imagesize[0] * shrink, settings.preferredsize[1]
    return int(max(imagesize) // 200)


def _imagelanguage_sort(image, basearttype):
    language = image.get('language')
    languages = providers.base.languages
    if language in languages:
        primary = languages.index(language)
    else:
        primary = len(languages) + 1
    # Prefer title-free backdrops for fanart. For posters, language-specific title art wins
    # unless the user explicitly requests title-free posters.
    if language and basearttype.endswith('fanart') and settings.titlefree_fanart:
        primary += len(languages) + 1
    if language and basearttype.endswith('poster') and settings.titlefree_poster:
        primary += len(languages) + 1
    return primary, language or ''

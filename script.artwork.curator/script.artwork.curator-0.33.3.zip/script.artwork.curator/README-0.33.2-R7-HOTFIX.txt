Library Artwork Curator 0.33.2 - R7 hotfix
=============================================

Fixes two packaging defects in 0.33.1:
1. default.py still imported lib.maintenance after that legacy module was removed.
2. Empty string settings lacked allowempty=true and were rejected by Kodi 22.

The artwork database is not migrated, rebuilt, or deleted. Active DBID handoff,
DBID reuse validation, provider fallback, and atomic writes remain unchanged.

Existing saved settings that contain old display labels may still be rejected by
Kodi. Close Kodi and remove only addon_data/script.artwork.curator/settings.xml
to reset those preferences. Keep artwork-cache.db.

Library Artwork Curator 0.33.1 - R7 Fresh-Install Baseline

- Creates the final artwork schema directly and rejects unsupported schemas.
- Contains no title-specific TWD/Miko/FTWD repair, collision history, old layout
  migration, persistent processed-items database, or old queue compatibility.
- Keeps exact scan DBID delta, DBID-reuse validation, active artwork handoff,
  current provider fallback, generated local thumbnails, diagnostics, and transactions.
- Uses the new Library Artwork Scraper icon supplied for the MrGee family.

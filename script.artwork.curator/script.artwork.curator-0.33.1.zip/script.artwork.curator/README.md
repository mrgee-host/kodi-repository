# Library Artwork Curator 0.33.1

MrGee Kodi Family R6 clean baseline.

- Fresh installations create the final database schema directly.
- Startup auto-fill uses only the exact Kodi scan DBID delta.
- When the same media is replaced and receives a new DBID, active DBID handoff preserves valid artwork without provider scraping.
- Provider fallback, identity validation, online-first episode thumbnails, local-video thumbnail fallback, atomic writes, reports, and diagnostics remain active.
- Historical schema migrations, title-specific repairs, collision-repair jobs, and OnUpdate/cache fallback detection are not included.

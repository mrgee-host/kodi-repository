# Artwork Curator 0.32.5 DB-first

- Final DB-first workflow: artwork-cache.db is the control source; Kodi DB is the display target.
- Final tables: metadata, library_items, artwork, runs, run_items.
- artwork replaces old artwork_slots + artwork_status.
- No bundled DB. Install the supplied DB manually.
- No DB migration/fixing logic is bundled.

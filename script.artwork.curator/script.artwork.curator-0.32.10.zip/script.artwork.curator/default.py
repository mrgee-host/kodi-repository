import sys
import xbmc
import xbmcgui
from itertools import chain

from lib import cleaner, reporting, refreshdebug, diagnostics, runtrace, maintenance, artworkdb
from lib.artworkprocessor import ArtworkProcessor
from lib.filemanager import FileManager
from lib.libs import mediainfo as info, mediatypes, pykodi, quickjson, utils
from lib.libs.addonsettings import settings
from lib.libs.pykodi import log
from lib.providers import search

REMOTE_HOST_MARKERS = ('image.tmdb.org', 'fanart.tv', 'thetvdb.com', 'theposterdb.com', 'images.theposterdb.com')


def main():
    settings.update_settings()
    mediatypes.update_settings()
    command = get_command()
    runtrace.event('menu', 'default.py invoked', argv=sys.argv[1:], command=command)
    if command.get('dbid') and command.get('mediatype'):
        with runtrace.run_context('command.process_item', mediatype=command['mediatype'], dbid=command['dbid'], mode=command.get('mode', 'auto')):
            ArtworkProcessor().process_item(command['mediatype'], int(command['dbid']), command.get('mode', 'auto'))
        return
    if command.get('command') == 'show_artwork_log':
        runtrace.event('menu', 'show artwork log command')
        show_artwork_log()
        return

    processor = ArtworkProcessor()
    if processor.processor_busy:
        options = [('Stop current process', 'NotifyAll(script.artwork.curator:control, CancelCurrent)')]
    else:
        options = [
            ('Refresh all artwork', confirm_refresh_all_artwork),
            ('Fill missing artwork', confirm_fill_missing_artwork),
            ('Cache missing artwork', lambda: cache_artwork(False)),
            ('Refresh Indonesian movie artwork', refresh_indonesian_artwork),
            ('Maintenance tools', maintenance_tools),
            ('View status', show_artwork_log),
            ('Export diagnostics ZIP', diagnostics.export),
            ('Settings', lambda: pykodi.get_main_addon().openSettings()),
        ]
    selected = xbmcgui.Dialog().select('Library Artwork Curator', [label for label, _ in options])
    runtrace.event('menu', 'main selection', selected=selected, option=options[selected][0] if 0 <= selected < len(options) else '<cancel>')
    if 0 <= selected < len(options):
        label, action = options[selected]
        if isinstance(action, str):
            runtrace.event('menu', 'execute builtin', label=label, builtin=action)
            pykodi.execute_builtin(action)
        elif label == 'Export diagnostics ZIP' or action == diagnostics.export:
            runtrace.event('menu', 'export diagnostics selected')
            action()
        else:
            with runtrace.run_context('menu.' + label):
                action()


def add_missing_for():
    # Compatibility wrapper retained for old skin/context calls. Main menu now calls Scrape missing directly.
    pykodi.execute_builtin('NotifyAll(script.artwork.curator:control, ProcessAllVideosManual)')


def maintenance_tools():
    options = [
        ('Reset N/A artwork status', reset_na_status),
        ('Clear run history', clear_run_history),
        ('Texture cache tools', texture_cache_tools),
    ]
    selected = xbmcgui.Dialog().select('Library Artwork Curator: Maintenance tools', [label for label, _ in options])
    if 0 <= selected < len(options):
        options[selected][1]()


def texture_cache_tools():
    options = [
        ('Prune obsolete cache', prune_obsolete_cache),
        ('Force recache all artwork', lambda: cache_artwork(True)),
        ('Cache actor thumbnails', cache_actor_thumbnails),
    ]
    selected = xbmcgui.Dialog().select('Library Artwork Curator: Texture cache tools', [label for label, _ in options])
    if 0 <= selected < len(options):
        options[selected][1]()


def reset_na_status():
    count = __import__('lib.artworkdb', fromlist=['reset_na']).reset_na()
    xbmcgui.Dialog().notification('Library Artwork Curator', 'Reset {0} N/A artwork status rows.'.format(count), xbmcgui.NOTIFICATION_INFO, 6000)


def clear_run_history():
    if not xbmcgui.Dialog().yesno(
        'Clear run history?',
        'This will remove old run logs from the Library Artwork Curator DB.\n\nArtwork data, URLs, N/A, MANUAL, and PROTECTED status will not be deleted.',
        'Cancel',
        'Clear runs'
    ):
        return
    runs, run_items = artworkdb.clear_run_history()
    xbmcgui.Dialog().notification('Library Artwork Curator', 'Cleared {0} runs and {1} run items.'.format(runs, run_items), xbmcgui.NOTIFICATION_INFO, 6000)


def cache_actor_thumbnails():
    if not settings.actor_thumb_cache:
        xbmcgui.Dialog().notification('Library Artwork Curator', 'Actor thumbnail cache is disabled in settings.', xbmcgui.NOTIFICATION_INFO, 6000)
        return
    xbmcgui.Dialog().notification('Library Artwork Curator', 'Actor thumbnail cache will be handled as a separate beta step.', xbmcgui.NOTIFICATION_INFO, 8000)


def show_indonesian_refresh_log():
    xbmcgui.Dialog().textviewer('Library Artwork Curator - Indonesian movie refresh log', refreshdebug.get_text())


def refresh_indonesian_artwork():
    confirm = xbmcgui.Dialog().yesno(
        'Refresh Indonesian movie artwork',
        'Re-check artwork for movies inside the Indonesian Movies collection folder?\n\n'
        'TV shows, seasons, episodes, and movie sets use the common flow. '
        'Existing TPDb or other manually chosen non-curator URLs will be preserved.',
        'Cancel',
        'Refresh'
    )
    if not confirm:
        return

    refreshdebug.reset()
    refreshdebug.important('START Refresh Indonesian movie artwork')
    refreshdebug.write('Accepted path markers: {0}'.format(', '.join(info.INDO_PATH_MARKERS)))
    items = []
    scan_counts = {'movie': 0}
    included_counts = {'movie': 0}

    def inspect_row(row):
        mediaitem = info.MediaItem(row)
        scan_counts['movie'] += 1
        included = bool(mediaitem.indonesia_hint)
        refreshdebug.write(
            'SCAN movie:{0} | included={1} | label={2} | file={3}'.format(
                mediaitem.dbid, included, mediaitem.label, mediaitem.file or '-'
            )
        )
        if included:
            included_counts['movie'] += 1
            items.append(mediaitem)

    if not mediatypes.disabled(mediatypes.MOVIE):
        for row in quickjson.get_item_list(mediatypes.MOVIE):
            inspect_row(row)

    refreshdebug.important('SCAN COUNTS: {0}'.format(scan_counts))
    refreshdebug.important('INCLUDED COUNTS: {0}'.format(included_counts))
    refreshdebug.important('TOTAL INCLUDED: {0}'.format(len(items)))

    if not items:
        xbmcgui.Dialog().notification('Library Artwork Curator', 'No Indonesian movies were found.', xbmcgui.NOTIFICATION_INFO)
        return

    success = ArtworkProcessor().process_medialist(
        items,
        alwaysnotify=True,
        foreground=False,
        force_progress=True,
        refresh_indonesian=True,
    )
    refreshdebug.important('END Refresh Indonesian movie artwork | success={0}'.format(success))



def _elapsed_text(ms):
    try: ms = int(ms or 0)
    except Exception: ms = 0
    if ms < 1000: return '%d ms' % ms
    sec = int(round(ms / 1000.0))
    if sec < 60: return '%ds' % sec
    minutes, sec = divmod(sec, 60)
    if minutes < 60: return '%dm %02ds' % (minutes, sec)
    hours, minutes = divmod(minutes, 60)
    return '%dh %02dm %02ds' % (hours, minutes, sec)


def _display_title_from_row(row, mediatype):
    label = (row.get('label') or row.get('title') or mediatype or 'UNKNOWN ITEM').upper()
    if mediatype == mediatypes.EPISODE:
        show = (row.get('showtitle') or '').upper()
        try:
            return '{0} - S{1:02d}E{2:02d}'.format(show or label, int(row.get('season') or 0), int(row.get('episode') or 0)).strip(' -')
        except Exception:
            return '{0} - {1}'.format(show, label) if show else label
    if mediatype == mediatypes.SEASON and row.get('showtitle'):
        try:
            return '{0} - SEASON {1:02d}'.format(row.get('showtitle').upper(), int(row.get('season') or 0))
        except Exception:
            return '{0} - {1}'.format(row.get('showtitle').upper(), label)
    return label


def _fit_line(line, maxlen=68):
    if len(line) <= maxlen:
        return line
    parts = line.split(' - ')
    if len(parts) >= 3:
        counter = parts[0]
        phase = parts[-1]
        title = ' - '.join(parts[1:-1])
        allowance = maxlen - len(counter) - len(phase) - 9
        if allowance > 14:
            return '{0} - {1}... - {2}'.format(counter, title[:allowance], phase)
    return line[:maxlen-3] + '...'


def _notify_line(done, total, title, phase, arttypes=(), percent=None):
    if percent is None:
        try:
            percent = int(done * 100 / float(total or 1))
        except Exception:
            percent = 0
    line = '{0}/{1} - {2} - {3} ARTWORK'.format(done, total, title or 'UNKNOWN ITEM', phase)
    return _fit_line(line)


def confirm_refresh_all_artwork():
    groups = list(iter_video_lists(include_sets=True))
    lines = ['This will recheck enabled artwork for all enabled library items.', '', 'Items:']
    total = 0
    for label, list_fn, mediatype in groups:
        if mediatypes.disabled(mediatype):
            continue
        try:
            count = len(list_fn())
        except Exception:
            count = 0
        total += count
        lines.append('{0}: {1}'.format(label, count))
    if not xbmcgui.Dialog().yesno('Refresh all artwork?', '\n'.join(lines), 'Cancel', 'Refresh all'):
        return
    pykodi.execute_builtin('NotifyAll(script.artwork.curator:control, ProcessRefreshAllArtworkManual)')


def confirm_fill_missing_artwork():
    groups = list(iter_video_lists(include_sets=True))
    lines = ['This will scan enabled library items using Library Artwork Curator DB as the source of truth.',
             'Rows marked MISSING/ERROR/RETRY or missing from DB will be searched.',
             'N/A, MANUAL, and PROTECTED rows will be skipped.', '', 'Items:']
    total = 0
    for label, list_fn, mediatype in groups:
        if mediatypes.disabled(mediatype):
            continue
        try:
            count = len(list_fn())
        except Exception:
            count = 0
        total += count
        lines.append('{0}: {1}'.format(label, count))
    if not xbmcgui.Dialog().yesno('Fill missing artwork?', '\n'.join(lines), 'Cancel', 'Fill missing'):
        return
    pykodi.execute_builtin('NotifyAll(script.artwork.curator:control, ProcessAllVideosManual)')


def iter_video_lists(include_sets=True):
    base = (
        ('Movie sets', lambda: quickjson.get_item_list(mediatypes.MOVIESET), mediatypes.MOVIESET),
        ('Movies', lambda: quickjson.get_item_list(mediatypes.MOVIE), mediatypes.MOVIE),
        ('TV shows', quickjson.get_tvshows, mediatypes.TVSHOW),
        ('Seasons', quickjson.get_seasons, mediatypes.SEASON),
        ('Episodes', quickjson.get_episodes, mediatypes.EPISODE),
    )
    return base if include_sets else tuple(row for row in base if row[2] != mediatypes.MOVIESET)


def _progress_update(progress, percent, message, heading=''):
    percent = max(0, min(100, int(percent)))
    try:
        # DialogProgressBG: percent, heading, message. This is the compact
        # persistent Kodi notification used by the original Library Artwork Curator.
        progress.update(percent, heading, message)
    except TypeError:
        progress.update(percent, message)


def _compact_arttypes(arttypes, maximum=4):
    clean = []
    for arttype in arttypes or ():
        value = str(arttype or '').strip()
        if value and value not in clean:
            clean.append(value)
    if not clean:
        return ''
    shown = clean[:maximum]
    result = ','.join(shown)
    if len(clean) > maximum:
        result += ' +{0}'.format(len(clean) - maximum)
    return result


def _titles_by_url(artmap):
    result = {}
    for key, url in artmap.items():
        parts = str(key).split(':')
        title = parts[1] if len(parts) > 2 else 'UNKNOWN ITEM'
        result.setdefault(url, title)
    return result


def _arttypes_by_url(artmap):
    reverse = {}
    for key, url in artmap.items():
        arttype = str(key).rsplit(':', 1)[-1]
        reverse.setdefault(url, [])
        if arttype not in reverse[url]:
            reverse[url].append(arttype)
    return reverse


def _status_heading(action, arttypes=()):
    types = _compact_arttypes(arttypes)
    return 'Library Artwork Curator: {0}{1}'.format(action, ' · ' + types if types else '')


def _progress_cancelled(progress):
    checker = getattr(progress, 'iscanceled', None)
    return bool(checker and checker())


def _set_idle_inhibition(enabled):
    state = 'true' if enabled else 'false'
    pykodi.execute_builtin('InhibitScreensaver({0})'.format(state))
    pykodi.execute_builtin('InhibitIdleShutdown({0})'.format(state))


def collect_video_art(progress=None, include_sets=True, mediatype_filter=None):
    timer = __import__('time').time()
    artmap = {}
    seen_urls = set()
    groups = list(iter_video_lists(include_sets=include_sets))
    if mediatype_filter:
        groups = [row for row in groups if row[2] in mediatype_filter]
    for index, (label, list_fn, mediatype) in enumerate(groups):
        if progress and _progress_cancelled(progress):
            break
        _progress_update(progress, int(index * 20 / float(len(groups) or 1)),
            'COLLECTING LIBRARY ARTWORK', 'Library Artwork Curator') if progress else None
        for item in list_fn():
            title = _display_title_from_row(item, mediatype).replace(':', ' ')
            for arttype, url in item.get('art', {}).items():
                if arttype == 'icon' or not url:
                    continue
                url = pykodi.unquoteimage(url)
                lower = (url or '').lower()
                if not url or url in seen_urls or 'defaultvideo.png' in lower or 'defaultplaylist.png' in lower or 'defaultfolder.png' in lower:
                    continue
                if url.startswith(('http://', 'https://', 'image://')):
                    artmap['{0}:{1}:{2}'.format(len(artmap), title, arttype)] = url
                    seen_urls.add(url)
    runtrace.event('library', 'collect_video_art complete', urls=len(artmap), elapsed_ms=int((__import__('time').time() - timer) * 1000))
    return artmap


def cache_artwork(force=False):
    runtrace.event('cache', 'cache_artwork start', force=force)
    heading = 'Force recache all artwork' if force else 'Cache missing artwork'
    if force and not xbmcgui.Dialog().yesno('Library Artwork Curator',
            'Remove the current texture-cache entries for all video artwork and cache them again?'):
        return
    progress = xbmcgui.DialogProgressBG()
    _set_idle_inhibition(True)
    progress.create('Library Artwork Curator: ' + heading, '')
    cancelled = False
    try:
        artmap = collect_video_art(progress)
        total_urls = len(set(artmap.values()))
        _progress_update(progress, 20, '0/{0} - CACHE ARTWORK'.format(total_urls), 'Library Artwork Curator')
        types_by_url = _arttypes_by_url(artmap)
        titles_by_url = _titles_by_url(artmap)
        if _progress_cancelled(progress):
            cancelled = True
            return
        fileman = FileManager(False, True)
        if not fileman.imagecachebase:
            xbmcgui.Dialog().notification('Library Artwork Curator', 'Enable Kodi web server / remote control via HTTP first.', xbmcgui.NOTIFICATION_WARNING)
            return
        if force:
            urls = sorted(set(artmap.values()))
            total = len(urls)
            for index, url in enumerate(urls, 1):
                if _progress_cancelled(progress):
                    cancelled = True
                    return
                _progress_update(progress, 20 + int(index * 20 / float(total or 1)),
                    _notify_line(index, total, titles_by_url.get(url, 'UNKNOWN ITEM'), 'REMOVING CACHE'), 'Library Artwork Curator')
                quickjson.remove_texture_byurl(url)
            fileman.alreadycached = []

        def on_cache_progress(done, total, url):
            base = 40 if force else 20
            span = 60 if force else 80
            _progress_update(progress, base + int(done * span / float(total or 1)),
                _notify_line(done, total, titles_by_url.get(url, 'UNKNOWN ITEM'), 'CACHE'), 'Library Artwork Curator')

        count = fileman.cachefor(
            artmap,
            multiplethreads=True,
            progress_callback=on_cache_progress,
            cancel_callback=lambda: _progress_cancelled(progress),
        )
        cancelled = _progress_cancelled(progress)
        if not cancelled:
            _progress_update(progress, 100, 'CACHE ARTWORK FINISHED - {0} CHECKED - {1} CACHED - 0 ERRORS'.format(len(set(artmap.values())), count), 'Library Artwork Curator')
            xbmc.sleep(300)
    finally:
        progress.close()
        _set_idle_inhibition(False)
    if cancelled:
        xbmcgui.Dialog().notification('Library Artwork Curator', 'CACHE ARTWORK CANCELLED', xbmcgui.NOTIFICATION_WARNING, 6000)
    else:
        xbmcgui.Dialog().notification('Library Artwork Curator', 'CACHE ARTWORK FINISHED - {0} CHECKED - {1} CACHED - 0 ERRORS'.format(len(set(artmap.values())), count), xbmcgui.NOTIFICATION_INFO, 6000)


def prune_obsolete_cache():
    runtrace.event('cache', 'prune_obsolete_cache start')
    if not xbmcgui.Dialog().yesno('Library Artwork Curator',
            'Remove cached TMDb, fanart.tv, and TheTVDB images that are no longer referenced by the video library?'):
        return
    progress = xbmcgui.DialogProgressBG()
    _set_idle_inhibition(True)
    progress.create('Library Artwork Curator: Pruning obsolete remote cache', '')
    cancelled = False
    removed = 0
    try:
        video_types = (mediatypes.MOVIESET, mediatypes.MOVIE, mediatypes.TVSHOW, mediatypes.SEASON, mediatypes.EPISODE)
        active_artmap = collect_video_art(progress, include_sets=True, mediatype_filter=video_types)
        active = set(active_artmap.values())
        types_by_url = _arttypes_by_url(active_artmap)
        titles_by_url = _titles_by_url(active_artmap)
        textures = quickjson.get_textures()
        total = len(textures)
        for index, texture in enumerate(textures, 1):
            if _progress_cancelled(progress):
                cancelled = True
                break
            url = pykodi.unquoteimage(texture.get('url', ''))
            _progress_update(progress, 20 + int(index * 80 / float(total or 1)),
                _notify_line(index, total, titles_by_url.get(url, 'OBSOLETE ARTWORK'), 'PRUNE CACHE'), 'Library Artwork Curator')
            if not url.startswith(('http://', 'https://')):
                continue
            lower = url.lower()
            if lower.startswith(('resource://', 'special://', 'plugin://')) or 'blur' in lower or 'skin.' in lower:
                continue
            if not any(host in lower for host in REMOTE_HOST_MARKERS):
                continue
            if url not in active:
                quickjson.remove_texture(texture['textureid'])
                removed += 1
        if not cancelled:
            _progress_update(progress, 100, 'PRUNE CACHE FINISHED - {0} REMOVED - 0 ERRORS'.format(removed), 'Library Artwork Curator')
            xbmc.sleep(300)
    finally:
        progress.close()
        _set_idle_inhibition(False)
    if cancelled:
        xbmcgui.Dialog().notification('Library Artwork Curator', 'PRUNE CACHE CANCELLED', xbmcgui.NOTIFICATION_WARNING, 6000)
    else:
        xbmcgui.Dialog().notification('Library Artwork Curator', 'PRUNE CACHE FINISHED - {0} REMOVED - 0 ERRORS'.format(removed), xbmcgui.NOTIFICATION_INFO, 6000)

def remove_specific_arttypes():
    runtrace.event('menu', 'remove_specific_arttypes start')
    groups = list(iter_video_lists())
    selected = xbmcgui.Dialog().select('Choose video content type', [row[0] for row in groups])
    if selected < 0:
        return
    label, list_fn, mediatype = groups[selected]
    items = list_fn()
    counter = {}
    for item in items:
        for arttype, url in item.get('art', {}).items():
            if '.' not in arttype:
                counter[arttype] = counter.get(arttype, 0) + 1
    options = ['* all'] + sorted(counter)
    picked = xbmcgui.Dialog().select(label, ['{0}: {1}'.format(t, len(items) if t == '* all' else counter[t]) for t in options])
    if picked < 0:
        return
    arttype = options[picked]
    if not xbmcgui.Dialog().yesno('Library Artwork Curator', 'Remove {0} artwork from {1}?'.format(arttype, label)):
        return
    changed = 0
    for row in items:
        mediaitem = info.MediaItem(row)
        updates = cleaner.remove_specific_arttype(mediaitem, arttype)
        if updates:
            info.update_art_in_library(mediaitem.mediatype, mediaitem.dbid, updates)
            changed += len(updates)
    xbmcgui.Dialog().ok('Library Artwork Curator', 'Removed {0} artwork references.'.format(changed))


def identify_unmatched_sets():
    runtrace.event('menu', 'identify_unmatched_sets start')
    from lib.libs.processeditems import ProcessedItems
    processed = ProcessedItems()
    sets = quickjson.get_item_list(mediatypes.MOVIESET)
    unmatched = [row for row in sets if not processed.get_data(row['setid'], mediatypes.MOVIESET, row['label'])]
    if not unmatched:
        xbmcgui.Dialog().notification('Library Artwork Curator', 'No unmatched movie sets.')
        return
    selected = xbmcgui.Dialog().select('Choose movie set', [row['label'] for row in unmatched])
    if selected < 0:
        return
    mediaitem = info.MediaItem(unmatched[selected])
    processor = ArtworkProcessor()
    if processor.manual_id(mediaitem):
        processor.process_item(mediatypes.MOVIESET, mediaitem.dbid, 'auto')


def show_artwork_log():
    xbmcgui.Dialog().textviewer('Library Artwork Curator - latest report', reporting.get_latest_report())


def get_command():
    command = {}
    for argument in sys.argv[1:]:
        key, sep, value = argument.partition('=')
        command[key.strip().lower()] = value.strip() if sep else True
    return command

if __name__ == '__main__':
    main()

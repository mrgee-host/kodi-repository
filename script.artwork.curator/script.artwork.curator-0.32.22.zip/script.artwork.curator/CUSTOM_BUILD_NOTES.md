# Library Artwork Curator 0.32.21

Custom fixes in this build:

- Season fanart is intentionally ignored. Season items now manage poster, banner, landscape, thumb, and keyart only.
- Removed season fanart from provider mapping and UI/dry-run/refresh targets so season dry-run will not show fanart as expected missing art.

- Auto artwork selection now uses one low-resolution fallback only when no candidate meets the preferred minimum resolution.
  - Fanart: if at least one candidate meets Minimum fanart resolution, only those candidates are used.
  - Fanart: if none meet the minimum, exactly one best lower-resolution fallback is selected; remaining fanart slots become N/A.
  - Landscape: if no 1920x1080 candidate exists, exactly one best lower-resolution fallback is selected.
  - Thumb: if no 1280x720 candidate exists, exactly one best lower-resolution fallback is selected.
- Season artwork targets now include keyart.
- Direct season provider path can request season keyart from TV providers.
- TV-show-level season artwork is no longer used when Include seasons is ON; the direct season pass decides final season artwork. This keeps Refresh All behavior clearer: TV shows handle show art, seasons handle season art.
- Provider order remains TMDb -> fanart.tv -> TheTVDB.
- Fanart Design B remains active: language/no-text -> provider -> resolution bucket -> gallery order.

No DB schema migration is required.


## 0.32.22

- Kept the confirmed decision to not add derived season fanart.
- Added Kodi generated video thumb fallback for movies/episodes when no remote thumb candidate is available.
  - Remote provider thumb still wins first.
  - One low-res remote fallback still wins before generated thumb.
  - Generated fallback uses Kodi `image://video@.../` URLs and is recorded as Kodi source.
- Added visible setting: `Use Kodi generated video thumb when no remote thumb is available` (default ON).
- Added primary TMDb provider error guard for normal scan/Refresh All.
  - If TMDb fails with a provider/connection error, the item is skipped and reported as error/retry instead of being overwritten by fallback-only provider results.
- Kept 0.32.20/0.32.21 artwork rules: one low-res fallback for fanart/landscape/thumb, season keyart, direct season final pass, provider order TMDb -> fanart.tv -> TheTVDB.

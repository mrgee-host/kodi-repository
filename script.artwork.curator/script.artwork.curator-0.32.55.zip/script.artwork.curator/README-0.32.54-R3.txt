LAC 0.32.54
- Episodes retain their full video file path instead of the TV-show folder.
- Malformed generated folder thumbnails are treated as missing.
- Generated thumbnails require a real local video and skip STRM.
- Prune progress says checking unused textures.
- Legacy runtime/diagnostics contents are removed after validated export.
- Notification maximum remains 58 characters.

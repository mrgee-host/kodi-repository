script.artwork.curator 0.32.55 - R4

MrGee Kodi Family R4 runtime and consistency fixes.

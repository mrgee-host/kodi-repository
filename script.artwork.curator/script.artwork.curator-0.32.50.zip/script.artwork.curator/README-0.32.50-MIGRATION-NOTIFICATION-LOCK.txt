Library Artwork Curator 0.32.50

- Migrates artwork-cache rows to replacement Kodi DBIDs before provider lookup.
- Supports path, filename, drive, and extension changes when media identity is unchanged.
- Reuses existing artwork URLs and Kodi texture cache; complete migrations skip providers.
- Keeps partial migrations in missing-only processing.
- AF3-safe progress: 65 characters full, otherwise word-safe 64-character output with Unicode ellipsis.
- Reports migrated and scraped counts separately for automatic runs.
- Shared LRS/LAC lock has a 30-second heartbeat, fast stale recovery, and throttled wait logging.
- Fill Missing performs a local DB-first candidate pass, so visible progress counts only actionable items.
- Last-run error count now uses terminal item failures, not recovered provider warnings.
- Old season rows can upgrade identity metadata without discarding valid artwork.

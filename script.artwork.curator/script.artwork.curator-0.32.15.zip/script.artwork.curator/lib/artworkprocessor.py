import os
import random
import re
import traceback
import xbmc
import xbmcgui
from datetime import timedelta

from lib import cleaner, reporting, refreshdebug, runtrace, artworkdb
from lib.artworkselection import prompt_for_artwork
from lib.filemanager import FileManager
from lib.gatherer import Gatherer
from lib.libs import mediainfo as info, mediatypes, pykodi, quickjson
from lib.libs.addonsettings import (settings, PROGRESS_DISPLAY_FULLPROGRESS,
    PROGRESS_DISPLAY_NONE, EXCLUSION_PATH_TYPE_FOLDER, EXCLUSION_PATH_TYPE_PREFIX,
    EXCLUSION_PATH_TYPE_REGEX)
from lib.libs.pykodi import datetime_now, localize as L, log
from lib.libs.utils import SortedDisplay, natural_sort, get_simpledict_updates
from lib.providers import search

MODE_AUTO = 'auto'
MODE_GUI = 'gui'
MODE_DEBUG = 'debug'
MODE_DRYRUN = 'dryrun'
THROTTLE_TIME = 0.02

SOMETHING_MISSING = 32001
FINAL_MESSAGE = 32019
ADDING_ARTWORK_MESSAGE = 32020
NOT_AVAILABLE_MESSAGE = 32021
ARTWORK_UPDATED_MESSAGE = 32022
NO_ARTWORK_UPDATED_MESSAGE = 32023
NOT_SUPPORTED_MESSAGE = 32025
CURRENT_ART = 13512
ENTER_COLLECTION_NAME = 32057
NO_IDS_MESSAGE = 32030
FILENAME_ENCODING_ERROR = 32040

CURATOR_REMOTE_HOST_MARKERS = ('image.tmdb.org', 'fanart.tv', 'thetvdb.com')

class ArtworkProcessor(object):
    """Video-only, remote-only artwork processor.

    This fork intentionally has no music library, music-video, NFO, filesystem-art,
    artwork download, or extrafanart-folder workflow.
    """
    def __init__(self, monitor=None):
        self.monitor = monitor or xbmc.Monitor()
        self.autolanguages = ()
        self.current_languages = ()
        self.progress = None
        self.progress_foreground = False
        self.cancelled = False
        self.visible = False
        self.processed = artworkdb.ProcessedItemsAdapter()
        self.gatherer = None
        self.downloader = None
        self.chunkcount = 1
        self.currentchunk = 0
        self.current_item_index = 0
        self.current_item_total = 1
        self.debug = False
        self.idle_inhibited = False
        self.refresh_indonesian = False
        self.db_run_id = None
        self.refresh_all_artwork = False
        self.item_error_count = 0
        self._last_process_aborted = False
        self.last_summary = {}
        settings.update_settings()
        mediatypes.update_settings()

    def create_progress(self, foreground=False, force=False):
        if not self.visible and (force or settings.progressdisplay == PROGRESS_DISPLAY_FULLPROGRESS):
            self.progress_foreground = bool(foreground)
            self.progress = xbmcgui.DialogProgress() if foreground else xbmcgui.DialogProgressBG()
            if foreground:
                self.progress.create('Library Artwork Curator', L(ADDING_ARTWORK_MESSAGE))
            else:
                self.progress.create('Library Artwork Curator: ' + L(ADDING_ARTWORK_MESSAGE), '')
            self.visible = True

    def update_progress(self, percent, message, heading=None):
        if self.chunkcount > 1:
            onechunk = 100 / float(self.chunkcount)
            percent = int(onechunk * self.currentchunk + percent / float(self.chunkcount))
        if self.visible:
            if self.progress_foreground:
                try:
                    self.progress.update(percent, message)
                except TypeError:
                    self.progress.update(percent, heading or '', message)
                if self.progress.iscanceled():
                    self.cancelled = True
            else:
                self.progress.update(percent, heading or '', message)

    @staticmethod
    def _compact_arttypes(arttypes, maximum=4):
        order = ['poster', 'fanart', 'extrafanart', 'landscape', 'banner', 'thumb', 'clearlogo', 'logo', 'clearart', 'keyart', 'discart', 'characterart']
        clean = []
        for arttype in arttypes or ():
            value = str(arttype or '').strip()
            if not value:
                continue
            base = value.rstrip('0123456789')
            if base == 'fanart' and value != 'fanart':
                value = 'extrafanart'
            if value not in clean:
                clean.append(value)
        clean.sort(key=lambda value: order.index(value.rstrip('0123456789')) if value.rstrip('0123456789') in order else 99)
        if not clean:
            return ''
        shown = clean[:maximum]
        result = ','.join(v.upper() for v in shown)
        if len(clean) > maximum:
            result += ',+{0}'.format(len(clean) - maximum)
        return result

    def _display_title(self, mediaitem):
        title = (getattr(mediaitem, 'label', '') or '').upper()
        if mediaitem.mediatype == mediatypes.EPISODE:
            show = (getattr(mediaitem, 'showtitle', '') or '').upper()
            try:
                return '{0} - S{1:02d}E{2:02d}'.format(show or title, int(mediaitem.season or 0), int(mediaitem.episode or 0)).strip(' -')
            except Exception:
                return show or title
        if mediaitem.mediatype == mediatypes.SEASON and getattr(mediaitem, 'showtitle', ''):
            try:
                return '{0} - SEASON {1:02d}'.format(mediaitem.showtitle.upper(), int(getattr(mediaitem, 'season', 0) or 0))
            except Exception:
                return '{0} - {1}'.format(mediaitem.showtitle.upper(), title)
        return title

    def _phase_name(self, action):
        if self.refresh_indonesian:
            return 'INDONESIAN'
        if self.refresh_all_artwork:
            return 'REFRESH ARTWORK'
        mapping = {
            'Missing': 'FILL MISSING ARTWORK',
            'Adding': 'FILL MISSING ARTWORK',
            'Searching': 'FILL MISSING ARTWORK',
            'Selecting': 'FILL MISSING ARTWORK',
            'Checking': 'FILL MISSING ARTWORK',
            'Reading': 'FILL MISSING ARTWORK',
            'Done': 'FILL MISSING ARTWORK',
            'Skipping': 'FILL MISSING ARTWORK',
            'Applying': 'FILL MISSING ARTWORK',
            'Error': 'FILL MISSING ARTWORK',
            'Cleaning': 'CLEAN ARTWORK',
            'Downloading': 'CACHE',
        }
        return mapping.get(action, str(action or '').upper())

    def _fit_line(self, line, maxlen=58):
        if len(line) <= maxlen:
            return line
        parts = line.split(' - ')
        if len(parts) >= 2:
            counter = parts[0]
            title = ' - '.join(parts[1:])
            allowance = maxlen - len(counter) - 6
            if allowance > 12:
                return '{0} - {1}...'.format(counter, title[:allowance])
        return line[:maxlen-3] + '...'

    def item_status(self, action, mediaitem, arttypes=(), stage=0.0):
        total = float(self.current_item_total or 1)
        percent = int(((self.current_item_index + max(0.0, min(0.99, stage))) * 100) / total)
        # Keep item progress compact. The selected menu/action already defines the run,
        # so do not append FILL/REFRESH/AUTO/CACHE phase text per item.
        line = '{0}/{1} - {2}'.format(
            self.current_item_index + 1,
            self.current_item_total or 1,
            self._display_title(mediaitem),
        )
        line = self._fit_line(line)
        runtrace.item_status(action, mediaitem, arttypes, stage=stage, percent=percent)
        self.update_progress(percent, line, 'Library Artwork Curator')

    def finalupdate(self, header, message):
        text = str(message or header or '')
        if header and message:
            text = '{0} - {1}'.format(header, message)
        text = self._fit_line(text, maxlen=68)
        if settings.final_notification:
            xbmcgui.Dialog().notification('Library Artwork Curator', text, xbmcgui.NOTIFICATION_INFO, 8000)
        elif self.visible:
            self.update_progress(100, text, 'Library Artwork Curator')

    def close_progress(self):
        if self.visible:
            self.progress.close()
            self.progress = None
            self.progress_foreground = False
            self.visible = False

    def notify_warning(self, message, header=None, error=False):
        if settings.progressdisplay != PROGRESS_DISPLAY_NONE:
            xbmcgui.Dialog().notification('Library Artwork Curator: ' + (header or 'Warning'), message,
                xbmcgui.NOTIFICATION_ERROR if error else xbmcgui.NOTIFICATION_WARNING)

    def set_idle_inhibition(self, enabled):
        """Keep long artwork jobs from launching a screensaver or idle shutdown."""
        enabled = bool(enabled)
        if self.idle_inhibited == enabled:
            return
        state = 'true' if enabled else 'false'
        try:
            pykodi.execute_builtin('InhibitScreensaver({0})'.format(state))
            pykodi.execute_builtin('InhibitIdleShutdown({0})'.format(state))
            self.idle_inhibited = enabled
            log('Idle inhibition {0}'.format('enabled' if enabled else 'disabled'), xbmc.LOGINFO)
        except Exception:
            log('Could not change Kodi idle inhibition state', xbmc.LOGWARNING)
            log(traceback.format_exc(), xbmc.LOGWARNING)

    def init_run(self, show_progress=False, chunkcount=1, foreground=False, force_progress=False):
        runtrace.event('processor', 'init_run', show_progress=show_progress, chunkcount=chunkcount, foreground=foreground, force_progress=force_progress)
        self.set_idle_inhibition(True)
        self.setlanguages()
        self.gatherer = Gatherer(self.monitor, self.autolanguages)
        self.downloader = FileManager(self.debug, True)
        self.chunkcount = chunkcount
        self.currentchunk = 0
        self.cancelled = False
        self.item_error_count = 0
        self._last_process_aborted = False
        self.last_summary = {}
        if show_progress:
            self.create_progress(foreground, force_progress)

    def set_debug(self, debug):
        if self.downloader:
            self.downloader.debug = debug
        reporting.debug = debug
        self.debug = debug

    def finish_run(self):
        runtrace.event('processor', 'finish_run')
        try:
            info.clear_cache()
            self.downloader = None
            self.set_debug(False)
            self.close_progress()
        finally:
            self.set_idle_inhibition(False)

    @property
    def processor_busy(self):
        # Only a real processing worker is busy. A stale/signalled auto queue
        # must not block manual context actions or make the main menu show
        # Stop current process.
        return pykodi.get_conditional('String.IsEqual(Window(Home).Property(ArtworkCurator.Status),processing)')

    @property
    def processor_signalled(self):
        return pykodi.get_conditional('String.IsEqual(Window(Home).Property(ArtworkCurator.Status),signalled)')

    def _clear_signalled_auto_queue(self):
        if not self.processor_signalled:
            return
        runtrace.event('context', 'clearing signalled auto queue before manual context action')
        try:
            pykodi.execute_builtin('NotifyAll(script.artwork.curator:control, CancelCurrent)')
            xbmc.sleep(150)
        except Exception as ex:
            runtrace.error('failed to clear signalled auto queue', ex)
        # The service should clear the Home property. If the service is still
        # restarting, unblock the manual action locally as well.
        try:
            pykodi.execute_builtin('SetProperty(ArtworkCurator.Status, idle, Home)')
            pykodi.execute_builtin('SetProperty(LibraryArtworkCurator.Status, idle, Home)')
            pykodi.execute_builtin('SetProperty(script.artwork.curator.Status, idle, Home)')
        except Exception:
            pass

    def process_item(self, mediatype, dbid, mode):
        if mediatype not in mediatypes.artinfo:
            xbmcgui.Dialog().notification('Library Artwork Curator', L(NOT_SUPPORTED_MESSAGE).format(mediatype), '-', 6500)
            return
        if self.processor_busy:
            runtrace.event('context', 'manual context blocked by active processing worker', mediatype=mediatype, dbid=dbid, mode=mode)
            xbmcgui.Dialog().notification('Library Artwork Curator', 'ARTWORK PROCESS IS RUNNING - TRY AGAIN AFTER IT FINISHES', xbmcgui.NOTIFICATION_WARNING, 6500)
            return
        if mode in (MODE_GUI, MODE_DRYRUN, MODE_AUTO):
            self._clear_signalled_auto_queue()
        self.init_run()
        if mode == MODE_DEBUG:
            self.set_debug(True)
            mode = MODE_AUTO
        busy = None
        if mode in (MODE_GUI, MODE_DRYRUN):
            busy = pykodi.get_busydialog()
            busy.create()
        try:
            mediaitem = info.MediaItem(quickjson.get_item_details(dbid, mediatype))
            info.add_additional_iteminfo(mediaitem, self.processed, search)
            if mediatype in mediatypes.require_manualid and not mediaitem.uniqueids and mode == MODE_GUI:
                self.manual_id(mediaitem)
                info.add_additional_iteminfo(mediaitem, self.processed, search)
            if mode == MODE_GUI:
                self._manual_item_process(mediaitem, busy)
            elif mode == MODE_DRYRUN:
                self._dry_run_item(mediaitem, busy)
            else:
                self.process_medialist([mediaitem], True, already_initialized=True)
        finally:
            if busy:
                try:
                    busy.close()
                except Exception:
                    pass
            if mode in (MODE_GUI, MODE_DRYRUN):
                self.finish_run()

    def _manual_item_process(self, mediaitem, busy):
        availableart = self._prepare_manual_selection_art(mediaitem, busy)
        if busy:
            busy.close()
        if not availableart:
            xbmcgui.Dialog().notification('Library Artwork Curator', 'NO ARTWORK AVAILABLE', xbmcgui.NOTIFICATION_WARNING, 7000)
            return
        arttype, selected = prompt_for_artwork(mediaitem.mediatype, mediaitem.label, availableart, self.monitor)
        if arttype == '!!-Refresh' and mediaitem.mediatype == mediatypes.MOVIESET:
            self.processed.set_data(mediaitem.dbid, mediaitem.mediatype, mediaitem.label, None)
            if self.manual_id(mediaitem):
                mediaitem.uniqueids = {}
                info.add_additional_iteminfo(mediaitem, self.processed, search)
                if busy:
                    busy.create()
                self._manual_item_process(mediaitem, busy)
            return
        if not arttype or selected is None:
            return
        if mediatypes.get_artinfo(mediaitem.mediatype, arttype)['multiselect']:
            changed = info.fill_multiart(mediaitem.art, arttype, selected)
            toset = get_simpledict_updates(mediaitem.art, changed)
        else:
            toset = {arttype: selected}
        if toset:
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, toset)
            mediaitem.art.update(toset)
            mediaitem.updatedart = list(toset)
            self._record_manual_selection(mediaitem, toset)
            self.cache_remote(mediaitem, toset)
            reporting.report_item(mediaitem, True, True, self.downloader.size)
            notifycount(len([url for url in toset.values() if url]))

    def _manual_select_targets(self, mediaitem):
        targets = []

        def add_target(exacttype):
            if exacttype == 'icon' or exacttype in targets:
                return
            targets.append(exacttype)

        for arttype, artcfg in mediatypes.artinfo[mediaitem.mediatype].items():
            if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                continue
            add_target(arttype)

        if mediaitem.mediatype == mediatypes.TVSHOW:
            for season in mediaitem.seasons:
                for arttype, artcfg in mediatypes.artinfo[mediatypes.SEASON].items():
                    if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                        continue
                    add_target('{0}.{1}.{2}'.format(mediatypes.SEASON, season, arttype))

        for arttype in mediatypes.othertypes[mediaitem.mediatype]:
            if arttype != 'icon' and arttype not in mediaitem.skip_artwork:
                add_target(arttype)
        return targets

    def _current_art_entries_for_manual_select(self, mediaitem, targets):
        allowed = set(targets or [])
        allowed_bases = set(info.get_basetype(target) for target in allowed)
        entries = {}
        for exacttype in sorted((mediaitem.art or {}), key=natural_sort):
            url = mediaitem.art.get(exacttype)
            if not url or exacttype == 'icon' or artworkdb.is_default_icon_url(url):
                continue
            base = info.get_basetype(exacttype)
            if exacttype in allowed:
                target = exacttype
            elif base in allowed_bases:
                target = base
            else:
                continue
            entries.setdefault(target, []).append({
                'url': url,
                'preview': url,
                'title': exacttype,
                'existing': True,
                'manual_current': True,
                'provider': SortedDisplay('current', L(CURRENT_ART)),
                'rating': SortedDisplay(10, ''),
                'size': SortedDisplay(10000, ''),
                'language': None,
                'gallery_order': -1000,
            })
        return entries

    def _merge_current_and_provider_art(self, mediaitem, targets):
        current_entries = self._current_art_entries_for_manual_select(mediaitem, targets)
        allowed = set(targets or [])
        allowed_bases = set(info.get_basetype(target) for target in allowed)
        result = {}
        for target in targets:
            merged = []
            seen = set()
            for image in current_entries.get(target, []):
                url = image.get('url')
                if url and url not in seen:
                    merged.append(image)
                    seen.add(url)
            for image in list((mediaitem.availableart or {}).get(target, []) or []):
                url = image.get('url')
                if url and url not in seen:
                    merged.append(image)
                    seen.add(url)
            if merged:
                result[target] = merged
        # Keep any exact provider art that maps to an allowed base, but never expose icon.
        for key, artlist in (mediaitem.availableart or {}).items():
            if key == 'icon' or key in result:
                continue
            base = info.get_basetype(key)
            if key not in allowed and base not in allowed_bases:
                continue
            merged = []
            seen = set()
            for image in current_entries.get(key, []) + list(artlist or []):
                url = image.get('url')
                if url and url not in seen:
                    merged.append(image)
                    seen.add(url)
            if merged:
                result[key] = merged
        return result

    def _prepare_manual_selection_art(self, mediaitem, busy=None):
        previous_refresh = self.refresh_all_artwork
        self.refresh_all_artwork = True
        try:
            if mediaitem.missingid:
                runtrace.event('context_gui', 'item missing provider id', mediatype=mediaitem.mediatype, dbid=mediaitem.dbid, label=mediaitem.label)
            targets = self._manual_select_targets(mediaitem)
            self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
            self.gatherer.set_languages(self.current_languages)
            if busy:
                try:
                    busy.update(25, 'Fetching artwork providers')
                except Exception:
                    pass
            services_hit, error = self.gatherer.getartwork(mediaitem, skipexisting=False)
            if error:
                mediaitem.error = '{0}: {1}'.format(error.get('providername'), error.get('message'))
            availableart = self._merge_current_and_provider_art(mediaitem, targets)
            runtrace.event('context_gui', 'manual selection candidates ready', mediatype=mediaitem.mediatype, dbid=mediaitem.dbid,
                           targets=len(targets), art_types=len(availableart), services_hit=services_hit,
                           counts=dict((key, len(value or [])) for key, value in availableart.items()))
            return availableart
        except Exception as ex:
            runtrace.error('manual selection candidate fetch failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''))
            return self._merge_current_and_provider_art(mediaitem, self._manual_select_targets(mediaitem))
        finally:
            self.refresh_all_artwork = previous_refresh

    def _record_manual_selection(self, mediaitem, toset):
        for art_type, url in (toset or {}).items():
            try:
                if art_type == 'icon' or artworkdb.is_default_icon_url(url):
                    continue
                if url:
                    artworkdb.set_artwork_item(mediaitem, art_type, url, artworkdb.infer_source(url), 'MANUAL', 'Selected from context menu')
                else:
                    artworkdb.set_artwork_item(mediaitem, art_type, '', '', 'MISSING', 'Removed from context menu')
            except Exception as ex:
                runtrace.error('manual selection DB record failed', ex, art_type=art_type)

    def process_medialist(self, medialist, alwaysnotify=False, already_initialized=False, foreground=False, force_progress=False, refresh_indonesian=False, refresh_all=False, suppress_final=False):
        timer = __import__('time').time()
        runtrace.event('processor', 'process_medialist start', total=len(medialist or []), alwaysnotify=alwaysnotify, already_initialized=already_initialized, refresh_indonesian=refresh_indonesian, refresh_all=refresh_all, suppress_final=suppress_final)
        previous_refresh = self.refresh_indonesian
        previous_refresh_all = self.refresh_all_artwork
        self.refresh_indonesian = bool(refresh_indonesian)
        self.refresh_all_artwork = bool(refresh_all)
        self.item_error_count = 0
        self.last_summary = {}
        self.db_run_id = artworkdb.begin_run(
            'refresh_indonesian' if refresh_indonesian else ('refresh_all' if refresh_all else 'scrape_missing'),
            total_items=len(medialist or []),
            notes='force_progress={0};foreground={1};refresh_all={2}'.format(force_progress, foreground, refresh_all)
        )
        if not already_initialized:
            self.init_run(True, 1, foreground, force_progress)
        elif self.gatherer is None:
            self.init_run(True, 1, foreground, force_progress)
        try:
            reporting.report_start(medialist)
            aborted, updateditems, artcount = self._process_chunk(medialist)
            reporting.report_end(medialist, updateditems if aborted else 0, self.downloader.size)
            action_label = 'REFRESH ARTWORK' if refresh_all else ('REFRESH INDONESIAN ARTWORK' if refresh_indonesian else 'FILL MISSING ARTWORK')
            status_label = 'ABORTED' if aborted else 'FINISHED'
            if not suppress_final:
                self.finalupdate(None, '{0} {1} - {2} ITEMS - {3} ARTWORK - {4} ERRORS'.format(
                    action_label, status_label, len(medialist or []), artcount, getattr(self, 'item_error_count', 0)))
            runtrace.event('processor', 'process_medialist end', aborted=aborted, updateditems=updateditems, artcount=artcount, elapsed_ms=int((__import__('time').time() - timer) * 1000))
            return not aborted
        finally:
            elapsed_ms = int((__import__('time').time() - timer) * 1000)
            try:
                aborted_state = bool(locals().get('aborted', False) or self.cancelled or getattr(self, '_last_process_aborted', False))
                self.last_summary = {
                    'total': len(medialist or []),
                    'updated_items': locals().get('updateditems', 0),
                    'updated_artwork': locals().get('artcount', 0),
                    'errors': getattr(self, 'item_error_count', 0),
                    'elapsed_ms': elapsed_ms,
                    'status': 'aborted' if aborted_state else 'finished',
                    'action': 'refresh_all' if refresh_all else ('refresh_indonesian' if refresh_indonesian else 'fill_missing'),
                }
                artworkdb.finish_run(
                    self.db_run_id,
                    status='aborted' if aborted_state else 'finished',
                    updated_items=locals().get('updateditems', 0),
                    updated_artwork=locals().get('artcount', 0),
                    errors=getattr(self, 'item_error_count', 0),
                    elapsed_ms=elapsed_ms
                )
            except Exception as db_ex:
                runtrace.error('artwork-cache.db finish_run failed', db_ex)
            artworkdb.cleanup_retention()
            runtrace.perf('processor.process_medialist', elapsed_ms, total=len(medialist or []), refresh_indonesian=refresh_indonesian)
            self.refresh_indonesian = previous_refresh
            self.refresh_all_artwork = previous_refresh_all
            self.db_run_id = None
            self.finish_run()

    def process_chunkedlist(self, chunkedlist, chunkcount, alwaysnotify=False):
        self.init_run(True, chunkcount)
        aborted, total = False, 0
        try:
            for index, medialist in enumerate(chunkedlist):
                self.currentchunk = index
                if self.monitor.abortRequested() or medialist is False:
                    aborted = True
                    break
                reporting.report_start(medialist)
                this_aborted, updateditems, artcount = self._process_chunk(medialist)
                total += artcount
                reporting.report_end(medialist, updateditems if this_aborted else 0, self.downloader.size)
                self.downloader.size = 0
                if this_aborted:
                    aborted = True
                    break
            if total or alwaysnotify:
                self.finalupdate(*finalmessages(total))
            return not aborted
        finally:
            self.finish_run()

    def _ensure_db_first_local_details(self, mediaitem):
        """Populate only local Kodi details needed for DB-first planning.

        This intentionally avoids provider lookup. In particular it must not search
        TMDb collection IDs for movie sets that already have final DB rows.
        """
        try:
            if mediaitem.mediatype == mediatypes.TVSHOW and not mediaitem.seasons:
                seasons, seasonart = info._get_seasons_artwork(quickjson.get_seasons(mediaitem.dbid))
                mediaitem.seasons = seasons
                mediaitem.art.update(seasonart)
        except Exception as ex:
            runtrace.error('DB-first local detail preload failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''))

    def _db_first_preflight(self, mediaitem):
        """Return DB-first apply/missing plan before any provider-ID lookup."""
        if self.refresh_all_artwork or self.refresh_indonesian:
            return None
        self._ensure_db_first_local_details(mediaitem)
        return self._db_first_plan(mediaitem)

    def _finish_db_first_skip(self, mediaitem, item_timer, db_apply):
        """Apply final DB artwork to Kodi if needed, then record a skipped/applied item."""
        updated = []
        if db_apply:
            self.item_status('Applying', mediaitem, db_apply.keys(), 0.20)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, db_apply)
            mediaitem.art.update(db_apply)
            updated = list(db_apply)
        mediaitem.updatedart = updated
        reporting.report_item(mediaitem)
        elapsed_item_ms = int((__import__('time').time() - item_timer) * 1000)
        status = 'applied' if updated else 'skipped'
        artworkdb.record_item(mediaitem, self.db_run_id, status=status, updatedart=updated, elapsed_ms=elapsed_item_ms)
        runtrace.item_result(mediaitem, elapsed_item_ms, updatedart=updated, services_hit=False, db_first='final_skip')

    def _process_chunk(self, medialist):
        updateditems, artcount = 0, 0
        total = len(medialist)
        for index, mediaitem in enumerate(medialist):
            item_timer = __import__('time').time()
            services_hit = None
            if self.monitor.abortRequested() or self.cancelled:
                return True, updateditems, artcount
            self.current_item_index = index
            self.current_item_total = total or 1
            self.item_status('Checking', mediaitem, (), 0.00)
            if is_excluded(mediaitem):
                self.item_status('Skipping', mediaitem, (), 0.98)
                runtrace.item_result(mediaitem, int((__import__('time').time() - item_timer) * 1000), updatedart=[], error_text='excluded')
                continue
            try:
                self.item_status('Reading', mediaitem, (), 0.08)
                preflight = self._db_first_preflight(mediaitem)
                if preflight is not None:
                    db_apply, db_missing_exact, db_search_targets, db_existing_for_selection = preflight
                    if not db_search_targets:
                        self._finish_db_first_skip(mediaitem, item_timer, db_apply)
                        if db_apply:
                            updateditems += 1
                            artcount += len(db_apply)
                        continue
                info.add_additional_iteminfo(mediaitem, self.processed, search)
                services_hit = self._process_item(mediaitem, skipexisting=not self.refresh_all_artwork, refresh_existing=self.refresh_all_artwork)

                # Record successful scans so automatic "new videos" processing stays incremental.
                self.processed.set_nextdate(
                    mediaitem.dbid, mediaitem.mediatype, mediaitem.label,
                    datetime_now() + timedelta(days=plus_some(224, 32)))
                if mediaitem.mediatype == mediatypes.TVSHOW:
                    self.processed.set_data(
                        mediaitem.dbid, mediaitem.mediatype, mediaitem.label, mediaitem.season)
                if mediaitem.updatedart:
                    updateditems += 1
                    artcount += len(mediaitem.updatedart)
                reporting.report_item(mediaitem)
                elapsed_item_ms = int((__import__('time').time() - item_timer) * 1000)
                artworkdb.record_item(mediaitem, self.db_run_id, status='processed', updatedart=mediaitem.updatedart, elapsed_ms=elapsed_item_ms)
                runtrace.item_result(mediaitem, elapsed_item_ms, updatedart=mediaitem.updatedart, services_hit=services_hit)
            except Exception as ex:
                # A broken provider response or malformed library item must not stop
                # the full-library run. Keep going and write the traceback to kodi.log.
                mediaitem.error = '{0}: {1}'.format(type(ex).__name__, ex)
                self.item_error_count += 1
                self.item_status('Error', mediaitem, (), 0.98)
                log('Recovered item error: {0} [{1}:{2}]'.format(
                    mediaitem.label, mediaitem.mediatype, mediaitem.dbid), xbmc.LOGERROR)
                log(traceback.format_exc(), xbmc.LOGERROR)
                elapsed_item_ms = int((__import__('time').time() - item_timer) * 1000)
                artworkdb.record_item(mediaitem, self.db_run_id, status='error', updatedart=getattr(mediaitem, 'updatedart', []), elapsed_ms=elapsed_item_ms, error=mediaitem.error)
                runtrace.item_result(mediaitem, elapsed_item_ms, updatedart=getattr(mediaitem, 'updatedart', []), error_text=mediaitem.error, services_hit=services_hit)
                try:
                    reporting.report_item(mediaitem, forcedreport=True)
                except Exception as report_ex:
                    runtrace.error('Could not write recovered item error to report', report_ex, mediatype=mediaitem.mediatype, dbid=mediaitem.dbid)
                    log('Could not write recovered item error to report', xbmc.LOGWARNING)
                    log(traceback.format_exc(), xbmc.LOGWARNING)
            xbmc.sleep(int(THROTTLE_TIME * 1000))
        return False, updateditems, artcount

    def _enabled_db_arttypes(self, mediaitem):
        result = []
        for arttype, artcfg in mediatypes.artinfo[mediaitem.mediatype].items():
            if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                continue
            if artcfg['multiselect']:
                for index in range(int(artcfg['autolimit'] or 0)):
                    exact = info.format_arttype(arttype, index)
                    if exact not in result:
                        result.append(exact)
            elif arttype not in result:
                result.append(arttype)
        if mediaitem.mediatype == mediatypes.TVSHOW and not mediatypes.disabled(mediatypes.SEASON):
            for season in mediaitem.seasons:
                for arttype, artcfg in mediatypes.artinfo[mediatypes.SEASON].items():
                    if not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                        continue
                    exact = 'season.{0}.{1}'.format(season, arttype)
                    if exact not in result:
                        result.append(exact)
        for arttype in mediatypes.othertypes[mediaitem.mediatype]:
            if arttype not in mediaitem.skip_artwork and arttype not in result:
                result.append(arttype)
        return result

    def _db_first_plan(self, mediaitem):
        rows = artworkdb.get_artwork_rows(mediaitem)
        apply_from_db, missing_exact, search_targets = {}, [], []
        for art_type, url in artworkdb.artwork_to_apply(mediaitem).items():
            if url and mediaitem.art.get(art_type) != url:
                apply_from_db[art_type] = url
        for exact in self._enabled_db_arttypes(mediaitem):
            row = rows.get(exact)
            if artworkdb.should_search_row(row):
                missing_exact.append(exact)
                itemtype, artkey = mediatypes.hack_mediaarttype(mediaitem.mediatype, exact)
                cfg = mediatypes.get_artinfo(itemtype, artkey)
                target = artkey if cfg.get('multiselect') else exact
                if target not in search_targets:
                    search_targets.append(target)
        existing_for_selection = dict(mediaitem.art)
        for exact in missing_exact:
            existing_for_selection[exact] = None
        return apply_from_db, missing_exact, search_targets, existing_for_selection

    def _process_item(self, mediaitem, skipexisting=True, refresh_existing=False):
        existing_before = [arttype for arttype, url in mediaitem.art.items() if url]
        self.item_status('Checking', mediaitem, existing_before, 0.12)

        cleaned = cleaner.clean_artwork(mediaitem)
        cleanchanges = get_simpledict_updates(mediaitem.art, cleaned)
        if cleanchanges:
            self.item_status('Cleaning', mediaitem, cleanchanges.keys(), 0.18)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, cleanchanges)
            mediaitem.art.update(cleanchanges)

        db_apply, db_missing_exact, db_search_targets, db_existing_for_selection = self._db_first_plan(mediaitem)
        if db_apply and not refresh_existing:
            self.item_status('Applying', mediaitem, db_apply.keys(), 0.20)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, db_apply)
            mediaitem.art.update(db_apply)
            cleanchanges.update(db_apply)

        # DB-first: Fill Missing follows artwork-cache.db status, not Kodi's current art table.
        mediaitem.missingart = list(db_search_targets if not refresh_existing and not self.refresh_indonesian else info.iter_missing_arttypes(mediaitem, mediaitem.art))
        mediaitem.db_missingart_exact = list(db_missing_exact)
        mediaitem.db_existing_for_selection = dict(db_existing_for_selection)
        mediaitem.missingid = not bool(mediaitem.uniqueids)
        if mediaitem.missingid:
            self.item_status('Skipping', mediaitem, mediaitem.missingart, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False
        if mediaitem.protected_custom_set:
            for art_type in (getattr(mediaitem, 'db_missingart_exact', None) or mediaitem.missingart or ()):
                artworkdb.mark_art_status_item(mediaitem, art_type, 'PROTECTED', 'Protected custom collection')
            self.item_status('Skipping', mediaitem, (), 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False
        if refresh_existing:
            return self._process_refresh_all_item(mediaitem, cleanchanges, existing_before)
        if self.refresh_indonesian and mediaitem.indonesia_hint:
            return self._process_indonesian_refresh(mediaitem, cleanchanges, existing_before)
        if not mediaitem.missingart:
            self.item_status('Skipping', mediaitem, existing_before, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False

        self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
        self.gatherer.set_languages(self.current_languages)
        self.item_status('Searching', mediaitem, mediaitem.missingart, 0.30)
        services_hit, error = self.gatherer.getartwork(mediaitem, skipexisting=skipexisting)
        if error:
            mediaitem.error = '{0}: {1}'.format(error['providername'], error['message'])
        self.item_status('Selecting', mediaitem, mediaitem.missingart, 0.60)
        selected = self.get_top_missing_art(mediaitem.missingart,
            mediaitem.mediatype, getattr(mediaitem, 'db_existing_for_selection', mediaitem.art), mediaitem.availableart, mediaitem=mediaitem)
        if selected:
            self.item_status('Adding', mediaitem, selected.keys(), 0.72)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, selected)
            mediaitem.art.update(selected)
        else:
            self.item_status('Missing', mediaitem, mediaitem.missingart, 0.88)
        self._mark_missing_na(mediaitem, mediaitem.missingart, selected)
        combined = dict(cleanchanges)
        combined.update(selected)
        mediaitem.updatedart = list(combined)
        self.cache_remote(mediaitem, selected)
        self.item_status('Done', mediaitem, combined.keys(), 0.98)
        return services_hit

    def _is_curator_managed_url(self, url):
        lower = (url or '').lower()
        return lower.startswith(('http://', 'https://')) and any(marker in lower for marker in CURATOR_REMOTE_HOST_MARKERS)

    def _existing_artwork_is_manual(self, url):
        return bool(url) and not self._is_curator_managed_url(url) and not url.startswith('image://')

    def _iter_refresh_targets(self, mediaitem):
        targets = []
        try:
            manual_rows = artworkdb.get_artwork_rows(mediaitem)
        except Exception:
            manual_rows = {}

        def is_db_manual(exacttype):
            row = manual_rows.get(exacttype)
            if row and (row.get('status') or '').upper() in ('MANUAL', 'PROTECTED'):
                return True
            base = info.get_basetype(exacttype)
            for key, value in (manual_rows or {}).items():
                if info.arttype_matches_base(key, base) and (value.get('status') or '').upper() in ('MANUAL', 'PROTECTED'):
                    return True
            return False

        def add_target(exacttype, current_url=None):
            if is_db_manual(exacttype):
                return
            if current_url and self._existing_artwork_is_manual(current_url):
                return
            if exacttype not in targets:
                targets.append(exacttype)

        for arttype, artcfg in mediatypes.artinfo[mediaitem.mediatype].items():
            if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                continue
            if artcfg['multiselect']:
                existing_urls = [
                    url for key, url in mediaitem.art.items()
                    if info.arttype_matches_base(key, arttype) and url
                ]
                if existing_urls and any(self._existing_artwork_is_manual(url) for url in existing_urls):
                    continue
                add_target(arttype)
            else:
                add_target(arttype, mediaitem.art.get(arttype))

        if mediaitem.mediatype == mediatypes.TVSHOW:
            for season in mediaitem.seasons:
                for arttype, artcfg in mediatypes.artinfo[mediatypes.SEASON].items():
                    if arttype in mediaitem.skip_artwork or not artcfg['autolimit'] or not mediatypes.arttype_enabled(arttype):
                        continue
                    exact = '{0}.{1}.{2}'.format(mediatypes.SEASON, season, arttype)
                    add_target(exact, mediaitem.art.get(exact))

        for arttype in mediatypes.othertypes[mediaitem.mediatype]:
            current = mediaitem.art.get(arttype)
            if current and self._existing_artwork_is_manual(current):
                continue
            if arttype not in mediaitem.skip_artwork and arttype not in targets:
                targets.append(arttype)

        return targets

    def _existing_art_for_refresh(self, mediaitem, targets):
        result = dict(mediaitem.art)
        for target in targets:
            itemtype, artkey = mediatypes.hack_mediaarttype(mediaitem.mediatype, target)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            if cfg['multiselect']:
                for key in list(result):
                    if info.arttype_matches_base(key, target):
                        result[key] = None
            else:
                result[target] = None
        return result

    def _build_refresh_updates(self, mediaitem, selected, targets):
        updates = {}
        selected = selected or {}
        for target in targets:
            itemtype, artkey = mediatypes.hack_mediaarttype(mediaitem.mediatype, target)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            if cfg['multiselect']:
                chosen_urls = [
                    url for exact, url in sorted(selected.items(), key=lambda pair: pair[0])
                    if info.arttype_matches_base(exact, target) and url
                ]
                if not chosen_urls:
                    continue
                existing_urls = [
                    url for key, url in mediaitem.art.items()
                    if info.arttype_matches_base(key, target) and url
                ]
                rebuilt = info.fill_multiart(mediaitem.art, target, (chosen_urls, existing_urls))
                updates.update(get_simpledict_updates(mediaitem.art, rebuilt))
            else:
                chosen = selected.get(target)
                if chosen and chosen != mediaitem.art.get(target):
                    updates[target] = chosen
        return updates

    def _debug_indonesian_poster(self, mediaitem, refresh_targets, selected=None, refresh_updates=None, phase=''):
        current_poster = mediaitem.art.get('poster')
        refreshdebug.write('')
        refreshdebug.write('ITEM {0}:{1} | {2} | phase={3}'.format(
            mediaitem.mediatype, mediaitem.dbid, mediaitem.label, phase))
        refreshdebug.write('  file={0}'.format(mediaitem.file or '-'))
        refreshdebug.write('  indonesia_hint={0}'.format(bool(mediaitem.indonesia_hint)))
        refreshdebug.write('  uniqueids={0}'.format(mediaitem.uniqueids))
        refreshdebug.write('  languages={0}'.format(self.current_languages))
        refreshdebug.write('  current poster={0}'.format(current_poster or '-'))
        refreshdebug.write('  refresh targets={0}'.format(refresh_targets))
        candidates = mediaitem.availableart.get('poster', [])
        refreshdebug.write('  poster candidates={0}'.format(len(candidates)))
        for index, candidate in enumerate(candidates[:30], 1):
            refreshdebug.write(refreshdebug.format_candidate(index, candidate))
        if len(candidates) > 30:
            refreshdebug.write('    ... {0} more candidate(s) omitted'.format(len(candidates) - 30))
        if selected is not None:
            refreshdebug.write('  selected poster={0}'.format(selected.get('poster') or '-'))
        if refresh_updates is not None:
            refreshdebug.write('  poster update={0}'.format(refresh_updates.get('poster') or '-'))

    def _verify_indonesian_poster_update(self, mediaitem, expected_url):
        if not expected_url or mediaitem.mediatype != mediatypes.MOVIE:
            return
        try:
            verify = quickjson.get_item_details(mediaitem.dbid, mediaitem.mediatype) or {}
            actual = info.get_own_artwork(verify).get('poster')
            refreshdebug.important(
                'VERIFY {0}:{1} | {2} | expected={3} | actual={4} | match={5}'.format(
                    mediaitem.mediatype, mediaitem.dbid, mediaitem.label,
                    expected_url, actual or '-', actual == expected_url
                )
            )
        except Exception as ex:
            refreshdebug.important(
                'VERIFY ERROR {0}:{1} | {2} | {3}'.format(
                    mediaitem.mediatype, mediaitem.dbid, mediaitem.label, repr(ex)
                )
            )


    def _mark_missing_na(self, mediaitem, requested, selected):
        selected = selected or {}
        requested_exact = list(getattr(mediaitem, 'db_missingart_exact', None) or requested or ())
        for exact, url in selected.items():
            if url:
                artworkdb.set_artwork_item(mediaitem, exact, url, artworkdb.infer_source(url), 'OK', '')
        for requested_art in requested_exact:
            if any(url and exact == requested_art for exact, url in selected.items()):
                continue
            artworkdb.set_artwork_item(mediaitem, requested_art, '', '', 'N/A', 'No provider candidate selected')

    def _process_refresh_all_item(self, mediaitem, cleanchanges, existing_before):
        refresh_targets = self._iter_refresh_targets(mediaitem)
        if not refresh_targets:
            self.item_status('Skipping', mediaitem, existing_before, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False
        self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
        self.gatherer.set_languages(self.current_languages)
        self.item_status('Searching', mediaitem, refresh_targets, 0.30)
        services_hit, error = self.gatherer.getartwork(mediaitem, skipexisting=False)
        if error:
            mediaitem.error = '{0}: {1}'.format(error['providername'], error['message'])
        self.item_status('Selecting', mediaitem, refresh_targets, 0.60)
        selected = self.get_top_missing_art(
            refresh_targets,
            mediaitem.mediatype,
            self._existing_art_for_refresh(mediaitem, refresh_targets),
            mediaitem.availableart,
            mediaitem=mediaitem,
        )
        refresh_updates = self._build_refresh_updates(mediaitem, selected, refresh_targets)
        combined = dict(cleanchanges)
        combined.update(refresh_updates)
        if refresh_updates:
            self.item_status('Adding', mediaitem, refresh_updates.keys(), 0.72)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, refresh_updates)
            mediaitem.art.update(refresh_updates)
        self._mark_missing_na(mediaitem, refresh_targets, selected)
        mediaitem.updatedart = list(combined)
        self.cache_remote(mediaitem, refresh_updates)
        self.item_status('Done', mediaitem, combined.keys(), 0.98)
        return services_hit

    def _process_indonesian_refresh(self, mediaitem, cleanchanges, existing_before):
        refresh_targets = self._iter_refresh_targets(mediaitem)
        if not refresh_targets:
            self.item_status('Skipping', mediaitem, existing_before, 0.98)
            mediaitem.updatedart = list(cleanchanges)
            return False

        self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
        self.gatherer.set_languages(self.current_languages)
        self.item_status('Searching', mediaitem, refresh_targets, 0.30)
        services_hit, error = self.gatherer.getartwork(mediaitem, skipexisting=False)
        if error:
            mediaitem.error = '{0}: {1}'.format(error['providername'], error['message'])
        self.item_status('Selecting', mediaitem, refresh_targets, 0.60)
        self._debug_indonesian_poster(mediaitem, refresh_targets, phase='after-gather')

        selected = self.get_top_missing_art(
            refresh_targets,
            mediaitem.mediatype,
            self._existing_art_for_refresh(mediaitem, refresh_targets),
            mediaitem.availableart,
            mediaitem=mediaitem,
        )
        refresh_updates = self._build_refresh_updates(mediaitem, selected, refresh_targets)
        self._debug_indonesian_poster(
            mediaitem, refresh_targets, selected=selected,
            refresh_updates=refresh_updates, phase='after-select')
        combined = dict(cleanchanges)
        combined.update(refresh_updates)
        if refresh_updates:
            self.item_status('Adding', mediaitem, refresh_updates.keys(), 0.72)
            add_art_to_library(mediaitem.mediatype, mediaitem.seasons, mediaitem.dbid, refresh_updates)
            mediaitem.art.update(refresh_updates)
            self._verify_indonesian_poster_update(mediaitem, refresh_updates.get('poster'))
        else:
            self.item_status('Skipping', mediaitem, existing_before, 0.88)
        mediaitem.updatedart = list(combined)
        self.cache_remote(mediaitem, refresh_updates)
        self.item_status('Done', mediaitem, combined.keys(), 0.98)
        return services_hit

    def cache_remote(self, mediaitem, toset):
        if settings.cache_remote_video_artwork and self.downloader:
            artmap = dict(mediaitem.art)
            artmap.update(toset or {})
            urltypes = {}
            for arttype, url in artmap.items():
                if url:
                    urltypes.setdefault(url, []).append(arttype)
            self.item_status('Checking', mediaitem, (toset or {}).keys(), 0.80)

            def on_cache_progress(done, total, url):
                # Keep the compact BG progress notification informative while
                # Kodi fetches remote URLs into userdata/Thumbnails.
                self.item_status('Downloading', mediaitem, urltypes.get(url, ()), 0.82 + (0.15 * done / float(total or 1)))

            self.downloader.cachefor(artmap, progress_callback=on_cache_progress)

    def _provider_display(self, image):
        provider = image.get('provider') if image else None
        return getattr(provider, 'display', None) or getattr(provider, 'sort', None) or provider or '-'

    def _display_field(self, value):
        return getattr(value, 'display', None) or getattr(value, 'sort', None) or value or '-'

    def _dryrun_candidate_line(self, prefix, index, image, selected_urls=None):
        selected_urls = selected_urls or set()
        url = image.get('url') or ''
        flags = []
        if url in selected_urls:
            flags.append('SELECTED')
        if image.get('existing'):
            flags.append('EXISTING')
        if image.get('details_primary') or image.get('localized_primary'):
            flags.append('PRIMARY')
        subtype = image.get('subtype')
        subtype = getattr(subtype, 'display', subtype) if subtype else ''
        title = image.get('title') or subtype or ''
        return '{prefix} #{idx:03d} {flags} provider={provider} lang={lang} size={size} rating={rating} gallery_order={order} title={title} preview={preview} url={url}'.format(
            prefix=prefix,
            idx=index,
            flags=('[{0}]'.format(','.join(flags)) if flags else ''),
            provider=self._provider_display(image),
            lang=image.get('language'),
            size=self._display_field(image.get('size')),
            rating=self._display_field(image.get('rating')),
            order=image.get('gallery_order'),
            title=title or '-',
            preview=image.get('preview') or '-',
            url=url or '-',
        )

    def _dryrun_log_paths(self):
        diagdir = runtrace.diagnostics_dir()
        return (
            os.path.join(diagdir, 'dry-run-artwork-selection-last.txt'),
            os.path.join(diagdir, 'dry-run-artwork-selection.txt'),
        )

    def _dryrun_write_logs(self, text):
        last_path, history_path = self._dryrun_log_paths()
        try:
            with open(last_path, 'w', encoding='utf-8') as handle:
                handle.write(text)
        except Exception as ex:
            runtrace.error('dry-run last log write failed', ex, path=last_path)
        try:
            with open(history_path, 'a', encoding='utf-8') as handle:
                handle.write('\n\n' + ('=' * 120) + '\n')
                handle.write(text)
        except Exception as ex:
            runtrace.error('dry-run history log write failed', ex, path=history_path)
        return last_path

    def _dryrun_selected_urls_for_target(self, selected, target):
        result = []
        for exact, url in sorted((selected or {}).items(), key=lambda pair: natural_sort(pair[0])):
            if url and info.arttype_matches_base(exact, target):
                result.append((exact, url))
        if not result and selected.get(target):
            result.append((target, selected.get(target)))
        return result

    def _dryrun_selection_text(self, mediaitem, targets, selected, refresh_updates, services_hit=None, error=None):
        rows = []
        now = __import__('time').strftime('%Y-%m-%d %H:%M:%S')
        rows.append('Library Artwork Curator - Dry run artwork selection')
        rows.append('=' * 120)
        rows.append('Created: {0}'.format(now))
        rows.append('Addon mode: DRY RUN - NO KODI ART UPDATE, NO DB WRITE, NO TEXTURE CACHE')
        rows.append('Item: {0}:{1} | {2}'.format(mediaitem.mediatype, mediaitem.dbid, mediaitem.label))
        rows.append('File: {0}'.format(mediaitem.file or '-'))
        rows.append('Unique IDs: {0}'.format(mediaitem.uniqueids or {}))
        rows.append('Premiered: {0}'.format(mediaitem.premiered or '-'))
        rows.append('Indonesian hint: {0}'.format(bool(mediaitem.indonesia_hint)))
        rows.append('Protected custom set: {0}'.format(bool(mediaitem.protected_custom_set)))
        rows.append('Language order: {0}'.format(self.current_languages))
        rows.append('Refresh targets: {0}'.format(', '.join(targets) if targets else '-'))
        rows.append('Provider services hit: {0}'.format(services_hit))
        if error:
            rows.append('Provider error: {0}'.format(error))
        rows.append('')
        rows.append('Current Kodi artwork')
        rows.append('-' * 120)
        if mediaitem.art:
            for key in sorted(mediaitem.art, key=natural_sort):
                rows.append('{0}: {1}'.format(key, mediaitem.art.get(key) or '-'))
        else:
            rows.append('<none>')
        rows.append('')
        rows.append('Provider candidate counts')
        rows.append('-' * 120)
        counts = dict((key, len(value or [])) for key, value in sorted(mediaitem.availableart.items(), key=lambda pair: natural_sort(pair[0])))
        rows.append(str(counts))
        rows.append('')
        rows.append('Planned Kodi updates if this was Refresh all artwork')
        rows.append('-' * 120)
        if refresh_updates:
            for key in sorted(refresh_updates, key=natural_sort):
                rows.append('{0}: {1}'.format(key, refresh_updates.get(key) or '-'))
        else:
            rows.append('<no Kodi art changes planned>')
        rows.append('')
        existing_for_refresh = self._existing_art_for_refresh(mediaitem, targets)
        for target in targets:
            itemtype, artkey = mediatypes.hack_mediaarttype(mediaitem.mediatype, target)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            candidates = list(mediaitem.availableart.get(target, []) or [])
            selected_pairs = self._dryrun_selected_urls_for_target(selected, target)
            selected_urls = set(url for _, url in selected_pairs)
            rows.append('')
            rows.append('ART TYPE: {0}'.format(target))
            rows.append('=' * 120)
            rows.append('mediaitem type={0} effective type={1} artkey={2} multiselect={3} autolimit={4}'.format(
                mediaitem.mediatype, itemtype, artkey, bool(cfg.get('multiselect')), cfg.get('autolimit')))
            rows.append('current exact artwork:')
            current_any = False
            for key in sorted(mediaitem.art, key=natural_sort):
                if info.arttype_matches_base(key, target) or key == target:
                    current_any = True
                    rows.append('  {0}: {1}'.format(key, mediaitem.art.get(key) or '-'))
            if not current_any:
                rows.append('  <none>')
            if selected_pairs:
                rows.append('selected order:')
                for exact, url in selected_pairs:
                    rows.append('  {0}: {1}'.format(exact, url))
            else:
                rows.append('selected order: <none>')
            rows.append('')
            if cfg.get('multiselect'):
                existingurls = [url for art, url in existing_for_refresh.items() if info.arttype_matches_base(art, target) and url]
                usable = [art for art in candidates if self._auto_filter(target, art, mediaitem.mediatype, candidates, existingurls)]
            else:
                usable = [art for art in candidates if self._auto_filter(target, art, mediaitem.mediatype, candidates)]
            rows.append('usable candidates after AC filter: {0}/{1}'.format(len(usable), len(candidates)))
            rows.append('usable order:')
            if usable:
                for index, image in enumerate(usable, 1):
                    rows.append(self._dryrun_candidate_line('  usable', index, image, selected_urls))
            else:
                rows.append('  <none>')
            rows.append('')
            rows.append('full provider order before AC usable filter:')
            if candidates:
                for index, image in enumerate(candidates, 1):
                    rows.append(self._dryrun_candidate_line('  candidate', index, image, selected_urls))
            else:
                rows.append('  <none>')
        rows.append('')
        rows.append('End dry run')
        rows.append('=' * 120)
        return '\n'.join(rows) + '\n'

    def _dry_run_item(self, mediaitem, busy=None):
        previous_refresh = self.refresh_all_artwork
        self.refresh_all_artwork = True
        services_hit = None
        error = None
        try:
            if busy:
                try:
                    busy.update(0, 'Dry run artwork selection')
                except Exception:
                    pass
            if mediaitem.missingid:
                runtrace.event('dryrun', 'item missing provider id', mediatype=mediaitem.mediatype, dbid=mediaitem.dbid, label=mediaitem.label)
            targets = self._iter_refresh_targets(mediaitem)
            self.current_languages = info.preferred_languages(mediaitem, self.autolanguages)
            self.gatherer.set_languages(self.current_languages)
            if busy:
                try:
                    busy.update(25, 'Fetching artwork providers')
                except Exception:
                    pass
            services_hit, error = self.gatherer.getartwork(mediaitem, skipexisting=False)
            if error:
                mediaitem.error = '{0}: {1}'.format(error.get('providername'), error.get('message'))
            if busy:
                try:
                    busy.update(70, 'Selecting artwork')
                except Exception:
                    pass
            selected = self.get_top_missing_art(
                targets,
                mediaitem.mediatype,
                self._existing_art_for_refresh(mediaitem, targets),
                mediaitem.availableart,
                mediaitem=mediaitem,
            )
            refresh_updates = self._build_refresh_updates(mediaitem, selected, targets)
            text = self._dryrun_selection_text(mediaitem, targets, selected, refresh_updates, services_hit=services_hit, error=mediaitem.error)
            path = self._dryrun_write_logs(text)
            runtrace.event('dryrun', 'finished', mediatype=mediaitem.mediatype, dbid=mediaitem.dbid, label=mediaitem.label,
                           targets=len(targets), planned_updates=len(refresh_updates), log=path)
            xbmcgui.Dialog().notification('Library Artwork Curator', 'DRY RUN FINISHED - CHECK DIAGNOSTICS LOG', xbmcgui.NOTIFICATION_INFO, 8000)
        except Exception as ex:
            runtrace.error('dry-run failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''))
            xbmcgui.Dialog().notification('Library Artwork Curator', 'DRY RUN FAILED - CHECK KODI.LOG', xbmcgui.NOTIFICATION_ERROR, 8000)
        finally:
            self.refresh_all_artwork = previous_refresh

    def manual_id(self, mediaitem):
        if mediaitem.mediatype != mediatypes.MOVIESET:
            return False
        result = xbmcgui.Dialog().input(L(ENTER_COLLECTION_NAME), mediaitem.label)
        if not result:
            return False
        options = search[mediaitem.mediatype].search(result, mediaitem.mediatype)
        selected = xbmcgui.Dialog().select(mediaitem.label, [option['label'] for option in options])
        if selected < 0:
            return False
        tmdbid = options[selected]['uniqueids'].get('tmdb')
        if tmdbid:
            self.processed.set_data(mediaitem.dbid, mediaitem.mediatype, mediaitem.label, tmdbid)
        return bool(tmdbid)

    def setlanguages(self):
        languages = []
        if settings.language_override:
            languages.append(settings.language_override)
        if settings.language_fallback_kodi:
            language = pykodi.get_language(xbmc.ISO_639_1)
            if language not in languages:
                languages.append(language)
        if settings.language_fallback_en and 'en' not in languages:
            languages.append('en')
        if None not in languages:
            languages.append(None)
        self.autolanguages = tuple(languages)
        log('Working language filter: ' + repr(self.autolanguages))

    def get_top_missing_art(self, missingarts, mediatype, existingart, availableart, mediaitem=None):
        newartwork = {}
        for missingart in missingarts:
            candidates = availableart.get(missingart, [])
            if not candidates:
                continue
            itemtype, artkey = mediatypes.hack_mediaarttype(mediatype, missingart)
            cfg = mediatypes.get_artinfo(itemtype, artkey)
            if cfg['multiselect']:
                existingurls = [url for art, url in existingart.items()
                    if info.arttype_matches_base(art, missingart) and url]
                exactnames = [art for art, url in existingart.items()
                    if info.arttype_matches_base(art, missingart) and url]
                usable = [art for art in candidates if self._auto_filter(missingart, art, mediatype, candidates, existingurls)]
                selected_urls = []
                newindex = 0
                for index in range(cfg['autolimit']):
                    exact = info.format_arttype(missingart, index)
                    if exact in exactnames:
                        continue
                    if newindex >= len(usable):
                        break
                    newartwork[exact] = usable[newindex]['url']
                    selected_urls.append('{0}={1}'.format(exact, usable[newindex]['url']))
                    existingurls.append(usable[newindex]['url'])
                    newindex += 1
                runtrace.selection(mediaitem, mediatype, missingart, candidates, usable, chosen='; '.join(selected_urls), existing_count=len(exactnames))
            else:
                usable = [art for art in candidates if self._auto_filter(missingart, art, mediatype, candidates)]
                chosen = usable[0] if usable else None
                runtrace.selection(mediaitem, mediatype, missingart, candidates, usable, chosen=chosen.get('url') if chosen else None)
                if chosen:
                    newartwork[missingart] = chosen['url']
        return newartwork

    def _passes_size_filter(self, basearttype, art):
        if basearttype.endswith('fanart') and art.get('size', SortedDisplay(0, '')).sort < settings.minimum_size:
            return False
        if basearttype.endswith('poster') and art.get('size', SortedDisplay(0, '')).sort < settings.minimum_poster_height:
            return False
        return True

    def _candidate_has_acceptable_language(self, art):
        language = art.get('language')
        return language in self.current_languages or language is None


    def _auto_filter(self, basearttype, art, mediatype, availableart, ignoreurls=()):
        if art.get('url') in ignoreurls:
            return False
        if not self._passes_size_filter(basearttype, art):
            return False

        # Rating is intentionally informational only. Selection is deterministic:
        # language priority, provider priority, provider/API index order, and the
        # configured minimum resolution. This prevents sparse or missing votes
        # from reshuffling otherwise correct artwork.
        language = art.get('language')
        if language in self.current_languages:
            # Title-free artwork is preferred for fanart by the language sort above.
            return True
        # Last resort: allow no-language candidate only when no acceptable-language candidate exists.
        if language is None:
            return not any(candidate.get('language') in self.current_languages and candidate.get('url') not in ignoreurls
                for candidate in availableart)
        return False


def add_art_to_library(mediatype, seasons, dbid, selectedart):
    if not selectedart:
        return
    if mediatype == mediatypes.TVSHOW:
        for season, season_id in seasons.items():
            prefix = 'season.{0}.'.format(season)
            seasonart = dict((arttype[len(prefix):], url) for arttype, url in selectedart.items() if arttype.startswith(prefix))
            info.update_art_in_library(mediatypes.SEASON, season_id, seasonart)
        itemart = dict((arttype, url) for arttype, url in selectedart.items() if '.' not in arttype)
        info.update_art_in_library(mediatype, dbid, itemart)
    else:
        info.update_art_in_library(mediatype, dbid, selectedart)
    info.remove_local_from_texturecache(selectedart.values())


def finalmessages(count):
    count = int(count or 0)
    if count:
        return (None, 'CHANGE ARTWORK FINISHED - 1 ITEM - {0} ARTWORK UPDATED'.format(count))
    return (None, 'CHANGE ARTWORK FINISHED - 1 ITEM - 0 ARTWORK UPDATED')


def notifycount(count):
    _header, message = finalmessages(count)
    xbmcgui.Dialog().notification('Library Artwork Curator', message, xbmcgui.NOTIFICATION_INFO, 8000)


def plus_some(start, rng):
    return start + random.randrange(-rng, rng + 1)


def is_excluded(mediaitem):
    if not mediaitem.file:
        return False
    for exclusion in settings.pathexclusion:
        if exclusion['type'] == EXCLUSION_PATH_TYPE_FOLDER:
            path_file = os.path.realpath(os.path.join(mediaitem.file, ''))
            path_excl = os.path.realpath(os.path.join(exclusion['folder'], ''))
            if os.path.commonprefix([path_file, path_excl]) == path_excl:
                return True
        elif exclusion['type'] == EXCLUSION_PATH_TYPE_PREFIX and mediaitem.file.startswith(exclusion['prefix']):
            return True
        elif exclusion['type'] == EXCLUSION_PATH_TYPE_REGEX and re.match(exclusion['regex'], mediaitem.file):
            return True
    return False


def tag_forcedandexisting_art(availableart, forcedart, existingart):
    typeinsert = {}
    for exacttype, existingurl in existingart.items():
        arttype = info.get_basetype(exacttype)
        if arttype not in availableart:
            availableart[arttype] = []
        match = next((available for available in availableart[arttype] if available.get('url') == existingurl), None)
        if match:
            match['preview'] = existingurl
            match['existing'] = True
            match.setdefault('title', exacttype)
        elif existingurl:
            typeinsert[arttype] = typeinsert.get(arttype, -1) + 1
            availableart[arttype].insert(typeinsert[arttype], {
                'url': existingurl, 'preview': existingurl, 'title': exacttype,
                'existing': True, 'provider': SortedDisplay('current', L(CURRENT_ART)),
                'rating': SortedDisplay(10, ''), 'size': SortedDisplay(10000, ''), 'language': None,
            })

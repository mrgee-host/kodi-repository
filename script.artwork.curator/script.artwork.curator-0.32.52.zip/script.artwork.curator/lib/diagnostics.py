import json
import os
import re
import time
import traceback
import zipfile
import json

import xbmc
import xbmcgui
import xbmcvfs

from lib.libs import mediatypes, mediainfo as info, quickjson
from lib.libs.addonsettings import settings
from lib.libs.pykodi import log
from lib import runtrace, artworkdb, indonesian_collection, thailand_collection

DIAG_PREFIX = 'lac-diagnostics-'
SENSITIVE_KEYWORDS = ('apikey', 'api_key', 'token', 'password', 'secret', 'client')
OBSOLETE_SETTINGS = ('actor_thumb_cache',)


def _is_diagnostics_zip_name(filename):
    name = (filename or '').lower()
    return name.startswith(DIAG_PREFIX) and (name.endswith('.zip') or name.endswith('.zip.tmp') or name.endswith('.tmp'))


def _delete_old_diagnostics_zips(profile, keep=None):
    removed = []
    try:
        keep = os.path.abspath(keep) if keep else None
        for filename in os.listdir(profile):
            if not _is_diagnostics_zip_name(filename):
                continue
            path = os.path.abspath(os.path.join(profile, filename))
            if keep and path == keep:
                continue
            try:
                os.remove(path)
                removed.append(filename)
            except Exception as ex:
                log('Failed to remove old diagnostics ZIP {0}: {1!r}'.format(filename, ex), xbmc.LOGWARNING, 'diagnostics')
    except Exception:
        pass
    return removed


def _translate(path):
    value = xbmcvfs.translatePath(path)
    if isinstance(value, bytes):
        value = value.decode('utf-8', 'replace')
    return value


def _profile_dir():
    path = _translate('special://profile/addon_data/script.artwork.curator/')
    os.makedirs(path, exist_ok=True)
    return path


def _diagnostics_dir():
    path = os.path.join(_profile_dir(), 'runtime', 'diagnostics')
    os.makedirs(path, exist_ok=True)
    return path


def _safe_read(path, max_bytes=None):
    try:
        if not path or not os.path.isfile(path):
            return ''
        with open(path, 'rb') as handle:
            data = handle.read(max_bytes or -1)
        return data.decode('utf-8', 'replace')
    except Exception as ex:
        return 'READ ERROR: {0}'.format(repr(ex))


def _write_text(zf, name, text):
    zf.writestr(name, str(text or ''))


def _copy_if_exists(zf, source, dest, max_bytes=None):
    try:
        if not source or not os.path.isfile(source):
            return False
        if max_bytes:
            zf.writestr(dest, _safe_read(source, max_bytes=max_bytes))
        else:
            zf.write(source, dest)
        return True
    except Exception as ex:
        zf.writestr(dest + '.ERROR.txt', repr(ex))
        return False


def _redact_value(setting_id, value):
    sid = (setting_id or '').lower()
    if any(word in sid for word in SENSITIVE_KEYWORDS):
        return '<redacted>' if value else ''
    return value or ''


def _settings_snapshot():
    result = []
    try:
        profile_settings = os.path.join(_profile_dir(), 'settings.xml')
        if os.path.isfile(profile_settings):
            import xml.etree.ElementTree as ET
            root = ET.parse(profile_settings).getroot()
            for node in root.findall('setting'):
                sid = node.get('id') or ''
                if sid in OBSOLETE_SETTINGS:
                    continue
                result.append('{0}={1}'.format(sid, _redact_value(sid, node.text)))
        else:
            result.append('settings.xml not found in add-on profile')
    except Exception:
        result.append('settings parse error:')
        result.append(traceback.format_exc())
    return '\n'.join(result) + '\n'


def _environment_snapshot():
    rows = []
    rows.append('Library Artwork Curator diagnostics')
    rows.append('=' * 72)
    rows.append('Created epoch: {0}'.format(int(time.time())))
    rows.append('Addon profile: {0}'.format(_profile_dir()))
    rows.append('Addon version: {0}'.format(_addon_version()))
    labels = [
        ('Kodi version', 'System.BuildVersion'),
        ('Kodi date', 'System.Date(yyyy-mm-dd)'),
        ('Kodi time', 'System.Time'),
        ('Profile', 'System.ProfileName'),
        ('Language', 'System.Language'),
        ('Screen resolution', 'System.ScreenResolution'),
        ('Current skin', 'Skin.CurrentTheme'),
    ]
    for title, label in labels:
        try:
            rows.append('{0}: {1}'.format(title, xbmc.getInfoLabel(label)))
        except Exception:
            rows.append('{0}: <error>'.format(title))
    rows.append('')
    rows.append('Privacy: API keys are redacted from settings-redacted.txt.')
    rows.append('Note: raw kodi.log may contain local paths and remote image URLs.')
    return '\n'.join(rows) + '\n'


def _addon_version():
    try:
        import xbmcaddon
        return xbmcaddon.Addon('script.artwork.curator').getAddonInfo('version')
    except Exception:
        return '<unknown>'


def _indonesian_movie_snapshot():
    rows = ['Indonesian movie artwork snapshot', '=' * 72]
    total = included = 0
    try:
        if mediatypes.disabled(mediatypes.MOVIE):
            rows.append('Movie media type disabled in settings.')
            return '\n'.join(rows) + '\n'
        for row in quickjson.get_item_list(mediatypes.MOVIE):
            total += 1
            mediaitem = info.MediaItem(row)
            if not mediaitem.indonesia_hint:
                continue
            included += 1
            rows.append('')
            rows.append('movie:{0} | {1}'.format(mediaitem.dbid, mediaitem.label))
            rows.append('file: {0}'.format(mediaitem.file or '-'))
            rows.append('uniqueids: {0}'.format(mediaitem.uniqueids))
            for key in sorted(mediaitem.art):
                url = mediaitem.art.get(key)
                if url:
                    rows.append('art.{0}: {1}'.format(key, url))
        rows.insert(2, 'Scanned movies: {0}'.format(total))
        rows.insert(3, 'Included Indonesian movies: {0}'.format(included))
    except Exception:
        rows.append('SNAPSHOT ERROR:')
        rows.append(traceback.format_exc())
    return '\n'.join(rows) + '\n'


def _filtered_kodi_logs():
    logpath = _translate('special://logpath/')
    candidates = [os.path.join(logpath, 'kodi.log'), os.path.join(logpath, 'kodi.old.log')]
    patterns = re.compile(r'(Library Artwork Curator|script\.artwork\.curator|indorefresh|diagnostics|ArtworkProcessor|TMDb|fanart\.tv|TheTVDB|ERROR|WARNING|Traceback)', re.I)
    blocks = []
    for source in candidates:
        blocks.append('\n\n## {0}\n'.format(os.path.basename(source)))
        text = _safe_read(source, max_bytes=3_000_000)
        kept = [line for line in text.splitlines() if patterns.search(line)]
        blocks.extend(kept[-2500:] if kept else ['<no matching diagnostic lines>'])
    return '\n'.join(blocks) + '\n'


def _profile_file_list():
    profile = _profile_dir()
    rows = []
    try:
        for filename in sorted(os.listdir(profile)):
            if _is_diagnostics_zip_name(filename):
                continue
            path = os.path.join(profile, filename)
            if os.path.isfile(path):
                rows.append('{0}\t{1} bytes'.format(filename, os.path.getsize(path)))
            elif os.path.isdir(path):
                rows.append('{0}/\t<dir>'.format(filename))
    except Exception:
        rows.append(traceback.format_exc())
    return '\n'.join(rows) + '\n'

def export():
    profile = _profile_dir()
    stamp = time.strftime('%Y%m%d-%H%M%S')
    zip_name = DIAG_PREFIX + stamp + '.zip'
    zip_path = os.path.join(profile, zip_name)
    tmp_path = zip_path + '.tmp'
    copied = []
    section_errors = []

    def safe_section(zf, name, producer):
        try:
            value = producer() if callable(producer) else producer
            _write_text(zf, name, value)
            return True
        except Exception as ex:
            section_errors.append('{0}: {1!r}'.format(name, ex))
            _write_text(zf, name + '.ERROR.txt', traceback.format_exc())
            return False

    try:
        try:
            artworkdb.checkpoint()
        except Exception:
            pass
        if os.path.isfile(tmp_path):
            try:
                os.remove(tmp_path)
            except Exception:
                pass
        with zipfile.ZipFile(tmp_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            safe_section(zf, 'manifest.json', lambda: json.dumps({'addon_id': 'script.artwork.curator', 'addon_name': 'Library Artwork Curator', 'created_at': time.strftime('%Y-%m-%d %H:%M:%S'), 'zip_layout': 'runtime-v1'}, indent=2) + '\n')
            safe_section(zf, 'summary/environment.txt', _environment_snapshot)
            safe_section(zf, 'summary/runtime-state.txt', runtrace.snapshot_runtime_state)
            safe_section(zf, 'summary/artwork-cache-db-summary.txt', artworkdb.summary_text)
            safe_section(zf, 'summary/settings-redacted.txt', _settings_snapshot)
            safe_section(zf, 'summary/profile-files.txt', _profile_file_list)
            safe_section(zf, 'summary/indonesian-movie-artwork-snapshot.txt', _indonesian_movie_snapshot)
            safe_section(zf, 'summary/indonesian-movie-collection-state.txt', indonesian_collection.snapshot_text)
            safe_section(zf, 'runtime/diagnostics/indonesian-collection-sync.txt', indonesian_collection.read_report)
            safe_section(zf, 'summary/thailand-movie-collection-state.txt', thailand_collection.snapshot_text)
            safe_section(zf, 'runtime/diagnostics/thailand-collection-sync.txt', thailand_collection.read_report)
            safe_section(zf, 'logs/kodi-artwork-curator-filtered.log', _filtered_kodi_logs)

            logpath = _translate('special://logpath/')
            for src, dest in ((os.path.join(logpath, 'kodi.log'), 'logs/kodi.log'), (os.path.join(logpath, 'kodi.old.log'), 'logs/kodi.old.log')):
                if _copy_if_exists(zf, src, dest, max_bytes=5_000_000):
                    copied.append(dest)

            # Main DB stays at profile root. Fixed DB files are not bundled in the add-on,
            # and legacy processeditems.db is no longer included in diagnostics by default.
            for filename in ('artwork-cache.db',):
                src = os.path.join(profile, filename)
                if _copy_if_exists(zf, src, 'profile/' + filename):
                    copied.append('profile/' + filename)

            diagdir = _diagnostics_dir()
            for filename in sorted(os.listdir(diagdir)) if os.path.isdir(diagdir) else []:
                if filename.lower().endswith('.zip'):
                    continue
                src = os.path.join(diagdir, filename)
                if not os.path.isfile(src):
                    continue
                max_bytes = 5_000_000 if filename.endswith(('.log', '.csv', '.txt', '.old')) else None
                if _copy_if_exists(zf, src, 'runtime/diagnostics/' + filename, max_bytes=max_bytes):
                    copied.append('runtime/diagnostics/' + filename)

            addon_base = _translate('special://home/addons/script.artwork.curator/')
            for filename in ('addon.xml', 'CUSTOM_BUILD_NOTES.md', 'changelog.txt'):
                _copy_if_exists(zf, os.path.join(addon_base, filename), 'addon/' + filename)

            if section_errors:
                _write_text(zf, 'summary/diagnostics-errors.txt', '\n'.join(section_errors) + '\n')
            _write_text(zf, 'summary/included-files.txt', '\n'.join(copied) + '\n')

        # Validate the temporary ZIP before removing old exports. Then keep only
        # the latest finished diagnostics ZIP in the add-on profile.
        with zipfile.ZipFile(tmp_path, 'r') as test_zf:
            bad = test_zf.testzip()
            if bad:
                raise RuntimeError('Diagnostics ZIP validation failed at {0}'.format(bad))
        removed = _delete_old_diagnostics_zips(profile, keep=tmp_path)
        try:
            for legacy_name in os.listdir(_diagnostics_dir()):
                if _is_diagnostics_zip_name(legacy_name):
                    os.remove(os.path.join(_diagnostics_dir(), legacy_name))
                    removed += 1
        except Exception:
            pass
        os.replace(tmp_path, zip_path)
        runtrace.event('diagnostics', 'old diagnostics zips removed', removed=removed)
        log('Diagnostics exported: {0}'.format(zip_path), xbmc.LOGINFO, 'diagnostics')
        xbmcgui.Dialog().notification('Library Artwork Curator', ('DIAGNOSTICS EXPORTED - {0}'.format(os.path.basename(zip_path)))[:58].upper(), xbmcgui.NOTIFICATION_INFO, 7000)
        return zip_path
    except Exception as ex:
        try:
            if os.path.isfile(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        try:
            fallback = os.path.join(profile, DIAG_PREFIX + stamp + '-FAILED.zip')
            with zipfile.ZipFile(fallback, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
                _write_text(zf, 'summary/export-failed.txt', traceback.format_exc())
                _write_text(zf, 'summary/environment.txt', _environment_snapshot())
            zip_path = fallback
        except Exception:
            pass
        log('Diagnostics export failed: {0}'.format(repr(ex)), xbmc.LOGERROR, 'diagnostics')
        log(traceback.format_exc(), xbmc.LOGERROR, 'diagnostics')
        xbmcgui.Dialog().notification('Library Artwork Curator', 'DIAGNOSTICS EXPORT FAILED - CHECK KODI.LOG', xbmcgui.NOTIFICATION_ERROR, 8000)
        return zip_path if os.path.isfile(zip_path) else None


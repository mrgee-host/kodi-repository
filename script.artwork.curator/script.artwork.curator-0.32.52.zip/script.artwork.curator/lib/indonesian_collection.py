import os
import time
import traceback

import xbmc
import xbmcgui
from lib.familyui import notify as family_notify
import xbmcvfs

from lib.libs import mediatypes, mediainfo as info, quickjson
from lib.libs.addonsettings import settings
from lib.libs.pykodi import log


REPORT_FILENAME = 'indonesian-collection-sync.txt'
DEFAULT_COLLECTION_NAME = 'Indonesian Movies Collection'


def _translate(path):
    value = xbmcvfs.translatePath(path)
    if isinstance(value, bytes):
        value = value.decode('utf-8', 'replace')
    return value


def _report_path():
    path = _translate(
        'special://profile/addon_data/script.artwork.curator/'
        'runtime/diagnostics/{0}'.format(REPORT_FILENAME)
    )
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


def _write_report(lines):
    path = _report_path()
    temp = path + '.tmp'
    try:
        with open(temp, 'w', encoding='utf-8', newline='\n') as handle:
            handle.write('\n'.join(str(line) for line in lines).rstrip() + '\n')
        os.replace(temp, path)
    except Exception:
        try:
            if os.path.exists(temp):
                os.remove(temp)
        except Exception:
            pass
        raise
    return path


def read_report():
    path = _report_path()
    if not os.path.isfile(path):
        return (
            'Indonesian movie collection sync\n'
            '================================\n\n'
            'No collection sync has run yet.\n'
        )
    try:
        with open(path, 'r', encoding='utf-8') as handle:
            return handle.read()
    except Exception as exc:
        return 'Could not read collection sync report: {0!r}\n'.format(exc)


def _target_name():
    value = str(getattr(settings, 'indonesian_collection_name', '') or '').strip()
    return value or DEFAULT_COLLECTION_NAME


def _set_rows():
    return quickjson.get_item_list(mediatypes.MOVIESET)


def _set_maps():
    by_id = {}
    by_name = {}
    for row in _set_rows():
        try:
            setid = int(row.get('setid'))
        except Exception:
            continue
        label = str(row.get('label') or row.get('title') or '').strip()
        by_id[setid] = label
        if label:
            by_name[label.casefold()] = setid
    return by_id, by_name


def _movie_rows():
    return quickjson.get_item_list(mediatypes.MOVIE)


def _indonesian_rows(movie_ids=None):
    wanted = None
    if movie_ids is not None:
        wanted = set()
        for value in movie_ids:
            try:
                wanted.add(int(value))
            except Exception:
                continue

    rows = []
    for row in _movie_rows():
        try:
            movieid = int(row.get('movieid'))
        except Exception:
            continue
        if wanted is not None and movieid not in wanted:
            continue
        mediaitem = info.MediaItem(row)
        if mediaitem.indonesia_hint:
            rows.append(row)
    return rows


def _refresh_target_id(target_name):
    _, by_name = _set_maps()
    return by_name.get(target_name.casefold())


def sync(reason='manual', movie_ids=None, notify=False):
    """Enforce one Kodi movie set for every Indonesian-folder movie.

    Kodi exposes movie-set assignment through VideoLibrary.SetMovieDetails(set=...).
    A movie has one set assignment, so assigning the Indonesian set replaces any
    previous collection assignment.
    """
    if not getattr(settings, 'indonesian_collection_sync', True):
        lines = [
            'Indonesian movie collection sync',
            '================================',
            '',
            'Result          : Disabled in settings',
            'Reason          : {0}'.format(reason),
            'Recorded at     : {0}'.format(time.strftime('%Y-%m-%d %H:%M:%S')),
        ]
        _write_report(lines)
        return {
            'success': True,
            'disabled': True,
            'total': 0,
            'changed': 0,
            'failed': 0,
        }

    target_name = _target_name()
    started = time.time()
    changed = []
    unchanged = []
    failed = []
    former_set_ids = set()

    try:
        set_by_id_before, set_by_name_before = _set_maps()
        target_id = set_by_name_before.get(target_name.casefold())
        rows = _indonesian_rows(movie_ids)

        for row in rows:
            movieid = int(row.get('movieid'))
            title = str(row.get('label') or row.get('title') or 'Movie {0}'.format(movieid))
            file_path = str(row.get('file') or '')
            old_set_id = row.get('setid')
            try:
                old_set_id = int(old_set_id) if old_set_id not in (None, '') else None
            except Exception:
                old_set_id = None
            old_set_name = set_by_id_before.get(old_set_id, '') if old_set_id else ''

            if target_id is not None and old_set_id == target_id:
                unchanged.append((movieid, title, file_path))
                continue

            if old_set_id and old_set_id != target_id:
                former_set_ids.add(old_set_id)

            try:
                quickjson.set_item_details(
                    movieid,
                    mediatypes.MOVIE,
                    set=target_name,
                )
                verify = quickjson.get_item_details(movieid, mediatypes.MOVIE) or {}
                new_set_id = verify.get('setid')
                try:
                    new_set_id = int(new_set_id) if new_set_id not in (None, '') else None
                except Exception:
                    new_set_id = None

                if target_id is None:
                    target_id = _refresh_target_id(target_name)

                if target_id is None or new_set_id != target_id:
                    raise RuntimeError(
                        'Kodi did not return the expected target set id '
                        '(expected={0}, actual={1})'.format(target_id, new_set_id)
                    )

                changed.append({
                    'movieid': movieid,
                    'title': title,
                    'file': file_path,
                    'old_set_id': old_set_id,
                    'old_set_name': old_set_name or '<none>',
                    'new_set_id': target_id,
                })
            except Exception as exc:
                failed.append({
                    'movieid': movieid,
                    'title': title,
                    'file': file_path,
                    'error': repr(exc),
                })

        set_by_id_after, _ = _set_maps()
        former_visibility = []
        for old_id in sorted(former_set_ids):
            old_name = set_by_id_before.get(old_id, 'Set {0}'.format(old_id))
            former_visibility.append({
                'setid': old_id,
                'name': old_name,
                'still_visible': old_id in set_by_id_after,
            })

        elapsed_ms = int((time.time() - started) * 1000)
        lines = [
            'Indonesian movie collection sync',
            '================================',
            '',
            'Recorded at      : {0}'.format(time.strftime('%Y-%m-%d %H:%M:%S')),
            'Reason           : {0}'.format(reason),
            'Target collection: {0}'.format(target_name),
            'Target set ID    : {0}'.format(target_id if target_id is not None else '<not resolved>'),
            'Folder markers   : {0}'.format(
                ' | '.join(getattr(settings, 'indonesian_movie_path_markers', ()) or info.INDO_PATH_MARKERS)
            ),
            '',
            'SUMMARY',
            '-------',
            'Indonesian movies found : {0}'.format(len(rows)),
            'Moved to target         : {0}'.format(len(changed)),
            'Already correct         : {0}'.format(len(unchanged)),
            'Failed                  : {0}'.format(len(failed)),
            'Elapsed                 : {0} ms'.format(elapsed_ms),
            '',
            'RULE',
            '----',
            'Every movie whose file path matches an Indonesian folder marker',
            'must belong only to the target collection.',
            'Assigning the target collection replaces the previous Kodi movie set.',
            '',
        ]

        if changed:
            lines.extend(['MOVED MOVIES', '------------'])
            for item in changed:
                lines.extend([
                    '',
                    'Title       : {0}'.format(item['title']),
                    'Movie ID    : {0}'.format(item['movieid']),
                    'Old set     : {0} (id={1})'.format(
                        item['old_set_name'],
                        item['old_set_id'] if item['old_set_id'] is not None else '-',
                    ),
                    'New set     : {0} (id={1})'.format(target_name, item['new_set_id']),
                    'File        : {0}'.format(item['file'] or '-'),
                ])
            lines.append('')

        if former_visibility:
            lines.extend(['FORMER COLLECTIONS', '------------------'])
            for item in former_visibility:
                lines.append(
                    '{0} (id={1}) : {2}'.format(
                        item['name'],
                        item['setid'],
                        'still visible in Kodi movie-set list'
                        if item['still_visible']
                        else 'no longer visible in Kodi movie-set list',
                    )
                )
            lines.append('')

        if failed:
            lines.extend(['FAILURES', '--------'])
            for item in failed:
                lines.extend([
                    '',
                    'Title    : {0}'.format(item['title']),
                    'Movie ID : {0}'.format(item['movieid']),
                    'File     : {0}'.format(item['file'] or '-'),
                    'Error    : {0}'.format(item['error']),
                ])
            lines.append('')

        report_path = _write_report(lines)
        result = {
            'success': not failed,
            'disabled': False,
            'total': len(rows),
            'changed': len(changed),
            'unchanged': len(unchanged),
            'failed': len(failed),
            'target_name': target_name,
            'target_id': target_id,
            'report_path': report_path,
        }

        if notify:
            icon = xbmcgui.NOTIFICATION_INFO if not failed else xbmcgui.NOTIFICATION_WARNING
            family_notify('INDONESIAN COLLECTION FINISHED - {0} MOVED - {1} ERRORS'.format(len(changed), len(failed)), icon, 7000)
        return result

    except Exception as exc:
        lines = [
            'Indonesian movie collection sync',
            '================================',
            '',
            'Recorded at : {0}'.format(time.strftime('%Y-%m-%d %H:%M:%S')),
            'Reason      : {0}'.format(reason),
            'Result      : FAILED',
            'Error       : {0!r}'.format(exc),
            '',
            traceback.format_exc(),
        ]
        try:
            _write_report(lines)
        except Exception:
            pass
        log(
            'Indonesian collection sync failed: {0!r}'.format(exc),
            xbmc.LOGERROR,
            'indonesian-collection',
        )
        if notify:
            family_notify('INDONESIAN COLLECTION FAILED - 1 ERROR', xbmcgui.NOTIFICATION_ERROR, 7000)
        return {
            'success': False,
            'disabled': False,
            'total': 0,
            'changed': 0,
            'failed': 1,
            'error': repr(exc),
        }


def snapshot_text():
    """Fresh human-readable collection state for diagnostics export."""
    target_name = _target_name()
    rows_out = [
        'Indonesian movie collection state',
        '=================================',
        '',
        'Generated at     : {0}'.format(time.strftime('%Y-%m-%d %H:%M:%S')),
        'Sync enabled     : {0}'.format(bool(getattr(settings, 'indonesian_collection_sync', True))),
        'Target collection: {0}'.format(target_name),
        '',
    ]
    try:
        set_by_id, set_by_name = _set_maps()
        target_id = set_by_name.get(target_name.casefold())
        movies = _indonesian_rows()
        correct = []
        wrong = []
        for row in movies:
            movieid = int(row.get('movieid'))
            title = str(row.get('label') or row.get('title') or movieid)
            setid = row.get('setid')
            try:
                setid = int(setid) if setid not in (None, '') else None
            except Exception:
                setid = None
            item = {
                'movieid': movieid,
                'title': title,
                'file': str(row.get('file') or ''),
                'setid': setid,
                'setname': set_by_id.get(setid, '<none>') if setid else '<none>',
            }
            if target_id is not None and setid == target_id:
                correct.append(item)
            else:
                wrong.append(item)

        rows_out.extend([
            'Target set ID           : {0}'.format(target_id if target_id is not None else '<not found>'),
            'Indonesian movies       : {0}'.format(len(movies)),
            'Correct target set      : {0}'.format(len(correct)),
            'Wrong or missing set    : {0}'.format(len(wrong)),
            '',
        ])
        if wrong:
            rows_out.extend(['WRONG OR MISSING SET', '--------------------'])
            for item in wrong:
                rows_out.extend([
                    '',
                    'Title    : {0}'.format(item['title']),
                    'Movie ID : {0}'.format(item['movieid']),
                    'Set      : {0} (id={1})'.format(
                        item['setname'],
                        item['setid'] if item['setid'] is not None else '-',
                    ),
                    'File     : {0}'.format(item['file'] or '-'),
                ])
            rows_out.append('')
        else:
            rows_out.append('All Indonesian-folder movies are in the target collection.')
            rows_out.append('')
    except Exception:
        rows_out.extend(['STATE ERROR:', traceback.format_exc()])
    return '\n'.join(rows_out).rstrip() + '\n'

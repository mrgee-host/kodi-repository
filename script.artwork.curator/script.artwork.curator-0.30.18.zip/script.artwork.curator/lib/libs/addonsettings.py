import xbmc
from lib.libs import pykodi
try:
    import projectkeys
except ImportError:
    projectkeys = None

addon = pykodi.get_main_addon()
DEFAULT_IMAGESIZE = '1'
AVAILABLE_IMAGESIZES = {'0': (10000, 10000, 600), '1': (1920, 1080, 600), '2': (1280, 720, 480)}
PROGRESS_DISPLAY_FULLPROGRESS = '0'
PROGRESS_DISPLAY_WARNINGSERRORS = '1'
PROGRESS_DISPLAY_NONE = '2'
EXCLUSION_PATH_TYPE_FOLDER = '0'
EXCLUSION_PATH_TYPE_PREFIX = '1'
EXCLUSION_PATH_TYPE_REGEX = '2'

class Settings(object):
    def __init__(self):
        self.addon_path = addon.path
        self.datapath = addon.datapath
        self._autoadd_episodes = ()
        self.update_settings()
        self.update_useragent()

    def update_useragent(self):
        self.useragent = 'ArtworkCurator/{0} '.format(pykodi.get_main_addon().version) + xbmc.getUserAgent()

    def update_settings(self):
        # Enable automatic new-video processing once after installing 0.30.6.
        # The visible setting remains user-controllable afterwards.
        if not addon.get_setting('auto_service_initialized_0306'):
            addon.set_setting('enableservice', True)
            addon.set_setting('auto_service_initialized_0306', True)
        self._autoadd_episodes = addon.get_setting('autoaddepisodes_list') if (addon.get_setting('episode.thumb') or addon.get_setting('episode.landscape')) else ()
        self.enableservice = addon.get_setting('enableservice')
        self.enable_olditem_updates = addon.get_setting('enable_olditem_updates')
        self.titlefree_fanart = addon.get_setting('titlefree_fanart')
        self.titlefree_poster = addon.get_setting('titlefree_poster')
        self.setartwork_fromparent = False
        self.setartwork_subdirs = True
        self.identify_alternatives = False
        self.report_peritem = addon.get_setting('report_peritem')
        self.fanarttv_clientkey = addon.get_setting('fanarttv_key')
        self.default_tvidsource = addon.get_setting('default_tvidsource') or 'tmdb'
        self.progressdisplay = addon.get_setting('progress_display') or PROGRESS_DISPLAY_FULLPROGRESS
        self.final_notification = addon.get_setting('final_notification')
        self.remove_deselected_files = False
        self.recycle_removed = False
        self.cache_remote_video_artwork = addon.get_setting('precache_during_scan')
        self.clean_imageurls = True
        self.use_tmdb_keyart = True
        self.remote_only_mode = True

        self.language_override = addon.get_setting('language_override')
        if self.language_override in ('', 'None'):
            self.language_override = None
        self.language_fallback_kodi = addon.get_setting('language_fallback_kodi')
        self.language_fallback_en = addon.get_setting('language_fallback_en')
        try:
            self.minimum_rating = int(addon.get_setting('minimum_rating'))
        except (TypeError, ValueError):
            self.minimum_rating = 5
        try:
            self.minimum_poster_height = int(addon.get_setting('minimum_poster_height') or 1000)
        except (TypeError, ValueError):
            self.minimum_poster_height = 1000
        sizesetting = addon.get_setting('preferredsize') or DEFAULT_IMAGESIZE
        if sizesetting not in AVAILABLE_IMAGESIZES:
            sizesetting = DEFAULT_IMAGESIZE
        self.preferredsize = AVAILABLE_IMAGESIZES[sizesetting][0:2]
        self.minimum_size = AVAILABLE_IMAGESIZES[sizesetting][2]

        self.apiconfig = {}
        for provider in ('fanarttv', 'tvdb', 'tmdb'):
            key = (addon.get_setting('apikey.' + provider) or '').strip()
            self.apiconfig[provider] = {'apikey': key, 'apikey-builtin': not key,
                'enabled': addon.get_setting('apienabled.' + provider)}
            if not key and projectkeys:
                self.apiconfig[provider]['apikey'] = get_projectkey(provider)
            pykodi.set_log_scrubstring(provider + '-apikey', key)

        self.pathexclusion = []
        for index in range(1, 11):
            suffix = str(index)
            if not addon.get_setting('exclude.path.option_' + suffix):
                continue
            self.pathexclusion.append({
                'type': addon.get_setting('exclude.path.type_' + suffix),
                'folder': addon.get_setting('exclude.path.folder_' + suffix),
                'prefix': addon.get_setting('exclude.path.prefix_' + suffix),
                'regex': addon.get_setting('exclude.path.regex_' + suffix),
            })
        pykodi.set_log_scrubstring('fanarttv-client-apikey', self.fanarttv_clientkey)

    def get_apikey(self, provider):
        return self.apiconfig[provider]['apikey']

    def get_apienabled(self, provider):
        return self.apiconfig[provider]['enabled']

    def get_api_config(self, provider):
        return self.apiconfig[provider]

    @property
    def autoadd_episodes(self):
        return self._autoadd_episodes

    @autoadd_episodes.setter
    def autoadd_episodes(self, value):
        self._autoadd_episodes = value
        addon.set_setting('autoaddepisodes_list', value)

def get_projectkey(provider):
    if provider == 'fanarttv':
        return projectkeys.FANARTTV_PROJECTKEY
    if provider == 'tvdb':
        return projectkeys.THETVDB_PROJECTKEY
    if provider == 'tmdb':
        return projectkeys.TMDB_PROJECTKEY
    return ''

settings = Settings()

from urllib.parse import quote
from lib.libs import pykodi, mediatypes, quickjson
from lib.libs.mediainfo import iter_base_arttypes, fill_multiart, keep_arttype
from lib.libs.addonsettings import settings

old_urls_fix = {
    'tvdb': (('http://www.thetvdb.com/banners/', 'http://thetvdb.com/banners/', 'https://thetvdb.com/banners/'),
        'https://www.thetvdb.com/banners/', 'thetvdb.com/banners/')
}
RASTER_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.webp')

def _is_remote_url(url):
    return (url or '').lower().startswith(('http://', 'https://'))

def _is_svg_url(url):
    lower = (url or '').lower().split('?', 1)[0]
    return lower.endswith('.svg')

def clean_artwork(mediaitem):
    updated = dict(_get_clean_art(*art) for art in mediaitem.art.items())
    for basetype in iter_base_arttypes(updated.keys()):
        updated.update(fill_multiart(updated, basetype))
    # Episode still artwork is intentionally exposed only as thumb and landscape.
    # Remove legacy episode fanart/fanart1... entries during the next normal scan.
    if mediaitem.mediatype == mediatypes.EPISODE:
        for arttype in list(updated):
            if arttype == 'fanart' or (arttype.startswith('fanart') and arttype[6:].isdigit()):
                updated[arttype] = None

    for arttype, url in list(updated.items()):
        if not url:
            continue
        # The custom fork is deliberately remote-only. Keep generated Kodi image://
        # thumbnails, but clear raw local paths, stale local artwork, and SVG URLs.
        if url.startswith('image://'):
            continue
        # Preserve manually selected remote URLs even when the provider uses an
        # extensionless asset URL (for example a poster-service CDN endpoint).
        # Only explicit SVG URLs are rejected here. New provider candidates are
        # still gathered from the configured remote artwork providers.
        if not _is_remote_url(url) or _is_svg_url(url):
            updated[arttype] = None
            continue
        for cfg in old_urls_fix.values():
            if url.startswith(cfg[0]):
                updated[arttype] = cfg[1] + url[url.index(cfg[2]) + len(cfg[2]):]
                quickjson.remove_texture_byurl(url)
    return updated

def remove_specific_arttype(mediaitem, arttype):
    if arttype == '* all':
        return dict((atype, None) for atype in mediaitem.art)
    if arttype == '* nowhitelist':
        return dict((atype, None) for atype, url in mediaitem.art.items()
            if not keep_arttype(mediaitem.mediatype, atype, url))
    return {arttype: None} if arttype in mediaitem.art else {}

def _get_clean_art(arttype, url):
    if not url:
        return arttype, None
    if url.startswith(('http://', 'https://')):
        return arttype, quote(url, safe="%/:=&?~#+!$,;'@()*[]")
    return arttype, url

import os
import xbmc
import xbmcvfs

from lib.libs.addonsettings import settings
from lib.libs.pykodi import log

LOG_NAME = 'indonesian-refresh-debug.txt'


def _path():
    return settings.datapath.rstrip('/\\') + '/' + LOG_NAME


def _local_path():
    value = xbmcvfs.translatePath(_path())
    if isinstance(value, bytes):
        value = value.decode('utf-8', 'replace')
    return value


def _ensure_parent():
    parent = os.path.dirname(_local_path())
    if parent and not os.path.isdir(parent):
        os.makedirs(parent, exist_ok=True)


def reset():
    try:
        _ensure_parent()
        with open(_local_path(), 'w', encoding='utf-8', errors='replace') as handle:
            handle.write('Artwork Curator - Indonesian refresh debug log\n')
            handle.write('=' * 72 + '\n')
        log('Indonesian refresh debug log reset: {0}'.format(_local_path()), xbmc.LOGINFO, 'indorefresh')
    except Exception as ex:
        log('Could not reset Indonesian refresh debug log: {0}'.format(repr(ex)), xbmc.LOGWARNING, 'indorefresh')


def write(message=''):
    try:
        _ensure_parent()
        with open(_local_path(), 'a', encoding='utf-8', errors='replace') as handle:
            handle.write(str(message) + '\n')
    except Exception as ex:
        log('Could not append Indonesian refresh debug log: {0}'.format(repr(ex)), xbmc.LOGWARNING, 'indorefresh')


def important(message):
    write(message)
    log(str(message), xbmc.LOGINFO, 'indorefresh')


def get_text():
    try:
        if not os.path.isfile(_local_path()):
            return 'No Indonesian refresh debug log exists yet.'
        with open(_local_path(), 'r', encoding='utf-8', errors='replace') as handle:
            return handle.read()
    except Exception as ex:
        return 'Could not read Indonesian refresh debug log: {0}'.format(repr(ex))


def format_value(value):
    if value is None:
        return '-'
    return str(value)


def format_candidate(index, candidate):
    provider = candidate.get('provider')
    provider_name = getattr(provider, 'display', None) or getattr(provider, 'sort', None) or str(provider)
    size = candidate.get('size')
    rating = candidate.get('rating')
    size_display = getattr(size, 'display', None) or format_value(size)
    size_sort = getattr(size, 'sort', None)
    rating_display = getattr(rating, 'display', None) or format_value(rating)
    rating_sort = getattr(rating, 'sort', None)
    return (
        '    [{0}] provider={1} | language={2} | size={3} (sort={4}) | '
        'rating={5} (sort={6}) | rating_unrated={7} | localized_primary={8} | gallery_order={9}\n'
        '         url={10}'
    ).format(
        index,
        provider_name,
        format_value(candidate.get('language')),
        size_display,
        format_value(size_sort),
        rating_display,
        format_value(rating_sort),
        bool(candidate.get('rating_unrated')),
        bool(candidate.get('localized_primary')),
        format_value(candidate.get('gallery_order')),
        format_value(candidate.get('url')),
    )

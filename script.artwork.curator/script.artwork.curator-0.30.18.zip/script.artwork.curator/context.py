import sys
import xbmc
from lib.artworkprocessor import ArtworkProcessor

VIDEO_TYPES = ('movie', 'set', 'tvshow', 'season', 'episode')

def main(mode):
    listitem = sys.listitem
    mediatype = get_mediatype(listitem)
    dbid = get_dbid(listitem)
    if dbid and mediatype in VIDEO_TYPES:
        ArtworkProcessor().process_item(mediatype, dbid, mode)

def get_mediatype(listitem):
    try:
        mediatype = listitem.getVideoInfoTag().getMediaType()
        if mediatype:
            return mediatype
    except AttributeError:
        pass
    return xbmc.getInfoLabel('ListItem.DBTYPE')

def get_dbid(listitem):
    try:
        return listitem.getVideoInfoTag().getDbId()
    except AttributeError:
        value = xbmc.getInfoLabel('ListItem.DBID')
        return int(value) if value else None

if __name__ == '__main__':
    main('auto')

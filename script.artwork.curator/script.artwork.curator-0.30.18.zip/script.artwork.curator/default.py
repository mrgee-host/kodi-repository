import sys
import xbmc
import xbmcgui
from itertools import chain

from lib import cleaner, reporting, refreshdebug, diagnostics, runtrace
from lib.artworkprocessor import ArtworkProcessor
from lib.filemanager import FileManager
from lib.libs import mediainfo as info, mediatypes, pykodi, quickjson, utils
from lib.libs.addonsettings import settings
from lib.libs.processeditems import ProcessedItems
from lib.libs.pykodi import log
from lib.providers import search

REMOTE_HOST_MARKERS = ('image.tmdb.org', 'fanart.tv', 'thetvdb.com')


def main():
    settings.update_settings()
    mediatypes.update_settings()
    command = get_command()
    runtrace.event('menu', 'default.py invoked', argv=sys.argv[1:], command=command)
    if command.get('dbid') and command.get('mediatype'):
        with runtrace.run_context('command.process_item', mediatype=command['mediatype'], dbid=command['dbid'], mode=command.get('mode', 'auto')):
            ArtworkProcessor().process_item(command['mediatype'], int(command['dbid']), command.get('mode', 'auto'))
        return
    if command.get('command') == 'show_artwork_log':
        runtrace.event('menu', 'show artwork log command')
        show_artwork_log()
        return

    processor = ArtworkProcessor()
    if processor.processor_busy:
        options = [('Stop current process', 'NotifyAll(script.artwork.curator:control, CancelCurrent)')]
    else:
        options = [
            ('Add missing artwork ...', add_missing_for),
            ('Refresh Indonesian movie artwork', refresh_indonesian_artwork),
            ('Show Indonesian refresh log', show_indonesian_refresh_log),
            ('Identify unmatched movie sets', identify_unmatched_sets),
            ('Remove artwork type ...', remove_specific_arttypes),
            ('Cache missing artwork', lambda: cache_artwork(False)),
            ('Prune obsolete cache', prune_obsolete_cache),
            ('Force recache all artwork', lambda: cache_artwork(True)),
            ('Show latest report', show_artwork_log),
            ('Export diagnostics', diagnostics.export),
        ]
    selected = xbmcgui.Dialog().select('Artwork Curator', [label for label, _ in options])
    runtrace.event('menu', 'main selection', selected=selected, option=options[selected][0] if 0 <= selected < len(options) else '<cancel>')
    if 0 <= selected < len(options):
        label, action = options[selected]
        if isinstance(action, str):
            runtrace.event('menu', 'execute builtin', label=label, builtin=action)
            pykodi.execute_builtin(action)
        elif label == 'Export diagnostics':
            runtrace.event('menu', 'export diagnostics selected')
            action()
        else:
            with runtrace.run_context('menu.' + label):
                action()


def add_missing_for():
    options = [
        ('Only new video-library items', 'ProcessNewVideosManual'),
        ('New items and scheduled older items', 'ProcessNewAndOldVideosManual'),
        ('All video-library items', 'ProcessAllVideosManual'),
    ]
    selected = xbmcgui.Dialog().select('Add missing artwork for ...', [label for label, _ in options])
    runtrace.event('menu', 'add missing selection', selected=selected, option=options[selected][0] if 0 <= selected < len(options) else '<cancel>')
    if 0 <= selected < len(options):
        builtin = 'NotifyAll(script.artwork.curator:control, {0})'.format(options[selected][1])
        runtrace.event('menu', 'queue service signal', signal=options[selected][1], builtin=builtin)
        pykodi.execute_builtin(builtin)


def show_indonesian_refresh_log():
    xbmcgui.Dialog().textviewer('Artwork Curator - Indonesian movie refresh log', refreshdebug.get_text())


def refresh_indonesian_artwork():
    confirm = xbmcgui.Dialog().yesno(
        'Refresh Indonesian movie artwork',
        'Re-check artwork for movies inside the Indonesian Movies collection folder?\n\n'
        'TV shows, seasons, episodes, and movie sets use the common flow. '
        'Existing TPDb or other manually chosen non-curator URLs will be preserved.',
        'Cancel',
        'Refresh'
    )
    if not confirm:
        return

    refreshdebug.reset()
    refreshdebug.important('START Refresh Indonesian movie artwork')
    refreshdebug.write('Accepted path markers: {0}'.format(', '.join(info.INDO_PATH_MARKERS)))
    items = []
    scan_counts = {'movie': 0}
    included_counts = {'movie': 0}

    def inspect_row(row):
        mediaitem = info.MediaItem(row)
        scan_counts['movie'] += 1
        included = bool(mediaitem.indonesia_hint)
        refreshdebug.write(
            'SCAN movie:{0} | included={1} | label={2} | file={3}'.format(
                mediaitem.dbid, included, mediaitem.label, mediaitem.file or '-'
            )
        )
        if included:
            included_counts['movie'] += 1
            items.append(mediaitem)

    if not mediatypes.disabled(mediatypes.MOVIE):
        for row in quickjson.get_item_list(mediatypes.MOVIE):
            inspect_row(row)

    refreshdebug.important('SCAN COUNTS: {0}'.format(scan_counts))
    refreshdebug.important('INCLUDED COUNTS: {0}'.format(included_counts))
    refreshdebug.important('TOTAL INCLUDED: {0}'.format(len(items)))

    if not items:
        xbmcgui.Dialog().notification('Artwork Curator', 'No Indonesian movies were found.', xbmcgui.NOTIFICATION_INFO)
        return

    success = ArtworkProcessor().process_medialist(
        items,
        alwaysnotify=True,
        foreground=False,
        force_progress=True,
        refresh_indonesian=True,
    )
    refreshdebug.important('END Refresh Indonesian movie artwork | success={0}'.format(success))


def iter_video_lists():
    return (
        ('Movies', lambda: quickjson.get_item_list(mediatypes.MOVIE), mediatypes.MOVIE),
        ('TV shows', quickjson.get_tvshows, mediatypes.TVSHOW),
        ('Seasons', quickjson.get_seasons, mediatypes.SEASON),
        ('Episodes', quickjson.get_episodes, mediatypes.EPISODE),
        ('Movie sets', lambda: quickjson.get_item_list(mediatypes.MOVIESET), mediatypes.MOVIESET),
    )


def _progress_update(progress, percent, message, heading=''):
    percent = max(0, min(100, int(percent)))
    try:
        # DialogProgressBG: percent, heading, message. This is the compact
        # persistent Kodi notification used by the original Artwork Curator.
        progress.update(percent, heading, message)
    except TypeError:
        progress.update(percent, message)


def _compact_arttypes(arttypes, maximum=4):
    clean = []
    for arttype in arttypes or ():
        value = str(arttype or '').strip()
        if value and value not in clean:
            clean.append(value)
    if not clean:
        return ''
    shown = clean[:maximum]
    result = ', '.join(shown)
    if len(clean) > maximum:
        result += ' +{0}'.format(len(clean) - maximum)
    return result


def _arttypes_by_url(artmap):
    reverse = {}
    for key, url in artmap.items():
        arttype = str(key).rsplit(':', 1)[-1]
        reverse.setdefault(url, [])
        if arttype not in reverse[url]:
            reverse[url].append(arttype)
    return reverse


def _status_heading(action, arttypes=()):
    types = _compact_arttypes(arttypes)
    return 'Artwork Curator: {0}{1}'.format(action, ' · ' + types if types else '')


def _progress_cancelled(progress):
    checker = getattr(progress, 'iscanceled', None)
    return bool(checker and checker())


def _set_idle_inhibition(enabled):
    state = 'true' if enabled else 'false'
    pykodi.execute_builtin('InhibitScreensaver({0})'.format(state))
    pykodi.execute_builtin('InhibitIdleShutdown({0})'.format(state))


def collect_video_art(progress=None):
    start_time = xbmc.getGlobalIdleTime() if False else None
    timer = __import__('time').time()
    artmap = {}
    groups = list(iter_video_lists())
    for index, (label, list_fn, _) in enumerate(groups):
        if progress and _progress_cancelled(progress):
            break
        _progress_update(progress, int(index * 20 / float(len(groups) or 1)),
            label, _status_heading('Checking')) if progress else None
        for item in list_fn():
            for arttype, url in item.get('art', {}).items():
                url = pykodi.unquoteimage(url)
                if url and url.startswith(('http://', 'https://', 'image://')):
                    artmap['{0}:{1}'.format(len(artmap), arttype)] = url
    runtrace.event('library', 'collect_video_art complete', urls=len(artmap), elapsed_ms=int((__import__('time').time() - timer) * 1000))
    return artmap


def cache_artwork(force=False):
    runtrace.event('cache', 'cache_artwork start', force=force)
    heading = 'Force recache all artwork' if force else 'Cache missing artwork'
    if force and not xbmcgui.Dialog().yesno('Artwork Curator',
            'Remove the current texture-cache entries for all video artwork and cache them again?'):
        return
    progress = xbmcgui.DialogProgressBG()
    _set_idle_inhibition(True)
    progress.create('Artwork Curator: ' + heading, '')
    cancelled = False
    try:
        artmap = collect_video_art(progress)
        types_by_url = _arttypes_by_url(artmap)
        if _progress_cancelled(progress):
            cancelled = True
            return
        fileman = FileManager(False, True)
        if not fileman.imagecachebase:
            xbmcgui.Dialog().notification('Artwork Curator', 'Enable Kodi web server / remote control via HTTP first.', xbmcgui.NOTIFICATION_WARNING)
            return
        if force:
            urls = sorted(set(artmap.values()))
            total = len(urls)
            for index, url in enumerate(urls, 1):
                if _progress_cancelled(progress):
                    cancelled = True
                    return
                _progress_update(progress, 20 + int(index * 20 / float(total or 1)),
                    '{0}/{1}'.format(index, total), _status_heading('Removing', types_by_url.get(url, ())))
                quickjson.remove_texture_byurl(url)
            fileman.alreadycached = []

        def on_cache_progress(done, total, url):
            base = 40 if force else 20
            span = 60 if force else 80
            _progress_update(progress, base + int(done * span / float(total or 1)),
                '{0}/{1}'.format(done, total), _status_heading('Downloading', types_by_url.get(url, ())))

        count = fileman.cachefor(
            artmap,
            multiplethreads=True,
            progress_callback=on_cache_progress,
            cancel_callback=lambda: _progress_cancelled(progress),
        )
        cancelled = _progress_cancelled(progress)
    finally:
        progress.close()
        _set_idle_inhibition(False)
    if cancelled:
        xbmcgui.Dialog().notification('Artwork Curator', 'Cache process cancelled.', xbmcgui.NOTIFICATION_WARNING)
    else:
        xbmcgui.Dialog().ok('Artwork Curator', 'Cached {0} missing remote artwork images.'.format(count))


def prune_obsolete_cache():
    runtrace.event('cache', 'prune_obsolete_cache start')
    if not xbmcgui.Dialog().yesno('Artwork Curator',
            'Remove cached TMDb, fanart.tv, and TheTVDB images that are no longer referenced by the video library?'):
        return
    progress = xbmcgui.DialogProgressBG()
    _set_idle_inhibition(True)
    progress.create('Artwork Curator: Pruning obsolete remote cache', '')
    cancelled = False
    removed = 0
    try:
        active_artmap = collect_video_art(progress)
        active = set(active_artmap.values())
        types_by_url = _arttypes_by_url(active_artmap)
        textures = quickjson.get_textures()
        total = len(textures)
        for index, texture in enumerate(textures, 1):
            if _progress_cancelled(progress):
                cancelled = True
                break
            url = pykodi.unquoteimage(texture.get('url', ''))
            _progress_update(progress, 20 + int(index * 80 / float(total or 1)),
                '{0}/{1}'.format(index, total), _status_heading('Checking', types_by_url.get(url, ())))
            if not url.startswith(('http://', 'https://')):
                continue
            if not any(host in url.lower() for host in REMOTE_HOST_MARKERS):
                continue
            if url not in active:
                quickjson.remove_texture(texture['textureid'])
                removed += 1
    finally:
        progress.close()
        _set_idle_inhibition(False)
    if cancelled:
        xbmcgui.Dialog().notification('Artwork Curator', 'Prune process cancelled.', xbmcgui.NOTIFICATION_WARNING)
    else:
        xbmcgui.Dialog().ok('Artwork Curator', 'Removed {0} obsolete cached images.'.format(removed))

def remove_specific_arttypes():
    runtrace.event('menu', 'remove_specific_arttypes start')
    groups = list(iter_video_lists())
    selected = xbmcgui.Dialog().select('Choose video content type', [row[0] for row in groups])
    if selected < 0:
        return
    label, list_fn, mediatype = groups[selected]
    items = list_fn()
    counter = {}
    for item in items:
        for arttype, url in item.get('art', {}).items():
            if '.' not in arttype:
                counter[arttype] = counter.get(arttype, 0) + 1
    options = ['* all'] + sorted(counter)
    picked = xbmcgui.Dialog().select(label, ['{0}: {1}'.format(t, len(items) if t == '* all' else counter[t]) for t in options])
    if picked < 0:
        return
    arttype = options[picked]
    if not xbmcgui.Dialog().yesno('Artwork Curator', 'Remove {0} artwork from {1}?'.format(arttype, label)):
        return
    changed = 0
    for row in items:
        mediaitem = info.MediaItem(row)
        updates = cleaner.remove_specific_arttype(mediaitem, arttype)
        if updates:
            info.update_art_in_library(mediaitem.mediatype, mediaitem.dbid, updates)
            changed += len(updates)
    xbmcgui.Dialog().ok('Artwork Curator', 'Removed {0} artwork references.'.format(changed))


def identify_unmatched_sets():
    runtrace.event('menu', 'identify_unmatched_sets start')
    processed = ProcessedItems()
    sets = quickjson.get_item_list(mediatypes.MOVIESET)
    unmatched = [row for row in sets if not processed.get_data(row['setid'], mediatypes.MOVIESET, row['label'])]
    if not unmatched:
        xbmcgui.Dialog().notification('Artwork Curator', 'No unmatched movie sets.')
        return
    selected = xbmcgui.Dialog().select('Choose movie set', [row['label'] for row in unmatched])
    if selected < 0:
        return
    mediaitem = info.MediaItem(unmatched[selected])
    processor = ArtworkProcessor()
    if processor.manual_id(mediaitem):
        processor.process_item(mediatypes.MOVIESET, mediaitem.dbid, 'auto')


def show_artwork_log():
    xbmcgui.Dialog().textviewer('Artwork Curator - latest report', reporting.get_latest_report())


def get_command():
    command = {}
    for argument in sys.argv[1:]:
        key, sep, value = argument.partition('=')
        command[key.strip().lower()] = value.strip() if sep else True
    return command

if __name__ == '__main__':
    main()

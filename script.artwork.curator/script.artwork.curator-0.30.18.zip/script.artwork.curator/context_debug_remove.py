import sys
import xbmcgui
from context import get_dbid, get_mediatype
from lib import cleaner
from lib.libs import quickjson, mediainfo as info
from lib.libs.pykodi import localize as L

def remove_art():
    listitem = sys.listitem
    mediatype = get_mediatype(listitem)
    dbid = get_dbid(listitem)
    if not dbid or not mediatype:
        return
    if not xbmcgui.Dialog().yesno('Artwork Curator', 'Remove every artwork reference for this item?'):
        return
    mediaitem = info.MediaItem(quickjson.get_item_details(dbid, mediatype))
    updates = cleaner.remove_specific_arttype(mediaitem, '* all')
    info.update_art_in_library(mediatype, dbid, updates)
    info.remove_local_from_texturecache(mediaitem.art.values(), True)
    xbmcgui.Dialog().notification('Artwork Curator', 'Removed {0} artwork references.'.format(len(updates)))

if __name__ == '__main__':
    remove_art()

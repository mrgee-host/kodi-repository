Library Artwork Curator 0.32.51

- Fill Missing displays a background progress notification during Kodi library
  collection and artwork-DB candidate checking.
- Stop current process is honored during this preflight stage.
- Kodi season rows often have no unique IDs. An exact show-season title match is
  now accepted after provider-ID conflict checks, preventing valid season artwork
  cache from being deleted on each Fill Missing run.

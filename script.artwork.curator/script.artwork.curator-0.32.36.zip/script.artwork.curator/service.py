import xbmc
import xbmcgui
import traceback
import time
from itertools import chain

from lib.artworkprocessor import ArtworkProcessor
from lib.libs import mediainfo as info, mediatypes, pykodi, quickjson
from lib.libs.addonsettings import settings
from lib import runtrace, artworkdb
from lib.libs.pykodi import log, json

STATUS_IDLE = 'idle'
STATUS_SIGNALLED = 'signalled'
STATUS_PROCESSING = 'processing'
addon = pykodi.get_main_addon()
AUTO_QUIET_DELAY_SECONDS = 3
AUTO_SCAN_RETRY_SECONDS = 2.0
AUTO_SCAN_MAX_ATTEMPTS = 10
AUTO_SCAN_CACHE_FALLBACK_MAX_ITEMS = 100

class ArtworkService(xbmc.Monitor):
    """Video-library listener only. AudioLibrary notifications are intentionally ignored."""
    def __init__(self):
        super(ArtworkService, self).__init__()
        self.abort = False
        self.processor = ArtworkProcessor(self)
        self.processaftersettings = False
        self.recentvideos = {'movie': [], 'tvshow': [], 'episode': []}
        self.stoppeditems = set()
        self._signal = None
        self._status = None
        self._last_videoupdate = addon.get_setting('last_videoupdate') or '0'
        self._scan_snapshot = None
        self._clean_snapshot = None
        self._auto_scan_pending = None
        self._scan_update_added = {'movie': set(), 'tvshow': set(), 'episode': set()}
        self._last_scan_started_at = 0.0
        self._last_scan_finished_at = 0.0
        self.status = STATUS_IDLE

    @property
    def scanning(self):
        return pykodi.get_conditional('Library.IsScanningVideo')

    @property
    def status(self):
        return self._status

    @status.setter
    def status(self, value):
        self._status = value
        self.abort = False
        pykodi.execute_builtin('SetProperty(ArtworkCurator.Status, {0}, Home)'.format(value))
        pykodi.execute_builtin('SetProperty(LibraryArtworkCurator.Status, {0}, Home)'.format(value))
        pykodi.execute_builtin('SetProperty(script.artwork.curator.Status, {0}, Home)'.format(value))

    @property
    def signal(self):
        return self._signal

    @signal.setter
    def signal(self, value):
        self._signal = value
        # Do not clobber PROCESSING while auto-scan queues work in memory.
        # The current job must finish first; the queued signal will be handled
        # by the main loop afterwards.
        if self._status != STATUS_PROCESSING:
            self.status = STATUS_SIGNALLED if value else STATUS_IDLE

    @property
    def last_videoupdate(self):
        return self._last_videoupdate

    @last_videoupdate.setter
    def last_videoupdate(self, value):
        addon.set_setting('last_videoupdate', value)
        self._last_videoupdate = value

    def reset_recent(self):
        self.recentvideos = {'movie': [], 'tvshow': [], 'episode': []}

    def run(self):
        # LRS-style single service loop: Kodi scan callbacks only create a pending
        # auto job. The loop consumes that pending job directly when idle instead
        # of routing it through signal -> quiet delay -> RUN START. Manual signals
        # keep priority.
        while not self.really_waitforabort(0.10):
            signal = self.signal
            if not signal:
                self._consume_auto_scan_job_lrs_style()
                continue
            if self.scanning and signal != 'recentvideos_really':
                continue
            if self.scanning and signal == 'recentvideos_really':
                runtrace.event('service', 'scan flag still true after OnScanFinished; proceeding with legacy auto signal', signal=signal)
            self._signal = None
            try:
                if signal == 'recentvideos':
                    self.signal = 'recentvideos_really'
                    continue
                if self._needs_lrs_lock_wait(signal) and not self._wait_for_shared_lrs_lock(signal):
                    self.signal = signal
                    self.really_waitforabort(5)
                    continue
                if signal == 'recentvideos_really' and not self._wait_for_quiet_auto_start(signal):
                    runtrace.event('service', 'auto fill quiet delay cancelled before processing', signal=signal)
                    self.status = STATUS_IDLE
                    continue
                self.status = STATUS_PROCESSING
                runtrace.event('service', 'service signal entering processing', signal=signal, recent=self.recentvideos)
                with runtrace.run_context('service.signal.' + str(signal), signal=signal):
                    try:
                        if signal == 'allvideos':
                            self.notify_finished(self.process_allvideos())
                        elif signal == 'allvideos_manual':
                            self.notify_finished(self.process_allvideos(force_progress=True))
                        elif signal == 'refreshall_manual':
                            self.notify_finished(self.process_allvideos(force_progress=True, refresh_all=True))
                        elif signal == 'newvideos':
                            self.notify_finished(self.process_recentvideos(refresh_all=False))
                        elif signal == 'newvideos_manual':
                            self.notify_finished(self.process_recentvideos(force_progress=True, notify_empty=True, refresh_all=False))
                        elif signal == 'oldvideos':
                            runtrace.event('service', 'oldvideos ignored; processeditems.db workflow removed')
                            self.notify_finished(True)
                        elif signal == 'oldvideos_manual':
                            runtrace.event('service', 'oldvideos manual ignored; processeditems.db workflow removed')
                            self.notify_finished(True)
                        elif signal == 'recentvideos_really':
                            self.notify_finished(self.process_recentvideos(refresh_all=False, auto=True, force_progress=True), auto=True)
                    except Exception as ex:
                        runtrace.error('Recovered unexpected Library Artwork Curator service error', ex, signal=signal)
                        log('Recovered unexpected Library Artwork Curator service error', xbmc.LOGERROR)
                        log(traceback.format_exc(), xbmc.LOGERROR)
                        try:
                            self.processor.close_progress()
                            self.processor.set_idle_inhibition(False)
                            self.processor.notify_warning('Processing stopped. Check kodi.log.', 'Error', True)
                        except Exception as inner:
                            runtrace.error('Service cleanup after error failed', inner, signal=signal)
                            log(traceback.format_exc(), xbmc.LOGWARNING)
                    finally:
                        self.status = STATUS_IDLE
            except Exception as ex:
                runtrace.error('Recovered pre-run Library Artwork Curator service error', ex, signal=signal)
                log('Recovered pre-run Library Artwork Curator service error', xbmc.LOGERROR)
                log(traceback.format_exc(), xbmc.LOGERROR)
                try:
                    self.processor.close_progress()
                    self.processor.set_idle_inhibition(False)
                    self.status = STATUS_IDLE
                except Exception as inner:
                    runtrace.error('Service pre-run cleanup failed', inner, signal=signal)

    def abortRequested(self):
        return self.waitForAbort(0.0001)

    def waitForAbort(self, timeout=0):
        return self.abort or super(ArtworkService, self).waitForAbort(timeout)

    def really_waitforabort(self, timeout=0):
        return super(ArtworkService, self).waitForAbort(timeout)

    def onNotification(self, sender, method, data):
        runtrace.event('notification', 'received', sender=sender, method=method, data=str(data)[:600])
        if method.startswith('Other.') and sender != 'script.artwork.curator:control':
            return
        if method == 'Other.CancelCurrent':
            if self.status == STATUS_PROCESSING:
                self.abort = True
            elif self._auto_scan_pending:
                pending = self._auto_scan_pending
                self._auto_scan_pending = None
                self.reset_recent()
                self.status = STATUS_IDLE
                self.abort = True
                runtrace.event('service', 'cancelled pending LRS-style auto scan before processing', pending=pending)
                self.processor.close_progress()
            elif self.status == STATUS_SIGNALLED or self.signal:
                # Covers both queued work that has not been consumed yet and the
                # quiet-delay gap after the run loop has consumed _signal but has
                # not entered PROCESSING. The previous build did not cancel that
                # gap because self.signal was already None while Status still read
                # signalled.
                queued_signal = self.signal
                self.signal = None
                self.abort = True
                runtrace.event('service', 'cancelled signalled auto queue before processing', signal=queued_signal)
                self.processor.close_progress()
        elif method == 'Other.ProcessNewVideos':
            self.signal = 'recentvideos'
        elif method == 'Other.ProcessNewVideosManual':
            self.signal = 'newvideos_manual'
        elif method == 'Other.ProcessNewAndOldVideos':
            self.signal = 'oldvideos'
        elif method == 'Other.ProcessNewAndOldVideosManual':
            self.signal = 'oldvideos_manual'
        elif method == 'Other.ProcessAllVideos':
            self.signal = 'allvideos'
        elif method == 'Other.ProcessAllVideosManual':
            self.signal = 'allvideos_manual'
        elif method == 'Other.ProcessRefreshAllArtworkManual':
            self.signal = 'refreshall_manual'
        elif method == 'Other.ProcessAfterSettings':
            self.processaftersettings = True
        elif method == 'VideoLibrary.OnScanStarted' and settings.enableservice:
            self._handle_video_scan_started('notification')
        elif method == 'VideoLibrary.OnScanFinished' and settings.enableservice:
            self._handle_video_scan_finished('notification')
        elif method == 'VideoLibrary.OnCleanStarted' and settings.enableservice:
            self._clean_snapshot = self._snapshot_library_item_keys()
            runtrace.event('service', 'Kodi clean library started; clean snapshot saved', count=len(self._clean_snapshot or []))
        elif method == 'VideoLibrary.OnCleanFinished' and settings.enableservice:
            self._cleanup_after_kodi_clean()
        elif method == 'VideoLibrary.OnRemove' and settings.enableservice:
            # Safety net for libraries/skins that emit OnRemove without the
            # paired CleanStarted/CleanFinished notifications. Snapshot cleanup
            # remains the main LRS-style clean flow.
            try:
                payload = json.loads(data)
                item = payload.get('item', {})
                mediatype, dbid = item.get('type'), item.get('id')
                if mediatype in (mediatypes.MOVIESET, mediatypes.MOVIE, mediatypes.TVSHOW, mediatypes.SEASON, mediatypes.EPISODE) and dbid not in (None, -1):
                    key = '{0}:{1}'.format(mediatype, int(dbid))
                    result = artworkdb.delete_item_keys([key])
                    runtrace.event('service', 'Kodi OnRemove cleaned exact item cache row', item_key=key, result=result)
            except Exception as ex:
                runtrace.error('Kodi OnRemove cleanup failed', ex, data=str(data)[:300])
        elif method == 'VideoLibrary.OnUpdate' and settings.enableservice:
            # Kodi sends OnUpdate for both real additions and ordinary metadata /
            # watched / resume changes. Only the explicit added=true payload is
            # buffered, and it is consumed only after OnScanFinished. This matches
            # the LRS safety pattern while still recovering when the service starts
            # after Kodi has already emitted OnScanStarted.
            try:
                payload = json.loads(data)
                self._buffer_onupdate_added(payload)
            except Exception as ex:
                runtrace.error('OnUpdate auto-fill fallback parse failed', ex, data=str(data)[:300])

    def onScanStarted(self, library):  # pylint: disable=invalid-name
        if str(library or "").lower() in ("video", "") and settings.enableservice:
            self._handle_video_scan_started('callback')

    def onScanFinished(self, library):  # pylint: disable=invalid-name
        if str(library or "").lower() in ("video", "") and settings.enableservice:
            self._handle_video_scan_finished('callback')

    def _buffer_onupdate_added(self, payload):
        item = (payload or {}).get('item', {})
        mediatype, dbid = item.get('type'), item.get('id')
        added = bool((payload or {}).get('added'))
        if added and mediatype in self._scan_update_added and dbid not in (None, -1):
            try:
                self._scan_update_added[mediatype].add(int(dbid))
                runtrace.event('service', 'buffered VideoLibrary.OnUpdate added=true for auto-fill fallback',
                               mediatype=mediatype, dbid=int(dbid), counts={k: len(v) for k, v in self._scan_update_added.items()})
            except Exception as ex:
                runtrace.error('buffer OnUpdate added=true failed', ex, mediatype=mediatype, dbid=dbid)
            return
        runtrace.event('service', 'ignore VideoLibrary.OnUpdate for auto-fill; not an added=true library item',
                       mediatype=mediatype, dbid=dbid, added=added, payload=str(payload)[:300])

    def _handle_video_scan_started(self, source):
        now = time.time()
        if now - self._last_scan_started_at < 0.50:
            runtrace.event('service', 'duplicate scan-start callback ignored', source=source)
            return
        self._last_scan_started_at = now
        self._scan_snapshot = self._snapshot_library_ids()
        self._auto_scan_pending = None
        self._scan_update_added = {'movie': set(), 'tvshow': set(), 'episode': set()}
        self.reset_recent()
        runtrace.event('service', 'Kodi scan started; LRS-style snapshot saved', source=source, counts={k: len(v) for k, v in self._scan_snapshot.items()} if self._scan_snapshot else {})

    def _handle_video_scan_finished(self, source):
        now = time.time()
        if now - self._last_scan_finished_at < 0.50:
            runtrace.event('service', 'duplicate scan-finish callback ignored', source=source)
            return
        self._last_scan_finished_at = now
        scan_old = settings.enable_olditem_updates and get_date() > self.last_videoupdate
        before = {k: sorted(v) for k, v in self._scan_snapshot.items()} if self._scan_snapshot is not None else None
        updates = {k: sorted(v) for k, v in (self._scan_update_added or {}).items()}
        self._auto_scan_pending = {
            'before': before,
            'updates': updates,
            'next_at': time.time(),
            'attempts': 0,
            'source': source,
            'fallback_mode': 'snapshot' if before is not None else ('onupdate-added' if any(updates.values()) else 'cache'),
        }
        self._scan_snapshot = None
        self._scan_update_added = {'movie': set(), 'tvshow': set(), 'episode': set()}
        if scan_old:
            log('Automatic older-item update skipped; processeditems workflow removed', xbmc.LOGINFO)
        runtrace.event('service', 'auto fill pending immediately after video library scan',
                       source=source,
                       fallback_mode=self._auto_scan_pending.get('fallback_mode'),
                       counts={k: len(v) for k, v in (before or {}).items()},
                       onupdate_counts={k: len(v) for k, v in updates.items()})
        log('Auto fill artwork queued immediately after VideoLibrary.OnScanFinished', xbmc.LOGINFO)

    def _auto_added_from_pending(self, pending):
        raw_before = pending.get('before')
        has_snapshot = raw_before is not None
        before = {k: set(v or []) for k, v in (raw_before or {}).items()}
        buffered_updates = {k: set(v or []) for k, v in (pending.get('updates') or {}).items()}
        after = self._snapshot_library_ids()
        # If Kodi JSON-RPC is not ready yet, quickjson may return an empty snapshot.
        # Treat that like LRS does: keep the pending job and retry briefly instead
        # of silently clearing the queue.
        if (has_snapshot and any(before.values()) or any(buffered_updates.values())) and not any(after.values()):
            raise RuntimeError('Kodi library snapshot returned empty after scan; DB may still be busy')

        added = {'movie': [], 'tvshow': [], 'episode': []}
        # Primary path: exact snapshot diff, plus explicit added=true updates as
        # a safety merge for Kodi builds that emit useful OnUpdate events.
        if has_snapshot:
            for mediatype in ('movie', 'tvshow', 'episode'):
                values = (after.get(mediatype, set()) - before.get(mediatype, set()))
                if buffered_updates.get(mediatype):
                    values |= (buffered_updates.get(mediatype) & after.get(mediatype, set()))
                added[mediatype] = sorted(values)
            total = sum(len(v) for v in added.values())
            runtrace.event('service', 'auto fill detection used snapshot diff', added=added, total=total)
            return added, total

        # Missed OnScanStarted path: only use Kodi's explicit added=true events,
        # filtered against the current library snapshot so stale/nonexistent IDs do
        # not get processed. This is the important LRS-style fallback for startup
        # races where the service begins after Kodi scan has already started.
        if any(buffered_updates.values()):
            for mediatype in ('movie', 'tvshow', 'episode'):
                added[mediatype] = sorted(buffered_updates.get(mediatype, set()) & after.get(mediatype, set()))
            total = sum(len(v) for v in added.values())
            runtrace.event('service', 'auto fill detection used OnUpdate added=true fallback', added=added, total=total)
            return added, total

        # Last-resort LRS-style uncached fallback. Artwork Curator has a larger
        # and more persistent cache than LRS, but on a new/empty AC cache this can
        # otherwise look like the whole library is new. Cap it hard and skip when
        # it exceeds the safety limit to prevent the previous 5231-item false run.
        cached = self._cached_artwork_item_keys()
        candidates = {'movie': [], 'tvshow': [], 'episode': []}
        total = 0
        for mediatype in ('movie', 'tvshow', 'episode'):
            values = []
            for dbid in sorted(after.get(mediatype, set())):
                key = '{0}:{1}'.format(mediatype, int(dbid))
                if key not in cached:
                    values.append(int(dbid))
            candidates[mediatype] = values
            total += len(values)
        if total > AUTO_SCAN_CACHE_FALLBACK_MAX_ITEMS:
            runtrace.event('service', 'auto fill cache fallback skipped: too many uncached items',
                           total=total, limit=AUTO_SCAN_CACHE_FALLBACK_MAX_ITEMS)
            return {'movie': [], 'tvshow': [], 'episode': []}, 0
        runtrace.event('service', 'auto fill detection used cache fallback', added=candidates, total=total)
        return candidates, total

    def _consume_auto_scan_job_lrs_style(self):
        pending = self._auto_scan_pending
        if not pending:
            return False
        if time.time() < float(pending.get('next_at') or 0):
            return False
        pending['attempts'] = int(pending.get('attempts') or 0) + 1
        try:
            added, total = self._auto_added_from_pending(pending)
        except Exception as ex:
            if pending['attempts'] < AUTO_SCAN_MAX_ATTEMPTS:
                pending['next_at'] = time.time() + AUTO_SCAN_RETRY_SECONDS
                self._auto_scan_pending = pending
                runtrace.event('service', 'auto fill waiting for Kodi library DB', attempts=pending['attempts'], error=str(ex))
                return False
            self._auto_scan_pending = None
            runtrace.error('auto fill new-item detection failed', ex, pending=pending)
            return False

        self._auto_scan_pending = None
        if not total:
            runtrace.event('service', 'auto fill skipped: no newly added video items found', attempts=pending.get('attempts'), added=added)
            return False

        self.recentvideos = {'movie': list(added.get('movie') or []), 'tvshow': list(added.get('tvshow') or []), 'episode': list(added.get('episode') or [])}
        log('Auto fill artwork processing {0} new item(s) after VideoLibrary.OnScanFinished'.format(total), xbmc.LOGINFO)
        runtrace.event('service', 'LRS-style auto fill job starting', recent=self.recentvideos, total=total, attempts=pending.get('attempts'))
        self.status = STATUS_PROCESSING
        with runtrace.run_context('service.auto_scan_lrs_style', recent=self.recentvideos, total=total):
            try:
                self.notify_finished(self.process_recentvideos(refresh_all=False, auto=True, force_progress=True), auto=True)
            except Exception as ex:  # pylint: disable=broad-except
                runtrace.error('Recovered LRS-style auto fill processing error', ex, recent=self.recentvideos)
                log('Recovered LRS-style auto fill processing error', xbmc.LOGERROR)
                log(traceback.format_exc(), xbmc.LOGERROR)
                try:
                    self.processor.close_progress()
                    self.processor.set_idle_inhibition(False)
                    self.processor.notify_warning('Auto fill stopped. Check kodi.log.', 'Error', True)
                except Exception as inner:
                    runtrace.error('LRS-style auto fill cleanup failed', inner)
            finally:
                self.status = STATUS_IDLE
        return True

    def onSettingsChanged(self):
        settings.update_settings()
        mediatypes.update_settings()
        if self.processaftersettings:
            self.processaftersettings = False
            self.signal = 'newvideos'

    def watchitem(self, payload):
        item = payload.get('item', {})
        return item.get('id') not in (None, -1) and item.get('type') in self.recentvideos and 'playcount' not in payload

    def _snapshot_library_item_keys(self):
        keys = set()
        try:
            if not mediatypes.disabled(mediatypes.MOVIESET):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIESET)):
                    dbid = row.get('setid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.MOVIESET, int(dbid)))
            if not mediatypes.disabled(mediatypes.MOVIE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)):
                    dbid = row.get('movieid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.MOVIE, int(dbid)))
            if not mediatypes.disabled(mediatypes.TVSHOW):
                for row in quickjson.get_tvshows():
                    dbid = row.get('tvshowid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.TVSHOW, int(dbid)))
            if not mediatypes.disabled(mediatypes.SEASON):
                for row in quickjson.get_seasons():
                    dbid = row.get('seasonid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.SEASON, int(dbid)))
            if not mediatypes.disabled(mediatypes.EPISODE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)):
                    dbid = row.get('episodeid')
                    if dbid not in (None, -1):
                        keys.add('{0}:{1}'.format(mediatypes.EPISODE, int(dbid)))
        except Exception as ex:
            runtrace.error('snapshot library item keys failed', ex)
        return keys

    def _cleanup_after_kodi_clean(self):
        before = self._clean_snapshot
        self._clean_snapshot = None
        if before is None:
            # CleanFinished without CleanStarted: still safe, but we cannot know
            # removals without comparing to the DB. Keep it silent and logged.
            runtrace.event('service', 'Kodi clean finished without prior snapshot; no AC DB cleanup performed')
            return
        after = self._snapshot_library_item_keys()
        removed = sorted(before - after)
        if not removed:
            runtrace.event('service', 'Kodi clean finished; no removed library item keys')
            return
        result = artworkdb.delete_item_keys(removed)
        message = 'CLEAN LIBRARY ARTWORK FINISHED - {0} ITEMS - {1} ARTWORK ROWS REMOVED'.format(result.get('items', 0), result.get('artwork', 0))
        runtrace.event('service', 'Kodi clean library AC DB cleanup finished', removed_keys=len(removed), result=result)
        try:
            xbmcgui.Dialog().notification('Library Artwork Curator', message, xbmcgui.NOTIFICATION_INFO, 7000)
        except Exception:
            pass

    def _snapshot_library_ids(self):
        snapshot = {'movie': set(), 'tvshow': set(), 'episode': set()}
        try:
            if not mediatypes.disabled(mediatypes.MOVIE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)):
                    dbid = row.get('movieid')
                    if dbid not in (None, -1):
                        snapshot['movie'].add(int(dbid))
            if not mediatypes.disabled(mediatypes.TVSHOW):
                for row in quickjson.get_tvshows():
                    dbid = row.get('tvshowid')
                    if dbid not in (None, -1):
                        snapshot['tvshow'].add(int(dbid))
            if not mediatypes.disabled(mediatypes.EPISODE):
                for row in chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)):
                    dbid = row.get('episodeid')
                    if dbid not in (None, -1):
                        snapshot['episode'].add(int(dbid))
        except Exception as ex:
            runtrace.error('snapshot library IDs failed', ex)
        return snapshot

    def _cached_artwork_item_keys(self):
        try:
            conn = artworkdb.connect()
            try:
                return set(row[0] for row in conn.execute('SELECT item_key FROM library_items'))
            finally:
                conn.close()
        except Exception as ex:
            runtrace.error('load cached artwork item keys failed', ex)
            return set()

    def _merge_scan_diff_into_recent(self):
        if self._scan_snapshot is None:
            # If the service starts while Kodi is already scanning, it can receive
            # OnScanFinished without the matching OnScanStarted snapshot. Treating
            # that as an empty snapshot falsely queues the entire library as new.
            runtrace.event('service', 'scan finished without start snapshot; auto diff skipped')
            return
        before = self._scan_snapshot
        after = self._snapshot_library_ids()
        self._scan_snapshot = None
        added = {}
        for mediatype in ('movie', 'tvshow', 'episode'):
            added[mediatype] = sorted(after.get(mediatype, set()) - before.get(mediatype, set()))
            for dbid in added[mediatype]:
                if dbid not in self.recentvideos[mediatype]:
                    self.recentvideos[mediatype].append(dbid)
        runtrace.event('service', 'scan snapshot diff merged into memory queue', added=added, recent=self.recentvideos)

    def _needs_lrs_lock_wait(self, signal):
        return signal in ('recentvideos', 'recentvideos_really', 'newvideos', 'newvideos_manual')

    def _wait_for_quiet_auto_start(self, signal):
        # Kodi does not expose a global notification queue API. This is a pragmatic
        # quiet-window delay after scan/LRS activity so Auto Fill progress does not
        # collide with LRS/Kodi toasts.
        #
        # Important: do not use Monitor.waitForAbort(0) as a polling check here.
        # In Kodi, timeout=0 can behave as an indefinite wait on some builds. That
        # was the remaining auto-scan bug: diagnostics stopped at
        # "auto fill quiet delay before starting" and never reached RUN START.
        delay = AUTO_QUIET_DELAY_SECONDS
        runtrace.event('service', 'auto fill quiet delay before starting', signal=signal, delay_seconds=delay)
        deadline = time.time() + delay
        while time.time() < deadline:
            if self.abort:
                runtrace.event('service', 'auto fill quiet delay cancelled by local abort', signal=signal)
                return False
            remaining = deadline - time.time()
            timeout = 0.1 if remaining > 0.1 else max(0.001, remaining)
            if self.really_waitforabort(timeout):
                runtrace.event('service', 'auto fill quiet delay cancelled by Kodi abort', signal=signal)
                return False
        if self.abort:
            runtrace.event('service', 'auto fill quiet delay cancelled by local abort', signal=signal)
            return False
        runtrace.event('service', 'auto fill quiet delay finished; starting processing', signal=signal)
        return True

    def _lrs_lock_state(self):
        window = xbmcgui.Window(10000)
        names = (
            'LibraryRatingsScraper.Status',
            'LibraryRatingsScraper.Busy',
            'LibraryRatingsScraper.Lock',
            'LRS.Status',
            'LRS.Busy',
            'LRS.Lock',
            'script.library.ratings.scraper.Status',
            'script.library.ratings.scraper.Busy',
            'script.library.ratings.scraper.Lock',
        )
        for name in names:
            value = (window.getProperty(name) or '').strip()
            if value and value.lower() not in ('idle', 'finished', 'done', 'false', '0', 'none'):
                return name, value
        return '', ''

    def _wait_for_shared_lrs_lock(self, signal, timeout=180):
        name, value = self._lrs_lock_state()
        if not name:
            return True
        runtrace.event('service', 'waiting for LRS shared lock', signal=signal, property=name, value=value, timeout=timeout)
        try:
            xbmcgui.Dialog().notification('Library Artwork Curator', 'WAITING FOR LRS', xbmcgui.NOTIFICATION_INFO, 5000)
        except Exception:
            pass
        waited = 0
        while waited < timeout and not self.really_waitforabort(1):
            name, value = self._lrs_lock_state()
            if not name:
                runtrace.event('service', 'LRS shared lock released', waited=waited)
                return True
            waited += 1
        runtrace.event('service', 'LRS shared lock still active; auto work remains queued', signal=signal, property=name, value=value, waited=waited)
        return False

    def _sort_mediaitems(self, items):
        order = {mediatypes.MOVIESET: 0, mediatypes.MOVIE: 1, mediatypes.TVSHOW: 2, mediatypes.SEASON: 3, mediatypes.EPISODE: 4}

        def key(item):
            label = (getattr(item, 'label', '') or '').lower()
            show = (getattr(item, 'showtitle', '') or '').lower()
            season = int(getattr(item, 'season', 0) or 0)
            episode = int(getattr(item, 'episode', 0) or 0)
            if item.mediatype == mediatypes.EPISODE:
                return (order.get(item.mediatype, 99), show or label, season, episode, label)
            if item.mediatype == mediatypes.SEASON:
                return (order.get(item.mediatype, 99), show or label, season, label)
            return (order.get(item.mediatype, 99), label)
        return sorted(items, key=key)

    def _dedupe_mediaitems(self, items):
        result, seen = [], set()
        for item in items:
            key = '{0}:{1}'.format(item.mediatype, item.dbid)
            if key in seen:
                continue
            seen.add(key)
            result.append(item)
        return result

    def process_allvideos(self, shouldinclude_fn=None, foreground=False, force_progress=False, refresh_all=False):
        timer = __import__('time').time()
        shouldinclude_fn = shouldinclude_fn or (lambda dbid, mediatype, label: True)
        items = []
        counts = {}

        def add_items(mediatype, rows, idkey):
            before = len(items)
            for row in rows:
                if shouldinclude_fn(row[idkey], mediatype, row.get('label', '')):
                    items.append(info.MediaItem(row))
            counts[mediatype] = len(items) - before

        if not mediatypes.disabled(mediatypes.MOVIESET):
            add_items(mediatypes.MOVIESET, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIESET)), 'setid')
        if not mediatypes.disabled(mediatypes.MOVIE):
            add_items(mediatypes.MOVIE, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.MOVIE)), 'movieid')
        if not mediatypes.disabled(mediatypes.TVSHOW):
            add_items(mediatypes.TVSHOW, quickjson.get_tvshows(), 'tvshowid')
        if not mediatypes.disabled(mediatypes.SEASON):
            add_items(mediatypes.SEASON, quickjson.get_seasons(), 'seasonid')
        if not mediatypes.disabled(mediatypes.EPISODE):
            add_items(mediatypes.EPISODE, chain.from_iterable(quickjson.gen_chunked_item_list(mediatypes.EPISODE)), 'episodeid')
        items = self._sort_mediaitems(self._dedupe_mediaitems(items))
        runtrace.event('service', 'process_allvideos collected items', total=len(items), counts=counts, order='set,movie,tvshow,season,episode', elapsed_ms=int((__import__('time').time() - timer) * 1000))
        self.reset_recent()
        return self.processor.process_medialist(items, foreground=foreground, force_progress=force_progress, refresh_all=refresh_all)

    def process_recentvideos(self, force_progress=False, notify_empty=False, refresh_all=False, auto=False):
        runtrace.event('service', 'process_recentvideos start', recent=self.recentvideos)
        items, seen_sets, seen_shows, seen_seasons = [], set(), set(), set()
        merged = {'movie': [], 'tvshow': [], 'episode': []}
        for mediatype in merged:
            merged[mediatype].extend(self.recentvideos.get(mediatype, []))

        for mediatype in ('movie', 'tvshow', 'episode'):
            for dbid in merged.get(mediatype, []):
                row = quickjson.get_item_details(dbid, mediatype)
                if not row:
                    continue
                if mediatype == 'movie' and row.get('setid') and row['setid'] not in seen_sets and not mediatypes.disabled(mediatypes.MOVIESET):
                    seen_sets.add(row['setid'])
                    setrow = quickjson.get_item_details(row['setid'], mediatypes.MOVIESET)
                    if setrow:
                        items.append(info.MediaItem(setrow))
                if mediatype == 'episode' and row.get('tvshowid') not in seen_shows and not mediatypes.disabled(mediatypes.TVSHOW):
                    seen_shows.add(row.get('tvshowid'))
                    showrow = quickjson.get_item_details(row['tvshowid'], mediatypes.TVSHOW)
                    if showrow:
                        items.append(info.MediaItem(showrow))
                if mediatype == 'episode' and not mediatypes.disabled(mediatypes.SEASON):
                    season_key = (row.get('tvshowid'), row.get('season'))
                    if season_key not in seen_seasons:
                        seen_seasons.add(season_key)
                        for seasonrow in quickjson.get_seasons(row.get('tvshowid')):
                            if int(seasonrow.get('season') or 0) == int(row.get('season') or 0):
                                items.append(info.MediaItem(seasonrow))
                                break
                items.append(info.MediaItem(row))

        self.reset_recent()
        items = self._sort_mediaitems(self._dedupe_mediaitems(items))
        runtrace.event('service', 'process_recentvideos collected items', total=len(items), queue_mode='memory', order='set,movie,tvshow,season,episode')
        if items:
            if auto:
                try:
                    xbmcgui.Dialog().notification('Library Artwork Curator', 'AUTO FILL ARTWORK STARTED - {0} ITEM{1}'.format(len(items), '' if len(items) == 1 else 'S'), xbmcgui.NOTIFICATION_INFO, 4000)
                except Exception:
                    pass
            return self.processor.process_medialist(items, alwaysnotify=True, force_progress=force_progress, refresh_all=refresh_all, suppress_final=auto)
        if notify_empty:
            runtrace.event('service', 'manual queue empty; no notification shown')
        return True

    def notify_finished(self, success, auto=False):
        summary = getattr(self.processor, 'last_summary', {}) or {}
        if success:
            pykodi.execute_builtin('NotifyAll(script.artwork.curator, OnVideoProcessingFinished)')
            if auto and int(summary.get('total') or 0) > 0:
                message = 'AUTO FILL ARTWORK FINISHED - {0} ITEMS - {1} ARTWORK - {2} ERRORS'.format(
                    int(summary.get('total') or 0),
                    int(summary.get('updated_artwork') or 0),
                    int(summary.get('errors') or 0),
                )
                xbmcgui.Dialog().notification('Library Artwork Curator', message, xbmcgui.NOTIFICATION_INFO, 7000)
        else:
            self.processor.close_progress()
            if auto and int(summary.get('total') or 0) > 0:
                xbmcgui.Dialog().notification('Library Artwork Curator', 'AUTO FILL ARTWORK ABORTED - {0} ITEMS'.format(int(summary.get('total') or 0)), xbmcgui.NOTIFICATION_WARNING, 7000)


def get_date():
    return pykodi.get_infolabel('System.Date(yyyy-mm-dd)')

if __name__ == '__main__':
    log('Video-only remote Library Artwork Curator service started v{0}'.format(addon.getAddonInfo('version')), xbmc.LOGINFO)
    ArtworkService().run()
    log('Video-only remote Library Artwork Curator service stopped', xbmc.LOGINFO)

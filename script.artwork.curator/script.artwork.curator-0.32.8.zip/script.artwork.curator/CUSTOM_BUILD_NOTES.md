# Library Artwork Curator 0.32.7 - DB-first UI/provider hotfix

- Renamed visible add-on to **Library Artwork Curator**.
- Removed manual percent from progress text to prevent `0% - 0%` double display.
- Internal `SKIP` is no longer shown as a notification phase.
- DB-first skip/apply now happens before provider-ID enrichment, so final DB rows should not trigger TMDb collection search.
- Stop/cancel now records the run as aborted.
- Fresh DB schema removes redundant `run_items.phase`; no DB fixing/migration is bundled.

# Library Artwork Curator 0.32.6 - Icon Hotfix

Changes:
- Replaced addon icon with the user-provided Library Library Artwork Curator icon.
- Resized icon.png to 256x256 for Kodi addon display.
- No DB schema, DB-first, provider, or diagnostics logic changes from 0.32.5.

# Library Artwork Curator 0.32.5 DB-first

- Final DB-first workflow: artwork-cache.db is the control source; Kodi DB is the display target.
- Final tables: metadata, library_items, artwork, runs, run_items.
- artwork replaces old artwork_slots + artwork_status.
- No bundled DB. Install the supplied DB manually.
- No DB migration/fixing logic is bundled.


import time
import traceback
import xbmc
import xbmcgui
from lib.libs import mediatypes, quickjson, pykodi
from lib import runtrace, artworkdb
from lib.familyui import notify

def _iter_icon_sources():
    return (
        ('Movie sets', mediatypes.MOVIESET, 'setid', lambda: quickjson.gen_chunked_item_list(mediatypes.MOVIESET)),
        ('Movies', mediatypes.MOVIE, 'movieid', lambda: quickjson.gen_chunked_item_list(mediatypes.MOVIE)),
        ('TV shows', mediatypes.TVSHOW, 'tvshowid', lambda: (quickjson.get_tvshows(),)),
        ('Seasons', mediatypes.SEASON, 'seasonid', lambda: (quickjson.get_seasons(),)),
        ('Episodes', mediatypes.EPISODE, 'episodeid', lambda: quickjson.gen_chunked_item_list(mediatypes.EPISODE)),
    )

def _display_title(row, mediatype):
    label = (row.get('label') or mediatype or 'UNKNOWN ITEM').upper()
    if mediatype == mediatypes.EPISODE:
        show = (row.get('showtitle') or '').upper()
        try:
            return '%s - S%02dE%02d - %s' % (label, int(row.get('season') or 0), int(row.get('episode') or 0), show)
        except Exception:
            return '%s - %s' % (label, show) if show else label
    if mediatype == mediatypes.SEASON and row.get('showtitle'):
        return '%s - %s' % (label, row.get('showtitle').upper())
    return label


def _default_icon(url):
    lower = (url or '').lower()
    return 'defaultvideo.png' in lower or 'defaultplaylist.png' in lower or 'defaultfolder.png' in lower


def _fit(line, maxlen=58):
    text = ' '.join(str(line or '').split()).upper().rstrip()
    if len(text) <= maxlen:
        return text
    raw = text[:maxlen - 1].rstrip()
    return (raw.rsplit(' ', 1)[0] if ' ' in raw else raw) + '…'


def _progress_update(progress, percent, heading, message):
    try: progress.update(max(0, min(100, int(percent))), heading, message)
    except TypeError: progress.update(max(0, min(100, int(percent))), message)

def clean_all_icons():
    if not xbmcgui.Dialog().yesno('Library Artwork Curator', 'Remove every video-library artwork slot named "icon"?\n\nThis is a maintenance cleanup only. It does not remove poster, fanart, thumb, landscape, or clearlogo.', 'Cancel', 'Clean icons'):
        return
    run_id = artworkdb.begin_run('maintenance.clean_all_icons')
    progress = xbmcgui.DialogProgress(); progress.create('Library Artwork Curator: Clean legacy icons', '')
    started = time.time(); scanned = updated = errors = 0
    with runtrace.run_context('maintenance.clean_all_icons'):
        try:
            sources = list(_iter_icon_sources())
            for group_index, (label, mediatype, idfield, list_fn) in enumerate(sources):
                if progress.iscanceled(): break
                _progress_update(progress, int(group_index * 100 / float(len(sources) or 1)), 'Library Artwork Curator', '0/0 {0} - CLEAN ICONS'.format(label.upper()))
                for chunk in list_fn():
                    for row in chunk:
                        scanned += 1
                        art = row.get('art') or {}; raw_icon = art.get('icon')
                        if not raw_icon:
                            continue
                        old_url = pykodi.unquoteimage(raw_icon)
                        if not old_url or _default_icon(old_url): continue
                        dbid = row.get(idfield); title = row.get('label', ''); display_title = _display_title(row, mediatype)
                        try:
                            _progress_update(progress, 0, 'Library Artwork Curator', _fit('{0}/{1} - {2} - CLEAN LEGACY ICONS'.format(scanned, scanned, display_title, 0)))
                            quickjson.set_item_details(dbid, mediatype, art={'icon': None})
                            updated += 1
                            artworkdb.record_maintenance(run_id, 'clean_all_icons', mediatype, dbid, title, 'icon', old_url, 'removed')
                            runtrace.event('maintenance', 'removed icon', mediatype=mediatype, dbid=dbid, title=title, url=old_url)
                        except Exception as ex:
                            errors += 1
                            artworkdb.record_maintenance(run_id, 'clean_all_icons', mediatype, dbid, title, 'icon', old_url, 'error')
                            runtrace.error('Clean icon failed', ex, mediatype=mediatype, dbid=dbid, title=title)
                    if progress.iscanceled(): break
            status = 'aborted' if progress.iscanceled() else 'finished'
        except Exception as ex:
            status = 'error'; errors += 1
            runtrace.error('Clean all icons failed', ex)
            xbmc.log('[Library Artwork Curator] Clean all icons failed\n%s' % traceback.format_exc(), xbmc.LOGERROR)
        finally:
            progress.close()
            elapsed_ms = int((time.time() - started) * 1000)
            artworkdb.finish_run(run_id, status=status, updated_items=updated, updated_artwork=updated, errors=errors, elapsed_ms=elapsed_ms, notes='scanned=%s' % scanned)
            notify('CLEAN ICONS FINISHED - {0} REMOVED - {1} ERRORS'.format(updated, errors), xbmcgui.NOTIFICATION_INFO if errors == 0 else xbmcgui.NOTIFICATION_WARNING, 8000)

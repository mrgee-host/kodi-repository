LAC 0.32.53
- Kodi webserver basic-auth credentials are removed from runtime/provider URLs.
- Text diagnostics redact API credentials, authorization headers, and TPDb email.
- Runtime logs live in runtime/logs; human reports live in runtime/reports.
- Legacy mixed files are migrated, old consecutive duplicate log rows are compacted, and empty root folders are removed.
- Diagnostics ZIPs contain unique archive names only.
- The new ZIP is validated and published before old ZIPs are deleted.
- Manifest includes addon_version and redacted settings are exported as summary/settings.xml.

Library Artwork Curator 0.32.48
================================

Problem fixed
-------------
Kodi can reuse a numeric video DBID after Clean Library or a source-path move.
Older LAC builds used type:DBID as the only DB-first key, so artwork cached for an
old episode could be applied to a different new episode.

Protection
----------
- Compare stable unique IDs before DB-first apply.
- For episodes also compare show title, season, and episode number.
- When identity differs, delete the stale library_items, artwork, and run_items rows.
- After a Kodi scan, identity-reused DBIDs are queued even if the number is unchanged.

Existing corrupted episode stills
---------------------------------
A second guard detects a newer remote thumb/landscape URL that is already owned
by an older episode from another show. The newer row is reopened once for normal
provider selection. A per-URL retry marker prevents endless loops if two shows
legitimately share the same image.

After installation run: Library Artwork Curator -> Scrape missing artwork.

Library Artwork Curator 0.32.47

Thailand movie collection sync
- Folder markers default to:
  Thailand Movies [Collection]
  Thailand Movies (Collection)
  Thailand Movies Collection
- Matching Kodi movies are assigned to Thailand Movies Collection.
- Any prior movie-set assignment is replaced because Kodi stores one active movie set per movie.
- Runs automatically after service startup and after each completed video-library scan.
- Existing libraries can be synced immediately from Maintenance tools -> Sync Thailand movie collection.
- Diagnostics include Thailand collection state and the latest sync report.
- This feature does not change artwork language selection.

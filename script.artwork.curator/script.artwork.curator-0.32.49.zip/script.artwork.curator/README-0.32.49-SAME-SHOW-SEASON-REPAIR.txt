LIBRARY ARTWORK CURATOR 0.32.49
================================

PERBAIKAN UTAMA
---------------
Scrape missing artwork sekarang menangani dua pola cache episode rusak:

1. Antarserial
   Contoh: The Legend of Korra memakai thumb The Walking Dead.

2. Serial sama tetapi musim berbeda
   Contoh: The Walking Dead S07 memakai thumb The Walking Dead S01.

Untuk pola serial yang sama, LAC tidak menghapus gambar hanya karena satu URL
kebetulan sama. Perbaikan baru aktif bila sedikitnya dua pasangan episode yang
berbeda membentuk pola musim-baru -> musim-lama dan row musim baru lebih muda.

CARA MEMPERBAIKI
----------------
1. Instal 0.32.49.
2. Restart Kodi penuh.
3. Jalankan Library Artwork Curator -> Scrape missing artwork.

Proses preflight membuka kembali row thumb/landscape yang terbukti bertabrakan,
lalu alur fill-missing mengambil artwork provider untuk episode yang benar.
Tidak perlu Refresh All.

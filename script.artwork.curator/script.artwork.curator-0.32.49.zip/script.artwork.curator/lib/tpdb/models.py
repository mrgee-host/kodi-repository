# -*- coding: utf-8 -*-
from dataclasses import dataclass, field
from typing import List


@dataclass
class SearchPage:
    url: str
    label: str = ""


@dataclass
class PosterEntry:
    asset_id: str = ""
    poster_type: str = ""
    title: str = ""
    year: str = ""
    username: str = ""
    set_id: str = ""
    set_count: int = 0
    download_url: str = ""
    thumb_url: str = ""
    collection_url: str = ""

    @property
    def display_title(self):
        if self.year:
            return "{} ({})".format(self.title, self.year)
        return self.title


@dataclass
class ApplyReport:
    success: List[str] = field(default_factory=list)
    skipped: List[str] = field(default_factory=list)
    failed: List[str] = field(default_factory=list)

    def text(self):
        lines = []
        lines.append("Success: {}".format(len(self.success)))
        lines.extend("OK   " + value for value in self.success)
        if self.skipped:
            lines.append("")
            lines.append("Skipped: {}".format(len(self.skipped)))
            lines.extend("SKIP " + value for value in self.skipped)
        if self.failed:
            lines.append("")
            lines.append("Failed: {}".format(len(self.failed)))
            lines.extend("FAIL " + value for value in self.failed)
        return "\n".join(lines)

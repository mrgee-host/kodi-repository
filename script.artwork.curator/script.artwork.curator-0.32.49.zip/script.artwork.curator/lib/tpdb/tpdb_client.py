# -*- coding: utf-8 -*-
import gzip
import html
from difflib import SequenceMatcher
from html.parser import HTMLParser
import re
import urllib.error
import urllib.parse
import urllib.request

import xbmcaddon

from . import log
from .parser import parse_poster_cards, parse_search_pages
from . import session_store
from . import settings

BASE_URL = "https://theposterdb.com"
LOGIN_URL = BASE_URL + "/login"
CHALLENGE_MARKERS = (
    "checking your browser",
    "verify you are human",
    "attention required",
    "managed challenge",
    "cf-chl",
    "captcha",
)
LOGIN_ERROR_MARKERS = (
    "these credentials do not match",
    "invalid credentials",
    "incorrect password",
    "login failed",
    "sign in failed",
)


class TPDbError(RuntimeError):
    pass


class TPDbVerificationRequired(TPDbError):
    pass


class TPDbAuthenticationError(TPDbError):
    pass


def normalize_posters_url(value):
    parsed = urllib.parse.urlparse((value or "").strip())
    host = (parsed.hostname or "").lower()
    if host not in ("theposterdb.com", "www.theposterdb.com"):
        return ""
    match = re.search(r"(?:/index\.php)?/posters/(\d+)(?:[/?#]|$)", parsed.path, re.I)
    if not match:
        return ""
    return "{}/posters/{}".format(BASE_URL, match.group(1))


class _LoginFormParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.forms = []
        self._form = None

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        data = {key: value or "" for key, value in attrs}
        if tag == "form":
            self._form = {
                "action": data.get("action", ""),
                "method": (data.get("method") or "post").lower(),
                "inputs": [],
            }
        elif tag == "input" and self._form is not None:
            self._form["inputs"].append(
                {
                    "name": data.get("name", ""),
                    "value": data.get("value", ""),
                    "type": (data.get("type") or "text").lower(),
                }
            )

    def handle_endtag(self, tag):
        if tag.lower() == "form" and self._form is not None:
            self.forms.append(self._form)
            self._form = None


def _parse_login_form(text):
    parser = _LoginFormParser()
    parser.feed(text or "")
    for form in parser.forms:
        if any(item.get("type") == "password" for item in form.get("inputs", [])):
            return form
    return None


def _looks_like_login_page(text, url=""):
    parsed = urllib.parse.urlparse(url or "")
    if parsed.path.rstrip("/").lower() == "/login":
        return True
    return _parse_login_form(text or "") is not None



def _normalize_search_label(value):
    """Normalize a TPDb search label for conservative collection matching."""
    value = html.unescape(value or "").lower()
    value = value.replace("&", " and ").replace("+", " plus ")
    # "Collection" and "franchise" describe the TPDb page type rather than
    # the underlying title, so ignore them during comparison.
    value = re.sub(r"\b(collection|franchise)\b", " ", value)
    value = re.sub(r"[^\w\s]", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def _collection_page_score(expected, actual):
    """Return a relevance score for a TPDb collection search result.

    TPDb's search endpoint deliberately returns loose matches.  That is useful
    on the website but noisy in a TV interface, where unrelated rows can be
    selected accidentally.  Prefer an exact normalized title, then titles that
    still contain all query words, and use a fuzzy fallback only for minor
    spelling/plural differences.
    """
    expected = _normalize_search_label(expected)
    actual = _normalize_search_label(actual)
    if not expected or not actual:
        return 0.0
    if expected == actual:
        return 1.0

    expected_tokens = expected.split()
    actual_tokens = actual.split()
    expected_set = set(expected_tokens)
    actual_set = set(actual_tokens)
    overlap = len(expected_set & actual_set)
    coverage = float(overlap) / float(max(1, len(expected_set)))
    precision = float(overlap) / float(max(1, len(actual_set)))
    fuzzy = SequenceMatcher(None, expected, actual).ratio()

    # Useful alternative pages such as "A Quiet Place: Day One" may contain
    # the complete collection name plus an additional subtitle.  Keep them as
    # secondary candidates only when no exact page exists.
    if expected in actual:
        return 0.90 + min(0.04, precision * 0.04)
    if actual in expected:
        return 0.86 + min(0.04, coverage * 0.04)
    if coverage >= 1.0:
        return 0.82 + min(0.06, fuzzy * 0.06)

    # Fallback for minor spelling/plural variations, but not broad search hits.
    if coverage >= 0.75 and fuzzy >= 0.72:
        return 0.70 + min(0.09, fuzzy * 0.09)
    return 0.0


def _filter_collection_pages(query, pages):
    """Hide broad TPDb search noise and rank collection pages conservatively."""
    ranked = []
    for index, page in enumerate(pages or []):
        current = _collection_page_score(query, page.label)
        if current > 0.0:
            ranked.append((current, index, page))

    if not ranked:
        return []

    # If TPDb returned the requested title exactly, do not show lower-quality
    # website search suggestions at all. This normally makes the correct page
    # open immediately without an unnecessary picker.
    exact = [entry for entry in ranked if entry[0] >= 0.999]
    if exact:
        ranked = exact
    else:
        ranked = [entry for entry in ranked if entry[0] >= 0.70]

    ranked.sort(key=lambda entry: (-entry[0], entry[1]))
    return [entry[2] for entry in ranked]


class TPDbClient:
    def __init__(self):
        addon = xbmcaddon.Addon()
        self.addon = addon
        self.manual_cookie = settings.get_text("session_cookie", addon=addon).strip()
        self.timeout = settings.get_int("timeout", 20, minimum=5, addon=addon)
        self.max_search_pages = settings.get_int("max_search_pages", 12, minimum=1, addon=addon)
        self.max_posters = settings.get_int("max_posters", 60, minimum=1, addon=addon)
        self.jar = session_store.load()
        if self.manual_cookie:
            session_store.apply_cookie_header(self.jar, self.manual_cookie)
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))
        self._html_cache = {}

    def _request(self, url, binary=False, data=None, extra_headers=None, return_url=False):
        headers = {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/131 Safari/537.36",
            "Accept": "*/*" if binary else "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8",
            "Accept-Encoding": "gzip",
            "Referer": BASE_URL + "/",
        }
        if extra_headers:
            headers.update(extra_headers)
        request = urllib.request.Request(url, data=data, headers=headers)
        log.debug("{} {}".format("POST" if data is not None else "GET", url))
        try:
            with self.opener.open(request, timeout=self.timeout) as response:
                payload = response.read()
                if response.headers.get("Content-Encoding", "").lower() == "gzip":
                    payload = gzip.decompress(payload)
                content_type = response.headers.get("Content-Type", "")
                final_url = response.geturl()
        except urllib.error.HTTPError as exc:
            if exc.code in (401, 403, 429, 503):
                raise TPDbVerificationRequired("TPDb requires browser verification or is rate-limiting requests (HTTP {}).".format(exc.code))
            raise TPDbError("TPDb HTTP error {} for {}".format(exc.code, url))
        except urllib.error.URLError as exc:
            raise TPDbError("Unable to connect to TPDb: {}".format(exc.reason))
        if binary:
            return (payload, content_type, final_url) if return_url else (payload, content_type)
        text = payload.decode("utf-8", errors="replace")
        lower = text.lower()
        if any(marker in lower for marker in CHALLENGE_MARKERS):
            raise TPDbVerificationRequired(
                "TPDb requires browser verification. Native Kodi login cannot bypass CAPTCHA or browser challenges. "
                "Use a manual browser Cookie header in Advanced settings if needed."
            )
        return (text, final_url) if return_url else text

    def login(self, identity, password, remember=True):
        identity = (identity or "").strip()
        if not identity or not password:
            raise TPDbAuthenticationError("TPDb email/username and password are required.")

        # Start with a fresh native session, but preserve an optional manual
        # browser Cookie header configured by the user.
        session_store.clear()
        self.jar = session_store.new_jar()
        if self.manual_cookie:
            session_store.apply_cookie_header(self.jar, self.manual_cookie)
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

        page, final_url = self._request(LOGIN_URL, return_url=True)
        form = _parse_login_form(page)
        if not form:
            if not _looks_like_login_page(page, final_url):
                session_store.save(self.jar)
                return True
            raise TPDbAuthenticationError("The TPDb login form could not be found.")

        payload = {}
        identity_name = ""
        password_name = "password"
        remember_name = ""
        for item in form.get("inputs", []):
            name = item.get("name", "")
            field_type = item.get("type", "text")
            if not name:
                continue
            if field_type == "hidden":
                payload[name] = item.get("value", "")
            elif field_type == "password":
                password_name = name
            elif field_type in ("email", "text") and not identity_name:
                identity_name = name
            elif field_type == "checkbox" and ("remember" in name.lower() or not remember_name):
                remember_name = name

        payload[identity_name or "email"] = identity
        payload[password_name] = password
        if remember_name and remember:
            payload[remember_name] = "on"

        action = urllib.parse.urljoin(LOGIN_URL, html.unescape(form.get("action") or LOGIN_URL))
        encoded = urllib.parse.urlencode(payload).encode("utf-8")
        response, final_url = self._request(
            action,
            data=encoded,
            extra_headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "Referer": LOGIN_URL,
            },
            return_url=True,
        )
        lower = response.lower()
        if _looks_like_login_page(response, final_url) or any(marker in lower for marker in LOGIN_ERROR_MARKERS):
            raise TPDbAuthenticationError("TPDb login failed. Check the email/username and password.")
        if session_store.cookie_count(self.jar) == 0:
            raise TPDbAuthenticationError("Login completed without a session cookie. TPDb may require browser verification.")
        session_store.save(self.jar)
        return True

    def test_saved_session(self):
        if session_store.cookie_count(self.jar) == 0:
            return False
        page, final_url = self._request(LOGIN_URL, return_url=True)
        if not _looks_like_login_page(page, final_url):
            session_store.save(self.jar)
            return True
        # Some deployments still render /login while a session cookie exists.
        # Check the homepage for common authenticated navigation markers.
        home = self._request(BASE_URL + "/")
        lower = home.lower()
        valid = any(marker in lower for marker in ("/logout", "sign out", "log out", "my profile", "account settings"))
        if valid:
            session_store.save(self.jar)
        return valid

    def clear_saved_session(self):
        session_store.clear()
        self.jar = session_store.new_jar()
        if self.manual_cookie:
            session_store.apply_cookie_header(self.jar, self.manual_cookie)
        self.opener = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar))

    def get_html(self, url, refresh=False):
        if not refresh and url in self._html_cache:
            return self._html_cache[url]
        value = self._request(url, binary=False)
        self._html_cache[url] = value
        return value

    def search_pages(self, query, section):
        variants = self._variants(query, section)
        result = []
        seen = set()
        for term in variants:
            url = "{}/index.php/search?term={}&section={}".format(
                BASE_URL,
                urllib.parse.quote(term),
                urllib.parse.quote(section),
            )
            pages = parse_search_pages(self.get_html(url), BASE_URL)
            log.info("section search term={!r} section={} pages={}".format(term, section, len(pages)))
            for page in pages:
                if page.url in seen:
                    continue
                seen.add(page.url)
                result.append(page)
        if section == "collections":
            filtered = _filter_collection_pages(query, result)
            log.info("collection search filtered raw={} relevant={}".format(len(result), len(filtered)))
            result = filtered
        return result[: self.max_search_pages]

    def get_page_posters(self, page_url):
        posters = parse_poster_cards(self.get_html(page_url), BASE_URL)
        log.info("poster page {} cards={}".format(page_url, len(posters)))
        return posters[: self.max_posters]

    def get_set_posters(self, set_id):
        url = "{}/set/{}".format(BASE_URL, set_id)
        posters = [
            poster
            for poster in parse_poster_cards(self.get_html(url), BASE_URL)
            if str(poster.set_id) == str(set_id)
        ]
        log.info("set {} matching-cards={}".format(set_id, len(posters)))
        return posters[: self.max_posters]

    def download(self, url):
        return self._request(url, binary=True)

    def _variants(self, query, section):
        clean = re.sub(r"\s+", " ", query or "").strip()
        clean = re.sub(r"(?i)\s*[\[\(]?\s*(collection|franchise)\s*[\]\)]?\s*$", "", clean).strip()
        values = [clean]
        if section == "collections":
            if "/" in clean:
                values.append(re.sub(r"\s*/\s*", " ", clean))
            if " and " in clean.lower():
                values.append(re.sub(r"(?i)\s+and\s+", " & ", clean))
            elif "&" in clean:
                values.append(clean.replace("&", " and "))
        result = []
        seen = set()
        for value in values:
            value = re.sub(r"\s+", " ", value).strip()
            if value and value.lower() not in seen:
                seen.add(value.lower())
                result.append(value)
        return result

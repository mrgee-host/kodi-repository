# -*- coding: utf-8 -*-
import re


def normalize(value):
    value = (value or "").lower()
    value = re.sub(r"\b(collection|franchise)\b", " ", value)
    value = value.replace("&", " and ").replace("+", " plus ")
    value = re.sub(r"[^\w\s]", " ", value)
    return re.sub(r"\s+", " ", value).strip()


def score(expected, actual):
    expected = normalize(expected)
    actual = normalize(actual)
    if not expected or not actual:
        return 0.0
    if expected == actual:
        return 1.0
    if expected in actual or actual in expected:
        return 0.9
    left = set(expected.split())
    right = set(actual.split())
    return float(len(left & right)) / float(max(len(left), len(right)))


def match_movie(movie, posters, used=None):
    used = used or set()
    movie_year = str(movie.get("year") or "")
    best = None
    best_score = -1.0
    for poster in posters:
        if poster.asset_id in used:
            continue
        if not poster.title or not poster.year:
            continue
        if movie_year and str(poster.year) != movie_year:
            continue
        current = score(movie.get("title", ""), poster.title)
        if current > best_score:
            best = poster
            best_score = current
    if best is not None and best_score >= 0.82:
        return best
    return None

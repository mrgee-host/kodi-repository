# -*- coding: utf-8 -*-
import os

import xbmcaddon
import xbmcgui


def _list_item(label, label2="", thumb=""):
    item = xbmcgui.ListItem(label=label, label2=label2)
    if thumb:
        item.setArt({"thumb": thumb, "poster": thumb, "icon": thumb})
    return item


def choose_search_page(pages, heading, compact=False):
    """Choose a TPDb result page.

    Collection searches intentionally use a compact names-only list because
    search result pages do not expose reliable artwork thumbnails. The URL is
    still retained internally and can be opened after the user selects a row.
    """
    if not pages:
        return None
    if len(pages) == 1:
        return pages[0]
    items = []
    for page in pages:
        label = page.label or page.url
        label2 = "" if compact else page.url
        items.append(_list_item(label, label2))
    selected = xbmcgui.Dialog().select(heading, items, useDetails=not compact)
    return None if selected < 0 else pages[selected]


def choose_poster(posters, heading, set_mode=False):
    if not posters:
        return None
    items = []
    for poster in posters:
        label = poster.username or poster.display_title or "TPDb poster"
        if set_mode:
            count = poster.set_count or "?"
            label = "Set by {}".format(poster.username or "Unknown")
            label2 = "{} posters".format(count)
        else:
            label2 = poster.display_title
        items.append(_list_item(label, label2, poster.thumb_url))
    selected = xbmcgui.Dialog().select(heading, items, useDetails=True)
    return None if selected < 0 else posters[selected]


def _addon_asset(filename):
    root = xbmcaddon.Addon().getAddonInfo("path")
    return os.path.join(root, "resources", "media", filename)


class _NativeFileBrowserSetPreview(xbmcgui.WindowXMLDialog):
    """Read-only TPDb set preview rendered by the active skin's FileBrowser.xml.

    FileBrowser.xml is the same native Kodi window used by the normal Choose art
    browser.  Control 451 is its thumbnail panel.  The panel remains navigable
    for visual inspection, but clicking a poster intentionally does nothing.
    The visible native APPLY button (9001) forwards its click to control 413.
    """

    ACTION_SELECT_ITEM = 7
    ACTION_PARENT_DIR = 9
    ACTION_PREVIOUS_MENU = 10
    ACTION_NAV_BACK = 92
    ACTION_BACKSPACE = 110

    def configure(self, poster, set_posters):
        self._cover = poster
        self._posters = list(set_posters or [])
        self.result = "back"

    def _control(self, control_id):
        try:
            return self.getControl(control_id)
        except Exception:
            return None

    def _set_visible(self, control_id, visible):
        control = self._control(control_id)
        if control is not None:
            try:
                control.setVisible(bool(visible))
            except Exception:
                pass

    def _set_enabled(self, control_id, enabled):
        control = self._control(control_id)
        if control is not None:
            try:
                control.setEnabled(bool(enabled))
            except Exception:
                pass

    def _set_label(self, control_id, label):
        control = self._control(control_id)
        if control is not None:
            try:
                control.setLabel(label)
            except Exception:
                pass

    def onInit(self):
        uploader = getattr(self._cover, "username", "") or "?"
        posters = list(getattr(self, "_posters", []) or [])

        # Native FileBrowser.xml labels and actions.
        self._set_label(411, "Preview poster set")
        self._set_label(412, "Set by: {}   |   Posters: {}".format(uploader, len(posters)))

        # Arctic Fuse 3 FileBrowser.xml renders the visible APPLY button as
        # control 9001. It forwards the click to Kodi's hidden proxy control
        # 413. The skin intentionally shows 9001 only while control 450 is
        # visible, so keep the empty directory list enabled behind the artwork
        # panel (451). Panel 451 is drawn later and remains the visible/focused
        # read-only poster grid.
        self._set_visible(450, True)   # required by native APPLY visibility condition
        self._set_enabled(450, True)
        directory_list = self._control(450)
        if directory_list is not None:
            try:
                directory_list.reset()
            except Exception:
                pass
        self._set_visible(413, True)   # hidden proxy used by native APPLY button
        self._set_enabled(413, True)
        self._set_visible(414, False)  # hide native side Close button
        self._set_visible(415, False)  # hide create-folder button
        self._set_visible(416, False)  # hide mirror toggle
        self._set_label(9001, "APPLY")

        panel = self._control(451)
        if panel is not None:
            try:
                panel.reset()
            except Exception:
                pass
            items = []
            for entry in posters:
                thumb = entry.thumb_url or ""
                label = entry.display_title or "[Collection]"
                item = _list_item(label, "Preview only", thumb)
                try:
                    item.setPath(thumb)
                except Exception:
                    pass
                item.setProperty("tpdb_preview_only", "true")
                items.append(item)
            try:
                panel.addItems(items)
            except Exception:
                for item in items:
                    try:
                        panel.addItem(item)
                    except Exception:
                        break
        try:
            self.setFocusId(451)
        except Exception:
            try:
                self.setFocusId(413)
            except Exception:
                pass

    def _apply(self):
        self.result = "apply"
        self.close()

    def _back(self):
        self.result = "back"
        self.close()

    def onClick(self, control_id):
        if control_id == 413:
            self._apply()
        elif control_id == 414:
            self._back()
        # Control 451 is deliberately preview-only. Clicking a poster does not
        # select it and does not close the dialog.

    def onAction(self, action):
        try:
            action_id = action.getId()
        except Exception:
            return
        if action_id in (
            self.ACTION_PARENT_DIR,
            self.ACTION_PREVIOUS_MENU,
            self.ACTION_NAV_BACK,
            self.ACTION_BACKSPACE,
        ):
            self._back()
            return
        if action_id == self.ACTION_SELECT_ITEM:
            try:
                focus_id = self.getFocusId()
            except Exception:
                focus_id = 0
            if focus_id == 413:
                self._apply()
            # Enter on poster panel is intentionally ignored.


def _confirm_set_preview_select_fallback(poster, set_posters):
    """Safe fallback when a skin cannot load FileBrowser.xml as WindowXMLDialog."""
    posters = list(set_posters or [])
    if not posters:
        return "back"
    uploader = poster.username or "?"
    heading = "Preview poster set - {}".format(uploader)
    apply_art = "special://skin/extras/icons/circle-check.png"
    while True:
        items = []
        apply_item = _list_item(
            "APPLY",
            "Apply all posters in this set",
            apply_art,
        )
        items.append(apply_item)
        for entry in posters:
            items.append(_list_item(entry.display_title or "[Collection]", "Preview only", entry.thumb_url))
        selected = xbmcgui.Dialog().select(heading, items, preselect=0, useDetails=True)
        if selected < 0:
            return "back"
        if selected == 0:
            return "apply"


def confirm_set_preview(poster, set_posters):
    """Render the preview with the active skin's *actual* FileBrowser.xml.

    This intentionally does not use DialogSelect.xml. Kodi's standard Choose art
    screen is FileBrowser.xml; its native thumbnail panel is control 451.
    """
    posters = list(set_posters or [])
    if not posters:
        return "back"
    dialog = None
    try:
        addon_path = xbmcaddon.Addon().getAddonInfo("path")
        dialog = _NativeFileBrowserSetPreview("FileBrowser.xml", addon_path, "Default", "1080i")
        dialog.configure(poster, posters)
        dialog.doModal()
        return dialog.result
    except Exception:
        return _confirm_set_preview_select_fallback(poster, posters)
    finally:
        if dialog is not None:
            del dialog

def notify(title, message, icon=xbmcgui.NOTIFICATION_INFO, milliseconds=5000):
    xbmcgui.Dialog().notification(title, message, icon, milliseconds)


def ok(title, message):
    xbmcgui.Dialog().ok(title, message)


def input_text(heading, default=""):
    return xbmcgui.Dialog().input(heading, defaultt=default, type=xbmcgui.INPUT_ALPHANUM)


def input_password(heading, default=""):
    hidden = getattr(xbmcgui, "ALPHANUM_HIDE_INPUT", 0)
    return xbmcgui.Dialog().input(heading, defaultt=default, type=xbmcgui.INPUT_ALPHANUM, option=hidden)


def progress(title, message=""):
    dialog = xbmcgui.DialogProgress()
    dialog.create(title, message)
    return dialog

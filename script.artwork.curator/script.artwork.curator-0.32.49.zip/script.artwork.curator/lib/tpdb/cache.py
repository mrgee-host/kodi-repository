# -*- coding: utf-8 -*-
import hashlib
import os
import re
import shutil

import xbmcvfs

from . import log


class ArtworkCache:
    def __init__(self):
        self.root = xbmcvfs.translatePath("special://profile/addon_data/script.artwork.curator/cache/tpdb")
        os.makedirs(self.root, exist_ok=True)

    def store_asset(self, client, poster):
        if not poster.download_url:
            raise RuntimeError("Poster does not have a download URL")
        data, content_type = client.download(poster.download_url)
        extension = self._extension(content_type, poster.download_url)
        key = poster.asset_id or hashlib.sha1(poster.download_url.encode("utf-8")).hexdigest()
        path = os.path.join(self.root, "asset_{}{}".format(key, extension))
        with open(path, "wb") as handle:
            handle.write(data)
        log.info("cached asset {} -> {}".format(key, path))
        return path

    def clear(self):
        """Remove files previously downloaded by this add-on only."""
        removed = 0
        if not os.path.isdir(self.root):
            return removed
        for name in os.listdir(self.root):
            path = os.path.join(self.root, name)
            try:
                if os.path.isfile(path) or os.path.islink(path):
                    os.remove(path)
                    removed += 1
                elif os.path.isdir(path):
                    shutil.rmtree(path)
                    removed += 1
            except OSError as exc:
                log.warning("unable to remove cached artwork {}: {!r}".format(path, exc))
        return removed

    @staticmethod
    def _extension(content_type, url):
        value = (content_type or "").lower()
        if "png" in value:
            return ".png"
        if "webp" in value:
            return ".webp"
        if "jpeg" in value or "jpg" in value:
            return ".jpg"
        match = re.search(r"\.(jpe?g|png|webp)(?:[?#]|$)", url or "", re.I)
        if match:
            extension = match.group(1).lower()
            return ".jpg" if extension == "jpeg" else "." + extension
        return ".jpg"

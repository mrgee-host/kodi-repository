# -*- coding: utf-8 -*-
"""Compatibility helpers for Kodi add-on settings.

Kodi supports the classic resources/settings.xml schema as well as the newer
versioned schema.  The classic schema must be read with Addon.getSetting() /
setSetting(), because typed accessors can raise ``Invalid setting type`` for
legacy ``text`` / ``number`` settings on some Kodi builds.
"""
import xbmcaddon


def _addon(instance=None):
    return instance or xbmcaddon.Addon()


def get_text(setting_id, default="", addon=None):
    instance = _addon(addon)
    try:
        value = instance.getSetting(setting_id)
    except Exception:
        try:
            value = instance.getSettingString(setting_id)
        except Exception:
            return default
    if value is None:
        return default
    return str(value)


def set_text(setting_id, value, addon=None):
    instance = _addon(addon)
    text = "" if value is None else str(value)
    try:
        instance.setSetting(setting_id, text)
        return
    except Exception:
        instance.setSettingString(setting_id, text)


def get_bool(setting_id, default=False, addon=None):
    raw = get_text(setting_id, "", addon=addon).strip().lower()
    if raw in ("true", "1", "yes", "on"):
        return True
    if raw in ("false", "0", "no", "off"):
        return False
    return bool(default)


def get_int(setting_id, default=0, minimum=None, maximum=None, addon=None):
    raw = get_text(setting_id, str(default), addon=addon).strip()
    try:
        value = int(raw)
    except (TypeError, ValueError):
        value = int(default)
    if minimum is not None:
        value = max(int(minimum), value)
    if maximum is not None:
        value = min(int(maximum), value)
    return value

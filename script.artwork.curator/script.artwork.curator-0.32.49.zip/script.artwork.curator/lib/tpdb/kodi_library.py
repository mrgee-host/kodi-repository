# -*- coding: utf-8 -*-
import json
import sys

import xbmc

from . import log


def rpc(method, params=None):
    payload = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": method,
        "params": params or {},
    }
    response = json.loads(xbmc.executeJSONRPC(json.dumps(payload)))
    if "error" in response:
        raise RuntimeError("{}: {}".format(method, response["error"]))
    return response.get("result")


def info_label(name):
    return xbmc.getInfoLabel(name) or ""


def current_item():
    """Return the context-menu item.

    Kodi context-item add-ons expose the selected item through ``sys.listitem``.
    Some skins do not keep all ListItem.* info labels populated while the
    context dialog is open, so prefer the copied ListItem and its VideoInfoTag.
    """
    selected = getattr(sys, "listitem", None)
    if selected is not None:
        try:
            tag = selected.getVideoInfoTag()
            dbtype = (tag.getMediaType() or "").lower()
            dbid = _as_int(tag.getDbId())
            title = tag.getTitle() or selected.getLabel()
            year = _as_int(tag.getYear())
            if dbtype or dbid or title:
                return {
                    "dbtype": dbtype,
                    "dbid": dbid,
                    "title": title,
                    "year": year,
                }
        except Exception as exc:
            log.warning("Unable to read sys.listitem: {!r}".format(exc))

    return {
        "dbtype": info_label("ListItem.DBTYPE").lower(),
        "dbid": _as_int(info_label("ListItem.DBID")),
        "title": info_label("ListItem.Title") or info_label("ListItem.Label"),
        "year": _as_int(info_label("ListItem.Year")),
    }


def get_movie_sets():
    result = rpc("VideoLibrary.GetMovieSets", {"properties": ["title", "art"]}) or {}
    return result.get("sets", [])


def resolve_set_id(dbid, title):
    if dbid:
        return dbid
    wanted = (title or "").strip().lower()
    for item in get_movie_sets():
        if (item.get("title") or "").strip().lower() == wanted:
            return int(item.get("setid"))
    return 0


def get_movie_set_details(setid):
    params = {
        "setid": int(setid),
        "properties": ["title", "art", "plot"],
        "movies": {"properties": ["title", "year", "art", "file"]},
    }
    result = rpc("VideoLibrary.GetMovieSetDetails", params) or {}
    return result.get("setdetails", {})


def set_movie_poster(movieid, path):
    rpc("VideoLibrary.SetMovieDetails", {"movieid": int(movieid), "art": {"poster": path}})


def set_movieset_poster(setid, path):
    rpc("VideoLibrary.SetMovieSetDetails", {"setid": int(setid), "art": {"poster": path}})


def refresh_container():
    xbmc.executebuiltin("Container.Refresh")


def _as_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return 0

# -*- coding: utf-8 -*-
import html
import re
from html.parser import HTMLParser
from urllib.parse import urljoin, urlparse

from .models import PosterEntry, SearchPage

_BASE = "https://theposterdb.com"
_POSTERS_RE = re.compile(r"(?:/index\.php)?/posters/(\d+)(?:[/?#]|$)", re.I)
_SET_RE = re.compile(r"/set/(\d+)(?:[/?#]|$)", re.I)
_USER_RE = re.compile(r"/user/([^/?#]+)", re.I)
_ASSET_RE = re.compile(r"/api/assets/(\d+)/download", re.I)
_YEAR_RE = re.compile(r"(?:\(|\[)((?:19|20)\d{2})(?:\)|\])")


def _classes(attrs):
    return set((attrs.get("class") or "").split())


def _attrs(items):
    return {key: value or "" for key, value in items}


def _largest_srcset(value):
    """Return the largest public image candidate exposed by TPDb.

    TPDb commonly exposes several preview sizes through srcset.  Kodi can use
    the public image URL directly in remote-art mode, so prefer the largest
    candidate instead of the first (usually smallest) one.
    """
    if not value:
        return ""
    best_url = ""
    best_score = -1
    for raw in value.split(","):
        parts = raw.strip().split()
        if not parts:
            continue
        url = parts[0].strip()
        score = 0
        if len(parts) > 1:
            descriptor = parts[1].lower()
            try:
                if descriptor.endswith("w"):
                    score = int(float(descriptor[:-1]))
                elif descriptor.endswith("x"):
                    score = int(float(descriptor[:-1]) * 1000)
            except ValueError:
                score = 0
        # Later candidates win ties because srcset is normally ascending.
        if score >= best_score:
            best_url = url
            best_score = score
    return best_url


def split_title_year(value):
    value = html.unescape(value or "").strip()
    value = re.sub(r"\.(?:jpe?g|png|webp)$", "", value, flags=re.I)
    match = _YEAR_RE.search(value)
    if not match:
        return value.strip(), ""
    year = match.group(1)
    title = value[: match.start()].strip()
    return title, year


class SearchPageParser(HTMLParser):
    def __init__(self, base_url=_BASE):
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.pages = []
        self._active = None
        self._seen = set()

    def handle_starttag(self, tag, attrs):
        if tag.lower() != "a":
            return
        data = _attrs(attrs)
        href = data.get("href", "")
        absolute = urljoin(self.base_url, href)
        parsed = urlparse(absolute)
        host = (parsed.hostname or "").lower()
        if host not in ("theposterdb.com", "www.theposterdb.com"):
            return
        match = _POSTERS_RE.search(parsed.path)
        if not match:
            return
        url = "{}/posters/{}".format(self.base_url, match.group(1))
        if url in self._seen:
            return
        self._seen.add(url)
        self._active = {"url": url, "parts": [], "depth": 1}

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag):
        if self._active and tag.lower() == "a":
            label = " ".join("".join(self._active["parts"]).split())
            self.pages.append(SearchPage(url=self._active["url"], label=label))
            self._active = None

    def handle_data(self, data):
        if self._active:
            self._active["parts"].append(data)


class PosterCardParser(HTMLParser):
    def __init__(self, base_url=_BASE):
        super().__init__(convert_charrefs=True)
        self.base_url = base_url
        self.posters = []
        self._pending_thumb = ""
        self._div_depth = 0
        self._card = None
        self._card_start_depth = 0
        self._capture = None
        self._capture_parts = []

    def handle_starttag(self, tag, attrs):
        tag = tag.lower()
        data = _attrs(attrs)
        classes = _classes(data)

        if tag == "div":
            self._div_depth += 1
            if "overlay" in classes and data.get("data-poster-id"):
                self._card = PosterEntry(
                    asset_id=data.get("data-poster-id", ""),
                    poster_type=data.get("data-poster-type", ""),
                    thumb_url=self._pending_thumb,
                )
                self._card_start_depth = self._div_depth

        if tag == "source" and data.get("type", "").lower() == "image/jpeg":
            src = _largest_srcset(data.get("srcset", ""))
            if src:
                self._pending_thumb = urljoin(self.base_url, src)
                if self._card and not self._card.thumb_url:
                    self._card.thumb_url = self._pending_thumb

        if not self._card:
            return

        if tag == "p" and "text-break" in classes and "uploaded-by" not in classes:
            self._capture = "title"
            self._capture_parts = []
        elif tag == "a":
            href = data.get("href", "")
            user = _USER_RE.search(href)
            set_match = _SET_RE.search(href)
            asset = _ASSET_RE.search(href)
            page = _POSTERS_RE.search(href)
            if user:
                self._card.username = user.group(1)
            if set_match:
                self._card.set_id = set_match.group(1)
                if "set_poster_count" in classes:
                    self._capture = "set_count"
                    self._capture_parts = []
            if asset:
                self._card.asset_id = self._card.asset_id or asset.group(1)
                self._card.download_url = urljoin(self.base_url, href)
                if not self._card.title and data.get("download"):
                    self._card.title, self._card.year = split_title_year(data.get("download"))
            if page:
                self._card.collection_url = urljoin(self.base_url, href)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)

    def handle_endtag(self, tag):
        tag = tag.lower()
        if self._card and self._capture == "title" and tag == "p":
            value = " ".join("".join(self._capture_parts).split())
            self._card.title, self._card.year = split_title_year(value)
            self._capture = None
            self._capture_parts = []
        elif self._card and self._capture == "set_count" and tag == "a":
            raw = "".join(self._capture_parts).strip()
            try:
                self._card.set_count = int(re.search(r"\d+", raw).group(0))
            except Exception:
                self._card.set_count = 0
            self._capture = None
            self._capture_parts = []

        if tag == "div":
            if self._card and self._div_depth == self._card_start_depth:
                if not self._card.download_url and self._card.asset_id:
                    self._card.download_url = "{}/api/assets/{}/download?performed_by=posterid".format(
                        self.base_url, self._card.asset_id
                    )
                self.posters.append(self._card)
                self._card = None
                self._card_start_depth = 0
            self._div_depth = max(0, self._div_depth - 1)

    def handle_data(self, data):
        if self._card and self._capture:
            self._capture_parts.append(data)


def parse_search_pages(html_text, base_url=_BASE):
    parser = SearchPageParser(base_url)
    parser.feed(html_text or "")
    return parser.pages


def parse_poster_cards(html_text, base_url=_BASE):
    parser = PosterCardParser(base_url)
    parser.feed(html_text or "")
    seen = set()
    result = []
    for poster in parser.posters:
        key = poster.asset_id or poster.download_url
        if not key or key in seen:
            continue
        seen.add(key)
        result.append(poster)
    return result

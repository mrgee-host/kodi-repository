# -*- coding: utf-8 -*-
import xbmc

from . import settings

_PREFIX = "[TPDb Artwork Picker] "


def _debug_enabled():
    return settings.get_bool("debug", True)


def debug(message):
    if _debug_enabled():
        xbmc.log(_PREFIX + str(message), xbmc.LOGDEBUG)


def info(message):
    xbmc.log(_PREFIX + str(message), xbmc.LOGINFO)


def warning(message):
    xbmc.log(_PREFIX + str(message), xbmc.LOGWARNING)


def error(message):
    xbmc.log(_PREFIX + str(message), xbmc.LOGERROR)

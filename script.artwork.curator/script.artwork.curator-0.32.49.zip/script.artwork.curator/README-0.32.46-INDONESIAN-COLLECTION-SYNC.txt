Library Artwork Curator 0.32.46
=================================

Feature: Indonesian movie collection sync

Default behavior:
- Detection uses the existing Indonesian movie folder markers.
- Every matching movie is assigned to "Indonesian Movies Collection".
- A previous Kodi movie-set assignment is replaced.
- The sync runs after service startup and after each completed video scan.
- Manual action:
  Maintenance tools -> Sync Indonesian movie collection

Settings:
- Automatically force Indonesian movies into one collection
- Indonesian movie collection name

Diagnostics:
- summary/indonesian-movie-collection-state.txt
- runtime/diagnostics/indonesian-collection-sync.txt

The implementation uses Kodi JSON-RPC VideoLibrary.SetMovieDetails with only
the set field. It does not edit media files or NFO files.

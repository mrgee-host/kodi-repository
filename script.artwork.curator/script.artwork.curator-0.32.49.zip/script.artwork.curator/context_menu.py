import sys
import xbmcgui

import context
from lib import runtrace
from lib.libs import mediatypes
from lib.libs.addonsettings import addon
from lib.tpdb.workflow import run_movie_context, run_set_context

BASE_ACTIONS = [
    ('auto', 'Add missing artwork'),
    ('refreshitem', 'Refresh artwork for this item'),
    ('gui', 'Select artwork'),
]
EXPERT_ACTIONS = [
    ('dryrun', 'Dry run artwork selection'),
]


def _selected_type():
    try:
        listitem = getattr(sys, 'listitem', None)
        mediatype = context.get_mediatype(listitem)
        dbid = context.get_dbid(listitem)
        if mediatype in (mediatypes.MOVIE, mediatypes.MOVIESET, mediatypes.TVSHOW, mediatypes.SEASON, mediatypes.EPISODE):
            return mediatype
        mediatype, _dbid = context.resolve_library_item(listitem, mediatype, dbid)
        return mediatype or ''
    except Exception:
        return ''


def _actions():
    mediatype = _selected_type()
    actions = list(BASE_ACTIONS)
    if mediatype == mediatypes.MOVIE:
        actions.append(('tpdb_movie', 'Choose TPDb poster'))
    elif mediatype == mediatypes.MOVIESET:
        actions.append(('tpdb_set', 'Choose TPDb collection poster set'))
    if addon.get_setting('show_expert_context'):
        actions.extend(EXPERT_ACTIONS)
    return actions


def main():
    with runtrace.run_context('context.menu'):
        actions = _actions()
        labels = [label for _mode, label in actions]
        selected = xbmcgui.Dialog().select('Library Artwork Curator', labels)
        if selected < 0:
            runtrace.event('context', 'submenu cancelled')
            return
        mode = actions[selected][0]
        runtrace.event('context', 'submenu selected', mode=mode, label=actions[selected][1])
        if mode == 'tpdb_movie':
            run_movie_context()
            return
        if mode == 'tpdb_set':
            run_set_context()
            return
        context.main(mode)


if __name__ == '__main__':
    main()

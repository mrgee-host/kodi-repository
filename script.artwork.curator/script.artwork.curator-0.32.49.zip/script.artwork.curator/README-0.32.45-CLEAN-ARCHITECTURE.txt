LAC 0.32.45 clean artwork-owner

Role: artwork scraping, refresh, cache and database. KPM owns cropV2 visual XML and full diagnostics.

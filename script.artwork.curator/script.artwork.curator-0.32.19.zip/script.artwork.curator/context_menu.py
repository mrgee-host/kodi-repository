import sys
import xbmcgui

import context
from lib import runtrace

ACTIONS = [
    ('auto', 'Add missing artwork'),
    ('gui', 'Select artwork'),
    ('dryrun', 'Dry run artwork selection'),
]


def main():
    with runtrace.run_context('context.menu'):
        labels = [label for _mode, label in ACTIONS]
        selected = xbmcgui.Dialog().select('Library Artwork Curator', labels)
        if selected < 0:
            runtrace.event('context', 'submenu cancelled')
            return
        mode = ACTIONS[selected][0]
        runtrace.event('context', 'submenu selected', mode=mode, label=ACTIONS[selected][1])
        context.main(mode)


if __name__ == '__main__':
    main()

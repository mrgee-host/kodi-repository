# 0.32.19 - Season direct rebuild fix

- Direct season dry-run/Refresh All now uses the TV-show provider pipeline for season artwork.
- Provider results like `season.2.poster`, `season.2.banner`, `season.2.landscape`, `season.2.thumb`, and `season.2.fanart` are converted back to direct season art types before selection/apply.
- This is intended to fix cases like `Breaking Bad - Season 2` where direct season dry-run previously returned `{}` provider candidates even though Kodi still had current season art.
- Dry-run reports now show where current Kodi/DB artwork sits in the new order: usable position, provider-only position, or not found.

# Library Artwork Curator 0.32.18

- Strict auto fanart minimum resolution.
- No fallback to below-minimum fanart during auto Refresh/Fill.
- Fanart limit is maximum, not mandatory fill count.
- Empty fanart slots are marked N/A in AC DB and managed Kodi fanart leftovers are cleared during Refresh All.
- Addon id remains script.artwork.curator.

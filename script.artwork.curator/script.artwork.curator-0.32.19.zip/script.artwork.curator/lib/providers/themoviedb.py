import re
import xbmc
from abc import ABCMeta
from urllib.parse import urlencode

from lib.libs import mediatypes
from lib.libs.addonsettings import settings
from lib.libs.pykodi import json, UTF8JSONDecoder
from lib.libs.utils import SortedDisplay
from lib.providers import base
from lib.providers.base import AbstractProvider, AbstractImageProvider, cache, build_key_error

CFG_URL = 'https://api.themoviedb.org/3/configuration'
RASTER_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.webp')


def is_raster(path):
    return bool(path) and str(path).lower().split('?', 1)[0].endswith(RASTER_EXTENSIONS)


def iter_generaltypes(value):
    return value if isinstance(value, (tuple, list)) else (value,)


def region_language(language):
    if language == 'id':
        return 'id-ID'
    if language == 'en':
        return 'en-US'
    return language


def image_query(url):
    languages = []
    for language in base.languages:
        if language and language not in languages:
            languages.append(language)
    if 'en' not in languages:
        languages.append('en')
    include = languages + ['null']
    params = {'include_image_language': ','.join(include)}
    if languages:
        params['language'] = region_language(languages[0])
    return url + ('&' if '?' in url else '?') + urlencode(params)


def details_query_for_language(url, language):
    if language:
        return url + ('&' if '?' in url else '?') + urlencode({'language': region_language(language)})
    return url


def details_query(url):
    languages = [lang for lang in base.languages if lang]
    return details_query_for_language(url, languages[0]) if languages else url


class TheMovieDBAbstractProvider(AbstractImageProvider):
    __metaclass__ = ABCMeta
    contenttype = 'application/json'
    name = SortedDisplay('themoviedb.org', 'The Movie Database')
    _baseurl = None
    artmap = {}

    @property
    def baseurl(self):
        if not self._baseurl:
            apikey = settings.get_apikey('tmdb')
            if not apikey:
                raise build_key_error('tmdb')
            response = self.doget(CFG_URL, params={'api_key': apikey})
            if response is None:
                return None
            self._baseurl = response.json()['images']['secure_base_url']
        return self._baseurl

    def _get_rating(self, image):
        count = image.get('vote_count') or 0
        average = image.get('vote_average') or 5
        if count:
            return SortedDisplay(5 + (average - 5) * 2, '{0:.1f} stars'.format(average))
        return SortedDisplay(0, 'Not rated')

    def get_data(self, url):
        result = cache.cacheFunction(self._get_data, url)
        return result if result != 'Empty' else None

    def _get_data(self, url):
        apikey = settings.get_apikey('tmdb')
        if not apikey:
            raise build_key_error('tmdb')
        self.log('uncached', xbmc.LOGINFO)
        response = self.doget(url, params={'api_key': apikey})
        return 'Empty' if response is None else json.loads(response.text, cls=UTF8JSONDecoder)

    def login(self):
        raise build_key_error('tmdb')

    def build_image(self, filepath, source_type, language=None, official=False):
        if not is_raster(filepath) or not self.baseurl:
            return None
        previewbit = 'w300' if source_type in ('backdrops', 'stills', 'logos') else 'w342'
        # Poster quality must be determined from the /images metadata rows.
        # Do not let a details-endpoint primary poster bypass the minimum-height filter.
        official_poster = official and source_type == 'posters'
        return {
            'url': self.baseurl + 'original' + filepath,
            'preview': self.baseurl + previewbit + filepath,
            'provider': self.name,
            'language': language,
            'rating': SortedDisplay(0 if official_poster else (10 if official else 0),
                'Official primary' if official else 'Not rated'),
            'rating_unrated': bool(official_poster or not official),
            'size': SortedDisplay(0 if official_poster else (10000 if official else 0),
                'Use /images metadata' if official_poster else ('Official primary' if official else '')),
        }

    def detect_language(self, data, source_type, filepath):
        if not filepath:
            return None
        for image in (data or {}).get(source_type, []):
            if image.get('file_path') == filepath:
                language = image.get('iso_639_1')
                return None if language in (None, '', 'xx') else language
        return None

    def add_primary(self, result, arttypes, filepath, source_type, language=None):
        built = self.build_image(filepath, source_type, language, True)
        if not built:
            return
        for arttype in iter_generaltypes(arttypes):
            rows = result.setdefault(arttype, [])
            if not any(row.get('url') == built['url'] for row in rows):
                rows.insert(0, dict(built))
            if arttype == 'poster' and not language:
                result.setdefault('keyart', []).insert(0, dict(built))

    def get_detail_chain(self, url):
        """Fetch details in deterministic fallback order.

        Common flow: configured/Kodi language -> en-US -> raw details.
        Indonesian movie flow naturally becomes: id-ID -> en-US -> raw details.
        """
        languages = []
        for language in base.languages:
            if language and language not in languages:
                languages.append(language)
        if 'en' not in languages:
            languages.append('en')
        languages.append(None)

        result = []
        seen = set()
        for language in languages:
            query = details_query_for_language(url, language)
            if query in seen:
                continue
            seen.add(query)
            result.append((language, self.get_data(query) or {}))
        return result

    @staticmethod
    def first_detail_value(detail_chain, key):
        for language, details in detail_chain:
            value = details.get(key)
            if value:
                return value, language
        return None, None

    def add_primary_poster_fallback(self, result, arttype, filepath, images, prefix=''):
        """Use details.poster_path only when TMDb /images returned no poster gallery rows."""
        exacttype = prefix + arttype
        if result.get(exacttype):
            return
        self.add_primary(
            result,
            exacttype,
            filepath,
            'posters',
            self.detect_language(images, 'posters', filepath),
        )

    def promote_details_primary_poster(self, result, filepath, images, language=None, prefix=''):
        """Promote the first details.poster_path from the language fallback chain.

        The matching /images row is reused when available, preserving real size
        metadata for minimum-height checks. This is common behavior for movies,
        sets, TV shows, and seasons; Indonesian specialization only changes the
        movie language chain to start with id-ID.
        """
        if not filepath:
            return

        exacttype = prefix + 'poster'
        rows = result.setdefault(exacttype, [])
        target_url = self.baseurl + 'original' + filepath
        matched = next((row for row in rows if row.get('url') == target_url), None)

        if matched is None:
            matched = self.build_image(
                filepath,
                'posters',
                self.detect_language(images, 'posters', filepath) or language,
                False,
            )
            if not matched:
                return
            rows.insert(0, matched)

        matched['details_primary'] = True
        matched['localized_primary'] = bool(language == 'id')
        matched['gallery_order'] = -1

    def process_data(self, data, prefix=''):
        result = {}
        for source_type, artlist in (data or {}).items():
            if source_type not in self.artmap or not isinstance(artlist, list):
                continue
            previewbit = 'w300' if source_type in ('backdrops', 'stills', 'logos') else 'w342'
            for gallery_order, image in enumerate(artlist):
                filepath = image.get('file_path')
                if not is_raster(filepath):
                    continue
                lang = image.get('iso_639_1')
                language = None if lang in (None, '', 'xx') else lang
                width, height = image.get('width') or 0, image.get('height') or 0
                sortsize = height if source_type == 'posters' else width
                built = {
                    'url': self.baseurl + 'original' + filepath,
                    'preview': self.baseurl + previewbit + filepath,
                    'provider': self.name,
                    'language': language,
                    'rating': self._get_rating(image),
                    'rating_unrated': not bool(image.get('vote_count') or 0),
                    'size': SortedDisplay(sortsize, '{0}x{1}'.format(width, height)),
                    'gallery_order': gallery_order,
                }
                for generaltype in iter_generaltypes(self.artmap[source_type]):
                    result.setdefault(prefix + generaltype, []).append(dict(built))
                    if generaltype == 'poster' and not language:
                        result.setdefault(prefix + 'keyart', []).append(dict(built))
        return result

    def provides(self, types):
        available = set()
        for targets in self.artmap.values():
            available.update(iter_generaltypes(targets))
        return any(value.rsplit('.', 1)[-1] in available for value in types)


class TheMovieDBMovieProvider(TheMovieDBAbstractProvider):
    mediatype = mediatypes.MOVIE
    imagesurl = 'https://api.themoviedb.org/3/movie/%s/images'
    detailsurl = 'https://api.themoviedb.org/3/movie/%s'
    artmap = {'backdrops': ('fanart', 'landscape', 'thumb'), 'posters': 'poster', 'logos': ('clearlogo', 'logo')}

    def get_images(self, uniqueids, types=None):
        if not settings.get_apienabled('tmdb') or types is not None and not self.provides(types):
            return {}
        mediaid = get_mediaid(uniqueids, ('tmdb', 'imdb', 'unknown'))
        if not mediaid or not self.baseurl:
            return {}
        images = self.get_data(image_query(self.imagesurl % mediaid)) or {}
        result = self.process_data(images)
        detail_chain = self.get_detail_chain(self.detailsurl % mediaid)
        poster_path, poster_language = self.first_detail_value(detail_chain, 'poster_path')
        backdrop_path, _ = self.first_detail_value(detail_chain, 'backdrop_path')
        self.promote_details_primary_poster(result, poster_path, images, poster_language)
        self.add_primary_poster_fallback(result, 'poster', poster_path, images)
        self.add_primary(result, ('fanart', 'landscape', 'thumb'), backdrop_path, 'backdrops', None)
        return result


class TheMovieDBTVProvider(TheMovieDBAbstractProvider):
    mediatype = mediatypes.TVSHOW
    imagesurl = 'https://api.themoviedb.org/3/tv/%s/images'
    detailsurl = 'https://api.themoviedb.org/3/tv/%s'
    seasonimagesurl = 'https://api.themoviedb.org/3/tv/%s/season/%s/images'
    seasondetailsurl = 'https://api.themoviedb.org/3/tv/%s/season/%s'
    tvdbfindurl = 'https://api.themoviedb.org/3/find/%s?external_source=tvdb_id'
    artmap = {'backdrops': ('fanart', 'landscape', 'thumb'), 'posters': 'poster', 'logos': ('clearlogo', 'logo')}

    def _resolve(self, uniqueids):
        mediaid = get_mediaid(uniqueids, ('tmdb', 'unknown'))
        if not mediaid and uniqueids.get('tvdb'):
            found = self.get_data(self.tvdbfindurl % uniqueids['tvdb'])
            if found and found.get('tv_results'):
                mediaid = found['tv_results'][0].get('id')
        return mediaid

    def get_images(self, uniqueids, types=None):
        if not settings.get_apienabled('tmdb'):
            return {}
        mediaid = self._resolve(uniqueids)
        if not mediaid or not self.baseurl:
            return {}
        result = {}
        if types is None or self.provides(types):
            images = self.get_data(image_query(self.imagesurl % mediaid)) or {}
            result.update(self.process_data(images))
            detail_chain = self.get_detail_chain(self.detailsurl % mediaid)
            poster_path, poster_language = self.first_detail_value(detail_chain, 'poster_path')
            backdrop_path, _ = self.first_detail_value(detail_chain, 'backdrop_path')
            self.promote_details_primary_poster(result, poster_path, images, poster_language)
            self.add_primary_poster_fallback(result, 'poster', poster_path, images)
            self.add_primary(result, ('fanart', 'landscape', 'thumb'), backdrop_path, 'backdrops', None)
        seasons = set()
        for requested in types or ():
            matched = re.match(r'^season\.(-?\d+)\.poster$', requested)
            if matched:
                seasons.add(int(matched.group(1)))
        for season in sorted(seasons):
            prefix = 'season.{0}.'.format(season)
            images = self.get_data(image_query(self.seasonimagesurl % (mediaid, season))) or {}
            rows = self.process_data({'posters': images.get('posters', [])}, prefix)
            result.update(rows)
            detail_chain = self.get_detail_chain(self.seasondetailsurl % (mediaid, season))
            poster_path, poster_language = self.first_detail_value(detail_chain, 'poster_path')
            self.promote_details_primary_poster(result, poster_path, images, poster_language, prefix)
            self.add_primary_poster_fallback(result, 'poster', poster_path, images, prefix)
        return result


class TheMovieDBEpisodeProvider(TheMovieDBAbstractProvider):
    mediatype = mediatypes.EPISODE
    findurl = 'https://api.themoviedb.org/3/find/%s?external_source=tvdb_id'
    imagesurl = 'https://api.themoviedb.org/3/tv/%s/season/%s/episode/%s/images'
    detailsurl = 'https://api.themoviedb.org/3/tv/%s/season/%s/episode/%s'
    artmap = {'stills': ('thumb', 'landscape')}

    def get_images(self, uniqueids, types=None):
        if not settings.get_apienabled('tmdb') or types is not None and not self.provides(types) or not self.baseurl:
            return {}
        mediaid = get_mediaid(uniqueids, ('tmdbse', 'tvdbse', 'tvdb', 'unknown'))
        if not mediaid:
            return {}
        if uniqueids.get('tmdbse'):
            showid, season, episode = uniqueids['tmdbse'].split('/')
        elif uniqueids.get('tvdbse'):
            tvdbid, season, episode = uniqueids['tvdbse'].split('/')
            found = self.get_data(self.findurl % tvdbid) or {}
            if not found.get('tv_results'):
                return {}
            showid = found['tv_results'][0]['id']
        else:
            found = self.get_data(self.findurl % mediaid) or {}
            if not found.get('tv_episode_results'):
                return {}
            item = found['tv_episode_results'][0]
            showid, season, episode = item['show_id'], item['season_number'], item['episode_number']
        result = self.process_data(self.get_data(image_query(self.imagesurl % (showid, season, episode))) or {})
        detail_chain = self.get_detail_chain(self.detailsurl % (showid, season, episode))
        still_path, _ = self.first_detail_value(detail_chain, 'still_path')
        self.add_primary(result, ('thumb', 'landscape'), still_path, 'stills', None)
        return result


class TheMovieDBMovieSetProvider(TheMovieDBAbstractProvider):
    mediatype = mediatypes.MOVIESET
    imagesurl = 'https://api.themoviedb.org/3/collection/%s/images'
    detailsurl = 'https://api.themoviedb.org/3/collection/%s'
    artmap = {'backdrops': ('fanart', 'landscape', 'thumb'), 'posters': 'poster', 'logos': ('clearlogo', 'logo')}

    def get_images(self, uniqueids, types=None):
        if not settings.get_apienabled('tmdb') or types is not None and not self.provides(types):
            return {}
        mediaid = get_mediaid(uniqueids, ('tmdb', 'unknown'))
        if not mediaid or not self.baseurl:
            return {}
        images = self.get_data(image_query(self.imagesurl % mediaid)) or {}
        result = self.process_data(images)
        detail_chain = self.get_detail_chain(self.detailsurl % mediaid)
        poster_path, poster_language = self.first_detail_value(detail_chain, 'poster_path')
        backdrop_path, _ = self.first_detail_value(detail_chain, 'backdrop_path')
        self.promote_details_primary_poster(result, poster_path, images, poster_language)
        self.add_primary_poster_fallback(result, 'poster', poster_path, images)
        self.add_primary(result, ('fanart', 'landscape', 'thumb'), backdrop_path, 'backdrops', None)
        return result


class TheMovieDBSearch(AbstractProvider):
    name = SortedDisplay('themoviedb.org:search', 'The Movie Database search')
    contenttype = 'application/json'
    searchurl = 'https://api.themoviedb.org/3/search/{0}'
    tvexternalidsurl = 'https://api.themoviedb.org/3/tv/{0}/external_ids'
    typemap = {mediatypes.MOVIESET: 'collection'}

    def get_data(self, url, params=None):
        frozen = tuple(sorted((params or {}).items()))
        result = cache.cacheFunction(self._get_data, url, frozen)
        return result if result != 'Empty' else None

    def _get_data(self, url, frozen=()):
        apikey = settings.get_apikey('tmdb')
        if not apikey:
            raise build_key_error('tmdb')
        params = dict(frozen)
        params['api_key'] = apikey
        response = self.doget(url, params=params)
        return 'Empty' if response is None else response.json()

    def login(self):
        raise build_key_error('tmdb')

    def search(self, query, mediatype):
        if mediatype not in self.typemap:
            return []
        data = self.get_data(self.searchurl.format(self.typemap[mediatype]), {'query': query}) or {}
        return [{'label': item.get('name', ''), 'uniqueids': {'tmdb': item.get('id')}} for item in data.get('results', [])]

    def get_more_uniqueids(self, uniqueids, mediatype):
        if mediatype != mediatypes.TVSHOW or 'tvdb' in uniqueids:
            return {}
        mediaid = get_mediaid(uniqueids, ('tmdb', 'unknown'))
        if not mediaid:
            return {}
        data = self.get_data(self.tvexternalidsurl % mediaid) or {}
        return {'tvdb': data['tvdb_id']} if data.get('tvdb_id') else {}


def get_mediaid(uniqueids, sources=('tmdb', 'imdb', 'unknown')):
    for source in sources:
        if uniqueids.get(source):
            return uniqueids[source]

# Library Artwork Curator 0.32.37

Build: `lrs-shared-lock-notification-serialization`

What changed:

- Keeps the working 0.32.36 LRS-style auto-scan detection.
- Adds compatibility with Library Ratings Scraper's shared auto-scan lock file:
  `special://profile/addon_data/.kodi-auto-scan.lock`.
- LAC waits a short grace period after `VideoLibrary.OnScanFinished` so LRS gets first chance to start.
- If LRS already owns the lock, LAC keeps its pending job and retries silently every 5 seconds.
- LAC acquires the same lock while its own auto artwork job runs, then releases it on finish/cancel/no-op/error.

Expected log sequence after Kodi scan:

```text
auto fill pending immediately after video library scan | start_grace_seconds=4.0
... LRS starts/finishes ...
auto fill acquired shared auto-scan lock
LRS-style auto fill job starting
RUN START | service.auto_scan_lrs_style
auto fill released shared auto-scan lock
```

Goal: stop LRS and LAC progress/final notifications from racing and overwriting each other.

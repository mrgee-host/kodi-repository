# Library Artwork Curator 0.32.20

Custom fixes in this build:

- Auto artwork selection now uses one low-resolution fallback only when no candidate meets the preferred minimum resolution.
  - Fanart: if at least one candidate meets Minimum fanart resolution, only those candidates are used.
  - Fanart: if none meet the minimum, exactly one best lower-resolution fallback is selected; remaining fanart slots become N/A.
  - Landscape: if no 1920x1080 candidate exists, exactly one best lower-resolution fallback is selected.
  - Thumb: if no 1280x720 candidate exists, exactly one best lower-resolution fallback is selected.
- Season artwork targets now include keyart.
- Direct season provider path can request season keyart from TV providers.
- TV-show-level season artwork is no longer used when Include seasons is ON; the direct season pass decides final season artwork. This keeps Refresh All behavior clearer: TV shows handle show art, seasons handle season art.
- Provider order remains TMDb -> fanart.tv -> TheTVDB.
- Fanart Design B remains active: language/no-text -> provider -> resolution bucket -> gallery order.

No DB schema migration is required.

import re
import xbmc
from abc import ABCMeta, abstractmethod
from urllib.parse import quote

from lib.providers.base import AbstractImageProvider, cache, build_key_error
from lib.libs import mediatypes
from lib.libs.addonsettings import settings
from lib.libs.pykodi import json, UTF8JSONDecoder
from lib.libs.utils import SortedDisplay

RASTER_EXTENSIONS = ('.jpg', '.jpeg', '.png', '.webp')

def is_raster(url):
    return bool(url) and str(url).lower().split('?', 1)[0].endswith(RASTER_EXTENSIONS)

def iter_targets(value):
    return value if isinstance(value, (tuple, list)) else (value,)

class FanartTVAbstractProvider(AbstractImageProvider):
    __metaclass__ = ABCMeta
    api_section = None
    mediatype = None
    contenttype = 'application/json'
    name = SortedDisplay('fanart.tv', 'fanart.tv')
    apiurl = 'https://webservice.fanart.tv/v3/%s/%s'

    def get_images(self, uniqueids, types=None):
        if not settings.get_apienabled('fanarttv'):
            return {}
        if types is not None and not self.provides(types):
            return {}
        mediaid = get_mediaid(uniqueids, self.mediatype)
        if not mediaid:
            return {}
        data = self.get_data(mediaid)
        return self._get_images(data) if data else {}

    def get_data(self, mediaid):
        result = cache.cacheFunction(self._get_data, mediaid)
        return result if result != 'Empty' else None

    def _get_data(self, mediaid):
        apikey = settings.get_apikey('fanarttv')
        if not apikey:
            raise build_key_error('fanarttv')
        self.log('uncached', xbmc.LOGINFO)
        headers = {'api-key': apikey}
        if settings.fanarttv_clientkey:
            headers['client-key'] = settings.fanarttv_clientkey
        response = self.doget(self.apiurl % (self.api_section, mediaid), headers=headers)
        return 'Empty' if response is None else json.loads(response.text, cls=UTF8JSONDecoder)

    def login(self):
        raise build_key_error('fanarttv')

    def build_image(self, url, arttype, image, likediv=5.0):
        if not is_raster(url):
            return None
        result = {'url': url, 'provider': self.name}
        result['preview'] = url.replace('.fanart.tv/fanart/', '.fanart.tv/preview/')
        likes = int(image.get('likes') or 0)
        result['rating'] = SortedDisplay(
            5.25 + likes / float(likediv) if likes else 0,
            '{0} likes'.format(likes) if likes else 'Not rated')
        result['rating_unrated'] = not bool(likes)
        result['size'] = _get_imagesize(arttype)
        result['language'] = _get_imagelanguage(arttype, image)
        return result

    @abstractmethod
    def _get_images(self, data):
        pass

    @abstractmethod
    def provides(self, types):
        pass

class FanartTVSeriesProvider(FanartTVAbstractProvider):
    mediatype = mediatypes.TVSHOW
    api_section = 'tv'
    artmap = {
        'hdclearart': 'clearart', 'tvbanner': 'banner',
        'clearlogo': ('clearlogo', 'logo'), 'hdtvlogo': ('clearlogo', 'logo'),
        'characterart': 'characterart', 'showbackground': 'fanart',
        'tvthumb': ('landscape', 'thumb'), 'clearart': 'clearart',
        'tvposter': 'poster',
        'seasonthumb': (mediatypes.SEASON + '.%s.landscape', mediatypes.SEASON + '.%s.thumb'),
        'seasonbanner': mediatypes.SEASON + '.%s.banner',
        'seasonposter': (mediatypes.SEASON + '.%s.poster', mediatypes.SEASON + '.%s.keyart'),
        'showbackground-season': mediatypes.SEASON + '.%s.fanart',
    }

    def _get_images(self, data):
        result = {}
        for arttype, artlist in data.items():
            if arttype not in self.artmap or not isinstance(artlist, list):
                continue
            for image in artlist:
                url = quote(image.get('url', ''), safe="%/:=&?~#+!$,;'@()*[]")
                built = self.build_image(url, arttype, image, 3.0)
                if not built:
                    continue
                isseason = arttype in ('seasonthumb', 'seasonbanner', 'seasonposter')
                seasonnum = self._get_seasonnum(image, data.get('name', ''), not isseason)
                targets = iter_targets(self.artmap[arttype])
                for target in targets:
                    generaltype = target % seasonnum if isseason else target
                    if generaltype.endswith('.keyart') and built.get('language'):
                        continue
                    if generaltype == 'poster' and not built['language']:
                        result.setdefault('keyart', []).append(dict(built))
                    result.setdefault(generaltype, []).append(dict(built))
                if arttype == 'showbackground' and seasonnum is not None:
                    seasontype = 'season.{0}.fanart'.format(seasonnum)
                    seasonal = dict(built)
                    seasonal['hasseason'] = True
                    result.setdefault(seasontype, []).append(seasonal)
        return result

    def _get_seasonnum(self, image, itemname, ignoreall=False):
        allitem = None if ignoreall else -1
        if 'season' not in image:
            return None
        try:
            return int(image['season']) if image['season'] != 'all' else allitem
        except ValueError:
            return allitem

    def provides(self, types):
        flattened = set()
        for value in self.artmap.values():
            flattened.update(iter_targets(value))
        patterns = set(x if not x.startswith('season.') else re.sub(r'-?\d+', '%s', x) for x in types)
        return any(value in patterns for value in flattened)

class FanartTVMovieProvider(FanartTVAbstractProvider):
    mediatype = mediatypes.MOVIE
    api_section = 'movies'
    artmap = {
        'movielogo': ('clearlogo', 'logo'), 'hdmovielogo': ('clearlogo', 'logo'),
        'hdmovieclearart': 'clearart', 'movieart': 'clearart', 'moviedisc': 'discart',
        'moviebanner': 'banner', 'moviethumb': ('landscape', 'thumb'),
        'moviebackground': 'fanart', 'movieposter': 'poster',
    }
    disctitles = {'dvd': 'DVD', '3d': '3D', 'bluray': 'Blu-ray'}

    def _get_images(self, data):
        result = {}
        for arttype, artlist in data.items():
            if arttype not in self.artmap or not isinstance(artlist, list):
                continue
            for image in artlist:
                url = quote(image.get('url', ''), safe="%/:=&?~#+!$,;'@()*[]")
                built = self.build_image(url, arttype, image)
                if not built:
                    continue
                if arttype == 'moviedisc':
                    subtype = image.get('disc_type') or 'unknown'
                    built['subtype'] = SortedDisplay(subtype, self.disctitles.get(subtype, subtype))
                for target in iter_targets(self.artmap[arttype]):
                    if target == 'poster' and not built['language']:
                        result.setdefault('keyart', []).append(dict(built))
                    result.setdefault(target, []).append(dict(built))
        return result

    def provides(self, types):
        flattened = set()
        for value in self.artmap.values():
            flattened.update(iter_targets(value))
        return any(x in types for x in flattened)

class FanartTVMovieSetProvider(FanartTVMovieProvider):
    mediatype = mediatypes.MOVIESET

def get_mediaid(uniqueids, mediatype):
    sources = ('tmdb', 'imdb', 'unknown') if mediatype == mediatypes.MOVIE else \
        ('tmdb', 'unknown') if mediatype == mediatypes.MOVIESET else ('tvdb', 'unknown')
    for source in sources:
        if source in uniqueids and uniqueids[source]:
            return uniqueids[source]

def _get_imagesize(arttype):
    if arttype in ('hdtvlogo', 'hdclearart', 'hdmovielogo', 'hdmovieclearart'):
        return SortedDisplay(800, 'HD')
    if arttype in ('clearlogo', 'clearart', 'movielogo', 'movieart'):
        return SortedDisplay(400, 'SD')
    if arttype in ('tvbanner', 'seasonbanner', 'moviebanner'):
        return SortedDisplay(1000, '1000x185')
    if arttype in ('showbackground', 'moviebackground'):
        return SortedDisplay(1920, '1920x1080')
    if arttype in ('tvposter', 'seasonposter', 'movieposter'):
        return SortedDisplay(1426, '1000x1426')
    if arttype in ('tvthumb', 'seasonthumb'):
        return SortedDisplay(1000, '1000x562')
    if arttype == 'characterart':
        return SortedDisplay(512, '512x512')
    if arttype == 'moviethumb':
        return SortedDisplay(1000, '1000x562')
    if arttype == 'moviedisc':
        return SortedDisplay(1000, '1000x1000')
    return SortedDisplay(0, '')

def _get_imagelanguage(arttype, image):
    if 'lang' not in image or arttype in ('showbackground', 'characterart', 'moviebackground'):
        return None
    value = image.get('lang')
    if arttype in ('clearlogo', 'hdtvlogo', 'seasonposter', 'hdclearart', 'clearart', 'tvthumb',
            'seasonthumb', 'tvbanner', 'seasonbanner', 'movielogo', 'hdmovielogo',
            'hdmovieclearart', 'movieart', 'moviebanner', 'moviethumb', 'moviedisc'):
        return value if value not in ('', '00') else 'en'
    return value if value not in ('', '00') else None

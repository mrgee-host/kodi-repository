v0.32.11
- Cache progress now counts every checked artwork URL, including already-cached URLs, so it no longer sticks at 0/total.
- Cache missing artwork asks for confirmation before starting and uses a single finish notification.
- Added Library Clean auto cleanup: Kodi Clean Video removes matching Library Artwork Curator DB rows.
- Menu Back/cancel returns to the parent menu for run submenus.

Library Artwork Curator 0.32.10
- Uses short LRS-style progress text so the action suffix is not cut off.
- Cache collection text is now COLLECTING LIBRARY ARTWORK; no VIDEO wording.
- Cache/Prune/Diagnostics finish with notifications only, no blocking OK popup.
- Cache missing artwork is promoted to the main menu; Clean legacy icon is hidden from Maintenance.
- Removes legacy contribute/donate completion notifications.
- Auto scan uses before/after library snapshots like LRS, queues in memory if AC is already busy, and waits for LRS shared lock before running.
- Final completion notifications include item/artwork/error counts.


0.32.9 - DB-first run/report/sorting hotfix
- Fixes DB-first final-skip TypeError that made skipped items appear as errors.
- Processes library in LRS-style order: sets, movies, TV shows, seasons, episodes; each group sorted alphabetically, episodes by series/season/episode.
- Keeps Fill Missing notifications stable and truncates long titles while preserving the action suffix.
- Moves rolling artwork report into diagnostics/.
- Cache/prune finish with compact notifications, no blocking OK dialog, and force progress to 100%.
- Auto new-item scan uses memory queue, waits for LRS shared lock, avoids concurrent AC runs, and shows a compact finish notification.

# Library Artwork Curator 0.32.7 - DB-first UI/provider hotfix

- Renamed visible add-on to **Library Artwork Curator**.
- Removed manual percent from progress text to prevent `0% - 0%` double display.
- Internal `SKIP` is no longer shown as a notification phase.
- DB-first skip/apply now happens before provider-ID enrichment, so final DB rows should not trigger TMDb collection search.
- Stop/cancel now records the run as aborted.
- Fresh DB schema removes redundant `run_items.phase`; no DB fixing/migration is bundled.

# Library Artwork Curator 0.32.6 - Icon Hotfix

Changes:
- Replaced addon icon with the user-provided Library Library Artwork Curator icon.
- Resized icon.png to 256x256 for Kodi addon display.
- No DB schema, DB-first, provider, or diagnostics logic changes from 0.32.5.

# Library Artwork Curator 0.32.5 DB-first

- Final DB-first workflow: artwork-cache.db is the control source; Kodi DB is the display target.
- Final tables: metadata, library_items, artwork, runs, run_items.
- artwork replaces old artwork_slots + artwork_status.
- No bundled DB. Install the supplied DB manually.
- No DB migration/fixing logic is bundled.

# -*- coding: utf-8 -*-
"""Persistent TPDb cookie storage for Kodi.

Cookies are kept under special://profile/addon_data/context.tpdb.artwork rather
than inside the add-on folder, so installing an update does not erase a session.
"""
import http.cookiejar
import json
import os
import time

import xbmcvfs

from . import log

SESSION_DIR = xbmcvfs.translatePath("special://profile/addon_data/context.tpdb.artwork")
SESSION_FILE = os.path.join(SESSION_DIR, "tpdb_session.json")


def _ensure_dir():
    os.makedirs(SESSION_DIR, exist_ok=True)


def new_jar():
    return http.cookiejar.CookieJar()


def _cookie_from_dict(item):
    expires = item.get("expires")
    try:
        expires = int(expires) if expires not in (None, "") else None
    except (TypeError, ValueError):
        expires = None
    return http.cookiejar.Cookie(
        version=0,
        name=str(item.get("name") or ""),
        value=str(item.get("value") or ""),
        port=None,
        port_specified=False,
        domain=str(item.get("domain") or ".theposterdb.com"),
        domain_specified=True,
        domain_initial_dot=str(item.get("domain") or "").startswith("."),
        path=str(item.get("path") or "/"),
        path_specified=True,
        secure=bool(item.get("secure", False)),
        expires=expires,
        discard=expires is None,
        comment=None,
        comment_url=None,
        rest={},
        rfc2109=False,
    )


def load():
    jar = new_jar()
    if not os.path.exists(SESSION_FILE):
        return jar
    try:
        with open(SESSION_FILE, "r", encoding="utf-8") as handle:
            payload = json.load(handle)
        for item in payload.get("cookies", []):
            cookie = _cookie_from_dict(item)
            if cookie.name and (cookie.expires is None or cookie.expires > int(time.time())):
                jar.set_cookie(cookie)
    except Exception as exc:
        log.warning("Unable to load TPDb session: {!r}".format(exc))
    return jar


def save(jar):
    _ensure_dir()
    cookies = []
    for cookie in jar:
        cookies.append(
            {
                "name": cookie.name,
                "value": cookie.value,
                "domain": cookie.domain,
                "path": cookie.path,
                "secure": bool(cookie.secure),
                "expires": cookie.expires,
            }
        )
    with open(SESSION_FILE, "w", encoding="utf-8") as handle:
        json.dump({"cookies": cookies}, handle, ensure_ascii=False, indent=2)
    log.info("Saved TPDb session cookies={}".format(len(cookies)))


def clear():
    try:
        if os.path.exists(SESSION_FILE):
            os.remove(SESSION_FILE)
    except OSError as exc:
        log.warning("Unable to clear TPDb session: {!r}".format(exc))


def apply_cookie_header(jar, header_value, domain=".theposterdb.com"):
    """Load a browser Cookie header as a fallback for browser challenges."""
    for part in (header_value or "").split(";"):
        part = part.strip()
        if not part or "=" not in part:
            continue
        name, value = part.split("=", 1)
        name = name.strip()
        if not name or name.lower() in ("path", "domain", "expires", "secure", "httponly", "samesite"):
            continue
        jar.set_cookie(
            http.cookiejar.Cookie(
                version=0,
                name=name,
                value=value.strip(),
                port=None,
                port_specified=False,
                domain=domain,
                domain_specified=True,
                domain_initial_dot=True,
                path="/",
                path_specified=True,
                secure=True,
                expires=None,
                discard=True,
                comment=None,
                comment_url=None,
                rest={},
                rfc2109=False,
            )
        )


def cookie_count(jar):
    return sum(1 for _ in jar)

# -*- coding: utf-8 -*-
from resources.lib.workflow import run_set_context

if __name__ == "__main__":
    run_set_context()

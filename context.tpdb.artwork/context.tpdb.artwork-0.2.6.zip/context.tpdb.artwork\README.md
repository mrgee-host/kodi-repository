# TPDb Artwork Picker v0.2.5

## Runtime settings compatibility fix

Kodi's classic `resources/settings.xml` format is retained, and the Python code now
reads and writes those values using `xbmcaddon.Addon().getSetting()` and
`setSetting()`. This avoids `Invalid setting type` exceptions when the picker is
started from a movie or collection context menu.

# TPDb Artwork Picker for Kodi 22 Piers

Native Kodi Python add-on for choosing The Poster Database artwork from Kodi.
No Selenium, Chrome, VB.NET helper, localhost server, or external executable is bundled.

## Update 0.1.2

- Fixed the Kodi 22 `Invalid setting type` error by converting `resources/settings.xml` to the current versioned settings format.
- Added native TPDb email/username and password login.
- Added saved-session test and clear actions.
- The password field is hidden in Kodi UI. The password is cleared after a successful login unless **Remember password in Kodi settings** is enabled.
- The TPDb cookie session is stored under `special://profile/addon_data/context.tpdb.artwork/tpdb_session.json`.
- Kept an optional manual Cookie header fallback for browser verification challenges.
- Registered the executable script before the context-menu extension so the add-on can be opened more easily from **Program add-ons**.

## Install or update

1. Kodi > Settings > System > Add-ons > enable **Unknown sources**.
2. Kodi > Add-ons > Install from zip file.
3. Select `context.tpdb.artwork-0.2.5.zip`.
4. Restart Kodi once after updating the context-menu extension.

## Login

Open **Add-ons > Program add-ons > TPDb Artwork Picker** and select:

- **Login / refresh TPDb session**
- **Test saved TPDb session**
- **Clear saved TPDb session**

The same actions are also available in the add-on Settings page.

Native login submits the ordinary TPDb sign-in form and saves its cookie session. It does not bypass CAPTCHA, Cloudflare checks, or browser challenges. If TPDb requires browser verification, paste a valid browser Cookie header into **Settings > Advanced**.

## Context-menu action

Open the context menu for a Kodi movie or movie set and select **TPDb Artwork...**.

## Notes

- Selected images are cached under `special://profile/addon_data/context.tpdb.artwork/cache`.
- Artwork is applied through Kodi JSON-RPC `VideoLibrary.SetMovieDetails` and `VideoLibrary.SetMovieSetDetails`.


## Kodi settings compatibility (v0.1.3)

The add-on uses Kodi's legacy-compatible `resources/settings.xml` syntax. This avoids
`Invalid setting type` errors reported by some Kodi builds when opening converted
version-1 settings. Account fields remain available in **Settings**. Run login, session
test, and clear-session commands from **Add-ons > Program add-ons > TPDb Artwork Picker**.

## v0.1.5 collection picker improvements

- Collection-page search results use a compact names-only list because TPDb search results do not expose reliable thumbnails for those pages.
- After choosing an poster set, a custom large preview opens with five poster cards per page.
- Use **APPLY** to apply the selected set. Press **BACK** or choose **BACK** to return to the poster-set chooser and try another set without starting over.
- Reports use `OK`, `SKIP`, and `FAIL` instead of unsupported Unicode glyphs. The movie-set artwork entry is labelled `[Collection]`.


## Remote artwork mode (v0.1.6)

`Store remote artwork URL in Kodi library` is enabled by default. Newly applied posters use TPDb's full-size remote asset endpoint, for example `https://theposterdb.com/index.php/api/assets/629678/view`, so Kodi art-table entries no longer point to an optimized preview image or `special://profile/addon_data/context.tpdb.artwork/cache`.

The picker grid still uses the smaller optimized `images.theposterdb.com` thumbnail URL intentionally, because thumbnails load faster while browsing. Only the final URL written to Kodi's library uses the full-size TPDb asset endpoint.

If TPDb does not expose a public image URL for a poster, the add-on falls back to a local cached file. Existing local files from older versions are not deleted automatically. Reapply old artwork before using `Clear local artwork cache` when converting old entries to remote URLs.

Kodi still creates its own internal thumbnail cache under `userdata/Thumbnails` when artwork is displayed. Kodi's internal cache is separate from this add-on cache and cannot be disabled by this add-on.


## Skin-native collection preview (v0.1.7)

The custom image-button preview introduced in v0.1.5 has been removed. Kodi now
opens a native detailed selection dialog styled by the active skin. The first
two rows are **APPLY** and **BACK**; the remaining rows are artwork
previews with thumbnails. The list scrolls normally, so no custom page buttons
are needed. Closing the dialog or choosing **BACK** returns to the uploader
set list.


## v0.1.9 collection-set preview

The poster-set confirmation screen is a large read-only artwork grid. Poster cards are visual previews only and do not accept clicks. The only visible action is **APPLY**. Press the normal Back action to return to the poster-set list. Sets with more than eight artwork entries can be previewed with arrow keys or the mouse wheel.


## v0.1.9 compact native-style preview

- Replaces the oversized full-screen preview surface with a compact centered dialog inspired by Arctic Fuse 3's native Choose art layout.
- Shows a 3 x 2 read-only artwork grid. Poster cards are not clickable.
- Keeps one visible action only: APPLY. Physical Back returns to uploader selection.
- Uses the active skin's circle-check icon for the apply action.


## v0.2.0 native DialogSelect preview

Collection-set preview now uses Kodi DialogSelect.xml through `xbmcgui.Dialog().select(..., useDetails=True)`. The first native card applies the set; artwork cards are display-only and cannot apply posters individually. Closing the dialog returns to the poster-set chooser.


## v0.2.1 preview window
Collection-set preview uses the active skin FileBrowser.xml thumbnail panel (control 451). Posters are preview-only. Control 413 is relabeled APPLY. Physical Back returns to the poster-set chooser.


## v0.2.2 native FileBrowser preview fix

Arctic Fuse 3 renders the visible APPLY action as FileBrowser control `9001`, forwarding clicks to hidden proxy control `413`. The skin only renders that button while control `450` is visible. The preview therefore keeps an empty `450` behind the read-only poster panel `451`.


## v0.2.3

Collection-page searches are now filtered conservatively. Exact normalized collection titles open immediately; loose unrelated TPDb website-search suggestions are hidden.


## v0.2.5 full-size remote artwork

- Stores selected library posters as TPDb full-size remote asset URLs: `https://theposterdb.com/index.php/api/assets/{asset_id}/view`.
- Keeps optimized image URLs only inside picker thumbnails for faster browsing.
- Reapply artwork selected with older versions to replace existing optimized URLs in Kodi's art table.

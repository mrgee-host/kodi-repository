# -*- coding: utf-8 -*-
import sys

import xbmcaddon
import xbmcgui

from resources.lib.workflow import (
    run_choose_library_set,
    run_clear_session,
    run_clear_art_cache,
    run_login,
    run_manual_movie,
    run_manual_set,
    run_test_session,
)


def _label(string_id, fallback):
    value = xbmcaddon.Addon().getLocalizedString(string_id)
    return value or fallback


def main():
    action = (sys.argv[1] if len(sys.argv) > 1 else "").strip().lower()
    if action == "login":
        run_login()
        return
    if action == "test_session":
        run_test_session()
        return
    if action == "clear_session":
        run_clear_session()
        return
    if action == "clear_art_cache":
        run_clear_art_cache()
        return

    dialog = xbmcgui.Dialog()
    choice = dialog.select(
        "TPDb Artwork Picker",
        [
            _label(32200, "Search movie poster (preview)"),
            _label(32201, "Search collection poster set (preview)"),
            _label(32202, "Apply poster set to Kodi movie set"),
            _label(32203, "Login / refresh TPDb session"),
            _label(32204, "Test saved TPDb session"),
            _label(32205, "Clear saved TPDb session"),
            _label(32206, "Open add-on settings"),
            _label(32207, "Clear local artwork cache"),
        ],
    )
    if choice == 0:
        run_manual_movie()
    elif choice == 1:
        run_manual_set()
    elif choice == 2:
        run_choose_library_set()
    elif choice == 3:
        run_login()
    elif choice == 4:
        run_test_session()
    elif choice == 5:
        run_clear_session()
    elif choice == 6:
        xbmcaddon.Addon().openSettings()
    elif choice == 7:
        run_clear_art_cache()


if __name__ == "__main__":
    main()

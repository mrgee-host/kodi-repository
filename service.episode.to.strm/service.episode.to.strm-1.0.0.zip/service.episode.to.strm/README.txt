EPISODE TO EMPTY STRM 1.0.0
===========================

FUNGSI
Setelah episode Kodi selesai diputar secara normal, addon akan:

1. Menyimpan identitas episode, status watched, last played, resume, date added,
   unique ID, dan artwork yang sedang terpasang.
2. Membuat placeholder sementara dan menguji izin rename.
3. Menghapus entri episode lama dari database Kodi.
4. Menghapus file video sumber tanpa membatasi ekstensi tertentu.
5. Membuat file .strm kosong dengan nama dasar yang sama.
6. Menjalankan VideoLibrary.Scan hanya pada folder episode.
7. Menemukan episode baru dan memulihkan data Kodi.
8. Memindahkan cache Library Artwork Curator jika DBID berubah.
9. Memindahkan rating Library Ratings Scraper jika DBID berubah.
10. Memasang ulang artwork dari snapshot Kodi dan cache LAC.
11. Melakukan Container.Refresh.

ADDON TIDAK MENJALANKAN CLEAN LIBRARY.
ADDON TIDAK MENJALANKAN SCRAPE INTERNET LAC/LRS PENUH.

CONTOH
Sebelum:
  Series.Name.S01E03.mkv
  Series.Name.S01E03.nfo

Sesudah:
  Series.Name.S01E03.strm   (0 byte)
  Series.Name.S01E03.nfo

BATAS KEAMANAN
- Hanya item library dengan type episode dan episodeid valid.
- Hanya callback onPlayBackEnded, bukan Stop atau Error.
- File .strm yang sudah ada tidak diproses.
- plugin://, http://, https://, pvr://, upnp://, stack://, archive, dan disc folder tidak diproses.
- File .strm tujuan yang sudah ada tidak akan ditimpa.
- Sebelum operasi destruktif, addon membuat pending-conversion.json untuk recovery.

KOMPATIBILITAS CACHE
- LAC yang didukung: artwork-cache.db dengan key episode:<dbid>.
- LRS yang didukung: ratings-cache.db dengan key episode|<dbid> pada tabel ratings
  dan external_ratings.
- Jika addon tersebut tidak terpasang atau database tidak ada, konversi Kodi tetap berjalan.

LOG DAN STATUS
Buka addon dari Program Add-ons untuk melihat hasil terakhir.
File status tersimpan di:
  special://profile/addon_data/service.episode.to.strm/

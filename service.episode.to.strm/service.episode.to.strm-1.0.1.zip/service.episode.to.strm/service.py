# -*- coding: utf-8 -*-
from __future__ import annotations

import copy
import datetime
import json
import os
import re
import sqlite3
import threading
import time
from typing import Any, Dict, List, Optional, Tuple

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo("id")
ADDON_NAME = ADDON.getAddonInfo("name")
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
ICON = ADDON.getAddonInfo("icon")

PENDING_FILE = os.path.join(PROFILE, "pending-conversion.json")
REPORT_FILE = os.path.join(PROFILE, "last-conversion.json")
LAC_DB = xbmcvfs.translatePath("special://profile/addon_data/script.artwork.curator/artwork-cache.db")
LRS_DB = xbmcvfs.translatePath("special://profile/addon_data/script.library.ratings.scraper/ratings-cache.db")
SHARED_LOCK_FILE = os.path.join(os.path.dirname(PROFILE.rstrip(os.sep)), ".kodi-auto-scan.lock")
SHARED_LOCK_STALE_SECONDS = 180

CAPTURE_RETRY_SECONDS = 0.35
CONVERSION_DELAY_SECONDS = 1.25
LIBRARY_IDLE_TIMEOUT = 120.0
FIND_EPISODE_TIMEOUT = 75.0
SCAN_RETRY_SECONDS = 3.0
RECOVERY_RETRY_SECONDS = 30.0

EXCLUDED_PREFIXES = (
    "plugin://", "http://", "https://", "pvr://", "upnp://", "stack://",
    "rar://", "zip://", "bluray://", "dvd://", "musicdb://", "videodb://",
)
DISC_MARKERS = ("/video_ts/", "/bdmv/")
APPLY_LAC_STATUSES = ("OK", "MANUAL", "PROTECTED")


def _ensure_profile() -> None:
    try:
        os.makedirs(PROFILE, exist_ok=True)
    except Exception:
        pass


def log(message: str, level: int = xbmc.LOGINFO) -> None:
    xbmc.log("[{0}] {1}".format(ADDON_ID, message), level)


def notify(message: str, warning: bool = False, duration: int = 5000) -> None:
    try:
        xbmcgui.Dialog().notification(
            ADDON_NAME,
            message,
            xbmcgui.NOTIFICATION_WARNING if warning else ICON,
            duration,
        )
    except Exception:
        pass


def now_text() -> str:
    return datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def now_iso() -> str:
    return datetime.datetime.now().astimezone().isoformat(timespec="seconds")


def safe_int(value: Any) -> Optional[int]:
    try:
        if value in (None, ""):
            return None
        return int(value)
    except (TypeError, ValueError):
        return None


def norm_text(value: Any) -> str:
    return re.sub(r"[^a-z0-9]+", " ", str(value or "").lower()).strip()


def norm_path(value: Any) -> str:
    text = str(value or "").strip().replace("\\", "/")
    while "//" in text and "://" not in text:
        text = text.replace("//", "/")
    return text.rstrip("/").casefold()


def json_rpc(method: str, params: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
    request = {
        "jsonrpc": "2.0",
        "id": 1,
        "method": method,
        "params": params or {},
    }
    try:
        raw = xbmc.executeJSONRPC(json.dumps(request, ensure_ascii=False))
        result = json.loads(raw or "{}")
        if isinstance(result, dict):
            return result
    except Exception as exc:
        log("JSON-RPC {0} failed: {1}".format(method, exc), xbmc.LOGWARNING)
    return {"error": {"message": "no response"}}


def rpc_ok(result: Dict[str, Any]) -> bool:
    return isinstance(result, dict) and "error" not in result and result.get("result") == "OK"


def read_json(path: str) -> Dict[str, Any]:
    try:
        with open(path, "r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def write_json(path: str, payload: Dict[str, Any]) -> None:
    _ensure_profile()
    temp = path + ".tmp"
    with open(temp, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, ensure_ascii=False, indent=2, sort_keys=True)
    os.replace(temp, path)


def delete_file_quiet(path: str) -> None:
    try:
        if os.path.exists(path):
            os.remove(path)
    except Exception:
        pass


def path_parts(path: str) -> Tuple[str, str]:
    value = str(path or "")
    if "/" in value.replace("\\", "/"):
        slash = max(value.rfind("/"), value.rfind("\\"))
        return value[:slash], value[slash + 1:]
    return "", value


def join_path(directory: str, filename: str) -> str:
    if not directory:
        return filename
    separator = "\\" if "\\" in directory and "/" not in directory else "/"
    return directory.rstrip("/\\") + separator + filename


def strm_paths(source_path: str) -> Tuple[str, str, str]:
    directory, filename = path_parts(source_path)
    stem, _extension = os.path.splitext(filename)
    if not stem:
        stem = filename
    target = join_path(directory, stem + ".strm")
    temp = target + ".tmp"
    return directory, target, temp


def supported_source_path(path: str) -> Tuple[bool, str]:
    value = str(path or "").strip()
    lower = value.lower().replace("\\", "/")
    if not value:
        return False, "empty path"
    if lower.endswith(".strm"):
        return False, "already STRM"
    if lower.startswith(EXCLUDED_PREFIXES):
        return False, "virtual or streaming path"
    if any(marker in lower for marker in DISC_MARKERS):
        return False, "disc folder path"
    # Windows drive paths such as C:\Video are accepted. Other URI schemes are not.
    if "://" in lower and not lower.startswith(("smb://", "nfs://", "file://")):
        return False, "unsupported protocol"
    return True, ""


def vfs_create_empty(path: str) -> bool:
    try:
        handle = xbmcvfs.File(path, "w")
        handle.close()
        return xbmcvfs.exists(path)
    except Exception as exc:
        log("Create empty file failed for {0}: {1}".format(path, exc), xbmc.LOGWARNING)
        return False


def vfs_delete(path: str, attempts: int = 1, delay: float = 0.35) -> bool:
    last_error = ""
    for index in range(max(1, int(attempts))):
        try:
            if not xbmcvfs.exists(path):
                return True
            xbmcvfs.delete(path)
            if not xbmcvfs.exists(path):
                return True
        except Exception as exc:
            last_error = str(exc)
        if index + 1 < max(1, int(attempts)):
            time.sleep(max(0.0, float(delay)))
    log("Delete failed for {0}: {1}".format(path, last_error or "file still exists"), xbmc.LOGWARNING)
    return False


def vfs_rename(source: str, target: str) -> bool:
    try:
        if xbmcvfs.exists(target):
            return False
        return bool(xbmcvfs.rename(source, target)) and xbmcvfs.exists(target)
    except Exception as exc:
        log("Rename failed {0} -> {1}: {2}".format(source, target, exc), xbmc.LOGWARNING)
        return False


def preflight_placeholder(target: str, temp: str) -> Tuple[bool, str]:
    if xbmcvfs.exists(target):
        return False, "target STRM already exists"
    if xbmcvfs.exists(temp) and not vfs_delete(temp):
        return False, "old temporary file cannot be removed"
    if not vfs_create_empty(temp):
        return False, "temporary STRM cannot be created"
    # Test both rename directions before deleting any media.
    if not vfs_rename(temp, target):
        vfs_delete(temp)
        return False, "temporary STRM cannot be renamed"
    if not vfs_rename(target, temp):
        return False, "STRM rename rollback test failed"
    return True, ""


def library_scanning() -> bool:
    try:
        return xbmc.getCondVisibility("Library.IsScanningVideo")
    except Exception:
        return False


def wait_library_idle(monitor: xbmc.Monitor, timeout: float) -> bool:
    deadline = time.time() + timeout
    while not monitor.abortRequested() and time.time() < deadline:
        if not library_scanning():
            return True
        monitor.waitForAbort(0.5)
    return not library_scanning()


def get_active_episode_snapshot() -> Dict[str, Any]:
    active = json_rpc("Player.GetActivePlayers")
    players = active.get("result") if isinstance(active.get("result"), list) else []
    playerid = None
    for row in players:
        if isinstance(row, dict) and str(row.get("type") or "").lower() == "video":
            playerid = safe_int(row.get("playerid"))
            break
    if playerid is None:
        return {}
    item_result = json_rpc("Player.GetItem", {
        "playerid": playerid,
        "properties": ["file", "showtitle", "season", "episode", "tvshowid", "uniqueid", "art"],
    })
    item = ((item_result.get("result") or {}).get("item") or {}) if isinstance(item_result, dict) else {}
    if str(item.get("type") or "").lower() != "episode":
        return {}
    episodeid = safe_int(item.get("id"))
    if episodeid is None or episodeid < 0:
        return {}
    details = get_episode_details(episodeid)
    if not details:
        details = dict(item)
        details["episodeid"] = episodeid
    details["captured_at"] = now_iso()
    details["episodeid"] = episodeid
    source = str(details.get("file") or item.get("file") or "")
    details["file"] = source
    allowed, reason = supported_source_path(source)
    if not allowed:
        log("Episode ignored: {0} ({1})".format(source, reason), xbmc.LOGDEBUG)
        return {}
    if not xbmcvfs.exists(source):
        log("Episode ignored because source does not exist: {0}".format(source), xbmc.LOGWARNING)
        return {}
    details["label"] = episode_label(details)
    return details


def get_episode_details(episodeid: int) -> Dict[str, Any]:
    result = json_rpc("VideoLibrary.GetEpisodeDetails", {
        "episodeid": int(episodeid),
        "properties": [
            "title", "showtitle", "season", "episode", "tvshowid", "file",
            "uniqueid", "art", "playcount", "lastplayed", "resume", "dateadded",
        ],
    })
    details = ((result.get("result") or {}).get("episodedetails") or {}) if isinstance(result, dict) else {}
    if isinstance(details, dict) and details:
        details["episodeid"] = int(episodeid)
        return details
    return {}


def refresh_finished_snapshot(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    latest = get_episode_details(int(snapshot.get("episodeid"))) if snapshot.get("episodeid") is not None else {}
    merged = dict(snapshot)
    if latest:
        merged.update(latest)
    playcount = safe_int(merged.get("playcount")) or 0
    merged["playcount"] = max(1, playcount)
    if not str(merged.get("lastplayed") or "").strip():
        merged["lastplayed"] = now_text()
    resume = merged.get("resume") if isinstance(merged.get("resume"), dict) else {}
    merged["resume"] = {
        "position": float(resume.get("position") or 0.0),
        "total": float(resume.get("total") or 0.0),
    }
    merged["label"] = episode_label(merged)
    return merged


def episode_label(item: Dict[str, Any]) -> str:
    show = str(item.get("showtitle") or "").strip()
    season = safe_int(item.get("season")) or 0
    episode = safe_int(item.get("episode")) or 0
    title = str(item.get("title") or "").strip()
    prefix = "{0} S{1:02d}E{2:02d}".format(show, season, episode).strip()
    return "{0} - {1}".format(prefix, title).strip(" -")


def _sqlite_rows(path: str, table: str, key_column: str, key_value: str) -> List[Dict[str, Any]]:
    if not os.path.exists(path):
        return []
    conn = None
    try:
        conn = sqlite3.connect(path, timeout=10)
        conn.row_factory = sqlite3.Row
        exists = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
        if not exists:
            return []
        rows = conn.execute("SELECT * FROM {0} WHERE {1}=?".format(table, key_column), (key_value,)).fetchall()
        return [dict(row) for row in rows]
    except Exception as exc:
        log("Read {0}:{1} failed: {2}".format(path, table, exc), xbmc.LOGWARNING)
        return []
    finally:
        if conn is not None:
            conn.close()


def _json_dict(value: Any) -> Dict[str, str]:
    if isinstance(value, dict):
        source = value
    else:
        try:
            source = json.loads(str(value or "{}"))
        except Exception:
            source = {}
    output: Dict[str, str] = {}
    for key, raw in (source or {}).items():
        text = str(raw or "").strip().lower()
        if text:
            output[str(key).strip().lower()] = text
    return output


def lac_identity_ok(row: Dict[str, Any], snapshot: Dict[str, Any]) -> bool:
    if not row:
        return False
    title = str(row.get("title") or "")
    match = re.match(r"^(.*?)\s*-\s*S(\d+)E(\d+)\s*$", title, re.I)
    if match:
        if norm_text(match.group(1)) and norm_text(snapshot.get("showtitle")) and norm_text(match.group(1)) != norm_text(snapshot.get("showtitle")):
            return False
        if safe_int(match.group(2)) != safe_int(snapshot.get("season")):
            return False
        if safe_int(match.group(3)) != safe_int(snapshot.get("episode")):
            return False
    stored_ids = _json_dict(row.get("uniqueids"))
    current_ids = _json_dict(snapshot.get("uniqueid"))
    strong = False
    for provider in set(stored_ids).intersection(current_ids):
        if stored_ids.get(provider) and current_ids.get(provider):
            if stored_ids[provider] != current_ids[provider]:
                return False
            strong = True
    if strong:
        return True
    if match:
        return True
    stored_file = norm_path(row.get("file"))
    current_file = norm_path(snapshot.get("file"))
    return bool(stored_file and current_file and stored_file == current_file)


def snapshot_lac(episodeid: int, episode_snapshot: Dict[str, Any]) -> Dict[str, Any]:
    key = "episode:{0}".format(int(episodeid))
    library_items = _sqlite_rows(LAC_DB, "library_items", "item_key", key)
    valid = bool(library_items and lac_identity_ok(library_items[0], episode_snapshot))
    return {
        "key": key,
        "valid": valid,
        "library_items": library_items if valid else [],
        "artwork": _sqlite_rows(LAC_DB, "artwork", "item_key", key) if valid else [],
    }


def snapshot_lrs(episodeid: int) -> Dict[str, Any]:
    key = "episode|{0}".format(int(episodeid))
    return {
        "key": key,
        "ratings": _sqlite_rows(LRS_DB, "ratings", "item_key", key),
        "external_ratings": _sqlite_rows(LRS_DB, "external_ratings", "item_key", key),
    }


def cache_identity_ok(row: Dict[str, Any], snapshot: Dict[str, Any]) -> bool:
    if not row:
        return False
    row_media = str(row.get("media_type") or row.get("type") or "episode").lower()
    if row_media and row_media != "episode":
        return False
    row_season = safe_int(row.get("season"))
    row_episode = safe_int(row.get("episode"))
    current_season = safe_int(snapshot.get("season"))
    current_episode = safe_int(snapshot.get("episode"))
    if row_season is not None and current_season is not None and row_season != current_season:
        return False
    if row_episode is not None and current_episode is not None and row_episode != current_episode:
        return False
    row_show = norm_text(row.get("showtitle"))
    current_show = norm_text(snapshot.get("showtitle"))
    if row_show and current_show and row_show != current_show:
        return False
    uniqueids = snapshot.get("uniqueid") if isinstance(snapshot.get("uniqueid"), dict) else {}
    comparisons = (
        (row.get("imdb_id"), uniqueids.get("imdb")),
        (row.get("tmdb_id"), uniqueids.get("tmdb")),
    )
    for left, right in comparisons:
        if str(left or "").strip() and str(right or "").strip() and str(left).strip().lower() != str(right).strip().lower():
            return False
    return bool((row_show and current_show) or (row_season is not None and row_episode is not None))


def table_columns(conn: sqlite3.Connection, table: str) -> List[str]:
    return [str(row[1]) for row in conn.execute("PRAGMA table_info({0})".format(table)).fetchall()]


def insert_dynamic(conn: sqlite3.Connection, table: str, row: Dict[str, Any]) -> None:
    columns = table_columns(conn, table)
    selected = [column for column in columns if column in row]
    if not selected:
        return
    sql = "INSERT OR REPLACE INTO {0}({1}) VALUES({2})".format(
        table,
        ",".join(selected),
        ",".join(["?"] * len(selected)),
    )
    conn.execute(sql, tuple(row.get(column) for column in selected))


def migrate_lac(snapshot: Dict[str, Any], old_id: int, new_id: int, target_path: str) -> str:
    rows_item = list((snapshot or {}).get("library_items") or [])
    rows_art = list((snapshot or {}).get("artwork") or [])
    if not os.path.exists(LAC_DB):
        return "not installed"
    if not rows_item and not rows_art:
        return "no old row"
    old_key = "episode:{0}".format(int(old_id))
    new_key = "episode:{0}".format(int(new_id))
    conn = None
    try:
        conn = sqlite3.connect(LAC_DB, timeout=30)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("BEGIN IMMEDIATE")
        if old_key != new_key:
            conn.execute("DELETE FROM artwork WHERE item_key=?", (new_key,))
            conn.execute("DELETE FROM library_items WHERE item_key=?", (new_key,))
        for row in rows_item:
            updated = dict(row)
            updated["item_key"] = new_key
            if "file" in updated:
                updated["file"] = target_path
            if "last_seen_at" in updated:
                updated["last_seen_at"] = int(time.time())
            if "updated_at" in updated:
                updated["updated_at"] = int(time.time())
            insert_dynamic(conn, "library_items", updated)
        for row in rows_art:
            updated = dict(row)
            updated["item_key"] = new_key
            insert_dynamic(conn, "artwork", updated)
        if old_key != new_key:
            conn.execute("DELETE FROM artwork WHERE item_key=?", (old_key,))
            conn.execute("DELETE FROM library_items WHERE item_key=?", (old_key,))
        try:
            conn.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)", (
                "last_episode_strm_rebind",
                "{0}|{1}|{2}".format(int(time.time()), old_key, new_key),
            ))
        except sqlite3.Error:
            pass
        conn.commit()
        return "kept" if old_key == new_key else "moved {0} -> {1}".format(old_key, new_key)
    except Exception as exc:
        if conn is not None:
            try:
                conn.rollback()
            except Exception:
                pass
        log("LAC migration failed: {0}".format(exc), xbmc.LOGWARNING)
        return "error: {0}".format(exc)
    finally:
        if conn is not None:
            conn.close()


def migrate_lrs(snapshot_rows: Dict[str, Any], episode_snapshot: Dict[str, Any], old_id: int, new_id: int) -> str:
    if not os.path.exists(LRS_DB):
        return "not installed"
    old_key = "episode|{0}".format(int(old_id))
    new_key = "episode|{0}".format(int(new_id))
    any_rows = False
    conn = None
    try:
        conn = sqlite3.connect(LRS_DB, timeout=30)
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("BEGIN IMMEDIATE")
        for table in ("ratings", "external_ratings"):
            rows = list((snapshot_rows or {}).get(table) or [])
            if not rows:
                continue
            exists = conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?", (table,)).fetchone()
            if not exists:
                continue
            valid_rows = [row for row in rows if cache_identity_ok(row, episode_snapshot)]
            if not valid_rows:
                continue
            any_rows = True
            if old_key != new_key:
                conn.execute("DELETE FROM {0} WHERE item_key=?".format(table), (new_key,))
            for row in valid_rows:
                updated = dict(row)
                updated["item_key"] = new_key
                if "dbid" in updated:
                    updated["dbid"] = int(new_id)
                insert_dynamic(conn, table, updated)
            if old_key != new_key:
                conn.execute("DELETE FROM {0} WHERE item_key=?".format(table), (old_key,))
        if any_rows:
            try:
                conn.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)", (
                    "last_episode_strm_rebind",
                    "{0}|{1}|{2}".format(now_iso(), old_key, new_key),
                ))
            except sqlite3.Error:
                pass
        conn.commit()
        if any_rows:
            try:
                conn.execute("PRAGMA wal_checkpoint(PASSIVE)")
            except sqlite3.Error:
                pass
            try:
                os.utime(LRS_DB, None)
            except Exception:
                pass
        if not any_rows:
            return "no matching old row"
        return "kept" if old_key == new_key else "moved {0} -> {1}".format(old_key, new_key)
    except Exception as exc:
        if conn is not None:
            try:
                conn.rollback()
            except Exception:
                pass
        log("LRS migration failed: {0}".format(exc), xbmc.LOGWARNING)
        return "error: {0}".format(exc)
    finally:
        if conn is not None:
            conn.close()


def restorable_kodi_art(kodi_art: Dict[str, Any], target_path: str) -> Dict[str, str]:
    art: Dict[str, str] = {}
    target_is_strm = str(target_path or '').strip().lower().endswith('.strm')
    for key, value in (kodi_art or {}).items():
        art_type = str(key or '').strip()
        url = str(value or '').strip()
        if not art_type or not url:
            continue
        lower_url = url.lower()
        if target_is_strm and lower_url.startswith('image://video@'):
            continue
        art[art_type] = url
    return art


def observe_lac_state(old_snapshot: Dict[str, Any], new_id: int, timeout: float = 8.0) -> str:
    if not os.path.exists(LAC_DB):
        return 'not installed'
    had_old = bool(list((old_snapshot or {}).get('library_items') or []) or list((old_snapshot or {}).get('artwork') or []))
    if not had_old:
        return 'no old row'
    new_key = 'episode:{0}'.format(int(new_id))
    deadline = time.time() + timeout
    while time.time() < deadline:
        if _sqlite_rows(LAC_DB, 'library_items', 'item_key', new_key) or _sqlite_rows(LAC_DB, 'artwork', 'item_key', new_key):
            return 'addon-managed'
        time.sleep(0.5)
    return 'pending'


def observe_lrs_state(old_snapshot: Dict[str, Any], new_id: int, timeout: float = 8.0) -> str:
    if not os.path.exists(LRS_DB):
        return 'not installed'
    had_old = bool(list((old_snapshot or {}).get('ratings') or []) or list((old_snapshot or {}).get('external_ratings') or []))
    if not had_old:
        return 'no old row'
    new_key = 'episode|{0}'.format(int(new_id))
    deadline = time.time() + timeout
    while time.time() < deadline:
        if _sqlite_rows(LRS_DB, 'ratings', 'item_key', new_key) or _sqlite_rows(LRS_DB, 'external_ratings', 'item_key', new_key):
            return 'addon-managed'
        time.sleep(0.5)
    return 'pending'


def set_episode_details(new_id: int, snapshot: Dict[str, Any], art: Dict[str, str]) -> bool:
    base: Dict[str, Any] = {
        "episodeid": int(new_id),
        "playcount": max(1, safe_int(snapshot.get("playcount")) or 0),
        "lastplayed": str(snapshot.get("lastplayed") or now_text()),
        "resume": snapshot.get("resume") if isinstance(snapshot.get("resume"), dict) else {"position": 0.0, "total": 0.0},
    }
    if art:
        base["art"] = art
    uniqueids = snapshot.get("uniqueid") if isinstance(snapshot.get("uniqueid"), dict) else {}
    if uniqueids:
        base["uniqueid"] = uniqueids
    if str(snapshot.get("dateadded") or "").strip():
        base["dateadded"] = str(snapshot.get("dateadded"))

    attempts = [
        base,
        {key: value for key, value in base.items() if key not in ("dateadded",)},
        {key: value for key, value in base.items() if key not in ("dateadded", "uniqueid")},
        {key: value for key, value in base.items() if key in ("episodeid", "playcount", "lastplayed", "resume", "art")},
    ]
    seen = set()
    for payload in attempts:
        marker = json.dumps(payload, sort_keys=True, ensure_ascii=False)
        if marker in seen:
            continue
        seen.add(marker)
        result = json_rpc("VideoLibrary.SetEpisodeDetails", payload)
        if rpc_ok(result):
            return True
        log("SetEpisodeDetails retry after error: {0}".format((result.get("error") or {}).get("message") or result), xbmc.LOGWARNING)
    return False


def find_episode_by_path(snapshot: Dict[str, Any], wanted_path: str) -> Dict[str, Any]:
    params: Dict[str, Any] = {
        "properties": ["file", "showtitle", "season", "episode", "tvshowid", "uniqueid", "art"],
        "sort": {"method": "episode", "order": "ascending"},
    }
    tvshowid = safe_int(snapshot.get("tvshowid"))
    season = safe_int(snapshot.get("season"))
    if tvshowid is not None and tvshowid >= 0:
        params["tvshowid"] = tvshowid
    if season is not None:
        params["season"] = season
    result = json_rpc("VideoLibrary.GetEpisodes", params)
    rows = ((result.get("result") or {}).get("episodes") or []) if isinstance(result, dict) else []
    exact = []
    fallback = []
    for row in rows:
        if not isinstance(row, dict):
            continue
        if norm_path(row.get("file")) == norm_path(wanted_path):
            exact.append(row)
            continue
        if (
            safe_int(row.get("season")) == safe_int(snapshot.get("season"))
            and safe_int(row.get("episode")) == safe_int(snapshot.get("episode"))
            and (not norm_text(snapshot.get("showtitle")) or norm_text(row.get("showtitle")) == norm_text(snapshot.get("showtitle")))
        ):
            fallback.append(row)
    candidates = exact or (fallback if len(fallback) == 1 else [])
    if not candidates:
        return {}
    row = dict(candidates[0])
    row["episodeid"] = safe_int(row.get("episodeid"))
    return row


def wait_for_episode(monitor: xbmc.Monitor, snapshot: Dict[str, Any], path: str, timeout: float) -> Dict[str, Any]:
    deadline = time.time() + timeout
    while not monitor.abortRequested() and time.time() < deadline:
        found = find_episode_by_path(snapshot, path)
        if found and safe_int(found.get("episodeid")) is not None:
            return found
        monitor.waitForAbort(0.75)
    return {}


def scan_directory(directory: str) -> bool:
    result = json_rpc("VideoLibrary.Scan", {
        "directory": directory,
        "showdialogs": False,
    })
    return rpc_ok(result)


def remove_episode(episodeid: int) -> bool:
    return rpc_ok(json_rpc("VideoLibrary.RemoveEpisode", {"episodeid": int(episodeid)}))


def read_lock() -> Dict[str, Any]:
    return read_json(SHARED_LOCK_FILE)


def lock_is_stale() -> bool:
    try:
        return (time.time() - os.path.getmtime(SHARED_LOCK_FILE)) > SHARED_LOCK_STALE_SECONDS
    except Exception:
        return True


def acquire_shared_lock(monitor: xbmc.Monitor, timeout: float = 120.0) -> bool:
    deadline = time.time() + timeout
    while not monitor.abortRequested() and time.time() < deadline:
        try:
            if os.path.exists(SHARED_LOCK_FILE):
                lock = read_lock()
                owner = str(lock.get("addon") or "")
                if owner == ADDON_ID:
                    return True
                if lock_is_stale():
                    try:
                        os.remove(SHARED_LOCK_FILE)
                    except Exception:
                        monitor.waitForAbort(1.0)
                        continue
                else:
                    monitor.waitForAbort(1.0)
                    continue
            payload = {
                "addon": ADDON_ID,
                "title": ADDON_NAME,
                "created_at": now_iso(),
                "pid": os.getpid(),
            }
            temp = SHARED_LOCK_FILE + "." + ADDON_ID + ".tmp"
            write_json(temp, payload)
            os.replace(temp, SHARED_LOCK_FILE)
            lock = read_lock()
            if str(lock.get("addon") or "") == ADDON_ID:
                return True
        except Exception as exc:
            log("Shared lock acquire failed: {0}".format(exc), xbmc.LOGWARNING)
        monitor.waitForAbort(1.0)
    return False


def release_shared_lock() -> None:
    try:
        lock = read_lock()
        if not lock or str(lock.get("addon") or "") == ADDON_ID:
            delete_file_quiet(SHARED_LOCK_FILE)
    except Exception:
        pass


def clear_own_stale_lock() -> None:
    try:
        lock = read_lock()
        if str(lock.get("addon") or "") == ADDON_ID:
            delete_file_quiet(SHARED_LOCK_FILE)
    except Exception:
        pass


def save_report(payload: Dict[str, Any]) -> None:
    report = dict(payload)
    report["finished_at"] = now_iso()
    try:
        write_json(REPORT_FILE, report)
    except Exception as exc:
        log("Report write failed: {0}".format(exc), xbmc.LOGWARNING)


def update_pending(job: Dict[str, Any], stage: str, **values: Any) -> Dict[str, Any]:
    job = dict(job)
    job["stage"] = stage
    job["updated_at"] = now_iso()
    job.update(values)
    write_json(PENDING_FILE, job)
    return job


def finalize_library_item(
    monitor: xbmc.Monitor,
    job: Dict[str, Any],
    final_path: str,
    old_id: int,
    source_kind: str = "target",
) -> Tuple[bool, Dict[str, Any]]:
    snapshot = dict(job.get("episode") or {})
    found = wait_for_episode(monitor, snapshot, final_path, FIND_EPISODE_TIMEOUT)
    if not found:
        directory = str(job.get("directory") or path_parts(final_path)[0])
        scan_directory(directory)
        found = wait_for_episode(monitor, snapshot, final_path, 30.0)
    if not found:
        return False, {"message": "episode did not return to Kodi library", "source_kind": source_kind}

    new_id = safe_int(found.get("episodeid"))
    if new_id is None:
        return False, {"message": "new episode DBID is missing", "source_kind": source_kind}

    art = restorable_kodi_art(snapshot.get("art") if isinstance(snapshot.get("art"), dict) else {}, final_path)
    restored = set_episode_details(new_id, snapshot, art)
    lac_state = observe_lac_state(job.get("lac") or {}, new_id)
    lrs_state = observe_lrs_state(job.get("lrs") or {}, new_id)
    xbmc.executebuiltin("Container.Refresh")
    return restored, {
        "new_episodeid": new_id,
        "lac": lac_state,
        "lrs": lrs_state,
        "artwork_count": len(art),
        "message": "restored" if restored else "episode returned, but Kodi detail restore failed",
        "source_kind": source_kind,
    }


def rollback_original(monitor: xbmc.Monitor, job: Dict[str, Any], reason: str) -> Dict[str, Any]:
    source_path = str(job.get("source_path") or "")
    directory = str(job.get("directory") or path_parts(source_path)[0])
    scan_directory(directory)
    ok, state = finalize_library_item(
        monitor,
        job,
        source_path,
        int((job.get("episode") or {}).get("episodeid")),
        source_kind="rollback-original",
    )
    state.update({
        "status": "failed",
        "reason": reason,
        "source_path": source_path,
        "target_path": job.get("target_path"),
        "old_episodeid": (job.get("episode") or {}).get("episodeid"),
        "label": (job.get("episode") or {}).get("label"),
    })
    if ok:
        state["message"] = reason + "; original file was re-added to Kodi"
    else:
        state["message"] = reason + "; automatic library rollback was incomplete"
    return state


def process_conversion(monitor: xbmc.Monitor, initial_snapshot: Dict[str, Any]) -> None:
    snapshot = refresh_finished_snapshot(initial_snapshot)
    source_path = str(snapshot.get("file") or "")
    old_id = safe_int(snapshot.get("episodeid"))
    if old_id is None:
        return
    allowed, reason = supported_source_path(source_path)
    if not allowed or not xbmcvfs.exists(source_path):
        log("Conversion canceled for {0}: {1}".format(source_path, reason or "source missing"), xbmc.LOGWARNING)
        return

    directory, target_path, temp_path = strm_paths(source_path)
    ok, reason = preflight_placeholder(target_path, temp_path)
    if not ok:
        notify("Tidak dikonversi: {0}".format(reason), True)
        save_report({
            "status": "skipped", "message": reason, "label": snapshot.get("label"),
            "source_path": source_path, "target_path": target_path, "old_episodeid": old_id,
        })
        return

    if not wait_library_idle(monitor, LIBRARY_IDLE_TIMEOUT):
        vfs_delete(temp_path)
        notify("Konversi batal: library masih scanning", True)
        save_report({
            "status": "failed", "message": "library remained busy", "label": snapshot.get("label"),
            "source_path": source_path, "target_path": target_path, "old_episodeid": old_id,
        })
        return

    if not acquire_shared_lock(monitor):
        vfs_delete(temp_path)
        notify("Konversi batal: LAC/LRS sedang bekerja", True)
        save_report({
            "status": "failed", "message": "shared auto-scan lock unavailable", "label": snapshot.get("label"),
            "source_path": source_path, "target_path": target_path, "old_episodeid": old_id,
        })
        return

    job: Dict[str, Any] = {
        "version": 1,
        "created_at": now_iso(),
        "stage": "prepared",
        "directory": directory,
        "source_path": source_path,
        "target_path": target_path,
        "temp_path": temp_path,
        "episode": snapshot,
        "lac": snapshot_lac(old_id, snapshot),
        "lrs": snapshot_lrs(old_id),
    }
    try:
        write_json(PENDING_FILE, job)
        log("Converting {0}".format(snapshot.get("label") or source_path), xbmc.LOGINFO)

        if not remove_episode(old_id):
            vfs_delete(temp_path)
            delete_file_quiet(PENDING_FILE)
            raise RuntimeError("VideoLibrary.RemoveEpisode failed")
        job = update_pending(job, "episode_removed")

        if not vfs_delete(source_path, attempts=8, delay=0.4):
            vfs_delete(temp_path)
            state = rollback_original(monitor, job, "source file could not be deleted")
            save_report(state)
            delete_file_quiet(PENDING_FILE)
            notify("Gagal hapus file. Episode dikembalikan ke library.", True, 7000)
            return
        job = update_pending(job, "source_deleted")

        if not vfs_rename(temp_path, target_path):
            # The preflight already tested this route. Retry once after a short pause.
            monitor.waitForAbort(0.5)
            if not vfs_rename(temp_path, target_path):
                job = update_pending(job, "rename_failed")
                state = {
                    "status": "failed",
                    "message": "source deleted, but temporary STRM could not be renamed; pending recovery kept",
                    "label": snapshot.get("label"),
                    "source_path": source_path,
                    "target_path": target_path,
                    "old_episodeid": old_id,
                    "lac": "pending",
                    "lrs": "pending",
                }
                save_report(state)
                notify("File video terhapus, tetapi rename STRM gagal. Recovery disimpan.", True, 9000)
                return
        job = update_pending(job, "target_ready")

        if not scan_directory(directory):
            log("VideoLibrary.Scan request returned an error for {0}".format(directory), xbmc.LOGWARNING)
        job = update_pending(job, "awaiting_library")

        restored, state = finalize_library_item(monitor, job, target_path, old_id)
        state.update({
            "status": "success" if restored else "partial",
            "label": snapshot.get("label"),
            "source_path": source_path,
            "target_path": target_path,
            "old_episodeid": old_id,
        })
        if restored:
            state["message"] = "empty STRM created and Kodi data restored"
            delete_file_quiet(PENDING_FILE)
            notify("Episode selesai: file diganti STRM kosong", False, 5000)
        else:
            state["message"] = state.get("message") or "STRM created; recovery remains pending"
            update_pending(job, "awaiting_recovery", last_error=state["message"])
            notify("STRM dibuat, tetapi pemulihan library belum lengkap", True, 7000)
        save_report(state)
    except Exception as exc:
        log("Conversion failed: {0}".format(exc), xbmc.LOGERROR)
        save_report({
            "status": "failed",
            "message": str(exc),
            "label": snapshot.get("label"),
            "source_path": source_path,
            "target_path": target_path,
            "old_episodeid": old_id,
        })
        notify("Konversi gagal: {0}".format(str(exc)[:120]), True, 7000)
    finally:
        release_shared_lock()


def recover_pending(monitor: xbmc.Monitor, pending: Dict[str, Any]) -> bool:
    if not pending:
        return True
    snapshot = pending.get("episode") if isinstance(pending.get("episode"), dict) else {}
    old_id = safe_int(snapshot.get("episodeid"))
    source_path = str(pending.get("source_path") or "")
    target_path = str(pending.get("target_path") or "")
    temp_path = str(pending.get("temp_path") or "")
    directory = str(pending.get("directory") or path_parts(target_path or source_path)[0])
    if old_id is None:
        return False

    if not acquire_shared_lock(monitor, timeout=30.0):
        return False
    try:
        # If the target is missing but the temp survived, finish the rename.
        if target_path and not xbmcvfs.exists(target_path) and temp_path and xbmcvfs.exists(temp_path):
            if not vfs_rename(temp_path, target_path):
                return False
        if target_path and xbmcvfs.exists(target_path):
            scan_directory(directory)
            restored, state = finalize_library_item(monitor, pending, target_path, old_id)
            if restored:
                state.update({
                    "status": "success",
                    "message": "pending STRM recovery completed",
                    "label": snapshot.get("label"),
                    "source_path": source_path,
                    "target_path": target_path,
                    "old_episodeid": old_id,
                })
                save_report(state)
                delete_file_quiet(PENDING_FILE)
                notify("Recovery STRM selesai", False, 5000)
                return True
            return False
        if source_path and xbmcvfs.exists(source_path):
            scan_directory(directory)
            restored, state = finalize_library_item(monitor, pending, source_path, old_id, source_kind="rollback-original")
            if restored:
                state.update({
                    "status": "failed",
                    "message": "pending operation rolled back to original source",
                    "label": snapshot.get("label"),
                    "source_path": source_path,
                    "target_path": target_path,
                    "old_episodeid": old_id,
                })
                save_report(state)
                delete_file_quiet(PENDING_FILE)
                if temp_path:
                    vfs_delete(temp_path)
                return True
        return False
    finally:
        release_shared_lock()


class EpisodePlayer(xbmc.Player):
    def __init__(self) -> None:
        super().__init__()
        self._lock = threading.Lock()
        self._capture_due = 0.0
        self._capture_attempts = 0
        self._current: Dict[str, Any] = {}
        self._ended_queue: List[Dict[str, Any]] = []

    def onAVStarted(self) -> None:  # pylint: disable=invalid-name
        with self._lock:
            self._current = {}
            self._capture_attempts = 0
            self._capture_due = time.time() + 0.15

    def onPlayBackEnded(self) -> None:  # pylint: disable=invalid-name
        with self._lock:
            if self._current:
                item = copy.deepcopy(self._current)
                item["ended_at"] = now_iso()
                item["not_before"] = time.time() + CONVERSION_DELAY_SECONDS
                self._ended_queue.append(item)
            self._current = {}
            self._capture_due = 0.0
            self._capture_attempts = 0

    def onPlayBackStopped(self) -> None:  # pylint: disable=invalid-name
        with self._lock:
            self._current = {}
            self._capture_due = 0.0
            self._capture_attempts = 0

    def onPlayBackError(self) -> None:  # pylint: disable=invalid-name
        with self._lock:
            self._current = {}
            self._capture_due = 0.0
            self._capture_attempts = 0

    def service_capture(self) -> None:
        with self._lock:
            due = self._capture_due
            attempts = self._capture_attempts
        if not due or time.time() < due:
            return
        snapshot = get_active_episode_snapshot()
        with self._lock:
            if snapshot:
                self._current = snapshot
                self._capture_due = 0.0
                self._capture_attempts = 0
                log("Captured episode: {0}".format(snapshot.get("label") or snapshot.get("file")), xbmc.LOGINFO)
                return
            attempts += 1
            self._capture_attempts = attempts
            if attempts >= 12:
                self._capture_due = 0.0
            else:
                self._capture_due = time.time() + CAPTURE_RETRY_SECONDS

    def pop_ready_ended(self) -> Dict[str, Any]:
        with self._lock:
            if not self._ended_queue:
                return {}
            first = self._ended_queue[0]
            if time.time() < float(first.get("not_before") or 0):
                return {}
            return self._ended_queue.pop(0)


def main() -> None:
    _ensure_profile()
    clear_own_stale_lock()
    monitor = xbmc.Monitor()
    player = EpisodePlayer()
    pending_retry_at = 0.0
    log("Service started", xbmc.LOGINFO)

    while not monitor.abortRequested():
        try:
            player.service_capture()
            pending = read_json(PENDING_FILE)
            if pending and time.time() >= pending_retry_at and not player.isPlayingVideo():
                pending_retry_at = time.time() + RECOVERY_RETRY_SECONDS
                if recover_pending(monitor, pending):
                    pending_retry_at = 0.0
            elif not pending:
                ended = player.pop_ready_ended()
                if ended:
                    process_conversion(monitor, ended)
        except Exception as exc:
            log("Service loop error: {0}".format(exc), xbmc.LOGERROR)
        monitor.waitForAbort(0.25)

    release_shared_lock()
    log("Service stopped", xbmc.LOGINFO)


if __name__ == "__main__":
    main()

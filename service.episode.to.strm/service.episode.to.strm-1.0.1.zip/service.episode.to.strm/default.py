# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os

import xbmcaddon
import xbmcgui
import xbmcvfs

ADDON = xbmcaddon.Addon()
PROFILE = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
REPORT_FILE = os.path.join(PROFILE, "last-conversion.json")
PENDING_FILE = os.path.join(PROFILE, "pending-conversion.json")


def _load(path):
    try:
        with open(path, "r", encoding="utf-8") as handle:
            value = json.load(handle)
        return value if isinstance(value, dict) else {}
    except Exception:
        return {}


def main():
    report = _load(REPORT_FILE)
    pending = _load(PENDING_FILE)
    rows = [
        "SERVICE AKTIF",
        "",
        "Episode lokal yang selesai normal akan diganti dengan file .strm kosong.",
        "Playback stop, error, stream internet, plugin, PVR, stack, disc folder, dan .strm tidak diproses.",
        "Kodi Clean Library tidak dijalankan.",
        "Migrasi artwork/rating ditangani oleh LAC/LRS masing-masing.",
        "",
    ]
    if pending:
        rows.extend([
            "PENDING RECOVERY",
            "Stage: {0}".format(pending.get("stage") or "unknown"),
            "File: {0}".format(pending.get("target_path") or pending.get("source_path") or "-"),
            "",
        ])
    if report:
        rows.extend([
            "LAST RESULT",
            "Status: {0}".format(report.get("status") or "-"),
            "Episode: {0}".format(report.get("label") or "-"),
            "Source: {0}".format(report.get("source_path") or "-"),
            "STRM: {0}".format(report.get("target_path") or "-"),
            "Old DBID: {0}".format(report.get("old_episodeid") if report.get("old_episodeid") is not None else "-"),
            "New DBID: {0}".format(report.get("new_episodeid") if report.get("new_episodeid") is not None else "-"),
            "LAC handoff: {0}".format(report.get("lac") or "-"),
            "LRS handoff: {0}".format(report.get("lrs") or "-"),
            "Message: {0}".format(report.get("message") or "-"),
            "Finished: {0}".format(report.get("finished_at") or "-"),
        ])
    else:
        rows.append("Belum ada episode yang dikonversi.")
    xbmcgui.Dialog().textviewer(ADDON.getAddonInfo("name"), "\n".join(rows))


if __name__ == "__main__":
    main()

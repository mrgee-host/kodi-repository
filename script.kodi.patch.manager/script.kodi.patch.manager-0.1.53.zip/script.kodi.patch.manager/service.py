# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import random
import os
import re
import sqlite3
import time
import traceback
from urllib.parse import unquote

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # pragma: no cover outside Kodi
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

ADDON_ID = 'script.kodi.patch.manager'
ADDON_NAME = 'Kodi Patch Manager'
ACTIVE_PROP = 'KPM.Service.Active.v0144'
ARMED_PROP = 'KPM.ResumeCloseService.Armed'
ARMED_DIALOG_PROP = 'KPM.ResumeCloseService.ArmedDialogId'
PAUSE_SINCE_PROP = 'KPM.ResumeCloseService.PauseSince'
LAST_FOREIGN_DIALOG_PROP = 'KPM.ResumeCloseService.LastForeignDialogId'
LOG_PREFIX = '[Kodi Patch Manager Service v0.1.53] '

NO_DIALOG_ID = 9999
KNOWN_OSD_DIALOG_IDS = {9999, 12901, 10142}
AUTO_OPEN_GRACE_SECONDS = 0.0
STARTUP_AUTO_DIALOG_GUARD_SECONDS = 0.85
STARTUP_GUARD_WINDOW_SECONDS = 3.0
STUDIO_RESOURCE_ID = 'resource.images.studios.coloured'
STUDIO_PROP_PREFIX = 'KPM.StudioLogo.'
STUDIO_NAME_PROP_PREFIX = 'KPM.StudioLogoName.'
STUDIO_COUNT_PROP = 'KPM.StudioLogos.Count'
STUDIO_AVAILABLE_PROP = 'KPM.StudioLogos.Available'
STUDIO_STATUS_PROP = 'KPM.StudioLogos.Status'
STUDIO_CANDIDATES_PROP = 'KPM.StudioLogos.Candidates'
STUDIO_RESOLVED_PROP = 'KPM.StudioLogos.Resolved'
STUDIO_MISSING_PROP = 'KPM.StudioLogos.Missing'
STUDIO_UPDATED_AT_PROP = 'KPM.StudioLogos.UpdatedAt'
STUDIO_SHOW_PROP = 'KPM.StudioLogos.Show'
STUDIO_CONTEXT_PROP = 'KPM.StudioLogos.Context'
STUDIO_CACHE_PROP = 'KPM.StudioLogos.Cache'
STUDIO_INDEX_BUILD_MS_PROP = 'KPM.StudioLogos.IndexBuildMs'
STUDIO_RESOLVE_LAST_MS_PROP = 'KPM.StudioLogos.ResolveLastMs'
STUDIO_RESOLVE_MAX_MS_PROP = 'KPM.StudioLogos.ResolveMaxMs'
STUDIO_RESOLVE_COUNT_PROP = 'KPM.StudioLogos.ResolveCount'
STUDIO_BROKEN_SKIPPED_PROP = 'KPM.StudioLogos.BrokenSkipped'
STUDIO_DEBUG_PROP = 'KPM.StudioLogos.Debug'
STUDIO_SOURCE_PROP = 'KPM.StudioLogos.Source'
STUDIO_EPISODE_PARENT_SHOW_ID_PROP = 'KPM.StudioLogos.EpisodeParentShowId'
STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP = 'KPM.StudioLogos.EpisodeParentShowTitle'
STUDIO_DB_LOOKUP_LAST_MS_PROP = 'KPM.StudioLogos.DBLookupLastMs'
STUDIO_DB_LOOKUP_COUNT_PROP = 'KPM.StudioLogos.DBLookupCount'
STUDIO_LAST_MEDIA_LABEL_PROP = 'KPM.StudioLogos.LastMediaLabel'
STUDIO_LAST_MEDIA_DBID_PROP = 'KPM.StudioLogos.LastMediaDBID'
STUDIO_LAST_MEDIA_DBTYPE_PROP = 'KPM.StudioLogos.LastMediaDBTYPE'
STUDIO_LAST_MEDIA_CANDIDATES_PROP = 'KPM.StudioLogos.LastMediaCandidates'
STUDIO_LAST_MEDIA_RESOLVED_PROP = 'KPM.StudioLogos.LastMediaResolved'
STUDIO_LAST_MEDIA_SOURCE_PROP = 'KPM.StudioLogos.LastMediaSource'
STUDIO_LAST_MEDIA_UPDATED_AT_PROP = 'KPM.StudioLogos.LastMediaUpdatedAt'
STUDIO_RESOLVE_INTERVAL_SECONDS = 0.15
STUDIO_EMPTY_CLEAR_SECONDS = 999999.0
BROKEN_STUDIO_TEXTURE_NAMES = {
    'centropolis entertainment.png',
    'dune entertainment.png',
    'gk films.png',
    'thunder road.png',
}

FANART_PATCH_ID = 'tmdb_focus_random_v11'
FANART_DISPLAY_PROP = 'KPM.Fanart.Display'
FANART_LAUNCH_PROP = 'KPM.Fanart.Launch'
FANART_LAUNCH_SOURCE_PROP = 'KPM.Fanart.LaunchSource'
FANART_LAUNCH_UPDATED_AT_PROP = 'KPM.Fanart.LaunchUpdatedAt'
FANART_LAUNCH_DB_PATH_PROP = 'KPM.Fanart.LaunchDBPath'
FANART_LAUNCH_CANDIDATES_COUNT_PROP = 'KPM.Fanart.LaunchCandidatesCount'
FANART_LAUNCH_REASON_PROP = 'KPM.Fanart.LaunchReason'
FANART_SHOW_PROP = 'KPM.Fanart.Show'
FANART_READY_PROP = 'KPM.Fanart.Ready'
FANART_SOURCE_IMAGE_PROP = 'KPM.Fanart.SourceImage'
FANART_SELECTED_PROP = 'KPM.Fanart.Selected'
FANART_LAST_FOR_ITEM_PROP = 'KPM.Fanart.LastForItem'
FANART_ITEM_KEY_PROP = 'KPM.Fanart.ItemKey'
FANART_VISIT_ID_PROP = 'KPM.Fanart.VisitId'
FANART_SOURCE_PROP = 'KPM.Fanart.Source'
FANART_CACHE_RESULT_PROP = 'KPM.Fanart.CacheResult'
FANART_REASON_PROP = 'KPM.Fanart.Reason'
FANART_CANDIDATES_PROP = 'KPM.Fanart.Candidates'
FANART_CANDIDATES_COUNT_PROP = 'KPM.Fanart.CandidatesCount'
FANART_UPDATED_AT_PROP = 'KPM.Fanart.UpdatedAt'
FANART_DB_PATH_PROP = 'KPM.Fanart.DBPath'
FANART_LOOKUP_MS_PROP = 'KPM.Fanart.LookupMs'
FANART_PARENT_ITEM_KEY_PROP = 'KPM.Fanart.ParentItemKey'
FANART_SELECTED_INDEX_PROP = 'KPM.Fanart.SelectedIndex'
FANART_DBTYPE_PROP = 'KPM.Fanart.DBTYPE'
FANART_DBID_PROP = 'KPM.Fanart.DBID'
FANART_FOCUS_LABEL_PROP = 'KPM.Fanart.FocusItem'
FANART_ENGINE_STATUS_PROP = 'KPM.Fanart.EngineStatus'
FANART_DISPLAY_ITEM_KEY_PROP = 'KPM.Fanart.DisplayItemKey'
FANART_CURRENT_FOCUS_KEY_PROP = 'KPM.Fanart.CurrentFocusKey'
FANART_MISMATCH_PROP = 'KPM.Fanart.Mismatch'
FANART_LAUNCH_ACTIVE_PROP = 'KPM.Fanart.LaunchActive'
FANART_PENDING_PROP = 'KPM.Fanart.Pending'
FANART_ACTIVE_CONTAINER_PROP = 'KPM.Active.ContainerID'
FANART_ACTIVE_CONTAINER_SOURCE_PROP = 'KPM.Active.ContainerSource'
FANART_ACTIVE_CONTAINER_ITEM_PROP = 'KPM.Active.ContainerItem'
FANART_FOCUS_CONTAINER_PROP = 'KPM.Focus.Container'
FANART_FOCUS_PREFIX_PROP = 'KPM.Focus.Prefix'
FANART_FOCUS_DBID_PROP = 'KPM.Focus.DBID'
FANART_FOCUS_DBTYPE_PROP = 'KPM.Focus.DBTYPE'
FANART_FOCUS_LABEL_PROP2 = 'KPM.Focus.Label'
FANART_MEDIA_WINDOW_IDS = {10000, 10024, 10025, 1101, 1102, 1103, 1104, 1105, 1106, 1107, 1108, 1140, 1141, 1193}
FANART_RESOLVE_INTERVAL_SECONDS = 0.02
FANART_ART_TYPES = ('fanart', 'fanart1', 'fanart2', 'fanart3', 'fanart4', 'fanart5', 'fanart6', 'fanart7', 'fanart8', 'fanart9', 'fanart10')



def translate(path: str) -> str:
    if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if xbmc and hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return path


def log(message: str, level=None) -> None:
    if xbmc:
        xbmc.log(LOG_PREFIX + message, level or xbmc.LOGINFO)
    else:
        print(LOG_PREFIX + message)


def cond(expression: str) -> bool:
    try:
        return bool(xbmc.getCondVisibility(expression)) if xbmc else False
    except Exception:
        return False


def info(label: str) -> str:
    try:
        return xbmc.getInfoLabel(label).strip() if xbmc else ''
    except Exception:
        return ''


def home_prop(name: str) -> str:
    try:
        return xbmcgui.Window(10000).getProperty(name) if xbmcgui else ''
    except Exception:
        return ''


def window_prop(window_id: int, name: str) -> str:
    try:
        return xbmcgui.Window(window_id).getProperty(name).strip() if xbmcgui else ''
    except Exception:
        return ''


def any_window_prop(*names: str) -> str:
    # AF3/LRS may write bridge properties to Home, current window, or the hub window.
    # Check all common AF3 windows so KPM can reuse the proven LRS bridge instead
    # of depending on a focused button's ListItem.* labels.
    window_ids = []
    for wid in (10000, current_window_id(), 1101, 1102, 1103, 1104):
        if isinstance(wid, int) and wid > 0 and wid not in window_ids:
            window_ids.append(wid)
    for wid in window_ids:
        for name in names:
            value = window_prop(wid, name)
            if value:
                return value
    return ''


def set_home_prop(name: str, value: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).setProperty(name, value)
    except Exception:
        pass


def clear_home_prop(name: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).clearProperty(name)
    except Exception:
        pass


def set_current_window_prop(name: str, value: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(current_window_id()).setProperty(name, value)
    except Exception:
        pass


def clear_current_window_prop(name: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(current_window_id()).clearProperty(name)
    except Exception:
        pass


def current_window_id() -> int:
    try:
        return int(xbmcgui.getCurrentWindowId()) if xbmcgui else -1
    except Exception:
        return -1


def current_dialog_id() -> int:
    try:
        return int(xbmcgui.getCurrentWindowDialogId()) if xbmcgui else NO_DIALOG_ID
    except Exception:
        return NO_DIALOG_ID


def addon_data_path(*parts: str) -> str:
    base = translate(f'special://profile/addon_data/{ADDON_ID}')
    return os.path.join(base, *parts)


def state_file(patch_id: str) -> str:
    return addon_data_path('state', f'{patch_id}.json')


def load_json_file(path: str) -> dict:
    with open(path, 'r', encoding='utf-8', errors='replace') as handle:
        return json.load(handle)


def patch_state_enabled(patch_id: str) -> bool:
    return os.path.exists(state_file(patch_id))


def pause_patch_enabled() -> bool:
    path = state_file('vfs_pause_ratings')
    if not os.path.exists(path):
        return False
    try:
        data = load_json_file(path)
        return bool(data.get('auto_videoosd') and data.get('pause_stay_until_resume'))
    except Exception:
        return True


def studio_patch_enabled() -> bool:
    return patch_state_enabled('reliable_studio_logos')


def load_kpm_settings() -> dict:
    data = {'studio_logo_count': 1, 'studio_debug': False}
    path = addon_data_path('settings.json')
    if os.path.exists(path):
        try:
            loaded = load_json_file(path)
            if isinstance(loaded, dict):
                data.update(loaded)
        except Exception:
            pass
    try:
        count = int(data.get('studio_logo_count', 1))
    except Exception:
        count = 1
    data['studio_logo_count'] = 1
    return data


def is_foreign_dialog(active_dialog_id: int) -> bool:
    return active_dialog_id not in KNOWN_OSD_DIALOG_IDS


def close_video_osd_safely() -> None:
    try:
        xbmc.executebuiltin('CancelAlarm(osd_timeout,true)')
        xbmc.executebuiltin('Dialog.Close(videoosd,true)')
        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
    except Exception:
        log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def _read_xbt_filenames(path: str) -> list[str]:
    try:
        with open(path, 'rb') as handle:
            data = handle.read()
    except Exception:
        return []
    names = []
    # Kodi XBTF2 texture packs used by the studio resources have a 5-byte magic,
    # a 4-byte little-endian file count, then 304-byte file records with a
    # null-terminated 256-byte filename at the start of each record.
    if data.startswith(b'XBTF2') and len(data) >= 9:
        try:
            count = int.from_bytes(data[5:9], 'little')
            step = 304
            start = 9
            for idx in range(count):
                off = start + idx * step
                raw = data[off:off + 256]
                if not raw:
                    break
                name = raw.split(b'\x00', 1)[0].decode('utf-8', 'ignore').strip()
                if name.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                    names.append(name.replace('\\', '/'))
            if names:
                return names
        except Exception:
            pass
    # Conservative fallback: scan the header/table for image-looking strings.
    for match in re.finditer(rb'([A-Za-z0-9][A-Za-z0-9 _.,&+!\'()\-]{1,180}\.(?:png|jpg|jpeg|webp))\x00', data[:4_000_000], re.I):
        try:
            names.append(match.group(1).decode('utf-8', 'ignore').strip().replace('\\', '/'))
        except Exception:
            pass
    return list(dict.fromkeys(names))


def _walk_resource_images(resource_dir: str) -> list[str]:
    found = []
    for root, _dirs, files in os.walk(resource_dir):
        for filename in files:
            if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                rel = os.path.relpath(os.path.join(root, filename), resource_dir).replace('\\', '/')
                found.append(rel)
    return found


def _strip_ext(name: str) -> str:
    base = os.path.basename(name.replace('\\', '/'))
    return re.sub(r'\.(png|jpg|jpeg|webp)$', '', base, flags=re.I).strip()


def _simple_key(value: str) -> str:
    value = unquote(value or '').lower().strip()
    value = value.replace('&', ' and ').replace('+', ' plus ')
    value = re.sub(r'\([^)]*\)', ' ', value)
    value = re.sub(r'[^a-z0-9]+', ' ', value)
    value = re.sub(r'\s+', ' ', value).strip()
    return value


def _drop_company_suffixes(key: str) -> str:
    suffixes = {
        'ltd', 'limited', 'inc', 'llc', 'gmbh', 'ag', 's a', 'sa', 's r l', 'srl',
        'co', 'company', 'corp', 'corporation', 'productions', 'production',
        'pictures', 'picture', 'films', 'film', 'studios', 'studio', 'entertainment'
    }
    parts = key.split()
    while parts and ' '.join(parts[-3:]) in suffixes:
        parts = parts[:-3]
    while parts and ' '.join(parts[-2:]) in suffixes:
        parts = parts[:-2]
    while parts and parts[-1] in suffixes:
        parts = parts[:-1]
    return ' '.join(parts).strip()


def _logo_keys(name: str) -> list[str]:
    raw = _strip_ext(name)
    raw = unquote(raw).strip()
    variants = [raw]
    variants.append(re.sub(r'\s*\([^)]*\)\s*$', '', raw).strip())
    variants.append(raw.replace(' Ltd.', '').replace(' Ltd', '').replace(' Inc.', '').replace(' Inc', '').replace(' LLC', '').strip())
    keys = []
    for variant in variants:
        key = _simple_key(variant)
        if key:
            keys.append(key)
            short = _drop_company_suffixes(key)
            if short and short != key:
                keys.append(short)
    alias_map = {
        'prime video': 'amazon prime video',
        'amazon video': 'amazon prime video',
        'fox searchlight': 'fox searchlight pictures',
        'searchlight': 'searchlight pictures',
        'lucasfilm ltd': 'lucasfilm',
    }
    for key in list(keys):
        alias = alias_map.get(key)
        if alias:
            keys.append(alias)
    return list(dict.fromkeys(keys))



def _studio_index_cache_path() -> str:
    return addon_data_path('cache', 'studio-logo-index-coloured-v2.json')


def _file_signature(path: str) -> dict:
    try:
        return {
            'path': path,
            'size': int(os.path.getsize(path)),
            'mtime': float(os.path.getmtime(path)),
        }
    except Exception:
        return {'path': path, 'size': -1, 'mtime': -1.0}


def _load_cached_studio_index(texture_path: str) -> dict[str, str]:
    cache_path = _studio_index_cache_path()
    if not os.path.exists(cache_path):
        return {}
    try:
        data = load_json_file(cache_path)
        if not isinstance(data, dict):
            return {}
        if data.get('resource_id') != STUDIO_RESOURCE_ID:
            return {}
        if data.get('texture_signature') != _file_signature(texture_path):
            return {}
        index = data.get('index')
        if not isinstance(index, dict):
            return {}
        set_home_prop(STUDIO_AVAILABLE_PROP, str(int(data.get('file_count', 0))))
        set_home_prop(STUDIO_STATUS_PROP, 'ready')
        set_home_prop(STUDIO_CACHE_PROP, 'hit')
        set_home_prop(STUDIO_INDEX_BUILD_MS_PROP, '0')
        set_home_prop(STUDIO_BROKEN_SKIPPED_PROP, str(int(data.get('broken_skipped', 0))))
        log(f'studio logo index cache hit; files={data.get("file_count", 0)}, keys={len(index)}')
        return {str(k): str(v) for k, v in index.items()}
    except Exception:
        return {}


def _save_cached_studio_index(texture_path: str, filenames_count: int, index: dict[str, str], broken_skipped: int) -> None:
    cache_path = _studio_index_cache_path()
    try:
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        payload = {
            'resource_id': STUDIO_RESOURCE_ID,
            'generated': time.strftime('%Y-%m-%d %H:%M:%S'),
            'texture_signature': _file_signature(texture_path),
            'file_count': filenames_count,
            'key_count': len(index),
            'broken_skipped': broken_skipped,
            'index': index,
        }
        with open(cache_path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, separators=(',', ':'))
    except Exception:
        pass


def _is_broken_studio_texture(filename_or_uri: str) -> bool:
    base = os.path.basename(unquote(str(filename_or_uri or '')).replace('\\', '/')).lower().strip()
    return base in BROKEN_STUDIO_TEXTURE_NAMES


def build_studio_logo_index() -> dict[str, str]:
    started = time.time()
    addon_dir = translate(f'special://home/addons/{STUDIO_RESOURCE_ID}')
    resource_dir = os.path.join(addon_dir, 'resources')
    texture_path = os.path.join(resource_dir, 'Textures.xbt')
    cached = _load_cached_studio_index(texture_path)
    if cached:
        return cached

    filenames = []
    if os.path.exists(texture_path):
        filenames.extend(_read_xbt_filenames(texture_path))
    if os.path.isdir(resource_dir):
        filenames.extend(_walk_resource_images(resource_dir))
    filenames = list(dict.fromkeys(filenames))
    ranked: dict[str, tuple[int, str]] = {}
    broken_skipped = 0
    for filename in filenames:
        clean = filename.replace('\\', '/')
        if _is_broken_studio_texture(clean):
            broken_skipped += 1
            continue
        uri = f'resource://{STUDIO_RESOURCE_ID}/{clean}'
        stem = _strip_ext(clean)
        # Prefer exact flat names over regional/parenthetical variants when two
        # filenames normalize to the same studio key, e.g. prefer
        # "universal pictures.png" over "universal pictures (spain).png".
        base_score = 0
        if '(' in stem or ')' in stem:
            base_score += 20
        if '/' in clean:
            base_score += 10
        base_score += min(9, len(stem) // 30)
        for pos, key in enumerate(_logo_keys(clean)):
            score = base_score + pos
            old = ranked.get(key)
            if old is None or score < old[0]:
                ranked[key] = (score, uri)
    index = {key: uri for key, (_score, uri) in ranked.items()}
    elapsed_ms = int((time.time() - started) * 1000)
    set_home_prop(STUDIO_AVAILABLE_PROP, str(len(filenames)))
    set_home_prop(STUDIO_STATUS_PROP, 'ready' if index else 'no-resource')
    set_home_prop(STUDIO_CACHE_PROP, 'rebuilt')
    set_home_prop(STUDIO_INDEX_BUILD_MS_PROP, str(elapsed_ms))
    set_home_prop(STUDIO_BROKEN_SKIPPED_PROP, str(broken_skipped))
    _save_cached_studio_index(texture_path, len(filenames), index, broken_skipped)
    log(f'studio logo index ready; files={len(filenames)}, keys={len(index)}, skipped_broken={broken_skipped}, build_ms={elapsed_ms}')
    return index


def _split_studio_label(value: str) -> list[str]:
    value = (value or '').strip()
    if not value:
        return []
    # Kodi multi-studio label commonly uses " / ". Also handle pipes and semicolons.
    parts = re.split(r'\s+/\s+|\s*\|\s*|\s*;\s*', value)
    return [p.strip() for p in parts if p and p.strip()]



def _safe_int(value: str) -> int:
    try:
        return int(str(value or '').strip())
    except Exception:
        return 0


def _focused_control_id() -> int:
    for label in ('System.CurrentControlID', 'System.CurrentControl'):
        number = _safe_int(info(label))
        if number > 0:
            return number
    return 0


def _container_selector_widget_id() -> int:
    for expression in (
        'Container(601).ListItem.Property(widget_id)',
        'Container(601).ListItem.Property(widgetid)',
        'Container(601).ListItem.Property(id)',
    ):
        number = _safe_int(info(expression))
        if number > 0:
            return number
    return 0


def _info_from_container(container_id: int, field: str) -> str:
    if container_id <= 0:
        return ''
    return info('Container({0}).ListItem.{1}'.format(container_id, field))


def _dbtype_clean(value: str, title: str = '', showtitle: str = '', season: str = '', episode: str = '') -> str:
    value = (value or '').lower().strip()
    aliases = {
        'movies': 'movie', 'movie': 'movie', 'film': 'movie',
        'tvshows': 'tvshow', 'tvshow': 'tvshow', 'show': 'tvshow', 'series': 'tvshow',
        'episodes': 'episode', 'episode': 'episode',
        'seasons': 'season', 'season': 'season',
        'sets': 'set', 'set': 'set', 'collection': 'set',
    }
    if value in aliases:
        return aliases[value]
    if episode:
        return 'episode'
    if season and showtitle and not title:
        return 'season'
    return value


def _container_media_context(container_id: int) -> tuple[str, str, int, str]:
    if container_id <= 0:
        return '', '', 0, ''
    raw_type = (
        _info_from_container(container_id, 'DBTYPE') or
        _info_from_container(container_id, 'DBType') or
        _info_from_container(container_id, 'Property(DBType)') or
        _info_from_container(container_id, 'Property(dbtype)') or
        _info_from_container(container_id, 'Property(type)')
    )
    title = (
        _info_from_container(container_id, 'Title') or
        _info_from_container(container_id, 'Label') or
        _info_from_container(container_id, 'Property(title)')
    )
    showtitle = (
        _info_from_container(container_id, 'TVShowTitle') or
        _info_from_container(container_id, 'ShowTitle') or
        _info_from_container(container_id, 'Property(tvshowtitle)') or
        _info_from_container(container_id, 'Property(showtitle)')
    )
    season = _info_from_container(container_id, 'Season') or _info_from_container(container_id, 'Property(season)')
    episode = _info_from_container(container_id, 'Episode') or _info_from_container(container_id, 'Property(episode)')
    dbtype = _dbtype_clean(raw_type, title, showtitle, season, episode)
    dbid = _safe_int(
        _info_from_container(container_id, 'DBID') or
        _info_from_container(container_id, 'DBId') or
        _info_from_container(container_id, 'Property(dbid)') or
        _info_from_container(container_id, 'Property(DBID)')
    )
    label = title or showtitle or _info_from_container(container_id, 'Label')
    if dbid > 0 and dbtype in ('movie', 'tvshow', 'episode', 'season', 'set'):
        set_home_prop(FANART_ACTIVE_CONTAINER_ITEM_PROP, '{0}:{1}:{2}'.format(container_id, dbtype, dbid))
        return 'Container({0}).ListItem'.format(container_id), dbtype, dbid, label
    return '', '', 0, label


def _active_container_ids_for_fanart() -> list[tuple[str, int]]:
    candidates: list[tuple[str, int]] = []
    def add(source: str, value: str | int) -> None:
        cid = _safe_int(value)
        if cid <= 0:
            return
        pair = (source, cid)
        if pair not in candidates and cid not in [existing for _src, existing in candidates]:
            candidates.append(pair)

    # Proven bridge from LRS wins first. This is the same visual container AF3
    # already uses for ratings, so buttons/tabs do not overwrite the media item.
    add('LRS.Active.ContainerID', any_window_prop('LRS.Active.ContainerID', 'LRS.Active.ContainerId', 'LRS.Active.WidgetContainer'))
    # KPM's own XML bridge is only a container bridge now, never direct DBID/DBTYPE.
    add('KPM.Active.ContainerID', any_window_prop(FANART_ACTIVE_CONTAINER_PROP, 'KPM.Active.ContainerId', 'KPM.Active.WidgetContainer'))
    add('KPM.Focus.Container', home_prop(FANART_FOCUS_CONTAINER_PROP))
    add('TMDbHelper.WidgetContainer', any_window_prop('TMDbHelper.WidgetContainer', 'TMDBHelper.WidgetContainer'))

    focused = _focused_control_id()
    if focused in (301, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510):
        add('FocusedControl', focused)
    if focused in (600, 601, 602, 603, 604, 605):
        add('SelectorWidgetId', _container_selector_widget_id())
    if focused in (300, 309, 310, 311, 312, 400, 500, 600, 601, 602, 603, 604, 605):
        add('SelectorWidgetId', _container_selector_widget_id())
        add('SpotlightFallback', 301)

    return candidates


def _latest_video_db_path() -> str:
    db_dir = translate('special://profile/Database')
    if not os.path.isdir(db_dir):
        db_dir = translate('special://database')
    if not os.path.isdir(db_dir):
        return ''
    best_path = ''
    best_num = -1
    try:
        for fname in os.listdir(db_dir):
            match = re.match(r'MyVideos(\d+)\.db$', fname, re.I)
            if not match:
                continue
            num = int(match.group(1))
            if num > best_num:
                best_num = num
                best_path = os.path.join(db_dir, fname)
    except Exception:
        return ''
    return best_path


def _episode_contexts() -> list[tuple[str, int]]:
    contexts: list[tuple[str, int]] = []
    for prefix in ('ListItem', 'Container.ListItem', 'VideoPlayer'):
        dbtype = (info(f'{prefix}.DBTYPE') or '').lower().strip()
        dbid = _safe_int(info(f'{prefix}.DBID'))
        is_episode = dbtype == 'episode'
        if prefix == 'VideoPlayer' and not is_episode and cond('VideoPlayer.Content(episodes)'):
            is_episode = True
        if dbid > 0 and is_episode:
            contexts.append((prefix, dbid))
    seen = set()
    deduped = []
    for prefix, dbid in contexts:
        if dbid not in seen:
            seen.add(dbid)
            deduped.append((prefix, dbid))
    return deduped


def _media_contexts() -> list[tuple[str, str, int, str]]:
    contexts: list[tuple[str, str, int, str]] = []
    for prefix in ('ListItem', 'Container.ListItem', 'VideoPlayer'):
        dbtype = (info(f'{prefix}.DBTYPE') or '').lower().strip()
        dbid = _safe_int(info(f'{prefix}.DBID'))
        label = info(f'{prefix}.Label') if prefix != 'VideoPlayer' else info('VideoPlayer.Title')
        if prefix == 'VideoPlayer' and not dbtype:
            if cond('VideoPlayer.Content(movies)'):
                dbtype = 'movie'
            elif cond('VideoPlayer.Content(tvshows)'):
                dbtype = 'tvshow'
            elif cond('VideoPlayer.Content(episodes)'):
                dbtype = 'episode'
        if dbid > 0 and dbtype in ('movie', 'tvshow', 'episode', 'season', 'set'):
            contexts.append((prefix, dbtype, dbid, label))
    seen = set()
    deduped = []
    for item in contexts:
        key = (item[1], item[2])
        if key not in seen:
            seen.add(key)
            deduped.append(item)
    return deduped


def _set_last_media_props(candidates: list[str], resolved: list[tuple[str, str]]) -> None:
    contexts = _media_contexts()
    label = dbtype = dbid = ''
    if contexts:
        _prefix, dbtype, dbid_int, label = contexts[0]
        dbid = str(dbid_int)
    source = home_prop(STUDIO_SOURCE_PROP)
    set_home_prop(STUDIO_LAST_MEDIA_LABEL_PROP, label)
    set_home_prop(STUDIO_LAST_MEDIA_DBID_PROP, dbid)
    set_home_prop(STUDIO_LAST_MEDIA_DBTYPE_PROP, dbtype)
    set_home_prop(STUDIO_LAST_MEDIA_CANDIDATES_PROP, ' | '.join(candidates[:20]))
    set_home_prop(STUDIO_LAST_MEDIA_RESOLVED_PROP, ' | '.join([f'{name} => {uri}' for name, uri in resolved[:1]]))
    set_home_prop(STUDIO_LAST_MEDIA_SOURCE_PROP, source)
    set_home_prop(STUDIO_LAST_MEDIA_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))


def _load_media_studios(media_type: str, media_id: int, media_cache: dict[tuple[str, int], dict], stats: dict | None = None) -> dict:
    if media_type not in ('movie', 'tvshow') or media_id <= 0:
        return {'media_type': media_type, 'media_id': media_id, 'studios': [], 'source': 'invalid_media'}
    key = (media_type, media_id)
    cached = media_cache.get(key)
    if cached is not None:
        return cached
    started = time.time()
    result = {'media_type': media_type, 'media_id': media_id, 'studios': [], 'source': f'{media_type}_db'}
    db_path = _latest_video_db_path()
    if not db_path or not os.path.exists(db_path):
        result['source'] = 'no_video_db'
        media_cache[key] = result
        return result
    try:
        con = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=0.15)
        cur = con.cursor()
        try:
            studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type=? AND sl.media_id=? ORDER BY sl.rowid", (media_type, media_id)) if r and r[0]]
        except Exception:
            studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type=? AND sl.media_id=?", (media_type, media_id)) if r and r[0]]
        result['studios'] = studios
        if not studios:
            result['source'] = f'{media_type}_db_no_studio'
        con.close()
    except Exception as exc:
        result['source'] = 'db_error'
        result['error'] = str(exc)
    elapsed_ms = int((time.time() - started) * 1000)
    set_home_prop(STUDIO_DB_LOOKUP_LAST_MS_PROP, str(elapsed_ms))
    if stats is not None:
        stats['db_lookup_count'] = int(stats.get('db_lookup_count', 0)) + 1
        set_home_prop(STUDIO_DB_LOOKUP_COUNT_PROP, str(stats['db_lookup_count']))
    media_cache[key] = result
    if len(media_cache) > 500:
        for old_key in list(media_cache.keys())[:100]:
            media_cache.pop(old_key, None)
    return result


def _load_parent_tvshow_studios_for_episode(episode_id: int, episode_cache: dict[int, dict], stats: dict | None = None) -> dict:
    if episode_id <= 0:
        return {'episode_id': episode_id, 'id_show': 0, 'show_title': '', 'studios': [], 'source': 'invalid_episode_id'}
    cached = episode_cache.get(episode_id)
    if cached is not None:
        return cached

    started = time.time()
    result = {'episode_id': episode_id, 'id_show': 0, 'show_title': '', 'studios': [], 'source': 'parent_tvshow_db'}
    db_path = _latest_video_db_path()
    if not db_path or not os.path.exists(db_path):
        result['source'] = 'no_video_db'
        episode_cache[episode_id] = result
        return result
    try:
        con = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=0.15)
        cur = con.cursor()
        row = cur.execute('SELECT e.idShow, COALESCE(t.c00, \'\') FROM episode e LEFT JOIN tvshow t ON t.idShow=e.idShow WHERE e.idEpisode=?', (episode_id,)).fetchone()
        if not row:
            result['source'] = 'episode_not_found'
        else:
            id_show = int(row[0] or 0)
            result['id_show'] = id_show
            result['show_title'] = row[1] or ''
            if id_show > 0:
                try:
                    studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type='tvshow' AND sl.media_id=? ORDER BY sl.rowid", (id_show,)) if r and r[0]]
                except Exception:
                    studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type='tvshow' AND sl.media_id=?", (id_show,)) if r and r[0]]
                result['studios'] = studios
                if not studios:
                    result['source'] = 'parent_tvshow_no_studio'
        con.close()
    except Exception as exc:
        result['source'] = 'db_error'
        result['error'] = str(exc)
    elapsed_ms = int((time.time() - started) * 1000)
    set_home_prop(STUDIO_DB_LOOKUP_LAST_MS_PROP, str(elapsed_ms))
    if stats is not None:
        stats['db_lookup_count'] = int(stats.get('db_lookup_count', 0)) + 1
        set_home_prop(STUDIO_DB_LOOKUP_COUNT_PROP, str(stats['db_lookup_count']))
    episode_cache[episode_id] = result
    # Keep the cache bounded because focus can move through many episode widgets.
    if len(episode_cache) > 500:
        for key in list(episode_cache.keys())[:100]:
            episode_cache.pop(key, None)
    return result


def collect_studio_candidates(episode_cache: dict[int, dict] | None = None, stats: dict | None = None, media_cache: dict[tuple[str, int], dict] | None = None) -> list[str]:
    candidates: list[str] = []
    direct_count = 0
    for label in ('Container.ListItem.Studio', 'ListItem.Studio', 'VideoPlayer.Studio'):
        before = len(candidates)
        candidates.extend(_split_studio_label(info(label)))
        direct_count += len(candidates) - before
    for idx in range(1, 11):
        before = len(candidates)
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.ListItem.Studio.{idx}.Name')))
        direct_count += len(candidates) - before
    for idx in range(1, 6):
        before = len(candidates)
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.ListItem.Network.{idx}.Name')))
        direct_count += len(candidates) - before
    for idx in range(1, 6):
        before = len(candidates)
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.Player.Studio.{idx}.Name')))
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.Player.Network.{idx}.Name')))
        direct_count += len(candidates) - before

    db_direct_count = 0
    db_direct_source = ''
    if media_cache is not None:
        for _prefix, dbtype, dbid, _label in _media_contexts():
            if dbtype in ('movie', 'tvshow'):
                db_res = _load_media_studios(dbtype, dbid, media_cache, stats)
                db_direct_source = db_res.get('source', '') or f'{dbtype}_db'
                before = len(candidates)
                candidates.extend(_split_studio_label(' / '.join(db_res.get('studios') or [])))
                db_direct_count += len(candidates) - before
                if db_direct_count:
                    break

    parent_count = 0
    parent_source = ''
    parent_show_id = 0
    parent_show_title = ''
    if episode_cache is not None:
        for prefix, episode_id in _episode_contexts():
            parent = _load_parent_tvshow_studios_for_episode(episode_id, episode_cache, stats)
            parent_source = parent.get('source', '') or 'parent_tvshow_db'
            parent_show_id = int(parent.get('id_show') or 0)
            parent_show_title = parent.get('show_title', '') or ''
            before = len(candidates)
            candidates.extend(_split_studio_label(' / '.join(parent.get('studios') or [])))
            parent_count += len(candidates) - before
            if parent_count:
                break

    deduped = []
    seen = set()
    for item in candidates:
        key = _simple_key(item)
        if key and key not in seen:
            seen.add(key)
            deduped.append(item)

    if direct_count and db_direct_count and parent_count:
        source = 'direct+media_db+parent_tvshow_db'
    elif direct_count and db_direct_count:
        source = 'direct+media_db'
    elif direct_count and parent_count:
        source = 'direct+parent_tvshow_db'
    elif db_direct_count and parent_count:
        source = 'media_db+parent_tvshow_db'
    elif parent_count:
        source = 'parent_tvshow_db'
    elif db_direct_count:
        source = db_direct_source or 'media_db'
    elif direct_count:
        source = 'direct'
    elif parent_source:
        source = parent_source
    else:
        source = 'none'
    set_home_prop(STUDIO_SOURCE_PROP, source)
    if parent_show_id > 0:
        set_home_prop(STUDIO_EPISODE_PARENT_SHOW_ID_PROP, str(parent_show_id))
        set_home_prop(STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP, parent_show_title)
    else:
        clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_ID_PROP)
        clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP)
    return deduped

def resolve_studio_logos(index: dict[str, str], count: int) -> list[tuple[str, str]]:
    resolved: list[tuple[str, str]] = []
    seen_uris = set()
    for name in collect_studio_candidates():
        uri = ''
        for key in _logo_keys(name):
            uri = index.get(key, '')
            if uri:
                break
        if uri and uri not in seen_uris:
            resolved.append((name, uri))
            seen_uris.add(uri)
        if len(resolved) >= count:
            break
    return resolved


def clear_studio_props() -> None:
    for idx in range(1, 4):
        clear_home_prop(f'{STUDIO_PROP_PREFIX}{idx}')
        clear_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}')
    clear_home_prop(STUDIO_COUNT_PROP)
    clear_home_prop(STUDIO_CANDIDATES_PROP)
    clear_home_prop(STUDIO_RESOLVED_PROP)
    clear_home_prop(STUDIO_MISSING_PROP)
    clear_home_prop(STUDIO_UPDATED_AT_PROP)
    clear_home_prop(STUDIO_SHOW_PROP)
    clear_home_prop(STUDIO_CONTEXT_PROP)
    clear_home_prop(STUDIO_RESOLVE_LAST_MS_PROP)
    clear_home_prop(STUDIO_RESOLVE_MAX_MS_PROP)
    clear_home_prop(STUDIO_RESOLVE_COUNT_PROP)
    clear_home_prop(STUDIO_SOURCE_PROP)
    clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_ID_PROP)
    clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP)
    clear_home_prop(STUDIO_DB_LOOKUP_LAST_MS_PROP)
    clear_home_prop(STUDIO_DB_LOOKUP_COUNT_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_LABEL_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_DBID_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_DBTYPE_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_CANDIDATES_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_RESOLVED_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_SOURCE_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_UPDATED_AT_PROP)


def update_studio_logo_props(
    index: dict[str, str],
    count: int,
    force: bool = False,
    last_key: str = '',
    empty_since: float = 0.0,
    debug: bool = False,
    stats: dict | None = None,
    episode_cache: dict[int, dict] | None = None,
    media_cache: dict[tuple[str, int], dict] | None = None,
) -> tuple[str, float]:
    started = time.time()
    count = 1
    studios = collect_studio_candidates(episode_cache, stats, media_cache)
    now = time.time()

    if not studios:
        # No active media context, usually because focus moved into an add-on/menu/dialog.
        # Keep KPM.StudioLogo.1 cached, but hide the furniture logo through a separate
        # visibility flag. This avoids stale logos in non-media menus without clearing
        # the last valid resolved logo needed by diagnostics and quick focus returns.
        set_home_prop(STUDIO_SHOW_PROP, 'false')
        set_home_prop(STUDIO_CONTEXT_PROP, 'non_media')
        set_home_prop(STUDIO_CANDIDATES_PROP, '')
        set_home_prop(STUDIO_RESOLVED_PROP, home_prop(STUDIO_LAST_MEDIA_RESOLVED_PROP))
        set_home_prop(STUDIO_MISSING_PROP, '')
        set_home_prop(STUDIO_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))
        set_home_prop(STUDIO_COUNT_PROP, '1')
        if empty_since <= 0.0:
            empty_since = now
        return last_key, empty_since

    empty_since = 0.0
    key = '|'.join(studios) + f'|count={count}'
    if not force and key == last_key:
        # Same focused media after a menu/dialog temporarily hid the footer: do not
        # wait for a later focus change. If a valid logo is already cached, make it
        # visible immediately; otherwise keep it hidden for this media item.
        if home_prop(f'{STUDIO_PROP_PREFIX}1'):
            set_home_prop(STUDIO_SHOW_PROP, 'true')
            set_home_prop(STUDIO_CONTEXT_PROP, 'media_cached_logo')
            if not home_prop(STUDIO_CANDIDATES_PROP):
                set_home_prop(STUDIO_CANDIDATES_PROP, ' | '.join(studios[:20]))
        else:
            set_home_prop(STUDIO_SHOW_PROP, 'false')
            set_home_prop(STUDIO_CONTEXT_PROP, 'media_no_logo')
        return last_key, empty_since

    resolved: list[tuple[str, str]] = []
    missing: list[str] = []
    broken: list[str] = []
    seen_uris = set()
    for name in studios:
        uri = ''
        for logo_key in _logo_keys(name):
            uri = index.get(logo_key, '')
            if uri:
                break
        if uri and _is_broken_studio_texture(uri):
            broken.append(name)
            uri = ''
        if uri:
            if uri not in seen_uris and len(resolved) < count:
                resolved.append((name, uri))
            seen_uris.add(uri)
        else:
            missing.append(name)

    for idx in range(1, 4):
        if idx <= len(resolved):
            name, uri = resolved[idx - 1]
            set_home_prop(f'{STUDIO_PROP_PREFIX}{idx}', uri)
            set_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}', name)
        else:
            clear_home_prop(f'{STUDIO_PROP_PREFIX}{idx}')
            clear_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}')
    elapsed_ms = int((time.time() - started) * 1000)
    if stats is not None:
        stats['resolve_count'] = int(stats.get('resolve_count', 0)) + 1
        stats['resolve_max_ms'] = max(int(stats.get('resolve_max_ms', 0)), elapsed_ms)
        set_home_prop(STUDIO_RESOLVE_COUNT_PROP, str(stats['resolve_count']))
        set_home_prop(STUDIO_RESOLVE_MAX_MS_PROP, str(stats['resolve_max_ms']))
    set_home_prop(STUDIO_RESOLVE_LAST_MS_PROP, str(elapsed_ms))
    set_home_prop(STUDIO_COUNT_PROP, str(count))
    set_home_prop(STUDIO_SHOW_PROP, 'true' if resolved else 'false')
    set_home_prop(STUDIO_CONTEXT_PROP, 'media_with_logo' if resolved else 'media_no_logo')
    set_home_prop(STUDIO_CANDIDATES_PROP, ' | '.join(studios[:20]))
    set_home_prop(STUDIO_RESOLVED_PROP, ' | '.join([f'{name} => {uri}' for name, uri in resolved[:3]]))
    missing_all = missing[:20]
    if broken:
        missing_all = (missing_all + [f'BROKEN_TEXTURE:{x}' for x in broken])[:20]
    set_home_prop(STUDIO_MISSING_PROP, ' | '.join(missing_all))
    set_home_prop(STUDIO_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))
    if studios:
        _set_last_media_props(studios, resolved)
    if debug:
        if resolved:
            log('studio logos: ' + ' | '.join([f'{name} -> {uri}' for name, uri in resolved]) + f' ({elapsed_ms}ms)')
        elif studios:
            log('studio logos: no valid match; candidates=' + ' | '.join(studios[:6]) + f' ({elapsed_ms}ms)')
    return key, empty_since




def fanart_patch_enabled() -> bool:
    # v0.1.44: Independent Fanart Engine was removed from KPM by request.
    # Keep this hard-off even if an old addon_data state file still exists.
    return False


def _candidate_artwork_cache_db_paths() -> list[str]:
    profile = translate('special://profile')
    candidates = [
        os.path.join(profile, 'addon_data', 'script.artwork.curator', 'artwork-cache.db'),
        os.path.join(profile, 'addon_data', 'script.artwork.curator', 'cache', 'artwork-cache.db'),
        os.path.join(profile, 'addon_data', 'script.artwork.curator', 'database', 'artwork-cache.db'),
        os.path.join(profile, 'addon_data', 'script.kodi.patch.manager', 'artwork-cache.db'),
        os.path.join(profile, 'addon_data', 'script.kodi.patch.manager', 'lac', 'artwork-cache.db'),
    ]
    output = []
    seen = set()
    for path in candidates:
        n = os.path.normpath(path)
        if n not in seen:
            seen.add(n)
            output.append(n)
    return output


def _find_artwork_cache_db() -> str:
    for path in _candidate_artwork_cache_db_paths():
        if os.path.exists(path):
            return path
    return ''


def _dbtype_to_item_key(dbtype: str, dbid: int, parent_cache: dict | None = None) -> tuple[str, str, str]:
    """Return (item_key, source_note, parent_key)."""
    dbtype = (dbtype or '').lower().strip()
    if dbid <= 0:
        return '', 'invalid_dbid', ''
    if dbtype in ('movie', 'tvshow', 'set'):
        return f'{dbtype}:{dbid}', 'direct', ''
    if dbtype == 'episode':
        parent = _load_parent_tvshow_studios_for_episode(dbid, parent_cache or {})
        show_id = int(parent.get('id_show') or 0)
        if show_id > 0:
            return f'tvshow:{show_id}', 'episode_parent_tvshow', f'episode:{dbid}'
        return f'episode:{dbid}', 'episode_direct_no_parent', ''
    if dbtype == 'season':
        parent_key = f'season:{dbid}'
        db_path = _latest_video_db_path()
        if db_path and os.path.exists(db_path):
            try:
                con = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=0.12)
                row = con.execute('SELECT idShow FROM seasons WHERE idSeason=?', (dbid,)).fetchone()
                con.close()
                show_id = int(row[0] or 0) if row else 0
                if show_id > 0:
                    return f'tvshow:{show_id}', 'season_parent_tvshow', parent_key
            except Exception:
                pass
        return parent_key, 'season_direct_no_parent', ''
    return f'{dbtype}:{dbid}', 'direct_unknown_type', ''


def _focused_media_context_for_fanart() -> tuple[str, str, int, str]:
    # Player/OSD wins. During playback, VideoPlayer is the exact library item;
    # AF3 hub/container props may still contain the last browsed item.
    vp_dbtype = _dbtype_clean(info('VideoPlayer.DBTYPE') or info('VideoPlayer.DBType'))
    if not vp_dbtype:
        if cond('VideoPlayer.Content(movies)'):
            vp_dbtype = 'movie'
        elif cond('VideoPlayer.Content(tvshows)'):
            vp_dbtype = 'tvshow'
        elif cond('VideoPlayer.Content(episodes)'):
            vp_dbtype = 'episode'
    vp_dbid = _safe_int(info('VideoPlayer.DBID') or info('VideoPlayer.DBId'))
    if vp_dbid > 0 and vp_dbtype in ('movie', 'tvshow', 'episode', 'season', 'set'):
        set_home_prop(FANART_ACTIVE_CONTAINER_SOURCE_PROP, 'VideoPlayer')
        return 'VideoPlayer', vp_dbtype, vp_dbid, info('VideoPlayer.Title')

    # v0.1.43: LRS-style bridge. Do not trust DBID/DBTYPE pushed from XML.
    # AF3 hub focus often sits on tab/play/more/selector controls, where
    # ListItem.DBID is empty or stale. Only the active container ID is bridged;
    # the service resolves Container(ID).ListItem.* itself.
    if current_window_id() in FANART_MEDIA_WINDOW_IDS:
        for source, container_id in _active_container_ids_for_fanart():
            prefix, dbtype, dbid, label = _container_media_context(container_id)
            if dbid > 0 and dbtype in ('movie', 'tvshow', 'episode', 'season', 'set'):
                set_home_prop(FANART_ACTIVE_CONTAINER_PROP, str(container_id))
                set_home_prop(FANART_ACTIVE_CONTAINER_SOURCE_PROP, source)
                # Keep old diagnostic aliases populated with resolved values only.
                set_home_prop(FANART_FOCUS_CONTAINER_PROP, str(container_id))
                set_home_prop(FANART_FOCUS_PREFIX_PROP, prefix)
                set_home_prop(FANART_FOCUS_DBID_PROP, str(dbid))
                set_home_prop(FANART_FOCUS_DBTYPE_PROP, dbtype)
                set_home_prop(FANART_FOCUS_LABEL_PROP2, label)
                return prefix, dbtype, dbid, label

    # Player/normal library fallback. VideoPlayer can still be exact in OSD.
    contexts = _media_contexts()
    if contexts:
        for prefix, dbtype, dbid, label in contexts:
            if dbtype in ('movie', 'tvshow', 'episode', 'season', 'set') and dbid > 0:
                set_home_prop(FANART_ACTIVE_CONTAINER_SOURCE_PROP, prefix)
                return prefix, dbtype, dbid, label

    for prefix in ('Container.ListItem', 'ListItem'):
        dbtype = _dbtype_clean(info(f'{prefix}.DBTYPE') or info(f'{prefix}.DBType'))
        dbid = _safe_int(info(f'{prefix}.DBID') or info(f'{prefix}.DBId'))
        label = info(f'{prefix}.Label') or info(f'{prefix}.Title')
        if dbid > 0 and dbtype in ('movie', 'tvshow', 'episode', 'season', 'set'):
            set_home_prop(FANART_ACTIVE_CONTAINER_SOURCE_PROP, prefix)
            return prefix, dbtype, dbid, label
    return '', '', 0, ''


def _load_fanarts_from_artwork_cache(item_key: str, db_path: str, fanart_cache: dict[str, list[tuple[str, str, str]]]) -> list[tuple[str, str, str]]:
    if not item_key or not db_path:
        return []
    cache_key = db_path + '|' + item_key
    cached = fanart_cache.get(cache_key)
    if cached is not None:
        return cached
    rows: list[tuple[str, str, str]] = []
    try:
        con = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=0.12)
        placeholders = ','.join(['?'] * len(FANART_ART_TYPES))
        sql = f"SELECT art_type, url, COALESCE(source,'') FROM artwork WHERE item_key=? AND status='OK' AND lower(art_type) IN ({placeholders})"
        fetched = con.execute(sql, (item_key, *FANART_ART_TYPES)).fetchall()
        con.close()
        order = {name: idx for idx, name in enumerate(FANART_ART_TYPES)}
        fetched.sort(key=lambda r: order.get((r[0] or '').lower(), 999))
        seen = set()
        for art_type, url, source in fetched:
            url = (url or '').strip()
            if not url or url in seen:
                continue
            seen.add(url)
            rows.append(((art_type or '').lower(), url, source or ''))
    except Exception:
        rows = []
    fanart_cache[cache_key] = rows
    if len(fanart_cache) > 800:
        for key in list(fanart_cache.keys())[:150]:
            fanart_cache.pop(key, None)
    return rows



def _load_launch_fanarts_from_artwork_cache(db_path: str, launch_cache: dict) -> list[str]:
    if not db_path:
        return []
    try:
        mtime = os.path.getmtime(db_path)
    except Exception:
        mtime = 0.0
    cache_key = db_path + '|' + str(mtime)
    if launch_cache.get('key') == cache_key:
        return launch_cache.get('urls') or []
    urls: list[str] = []
    try:
        con = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=0.25)
        placeholders = ','.join(['?'] * len(FANART_ART_TYPES))
        # Launch fallback should only use movie + TV show fanart, not episode/thumb/season/set art.
        sql = f"""
            SELECT url
            FROM artwork
            WHERE status='OK'
              AND lower(art_type) IN ({placeholders})
              AND (item_key LIKE 'movie:%' OR item_key LIKE 'tvshow:%')
        """
        fetched = con.execute(sql, FANART_ART_TYPES).fetchall()
        con.close()
        seen = set()
        for row in fetched:
            url = ((row[0] if row else '') or '').strip()
            if not url or url in seen:
                continue
            seen.add(url)
            urls.append(url)
    except Exception:
        urls = []
    launch_cache.clear()
    launch_cache['key'] = cache_key
    launch_cache['urls'] = urls
    return urls


def update_launch_fanart_prop(launch_cache: dict, force: bool = False) -> None:
    # This replaces AF3's static extras/backgrounds/launch mountain fallback.
    # KPM only supplies a normal URL; Kodi's texture cache handles local/remote loading.
    if home_prop(FANART_LAUNCH_PROP) and not force:
        return
    db_path = _find_artwork_cache_db()
    if not db_path:
        clear_home_prop(FANART_LAUNCH_PROP)
        set_home_prop(FANART_LAUNCH_REASON_PROP, 'missing_artwork_cache_db')
        return
    urls = _load_launch_fanarts_from_artwork_cache(db_path, launch_cache)
    set_home_prop(FANART_LAUNCH_DB_PATH_PROP, db_path)
    set_home_prop(FANART_LAUNCH_CANDIDATES_COUNT_PROP, str(len(urls)))
    if not urls:
        clear_home_prop(FANART_LAUNCH_PROP)
        set_home_prop(FANART_LAUNCH_REASON_PROP, 'no_movie_tv_fanart_rows')
        return
    selected = random.choice(urls)
    set_home_prop(FANART_LAUNCH_PROP, selected)
    set_home_prop(FANART_LAUNCH_SOURCE_PROP, 'artwork_cache_db_url_movie_tv')
    set_home_prop(FANART_LAUNCH_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))
    set_home_prop(FANART_LAUNCH_REASON_PROP, 'selected_random_launch_fallback')




def _set_tmdbhelper_prop(name: str, value: str) -> None:
    # AF3 reads both Window.Property(...) and Window(Home).Property(...).
    # Set both so blur/background/foreground layers agree on one source.
    set_home_prop(name, value)
    set_current_window_prop(name, value)


def _clear_tmdbhelper_prop(name: str) -> None:
    clear_home_prop(name)
    clear_current_window_prop(name)


def _publish_af3_fanart_source(url: str, ready: bool = True) -> None:
    if not url:
        _clear_af3_fanart_source()
        return
    set_home_prop(FANART_SOURCE_IMAGE_PROP, url)
    # KPM is a SOURCE selector only. TMDbHelper.Blur.SourceImage expects a
    # source expression like Property(x)|Art(fanart), not a raw URL and not the
    # literal property name. KPM stores the selected URL in KPM.Fanart.SourceImage;
    # TMDbHelper then resolves Property(KPM.Fanart.SourceImage) and generates the
    # normal blur_v3 outputs consumed by AF3.
    source_expr = 'Property(KPM.Fanart.SourceImage)|Art(fanart)|Property(fanart)||EPGEventIcon||PicturePath'
    _set_tmdbhelper_prop('TMDbHelper.Blur.SourceImage', source_expr)
    _set_tmdbhelper_prop('TMDbHelper.Blur.Fallback', url)
    set_home_prop(FANART_PENDING_PROP, 'false')
    set_home_prop(FANART_READY_PROP, 'true' if ready else 'false')


def _clear_af3_fanart_source() -> None:
    set_home_prop(FANART_READY_PROP, 'false')
    # Only clear the KPM input bridge. Never clear TMDbHelper.ListItem.BlurImage,
    # TMDbHelper.ListItem.Current.BlurImage, or SimpleBackground.BlurImage here;
    # those are AF3/TMDbHelper output state and clearing them causes missing/flashy
    # default backgrounds.
    for prop in (
        FANART_SOURCE_IMAGE_PROP,
        'TMDbHelper.Blur.Fallback',
    ):
        clear_home_prop(prop)
        clear_current_window_prop(prop)


def _clear_fanart_display(show_false_only: bool = True) -> None:
    set_home_prop(FANART_SHOW_PROP, 'false')
    set_home_prop(FANART_READY_PROP, 'false')
    set_home_prop(FANART_PENDING_PROP, 'false')
    _clear_af3_fanart_source()
    if show_false_only:
        return
    for key in (
        FANART_DISPLAY_PROP, FANART_SELECTED_PROP, FANART_ITEM_KEY_PROP, FANART_DISPLAY_ITEM_KEY_PROP,
        FANART_CURRENT_FOCUS_KEY_PROP, FANART_MISMATCH_PROP, FANART_SOURCE_PROP, FANART_REASON_PROP,
        FANART_CANDIDATES_PROP, FANART_LAUNCH_PROP, FANART_LAUNCH_SOURCE_PROP, FANART_LAUNCH_UPDATED_AT_PROP,
        FANART_LAUNCH_DB_PATH_PROP, FANART_LAUNCH_CANDIDATES_COUNT_PROP, FANART_LAUNCH_REASON_PROP,
        FANART_LAUNCH_ACTIVE_PROP,
    ):
        clear_home_prop(key)


def update_independent_fanart_props(
    last_focus_key: str,
    last_by_item: dict[str, str],
    fanart_cache: dict[str, list[tuple[str, str, str]]],
    parent_cache: dict[int, dict],
    visit_counter: int,
    force: bool = False,
) -> tuple[str, int]:
    started = time.time()
    prefix, dbtype, dbid, label = _focused_media_context_for_fanart()
    if not dbtype or dbid <= 0:
        # No focused media: do NOT feed random movie/TV fanart into AF3/TMDbHelper.
        # v0.1.39 published KPM.Fanart.Launch here, which made Add-ons/Settings/KPM
        # dialogs show random library movie fanart behind the UI. Launch fallback must not
        # be treated as a global background source. Keep the selected launch URL for
        # diagnostics/future startup-only handling, but clear the live AF3 bridge.
        _clear_fanart_display(True)
        set_home_prop(FANART_LAUNCH_ACTIVE_PROP, 'false')
        set_home_prop(FANART_REASON_PROP, 'no_media_context_bridge_off')
        set_home_prop(FANART_CURRENT_FOCUS_KEY_PROP, '')
        set_home_prop(FANART_MISMATCH_PROP, 'false')
        return '', visit_counter

    # A real media item is focused. Launch fallback must not be drawn behind it.
    set_home_prop(FANART_LAUNCH_ACTIVE_PROP, 'false')
    item_key, source_note, parent_key = _dbtype_to_item_key(dbtype, dbid, parent_cache)
    focus_key = f'{prefix}|{dbtype}:{dbid}|{item_key}'
    set_home_prop(FANART_CURRENT_FOCUS_KEY_PROP, focus_key)
    set_home_prop(FANART_DBTYPE_PROP, dbtype)
    set_home_prop(FANART_DBID_PROP, str(dbid))
    set_home_prop(FANART_FOCUS_LABEL_PROP, label)

    if not item_key:
        _clear_fanart_display(True)
        set_home_prop(FANART_REASON_PROP, source_note or 'no_item_key')
        set_home_prop(FANART_MISMATCH_PROP, 'true')
        return focus_key, visit_counter

    display_item_key = home_prop(FANART_DISPLAY_ITEM_KEY_PROP) or home_prop(FANART_ITEM_KEY_PROP)
    focus_changed = force or focus_key != last_focus_key
    item_mismatch = bool(display_item_key and display_item_key != item_key)

    if item_mismatch:
        # Critical anti-ghost rule: never keep old A visible after focus already moved to B.
        # Hide old KPM layer immediately before any DB/cache work so AF3 cannot blend two items.
        set_home_prop(FANART_SHOW_PROP, 'false')
        set_home_prop(FANART_READY_PROP, 'false')
        _clear_af3_fanart_source()
        set_home_prop(FANART_MISMATCH_PROP, 'true')
        set_home_prop(FANART_CACHE_RESULT_PROP, 'focus_mismatch_hidden_old_display')
    else:
        set_home_prop(FANART_MISMATCH_PROP, 'false')

    if not focus_changed:
        # Same focused item: keep the selected image locked. Only show it when it belongs to this item.
        if home_prop(FANART_DISPLAY_PROP) and not item_mismatch:
            _publish_af3_fanart_source(home_prop(FANART_DISPLAY_PROP), ready=True)
            set_home_prop(FANART_SHOW_PROP, 'true')
            set_home_prop(FANART_CACHE_RESULT_PROP, 'same_focus_locked')
        return last_focus_key, visit_counter

    db_path = _find_artwork_cache_db()
    if not db_path:
        _clear_fanart_display(True)
        set_home_prop(FANART_ENGINE_STATUS_PROP, 'missing_artwork_cache_db')
        set_home_prop(FANART_REASON_PROP, 'missing_artwork_cache_db')
        return focus_key, visit_counter

    rows = _load_fanarts_from_artwork_cache(item_key, db_path, fanart_cache)
    if not rows and parent_key and parent_key != item_key:
        rows = _load_fanarts_from_artwork_cache(parent_key, db_path, fanart_cache)
        if rows:
            item_key = parent_key
            source_note += '+fallback_parent_key'
    if not rows:
        _clear_fanart_display(True)
        set_home_prop(FANART_ENGINE_STATUS_PROP, 'ready_no_fanart')
        set_home_prop(FANART_REASON_PROP, 'no_fanart_rows_for_' + item_key)
        set_home_prop(FANART_ITEM_KEY_PROP, item_key)
        set_home_prop(FANART_DISPLAY_ITEM_KEY_PROP, '')
        set_home_prop(FANART_CANDIDATES_COUNT_PROP, '0')
        set_home_prop(FANART_LOOKUP_MS_PROP, str(int((time.time() - started) * 1000)))
        return focus_key, visit_counter

    urls = [row[1] for row in rows]
    last = last_by_item.get(item_key, '')
    if len(urls) == 1:
        selected = urls[0]
    else:
        choices = [u for u in urls if u != last] or urls
        selected = random.choice(choices)
    last_by_item[item_key] = selected
    selected_index = urls.index(selected) if selected in urls else -1
    visit_counter += 1
    elapsed = int((time.time() - started) * 1000)

    # Atomic publish order: set URL + owner key first, then Show=true last.
    # That prevents AF3 from drawing the old item while focus already belongs to the new one.
    set_home_prop(FANART_DISPLAY_PROP, selected)
    set_home_prop(FANART_SELECTED_PROP, selected)
    set_home_prop(FANART_ITEM_KEY_PROP, item_key)
    set_home_prop(FANART_DISPLAY_ITEM_KEY_PROP, item_key)
    set_home_prop(FANART_VISIT_ID_PROP, str(visit_counter))
    set_home_prop(FANART_SOURCE_PROP, 'artwork_cache_db:' + source_note)
    set_home_prop(FANART_CACHE_RESULT_PROP, 'new_visit_atomic')
    set_home_prop(FANART_REASON_PROP, 'selected_on_focus_change_atomic')
    set_home_prop(FANART_LAST_FOR_ITEM_PROP, last)
    set_home_prop(FANART_CANDIDATES_COUNT_PROP, str(len(urls)))
    set_home_prop(FANART_CANDIDATES_PROP, ' || '.join(urls[:12]))
    set_home_prop(FANART_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))
    set_home_prop(FANART_DB_PATH_PROP, db_path)
    set_home_prop(FANART_LOOKUP_MS_PROP, str(elapsed))
    set_home_prop(FANART_PARENT_ITEM_KEY_PROP, parent_key)
    set_home_prop(FANART_SELECTED_INDEX_PROP, str(selected_index))
    set_home_prop(FANART_DBTYPE_PROP, dbtype)
    set_home_prop(FANART_DBID_PROP, str(dbid))
    set_home_prop(FANART_FOCUS_LABEL_PROP, label)
    set_home_prop(FANART_ENGINE_STATUS_PROP, 'ready')
    set_home_prop(FANART_MISMATCH_PROP, 'false')
    _publish_af3_fanart_source(selected, ready=True)
    set_home_prop(FANART_SHOW_PROP, 'true')
    return focus_key, visit_counter


def main() -> None:
    if not xbmc:
        return

    if home_prop(ACTIVE_PROP) == 'true':
        log('already running; exiting duplicate instance')
        return

    set_home_prop(ACTIVE_PROP, 'true')
    monitor = xbmc.Monitor()
    armed = home_prop(ARMED_PROP) == 'true'
    try:
        armed_dialog_id = int(home_prop(ARMED_DIALOG_PROP) or '0')
    except Exception:
        armed_dialog_id = 0

    log('started; fanart engine removed; studio resolver and pause monitor only')
    pause_since = 0.0
    last_foreign_dialog = 0
    playback_started_at = 0.0
    last_has_video = False
    studio_index: dict[str, str] = {}
    studio_last_key = ''
    studio_empty_since = 0.0
    studio_stats = {'resolve_count': 0, 'resolve_max_ms': 0, 'db_lookup_count': 0}
    episode_studio_cache: dict[int, dict] = {}
    media_studio_cache: dict[tuple[str, int], dict] = {}
    studio_enabled_cached = False
    studio_count_cached = 1
    studio_debug_cached = False
    last_config_check = 0.0
    last_studio_update = 0.0
    try:
        while not monitor.abortRequested():
            now = time.time()
            if now - last_config_check >= 1.0:
                last_config_check = now
                studio_enabled_cached = studio_patch_enabled()
                settings_cached = load_kpm_settings()
                studio_count_cached = 1
                studio_debug_cached = bool(settings_cached.get('studio_debug')) or home_prop(STUDIO_DEBUG_PROP).lower() == 'true'
                if studio_enabled_cached and not studio_index:
                    studio_index = build_studio_logo_index()
                if not studio_enabled_cached:
                    studio_last_key = ''
                    studio_empty_since = 0.0
                    clear_studio_props()

            if studio_enabled_cached and studio_index and now - last_studio_update >= STUDIO_RESOLVE_INTERVAL_SECONDS:
                last_studio_update = now
                try:
                    studio_last_key, studio_empty_since = update_studio_logo_props(studio_index, 1, False, studio_last_key, studio_empty_since, studio_debug_cached, studio_stats, episode_studio_cache, media_studio_cache)
                except Exception:
                    log('studio resolver error:\n' + traceback.format_exc(), xbmc.LOGWARNING)

            if not pause_patch_enabled():
                armed = False
                armed_dialog_id = 0
                pause_since = 0.0
                last_foreign_dialog = 0
                playback_started_at = 0.0
                last_has_video = False
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                clear_home_prop(PAUSE_SINCE_PROP)
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)
                monitor.waitForAbort(0.25)
                continue

            paused = cond('Player.Paused')
            playing = cond('Player.Playing')
            seeking = cond('Player.Seeking')
            has_video = cond('Player.HasVideo') or cond('Player.HasMedia')
            fullscreen_video = cond('Window.IsActive(VideoFullScreen.xml)') or cond('Window.IsActive(fullscreenvideo)')
            videoosd = cond('Window.IsActive(videoosd)') or cond('Window.IsVisible(videoosd)')
            dialog_id = current_dialog_id()
            foreign_dialog = is_foreign_dialog(dialog_id)

            if has_video and not last_has_video:
                playback_started_at = now
                log(f'video session detected; startup guard active for {STARTUP_GUARD_WINDOW_SECONDS:.1f}s')
            elif not has_video:
                playback_started_at = 0.0
            last_has_video = has_video

            if foreign_dialog:
                if dialog_id != last_foreign_dialog:
                    last_foreign_dialog = dialog_id
                    set_home_prop(LAST_FOREIGN_DIALOG_PROP, str(dialog_id))
                    log(f'foreign dialog active; KPM will not auto-open/close/focus VideoOSD; dialog_id={dialog_id}, window_id={current_window_id()}')
            else:
                last_foreign_dialog = 0
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)

            if has_video and paused and not seeking:
                if pause_since <= 0:
                    pause_since = time.time()
                    set_home_prop(PAUSE_SINCE_PROP, str(pause_since))
                if fullscreen_video and not videoosd and not foreign_dialog:
                    startup_age = (time.time() - playback_started_at) if playback_started_at > 0 else 999.0
                    grace = AUTO_OPEN_GRACE_SECONDS
                    grace_reason = 'normal-pause-no-delay'
                    if startup_age < STARTUP_GUARD_WINDOW_SECONDS:
                        grace = STARTUP_AUTO_DIALOG_GUARD_SECONDS
                        grace_reason = 'startup-dialog-guard'
                    if time.time() - pause_since >= grace:
                        log(f'paused with no foreign dialog; opening VideoOSD; grace={grace:.2f}s/{grace_reason}; dialog_id={dialog_id}, window_id={current_window_id()}')
                        try:
                            xbmc.executebuiltin('CancelAlarm(osd_timeout,true)')
                            xbmc.executebuiltin('ActivateWindow(videoosd)')
                        except Exception:
                            log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
                        monitor.waitForAbort(0.15)
                        continue
            else:
                pause_since = 0.0
                clear_home_prop(PAUSE_SINCE_PROP)

            if has_video and paused and videoosd:
                if not armed:
                    armed_dialog_id = dialog_id
                    set_home_prop(ARMED_DIALOG_PROP, str(armed_dialog_id))
                    log(f'armed while paused; dialog_id={armed_dialog_id}, window_id={current_window_id()}')
                armed = True
                set_home_prop(ARMED_PROP, 'true')

            if armed and has_video and playing and videoosd:
                if foreign_dialog:
                    monitor.waitForAbort(0.25)
                    continue
                log(f'pause->play detected; closing VideoOSD safely; dialog_id={dialog_id}, armed_dialog_id={armed_dialog_id}')
                close_video_osd_safely()
                armed = False
                armed_dialog_id = 0
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                monitor.waitForAbort(0.4)
                continue

            if not has_video or (not paused and not playing):
                armed = False
                armed_dialog_id = 0
                pause_since = 0.0
                last_foreign_dialog = 0
                playback_started_at = 0.0
                last_has_video = False
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                clear_home_prop(PAUSE_SINCE_PROP)
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)

            monitor.waitForAbort(0.08)
    finally:
        clear_home_prop(ACTIVE_PROP)
        clear_home_prop(ARMED_PROP)
        clear_home_prop(ARMED_DIALOG_PROP)
        clear_home_prop(PAUSE_SINCE_PROP)
        clear_home_prop(LAST_FOREIGN_DIALOG_PROP)
        log('stopped')


if __name__ == '__main__':
    main()

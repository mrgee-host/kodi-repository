Kodi Patch Manager 0.2.37

Runtime-only AF3 update
- Does not bundle or directly replace Includes_Info.xml.
- The enabled KPM patch repairs the active file atomically at Kodi startup.
- Restores the Steam game plot block even when an earlier patch removed its indentation anchor.
- Validates the rating-row ancestry and the Steam plot ancestry before writing.
- Keeps the current Arctic Mirage six-panel patch and 1 ms metadata fade-out.

Combined Expanded episodes
- White star texture.
- IMDb rating first, TMDb only when IMDb is empty.
- No star or number when both ratings are empty.
- Focused long episode title scrolls; unfocused titles remain truncated.

AF3 startup weather fallback
- Runs only when weather is unavailable, the code is outside Kodi 0..47, or the code is a Kodi snow code.
- Local-clock daypart bands: dawn/dusk 05:00–06:59 and 17:00–18:59; day 07:00–16:59; night 19:00–04:59.
- Dawn/dusk uses dawn-dusk only when that folder contains a direct file.
- Day/night randomly selects one non-empty rainy, cloudy, clear, storm, fog, or haze folder.
- Writes Window(Home).Property(KPM.AF3StartupFallbackPath).
- Includes_Images.xml receives one partial Image_StartUp value only.
- No all folders are created or referenced.

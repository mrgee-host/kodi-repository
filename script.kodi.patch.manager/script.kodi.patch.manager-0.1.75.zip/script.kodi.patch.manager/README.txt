Kodi Patch Manager v0.1.75
- Reliable Studio Logos now also resolves Steam game developer/publisher logos via resource.images.gamestudios.grayscale when that image resource is installed.
- Movie/TV studio logos still use resource.images.studios.coloured. No fanart/random bridge is added.

Kodi Patch Manager v0.1.71

Built from v0.1.67 clean-no-fanart base. Unified runtime/diagnostics storage added. No v0.1.69 screensaver-games plugin-source changes are included.

Included modules:
- Episode Thumb Up Next
- Movies + Shows Screensaver
- Pause Shows Full OSD
- Reliable Studio Logos

Removed from this build:
- Background random/source bridge module
- Related runtime engine in service.py
- Related patch menu entries
- Related diagnostic menu entries
- Related bridge/status/state handling
- One-time cleanup/restore routines that touch AF3/TMDbHelper files

Install notes:
1. Install this ZIP over the previous KPM version.
2. Restart Kodi.
3. Because this build does not run cleanup routines, it will not alter restored AF3/TMDbHelper files.


Unified runtime update in v0.1.71:
- Patch state now uses runtime/state/.
- Snapshots and diagnostics staging use runtime/exports/.
- Live diagnostic JSONL files use runtime/logs/diagnostics_live/.
- Diagnostics ZIP files are written to the addon_data root.
- Older KPM diagnostics ZIP files in the root are automatically removed before a new one is written.
- Patch Status opens in a text viewer for easier reading.


Shared icon policy:
- KPM is the only canonical shared icon path.
- Uses only the fixed icon filenames supplied in ikon fix.zip.
- No local fallback icons in companion addons.

# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import hashlib
import random
import os
import re
import sqlite3
import time
import traceback
from urllib.parse import unquote

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # pragma: no cover outside Kodi
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

ADDON_ID = 'script.kodi.patch.manager'
ADDON_NAME = 'Kodi Patch Manager'
ACTIVE_PROP = 'KPM.Service.Active.v0144'
ARMED_PROP = 'KPM.ResumeCloseService.Armed'
ARMED_DIALOG_PROP = 'KPM.ResumeCloseService.ArmedDialogId'
PAUSE_SINCE_PROP = 'KPM.ResumeCloseService.PauseSince'
LAST_FOREIGN_DIALOG_PROP = 'KPM.ResumeCloseService.LastForeignDialogId'
LOG_PREFIX = '[Kodi Patch Manager Service v0.1.75] '

NO_DIALOG_ID = 9999
KNOWN_OSD_DIALOG_IDS = {9999, 12901, 10142}
AUTO_OPEN_GRACE_SECONDS = 0.0
STARTUP_AUTO_DIALOG_GUARD_SECONDS = 0.85
STARTUP_GUARD_WINDOW_SECONDS = 3.0
# Dynamic wait policy: keep pause/OSD states fast, but back off when no
# playback/studio work is active.
KPM_WAIT_FAST_SECONDS = 0.08
KPM_WAIT_ACTIVE_SECONDS = 0.20
KPM_WAIT_PLAYBACK_SECONDS = 0.25
KPM_WAIT_IDLE_SECONDS = 1.00
KPM_WAIT_DEEP_IDLE_SECONDS = 5.00
STUDIO_RESOURCE_ID = 'resource.images.studios.coloured'
GAME_STUDIO_RESOURCE_ID = 'resource.images.gamestudios.grayscale'
STUDIO_PROP_PREFIX = 'KPM.StudioLogo.'
STUDIO_NAME_PROP_PREFIX = 'KPM.StudioLogoName.'
STUDIO_COUNT_PROP = 'KPM.StudioLogos.Count'
STUDIO_AVAILABLE_PROP = 'KPM.StudioLogos.Available'
STUDIO_STATUS_PROP = 'KPM.StudioLogos.Status'
STUDIO_CANDIDATES_PROP = 'KPM.StudioLogos.Candidates'
STUDIO_RESOLVED_PROP = 'KPM.StudioLogos.Resolved'
STUDIO_MISSING_PROP = 'KPM.StudioLogos.Missing'
STUDIO_UPDATED_AT_PROP = 'KPM.StudioLogos.UpdatedAt'
STUDIO_SHOW_PROP = 'KPM.StudioLogos.Show'
STUDIO_CONTEXT_PROP = 'KPM.StudioLogos.Context'
STUDIO_CACHE_PROP = 'KPM.StudioLogos.Cache'
GAME_STUDIO_AVAILABLE_PROP = 'KPM.StudioLogos.GameAvailable'
GAME_STUDIO_STATUS_PROP = 'KPM.StudioLogos.GameStatus'
GAME_STUDIO_CACHE_PROP = 'KPM.StudioLogos.GameCache'
GAME_STUDIO_INDEX_BUILD_MS_PROP = 'KPM.StudioLogos.GameIndexBuildMs'
STUDIO_INDEX_BUILD_MS_PROP = 'KPM.StudioLogos.IndexBuildMs'
STUDIO_RESOLVE_LAST_MS_PROP = 'KPM.StudioLogos.ResolveLastMs'
STUDIO_RESOLVE_MAX_MS_PROP = 'KPM.StudioLogos.ResolveMaxMs'
STUDIO_RESOLVE_COUNT_PROP = 'KPM.StudioLogos.ResolveCount'
STUDIO_BROKEN_SKIPPED_PROP = 'KPM.StudioLogos.BrokenSkipped'
STUDIO_DEBUG_PROP = 'KPM.StudioLogos.Debug'
STUDIO_SOURCE_PROP = 'KPM.StudioLogos.Source'
STUDIO_EPISODE_PARENT_SHOW_ID_PROP = 'KPM.StudioLogos.EpisodeParentShowId'
STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP = 'KPM.StudioLogos.EpisodeParentShowTitle'
STUDIO_DB_LOOKUP_LAST_MS_PROP = 'KPM.StudioLogos.DBLookupLastMs'
STUDIO_DB_LOOKUP_COUNT_PROP = 'KPM.StudioLogos.DBLookupCount'
STUDIO_LAST_MEDIA_LABEL_PROP = 'KPM.StudioLogos.LastMediaLabel'
STUDIO_LAST_MEDIA_DBID_PROP = 'KPM.StudioLogos.LastMediaDBID'
STUDIO_LAST_MEDIA_DBTYPE_PROP = 'KPM.StudioLogos.LastMediaDBTYPE'
STUDIO_LAST_MEDIA_CANDIDATES_PROP = 'KPM.StudioLogos.LastMediaCandidates'
STUDIO_LAST_MEDIA_RESOLVED_PROP = 'KPM.StudioLogos.LastMediaResolved'
STUDIO_LAST_MEDIA_SOURCE_PROP = 'KPM.StudioLogos.LastMediaSource'
STUDIO_LAST_MEDIA_UPDATED_AT_PROP = 'KPM.StudioLogos.LastMediaUpdatedAt'
STUDIO_RESOLVE_INTERVAL_SECONDS = 0.15
STUDIO_EMPTY_CLEAR_SECONDS = 999999.0
BROKEN_STUDIO_TEXTURE_NAMES = {
    'centropolis entertainment.png',
    'dune entertainment.png',
    'gk films.png',
    'thunder road.png',
}



def translate(path: str) -> str:
    if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if xbmc and hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return path


def log(message: str, level=None) -> None:
    if xbmc:
        xbmc.log(LOG_PREFIX + message, level or xbmc.LOGINFO)
    else:
        print(LOG_PREFIX + message)


def cond(expression: str) -> bool:
    try:
        return bool(xbmc.getCondVisibility(expression)) if xbmc else False
    except Exception:
        return False


def info(label: str) -> str:
    try:
        return xbmc.getInfoLabel(label).strip() if xbmc else ''
    except Exception:
        return ''


def home_prop(name: str) -> str:
    try:
        return xbmcgui.Window(10000).getProperty(name) if xbmcgui else ''
    except Exception:
        return ''


def window_prop(window_id: int, name: str) -> str:
    try:
        return xbmcgui.Window(window_id).getProperty(name).strip() if xbmcgui else ''
    except Exception:
        return ''


def any_window_prop(*names: str) -> str:
    window_ids = []
    for wid in (10000, current_window_id()):
        if isinstance(wid, int) and wid > 0 and wid not in window_ids:
            window_ids.append(wid)
    for wid in window_ids:
        for name in names:
            value = window_prop(wid, name)
            if value:
                return value
    return ''


def set_home_prop(name: str, value: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).setProperty(name, value)
    except Exception:
        pass


def clear_home_prop(name: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).clearProperty(name)
    except Exception:
        pass


def set_current_window_prop(name: str, value: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(current_window_id()).setProperty(name, value)
    except Exception:
        pass


def clear_current_window_prop(name: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(current_window_id()).clearProperty(name)
    except Exception:
        pass


def current_window_id() -> int:
    try:
        return int(xbmcgui.getCurrentWindowId()) if xbmcgui else -1
    except Exception:
        return -1


def current_dialog_id() -> int:
    try:
        return int(xbmcgui.getCurrentWindowDialogId()) if xbmcgui else NO_DIALOG_ID
    except Exception:
        return NO_DIALOG_ID


def addon_data_path(*parts: str) -> str:
    base = translate(f'special://profile/addon_data/{ADDON_ID}')
    return os.path.join(base, *parts)


def state_file(patch_id: str) -> str:
    return addon_data_path('runtime', 'state', f'{patch_id}.json')


def load_json_file(path: str) -> dict:
    with open(path, 'r', encoding='utf-8', errors='replace') as handle:
        return json.load(handle)


def patch_state_enabled(patch_id: str) -> bool:
    return os.path.exists(state_file(patch_id))


def pause_patch_enabled() -> bool:
    path = state_file('vfs_pause_ratings')
    if not os.path.exists(path):
        return False
    try:
        data = load_json_file(path)
        return bool(data.get('auto_videoosd') and data.get('pause_stay_until_resume'))
    except Exception:
        return True


def studio_patch_enabled() -> bool:
    return patch_state_enabled('reliable_studio_logos')


def load_kpm_settings() -> dict:
    data = {'studio_logo_count': 1, 'studio_debug': False}
    path = addon_data_path('settings.json')
    if os.path.exists(path):
        try:
            loaded = load_json_file(path)
            if isinstance(loaded, dict):
                data.update(loaded)
        except Exception:
            pass
    try:
        count = int(data.get('studio_logo_count', 1))
    except Exception:
        count = 1
    data['studio_logo_count'] = 1
    return data


def is_foreign_dialog(active_dialog_id: int) -> bool:
    return active_dialog_id not in KNOWN_OSD_DIALOG_IDS


def close_video_osd_safely() -> None:
    try:
        xbmc.executebuiltin('CancelAlarm(osd_timeout,true)')
        xbmc.executebuiltin('Dialog.Close(videoosd,true)')
        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
    except Exception:
        log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def _read_xbt_filenames(path: str) -> list[str]:
    try:
        with open(path, 'rb') as handle:
            data = handle.read()
    except Exception:
        return []
    names = []
    # Kodi XBTF2 texture packs used by the studio resources have a 5-byte magic,
    # a 4-byte little-endian file count, then 304-byte file records with a
    # null-terminated 256-byte filename at the start of each record.
    if data.startswith(b'XBTF2') and len(data) >= 9:
        try:
            count = int.from_bytes(data[5:9], 'little')
            step = 304
            start = 9
            for idx in range(count):
                off = start + idx * step
                raw = data[off:off + 256]
                if not raw:
                    break
                name = raw.split(b'\x00', 1)[0].decode('utf-8', 'ignore').strip()
                if name.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                    names.append(name.replace('\\', '/'))
            if names:
                return names
        except Exception:
            pass
    # Conservative fallback: scan the header/table for image-looking strings.
    for match in re.finditer(rb'([A-Za-z0-9][A-Za-z0-9 _.,&+!\'()\-]{1,180}\.(?:png|jpg|jpeg|webp))\x00', data[:4_000_000], re.I):
        try:
            names.append(match.group(1).decode('utf-8', 'ignore').strip().replace('\\', '/'))
        except Exception:
            pass
    return list(dict.fromkeys(names))


def _walk_resource_images(resource_dir: str) -> list[str]:
    found = []
    for root, _dirs, files in os.walk(resource_dir):
        for filename in files:
            if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                rel = os.path.relpath(os.path.join(root, filename), resource_dir).replace('\\', '/')
                found.append(rel)
    return found


def _strip_ext(name: str) -> str:
    base = os.path.basename(name.replace('\\', '/'))
    return re.sub(r'\.(png|jpg|jpeg|webp)$', '', base, flags=re.I).strip()


def _simple_key(value: str) -> str:
    value = unquote(value or '').lower().strip()
    value = value.replace('&', ' and ').replace('+', ' plus ')
    value = re.sub(r'\([^)]*\)', ' ', value)
    value = re.sub(r'[^a-z0-9]+', ' ', value)
    value = re.sub(r'\s+', ' ', value).strip()
    return value


def _drop_company_suffixes(key: str) -> str:
    suffixes = {
        'ltd', 'limited', 'inc', 'llc', 'gmbh', 'ag', 's a', 'sa', 's r l', 'srl',
        'co', 'company', 'corp', 'corporation', 'productions', 'production',
        'pictures', 'picture', 'films', 'film', 'studios', 'studio', 'entertainment'
    }
    parts = key.split()
    while parts and ' '.join(parts[-3:]) in suffixes:
        parts = parts[:-3]
    while parts and ' '.join(parts[-2:]) in suffixes:
        parts = parts[:-2]
    while parts and parts[-1] in suffixes:
        parts = parts[:-1]
    return ' '.join(parts).strip()


def _logo_keys(name: str) -> list[str]:
    raw = _strip_ext(name)
    raw = unquote(raw).strip()
    variants = [raw]
    variants.append(re.sub(r'\s*\([^)]*\)\s*$', '', raw).strip())
    variants.append(raw.replace(' Ltd.', '').replace(' Ltd', '').replace(' Inc.', '').replace(' Inc', '').replace(' LLC', '').strip())
    keys = []
    for variant in variants:
        key = _simple_key(variant)
        if key:
            keys.append(key)
            short = _drop_company_suffixes(key)
            if short and short != key:
                keys.append(short)
    alias_map = {
        'prime video': 'amazon prime video',
        'amazon video': 'amazon prime video',
        'fox searchlight': 'fox searchlight pictures',
        'searchlight': 'searchlight pictures',
        'lucasfilm ltd': 'lucasfilm',
        # Common game-studio credit variants from Steam / publisher metadata.
        'ea': 'electronic arts',
        'ea games': 'electronic arts',
        'ea sports': 'electronic arts',
        'rockstar games inc': 'rockstar games',
        'rockstar north ltd': 'rockstar north',
        'valve': 'valve corporation',
        'valve software': 'valve corporation',
        'microsoft studios': 'microsoft game studios',
        'sony interactive entertainment': 'playstation',
        'sony interactive entertainment llc': 'playstation',
        'bethesda softworks': 'bethesda',
        'bethesda softworks llc': 'bethesda',
        'square enix ltd': 'square enix',
        'square enix inc': 'square enix',
        'square enix co ltd': 'square enix',
    }
    for key in list(keys):
        alias = alias_map.get(key)
        if alias:
            keys.append(alias)
    return list(dict.fromkeys(keys))



def _studio_index_cache_path(resource_id: str = STUDIO_RESOURCE_ID) -> str:
    suffix = 'gamestudios-grayscale-v1' if resource_id == GAME_STUDIO_RESOURCE_ID else 'coloured-v2'
    return addon_data_path('cache', f'studio-logo-index-{suffix}.json')


def _set_index_status_props(resource_id: str, *, file_count: int = 0, status: str = '', cache: str = '', build_ms: str = '', broken_skipped: int | None = None) -> None:
    if resource_id == GAME_STUDIO_RESOURCE_ID:
        set_home_prop(GAME_STUDIO_AVAILABLE_PROP, str(file_count))
        if status:
            set_home_prop(GAME_STUDIO_STATUS_PROP, status)
        if cache:
            set_home_prop(GAME_STUDIO_CACHE_PROP, cache)
        if build_ms:
            set_home_prop(GAME_STUDIO_INDEX_BUILD_MS_PROP, build_ms)
        return
    set_home_prop(STUDIO_AVAILABLE_PROP, str(file_count))
    if status:
        set_home_prop(STUDIO_STATUS_PROP, status)
    if cache:
        set_home_prop(STUDIO_CACHE_PROP, cache)
    if build_ms:
        set_home_prop(STUDIO_INDEX_BUILD_MS_PROP, build_ms)
    if broken_skipped is not None:
        set_home_prop(STUDIO_BROKEN_SKIPPED_PROP, str(broken_skipped))


def _file_signature(path: str) -> dict:
    try:
        return {
            'path': path,
            'size': int(os.path.getsize(path)),
            'mtime': float(os.path.getmtime(path)),
        }
    except Exception:
        return {'path': path, 'size': -1, 'mtime': -1.0}


def _load_cached_studio_index(texture_path: str, resource_id: str = STUDIO_RESOURCE_ID) -> dict[str, str]:
    cache_path = _studio_index_cache_path(resource_id)
    if not os.path.exists(cache_path):
        return {}
    try:
        data = load_json_file(cache_path)
        if not isinstance(data, dict):
            return {}
        if data.get('resource_id') != resource_id:
            return {}
        if data.get('texture_signature') != _file_signature(texture_path):
            return {}
        index = data.get('index')
        if not isinstance(index, dict):
            return {}
        _set_index_status_props(
            resource_id,
            file_count=int(data.get('file_count', 0)),
            status='ready',
            cache='hit',
            build_ms='0',
            broken_skipped=int(data.get('broken_skipped', 0)),
        )
        log(f'studio logo index cache hit; resource={resource_id}; files={data.get("file_count", 0)}, keys={len(index)}')
        return {str(k): str(v) for k, v in index.items()}
    except Exception:
        return {}


def _save_cached_studio_index(texture_path: str, filenames_count: int, index: dict[str, str], broken_skipped: int, resource_id: str = STUDIO_RESOURCE_ID) -> None:
    cache_path = _studio_index_cache_path(resource_id)
    try:
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        payload = {
            'resource_id': resource_id,
            'generated': time.strftime('%Y-%m-%d %H:%M:%S'),
            'texture_signature': _file_signature(texture_path),
            'file_count': filenames_count,
            'key_count': len(index),
            'broken_skipped': broken_skipped,
            'index': index,
        }
        with open(cache_path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, separators=(',', ':'))
    except Exception:
        pass


def build_studio_logo_index(resource_id: str = STUDIO_RESOURCE_ID) -> dict[str, str]:
    started = time.time()
    addon_dir = translate(f'special://home/addons/{resource_id}')
    resource_dir = os.path.join(addon_dir, 'resources')
    texture_path = os.path.join(resource_dir, 'Textures.xbt')
    cached = _load_cached_studio_index(texture_path, resource_id)
    if cached:
        return cached

    filenames = []
    if os.path.exists(texture_path):
        filenames.extend(_read_xbt_filenames(texture_path))
    if os.path.isdir(resource_dir):
        filenames.extend(_walk_resource_images(resource_dir))
    filenames = list(dict.fromkeys(filenames))
    ranked: dict[str, tuple[int, str]] = {}
    broken_skipped = 0
    for filename in filenames:
        clean = filename.replace('\\', '/')
        if _is_broken_studio_texture(clean):
            broken_skipped += 1
            continue
        uri = f'resource://{resource_id}/{clean}'
        stem = _strip_ext(clean)
        # Prefer exact flat names over regional/parenthetical variants when two
        # filenames normalize to the same studio key, e.g. prefer
        # "universal pictures.png" over "universal pictures (spain).png".
        base_score = 0
        if '(' in stem or ')' in stem:
            base_score += 20
        if '/' in clean:
            base_score += 10
        base_score += min(9, len(stem) // 30)
        for pos, key in enumerate(_logo_keys(clean)):
            score = base_score + pos
            old = ranked.get(key)
            if old is None or score < old[0]:
                ranked[key] = (score, uri)
    index = {key: uri for key, (_score, uri) in ranked.items()}
    elapsed_ms = int((time.time() - started) * 1000)
    _set_index_status_props(
        resource_id,
        file_count=len(filenames),
        status='ready' if index else 'no-resource',
        cache='rebuilt',
        build_ms=str(elapsed_ms),
        broken_skipped=broken_skipped,
    )
    _save_cached_studio_index(texture_path, len(filenames), index, broken_skipped, resource_id)
    log(f'studio logo index ready; resource={resource_id}; files={len(filenames)}, keys={len(index)}, skipped_broken={broken_skipped}, build_ms={elapsed_ms}')
    return index


def _latest_video_db_path() -> str:
    db_dir = translate('special://profile/Database')
    if not os.path.isdir(db_dir):
        db_dir = translate('special://database')
    if not os.path.isdir(db_dir):
        return ''
    best_path = ''
    best_num = -1
    try:
        for fname in os.listdir(db_dir):
            match = re.match(r'MyVideos(\d+)\.db$', fname, re.I)
            if not match:
                continue
            num = int(match.group(1))
            if num > best_num:
                best_num = num
                best_path = os.path.join(db_dir, fname)
    except Exception:
        return ''
    return best_path


def _episode_contexts() -> list[tuple[str, int]]:
    contexts: list[tuple[str, int]] = []
    for prefix in ('ListItem', 'Container.ListItem', 'VideoPlayer'):
        dbtype = (info(f'{prefix}.DBTYPE') or '').lower().strip()
        dbid = _safe_int(info(f'{prefix}.DBID'))
        is_episode = dbtype == 'episode'
        if prefix == 'VideoPlayer' and not is_episode and cond('VideoPlayer.Content(episodes)'):
            is_episode = True
        if dbid > 0 and is_episode:
            contexts.append((prefix, dbid))
    seen = set()
    deduped = []
    for prefix, dbid in contexts:
        if dbid not in seen:
            seen.add(dbid)
            deduped.append((prefix, dbid))
    return deduped


def _media_contexts() -> list[tuple[str, str, int, str]]:
    contexts: list[tuple[str, str, int, str]] = []
    for prefix in ('ListItem', 'Container.ListItem', 'VideoPlayer'):
        dbtype = (info(f'{prefix}.DBTYPE') or '').lower().strip()
        dbid = _safe_int(info(f'{prefix}.DBID'))
        label = info(f'{prefix}.Label') if prefix != 'VideoPlayer' else info('VideoPlayer.Title')
        if prefix == 'VideoPlayer' and not dbtype:
            if cond('VideoPlayer.Content(movies)'):
                dbtype = 'movie'
            elif cond('VideoPlayer.Content(tvshows)'):
                dbtype = 'tvshow'
            elif cond('VideoPlayer.Content(episodes)'):
                dbtype = 'episode'
        if dbid > 0 and dbtype in ('movie', 'tvshow', 'episode', 'season', 'set'):
            contexts.append((prefix, dbtype, dbid, label))
    seen = set()
    deduped = []
    for item in contexts:
        key = (item[1], item[2])
        if key not in seen:
            seen.add(key)
            deduped.append(item)
    return deduped


def _set_last_media_props(candidates: list[str], resolved: list[tuple[str, str]]) -> None:
    contexts = _media_contexts()
    label = dbtype = dbid = ''
    if contexts:
        _prefix, dbtype, dbid_int, label = contexts[0]
        dbid = str(dbid_int)
    else:
        game_contexts = _game_contexts()
        if game_contexts:
            gctx = game_contexts[0]
            label = gctx.get('label', '')
            dbtype = 'game'
            dbid = gctx.get('appid', '')
    source = home_prop(STUDIO_SOURCE_PROP)
    set_home_prop(STUDIO_LAST_MEDIA_LABEL_PROP, label)
    set_home_prop(STUDIO_LAST_MEDIA_DBID_PROP, dbid)
    set_home_prop(STUDIO_LAST_MEDIA_DBTYPE_PROP, dbtype)
    set_home_prop(STUDIO_LAST_MEDIA_CANDIDATES_PROP, ' | '.join(candidates[:20]))
    set_home_prop(STUDIO_LAST_MEDIA_RESOLVED_PROP, ' | '.join([f'{name} => {uri}' for name, uri in resolved[:1]]))
    set_home_prop(STUDIO_LAST_MEDIA_SOURCE_PROP, source)
    set_home_prop(STUDIO_LAST_MEDIA_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))


def _load_media_studios(media_type: str, media_id: int, media_cache: dict[tuple[str, int], dict], stats: dict | None = None) -> dict:
    if media_type not in ('movie', 'tvshow') or media_id <= 0:
        return {'media_type': media_type, 'media_id': media_id, 'studios': [], 'source': 'invalid_media'}
    key = (media_type, media_id)
    cached = media_cache.get(key)
    if cached is not None:
        return cached
    started = time.time()
    result = {'media_type': media_type, 'media_id': media_id, 'studios': [], 'source': f'{media_type}_db'}
    db_path = _latest_video_db_path()
    if not db_path or not os.path.exists(db_path):
        result['source'] = 'no_video_db'
        media_cache[key] = result
        return result
    try:
        con = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=0.15)
        cur = con.cursor()
        try:
            studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type=? AND sl.media_id=? ORDER BY sl.rowid", (media_type, media_id)) if r and r[0]]
        except Exception:
            studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type=? AND sl.media_id=?", (media_type, media_id)) if r and r[0]]
        result['studios'] = studios
        if not studios:
            result['source'] = f'{media_type}_db_no_studio'
        con.close()
    except Exception as exc:
        result['source'] = 'db_error'
        result['error'] = str(exc)
    elapsed_ms = int((time.time() - started) * 1000)
    set_home_prop(STUDIO_DB_LOOKUP_LAST_MS_PROP, str(elapsed_ms))
    if stats is not None:
        stats['db_lookup_count'] = int(stats.get('db_lookup_count', 0)) + 1
        set_home_prop(STUDIO_DB_LOOKUP_COUNT_PROP, str(stats['db_lookup_count']))
    media_cache[key] = result
    if len(media_cache) > 500:
        for old_key in list(media_cache.keys())[:100]:
            media_cache.pop(old_key, None)
    return result


def _load_parent_tvshow_studios_for_episode(episode_id: int, episode_cache: dict[int, dict], stats: dict | None = None) -> dict:
    if episode_id <= 0:
        return {'episode_id': episode_id, 'id_show': 0, 'show_title': '', 'studios': [], 'source': 'invalid_episode_id'}
    cached = episode_cache.get(episode_id)
    if cached is not None:
        return cached

    started = time.time()
    result = {'episode_id': episode_id, 'id_show': 0, 'show_title': '', 'studios': [], 'source': 'parent_tvshow_db'}
    db_path = _latest_video_db_path()
    if not db_path or not os.path.exists(db_path):
        result['source'] = 'no_video_db'
        episode_cache[episode_id] = result
        return result
    try:
        con = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=0.15)
        cur = con.cursor()
        row = cur.execute('SELECT e.idShow, COALESCE(t.c00, \'\') FROM episode e LEFT JOIN tvshow t ON t.idShow=e.idShow WHERE e.idEpisode=?', (episode_id,)).fetchone()
        if not row:
            result['source'] = 'episode_not_found'
        else:
            id_show = int(row[0] or 0)
            result['id_show'] = id_show
            result['show_title'] = row[1] or ''
            if id_show > 0:
                try:
                    studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type='tvshow' AND sl.media_id=? ORDER BY sl.rowid", (id_show,)) if r and r[0]]
                except Exception:
                    studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type='tvshow' AND sl.media_id=?", (id_show,)) if r and r[0]]
                result['studios'] = studios
                if not studios:
                    result['source'] = 'parent_tvshow_no_studio'
        con.close()
    except Exception as exc:
        result['source'] = 'db_error'
        result['error'] = str(exc)
    elapsed_ms = int((time.time() - started) * 1000)
    set_home_prop(STUDIO_DB_LOOKUP_LAST_MS_PROP, str(elapsed_ms))
    if stats is not None:
        stats['db_lookup_count'] = int(stats.get('db_lookup_count', 0)) + 1
        set_home_prop(STUDIO_DB_LOOKUP_COUNT_PROP, str(stats['db_lookup_count']))
    episode_cache[episode_id] = result
    # Keep the cache bounded because focus can move through many episode widgets.
    if len(episode_cache) > 500:
        for key in list(episode_cache.keys())[:100]:
            episode_cache.pop(key, None)
    return result



def _info_prop(prefix: str, name: str) -> str:
    return info(f'{prefix}.Property({name})')


def _game_contexts() -> list[dict[str, str]]:
    contexts: list[dict[str, str]] = []
    for prefix in ('Container.ListItem', 'ListItem'):
        appid = _info_prop(prefix, 'steam_appid') or _info_prop(prefix, 'appid')
        platform = (_info_prop(prefix, 'platform') or _info_prop(prefix, 'steam_platform')).lower().strip()
        is_steam = (_info_prop(prefix, 'is_steam_library') or '').lower().strip() == 'true'
        dbtype = (info(f'{prefix}.DBTYPE') or '').lower().strip()
        path = info(f'{prefix}.FileNameAndPath') or info(f'{prefix}.FolderPath')
        if not (is_steam or platform == 'steam' or appid or dbtype == 'game' or 'plugin.program.steam.library' in path):
            continue
        label = info(f'{prefix}.Label') or info(f'{prefix}.Title')
        developer = _info_prop(prefix, 'developer') or _info_prop(prefix, 'developer_display')
        publisher = _info_prop(prefix, 'publisher') or _info_prop(prefix, 'publisher_display')
        contexts.append({
            'prefix': prefix,
            'appid': appid,
            'label': label,
            'developer': developer,
            'publisher': publisher,
            'platform': platform or ('steam' if is_steam or appid else ''),
        })
    seen = set()
    deduped = []
    for ctx in contexts:
        key = (ctx.get('appid') or '', _simple_key(ctx.get('label') or ''))
        if key not in seen:
            seen.add(key)
            deduped.append(ctx)
    return deduped


def _split_game_credit_label(value: str) -> list[str]:
    value = (value or '').strip()
    if not value or value.upper() == 'N/A':
        return []
    parts = _split_studio_label(value)
    expanded = []
    for part in parts:
        expanded.append(part)
        # Steam metadata commonly stores multiple developers/publishers as comma
        # separated text. Keep the full credit too so names like "2015, Inc." can
        # still match, but also try each comma piece as a candidate.
        for comma_part in re.split(r'\s*,\s*', part):
            comma_part = comma_part.strip()
            if comma_part and comma_part.upper() != 'N/A':
                expanded.append(comma_part)
    deduped = []
    seen = set()
    for item in expanded:
        key = _simple_key(item)
        if key and key not in seen:
            seen.add(key)
            deduped.append(item)
    return deduped


def collect_game_studio_candidates() -> list[str]:
    contexts = _game_contexts()
    if not contexts:
        return []
    ctx = contexts[0]
    candidates: list[str] = []
    dev_count = 0
    pub_count = 0
    before = len(candidates)
    candidates.extend(_split_game_credit_label(ctx.get('developer', '')))
    dev_count = len(candidates) - before
    before = len(candidates)
    candidates.extend(_split_game_credit_label(ctx.get('publisher', '')))
    pub_count = len(candidates) - before
    deduped = []
    seen = set()
    for item in candidates:
        key = _simple_key(item)
        if key and key not in seen:
            seen.add(key)
            deduped.append(item)
    if dev_count and pub_count:
        source = 'game_developer+publisher'
    elif dev_count:
        source = 'game_developer'
    elif pub_count:
        source = 'game_publisher'
    else:
        source = 'game_no_credit'
    set_home_prop(STUDIO_SOURCE_PROP, source)
    clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_ID_PROP)
    clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP)
    return deduped


def collect_studio_candidates(episode_cache: dict[int, dict] | None = None, stats: dict | None = None, media_cache: dict[tuple[str, int], dict] | None = None) -> list[str]:
    candidates: list[str] = []
    direct_count = 0
    for label in ('Container.ListItem.Studio', 'ListItem.Studio', 'VideoPlayer.Studio'):
        before = len(candidates)
        candidates.extend(_split_studio_label(info(label)))
        direct_count += len(candidates) - before
    for idx in range(1, 11):
        before = len(candidates)
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.ListItem.Studio.{idx}.Name')))
        direct_count += len(candidates) - before
    for idx in range(1, 6):
        before = len(candidates)
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.ListItem.Network.{idx}.Name')))
        direct_count += len(candidates) - before
    for idx in range(1, 6):
        before = len(candidates)
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.Player.Studio.{idx}.Name')))
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.Player.Network.{idx}.Name')))
        direct_count += len(candidates) - before

    db_direct_count = 0
    db_direct_source = ''
    if media_cache is not None:
        for _prefix, dbtype, dbid, _label in _media_contexts():
            if dbtype in ('movie', 'tvshow'):
                db_res = _load_media_studios(dbtype, dbid, media_cache, stats)
                db_direct_source = db_res.get('source', '') or f'{dbtype}_db'
                before = len(candidates)
                candidates.extend(_split_studio_label(' / '.join(db_res.get('studios') or [])))
                db_direct_count += len(candidates) - before
                if db_direct_count:
                    break

    parent_count = 0
    parent_source = ''
    parent_show_id = 0
    parent_show_title = ''
    if episode_cache is not None:
        for prefix, episode_id in _episode_contexts():
            parent = _load_parent_tvshow_studios_for_episode(episode_id, episode_cache, stats)
            parent_source = parent.get('source', '') or 'parent_tvshow_db'
            parent_show_id = int(parent.get('id_show') or 0)
            parent_show_title = parent.get('show_title', '') or ''
            before = len(candidates)
            candidates.extend(_split_studio_label(' / '.join(parent.get('studios') or [])))
            parent_count += len(candidates) - before
            if parent_count:
                break

    deduped = []
    seen = set()
    for item in candidates:
        key = _simple_key(item)
        if key and key not in seen:
            seen.add(key)
            deduped.append(item)

    if direct_count and db_direct_count and parent_count:
        source = 'direct+media_db+parent_tvshow_db'
    elif direct_count and db_direct_count:
        source = 'direct+media_db'
    elif direct_count and parent_count:
        source = 'direct+parent_tvshow_db'
    elif db_direct_count and parent_count:
        source = 'media_db+parent_tvshow_db'
    elif parent_count:
        source = 'parent_tvshow_db'
    elif db_direct_count:
        source = db_direct_source or 'media_db'
    elif direct_count:
        source = 'direct'
    elif parent_source:
        source = parent_source
    else:
        source = 'none'
    set_home_prop(STUDIO_SOURCE_PROP, source)
    if parent_show_id > 0:
        set_home_prop(STUDIO_EPISODE_PARENT_SHOW_ID_PROP, str(parent_show_id))
        set_home_prop(STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP, parent_show_title)
    else:
        clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_ID_PROP)
        clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP)
    return deduped

def resolve_studio_logos(index: dict[str, str], count: int) -> list[tuple[str, str]]:
    resolved: list[tuple[str, str]] = []
    seen_uris = set()
    for name in collect_studio_candidates():
        uri = ''
        for key in _logo_keys(name):
            uri = index.get(key, '')
            if uri:
                break
        if uri and uri not in seen_uris:
            resolved.append((name, uri))
            seen_uris.add(uri)
        if len(resolved) >= count:
            break
    return resolved


def clear_studio_props() -> None:
    for idx in range(1, 4):
        clear_home_prop(f'{STUDIO_PROP_PREFIX}{idx}')
        clear_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}')
    clear_home_prop(STUDIO_COUNT_PROP)
    clear_home_prop(STUDIO_CANDIDATES_PROP)
    clear_home_prop(STUDIO_RESOLVED_PROP)
    clear_home_prop(STUDIO_MISSING_PROP)
    clear_home_prop(STUDIO_UPDATED_AT_PROP)
    clear_home_prop(STUDIO_SHOW_PROP)
    clear_home_prop(STUDIO_CONTEXT_PROP)
    clear_home_prop(STUDIO_RESOLVE_LAST_MS_PROP)
    clear_home_prop(STUDIO_RESOLVE_MAX_MS_PROP)
    clear_home_prop(STUDIO_RESOLVE_COUNT_PROP)
    clear_home_prop(STUDIO_SOURCE_PROP)
    clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_ID_PROP)
    clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP)
    clear_home_prop(STUDIO_DB_LOOKUP_LAST_MS_PROP)
    clear_home_prop(STUDIO_DB_LOOKUP_COUNT_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_LABEL_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_DBID_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_DBTYPE_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_CANDIDATES_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_RESOLVED_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_SOURCE_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_UPDATED_AT_PROP)


def update_studio_logo_props(
    index: dict[str, str],
    game_index: dict[str, str] | None,
    count: int,
    force: bool = False,
    last_key: str = '',
    empty_since: float = 0.0,
    debug: bool = False,
    stats: dict | None = None,
    episode_cache: dict[int, dict] | None = None,
    media_cache: dict[tuple[str, int], dict] | None = None,
) -> tuple[str, float]:
    started = time.time()
    count = 1
    game_contexts = _game_contexts()
    if game_contexts:
        studios = collect_game_studio_candidates()
        active_index = game_index or {}
        active_resource_id = GAME_STUDIO_RESOURCE_ID
    else:
        studios = collect_studio_candidates(episode_cache, stats, media_cache)
        active_index = index
        active_resource_id = STUDIO_RESOURCE_ID
    now = time.time()

    if not studios:
        # No active media context, usually because focus moved into an add-on/menu/dialog.
        # Keep KPM.StudioLogo.1 cached, but hide the furniture logo through a separate
        # visibility flag. This avoids stale logos in non-media menus without clearing
        # the last valid resolved logo needed by diagnostics and quick focus returns.
        set_home_prop(STUDIO_SHOW_PROP, 'false')
        set_home_prop(STUDIO_CONTEXT_PROP, 'non_media')
        set_home_prop(STUDIO_CANDIDATES_PROP, '')
        set_home_prop(STUDIO_RESOLVED_PROP, home_prop(STUDIO_LAST_MEDIA_RESOLVED_PROP))
        set_home_prop(STUDIO_MISSING_PROP, '')
        set_home_prop(STUDIO_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))
        set_home_prop(STUDIO_COUNT_PROP, '1')
        if empty_since <= 0.0:
            empty_since = now
        return last_key, empty_since

    empty_since = 0.0
    key = active_resource_id + '|' + '|'.join(studios) + f'|count={count}'
    if not force and key == last_key:
        # Same focused media after a menu/dialog temporarily hid the footer: do not
        # wait for a later focus change. If a valid logo is already cached, make it
        # visible immediately; otherwise keep it hidden for this media item.
        if home_prop(f'{STUDIO_PROP_PREFIX}1'):
            set_home_prop(STUDIO_SHOW_PROP, 'true')
            set_home_prop(STUDIO_CONTEXT_PROP, 'media_cached_logo')
            if not home_prop(STUDIO_CANDIDATES_PROP):
                set_home_prop(STUDIO_CANDIDATES_PROP, ' | '.join(studios[:20]))
        else:
            set_home_prop(STUDIO_SHOW_PROP, 'false')
            set_home_prop(STUDIO_CONTEXT_PROP, 'media_no_logo')
        return last_key, empty_since

    resolved: list[tuple[str, str]] = []
    missing: list[str] = []
    broken: list[str] = []
    seen_uris = set()
    for name in studios:
        uri = ''
        for logo_key in _logo_keys(name):
            uri = active_index.get(logo_key, '')
            if uri:
                break
        if uri and _is_broken_studio_texture(uri):
            broken.append(name)
            uri = ''
        if uri:
            if uri not in seen_uris and len(resolved) < count:
                resolved.append((name, uri))
            seen_uris.add(uri)
        else:
            missing.append(name)

    for idx in range(1, 4):
        if idx <= len(resolved):
            name, uri = resolved[idx - 1]
            set_home_prop(f'{STUDIO_PROP_PREFIX}{idx}', uri)
            set_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}', name)
        else:
            clear_home_prop(f'{STUDIO_PROP_PREFIX}{idx}')
            clear_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}')
    elapsed_ms = int((time.time() - started) * 1000)
    if stats is not None:
        stats['resolve_count'] = int(stats.get('resolve_count', 0)) + 1
        stats['resolve_max_ms'] = max(int(stats.get('resolve_max_ms', 0)), elapsed_ms)
        set_home_prop(STUDIO_RESOLVE_COUNT_PROP, str(stats['resolve_count']))
        set_home_prop(STUDIO_RESOLVE_MAX_MS_PROP, str(stats['resolve_max_ms']))
    set_home_prop(STUDIO_RESOLVE_LAST_MS_PROP, str(elapsed_ms))
    set_home_prop(STUDIO_COUNT_PROP, str(count))
    set_home_prop(STUDIO_SHOW_PROP, 'true' if resolved else 'false')
    set_home_prop(STUDIO_CONTEXT_PROP, 'media_with_logo' if resolved else 'media_no_logo')
    set_home_prop(STUDIO_CANDIDATES_PROP, ' | '.join(studios[:20]))
    set_home_prop(STUDIO_RESOLVED_PROP, ' | '.join([f'{name} => {uri}' for name, uri in resolved[:3]]))
    missing_all = missing[:20]
    if broken:
        missing_all = (missing_all + [f'BROKEN_TEXTURE:{x}' for x in broken])[:20]
    set_home_prop(STUDIO_MISSING_PROP, ' | '.join(missing_all))
    set_home_prop(STUDIO_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))
    if studios:
        _set_last_media_props(studios, resolved)
    if debug:
        if resolved:
            log('studio logos: ' + ' | '.join([f'{name} -> {uri}' for name, uri in resolved]) + f' ({elapsed_ms}ms)')
        elif studios:
            log('studio logos: no valid match; candidates=' + ' | '.join(studios[:6]) + f' ({elapsed_ms}ms)')
    return key, empty_since





def main() -> None:
    if not xbmc:
        return

    if home_prop(ACTIVE_PROP) == 'true':
        log('already running; exiting duplicate instance')
        return

    set_home_prop(ACTIVE_PROP, 'true')
    monitor = xbmc.Monitor()
    armed = home_prop(ARMED_PROP) == 'true'
    try:
        armed_dialog_id = int(home_prop(ARMED_DIALOG_PROP) or '0')
    except Exception:
        armed_dialog_id = 0

    log('started; movie/tv/game studio resolver and pause monitor')
    pause_since = 0.0
    last_foreign_dialog = 0
    playback_started_at = 0.0
    last_has_video = False
    studio_index: dict[str, str] = {}
    game_studio_index: dict[str, str] = {}
    studio_last_key = ''
    studio_empty_since = 0.0
    studio_stats = {'resolve_count': 0, 'resolve_max_ms': 0, 'db_lookup_count': 0}
    episode_studio_cache: dict[int, dict] = {}
    media_studio_cache: dict[tuple[str, int], dict] = {}
    studio_enabled_cached = False
    studio_count_cached = 1
    studio_debug_cached = False
    last_config_check = 0.0
    last_studio_update = 0.0
    try:
        while not monitor.abortRequested():
            now = time.time()
            if now - last_config_check >= 1.0:
                last_config_check = now
                studio_enabled_cached = studio_patch_enabled()
                settings_cached = load_kpm_settings()
                studio_count_cached = 1
                studio_debug_cached = bool(settings_cached.get('studio_debug')) or home_prop(STUDIO_DEBUG_PROP).lower() == 'true'
                if studio_enabled_cached and not studio_index:
                    studio_index = build_studio_logo_index(STUDIO_RESOURCE_ID)
                if studio_enabled_cached and not game_studio_index:
                    game_studio_index = build_studio_logo_index(GAME_STUDIO_RESOURCE_ID)
                if not studio_enabled_cached:
                    studio_last_key = ''
                    studio_empty_since = 0.0
                    clear_studio_props()

            if studio_enabled_cached and (studio_index or game_studio_index) and now - last_studio_update >= STUDIO_RESOLVE_INTERVAL_SECONDS:
                last_studio_update = now
                try:
                    studio_last_key, studio_empty_since = update_studio_logo_props(studio_index, game_studio_index, 1, False, studio_last_key, studio_empty_since, studio_debug_cached, studio_stats, episode_studio_cache, media_studio_cache)
                except Exception:
                    log('studio resolver error:\n' + traceback.format_exc(), xbmc.LOGWARNING)

            if not pause_patch_enabled():
                armed = False
                armed_dialog_id = 0
                pause_since = 0.0
                last_foreign_dialog = 0
                playback_started_at = 0.0
                last_has_video = False
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                clear_home_prop(PAUSE_SINCE_PROP)
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)
                monitor.waitForAbort(KPM_WAIT_IDLE_SECONDS if studio_enabled_cached else KPM_WAIT_DEEP_IDLE_SECONDS)
                continue

            paused = cond('Player.Paused')
            playing = cond('Player.Playing')
            seeking = cond('Player.Seeking')
            has_video = cond('Player.HasVideo') or cond('Player.HasMedia')
            fullscreen_video = cond('Window.IsActive(VideoFullScreen.xml)') or cond('Window.IsActive(fullscreenvideo)')
            videoosd = cond('Window.IsActive(videoosd)') or cond('Window.IsVisible(videoosd)')
            dialog_id = current_dialog_id()
            foreign_dialog = is_foreign_dialog(dialog_id)

            if has_video and not last_has_video:
                playback_started_at = now
                log(f'video session detected; startup guard active for {STARTUP_GUARD_WINDOW_SECONDS:.1f}s')
            elif not has_video:
                playback_started_at = 0.0
            last_has_video = has_video

            if foreign_dialog:
                if dialog_id != last_foreign_dialog:
                    last_foreign_dialog = dialog_id
                    set_home_prop(LAST_FOREIGN_DIALOG_PROP, str(dialog_id))
                    log(f'foreign dialog active; KPM will not auto-open/close/focus VideoOSD; dialog_id={dialog_id}, window_id={current_window_id()}')
            else:
                last_foreign_dialog = 0
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)

            if has_video and paused and not seeking:
                if pause_since <= 0:
                    pause_since = time.time()
                    set_home_prop(PAUSE_SINCE_PROP, str(pause_since))
                if fullscreen_video and not videoosd and not foreign_dialog:
                    startup_age = (time.time() - playback_started_at) if playback_started_at > 0 else 999.0
                    grace = AUTO_OPEN_GRACE_SECONDS
                    grace_reason = 'normal-pause-no-delay'
                    if startup_age < STARTUP_GUARD_WINDOW_SECONDS:
                        grace = STARTUP_AUTO_DIALOG_GUARD_SECONDS
                        grace_reason = 'startup-dialog-guard'
                    if time.time() - pause_since >= grace:
                        log(f'paused with no foreign dialog; opening VideoOSD; grace={grace:.2f}s/{grace_reason}; dialog_id={dialog_id}, window_id={current_window_id()}')
                        try:
                            xbmc.executebuiltin('CancelAlarm(osd_timeout,true)')
                            xbmc.executebuiltin('ActivateWindow(videoosd)')
                        except Exception:
                            log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
                        monitor.waitForAbort(0.15)
                        continue
            else:
                pause_since = 0.0
                clear_home_prop(PAUSE_SINCE_PROP)

            if has_video and paused and videoosd:
                if not armed:
                    armed_dialog_id = dialog_id
                    set_home_prop(ARMED_DIALOG_PROP, str(armed_dialog_id))
                    log(f'armed while paused; dialog_id={armed_dialog_id}, window_id={current_window_id()}')
                armed = True
                set_home_prop(ARMED_PROP, 'true')

            if armed and has_video and playing and videoosd:
                if foreign_dialog:
                    monitor.waitForAbort(KPM_WAIT_PLAYBACK_SECONDS)
                    continue
                log(f'pause->play detected; closing VideoOSD safely; dialog_id={dialog_id}, armed_dialog_id={armed_dialog_id}')
                close_video_osd_safely()
                armed = False
                armed_dialog_id = 0
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                monitor.waitForAbort(0.4)
                continue

            if not has_video or (not paused and not playing):
                armed = False
                armed_dialog_id = 0
                pause_since = 0.0
                last_foreign_dialog = 0
                playback_started_at = 0.0
                last_has_video = False
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                clear_home_prop(PAUSE_SINCE_PROP)
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)

            if has_video:
                if paused or videoosd or armed:
                    wait_seconds = KPM_WAIT_FAST_SECONDS
                elif playing:
                    wait_seconds = KPM_WAIT_ACTIVE_SECONDS
                else:
                    wait_seconds = KPM_WAIT_PLAYBACK_SECONDS
            else:
                wait_seconds = KPM_WAIT_IDLE_SECONDS if studio_enabled_cached else KPM_WAIT_DEEP_IDLE_SECONDS
            monitor.waitForAbort(wait_seconds)
    finally:
        clear_home_prop(ACTIVE_PROP)
        clear_home_prop(ARMED_PROP)
        clear_home_prop(ARMED_DIALOG_PROP)
        clear_home_prop(PAUSE_SINCE_PROP)
        clear_home_prop(LAST_FOREIGN_DIALOG_PROP)
        log('stopped')


if __name__ == '__main__':
    main()

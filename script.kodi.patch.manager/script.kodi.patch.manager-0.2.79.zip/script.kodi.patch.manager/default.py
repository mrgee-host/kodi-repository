# -*- coding: utf-8 -*-
from __future__ import annotations

import sys

from resources.lib.main import run, run_diag_live, artwork_runtime_tools, apply_af2_colour_scheme_0277

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'artwork_runtime':
        artwork_runtime_tools()
    elif len(sys.argv) > 1 and sys.argv[1] == 'diag_live':
        try:
            duration = int(sys.argv[2]) if len(sys.argv) > 2 else 120
        except Exception:
            duration = 120
        run_diag_live(duration)
    elif len(sys.argv) > 1 and sys.argv[1] == 'af2_scheme':
        scheme = sys.argv[2] if len(sys.argv) > 2 else ''
        apply_af2_colour_scheme_0277(scheme, reload_skin=True)
    else:
        run()

Kodi Patch Manager 0.2.24 - R7 Fresh-Install Baseline

- Applies only current Arctic Fuse 3 patch definitions.
- Historical AF3 marker, malformed-XML, old VideoFullScreen, and old rating-row
  cleanup paths are not executed.
- Keeps current idempotent apply/status/remove, XML validation, atomic replacement,
  one ReloadSkin per batch, shared icons, and Cinema Pre-roll font installation.
- Uses the new Kodi Patch Manager icon supplied for the MrGee family.

Kodi Patch Manager 0.2.28

- Container.IsUpdating no longer hides the committed rating row.
- KPM.Visual.Ready controls replacement of the current row.
- Navigation focus keeps the last complete media row while the media panel remains visible.
- A new row replaces the old row only after the new canonical media item is ready.

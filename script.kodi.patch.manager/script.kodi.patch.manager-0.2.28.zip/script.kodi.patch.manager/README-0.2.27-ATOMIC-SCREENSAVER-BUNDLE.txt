KPM 0.2.27 ATOMIC SCREENSAVER BUNDLE

All three metadata panels are visible only when LRS reports BundleReady for the exact current mediahub_item_key.
This makes plot, rating and clearlogo/title fade together. Fanart remains the independent Arctic Mirage background crossfade.

Kodi Patch Manager 0.2.24
=========================

Current-only Arctic Fuse 3 integration owner for the Mr.Gee Kodi Family.

- Applies and removes only the R7 patch definitions.
- Keeps current idempotent markers, XML validation, atomic writes, and one ReloadSkin per batch.
- Installs Cinema Pre-roll fonts and the current KPM rating, Steam, studio-logo, screensaver, and pause-OSD integration.
- Does not run historical AF3 repair or patch-version conversion paths.
- Uses resource.images.kpm.studiologos 1.0.2.

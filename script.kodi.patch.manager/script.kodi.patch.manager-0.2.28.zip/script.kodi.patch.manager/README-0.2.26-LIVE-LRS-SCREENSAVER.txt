Kodi Patch Manager 0.2.26

- Restores LibraryRatings.Screensaver.* rendering with strict item-key guards.
- Removes the R9/R10 direct screensaver_* ListItem overlay renderer.
- Keeps normal Home/Hub keep-last transitions unchanged.
- Keeps Cinema fonts, pause OSD, studio logos, poster ratio, progress spacing,
  notification-safe Arctic Mirage layout, atomic XML writes and diagnostics.

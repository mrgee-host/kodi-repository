# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import re
import shutil
import time
import traceback
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # Allows syntax checks outside Kodi.
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

ADDON_ID = 'script.kodi.patch.manager'
ADDON_NAME = 'Kodi Patch Manager'
VERSION = '0.1.0'

# Markers: every injected/replaced block has an obvious marker.
UPNEXT_MARKER = '<!-- KPM-UPNEXT-EPISODE-THUMB -->'
SHW_METHOD_START = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-METHOD-START'
SHW_METHOD_END = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-METHOD-END'
SHW_ENTRY_MARKER = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-LISTING'
SHW_XML_MARKER = '<!-- KPM-SHW-RANDOM-MOVIES-TVSHOWS-XML -->'
LEGACY_SHW_METHOD_START = '# AFM-RANDOM-MOVIES-TVSHOWS-METHOD-START'
LEGACY_SHW_METHOD_END = '# AFM-RANDOM-MOVIES-TVSHOWS-METHOD-END'
LEGACY_SHW_ENTRY_MARKER = '# AFM-RANDOM-MOVIES-TVSHOWS-LISTING'
LEGACY_SHW_XML_MARKER = '<!-- AFM-RANDOM-MOVIES-TVSHOWS-XML-PATCH -->'
TMDB_ATTR_MARKER = '# KPM-TMDB-FOCUS-RANDOM-V11-ATTR'
TMDB_REFRESH_START = '# KPM-TMDB-FOCUS-RANDOM-V11-REFRESH-START'
TMDB_REFRESH_END = '# KPM-TMDB-FOCUS-RANDOM-V11-REFRESH-END'
TMDB_HELPER_START = '# KPM-TMDB-FOCUS-RANDOM-V11-HELPER-START'
TMDB_HELPER_END = '# KPM-TMDB-FOCUS-RANDOM-V11-HELPER-END'
TMDB_CALL_MARKER = '# KPM-TMDB-FOCUS-RANDOM-V11-CALL'
LEGACY_TMDB_MARKER = 'Focus-random sticky visit patch V11'


def log(message: str, level=None) -> None:
    if xbmc:
        xbmc.log(f'[{ADDON_NAME}] {message}', level or xbmc.LOGINFO)
    else:
        print(f'[{ADDON_NAME}] {message}')


def notify(message: str, icon=None) -> None:
    if xbmcgui:
        xbmcgui.Dialog().notification(ADDON_NAME, message, icon or xbmcgui.NOTIFICATION_INFO, 3500)
    else:
        print(message)


def ok(title: str, message: str) -> None:
    if xbmcgui:
        xbmcgui.Dialog().ok(title, message)
    else:
        print('\n' + title + '\n' + message)


def yesno(title: str, message: str) -> bool:
    if xbmcgui:
        return xbmcgui.Dialog().yesno(title, message)
    return True


def translate(path: str) -> str:
    if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if xbmc and hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return (path
            .replace('special://home/', os.environ.get('KODI_HOME', 'E:/Kodi/portable_data/'))
            .replace('special://profile/', os.environ.get('KODI_PROFILE', 'E:/Kodi/portable_data/userdata/')))


def addon_data_dir(*parts: str) -> str:
    base = translate(f'special://profile/addon_data/{ADDON_ID}')
    path = os.path.join(base, *parts)
    os.makedirs(path, exist_ok=True)
    return path


def norm(path: str) -> str:
    return os.path.normpath(path)


def read_text(path: str) -> str:
    if not os.path.exists(path):
        raise FileNotFoundError(f'File not found: {path}')
    with open(path, 'r', encoding='utf-8-sig', errors='replace', newline='') as handle:
        return handle.read()


def write_text(path: str, text: str) -> None:
    # This writes the active file after a targeted text edit. It never copies a bundled full target file over it.
    with open(path, 'w', encoding='utf-8', errors='replace', newline='') as handle:
        handle.write(text)


def newline_of(text: str) -> str:
    return '\r\n' if '\r\n' in text else '\n'


def safe_name(path: str) -> str:
    drive, tail = os.path.splitdrive(path)
    value = (drive.replace(':', '') + tail).replace('\\', '__').replace('/', '__').strip('_')
    return value or 'file'


def save_json(path: str, data: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)


def load_json(path: str) -> dict:
    with open(path, 'r', encoding='utf-8') as handle:
        return json.load(handle)


def state_file(patch_id: str) -> str:
    return os.path.join(addon_data_dir('state'), f'{patch_id}.json')


def save_state(patch_id: str, data: dict) -> None:
    data.setdefault('patch_id', patch_id)
    data.setdefault('version', VERSION)
    data.setdefault('saved_at', time.strftime('%Y-%m-%d %H:%M:%S'))
    save_json(state_file(patch_id), data)


def load_state(patch_id: str) -> dict:
    path = state_file(patch_id)
    if not os.path.exists(path):
        raise FileNotFoundError(f'Patch state not found: {path}')
    return load_json(path)


def delete_state(patch_id: str) -> None:
    path = state_file(patch_id)
    if os.path.exists(path):
        os.remove(path)


def snapshot(patch_id: str, paths: List[str]) -> None:
    # Safety only. Normal restore/remove below is block-level and does not use this to overwrite target files.
    root = addon_data_dir('snapshots', patch_id, time.strftime('%Y%m%d-%H%M%S'))
    manifest = []
    for path in paths:
        if os.path.exists(path):
            dst_name = safe_name(path)
            shutil.copy2(path, os.path.join(root, dst_name))
            manifest.append({'source': path, 'snapshot': dst_name})
    save_json(os.path.join(root, 'manifest.json'), {'files': manifest})


def af3_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/skin.arctic.fuse.3'), *parts))


def tmdbhelper_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/plugin.video.themoviedb.helper'), *parts))


def skinhelper_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/script.skin.helper.widgets'), *parts))


def clear_pycache(folder: str, prefixes: Tuple[str, ...]) -> None:
    cache = os.path.join(folder, '__pycache__')
    if not os.path.isdir(cache):
        return
    for name in os.listdir(cache):
        if name.endswith('.pyc') and any(name.startswith(prefix + '.') for prefix in prefixes):
            try:
                os.remove(os.path.join(cache, name))
            except Exception:
                pass


@dataclass
class Result:
    name: str
    status: str
    detail: str = ''


# -----------------------------------------------------------------------------
# Patch 1: AF3 Up Next episode thumbnail priority
# -----------------------------------------------------------------------------

def upnext_target() -> str:
    return af3_path('1080i', 'Includes_Images.xml')


def status_upnext() -> str:
    target = upnext_target()
    if not os.path.exists(target):
        return 'Missing target'
    text = read_text(target)
    if UPNEXT_MARKER in text:
        return 'Patched'
    if '<variable name="Image_UpNext">' in text:
        return 'Not patched'
    return 'Unknown layout'


def patch_upnext() -> Result:
    name = 'AF3 Up Next episode thumbnail'
    target = upnext_target()
    text = read_text(target)
    if UPNEXT_MARKER in text:
        return Result(name, 'Skipped', 'Already patched.')

    pattern = r'(?ms)([ \t]*)<variable\s+name="Image_UpNext">.*?</variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Anchor not found: variable Image_UpNext in Includes_Images.xml')

    original = match.group(0)
    nl = newline_of(text)
    indent = match.group(1)
    inner = indent + '    '
    new_block = nl.join([
        f'{indent}<variable name="Image_UpNext">',
        f'{inner}{UPNEXT_MARKER}',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(thumb))">$INFO[Window.Property(thumb)]</value>',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(landscape))">$INFO[Window.Property(landscape)]</value>',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(fanart))">$INFO[Window.Property(fanart)]</value>',
        f'{indent}</variable>',
    ])

    snapshot('upnext_episode_thumb', [target])
    save_state('upnext_episode_thumb', {'target': target, 'original_block': original})
    text = text[:match.start()] + new_block + text[match.end():]
    write_text(target, text)
    return Result(name, 'Patched', 'Image_UpNext priority: thumb -> landscape -> fanart.')


def remove_upnext() -> Result:
    name = 'AF3 Up Next episode thumbnail'
    target = upnext_target()
    text = read_text(target)
    if UPNEXT_MARKER not in text:
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('upnext_episode_thumb')
    original = state.get('original_block')
    if not original:
        raise RuntimeError('Original Image_UpNext block is missing from saved state.')
    pattern = r'(?ms)[ \t]*<variable\s+name="Image_UpNext">(?:(?!</variable>).)*?' + re.escape(UPNEXT_MARKER) + r'.*?</variable>'
    if not re.search(pattern, text):
        raise RuntimeError('Patched Image_UpNext block not found.')
    text = re.sub(pattern, original, text, count=1)
    write_text(target, text)
    delete_state('upnext_episode_thumb')
    return Result(name, 'Removed', 'Original Image_UpNext block restored only.')


# -----------------------------------------------------------------------------
# Patch 2: TMDbHelper focus-random sticky visit V11
# -----------------------------------------------------------------------------

def tmdb_targets() -> Tuple[str, str]:
    imgmon = tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'imgmon.py')
    images = tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'images.py')
    return imgmon, images


def status_tmdb() -> str:
    imgmon, images = tmdb_targets()
    if not os.path.exists(imgmon) or not os.path.exists(images):
        return 'Missing target'
    t1 = read_text(imgmon)
    t2 = read_text(images)
    if TMDB_REFRESH_START in t1 and TMDB_HELPER_START in t2 and TMDB_CALL_MARKER in t2:
        return 'Patched'
    if LEGACY_TMDB_MARKER in t1 and '_focus_random_sticky_choose' in t2:
        return 'Patched (legacy)'
    return 'Not patched'


def patch_tmdb_imgmon(text: str) -> Tuple[str, Dict[str, str]]:
    nl = newline_of(text)
    state: Dict[str, str] = {}

    if TMDB_ATTR_MARKER not in text:
        pattern_attr = r'self\.properties\s*=\s*set\(\)'
        match_attr = re.search(pattern_attr, text)
        if not match_attr:
            raise RuntimeError('Anchor not found in imgmon.py: self.properties = set()')
        replacement_attr = match_attr.group(0) + nl + f'        self._focus_random_visit_id = 0  {TMDB_ATTR_MARKER}'
        text = text[:match_attr.start()] + replacement_attr + text[match_attr.end():]

    if TMDB_REFRESH_START not in text:
        pattern_refresh = (
            r'(?ms)(        # Check if the item has changed before retrieving details again\r?\n'
            r'        if not self\.is_same_item\(update=True\) or not self\.is_same_window\(update=True\):\r?\n)'
            r'(.*?)'
            r'(?=\r?\n    @kodi_try_except)'
        )
        match_refresh = re.search(pattern_refresh, text)
        if not match_refresh:
            raise RuntimeError('Anchor not found in imgmon.py: is_next_refresh block')
        original_block = match_refresh.group(0)
        state['original_refresh_block'] = original_block
        prefix = match_refresh.group(1)
        new_block = prefix + nl.join([
            f'            {TMDB_REFRESH_START}',
            '            # New item/window = new random visit.',
            '            try:',
            '                self._focus_random_visit_id += 1',
            '            except AttributeError:',
            '                self._focus_random_visit_id = 1',
            '            return True',
            '',
            '        # Disable idle extra-fanart refresh.',
            '        # Random only changes when Kodi focus moves to another item/window.',
            '        return False',
            f'        {TMDB_REFRESH_END}',
        ])
        text = text[:match_refresh.start()] + new_block + text[match_refresh.end():]
    return text, state


TMDB_HELPER_BLOCK = '''
# KPM-TMDB-FOCUS-RANDOM-V11-HELPER-START
# Keeps the random fanart choice stable while the same focused item is being processed.
# A new visit id from imgmon.py allows the same movie to get a new random fanart when you leave it and return.
_FOCUS_RANDOM_STICKY_BY_VISIT = {}
_FOCUS_RANDOM_STICKY_LAST_BY_ITEM = {}


def _focus_random_sticky_unique(values):
    output = []
    for value in values:
        if value and value not in output:
            output.append(value)
    return output


def _focus_random_sticky_attr(parent, name, default=None):
    try:
        return getattr(parent, name, default)
    except Exception:
        return default


def _focus_random_sticky_choose(item, artworks, parent=None):
    artworks = _focus_random_sticky_unique(artworks)
    if not artworks:
        return None
    if len(artworks) == 1:
        return artworks[0]

    parent_id = id(parent) if parent is not None else 0
    visit_id = _focus_random_sticky_attr(parent, '_focus_random_visit_id', 0)
    cur_item = repr(_focus_random_sticky_attr(parent, 'pre_item', None))
    cur_window = repr(_focus_random_sticky_attr(parent, 'pre_window', None))

    visit_key = (parent_id, visit_id, cur_item, cur_window, item)
    cached = _FOCUS_RANDOM_STICKY_BY_VISIT.get(visit_key)
    if cached in artworks:
        return cached

    item_key = (parent_id, cur_item, item)
    last = _FOCUS_RANDOM_STICKY_LAST_BY_ITEM.get(item_key)
    choices = [art for art in artworks if art != last] or artworks
    choice = random.choice(choices)

    _FOCUS_RANDOM_STICKY_BY_VISIT[visit_key] = choice
    _FOCUS_RANDOM_STICKY_LAST_BY_ITEM[item_key] = choice

    # Keep dictionaries small during long library browsing sessions.
    if len(_FOCUS_RANDOM_STICKY_BY_VISIT) > 500:
        _FOCUS_RANDOM_STICKY_BY_VISIT.clear()
        _FOCUS_RANDOM_STICKY_BY_VISIT[visit_key] = choice
    if len(_FOCUS_RANDOM_STICKY_LAST_BY_ITEM) > 500:
        _FOCUS_RANDOM_STICKY_LAST_BY_ITEM.clear()
        _FOCUS_RANDOM_STICKY_LAST_BY_ITEM[item_key] = choice

    return choice
# KPM-TMDB-FOCUS-RANDOM-V11-HELPER-END
'''.strip('\n')


def patch_tmdb_images(text: str) -> Tuple[str, Dict[str, str]]:
    nl = newline_of(text)
    state: Dict[str, str] = {}

    if TMDB_HELPER_START not in text:
        anchor = 'class ImageFunctions'
        index = text.find(anchor)
        if index < 0:
            raise RuntimeError('Anchor not found in images.py: class ImageFunctions')
        helper = TMDB_HELPER_BLOCK.replace('\n', nl) + nl + nl
        text = text[:index] + helper + text[index:]

    if TMDB_CALL_MARKER not in text:
        matches = list(re.finditer(r'return\s+random\.choice\(artworks\)', text))
        if len(matches) != 1:
            raise RuntimeError(f'Anchor mismatch in images.py: return random.choice(artworks) count={len(matches)}')
        match = matches[0]
        state['original_random_choice_line'] = match.group(0)
        new_line = f'return _focus_random_sticky_choose(item, artworks, self._parent)  {TMDB_CALL_MARKER}'
        text = text[:match.start()] + new_line + text[match.end():]
    return text, state


def patch_tmdb() -> Result:
    name = 'TMDbHelper focus-random sticky visit V11'
    imgmon, images = tmdb_targets()
    t1 = read_text(imgmon)
    t2 = read_text(images)
    if TMDB_REFRESH_START in t1 and TMDB_HELPER_START in t2 and TMDB_CALL_MARKER in t2:
        return Result(name, 'Skipped', 'Already patched.')
    if LEGACY_TMDB_MARKER in t1 and '_focus_random_sticky_choose' in t2:
        return Result(name, 'Skipped', 'Legacy V11 patch already detected. Not injecting duplicate code.')

    snapshot('tmdb_focus_random_v11', [imgmon, images])
    n1, s1 = patch_tmdb_imgmon(t1)
    n2, s2 = patch_tmdb_images(t2)
    save_state('tmdb_focus_random_v11', {'imgmon': imgmon, 'images': images, 'imgmon_state': s1, 'images_state': s2})
    write_text(imgmon, n1)
    write_text(images, n2)
    clear_pycache(os.path.dirname(imgmon), ('imgmon', 'images'))
    return Result(name, 'Patched', 'Injected stable random fanart visit logic; pycache cleaned.')


def remove_tmdb() -> Result:
    name = 'TMDbHelper focus-random sticky visit V11'
    imgmon, images = tmdb_targets()
    t1 = read_text(imgmon)
    t2 = read_text(images)
    has_kpm = TMDB_REFRESH_START in t1 or TMDB_HELPER_START in t2 or TMDB_CALL_MARKER in t2 or TMDB_ATTR_MARKER in t1
    if not has_kpm:
        if LEGACY_TMDB_MARKER in t1 and '_focus_random_sticky_choose' in t2:
            return Result(name, 'Skipped', 'Legacy V11 patch detected. It was not installed by this add-on, so block-level restore state is unavailable.')
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('tmdb_focus_random_v11') if os.path.exists(state_file('tmdb_focus_random_v11')) else {}

    # Remove inserted attribute line.
    t1 = re.sub(r'\r?\n[ \t]*self\._focus_random_visit_id\s*=\s*0\s*' + re.escape(TMDB_ATTR_MARKER), '', t1, count=1)

    # Restore only the original is_next_refresh block if state exists. Otherwise fail safely.
    if TMDB_REFRESH_START in t1:
        original = state.get('imgmon_state', {}).get('original_refresh_block')
        if not original:
            raise RuntimeError('Cannot remove TMDbHelper refresh patch: original block state is missing.')
        pattern = (
            r'(?ms)        # Check if the item has changed before retrieving details again\r?\n'
            r'        if not self\.is_same_item\(update=True\) or not self\.is_same_window\(update=True\):\r?\n'
            r'.*?' + re.escape(TMDB_REFRESH_END)
        )
        t1 = re.sub(pattern, original, t1, count=1)

    # Remove helper block and restore random.choice line.
    if TMDB_HELPER_START in t2:
        helper_pattern = r'(?ms)\r?\n?' + re.escape(TMDB_HELPER_START) + r'.*?' + re.escape(TMDB_HELPER_END) + r'\r?\n?'
        t2 = re.sub(helper_pattern, '\n', t2, count=1)
    if TMDB_CALL_MARKER in t2:
        t2 = re.sub(
            r'return\s+_focus_random_sticky_choose\(item, artworks, self\._parent\)\s*' + re.escape(TMDB_CALL_MARKER),
            'return random.choice(artworks)',
            t2,
            count=1,
        )

    write_text(imgmon, t1)
    write_text(images, t2)
    clear_pycache(os.path.dirname(imgmon), ('imgmon', 'images'))
    delete_state('tmdb_focus_random_v11')
    return Result(name, 'Removed', 'Injected helper/call/refresh blocks removed; original refresh block restored only.')


# -----------------------------------------------------------------------------
# Patch 3: Skin Helper Widgets random Movies + TV Shows screensaver for AF3
# -----------------------------------------------------------------------------

def shw_targets() -> Tuple[str, str]:
    media = skinhelper_path('resources', 'lib', 'media.py')
    defaults = af3_path('1080i', 'Includes_Defaults.xml')
    return media, defaults


def status_shw() -> str:
    media, defaults = shw_targets()
    if not os.path.exists(media) or not os.path.exists(defaults):
        return 'Missing target'
    t1 = read_text(media)
    t2 = read_text(defaults)
    method_ok = SHW_METHOD_START in t1 or LEGACY_SHW_METHOD_START in t1 or re.search(r'def\s+randommoviestvshows\s*\(\s*self\s*\)\s*:', t1)
    xml_ok = SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2
    if method_ok and xml_ok:
        return 'Patched'
    return 'Not patched'


def extract_variable_block(text: str, variable_name: str) -> Optional[str]:
    pattern = r'(?ms)[ \t]*<variable\s+name="' + re.escape(variable_name) + r'">.*?</variable>'
    match = re.search(pattern, text)
    return match.group(0) if match else None


def legacy_shw_xml_backup(defaults: str) -> Optional[str]:
    backup = defaults + '.afm-random-movies-tvshows-xml.bak'
    if os.path.exists(backup):
        try:
            return extract_variable_block(read_text(backup), 'Defs_ScreensaverWidget')
        except Exception:
            return None
    return None


def patch_shw_media(text: str) -> str:
    nl = newline_of(text)
    has_any_method = (SHW_METHOD_START in text or LEGACY_SHW_METHOD_START in text or
                      re.search(r'def\s+randommoviestvshows\s*\(\s*self\s*\)\s*:', text))
    if not has_any_method:
        method = nl.join([
            f'    {SHW_METHOD_START}',
            '    def randommoviestvshows(self):',
            '        """get random movies and tvshows only - no episodes, no music, no pvr"""',
            '        all_items = self.movies.random()',
            '        all_items += self.tvshows.random()',
            '        return sorted(all_items, key=lambda k: random.random())[:self.options["limit"]]',
            f'    {SHW_METHOD_END}',
            '',
        ]) + nl
        anchor = '    def inprogress(self):'
        if anchor not in text:
            raise RuntimeError('Anchor not found in media.py: def inprogress(self)')
        text = text.replace(anchor, method + anchor, 1)

    if SHW_ENTRY_MARKER not in text and LEGACY_SHW_ENTRY_MARKER not in text:
        old = '            (self.addon.getLocalizedString(32059), "random&mediatype=media", "DefaultMovies.png"),'
        if old in text:
            new = old + nl + f'            ("Random Movies + TV Shows", "randommoviestvshows&mediatype=media", "DefaultMovies.png"),  {SHW_ENTRY_MARKER}'
            text = text.replace(old, new, 1)
    return text


def patch_shw_xml(text: str, limit: int) -> Tuple[str, str]:
    pattern = r'(?ms)([ \t]*)<variable\s+name="Defs_ScreensaverWidget">.*?</variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_Defaults.xml: variable Defs_ScreensaverWidget')
    original = match.group(0)
    nl = newline_of(text)
    indent = match.group(1)
    inner = indent + '    '
    path = f'plugin://script.skin.helper.widgets/?action=randommoviestvshows&amp;mediatype=media&amp;limit={limit}'
    new_block = nl.join([
        f'{indent}<variable name="Defs_ScreensaverWidget">',
        f'{inner}{SHW_XML_MARKER}',
        f'{inner}<value>{path}</value>',
        f'{indent}</variable>',
    ])
    text = text[:match.start()] + new_block + text[match.end():]
    return text, original


def patch_shw(limit: int = 100) -> Result:
    name = 'SHW random Movies + TV Shows screensaver'
    media, defaults = shw_targets()
    t1 = read_text(media)
    t2 = read_text(defaults)
    if (SHW_METHOD_START in t1 or LEGACY_SHW_METHOD_START in t1) and (SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2):
        return Result(name, 'Skipped', 'Already patched.')

    snapshot('shw_random_movies_tvshows', [media, defaults])
    n1 = patch_shw_media(t1)
    if SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2:
        n2 = t2
        original_xml = None
    else:
        n2, original_xml = patch_shw_xml(t2, limit)
    save_state('shw_random_movies_tvshows', {'media': media, 'defaults': defaults, 'original_xml_block': original_xml})
    write_text(media, n1)
    write_text(defaults, n2)
    clear_pycache(os.path.dirname(media), ('media',))
    return Result(name, 'Patched', f'Screensaver path: random movies + TV shows only, limit={limit}.')


def remove_shw() -> Result:
    name = 'SHW random Movies + TV Shows screensaver'
    media, defaults = shw_targets()
    t1 = read_text(media)
    t2 = read_text(defaults)
    has_markers = any(marker in t1 for marker in (SHW_METHOD_START, LEGACY_SHW_METHOD_START, SHW_ENTRY_MARKER, LEGACY_SHW_ENTRY_MARKER)) or any(marker in t2 for marker in (SHW_XML_MARKER, LEGACY_SHW_XML_MARKER))
    if not has_markers:
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('shw_random_movies_tvshows') if os.path.exists(state_file('shw_random_movies_tvshows')) else {}

    # Remove method block by marker. Supports current KPM markers and the older uploaded AFM PowerShell markers.
    for start, end in ((SHW_METHOD_START, SHW_METHOD_END), (LEGACY_SHW_METHOD_START, LEGACY_SHW_METHOD_END)):
        method_pattern = r'(?ms)\r?\n?    ' + re.escape(start) + r'.*?    ' + re.escape(end) + r'\r?\n?'
        t1 = re.sub(method_pattern, '\n', t1, count=1)

    # Remove optional listing line by marker.
    for marker in (SHW_ENTRY_MARKER, LEGACY_SHW_ENTRY_MARKER):
        entry_pattern = r'(?m)^.*' + re.escape(marker) + r'.*(\r?\n)?'
        t1 = re.sub(entry_pattern, '', t1, count=1)

    # Restore only the original XML variable block. If this was an older PS1 patch, read its .bak file
    # and restore only the Defs_ScreensaverWidget variable from that backup, not the whole XML file.
    if SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2:
        original = state.get('original_xml_block') or legacy_shw_xml_backup(defaults)
        if not original:
            raise RuntimeError('Cannot remove SHW XML patch: original Defs_ScreensaverWidget block state/legacy backup is missing.')
        marker_pat = re.escape(SHW_XML_MARKER) + '|' + re.escape(LEGACY_SHW_XML_MARKER)
        pattern = r'(?ms)[ \t]*<variable\s+name="Defs_ScreensaverWidget">(?:(?!</variable>).)*?(?:' + marker_pat + r').*?</variable>'
        t2 = re.sub(pattern, original, t2, count=1)

    write_text(media, t1)
    write_text(defaults, t2)
    clear_pycache(os.path.dirname(media), ('media',))
    delete_state('shw_random_movies_tvshows')
    return Result(name, 'Removed', 'Injected method/listing removed; original XML variable restored only.')


# -----------------------------------------------------------------------------
# UI and batch actions
# -----------------------------------------------------------------------------

def format_results(results: List[Result]) -> str:
    chunks = []
    for item in results:
        text = f'{item.name}: {item.status}'
        if item.detail:
            text += f'\n{item.detail}'
        chunks.append(text)
    return '\n\n'.join(chunks)


def run_single(func: Callable[[], Result]) -> None:
    try:
        result = func()
        notify(f'{result.name}: {result.status}')
        ok(ADDON_NAME, format_results([result]))
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
        ok(f'{ADDON_NAME} - Error', str(exc))


def apply_all() -> None:
    if not yesno(ADDON_NAME, 'Apply all stable patches now?\n\nPatch style: inject/replace only selected blocks, with block-level remove/restore.'):
        return
    funcs = [patch_upnext, patch_tmdb, lambda: patch_shw(100)]
    results: List[Result] = []
    for func in funcs:
        try:
            results.append(func())
        except Exception as exc:
            log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
            results.append(Result(getattr(func, '__name__', 'patch'), 'Error', str(exc)))
    notify('Apply all finished')
    ok(ADDON_NAME, format_results(results))


def remove_all() -> None:
    if not yesno(ADDON_NAME, 'Remove all patches now?\n\nNormal remove restores only the edited blocks, not whole files.'):
        return
    funcs = [remove_upnext, remove_tmdb, remove_shw]
    results: List[Result] = []
    for func in funcs:
        try:
            results.append(func())
        except Exception as exc:
            log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
            results.append(Result(getattr(func, '__name__', 'remove'), 'Error', str(exc)))
    notify('Remove all finished')
    ok(ADDON_NAME, format_results(results))


def view_status() -> None:
    lines = [
        f'Addon: {ADDON_NAME} v{VERSION}',
        '',
        f'AF3 Up Next episode thumbnail: {status_upnext()}',
        f'TMDbHelper focus-random sticky visit V11: {status_tmdb()}',
        f'SHW random Movies + TV Shows screensaver: {status_shw()}',
        '',
        'Patch mode: anchor-based inject/remove, block-level restore.',
    ]
    ok(f'{ADDON_NAME} - Status', '\n'.join(lines))


def run_console() -> None:
    print(f'{ADDON_NAME} v{VERSION}')
    print('This add-on is intended to run inside Kodi.')
    print('Status:')
    print('  AF3 Up Next episode thumbnail:', status_upnext())
    print('  TMDbHelper focus-random sticky visit V11:', status_tmdb())
    print('  SHW random Movies + TV Shows screensaver:', status_shw())


def run() -> None:
    if not xbmcgui:
        run_console()
        return
    while True:
        items = [
            'Apply all stable patches',
            'Remove all patches',
            'Patch AF3 Up Next episode thumbnail',
            'Remove AF3 Up Next patch',
            'Patch TMDbHelper focus-random sticky visit V11',
            'Remove TMDbHelper patch',
            'Patch SHW random Movies + TV Shows screensaver',
            'Remove SHW screensaver patch',
            'View patch status',
            'Exit',
        ]
        index = xbmcgui.Dialog().select(ADDON_NAME, items)
        if index < 0 or index == len(items) - 1:
            return
        if index == 0:
            apply_all()
        elif index == 1:
            remove_all()
        elif index == 2:
            run_single(patch_upnext)
        elif index == 3:
            run_single(remove_upnext)
        elif index == 4:
            run_single(patch_tmdb)
        elif index == 5:
            run_single(remove_tmdb)
        elif index == 6:
            run_single(lambda: patch_shw(100))
        elif index == 7:
            run_single(remove_shw)
        elif index == 8:
            view_status()

Kodi Patch Manager v0.1.0

Safe patch style:
- Does not ship full replacement XML/PY target files.
- Uses anchor-based injection/replacement only.
- Adds clear markers to every injected block.
- Normal Remove/Restore is block-level: it removes injected blocks or restores only the saved original XML variable block, not the whole file.
- A safety snapshot is also stored before patching, but normal restore does not overwrite the whole target file.

Included patches:
1. AF3 Up Next episode thumbnail priority
   Target: skin.arctic.fuse.3/1080i/Includes_Images.xml
   Change: Image_UpNext becomes thumb -> landscape -> fanart.

2. TMDbHelper Focus Random Sticky Visit V11
   Target: plugin.video.themoviedb.helper/resources/tmdbhelper/lib/monitor/imgmon.py
   Target: plugin.video.themoviedb.helper/resources/tmdbhelper/lib/monitor/images.py
   Change: random extra-fanart stays stable while focus stays on the same item.

3. Skin Helper Widgets random Movies + TV Shows screensaver
   Target: script.skin.helper.widgets/resources/lib/media.py
   Target: skin.arctic.fuse.3/1080i/Includes_Defaults.xml
   Change: adds randommoviestvshows path and points AF3 screensaver widget to movies + TV shows only.

Reference uploads:
- Original uploaded PowerShell/XML reference files are included under resources/reference/uploads.
- The add-on uses native Python patchers inside Kodi; it does not call PowerShell.

Backups/state:
- special://profile/addon_data/script.kodi.patch.manager/state
- special://profile/addon_data/script.kodi.patch.manager/snapshots

After patch/remove:
- Fully close Kodi and open it again for Python helper patches.
- Reload Skin may be enough for XML-only changes, but full restart is safest.

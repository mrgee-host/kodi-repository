# -*- coding: utf-8 -*-
from resources.lib.main import run

if __name__ == '__main__':
    run()

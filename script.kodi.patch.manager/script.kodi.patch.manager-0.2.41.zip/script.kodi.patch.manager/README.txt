Kodi Patch Manager 0.2.41

Runtime patch manager for the MrGee Kodi family.

Combined Expanded episodes
- AF3 native Object_StarRating.
- IMDb rating with TMDb fallback.
- Four-digit ListItem.Year.
- Episode title right=400 with no scrolling.
- Star-to-rating geometry remains unchanged.
- Bullet separator uses right=234 and width=24, preserving its previous center at 246 px while avoiding truncation on unfocused rows.
- Native Object_Indicator_List and duration controls remain untouched.

All AF3 changes are partial runtime patches. No complete skin XML file is bundled or replaced.

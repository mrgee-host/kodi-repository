# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import re
import shutil
import sqlite3
import time
import traceback
import zipfile
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple
from urllib.parse import unquote, quote

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # Allows syntax checks outside Kodi.
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

ADDON_ID = 'script.kodi.patch.manager'
ADDON_NAME = 'Kodi Patch Manager'
VERSION = '0.1.83'

# Markers: every injected/replaced block has an obvious marker.
UPNEXT_MARKER = '<!-- KPM-UPNEXT-EPISODE-THUMB -->'
SHW_METHOD_START = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-METHOD-START'
SHW_METHOD_END = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-METHOD-END'
SHW_ENTRY_MARKER = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-LISTING'
SHW_XML_MARKER = '<!-- KPM-SHW-RANDOM-MOVIES-TVSHOWS-XML -->'
LEGACY_SHW_METHOD_START = '# AFM-RANDOM-MOVIES-TVSHOWS-METHOD-START'
LEGACY_SHW_METHOD_END = '# AFM-RANDOM-MOVIES-TVSHOWS-METHOD-END'
LEGACY_SHW_ENTRY_MARKER = '# AFM-RANDOM-MOVIES-TVSHOWS-LISTING'
LEGACY_SHW_XML_MARKER = '<!-- AFM-RANDOM-MOVIES-TVSHOWS-XML-PATCH -->'
VFS_PAUSE_RATINGS_START = '<!-- KPM-VFS-PAUSE-RATINGS-START -->'
VFS_PAUSE_RATINGS_END = '<!-- KPM-VFS-PAUSE-RATINGS-END -->'
DIALOG_SEEKBAR_PAUSE_RATINGS_START = '<!-- KPM-DIALOG-SEEKBAR-PAUSE-RATINGS-START -->'
DIALOG_SEEKBAR_PAUSE_RATINGS_END = '<!-- KPM-DIALOG-SEEKBAR-PAUSE-RATINGS-END -->'
DIALOG_SEEKBAR_AUTO_OSD_MARKER = '<!-- KPM-DIALOG-SEEKBAR-AUTO-VIDEOOSD -->'
VIDEOOSD_CLEARART_START = '<!-- KPM-VIDEOOSD-CLEARART-RIGHT-START -->'
VIDEOOSD_CLEARART_END = '<!-- KPM-VIDEOOSD-CLEARART-RIGHT-END -->'
VIDEOOSD_FAST_CLOSE_START = '<!-- KPM-VIDEOOSD-FAST-CLOSE-RESUME-START -->'
VIDEOOSD_FAST_CLOSE_END = '<!-- KPM-VIDEOOSD-FAST-CLOSE-RESUME-END -->'
OSD_PLOT_WIDTH_START = '<!-- KPM-OSD-PLOT-WIDTH-START -->'
OSD_PLOT_WIDTH_END = '<!-- KPM-OSD-PLOT-WIDTH-END -->'
DIALOG_SEEKBAR_CLEARART_START = '<!-- KPM-DIALOG-SEEKBAR-CLEARART-BEHIND-PROGRESS-START -->'
DIALOG_SEEKBAR_CLEARART_END = '<!-- KPM-DIALOG-SEEKBAR-CLEARART-BEHIND-PROGRESS-END -->'
OSD_RANGE_MARKERS_START = '<!-- KPM-OSD-RANGE-MARKERS-HIDDEN-START -->'
OSD_RANGE_MARKERS_END = '<!-- KPM-OSD-RANGE-MARKERS-HIDDEN-END -->'
ACTION_OSD_PAUSE_STAY_START = '<!-- KPM-ACTION-OSD-PAUSE-STAY-START -->'
ACTION_OSD_PAUSE_STAY_END = '<!-- KPM-ACTION-OSD-PAUSE-STAY-END -->'
STUDIO_IMAGE_VAR_START = '<!-- KPM-STUDIO-LOGOS-IMAGE-VAR-START -->'
STUDIO_IMAGE_VAR_END = '<!-- KPM-STUDIO-LOGOS-IMAGE-VAR-END -->'
STUDIO_FURNITURE_START = '<!-- KPM-STUDIO-LOGOS-FURNITURE-START -->'
STUDIO_FURNITURE_END = '<!-- KPM-STUDIO-LOGOS-FURNITURE-END -->'
STUDIO_FURNITURE_CURRENT_MARKER = '<!-- KPM-STUDIO-LOGOS-FURNITURE-v0.1.30-SINGLE -->'
BROKEN_STUDIO_TEXTURE_NAMES = ('centropolis entertainment.png', 'dune entertainment.png', 'gk films.png', 'thunder road.png')


PATCH_DETAILS = {
    'af3_unified_integration': {
        'title': 'AF3 Unified Integration',
        'apply_label': 'Apply AF3 Unified Integration',
        'remove_label': 'Remove AF3 Unified Integration',
        'summary': 'KPM-owned AF3 visual integration: rating row, Steam game top meta, and legacy LRS/Steam row cleanup.',
        'function': 'Patches AF3 Includes_Info.xml so the skin reads KPM.RatingRow.* and KPM owns the lower rating row and Steam game info layout. LRS, Steam Library, LAC, and MediaHub remain data owners.',
        'target': 'skin.arctic.fuse.3/1080i/Includes_Info.xml',
        'reference': 'Clean architecture integration owner. No calls to LRS/Steam patchers.',
    },
    'upnext_episode_thumb': {
        'title': 'Episode Thumb Up Next',
        'apply_label': 'Patch Episode Thumb Up Next',
        'remove_label': 'Remove Episode Thumb Up Next',
        'summary': 'Use next episode thumbnail first.',
        'function': 'Makes the Up Next popup show the next episode thumbnail first, then falls back to landscape.',
        'target': 'skin.arctic.fuse.3/1080i/Includes_Images.xml -> variable Image_UpNext',
        'reference': 'Native Kodi patcher. No bundled standalone patch file.',
    },
    'vfs_pause_ratings': {
        'title': 'Pause Shows Full OSD',
        'apply_label': 'Patch Pause Shows Full OSD',
        'remove_label': 'Remove Pause Shows Full OSD',
        'summary': 'Open full VideoOSD on pause through a dialog-safe service, keep it behind dialogs, hide chapter ticks, shorten OSD plot, close safely after resume.',
        'function': 'Marks DialogSeekBar.xml as KPM-managed and uses service.py so a normal pause opens videoosd quickly on normal pause with a longer playback-start guard, matching the result of pressing M; normal pause opens fast while playback-start auto subtitle dialogs are still guarded. It removes the old minimalist inline Paused rating fallback, draws a native/TMDbHelper clearart panel behind the progress line in DialogSeekBar, hides chapter/cutlist marker ticks, shortens the OSD plot width in Includes_OSD.xml, prevents OSD timeout while paused, patches the main play button, and starts the KPM lightweight resume monitor. The monitor no longer uses Action(Back); it keeps VideoOSD behind foreign dialogs and only closes VideoOSD safely after resume when no other dialog has focus.',
        'target': 'skin.arctic.fuse.3/1080i/DialogSeekBar.xml + VideoOSD.xml + Includes_OSD.xml + Includes_Actions.xml; old VideoFullScreen.xml and old inline DialogSeekBar/VideoOSD clearart markers are cleaned if present; service.py monitors pause→play only while this patch is enabled and does not steal focus from other dialogs',
        'reference': 'Native Kodi patcher. Pause opens VideoOSD by Kodi window action. A lightweight KPM service only closes VideoOSD after resume and avoids Action(Back). Clearart may use Kodi native artwork first and TMDbHelper.Player.ClearArt as fallback.',
    },
    'reliable_studio_logos': {
        'title': 'Reliable Studio Logos',
        'apply_label': 'Patch Reliable Studio Logos',
        'remove_label': 'Remove Reliable Studio Logos',
        'summary': 'Show one reliable valid studio logo only, including parent TV show studios for episodes and Steam game developer/publisher logos.',
        'function': 'Replaces AF3 raw studio texture lookup with a single KPM resolved studio logo property. KPM scans/caches resource.images.studios.coloured for movies/TV and resource.images.gamestudios.grayscale for Steam games, splits multi-studio labels, uses database studios and parent TV show studios for episode items, uses Steam developer/publisher properties for games, skips missing or known-broken logos, and fills KPM.StudioLogo.1 with the first valid match. Metadata in MyVideos/Steam DB is not changed.',
        'target': 'skin.arctic.fuse.3/1080i -> Includes_Images.xml variable Image_CombinedStudio and Includes_Furniture.xml include Furniture_Studio; service.py fills Window(Home).Property(KPM.StudioLogo.1)',
        'reference': 'Native Kodi patcher using installed studio resource names. Single-logo mode only; no raw AF3 fallback. Game logos use resource.images.gamestudios.grayscale if installed.',
    },
    'shw_random_movies_tvshows': {
        'title': 'Movies + Shows Screensaver',
        'apply_label': 'Patch Movies + Shows Screensaver',
        'remove_label': 'Remove Movies + Shows Screensaver',
        'summary': 'Random movies + TV shows only; no episodes.',
        'function': 'Adds a Skin Helper Widgets random source that returns movies and TV shows only, then points AF3 screensaver widget to that source so episodes are excluded.',
        'target': 'script.skin.helper.widgets/resources/lib/media.py + skin.arctic.fuse.3/1080i/Includes_Defaults.xml',
        'reference': 'Converted to native Kodi patcher. No bundled standalone patch file.',
    },
}


def patch_detail(patch_id: str) -> dict:
    return PATCH_DETAILS.get(patch_id, {})


def patch_title(patch_id: str, fallback: str) -> str:
    return patch_detail(patch_id).get('title', fallback)


def menu_label(patch_id: str, mode: str) -> str:
    data = patch_detail(patch_id)
    return data.get('apply_label' if mode == 'apply' else 'remove_label', data.get('title', patch_id))


PATCH_ORDER = (
    ('af3_unified_integration', 'status_af3_unified_integration', 'apply_af3_unified_integration', 'remove_af3_unified_integration'),
    ('upnext_episode_thumb', 'status_upnext', 'patch_upnext', 'remove_upnext'),
    ('shw_random_movies_tvshows', 'status_shw', 'patch_shw', 'remove_shw'),
    ('vfs_pause_ratings', 'status_vfs_pause_ratings', 'patch_vfs_pause_ratings', 'remove_vfs_pause_ratings'),
    ('reliable_studio_logos', 'status_reliable_studio_logos', 'patch_reliable_studio_logos', 'remove_reliable_studio_logos'),
)



def patch_details_summary(include_status: bool = False) -> str:
    chunks = []
    for patch_id, status_name, _apply_name, _remove_name in PATCH_ORDER:
        data = patch_detail(patch_id)
        heading = data.get('title', patch_id)
        if include_status:
            status_func = globals().get(status_name)
            if status_func:
                try:
                    heading += f': {status_func()}'
                except Exception as exc:
                    heading += f': Error ({exc})'
        chunks.append(
            f"{heading}\n"
            f"Function: {data.get('function', '-')}\n"
            f"Target: {data.get('target', '-')}\n"
            f"Reference: {data.get('reference', '-')}"
        )
    return '\n\n'.join(chunks)


def log(message: str, level=None) -> None:
    if xbmc:
        xbmc.log(f'[{ADDON_NAME}] {message}', level or xbmc.LOGINFO)
    else:
        print(f'[{ADDON_NAME}] {message}')


def notify(message: str, icon=None) -> None:
    if xbmcgui:
        xbmcgui.Dialog().notification(ADDON_NAME, message, icon or xbmcgui.NOTIFICATION_INFO, 3500)
    else:
        print(message)


def ok(title: str, message: str) -> None:
    if xbmcgui:
        xbmcgui.Dialog().ok(title, message)
    else:
        print('\n' + title + '\n' + message)


def textviewer(title: str, message: str) -> None:
    if xbmcgui and hasattr(xbmcgui.Dialog(), 'textviewer'):
        xbmcgui.Dialog().textviewer(title, message)
    else:
        ok(title, message)


def yesno(title: str, message: str) -> bool:
    if xbmcgui:
        return xbmcgui.Dialog().yesno(title, message)
    return True


def translate(path: str) -> str:
    if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if xbmc and hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return (path
            .replace('special://home/', os.environ.get('KODI_HOME', 'E:/Kodi/portable_data/'))
            .replace('special://profile/', os.environ.get('KODI_PROFILE', 'E:/Kodi/portable_data/userdata/')))


def addon_data_dir(*parts: str) -> str:
    base = translate(f'special://profile/addon_data/{ADDON_ID}')
    path = os.path.join(base, *parts)
    os.makedirs(path, exist_ok=True)
    return path


def norm(path: str) -> str:
    return os.path.normpath(path)


def read_text(path: str) -> str:
    if not os.path.exists(path):
        raise FileNotFoundError(f'File not found: {path}')
    with open(path, 'r', encoding='utf-8-sig', errors='replace', newline='') as handle:
        return handle.read()


def write_text(path: str, text: str) -> None:
    # This writes the active file after a targeted text edit. It never copies a bundled full target file over it.
    with open(path, 'w', encoding='utf-8', errors='replace', newline='') as handle:
        handle.write(text)


def newline_of(text: str) -> str:
    return '\r\n' if '\r\n' in text else '\n'


def safe_name(path: str) -> str:
    drive, tail = os.path.splitdrive(path)
    value = (drive.replace(':', '') + tail).replace('\\', '__').replace('/', '__').strip('_')
    return value or 'file'


def save_json(path: str, data: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)


def load_json(path: str) -> dict:
    with open(path, 'r', encoding='utf-8') as handle:
        return json.load(handle)


def state_file(patch_id: str) -> str:
    return os.path.join(addon_data_dir('runtime', 'state'), f'{patch_id}.json')


def save_state(patch_id: str, data: dict) -> None:
    data.setdefault('patch_id', patch_id)
    data.setdefault('version', VERSION)
    data.setdefault('saved_at', time.strftime('%Y-%m-%d %H:%M:%S'))
    save_json(state_file(patch_id), data)


def load_state(patch_id: str) -> dict:
    path = state_file(patch_id)
    if not os.path.exists(path):
        raise FileNotFoundError(f'Patch state not found: {path}')
    return load_json(path)


def delete_state(patch_id: str) -> None:
    path = state_file(patch_id)
    if os.path.exists(path):
        os.remove(path)


def kpm_settings_file() -> str:
    return os.path.join(addon_data_dir('runtime', 'state'), 'settings.json')


def load_kpm_settings() -> dict:
    path = kpm_settings_file()
    data = {'studio_logo_count': 1, 'studio_debug': False}
    if os.path.exists(path):
        try:
            loaded = load_json(path)
            if isinstance(loaded, dict):
                data.update(loaded)
        except Exception:
            pass
    try:
        count = int(data.get('studio_logo_count', 1))
    except Exception:
        count = 1
    data['studio_logo_count'] = 1
    return data


def save_kpm_settings(data: dict) -> None:
    current = load_kpm_settings()
    current.update(data or {})
    try:
        current['studio_logo_count'] = 1
    except Exception:
        current['studio_logo_count'] = 1
    save_json(kpm_settings_file(), current)


def snapshot(patch_id: str, paths: List[str]) -> None:
    # Safety only. Normal restore/remove below is block-level and does not use this to overwrite target files.
    root = addon_data_dir('runtime', 'exports', 'snapshots', patch_id, time.strftime('%Y%m%d-%H%M%S'))
    manifest = []
    for path in paths:
        if os.path.exists(path):
            dst_name = safe_name(path)
            shutil.copy2(path, os.path.join(root, dst_name))
            manifest.append({'source': path, 'snapshot': dst_name})
    save_json(os.path.join(root, 'manifest.json'), {'files': manifest})


def af3_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/skin.arctic.fuse.3'), *parts))


def tmdbhelper_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/plugin.video.themoviedb.helper'), *parts))


def skinhelper_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/script.skin.helper.widgets'), *parts))


SHARED_ICON_FILENAMES = (
    'certified.png', 'emmys.png', 'ends.png', 'imdb.png', 'metacritic.png',
    'oscars.png', 'oscars_bp.png', 'popcorn.png', 'popcorn_spilt.png',
    'rtfresh.png', 'rtrotten.png', 'steam.png', 'steam-dev.png', 'steam-pub.png',
    'steam-ach.png', 'tmdb.png', 'verified.png',
)


def kpm_shared_icon_dir() -> str:
    return norm(os.path.join(translate('special://home/addons/{0}'.format(ADDON_ID)), 'resources', 'media', 'shared-icons'))


def kpm_shared_icon_path(filename: str) -> str:
    return norm(os.path.join(kpm_shared_icon_dir(), filename))


def _af3_rating_icon_dirs() -> List[str]:
    """Return AF3 rating icon folders that can consume KPM shared icons.

    AF3 textures reference flags/$VAR[Color_Directory]/ratings/<file>.png.
    Depending on skin packaging, that can exist under skin/media/flags or a
    development/unpacked skin flags folder, so keep both targets safe.
    """
    skin_root = af3_path()
    dirs: List[str] = []
    roots = [os.path.join(skin_root, 'media', 'flags'), os.path.join(skin_root, 'flags')]
    for flags_root in roots:
        if os.path.isdir(flags_root):
            try:
                for color in os.listdir(flags_root):
                    ratings_dir = os.path.join(flags_root, color, 'ratings')
                    if os.path.isdir(ratings_dir):
                        dirs.append(norm(ratings_dir))
            except Exception:
                pass
    # Fallback for the default AF3 color folder used by the Steam/KPM patches.
    for fallback in (os.path.join(skin_root, 'media', 'flags', 'color', 'ratings'),
                     os.path.join(skin_root, 'flags', 'color', 'ratings')):
        if os.path.isdir(os.path.dirname(fallback)) and norm(fallback) not in dirs:
            dirs.append(norm(fallback))
    # Stable order, no duplicates.
    out: List[str] = []
    for path in dirs:
        if path not in out:
            out.append(path)
    return out


def shared_rating_icons_status() -> str:
    src_dir = kpm_shared_icon_dir()
    bundled = [name for name in SHARED_ICON_FILENAMES if os.path.exists(os.path.join(src_dir, name))]
    return 'KPM source {0}/{1}; AF3 target dirs {2}'.format(len(bundled), len(SHARED_ICON_FILENAMES), len(_af3_rating_icon_dirs()))


def clear_pycache(folder: str, prefixes: Tuple[str, ...]) -> None:
    cache = os.path.join(folder, '__pycache__')
    if not os.path.isdir(cache):
        return
    for name in os.listdir(cache):
        if name.endswith('.pyc') and any(name.startswith(prefix + '.') for prefix in prefixes):
            try:
                os.remove(os.path.join(cache, name))
            except Exception:
                pass


@dataclass
class Result:
    name: str
    status: str
    detail: str = ''


# -----------------------------------------------------------------------------
# Patch 1: AF3 Up Next episode thumbnail priority
# -----------------------------------------------------------------------------

def upnext_target() -> str:
    return af3_path('1080i', 'Includes_Images.xml')


def status_upnext() -> str:
    target = upnext_target()
    if not os.path.exists(target):
        return 'Missing target'
    text = read_text(target)
    if UPNEXT_MARKER in text:
        return 'Patched'
    if '<variable name="Image_UpNext">' in text:
        return 'Not patched'
    return 'Unknown layout'


def patch_upnext() -> Result:
    name = patch_title('upnext_episode_thumb', 'Episode Thumb Up Next')
    target = upnext_target()
    text = read_text(target)
    if UPNEXT_MARKER in text:
        return Result(name, 'Skipped', 'Already patched.')

    pattern = r'(?ms)([ \t]*)<variable\s+name="Image_UpNext">.*?</variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Anchor not found: variable Image_UpNext in Includes_Images.xml')

    original = match.group(0)
    nl = newline_of(text)
    indent = match.group(1)
    inner = indent + '    '
    new_block = nl.join([
        f'{indent}<variable name="Image_UpNext">',
        f'{inner}{UPNEXT_MARKER}',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(thumb))">$INFO[Window.Property(thumb)]</value>',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(landscape))">$INFO[Window.Property(landscape)]</value>',
        f'{indent}</variable>',
    ])

    snapshot('upnext_episode_thumb', [target])
    save_state('upnext_episode_thumb', {'target': target, 'original_block': original})
    text = text[:match.start()] + new_block + text[match.end():]
    write_text(target, text)
    return Result(name, 'Patched', 'Image_UpNext priority: thumb -> landscape.')


def remove_upnext() -> Result:
    name = patch_title('upnext_episode_thumb', 'Episode Thumb Up Next')
    target = upnext_target()
    text = read_text(target)
    if UPNEXT_MARKER not in text:
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('upnext_episode_thumb')
    original = state.get('original_block')
    if not original:
        raise RuntimeError('Original Image_UpNext block is missing from saved state.')
    pattern = r'(?ms)[ \t]*<variable\s+name="Image_UpNext">(?:(?!</variable>).)*?' + re.escape(UPNEXT_MARKER) + r'.*?</variable>'
    if not re.search(pattern, text):
        raise RuntimeError('Patched Image_UpNext block not found.')
    text = re.sub(pattern, original, text, count=1)
    write_text(target, text)
    delete_state('upnext_episode_thumb')
    return Result(name, 'Removed', 'Original Image_UpNext block restored only.')


# -----------------------------------------------------------------------------


# Patch 3: Skin Helper Widgets random Movies + TV Shows screensaver for AF3
# -----------------------------------------------------------------------------

def shw_targets() -> Tuple[str, str]:
    media = skinhelper_path('resources', 'lib', 'media.py')
    defaults = af3_path('1080i', 'Includes_Defaults.xml')
    return media, defaults


def status_shw() -> str:
    media, defaults = shw_targets()
    if not os.path.exists(media) or not os.path.exists(defaults):
        return 'Missing target'
    t1 = read_text(media)
    t2 = read_text(defaults)
    method_ok = SHW_METHOD_START in t1 or LEGACY_SHW_METHOD_START in t1 or re.search(r'def\s+randommoviestvshows\s*\(\s*self\s*\)\s*:', t1)
    xml_ok = SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2
    if method_ok and xml_ok:
        return 'Patched'
    return 'Not patched'


def extract_variable_block(text: str, variable_name: str) -> Optional[str]:
    pattern = r'(?ms)[ \t]*<variable\s+name="' + re.escape(variable_name) + r'">.*?</variable>'
    match = re.search(pattern, text)
    return match.group(0) if match else None


def legacy_shw_xml_backup(defaults: str) -> Optional[str]:
    backup = defaults + '.afm-random-movies-tvshows-xml.bak'
    if os.path.exists(backup):
        try:
            return extract_variable_block(read_text(backup), 'Defs_ScreensaverWidget')
        except Exception:
            return None
    return None


def patch_shw_media(text: str) -> str:
    nl = newline_of(text)
    has_any_method = (SHW_METHOD_START in text or LEGACY_SHW_METHOD_START in text or
                      re.search(r'def\s+randommoviestvshows\s*\(\s*self\s*\)\s*:', text))
    if not has_any_method:
        method = nl.join([
            f'    {SHW_METHOD_START}',
            '    def randommoviestvshows(self):',
            '        """get random movies and tvshows only - no episodes, no music, no pvr"""',
            '        all_items = self.movies.random()',
            '        all_items += self.tvshows.random()',
            '        return sorted(all_items, key=lambda k: random.random())[:self.options["limit"]]',
            f'    {SHW_METHOD_END}',
            '',
        ]) + nl
        anchor = '    def inprogress(self):'
        if anchor not in text:
            raise RuntimeError('Anchor not found in media.py: def inprogress(self)')
        text = text.replace(anchor, method + anchor, 1)

    if SHW_ENTRY_MARKER not in text and LEGACY_SHW_ENTRY_MARKER not in text:
        old = '            (self.addon.getLocalizedString(32059), "random&mediatype=media", "DefaultMovies.png"),'
        if old in text:
            new = old + nl + f'            ("Random Movies + TV Shows", "randommoviestvshows&mediatype=media", "DefaultMovies.png"),  {SHW_ENTRY_MARKER}'
            text = text.replace(old, new, 1)
    return text


def patch_shw_xml(text: str, limit: int) -> Tuple[str, str]:
    pattern = r'(?ms)([ \t]*)<variable\s+name="Defs_ScreensaverWidget">.*?</variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_Defaults.xml: variable Defs_ScreensaverWidget')
    original = match.group(0)
    nl = newline_of(text)
    indent = match.group(1)
    inner = indent + '    '
    path = f'plugin://script.skin.helper.widgets/?action=randommoviestvshows&amp;mediatype=media&amp;limit={limit}'
    new_block = nl.join([
        f'{indent}<variable name="Defs_ScreensaverWidget">',
        f'{inner}{SHW_XML_MARKER}',
        f'{inner}<value>{path}</value>',
        f'{indent}</variable>',
    ])
    text = text[:match.start()] + new_block + text[match.end():]
    return text, original


def patch_shw(limit: int = 100) -> Result:
    name = patch_title('shw_random_movies_tvshows', 'Movies + Shows Screensaver')
    media, defaults = shw_targets()
    t1 = read_text(media)
    t2 = read_text(defaults)
    if (SHW_METHOD_START in t1 or LEGACY_SHW_METHOD_START in t1) and (SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2):
        return Result(name, 'Skipped', 'Already patched.')

    snapshot('shw_random_movies_tvshows', [media, defaults])
    n1 = patch_shw_media(t1)
    if SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2:
        n2 = t2
        original_xml = None
    else:
        n2, original_xml = patch_shw_xml(t2, limit)
    save_state('shw_random_movies_tvshows', {'media': media, 'defaults': defaults, 'original_xml_block': original_xml})
    write_text(media, n1)
    write_text(defaults, n2)
    clear_pycache(os.path.dirname(media), ('media',))
    return Result(name, 'Patched', f'Screensaver path: random movies + TV shows only, limit={limit}.')


def remove_shw() -> Result:
    name = patch_title('shw_random_movies_tvshows', 'Movies + Shows Screensaver')
    media, defaults = shw_targets()
    t1 = read_text(media)
    t2 = read_text(defaults)
    has_markers = any(marker in t1 for marker in (SHW_METHOD_START, LEGACY_SHW_METHOD_START, SHW_ENTRY_MARKER, LEGACY_SHW_ENTRY_MARKER)) or any(marker in t2 for marker in (SHW_XML_MARKER, LEGACY_SHW_XML_MARKER))
    if not has_markers:
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('shw_random_movies_tvshows') if os.path.exists(state_file('shw_random_movies_tvshows')) else {}

    # Remove method block by marker. Supports current KPM markers and the older uploaded AFM PowerShell markers.
    for start, end in ((SHW_METHOD_START, SHW_METHOD_END), (LEGACY_SHW_METHOD_START, LEGACY_SHW_METHOD_END)):
        method_pattern = r'(?ms)\r?\n?    ' + re.escape(start) + r'.*?    ' + re.escape(end) + r'\r?\n?'
        t1 = re.sub(method_pattern, '\n', t1, count=1)

    # Remove optional listing line by marker.
    for marker in (SHW_ENTRY_MARKER, LEGACY_SHW_ENTRY_MARKER):
        entry_pattern = r'(?m)^.*' + re.escape(marker) + r'.*(\r?\n)?'
        t1 = re.sub(entry_pattern, '', t1, count=1)

    # Restore only the original XML variable block. If this was an older PS1 patch, read its .bak file
    # and restore only the Defs_ScreensaverWidget variable from that backup, not the whole XML file.
    if SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2:
        original = state.get('original_xml_block') or legacy_shw_xml_backup(defaults)
        if not original:
            raise RuntimeError('Cannot remove SHW XML patch: original Defs_ScreensaverWidget block state/legacy backup is missing.')
        marker_pat = re.escape(SHW_XML_MARKER) + '|' + re.escape(LEGACY_SHW_XML_MARKER)
        pattern = r'(?ms)[ \t]*<variable\s+name="Defs_ScreensaverWidget">(?:(?!</variable>).)*?(?:' + marker_pat + r').*?</variable>'
        t2 = re.sub(pattern, original, t2, count=1)

    write_text(media, t1)
    write_text(defaults, t2)
    clear_pycache(os.path.dirname(media), ('media',))
    delete_state('shw_random_movies_tvshows')
    return Result(name, 'Removed', 'Injected method/listing removed; original XML variable restored only.')



# -----------------------------------------------------------------------------
# Patch 4 removed in v0.1.44: AF3 x LRS Ratings UI is no longer installed/removed by KPM.


# Patch 5: fullscreen pause rating row beside Paused
# -----------------------------------------------------------------------------

def vfs_pause_target() -> str:
    # Legacy target from v0.1.8-v0.1.11. Kept so remove/patch can clean old blocks.
    return af3_path('1080i', 'VideoFullScreen.xml')


def seekbar_pause_target() -> str:
    # Actual AF3 pause overlay with the Paused header is DialogSeekBar.xml.
    return af3_path('1080i', 'DialogSeekBar.xml')


def video_osd_target() -> str:
    # Full OSD window shown by pressing M / videoosd.
    return af3_path('1080i', 'VideoOSD.xml')


def includes_osd_target() -> str:
    # OSD detail layout includes title / plot / metadata area used by VideoOSD.
    return af3_path('1080i', 'Includes_OSD.xml')


def includes_actions_target() -> str:
    # AF3 OSD timeout actions live here.
    return af3_path('1080i', 'Includes_Actions.xml')


def includes_images_target() -> str:
    return af3_path('1080i', 'Includes_Images.xml')


def includes_furniture_target() -> str:
    return af3_path('1080i', 'Includes_Furniture.xml')


def _has_marked_block(text: str, start: str, end: str) -> bool:
    return start in text and end in text


def status_vfs_pause_ratings() -> str:
    seekbar = seekbar_pause_target()
    videoosd = video_osd_target()
    includes_osd = includes_osd_target()
    includes_actions = includes_actions_target()
    vfs = vfs_pause_target()
    if not os.path.exists(seekbar):
        return 'Missing DialogSeekBar.xml'
    if not os.path.exists(videoosd):
        return 'Missing VideoOSD.xml'
    if not os.path.exists(includes_osd):
        return 'Missing Includes_OSD.xml'
    if not os.path.exists(includes_actions):
        return 'Missing Includes_Actions.xml'
    seekbar_text = read_text(seekbar)
    videoosd_text = read_text(videoosd)
    includes_osd_text = read_text(includes_osd)
    includes_actions_text = read_text(includes_actions)
    has_auto_osd = DIALOG_SEEKBAR_AUTO_OSD_MARKER in seekbar_text
    has_seekbar_clearart = _has_marked_block(seekbar_text, DIALOG_SEEKBAR_CLEARART_START, DIALOG_SEEKBAR_CLEARART_END)
    has_seekbar_inline = _has_marked_block(seekbar_text, DIALOG_SEEKBAR_PAUSE_RATINGS_START, DIALOG_SEEKBAR_PAUSE_RATINGS_END)
    has_videoosd_clearart = _has_marked_block(videoosd_text, VIDEOOSD_CLEARART_START, VIDEOOSD_CLEARART_END)
    has_fast_close = _has_marked_block(videoosd_text, VIDEOOSD_FAST_CLOSE_START, VIDEOOSD_FAST_CLOSE_END)
    has_plot_width = _has_marked_block(includes_osd_text, OSD_PLOT_WIDTH_START, OSD_PLOT_WIDTH_END)
    has_range_hidden = _has_marked_block(includes_osd_text, OSD_RANGE_MARKERS_START, OSD_RANGE_MARKERS_END)
    has_pause_stay = _has_marked_block(includes_actions_text, ACTION_OSD_PAUSE_STAY_START, ACTION_OSD_PAUSE_STAY_END)
    has_legacy = os.path.exists(vfs) and _has_marked_block(read_text(vfs), VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END)
    if has_auto_osd and has_seekbar_clearart and has_fast_close and has_plot_width and has_range_hidden and has_pause_stay and not has_seekbar_inline and not has_videoosd_clearart and not has_legacy:
        return 'Patched'
    parts = []
    if has_auto_osd:
        parts.append('Auto OSD')
    if has_seekbar_clearart:
        parts.append('clearart behind progress')
    if has_videoosd_clearart:
        parts.append('old front clearart cleanup available')
    if has_fast_close:
        parts.append('fast close')
    if has_plot_width:
        parts.append('plot width')
    if has_range_hidden:
        parts.append('chapter ticks hidden')
    if has_pause_stay:
        parts.append('pause stay')
    if has_seekbar_inline:
        parts.append('old inline rating cleanup available')
    if has_legacy:
        parts.append('legacy VideoFullScreen cleanup available')
    return 'Partial: ' + ', '.join(parts) if parts else 'Not patched'


def _remove_marked_block(text: str, start: str, end: str) -> Tuple[str, bool]:
    if start not in text or end not in text:
        return text, False
    pattern = r'(?ms)\s*' + re.escape(start) + r'.*?' + re.escape(end)
    new_text = re.sub(pattern, '', text, count=1)
    return new_text, new_text != text


def _remove_seekbar_auto_videoosd(text: str) -> Tuple[str, bool]:
    if DIALOG_SEEKBAR_AUTO_OSD_MARKER not in text:
        return text, False
    # v0.1.14-v0.1.20 used an immediate DialogSeekBar onload ActivateWindow(videoosd).
    # v0.1.21 keeps only a marker/comment and lets service.py open VideoOSD after a
    # short dialog-safe pause grace. Remove either shape cleanly.
    pattern = (
        r'(?ms)\s*' + re.escape(DIALOG_SEEKBAR_AUTO_OSD_MARKER) +
        r'(?:\s*<!--.*?-->)?' +
        r'(?:\s*<onload[^>]*>ActivateWindow\(videoosd\)</onload>)?'
    )
    new_text = re.sub(pattern, '', text, count=1)
    return new_text, new_text != text


def _inject_seekbar_auto_videoosd(text: str, nl: str) -> Tuple[str, bool]:
    """Mark DialogSeekBar as KPM pause-OSD managed without stealing focus.

    Earlier builds fired ActivateWindow(videoosd) directly from DialogSeekBar onload.
    That raced with automatic subtitle/add-on dialogs at playback startup and could
    leave focus on the underlying OSD. Since v0.1.21, service.py opens VideoOSD
    with no intentional normal-pause delay and only when no foreign dialog has focus; a longer guard is used only during playback startup.
    """
    text, removed = _remove_seekbar_auto_videoosd(text)
    block = nl.join([
        '    ' + DIALOG_SEEKBAR_AUTO_OSD_MARKER,
        '    <!-- KPM v0.1.23+: service.py opens videoosd with no intentional normal-pause delay; startup guard remains for auto subtitle dialogs. -->',
    ])
    if '<zorder>0</zorder>' in text:
        return text.replace('<zorder>0</zorder>', '<zorder>0</zorder>' + nl + block, 1), True
    if '<window>' in text:
        return text.replace('<window>', '<window>' + nl + block, 1), True
    raise RuntimeError('Anchor not found in DialogSeekBar.xml: <zorder>0</zorder> or <window>')




def _videoosd_clearart_block(nl: str) -> str:
    return nl.join([
        '            ' + VIDEOOSD_CLEARART_START,
        '            <!-- KPM right-side clearart panel for full VideoOSD. Kodi artwork first, TMDbHelper fallback allowed. -->',
        '            <control type="group">',
        '                <visible>Window.IsActive(videoosd) + Player.HasMedia + !Pvr.IsPlayingTv</visible>',
        '                <visible>!Window.IsVisible(DialogPlayerProcessInfo.xml) + !Window.IsVisible(DialogSlider.xml)</visible>',
        '                <right>view_osd_r</right>',
        '                <bottom>180</bottom>',
        '                <width>520</width>',
        '                <height>300</height>',
        '                <animation effect="fade" start="0" end="100" time="200">WindowOpen</animation>',
        '                <control type="image">',
        '                    <width>100%</width>',
        '                    <height>100%</height>',
        '                    <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                    <texture background="true">$INFO[VideoPlayer.Art(clearart)]</texture>',
        '                    <visible>!String.IsEmpty(VideoPlayer.Art(clearart))</visible>',
        '                </control>',
        '                <control type="image">',
        '                    <width>100%</width>',
        '                    <height>100%</height>',
        '                    <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                    <texture background="true">$INFO[VideoPlayer.Art(tvshow.clearart)]</texture>',
        '                    <visible>String.IsEmpty(VideoPlayer.Art(clearart)) + !String.IsEmpty(VideoPlayer.Art(tvshow.clearart))</visible>',
        '                </control>',
        '                <control type="image">',
        '                    <width>100%</width>',
        '                    <height>100%</height>',
        '                    <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                    <texture background="true">$INFO[Window(Home).Property(TMDbHelper.Player.ClearArt)]</texture>',
        '                    <visible>String.IsEmpty(VideoPlayer.Art(clearart)) + String.IsEmpty(VideoPlayer.Art(tvshow.clearart)) + !String.IsEmpty(Window(Home).Property(TMDbHelper.Player.ClearArt))</visible>',
        '                </control>',
        '            </control>',
        '            ' + VIDEOOSD_CLEARART_END,
    ])


def _remove_videoosd_clearart(text: str) -> Tuple[str, bool]:
    return _remove_marked_block(text, VIDEOOSD_CLEARART_START, VIDEOOSD_CLEARART_END)


def _seekbar_clearart_block(nl: str) -> str:
    return nl.join([
        '                        ' + DIALOG_SEEKBAR_CLEARART_START,
        '                        <!-- KPM clearart is intentionally drawn inside DialogSeekBar before OSD_Progress_Bar, so the progress line and time labels render above it. -->',
        '                        <control type="group">',
        '                            <visible>Window.IsActive(videoosd) + Player.HasMedia + !Pvr.IsPlayingTv</visible>',
        '                            <visible>!Window.IsVisible(DialogPlayerProcessInfo.xml) + !Window.IsVisible(DialogSlider.xml)</visible>',
        '                            <right>view_osd_r</right>',
        '                            <bottom>180</bottom>',
        '                            <width>480</width>',
        '                            <height>270</height>',
        '                            <animation effect="fade" start="0" end="100" time="200">WindowOpen</animation>',
        '                            <control type="image">',
        '                                <width>100%</width>',
        '                                <height>100%</height>',
        '                                <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                                <texture background="true">$INFO[VideoPlayer.Art(clearart)]</texture>',
        '                                <visible>!String.IsEmpty(VideoPlayer.Art(clearart))</visible>',
        '                            </control>',
        '                            <control type="image">',
        '                                <width>100%</width>',
        '                                <height>100%</height>',
        '                                <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                                <texture background="true">$INFO[VideoPlayer.Art(tvshow.clearart)]</texture>',
        '                                <visible>String.IsEmpty(VideoPlayer.Art(clearart)) + !String.IsEmpty(VideoPlayer.Art(tvshow.clearart))</visible>',
        '                            </control>',
        '                            <control type="image">',
        '                                <width>100%</width>',
        '                                <height>100%</height>',
        '                                <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                                <texture background="true">$INFO[Window(Home).Property(TMDbHelper.Player.ClearArt)]</texture>',
        '                                <visible>String.IsEmpty(VideoPlayer.Art(clearart)) + String.IsEmpty(VideoPlayer.Art(tvshow.clearart)) + !String.IsEmpty(Window(Home).Property(TMDbHelper.Player.ClearArt))</visible>',
        '                            </control>',
        '                        </control>',
        '                        ' + DIALOG_SEEKBAR_CLEARART_END,
    ])


def _remove_seekbar_clearart(text: str) -> Tuple[str, bool]:
    return _remove_marked_block(text, DIALOG_SEEKBAR_CLEARART_START, DIALOG_SEEKBAR_CLEARART_END)


def _inject_seekbar_clearart(text: str, nl: str) -> Tuple[str, bool]:
    text, _ = _remove_seekbar_clearart(text)
    block = _seekbar_clearart_block(nl)
    anchor = '                        <include>OSD_Progress_Labels</include>'
    if anchor not in text:
        raise RuntimeError('Anchor not found in DialogSeekBar.xml: OSD_Progress_Labels include')
    return text.replace(anchor, block + nl + anchor, 1), True


def _inject_videoosd_clearart(text: str, nl: str) -> Tuple[str, bool]:
    text, removed = _remove_videoosd_clearart(text)
    block = _videoosd_clearart_block(nl)
    anchor = nl + '    </controls>'
    if anchor not in text:
        raise RuntimeError('Anchor not found in VideoOSD.xml: closing </controls>')
    text = text.replace(anchor, nl + block + anchor, 1)
    return text, True


def _fast_close_block(nl: str, indent: str = '                            ') -> str:
    return nl.join([
        indent + VIDEOOSD_FAST_CLOSE_START,
        indent + '<onclick condition="Player.Paused">Close</onclick>',
        indent + '<onclick>PlayerControl(Play)</onclick>',
        indent + VIDEOOSD_FAST_CLOSE_END,
    ])


def _restore_videoosd_fast_close(text: str, nl: str) -> Tuple[str, bool]:
    if VIDEOOSD_FAST_CLOSE_START not in text or VIDEOOSD_FAST_CLOSE_END not in text:
        return text, False
    pattern = re.compile(r'(?ms)\s*' + re.escape(VIDEOOSD_FAST_CLOSE_START) + r'.*?' + re.escape(VIDEOOSD_FAST_CLOSE_END))
    new_text = pattern.sub(nl + '                            <onclick>PlayerControl(Play)</onclick>', text, count=1)
    return new_text, new_text != text


def _inject_videoosd_fast_close(text: str, nl: str) -> Tuple[str, bool]:
    text, _ = _restore_videoosd_fast_close(text, nl)
    pattern = re.compile(
        r'(?ms)(<control type="button" id="6001">.*?)(\s*<onclick>PlayerControl\(Play\)</onclick>)(.*?</control>)'
    )
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in VideoOSD.xml: button id 6001 PlayerControl(Play)')
    block = nl + _fast_close_block(nl)
    return text[:match.start(2)] + block + text[match.end(2):], True


def _restore_osd_plot_width(text: str, nl: str) -> Tuple[str, bool]:
    """Restore the OSD plot width parameter modified by KPM."""
    if OSD_PLOT_WIDTH_START not in text or OSD_PLOT_WIDTH_END not in text:
        return text, False
    pattern = re.compile(
        r'(?ms)\s*' + re.escape(OSD_PLOT_WIDTH_START) + r'.*?' + re.escape(OSD_PLOT_WIDTH_END)
    )
    replacement = nl + '                    <param name="width">info_panel_w</param>'
    new_text = pattern.sub(replacement, text, count=1)
    return new_text, new_text != text


def _inject_osd_plot_width(text: str, nl: str) -> Tuple[str, bool]:
    """Shorten only the plot width inside OSD_Progress_Details_Extended.

    This keeps title, info line, ratings, and buttons unchanged, but stops the
    plot text before the clearart area on the right.
    """
    text, _ = _restore_osd_plot_width(text, nl)
    pattern = re.compile(
        r'(?ms)(<include name="OSD_Progress_Details_Extended">.*?'
        r'<include content="Info_Plot" condition="\$PARAM\[plot_visible\]">.*?)'
        r'(\s*<param name="width">info_panel_w</param>)'
    )
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_OSD.xml: OSD_Progress_Details_Extended Info_Plot width')
    block = nl.join([
        '                    ' + OSD_PLOT_WIDTH_START,
        '                    <param name="width">900</param>',
        '                    ' + OSD_PLOT_WIDTH_END,
    ])
    return text[:match.start(2)] + nl + block + text[match.end(2):], True


def _restore_osd_range_markers(text: str, nl: str) -> Tuple[str, bool]:
    """Restore cutlist/chapter range marker controls hidden by KPM."""
    if OSD_RANGE_MARKERS_START not in text or OSD_RANGE_MARKERS_END not in text:
        return text, False
    pattern = re.compile(
        r'(?ms)\s*' + re.escape(OSD_RANGE_MARKERS_START) + r'.*?' + re.escape(OSD_RANGE_MARKERS_END)
    )
    replacement = nl.join([
        '        <!-- CutList and Chapters Range -->',
        '        <control type="ranges">',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="panel_fg_50">progress/marker.png</righttexture>',
        '            <info>Player.CutList</info>',
        '        </control>',
        '        <control type="ranges">',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="panel_fg_50">progress/marker.png</righttexture>',
        '            <info>Player.Chapters</info>',
        '        </control>',
    ])
    new_text = pattern.sub(nl + replacement, text, count=1)
    return new_text, new_text != text


def _inject_osd_range_markers_hidden(text: str, nl: str) -> Tuple[str, bool]:
    """Hide chapter/cutlist tick markers on the progress line.

    The orange progress and time labels remain intact. Only the small white
    range/chapter marker ticks are suppressed.
    """
    text, _ = _restore_osd_range_markers(text, nl)
    pattern = re.compile(
        r'(?ms)(\s*<!-- CutList and Chapters Range -->\s*'
        r'<control type="ranges">.*?<info>Player\.CutList</info>\s*</control>\s*'
        r'<control type="ranges">.*?<info>Player\.Chapters</info>\s*</control>)'
    )
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_OSD.xml: CutList and Chapters Range controls')
    block = nl.join([
        '        ' + OSD_RANGE_MARKERS_START,
        '        <!-- KPM hides the small cutlist/chapter marker ticks on the progress line. -->',
        '        <control type="ranges">',
        '            <visible>false</visible>',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="00ffffff">progress/marker.png</righttexture>',
        '            <info>Player.CutList</info>',
        '        </control>',
        '        <control type="ranges">',
        '            <visible>false</visible>',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="00ffffff">progress/marker.png</righttexture>',
        '            <info>Player.Chapters</info>',
        '        </control>',
        '        ' + OSD_RANGE_MARKERS_END,
    ])
    return text[:match.start()] + nl + block + text[match.end():], True


def _original_action_osd_button_block(nl: str) -> str:
    return nl.join([
        '    <include name="Action_OSD_Button">',
        '        <onfocus condition="!String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onfocus>',
        '        <onunfocus>CancelAlarm(osd_timeout,true)</onunfocus>',
        '',
        '        <onclick condition="!String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onclick>',
        '    </include>',
    ])


def _pause_stay_action_osd_button_block(nl: str) -> str:
    return nl.join([
        '    ' + ACTION_OSD_PAUSE_STAY_START,
        '    <!-- KPM: while paused, do not start AF3 osd_timeout; the full OSD stays until playback resumes or user closes it. -->',
        '    <include name="Action_OSD_Button">',
        '        <onfocus condition="!Player.Paused + !String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onfocus>',
        '        <onfocus condition="Player.Paused">CancelAlarm(osd_timeout,true)</onfocus>',
        '        <onunfocus>CancelAlarm(osd_timeout,true)</onunfocus>',
        '',
        '        <onclick condition="!Player.Paused + !String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onclick>',
        '        <onclick condition="Player.Paused">CancelAlarm(osd_timeout,true)</onclick>',
        '    </include>',
        '    ' + ACTION_OSD_PAUSE_STAY_END,
    ])


def _restore_action_osd_pause_stay(text: str, nl: str) -> Tuple[str, bool]:
    if ACTION_OSD_PAUSE_STAY_START not in text or ACTION_OSD_PAUSE_STAY_END not in text:
        return text, False
    pattern = re.compile(
        r'(?ms)\s*' + re.escape(ACTION_OSD_PAUSE_STAY_START) + r'.*?' + re.escape(ACTION_OSD_PAUSE_STAY_END)
    )
    replacement = nl + _original_action_osd_button_block(nl)
    new_text = pattern.sub(replacement, text, count=1)
    return new_text, new_text != text


def _inject_action_osd_pause_stay(text: str, nl: str) -> Tuple[str, bool]:
    text, _ = _restore_action_osd_pause_stay(text, nl)
    pattern = re.compile(r'(?ms)\s*<include name="Action_OSD_Button">.*?</include>')
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_Actions.xml: include Action_OSD_Button')
    block = nl + _pause_stay_action_osd_button_block(nl)
    return text[:match.start()] + block + text[match.end():], True

def _seekbar_lrs_slot_controls(slot: int, nl: str, indent: str = '                                ') -> str:
    """Hard-render one LRS player rating slot for DialogSeekBar.xml.

    No TMDbHelper, no Info_Meta_Object. It reads only:
      LibraryRatings.Player.RatingSlotN_Source
      LibraryRatings.Player.RatingSlotN_IconFile
      LibraryRatings.Player.RatingSlotN_Label
    """
    base = 'LibraryRatings.Player.RatingSlot{0}'.format(slot)
    has_data = (
        '!String.IsEmpty(Window(Home).Property({0}_Label)) + '
        '!String.IsEmpty(Window(Home).Property({0}_IconFile))'
    ).format(base)
    imdb_visible = has_data + ' + String.IsEqual(Window(Home).Property({0}_Source),imdb)'.format(base)
    other_visible = has_data + ' + !String.IsEqual(Window(Home).Property({0}_Source),imdb)'.format(base)
    return nl.join([
        indent + '<!-- LRS Player RatingSlot{0} -->'.format(slot),
        indent + '<control type="image">',
        indent + '    <width>52</width>',
        indent + '    <height>32</height>',
        indent + '    <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        indent + '    <centertop>50%</centertop>',
        indent + '    <texture colordiffuse="panel_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property({0}_IconFile)]</texture>'.format(base),
        indent + '    <visible>{0}</visible>'.format(imdb_visible),
        indent + '</control>',
        indent + '<control type="image">',
        indent + '    <width>32</width>',
        indent + '    <height>32</height>',
        indent + '    <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        indent + '    <centertop>50%</centertop>',
        indent + '    <texture colordiffuse="panel_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property({0}_IconFile)]</texture>'.format(base),
        indent + '    <visible>{0}</visible>'.format(other_visible),
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <height>80</height>',
        indent + '    <aligny>center</aligny>',
        indent + '    <label>$INFO[Window(Home).Property({0}_Label)]</label>'.format(base),
        indent + '    <textcolor>panel_fg_90</textcolor>',
        indent + '    <font>font_main</font>',
        indent + '    <width max="90">auto</width>',
        indent + '    <textoffsetx>0</textoffsetx>',
        indent + '    <visible>{0}</visible>'.format(has_data),
        indent + '</control>',
        indent + '<control type="group">',
        indent + '    <width>10</width>',
        indent + '    <visible>{0}</visible>'.format(has_data),
        indent + '</control>',
    ])


def _seekbar_original_header_include(nl: str, indent: str = '                            ') -> str:
    return nl.join([
        indent + '<include content="Furniture_Header">',
        indent + '    <param name="label">$VAR[Label_OSD_Header]</param>',
        indent + '    <param name="include_right">false</param>',
        indent + '    <param name="textcolor">panel_fg_90</param>',
        indent + '    <param name="top">780</param>',
        indent + '</include>',
    ])


def _seekbar_inline_header_block(nl: str) -> str:
    # Same header line as AF3 Furniture_Header, but the left side is a single
    # horizontal grouplist: [Paused] [IMDb 8.4] [TMDb 8.5] ...
    pause_visible = 'Player.Paused + !Player.Seeking + !Window.IsActive(videoosd) + !Window.IsVisible(1152) + !Window.IsVisible(1153)'
    fallback_visible = '!Player.Paused | Player.Seeking | Window.IsActive(videoosd) | Window.IsVisible(1152) | Window.IsVisible(1153)'
    lines = [
        '                            ' + DIALOG_SEEKBAR_PAUSE_RATINGS_START,
        '                            <!-- KPM inline Paused header replacement -->',
        '                            <control type="group">',
        '                                <visible>' + fallback_visible + '</visible>',
        _seekbar_original_header_include(nl, '                                '),
        '                            </control>',
        '                            <control type="group">',
        '                                <visible>' + pause_visible + '</visible>',
        '                                <top>780</top>',
        '                                <height>80</height>',
        '                                <left>view_pad</left>',
        '                                <right>view_pad</right>',
        '                                <include content="View_Line_Divider">',
        '                                    <param name="align">left</param>',
        '                                </include>',
        '                                <control type="grouplist">',
        '                                    <orientation>horizontal</orientation>',
        '                                    <height>80</height>',
        '                                    <width>720</width>',
        '                                    <itemgap>8</itemgap>',
        '                                    <align>left</align>',
        '                                    <control type="label">',
        '                                        <label>$VAR[Label_OSD_Header]</label>',
        '                                        <align>left</align>',
        '                                        <aligny>center</aligny>',
        '                                        <textcolor>panel_fg_90</textcolor>',
        '                                        <font>font_midi_bold</font>',
        '                                        <height>80</height>',
        '                                        <width>auto</width>',
        '                                    </control>',
        '                                    <control type="group">',
        '                                        <width>6</width>',
        '                                    </control>',
    ]
    for slot in range(1, 7):
        lines.append(_seekbar_lrs_slot_controls(slot, nl, '                                    '))
    lines.extend([
        '                                </control>',
        '                            </control>',
        '                            ' + DIALOG_SEEKBAR_PAUSE_RATINGS_END,
    ])
    return nl.join(lines)


def _restore_seekbar_pause_block(text: str, nl: str) -> Tuple[str, bool]:
    """Remove the KPM DialogSeekBar marker safely.

    v0.1.12 inserted a separate rating row after the original header. That can
    be removed directly. v0.1.13 replaces the original header include with a
    marked custom block, so removal must restore the original include instead
    of deleting the header entirely.
    """
    if DIALOG_SEEKBAR_PAUSE_RATINGS_START not in text or DIALOG_SEEKBAR_PAUSE_RATINGS_END not in text:
        return text, False
    pattern = re.compile(
        r'(?ms)\s*' + re.escape(DIALOG_SEEKBAR_PAUSE_RATINGS_START) + r'.*?' + re.escape(DIALOG_SEEKBAR_PAUSE_RATINGS_END)
    )
    m = pattern.search(text)
    if not m:
        return text, False
    block = m.group(0)
    replacement = ''
    if 'KPM inline Paused header replacement' in block:
        replacement = nl + _seekbar_original_header_include(nl)
    return text[:m.start()] + replacement + text[m.end():], True


def _inject_seekbar_pause_block(text: str, block: str, nl: str) -> str:
    # Replace the exact Furniture_Header instance that renders $VAR[Label_OSD_Header]
    # (Paused / Caching / Seeking) at top 780 in DialogSeekBar.xml.
    pattern = re.compile(
        r'(?ms)(\s*<include content="Furniture_Header">\s*'
        r'<param name="label">\$VAR\[Label_OSD_Header\]</param>.*?'
        r'<param name="top">780</param>\s*'
        r'</include>)'
    )
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in DialogSeekBar.xml: Furniture_Header with $VAR[Label_OSD_Header] and top 780')
    return text[:match.start()] + nl + block + text[match.end():]


def _reload_skin_after_patch() -> None:
    if xbmc:
        try:
            xbmc.executebuiltin('ReloadSkin()')
            log('[KPM] ReloadSkin requested after Fullscreen Pause Ratings patch')
        except Exception:
            log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def addon_install_path() -> str:
    return norm(translate(f'special://home/addons/{ADDON_ID}'))


def _start_resume_close_service() -> None:
    """Start the tiny service immediately after patching.

    Kodi will also start it at login because addon.xml declares xbmc.service.
    This RunScript path is only for the current session after the user patches
    without restarting Kodi. The service exits if another instance is already
    running.
    """
    if not xbmc:
        return
    try:
        service_path = os.path.join(addon_install_path(), 'service.py')
        xbmc.executebuiltin('RunScript({0})'.format(service_path))
        log('[KPM] Resume-close service start requested')
    except Exception:
        log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def patch_vfs_pause_ratings() -> Result:
    name = patch_title('vfs_pause_ratings', 'Pause Shows Full OSD')
    if status_vfs_pause_ratings() == 'Patched':
        _start_resume_close_service()
        return Result(name, 'Skipped', 'Already patched with current pause/full OSD layout.')
    seekbar = seekbar_pause_target()
    videoosd = video_osd_target()
    includes_osd = includes_osd_target()
    includes_actions = includes_actions_target()
    vfs = vfs_pause_target()
    targets = [seekbar, videoosd, includes_osd, includes_actions]
    if os.path.exists(vfs):
        targets.append(vfs)
    snapshot('vfs_pause_ratings', targets)

    # Clean legacy VideoFullScreen injection from v0.1.8-v0.1.11.
    legacy_removed = False
    if os.path.exists(vfs):
        vfs_text = read_text(vfs)
        vfs_new, legacy_removed = _remove_marked_block(vfs_text, VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END)
        if legacy_removed:
            write_text(vfs, vfs_new)

    # DialogSeekBar opens VideoOSD on pause and now owns the clearart layer.
    # Clearart is drawn BEFORE progress labels/bar so the line and times stay on top.
    seek_text = read_text(seekbar)
    seek_nl = newline_of(seek_text)
    seek_text, old_inline_removed = _restore_seekbar_pause_block(seek_text, seek_nl)
    seek_text, old_auto_removed = _remove_seekbar_auto_videoosd(seek_text)
    seek_text, old_seekbar_clearart_removed = _remove_seekbar_clearart(seek_text)
    seek_text, auto_inserted = _inject_seekbar_auto_videoosd(seek_text, seek_nl)
    seek_text, seekbar_clearart_inserted = _inject_seekbar_clearart(seek_text, seek_nl)
    write_text(seekbar, seek_text)

    # VideoOSD keeps the fast close-on-resume behavior. The old front-layer clearart
    # is removed because it covered the progress line.
    osd_text = read_text(videoosd)
    osd_nl = newline_of(osd_text)
    osd_text, old_videoosd_clearart_removed = _remove_videoosd_clearart(osd_text)
    osd_text, old_fast_removed = _restore_videoosd_fast_close(osd_text, osd_nl)
    osd_text, fast_inserted = _inject_videoosd_fast_close(osd_text, osd_nl)
    write_text(videoosd, osd_text)

    # OSD details plot width is shortened and the small cutlist/chapter marker ticks are hidden.
    includes_text = read_text(includes_osd)
    includes_nl = newline_of(includes_text)
    includes_text, old_plot_width_removed = _restore_osd_plot_width(includes_text, includes_nl)
    includes_text, plot_width_inserted = _inject_osd_plot_width(includes_text, includes_nl)
    includes_text, old_range_removed = _restore_osd_range_markers(includes_text, includes_nl)
    includes_text, range_inserted = _inject_osd_range_markers_hidden(includes_text, includes_nl)
    write_text(includes_osd, includes_text)

    # Prevent AF3 native OSD timeout from closing VideoOSD while playback is paused.
    actions_text = read_text(includes_actions)
    actions_nl = newline_of(actions_text)
    actions_text, old_pause_stay_removed = _restore_action_osd_pause_stay(actions_text, actions_nl)
    actions_text, pause_stay_inserted = _inject_action_osd_pause_stay(actions_text, actions_nl)
    write_text(includes_actions, actions_text)

    save_state('vfs_pause_ratings', {
        'seekbar_target': seekbar,
        'videoosd_target': videoosd,
        'includes_osd_target': includes_osd,
        'includes_actions_target': includes_actions,
        'legacy_cleanup': legacy_removed,
        'layout': 'service_managed_fast_auto_videoosd_clearart_behind_progress_pause_stay_chapter_ticks_hidden_plot_short_safe_resume_close',
        'auto_videoosd': True,
        'auto_videoosd_mode': 'service_fast_pause_startup_guard',
        'clearart_layer': 'DialogSeekBar before OSD_Progress_Bar',
        'clearart_box': {'right': 'view_osd_r', 'bottom': 180, 'width': 480, 'height': 270},
        'clearart_sources': ['VideoPlayer.Art(clearart)', 'VideoPlayer.Art(tvshow.clearart)', 'TMDbHelper.Player.ClearArt'],
        'fast_close_resume': True,
        'resume_close_service': True,
        'resume_close_no_action_back': True,
        'resume_close_dialog_safe': True,
        'pause_stay_until_resume': True,
        'hide_chapter_ticks': True,
        'plot_width': 900,
    })
    _reload_skin_after_patch()
    _start_resume_close_service()

    changed = any([
        legacy_removed, old_inline_removed, old_auto_removed, old_seekbar_clearart_removed,
        auto_inserted, seekbar_clearart_inserted, old_videoosd_clearart_removed,
        old_fast_removed, fast_inserted, old_plot_width_removed, plot_width_inserted,
        old_range_removed, range_inserted, old_pause_stay_removed, pause_stay_inserted,
    ])
    detail = 'Pause now opens full VideoOSD via the KPM service quickly on normal pause and stays open while paused; a longer startup guard is kept only for auto subtitle dialogs at playback start. Minimalist inline rating is removed, clearart is drawn behind the progress line, chapter/cutlist tick markers are hidden, OSD plot width is shortened, and KPM resume monitor closes OSD after playback resumes without Action(Back). VideoOSD can stay behind subtitle/audio/other dialogs without KPM stealing focus; auto subtitle dialogs at playback start are still guarded, but normal manual pause opens faster. ReloadSkin and service start requested.'
    if legacy_removed:
        detail += ' Legacy VideoFullScreen block was removed.'
    if old_videoosd_clearart_removed:
        detail += ' Old front-layer VideoOSD clearart block was removed.'
    return Result(name, 'Patched' if changed else 'Skipped', detail)


def remove_vfs_pause_ratings() -> Result:
    name = patch_title('vfs_pause_ratings', 'Pause Shows Full OSD')
    removed = []
    seekbar = seekbar_pause_target()
    if os.path.exists(seekbar):
        text = read_text(seekbar)
        nl = newline_of(text)
        text_new, did_header = _restore_seekbar_pause_block(text, nl)
        text_new, did_auto = _remove_seekbar_auto_videoosd(text_new)
        text_new, did_seekbar_clearart = _remove_seekbar_clearart(text_new)
        if did_header or did_auto or did_seekbar_clearart:
            write_text(seekbar, text_new)
            removed.append('DialogSeekBar.xml')

    videoosd = video_osd_target()
    if os.path.exists(videoosd):
        text = read_text(videoosd)
        nl = newline_of(text)
        text_new, did_clearart = _remove_videoosd_clearart(text)
        text_new, did_fast = _restore_videoosd_fast_close(text_new, nl)
        if did_clearart or did_fast:
            write_text(videoosd, text_new)
            removed.append('VideoOSD.xml')

    includes_osd = includes_osd_target()
    if os.path.exists(includes_osd):
        text = read_text(includes_osd)
        nl = newline_of(text)
        text_new, did_plot = _restore_osd_plot_width(text, nl)
        text_new, did_ranges = _restore_osd_range_markers(text_new, nl)
        if did_plot or did_ranges:
            write_text(includes_osd, text_new)
            removed.append('Includes_OSD.xml')

    includes_actions = includes_actions_target()
    if os.path.exists(includes_actions):
        text = read_text(includes_actions)
        nl = newline_of(text)
        text_new, did_pause_stay = _restore_action_osd_pause_stay(text, nl)
        if did_pause_stay:
            write_text(includes_actions, text_new)
            removed.append('Includes_Actions.xml')

    vfs = vfs_pause_target()
    if os.path.exists(vfs):
        text = read_text(vfs)
        text_new, did = _remove_marked_block(text, VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END)
        if did:
            write_text(vfs, text_new)
            removed.append('VideoFullScreen.xml legacy')
    delete_state('vfs_pause_ratings')
    if removed:
        _reload_skin_after_patch()
        return Result(name, 'Removed', 'Removed pause/full OSD edits from: {0}. ReloadSkin requested.'.format(', '.join(removed)))
    return Result(name, 'Skipped', 'Patch marker not found.')



# -----------------------------------------------------------------------------
# Patch 6: reliable studio logos
# -----------------------------------------------------------------------------


def _studio_image_var_block(nl: str) -> str:
    lines = [
        f'    {STUDIO_IMAGE_VAR_START}',
        '    <variable name="Image_CombinedStudio">',
        '        <value condition="!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))">$INFO[Window(Home).Property(KPM.StudioLogo.1)]</value>',
        '    </variable>',
        f'    {STUDIO_IMAGE_VAR_END}',
    ]
    return nl.join(lines)


def _studio_furniture_block_from_original(original: str, nl: str) -> str:
    """Patch Furniture_Studio without rebuilding its layout.

    The original AF3 block owns the exact position/size/animation. KPM only swaps
    the studio texture source and adds KPM visibility guards. This prevents the
    footer studio logo from moving when KPM is updated.
    """
    block = original.rstrip('\r\n')
    # Remove any stale KPM guards if the original came from an old KPM block.
    block = re.sub(r'(?m)^\s*<visible>String\.IsEqual\(Window\(Home\)\.Property\(KPM\.StudioLogos\.Show\),true\)</visible>\s*\r?\n?', '', block)
    block = re.sub(r'(?m)^\s*<visible>!String\.IsEmpty\(Window\(Home\)\.Property\(KPM\.StudioLogo\.1\)\)</visible>\s*\r?\n?', '', block)
    block = block.replace(STUDIO_FURNITURE_CURRENT_MARKER + nl, '').replace(STUDIO_FURNITURE_CURRENT_MARKER, '')

    texture_re = r'(<texture(?=[^>]*background="true")[^>]*>).*?(</texture>)'
    block_new, count = re.subn(texture_re, r'\1$INFO[Window(Home).Property(KPM.StudioLogo.1)]\2', block, count=1, flags=re.S)
    if count == 0:
        block_new, count = re.subn(r'(<texture[^>]*>).*?(</texture>)', r'\1$INFO[Window(Home).Property(KPM.StudioLogo.1)]\2', block, count=1, flags=re.S)
    if count == 0:
        raise RuntimeError('Cannot patch Furniture_Studio: texture line not found')
    block = block_new

    guards = nl.join([
        '            ' + STUDIO_FURNITURE_CURRENT_MARKER,
        '            <visible>String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)</visible>',
        '            <visible>!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))</visible>',
    ])
    # Put visibility on the existing outer control, right before the first image.
    if '<control type="image">' in block:
        block = block.replace('            <control type="image">', guards + nl + '            <control type="image">', 1)
    else:
        block = block.replace('        </control>', guards + nl + '        </control>', 1)
    return nl.join([f'    {STUDIO_FURNITURE_START}', block, f'    {STUDIO_FURNITURE_END}'])


def _studio_furniture_block(nl: str) -> str:
    # Fallback template only used when no saved original exists. It mirrors AF3's
    # stock Furniture_Studio layout and still uses only KPM.StudioLogo.1.
    original = nl.join([
        '    <include name="Furniture_Studio">',
        '        <control type="grouplist">',
        '            <align>right</align>',
        '            <orientation>horizontal</orientation>',
        '            <itemgap>20</itemgap>',
        '            <include>Furniture_SlidesOver</include>',
        '            <visible>!Player.HasMedia | Skin.HasSetting(Footer.DisableNowPlaying)</visible>',
        '            <visible>String.IsEmpty(ListItem.VideoCodec) | !Skin.HasSetting(Footer.EnableCodecs)</visible>',
        '            <control type="image">',
        '                <width>300</width>',
        '                <height>80</height>',
        '                <aspectratio align="right">keep</aspectratio>',
        '                <texture background="true">$VAR[Image_CombinedStudio]</texture>',
        '                <centertop>50%</centertop>',
        '            </control>',
        '        </control>',
        '    </include>',
    ])
    return _studio_furniture_block_from_original(original, nl)

def _replace_marked_block_only(text: str, start: str, end: str, replacement: str) -> Tuple[str, bool]:
    pattern = r'(?ms)\s*' + re.escape(start) + r'.*?' + re.escape(end)
    new_text, count = re.subn(pattern, '\n' + replacement, text, count=1)
    return new_text, count > 0


def _replace_studio_image_var(text: str, nl: str, state: dict) -> Tuple[str, bool]:
    replacement = _studio_image_var_block(nl)
    if STUDIO_IMAGE_VAR_START in text and STUDIO_IMAGE_VAR_END in text:
        text, did = _replace_marked_block_only(text, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END, replacement)
        if os.path.exists(state_file('reliable_studio_logos')):
            try:
                old_state = load_state('reliable_studio_logos')
                if old_state.get('original_image_var'):
                    state['original_image_var'] = old_state.get('original_image_var')
            except Exception:
                pass
        return text, did
    pattern = r'(?s)    <variable name="Image_CombinedStudio">.*?    </variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Cannot find Image_CombinedStudio variable in Includes_Images.xml')
    state['original_image_var'] = match.group(0)
    return text[:match.start()] + replacement + text[match.end():], True


def _replace_studio_furniture(text: str, nl: str, state: dict) -> Tuple[str, bool]:
    original_from_state = ''
    if os.path.exists(state_file('reliable_studio_logos')):
        try:
            old_state = load_state('reliable_studio_logos')
            original_from_state = old_state.get('original_furniture') or ''
        except Exception:
            original_from_state = ''

    if STUDIO_FURNITURE_START in text and STUDIO_FURNITURE_END in text:
        # Updating an older KPM studio patch: rebuild from the saved stock AF3 block
        # if possible, not from the previously rebuilt KPM block.
        original = original_from_state
        if not original:
            marked = re.search(r'(?ms)' + re.escape(STUDIO_FURNITURE_START) + r'.*?' + re.escape(STUDIO_FURNITURE_END), text)
            original = marked.group(0) if marked else ''
        replacement = _studio_furniture_block_from_original(original, nl) if original else _studio_furniture_block(nl)
        text, did = _replace_marked_block_only(text, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END, replacement)
        if original_from_state:
            state['original_furniture'] = original_from_state
        return text, did

    pattern = r'(?s)    <include name="Furniture_Studio">.*?(?=\n    <include name="Furniture_Codecs">)'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Cannot find Furniture_Studio include in Includes_Furniture.xml')
    original = match.group(0).rstrip('\r\n')
    state['original_furniture'] = original
    replacement = _studio_furniture_block_from_original(original, nl)
    return text[:match.start()] + replacement + text[match.end():], True


def status_reliable_studio_logos() -> str:
    images = includes_images_target()
    furniture = includes_furniture_target()
    if not os.path.exists(images) or not os.path.exists(furniture):
        return 'Missing target'
    ti = read_text(images)
    tf = read_text(furniture)
    if STUDIO_IMAGE_VAR_START in ti and STUDIO_FURNITURE_START in tf and os.path.exists(state_file('reliable_studio_logos')):
        if STUDIO_FURNITURE_CURRENT_MARKER in tf and 'KPM.StudioLogo.2' not in tf and 'KPM.StudioLogo.3' not in tf:
            return 'Patched'
        return 'Patched (old version; update needed)'
    if '<variable name="Image_CombinedStudio">' in ti and '<include name="Furniture_Studio">' in tf:
        return 'Not patched'
    return 'Unknown layout'


def patch_reliable_studio_logos() -> Result:
    name = patch_title('reliable_studio_logos', 'Reliable Studio Logos')
    if status_reliable_studio_logos() == 'Patched':
        _start_resume_close_service()
        return Result(name, 'Skipped', 'Already patched with current single-logo layout.')
    images = includes_images_target()
    furniture = includes_furniture_target()
    missing = [p for p in (images, furniture) if not os.path.exists(p)]
    if missing:
        raise FileNotFoundError('Missing target: ' + ', '.join(missing))
    snapshot('reliable_studio_logos', [images, furniture])
    state: Dict[str, object] = {'targets': {'images': images, 'furniture': furniture}}

    ti = read_text(images)
    ni = newline_of(ti)
    ti_new, did_images = _replace_studio_image_var(ti, ni, state)
    write_text(images, ti_new)

    tf = read_text(furniture)
    nf = newline_of(tf)
    tf_new, did_furniture = _replace_studio_furniture(tf, nf, state)
    write_text(furniture, tf_new)

    save_state('reliable_studio_logos', {
        **state,
        'max_logos': 1,
        'properties': ['KPM.StudioLogo.1'],
        'resource': 'resource.images.studios.coloured',
        'game_resource': 'resource.images.gamestudios.grayscale',
        'metadata_changed': False,
    })
    _reload_skin_after_patch()
    _start_resume_close_service()
    return Result(name, 'Patched' if (did_images or did_furniture) else 'Skipped', 'AF3 now uses one KPM resolved studio logo only. Raw AF3/TMDbHelper/ListItem fallback is disabled, multi-studio labels are split in the service, episode items can use parent TV show studios, missing/broken logos are skipped, and MyVideos metadata is unchanged. ReloadSkin and service start requested.')


def remove_reliable_studio_logos() -> Result:
    name = patch_title('reliable_studio_logos', 'Reliable Studio Logos')
    images = includes_images_target()
    furniture = includes_furniture_target()
    state = load_state('reliable_studio_logos') if os.path.exists(state_file('reliable_studio_logos')) else {}
    removed = []
    if os.path.exists(images):
        text = read_text(images)
        original = state.get('original_image_var') if isinstance(state, dict) else None
        if original and STUDIO_IMAGE_VAR_START in text:
            text, _ = _remove_marked_block(text, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END)
            # Insert original variable where the marked block was removed by matching a nearby double newline.
            # The removal leaves no Image_CombinedStudio variable, so put it back before Image_OSD_CombinedStudio.
            if '<variable name="Image_OSD_CombinedStudio">' in text:
                text = text.replace('    <variable name="Image_OSD_CombinedStudio">', original.rstrip('\r\n') + newline_of(text) + newline_of(text) + '    <variable name="Image_OSD_CombinedStudio">', 1)
                write_text(images, text)
                removed.append('Includes_Images.xml')
        elif STUDIO_IMAGE_VAR_START in text:
            text, did = _remove_marked_block(text, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END)
            if did:
                write_text(images, text)
                removed.append('Includes_Images.xml marker-only')

    if os.path.exists(furniture):
        text = read_text(furniture)
        original = state.get('original_furniture') if isinstance(state, dict) else None
        if original and STUDIO_FURNITURE_START in text:
            text, _ = _remove_marked_block(text, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END)
            if '    <include name="Furniture_Codecs">' in text:
                text = text.replace('    <include name="Furniture_Codecs">', original.rstrip('\r\n') + newline_of(text) + '    <include name="Furniture_Codecs">', 1)
                write_text(furniture, text)
                removed.append('Includes_Furniture.xml')
        elif STUDIO_FURNITURE_START in text:
            text, did = _remove_marked_block(text, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END)
            if did:
                write_text(furniture, text)
                removed.append('Includes_Furniture.xml marker-only')

    delete_state('reliable_studio_logos')
    if removed:
        _reload_skin_after_patch()
        return Result(name, 'Removed', 'Restored studio logo XML blocks from: {0}. ReloadSkin requested.'.format(', '.join(removed)))
    return Result(name, 'Skipped', 'Patch marker not found.')


# -----------------------------------------------------------------------------
# Tool: clear Kodi add-on icon thumbnail cache
# -----------------------------------------------------------------------------

ADDON_ICON_EXTENSIONS = ('.png', '.jpg', '.jpeg', '.webp')


def profile_database_path() -> str:
    return norm(translate('special://profile/Database'))


def thumbnails_path() -> str:
    return norm(translate('special://profile/Thumbnails'))


def latest_textures_db() -> str:
    db_dir = profile_database_path()
    if not os.path.isdir(db_dir):
        return ''
    candidates = []
    for name in os.listdir(db_dir):
        match = re.match(r'^Textures(\d+)\.db$', name, re.I)
        if match:
            candidates.append((int(match.group(1)), os.path.join(db_dir, name)))
    if not candidates:
        return ''
    candidates.sort(reverse=True)
    return candidates[0][1]


def _normalize_texture_url(value: str) -> str:
    text = unquote(str(value or '')).replace('\\', '/').lower()
    # image:// URLs often add a trailing slash after the encoded source path.
    while text.endswith('/'):
        text = text[:-1]
    return text


def _texture_table_columns(conn: sqlite3.Connection, table: str) -> List[str]:
    try:
        return [str(row[1]) for row in conn.execute(f'PRAGMA table_info({table})').fetchall()]
    except sqlite3.Error:
        return []


def _texture_table_exists(conn: sqlite3.Connection, table: str) -> bool:
    try:
        row = conn.execute('SELECT name FROM sqlite_master WHERE type=\'table\' AND name=?', (table,)).fetchone()
        return row is not None
    except sqlite3.Error:
        return False


def _looks_like_addon_icon_url(url: str) -> bool:
    text = _normalize_texture_url(url)
    if '/addons/' not in text and 'special://home/addons/' not in text and 'special://xbmc/addons/' not in text:
        return False
    # Clear all add-on icon files, not video artwork. Most add-ons use icon.png,
    # but this also catches icon.jpg/icon.webp if an add-on uses them.
    return any(text.endswith('/icon' + ext) or '/icon' + ext + '/' in text for ext in ADDON_ICON_EXTENSIONS)


def clear_addon_icon_cache() -> Result:
    name = 'Add-on Icon Cache'
    db_path = latest_textures_db()
    thumb_root = thumbnails_path()
    if not db_path or not os.path.exists(db_path):
        return Result(name, 'Skipped', 'Textures database not found.')

    removed_files = 0
    removed_rows = 0
    matched_rows: List[Tuple[int, str, str]] = []
    conn = sqlite3.connect(db_path, timeout=30)
    try:
        conn.row_factory = sqlite3.Row
        cols = _texture_table_columns(conn, 'texture')
        if not cols or 'url' not in cols:
            return Result(name, 'Skipped', 'Textures DB has no texture.url table/column.')
        id_col = 'idtexture' if 'idtexture' in cols else ('id' if 'id' in cols else cols[0])
        cached_col = 'cachedurl' if 'cachedurl' in cols else ''
        query_cols = f'{id_col}, url' + (f', {cached_col}' if cached_col else '')
        for row in conn.execute(f'SELECT {query_cols} FROM texture').fetchall():
            url = str(row['url'] or '')
            if _looks_like_addon_icon_url(url):
                cached = str(row[cached_col] or '') if cached_col else ''
                matched_rows.append((int(row[id_col]), url, cached))

        if not matched_rows:
            return Result(name, 'Skipped', 'No cached add-on icon rows found.')

        for _id, _url, cached in matched_rows:
            if cached:
                cached_path = os.path.join(thumb_root, cached.replace('/', os.sep).replace('\\', os.sep))
                if os.path.exists(cached_path):
                    try:
                        os.remove(cached_path)
                        removed_files += 1
                    except OSError:
                        pass
                # Some Kodi installs also have sidecar DDS cache for the same base name.
                base, _ext = os.path.splitext(cached_path)
                dds_path = base + '.dds'
                if os.path.exists(dds_path):
                    try:
                        os.remove(dds_path)
                        removed_files += 1
                    except OSError:
                        pass

        ids = [row[0] for row in matched_rows]
        placeholders = ','.join('?' for _ in ids)
        try:
            if _texture_table_exists(conn, 'sizes') and 'idtexture' in _texture_table_columns(conn, 'sizes'):
                conn.execute(f'DELETE FROM sizes WHERE idtexture IN ({placeholders})', ids)
        except sqlite3.Error:
            pass
        conn.execute(f'DELETE FROM texture WHERE {id_col} IN ({placeholders})', ids)
        removed_rows = conn.total_changes
        conn.commit()
    finally:
        conn.close()

    return Result(name, 'Cleared', f'Removed {len(matched_rows)} add-on icon cache rows and {removed_files} thumbnail files from {os.path.basename(db_path)}. Restart Kodi or reload skin so icons rebuild.')


def clear_addon_icon_cache_menu() -> None:
    message = (
        'Clear cached icons for all installed Kodi add-ons?\n\n'
        'This deletes only add-on icon thumbnail cache rows/files from the latest Textures DB. '
        'Original add-on icon.png files are not touched. Kodi will rebuild icons automatically.'
    )
    if not yesno(ADDON_NAME, message):
        return
    run_single(clear_addon_icon_cache)



# -----------------------------------------------------------------------------
# Diagnostics: Fullscreen pause ratings live/static export
# -----------------------------------------------------------------------------

DIAG_LIVE_DIRNAME = 'diagnostics_live'
DIAG_EXPORT_DIRNAME = 'diagnostics'
DIAG_LIVE_PREFIX = 'fullscreen-pause-ratings-live'


def _safe_call(default, func, *args):
    try:
        return func(*args)
    except Exception as exc:  # pylint: disable=broad-except
        return default if default is not None else f'ERROR: {exc}'


def info_label(expr: str) -> str:
    if xbmc:
        return _safe_call('', xbmc.getInfoLabel, expr)
    return ''


def cond_visible(expr: str) -> bool:
    if xbmc:
        try:
            return bool(xbmc.getCondVisibility(expr))
        except Exception:  # pylint: disable=broad-except
            return False
    return False


def _window_obj(window_id: int):
    if xbmcgui:
        try:
            return xbmcgui.Window(window_id)
        except Exception:  # pylint: disable=broad-except
            return None
    return None


def _window_prop(window_id: int, name: str) -> str:
    win = _window_obj(window_id)
    if not win:
        return ''
    try:
        return str(win.getProperty(name) or '')
    except Exception:  # pylint: disable=broad-except
        return ''


def _current_window_ids() -> Dict[str, int]:
    data = {'current_window_id': 0, 'current_dialog_id': 0}
    if not xbmcgui:
        return data
    for key, getter_name in (('current_window_id', 'getCurrentWindowId'), ('current_dialog_id', 'getCurrentWindowDialogId')):
        getter = getattr(xbmcgui, getter_name, None)
        if getter:
            try:
                data[key] = int(getter())
            except Exception:  # pylint: disable=broad-except
                data[key] = 0
    return data


def _lrs_property_matrix(window_ids: Optional[List[int]] = None) -> Dict[str, dict]:
    if window_ids is None:
        ids = [10000]
        current = _current_window_ids().get('current_window_id', 0)
        if current and current not in ids:
            ids.append(current)
    else:
        ids = window_ids
    services = ('Player', 'VideoPlayer', 'ListItem', 'Screensaver')
    suffixes = ('Source', 'Icon', 'IconFile', 'Label', 'Value')
    matrix: Dict[str, dict] = {}
    for wid in ids:
        wkey = str(wid)
        matrix[wkey] = {}
        for service in services:
            skey = service
            matrix[wkey][skey] = {
                'HasData': _window_prop(wid, f'LibraryRatings.{service}.HasData'),
                'ItemKey': _window_prop(wid, f'LibraryRatings.{service}.ItemKey'),
                'Title': _window_prop(wid, f'LibraryRatings.{service}.Title'),
                'DBType': _window_prop(wid, f'LibraryRatings.{service}.DBType'),
                'Display_RatingSlots': _window_prop(wid, f'LibraryRatings.{service}.Display_RatingSlots'),
                'EndsAt': {suffix: _window_prop(wid, f'LibraryRatings.{service}.EndsAt_{suffix}') for suffix in LRS_ENDSAT_SUFFIXES},
            }
            for slot in range(1, 7):
                slot_data = {}
                for suffix in suffixes:
                    slot_data[suffix] = _window_prop(wid, f'LibraryRatings.{service}.RatingSlot{slot}_{suffix}')
                matrix[wkey][skey][f'RatingSlot{slot}'] = slot_data
        matrix[wkey]['Display'] = {
            'RatingSlots': _window_prop(wid, 'LibraryRatings.Display.RatingSlots'),
            'Top250': _window_prop(wid, 'LibraryRatings.Display.Top250'),
            'Awards': _window_prop(wid, 'LibraryRatings.Display.Awards'),
            'TVStatus': _window_prop(wid, 'LibraryRatings.Display.TVStatus'),
        }
        matrix[wkey]['HomeHub'] = _lrs_homehub_display_props([wid]).get(str(wid), {})
    return matrix


def _player_runtime_state() -> Dict[str, object]:
    ids = _current_window_ids()
    return {
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        **ids,
        'conditions': {
            'Player.HasMedia': cond_visible('Player.HasMedia'),
            'Player.HasVideo': cond_visible('Player.HasVideo'),
            'Player.Playing': cond_visible('Player.Playing'),
            'Player.Paused': cond_visible('Player.Paused'),
            'Player.Seeking': cond_visible('Player.Seeking'),
            'Player.Caching': cond_visible('Player.Caching'),
            'Window.IsActive(fullscreenvideo)': cond_visible('Window.IsActive(fullscreenvideo)'),
            'Window.IsActive(VideoFullScreen.xml)': cond_visible('Window.IsActive(VideoFullScreen.xml)'),
            'Window.IsActive(videoosd)': cond_visible('Window.IsActive(videoosd)'),
            'Window.IsActive(DialogSeekBar.xml)': cond_visible('Window.IsActive(DialogSeekBar.xml)'),
            'Window.IsVisible(DialogSeekBar.xml)': cond_visible('Window.IsVisible(DialogSeekBar.xml)'),
            'Window.IsVisible(1152)': cond_visible('Window.IsVisible(1152)'),
            'Window.IsVisible(1153)': cond_visible('Window.IsVisible(1153)'),
        },
        'videoplayer_labels': {
            'Title': info_label('VideoPlayer.Title'),
            'TVShowTitle': info_label('VideoPlayer.TVShowTitle'),
            'Season': info_label('VideoPlayer.Season'),
            'Episode': info_label('VideoPlayer.Episode'),
            'DBID': info_label('VideoPlayer.DBID'),
            'DBTYPE': info_label('VideoPlayer.DBTYPE'),
            'Rating': info_label('VideoPlayer.Rating'),
            'UserRating': info_label('VideoPlayer.UserRating'),
            'Year': info_label('VideoPlayer.Year'),
            'FileNameAndPath': info_label('VideoPlayer.FileNameAndPath'),
        },
        'lrs_properties': _lrs_property_matrix(),
        'lrs_homehub_display': _lrs_homehub_display_props(),
        'lrs_strict_current_endsat': _lrs_strict_current_endsat_props(),
        'current_game_bridge': _current_game_bridge_report(),
    }


def _line_numbered_snippet(text: str, start_marker: str, end_marker: str, context: int = 8) -> str:
    lines = text.splitlines()
    start = end = -1
    for idx, line in enumerate(lines):
        if start_marker in line and start < 0:
            start = idx
        if end_marker in line:
            end = idx
            break
    if start < 0:
        return f'Marker not found: {start_marker}'
    if end < start:
        end = start
    lo = max(0, start - context)
    hi = min(len(lines), end + context + 1)
    return '\n'.join(f'{i + 1:05d}: {lines[i]}' for i in range(lo, hi))


def _full_file_digest(path: str) -> Dict[str, object]:
    data: Dict[str, object] = {'path': path, 'exists': os.path.exists(path)}
    if not os.path.exists(path):
        return data
    try:
        with open(path, 'rb') as handle:
            raw = handle.read()
        data['size'] = len(raw)
        data['mtime'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(path)))
        try:
            import hashlib
            data['sha256'] = hashlib.sha256(raw).hexdigest()
        except Exception:  # pylint: disable=broad-except
            pass
    except Exception as exc:  # pylint: disable=broad-except
        data['error'] = str(exc)
    return data


def _read_file_if_exists(path: str, max_chars: int = 300000) -> str:
    if not os.path.exists(path):
        return f'File not found: {path}'
    try:
        text = read_text(path)
    except Exception as exc:  # pylint: disable=broad-except
        return f'Could not read {path}: {exc}'
    if len(text) > max_chars:
        return text[-max_chars:]
    return text


def _read_live_text_if_exists(path: str, max_chars: int = 20000000) -> str:
    """Read live JSONL without corrupting the first line.

    Old diagnostics used a raw character tail, so exported JSONL could start in the
    middle of a JSON object. Export the full file when possible or tail only
    complete lines with a marker.
    """
    if not os.path.exists(path):
        return f'File not found: {path}'
    try:
        text = read_text(path)
    except Exception as exc:  # pylint: disable=broad-except
        return f'Could not read {path}: {exc}'
    if len(text) <= max_chars:
        return text
    tail = text[-max_chars:]
    first_nl = tail.find('\n')
    if first_nl >= 0:
        tail = tail[first_nl + 1:]
    return '# KPM diagnostic note: file was too large; exported tail starts at the next complete JSONL line.\n' + tail


def _latest_kodi_log_path() -> str:
    return norm(translate('special://logpath/kodi.log'))


def _filtered_kodi_log() -> str:
    keys = ('Kodi Patch Manager', 'KPM', 'StudioLogo', 'Image_CombinedStudio', 'resource.images.studios', 'resource.images.gamestudios', 'Misplaced [', 'Library Ratings Scraper', 'LibraryRatings', 'script.library.ratings.scraper', 'Steam Library', 'plugin.program.steam.library', 'steam_rating_display', 'achievement_display', 'metacritic_score', 'DisplaySlot', 'HomeHub', 'MyPrograms.xml', 'MyVideoNav.xml', 'Custom_1101_Hub.xml', 'Custom_1103_Hub.xml', 'Includes_Info.xml', 'RatingSlot', 'EndsAt', 'FinishTime', 'VideoFullScreen', 'fullscreenvideo', 'ERROR', 'Traceback', 'Skin Helper Service')
    return _filtered_kodi_log_for_keys(keys)




# -----------------------------------------------------------------------------
# LRS / Steam Library focused diagnostics (v0.1.79)
# Diagnostics/status only: no rendering XML patch, no Steam lower meta row patch.
# -----------------------------------------------------------------------------

LRS_STEAM_LOG_KEYS = (
    'Kodi Patch Manager', 'KPM', 'Library Ratings Scraper', 'LibraryRatings',
    'script.library.ratings.scraper', 'Steam Library', 'plugin.program.steam.library',
    'steam_rating_display', 'achievement_display', 'metacritic_score',
    'DisplaySlot', 'HomeHub', 'MyPrograms.xml', 'MyVideoNav.xml',
    'Custom_1101_Hub.xml', 'Custom_1103_Hub.xml', 'Includes_Info.xml',
    'RatingSlot', 'EndsAt', 'FinishTime', 'ERROR', 'Traceback'
)

LRS_HOMEHUB_BASE_PROPS = (
    'DisplayActive', 'DisplayMode', 'ItemKey', 'Title', 'DBType', 'Context',
    'Display_RatingSlots'
)

LRS_SLOT_SUFFIXES = ('Source', 'Icon', 'IconFile', 'Label', 'Value')
LRS_ENDSAT_SUFFIXES = ('Label', 'IconFile', 'Value', 'Source')

GAME_BRIDGE_PROPS = (
    'platform', 'is_steam_library', 'steam_appid', 'appid',
    'steam_rating_display', 'steam_review_percent', 'steam_review_desc', 'steam_review_total',
    'metacritic_score', 'achievement_display', 'achievement_unlocked', 'achievement_total',
    'lrs_game', 'lrs_item_type', 'library_ratings_type', 'DBTYPE', 'MediaType',
    'developer', 'developer_display', 'publisher', 'publisher_display'
)

AF3_LRS_CONTEXT_XMLS = (
    'Includes_Info.xml', 'Home.xml', 'MyPrograms.xml', 'MyVideoNav.xml',
    'Custom_1101_Hub.xml', 'Custom_1102_Hub.xml', 'Custom_1103_Hub.xml'
)


AF3_FULL_CONTEXT_XMLS = (
    'Includes_Info.xml', 'Home.xml', 'MyPrograms.xml', 'MyVideoNav.xml',
    'Custom_1101_Hub.xml', 'Custom_1102_Hub.xml', 'Custom_1103_Hub.xml',
    'Includes_Images.xml', 'Includes_Furniture.xml', 'Includes_OSD.xml',
    'VideoOSD.xml', 'DialogSeekBar.xml', 'Includes_Actions.xml', 'Includes_Defaults.xml'
)

FULL_SYSTEM_ADDONS = {
    'kpm': ADDON_ID,
    'lrs': 'script.library.ratings.scraper',
    'steam_library': 'plugin.program.steam.library',
    'lac': 'script.artwork.curator',
    'mediahub': 'plugin.video.mediahub.widget',
}

SENSITIVE_SETTING_RE = re.compile(r'(apikey|api_key|key|clientkey|client-key|token|secret|password|pass)', re.I)

FULL_SYSTEM_LOG_KEYS = (
    'Kodi Patch Manager', 'KPM',
    'Library Ratings Scraper', 'LibraryRatings', 'script.library.ratings.scraper',
    'Steam Library', 'plugin.program.steam.library', 'steam_rating_display', 'achievement_display', 'metacritic_score',
    'Library Artwork Curator', 'script.artwork.curator', 'ArtworkProcessor', 'LAC', 'cropv2', 'CropV2',
    'MediaHub', 'plugin.video.mediahub.widget', 'Artwork filters', 'clearlogo', 'fanart', 'Textures', 'Texture DB',
    'DisplaySlot', 'HomeHub', 'RatingSlot', 'EndsAt', 'FinishTime',
    'Home.xml', 'MyPrograms.xml', 'MyVideoNav.xml', 'Custom_1101_Hub.xml', 'Custom_1102_Hub.xml', 'Custom_1103_Hub.xml', 'Includes_Info.xml',
    'ERROR', 'WARNING', 'Traceback', 'Exception'
)

ART_LABELS = (
    'poster', 'thumb', 'fanart', 'landscape', 'clearlogo', 'logo', 'clearart', 'banner',
    'tvshow.poster', 'tvshow.thumb', 'tvshow.fanart', 'tvshow.landscape', 'tvshow.clearlogo', 'season.poster', 'season.thumb'
)

CROPV2_XML_PATTERNS = (
    'cropv2', 'CropV2', 'clearlogo', 'ClearLogo', 'fanart', 'Fanart', 'landscape',
    'Image_Crop', 'Image_Blur', 'Image_Fanart', 'KPM-CROP', 'MEDIAHUB', 'LAC'
)


def _redact_sensitive_settings_text(text: str) -> str:
    """Redact likely API keys/tokens in copied settings files while preserving structure."""
    if not text:
        return text

    def redact_value_attr(match: re.Match) -> str:
        whole = match.group(0)
        sid = match.group(1) or ''
        if SENSITIVE_SETTING_RE.search(sid):
            return re.sub(r'\bvalue=("|\')[^"\']*(\1)', 'value="[redacted]"', whole, flags=re.I)
        return whole

    # Kodi settings v2 style: <setting id="foo" value="bar" />
    text = re.sub(r'<setting\b[^>]*(?:id|name)=(?:"|\')([^"\']+)(?:"|\')[^>]*\bvalue=(?:"|\')[^"\']*(?:"|\')[^>]*/?>', redact_value_attr, text, flags=re.I)

    # Kodi settings v1 style: <setting id="foo">bar</setting>
    def redact_node(match: re.Match) -> str:
        open_tag, sid, value, close_tag = match.group(1), match.group(2), match.group(3), match.group(4)
        if SENSITIVE_SETTING_RE.search(sid or ''):
            return open_tag + '[redacted]' + close_tag
        return match.group(0)

    text = re.sub(r'(<setting\b[^>]*(?:id|name)=(?:"|\')([^"\']+)(?:"|\')[^>]*>)(.*?)(</setting>)', redact_node, text, flags=re.I | re.S)
    return text


def _read_text_redacted_if_settings(path: str, max_chars: int = 3000000) -> str:
    text = _read_file_if_exists(path, max_chars)
    if os.path.basename(path).lower() == 'settings.xml':
        return _redact_sensitive_settings_text(text)
    return text


def _addon_base_dirs(addon_id: str) -> Dict[str, str]:
    return {
        'addon_dir': norm(translate(f'special://home/addons/{addon_id}')),
        'profile_dir': norm(translate(f'special://profile/addon_data/{addon_id}')),
    }


def _addon_basic_report(addon_id: str) -> Dict[str, object]:
    dirs = _addon_base_dirs(addon_id)
    addon_xml = norm(os.path.join(dirs['addon_dir'], 'addon.xml'))
    settings_xml = norm(os.path.join(dirs['profile_dir'], 'settings.xml'))
    return {
        'addon_id': addon_id,
        'version': _addon_version_from_addon_xml(addon_id),
        'addon_dir': dirs['addon_dir'],
        'profile_dir': dirs['profile_dir'],
        'addon_xml': _full_file_digest(addon_xml),
        'profile_settings_xml': _full_file_digest(settings_xml),
    }


def _profile_db_digests(addon_id: str, max_files: int = 40) -> Dict[str, object]:
    profile = _addon_base_dirs(addon_id)['profile_dir']
    result: Dict[str, object] = {'profile_dir': profile, 'databases': []}
    if not os.path.isdir(profile):
        result['exists'] = False
        return result
    items = []
    for root, _dirs, files in os.walk(profile):
        for fname in files:
            if fname.lower().endswith(('.db', '.sqlite', '.sqlite3')):
                fpath = os.path.join(root, fname)
                try:
                    items.append((os.path.getmtime(fpath), fpath))
                except Exception:
                    items.append((0, fpath))
    items.sort(reverse=True)
    for _mtime, fpath in items[:max_files]:
        digest = _safe_db_digest(fpath)
        digest['relative_path'] = os.path.relpath(fpath, profile).replace(os.sep, '/')
        result['databases'].append(digest)
    return result


def _copy_recent_text_tree(files_to_write: Dict[str, str], root_dir: str, rel_prefix: str, max_files: int = 60, max_chars: int = 600000) -> None:
    if not os.path.isdir(root_dir):
        files_to_write[rel_prefix.rstrip('/') + '/_missing.txt'] = f'Missing directory: {root_dir}'
        return
    allowed_ext = ('.txt', '.log', '.json', '.jsonl', '.xml', '.csv', '.md')
    blocked_ext = ('.zip', '.db', '.sqlite', '.sqlite3', '.png', '.jpg', '.jpeg', '.webp', '.gif', '.mp4', '.mkv')
    candidates = []
    for root, _dirs, files in os.walk(root_dir):
        for fname in files:
            lower = fname.lower()
            if lower.endswith(blocked_ext):
                continue
            if not lower.endswith(allowed_ext):
                continue
            fpath = os.path.join(root, fname)
            try:
                candidates.append((os.path.getmtime(fpath), fpath))
            except Exception:
                candidates.append((0, fpath))
    candidates.sort(reverse=True)
    manifest = []
    for _mtime, fpath in candidates[:max_files]:
        rel = os.path.relpath(fpath, root_dir).replace(os.sep, '/')
        manifest.append(_full_file_digest(fpath))
        files_to_write[f'{rel_prefix.rstrip("/")}/{rel}'] = _read_text_redacted_if_settings(fpath, max_chars)
    files_to_write[rel_prefix.rstrip('/') + '/_manifest.json'] = json.dumps(manifest, indent=2, ensure_ascii=False)


def _copy_addon_snapshot(files_to_write: Dict[str, str], rel_root: str, addon_id: str, addon_files: Optional[List[str]] = None, profile_dirs: Optional[List[str]] = None) -> None:
    dirs = _addon_base_dirs(addon_id)
    files_to_write[f'{rel_root}/addon-basic.json'] = json.dumps(_addon_basic_report(addon_id), indent=2, ensure_ascii=False)
    files_to_write[f'{rel_root}/profile-db-digests.json'] = json.dumps(_profile_db_digests(addon_id), indent=2, ensure_ascii=False)
    addon_files = addon_files or ['addon.xml']
    for rel in addon_files:
        path = norm(os.path.join(dirs['addon_dir'], *rel.split('/')))
        if os.path.exists(path):
            files_to_write[f'{rel_root}/addon/{rel}'] = _read_text_redacted_if_settings(path, 1500000)
    settings = norm(os.path.join(dirs['profile_dir'], 'settings.xml'))
    if os.path.exists(settings):
        files_to_write[f'{rel_root}/profile/settings.xml'] = _read_text_redacted_if_settings(settings, 400000)
    for sub in (profile_dirs or ['runtime/logs', 'runtime/diagnostics', 'runtime/reports']):
        _copy_recent_text_tree(files_to_write, norm(os.path.join(dirs['profile_dir'], *sub.split('/'))), f'{rel_root}/profile/{sub}', max_files=40, max_chars=700000)


def _shared_icons_report() -> Dict[str, object]:
    root = norm(os.path.join(translate(f'special://home/addons/{ADDON_ID}'), 'resources', 'media', 'shared-icons'))
    report: Dict[str, object] = {'path': root, 'exists': os.path.isdir(root), 'icons': {}, 'bad_legacy_names': {}}
    expected = ('certified.png', 'emmys.png', 'ends.png', 'imdb.png', 'metacritic.png', 'oscars.png', 'oscars_bp.png', 'popcorn.png', 'popcorn_spilt.png', 'rtfresh.png', 'rtrotten.png', 'steam-ach.png', 'steam-dev.png', 'steam-pub.png', 'steam.png', 'tmdb.png', 'trakt.png', 'verified.png')
    bad = ('stema-ach.png', 'oscars-bp.png', 'verifiedhot.png', 'verified-hot.png', 'verified_hot.png')
    for name in expected:
        report['icons'][name] = _full_file_digest(os.path.join(root, name))
    for name in bad:
        report['bad_legacy_names'][name] = os.path.exists(os.path.join(root, name))
    return report


def _info_art(prefix: str) -> Dict[str, str]:
    data: Dict[str, str] = {}
    for art in ART_LABELS:
        data[art] = info_label(f'{prefix}.Art({art})')
    return data


def _current_item_snapshot() -> Dict[str, object]:
    prefixes = ('ListItem', 'Container.ListItem', 'VideoPlayer')
    result: Dict[str, object] = {'window_ids': _current_window_ids(), 'prefixes': {}}
    base_labels = ('Label', 'Title', 'OriginalTitle', 'TVShowTitle', 'DBID', 'DBTYPE', 'MediaType', 'Year', 'Duration', 'Genre', 'FileNameAndPath', 'FolderPath', 'EndTimeResume', 'FinishTime')
    prop_names = tuple(dict.fromkeys(GAME_BRIDGE_PROPS + (
        'mediatype', 'dbtype', 'DBType', 'lrs_media_type', 'mediahub_type',
        'RatingSlot1_Label', 'RatingSlot1_Value', 'RatingSlot1_Source', 'RatingSlot1_IconFile',
        'RatingSlot2_Label', 'RatingSlot2_Value', 'RatingSlot2_Source', 'RatingSlot2_IconFile',
        'RatingSlot3_Label', 'RatingSlot3_Value', 'RatingSlot3_Source', 'RatingSlot3_IconFile',
    )))
    for prefix in prefixes:
        entry: Dict[str, object] = {}
        entry['labels'] = {name: info_label(f'{prefix}.{name}') for name in base_labels}
        entry['art'] = _info_art(prefix)
        entry['properties'] = {name: info_label(f'{prefix}.Property({name})') for name in prop_names}
        result['prefixes'][prefix] = entry
    return result


def _latest_textures_db_path() -> str:
    db_dir = norm(translate('special://profile/Database'))
    candidates = []
    if os.path.isdir(db_dir):
        for fname in os.listdir(db_dir):
            if re.match(r'Textures\d*\.db$', fname, re.I):
                path = os.path.join(db_dir, fname)
                try:
                    candidates.append((int(re.sub(r'\D', '', fname) or '0'), os.path.getmtime(path), path))
                except Exception:
                    candidates.append((0, 0, path))
    candidates.sort(reverse=True)
    return candidates[0][2] if candidates else ''


def _texture_lookup_for_art(uri: str, limit: int = 5) -> Dict[str, object]:
    uri = str(uri or '').strip()
    path = _latest_textures_db_path()
    result: Dict[str, object] = {'art': uri, 'textures_db': path, 'textures_db_digest': _safe_db_digest(path) if path else {'exists': False}, 'matches': []}
    if not uri or not path or not os.path.exists(path):
        return result
    needles = [uri, quote(uri, safe='')]
    try:
        con = sqlite3.connect(path)
        cur = con.cursor()
        rows = []
        for needle in needles:
            if not needle:
                continue
            try:
                rows.extend(cur.execute("SELECT url, cachedurl, width, height FROM texture WHERE url LIKE ? LIMIT ?", ('%' + needle + '%', limit)).fetchall())
            except Exception:
                # Some Kodi versions use slightly different texture schemas.
                rows.extend(cur.execute("SELECT url, cachedurl FROM texture WHERE url LIKE ? LIMIT ?", ('%' + needle + '%', limit)).fetchall())
        con.close()
        seen = set()
        for row in rows:
            key = repr(row)
            if key in seen:
                continue
            seen.add(key)
            item = {'url': row[0] if len(row) > 0 else '', 'cachedurl': row[1] if len(row) > 1 else ''}
            if len(row) > 3:
                item.update({'width': row[2], 'height': row[3]})
            result['matches'].append(item)
    except Exception as exc:
        result['error'] = str(exc)
    return result


def _mediahub_settings_snapshot() -> Dict[str, object]:
    profile = _addon_base_dirs('plugin.video.mediahub.widget')['profile_dir']
    settings = norm(os.path.join(profile, 'settings.xml'))
    result = {'settings_xml': _full_file_digest(settings), 'parsed': {}}
    text = _read_file_if_exists(settings, 300000) if os.path.exists(settings) else ''
    for sid in ('exclude_fanart_below_1080p', 'exclude_without_clearlogo', 'include_movies', 'include_series', 'include_games', 'default_limit', 'default_random', 'steam_addon_id'):
        m = re.search(r'<setting\b[^>]*id=["\']' + re.escape(sid) + r'["\'][^>]*value=["\']([^"\']*)["\']', text, re.I)
        if not m:
            m = re.search(r'<setting\b[^>]*id=["\']' + re.escape(sid) + r'["\'][^>]*>(.*?)</setting>', text, re.I | re.S)
        result['parsed'][sid] = (m.group(1).strip() if m else '')
    return result


def _lac_settings_snapshot() -> Dict[str, object]:
    profile = _addon_base_dirs('script.artwork.curator')['profile_dir']
    settings = norm(os.path.join(profile, 'settings.xml'))
    result = {'settings_xml': _full_file_digest(settings), 'parsed': {}}
    text = _read_file_if_exists(settings, 300000) if os.path.exists(settings) else ''
    for sid in ('minimum_fanart_resolution', 'titlefree_fanart', 'enable_fanarttv', 'enable_tmdb', 'enable_tvdb'):
        m = re.search(r'<setting\b[^>]*id=["\']' + re.escape(sid) + r'["\'][^>]*value=["\']([^"\']*)["\']', text, re.I)
        if not m:
            m = re.search(r'<setting\b[^>]*id=["\']' + re.escape(sid) + r'["\'][^>]*>(.*?)</setting>', text, re.I | re.S)
        result['parsed'][sid] = (m.group(1).strip() if m else '')
    return result


def _cropv2_diagnostics_report() -> Dict[str, object]:
    current = _current_item_snapshot()
    art_values = []
    for pdata in current.get('prefixes', {}).values():
        art = pdata.get('art', {}) if isinstance(pdata, dict) else {}
        if isinstance(art, dict):
            for key in ('fanart', 'landscape', 'thumb', 'poster', 'clearlogo', 'tvshow.fanart', 'tvshow.clearlogo'):
                val = art.get(key)
                if val and val not in art_values:
                    art_values.append(val)
    texture_lookups = {f'art_{idx+1}': _texture_lookup_for_art(uri) for idx, uri in enumerate(art_values[:12])}
    xml_markers: Dict[str, object] = {}
    for fname in AF3_FULL_CONTEXT_XMLS:
        path = af3_path('1080i', fname)
        text = _read_file_if_exists(path, 1500000)
        marker_lines = []
        for lineno, line in enumerate(text.splitlines(), 1):
            if any(pattern.lower() in line.lower() for pattern in CROPV2_XML_PATTERNS):
                marker_lines.append(f'{lineno:05d}: {line}')
                if len(marker_lines) >= 120:
                    break
        xml_markers[fname] = marker_lines
    return {
        'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'scope': 'cropV2 visual/path/filter diagnostics only; artwork scraping remains in LAC/MediaHub',
        'current_item': current,
        'mediahub_settings': _mediahub_settings_snapshot(),
        'lac_settings': _lac_settings_snapshot(),
        'texture_db_current_art_lookup': texture_lookups,
        'xml_cropv2_marker_lines': xml_markers,
        'expected_filter_policy': {
            'exclude_without_clearlogo_setting': 'plugin.video.mediahub.widget: exclude_without_clearlogo',
            'exclude_fanart_below_1080p_setting': 'plugin.video.mediahub.widget: exclude_fanart_below_1080p',
            'texture_db_source': 'special://profile/Database/Textures*.db',
            'visual_owner_target': 'KPM full diagnostics + future KPM visual patching; LAC/MediaHub remain data providers',
        },
    }


def _xml_marker_scan_report() -> Dict[str, object]:
    patterns = ('KPM-', 'LRS-', 'LRS-AF3', 'STEAM-LIBRARY', 'DisplaySlot', 'RatingSlot', 'cropv2', 'CropV2', 'KPM-CROP', 'LRS_AF3', 'steam_rating_display', 'achievement_display', 'metacritic_score')
    report: Dict[str, object] = {}
    for fname in AF3_FULL_CONTEXT_XMLS:
        path = af3_path('1080i', fname)
        text = _read_file_if_exists(path, 2500000)
        lines = []
        counts = {pattern: text.count(pattern) for pattern in patterns}
        for lineno, line in enumerate(text.splitlines(), 1):
            if any(pattern in line for pattern in patterns):
                lines.append(f'{lineno:05d}: {line}')
                if len(lines) >= 220:
                    break
        report[fname] = {'path': path, 'digest': _full_file_digest(path), 'counts': counts, 'marker_lines': lines}
    return report


def _full_system_versions_report() -> Dict[str, str]:
    return {key: _addon_version_from_addon_xml(addon_id) if key != 'kpm' else VERSION for key, addon_id in FULL_SYSTEM_ADDONS.items()}


def _full_system_runtime_report() -> Dict[str, object]:
    return {
        'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'versions': _full_system_versions_report(),
        'player_runtime': _player_runtime_state(),
        'current_item_snapshot': _current_item_snapshot(),
        'cropv2': _cropv2_diagnostics_report(),
        'shared_icons': _shared_icons_report(),
    }


def _filtered_full_system_kodi_log() -> str:
    return _filtered_kodi_log_for_keys(FULL_SYSTEM_LOG_KEYS)


def _full_system_summary(runtime: Dict[str, object]) -> str:
    lines = []
    lines.append(f'{ADDON_NAME} Full System Diagnostics v{VERSION}')
    lines.append(f'Generated: {time.strftime("%Y-%m-%d %H:%M:%S")}')
    lines.append('Scope: one ZIP for visual/XML/pathing/service integration. Scraping/provider internals remain owned by LRS, Steam Library, and LAC.')
    lines.append('')
    lines.append('Versions:')
    lines.append(json.dumps(runtime.get('versions', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Current item snapshot:')
    lines.append(json.dumps(runtime.get('current_item_snapshot', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('KPM/LRS visual runtime snapshot:')
    lines.append(json.dumps(runtime.get('player_runtime', {}), indent=2, ensure_ascii=False))
    return '\n'.join(lines)


def _add_full_system_diagnostic_files(files_to_write: Dict[str, str], stamp: str) -> None:
    runtime = _full_system_runtime_report()
    files_to_write['summary/full-system-summary.txt'] = _full_system_summary(runtime)
    files_to_write['kpm/runtime/full-system-runtime.json'] = json.dumps(runtime, indent=2, ensure_ascii=False)
    files_to_write['kpm/runtime/current-item-snapshot.json'] = json.dumps(runtime.get('current_item_snapshot', {}), indent=2, ensure_ascii=False)
    files_to_write['kpm/runtime/cropv2-diagnostics.json'] = json.dumps(runtime.get('cropv2', {}), indent=2, ensure_ascii=False)
    files_to_write['kpm/runtime/shared-icons.json'] = json.dumps(runtime.get('shared_icons', {}), indent=2, ensure_ascii=False)
    files_to_write['kpm/runtime/xml-marker-scan.json'] = json.dumps(_xml_marker_scan_report(), indent=2, ensure_ascii=False)
    files_to_write['kpm/logs/kodi-log-full-filtered.txt'] = _filtered_full_system_kodi_log()
    files_to_write['kpm/patch-status.txt'] = patch_status_summary()

    # Add-on snapshots: text/config/logs only; DBs are digests only.
    _copy_addon_snapshot(files_to_write, 'addons/kpm', ADDON_ID, ['addon.xml', 'default.py', 'service.py', 'resources/lib/main.py'], ['runtime/logs', 'runtime/diagnostics', 'runtime/reports'])
    _copy_addon_snapshot(files_to_write, 'addons/lrs', 'script.library.ratings.scraper', ['addon.xml', 'default.py', 'service.py', 'resources/lib/core.py'], ['runtime/logs', 'runtime/diagnostics', 'runtime/reports', 'logs', 'cache'])
    _copy_addon_snapshot(files_to_write, 'addons/steam_library', 'plugin.program.steam.library', ['addon.xml', 'addon.py'], ['runtime/logs', 'runtime/diagnostics', 'runtime/reports', 'reports', 'logs'])
    _copy_addon_snapshot(files_to_write, 'addons/lac', 'script.artwork.curator', ['addon.xml', 'default.py', 'service.py', 'lib/diagnostics.py', 'lib/artworkprocessor.py'], ['runtime/logs', 'runtime/diagnostics', 'runtime/reports', 'reports', 'logs'])
    _copy_addon_snapshot(files_to_write, 'addons/mediahub', 'plugin.video.mediahub.widget', ['addon.xml', 'addon.py'], ['runtime/logs', 'runtime/diagnostics', 'runtime/reports', 'logs'])

    # Full AF3 XML context files and every Custom_*_Hub.xml.
    for fname in AF3_FULL_CONTEXT_XMLS:
        _copy_text_file_to_diag(files_to_write, f'xml/1080i/{fname}', af3_path('1080i', fname), 6000000)
    try:
        for fname in sorted(os.listdir(af3_path('1080i'))):
            if re.match(r'Custom_.*_Hub\.xml$', fname, re.I) and f'xml/1080i/{fname}' not in files_to_write:
                _copy_text_file_to_diag(files_to_write, f'xml/1080i/{fname}', af3_path('1080i', fname), 3000000)
    except Exception:
        pass
    files_to_write['xml/xml-context-snippets.json'] = json.dumps(_xml_context_snippets(), indent=2, ensure_ascii=False)

def _addon_version_from_addon_xml(addon_id: str) -> str:
    path = norm(os.path.join(translate(f'special://home/addons/{addon_id}'), 'addon.xml'))
    try:
        text = read_text(path)
    except Exception:
        return ''
    match = re.search(r'<addon\b[^>]*\bversion=["\']([^"\']+)["\']', text, re.I)
    return match.group(1).strip() if match else ''


def _safe_db_digest(path: str) -> Dict[str, object]:
    data = _full_file_digest(path)
    data['raw_dumped'] = False
    data['policy'] = 'digest_only'
    return data


def _lrs_homehub_display_props(window_ids: Optional[List[int]] = None) -> Dict[str, dict]:
    if window_ids is None:
        ids = [10000]
        current = _current_window_ids().get('current_window_id', 0)
        if current and current not in ids:
            ids.append(current)
    else:
        ids = window_ids
    result: Dict[str, dict] = {}
    for wid in ids:
        entry: Dict[str, object] = {}
        for prop in LRS_HOMEHUB_BASE_PROPS:
            entry[prop] = _window_prop(wid, f'LibraryRatings.HomeHub.{prop}')
        for suffix in LRS_ENDSAT_SUFFIXES:
            entry[f'EndsAt_{suffix}'] = _window_prop(wid, f'LibraryRatings.HomeHub.EndsAt_{suffix}')
        for slot in range(1, 11):
            slot_data = {}
            for suffix in LRS_SLOT_SUFFIXES:
                slot_data[suffix] = _window_prop(wid, f'LibraryRatings.HomeHub.DisplaySlot{slot}_{suffix}')
            entry[f'DisplaySlot{slot}'] = slot_data
        result[str(wid)] = entry
    return result


def _lrs_strict_current_endsat_props(window_ids: Optional[List[int]] = None) -> Dict[str, dict]:
    if window_ids is None:
        ids = [10000]
        current = _current_window_ids().get('current_window_id', 0)
        if current and current not in ids:
            ids.append(current)
    else:
        ids = window_ids
    result: Dict[str, dict] = {}
    for wid in ids:
        entry: Dict[str, dict] = {}
        for service in ('ListItem', 'HomeHub'):
            ends = {}
            for suffix in LRS_ENDSAT_SUFFIXES:
                ends[suffix] = _window_prop(wid, f'LibraryRatings.{service}.EndsAt_{suffix}')
            entry[service] = ends
        result[str(wid)] = entry
    return result


def _game_bridge_for_prefix(prefix: str) -> Dict[str, object]:
    entry: Dict[str, object] = {
        'Label': info_label(f'{prefix}.Label'),
        'Title': info_label(f'{prefix}.Title'),
        'DBTYPE': info_label(f'{prefix}.DBTYPE'),
        'DBID': info_label(f'{prefix}.DBID'),
        'FileNameAndPath': info_label(f'{prefix}.FileNameAndPath'),
        'FolderPath': info_label(f'{prefix}.FolderPath'),
    }
    entry['properties'] = {prop: info_label(f'{prefix}.Property({prop})') for prop in GAME_BRIDGE_PROPS}
    slots: Dict[str, dict] = {}
    for slot in range(1, 7):
        slot_data = {}
        for suffix in LRS_SLOT_SUFFIXES:
            slot_data[suffix] = info_label(f'{prefix}.Property(RatingSlot{slot}_{suffix})')
        slots[f'RatingSlot{slot}'] = slot_data
    entry['rating_slots'] = slots
    return entry


def _current_game_bridge_report() -> Dict[str, object]:
    return {
        'Container.ListItem': _game_bridge_for_prefix('Container.ListItem'),
        'ListItem': _game_bridge_for_prefix('ListItem'),
    }


def _steam_library_files_report() -> Dict[str, object]:
    steam_addon_dir = norm(translate('special://home/addons/plugin.program.steam.library'))
    steam_profile = norm(translate('special://profile/addon_data/plugin.program.steam.library'))
    files = {
        'addon.xml': norm(os.path.join(steam_addon_dir, 'addon.xml')),
        'addon.py': norm(os.path.join(steam_addon_dir, 'addon.py')),
        'settings.xml': norm(os.path.join(steam_profile, 'settings.xml')),
        'steam_library.db': norm(os.path.join(steam_profile, 'steam_library.db')),
    }
    report: Dict[str, object] = {}
    for name, path in files.items():
        report[name] = _safe_db_digest(path) if name.endswith('.db') else _full_file_digest(path)
    return report


def _af3_lrs_xml_files_report() -> Dict[str, object]:
    report: Dict[str, object] = {}
    for fname in AF3_LRS_CONTEXT_XMLS:
        report[fname] = _full_file_digest(af3_path('1080i', fname))
    hub_dir = af3_path('1080i')
    custom_hubs = []
    try:
        for fname in sorted(os.listdir(hub_dir)):
            if re.match(r'Custom_.*_Hub\.xml$', fname, re.I):
                path = af3_path('1080i', fname)
                custom_hubs.append(_full_file_digest(path))
    except Exception:
        pass
    report['all_Custom_*_Hub.xml'] = custom_hubs
    return report


def _xml_context_snippets() -> Dict[str, str]:
    snippets: Dict[str, str] = {}
    names = list(AF3_LRS_CONTEXT_XMLS)
    try:
        for fname in sorted(os.listdir(af3_path('1080i'))):
            if re.match(r'Custom_.*_Hub\.xml$', fname, re.I) and fname not in names:
                names.append(fname)
    except Exception:
        pass
    for fname in names:
        path = af3_path('1080i', fname)
        text = _read_file_if_exists(path, 1000000)
        chunks = []
        for pattern in ('Info_Panel', 'Info_Meta', 'Includes_Info', 'RatingSlot', 'DisplaySlot', 'HomeHub', 'EndsAt', 'FinishTime'):
            snippet = _line_numbered_snippet(text, pattern, pattern)
            if snippet and 'Marker not found' not in snippet:
                chunks.append(f'--- {pattern} ---\n{snippet}')
        snippets[fname] = '\n\n'.join(chunks) if chunks else 'No focused Info_Panel/Info_Meta/LRS markers found.'
    return snippets


def _lrs_steam_versions_report() -> Dict[str, str]:
    return {
        'kpm': VERSION,
        'lrs': _addon_version_from_addon_xml('script.library.ratings.scraper'),
        'steam_library': _addon_version_from_addon_xml('plugin.program.steam.library'),
    }


def _lrs_steam_runtime_state() -> Dict[str, object]:
    runtime = _player_runtime_state()
    runtime['versions'] = _lrs_steam_versions_report()
    runtime['lrs_homehub_display'] = _lrs_homehub_display_props()
    runtime['lrs_strict_current_endsat'] = _lrs_strict_current_endsat_props()
    runtime['current_game_bridge'] = _current_game_bridge_report()
    runtime['notes'] = {
        'scope': 'diagnostics/status only',
        'no_lower_meta_row_patching': True,
        'no_lrs_render_xml_modifications': True,
    }
    return runtime


def _filtered_kodi_log_for_keys(keys: tuple[str, ...]) -> str:
    path = _latest_kodi_log_path()
    text = _read_file_if_exists(path, 700000)
    out = []
    lowered = tuple(k.lower() for k in keys)
    for line in text.splitlines():
        lline = line.lower()
        if any(k in lline for k in lowered):
            out.append(line)
    return '\n'.join(out[-3000:]) if out else 'No matching lines found in kodi.log tail.'


def _lrs_steam_filtered_kodi_log() -> str:
    return _filtered_kodi_log_for_keys(LRS_STEAM_LOG_KEYS)


def _lrs_steam_summary(runtime: dict, steam_report: dict, af3_report: dict) -> str:
    lines = []
    lines.append(f'{ADDON_NAME} LRS / Steam Library diagnostics v{VERSION}')
    lines.append(f'Generated: {time.strftime("%Y-%m-%d %H:%M:%S")}')
    lines.append('Scope: diagnostics/status only; no LRS/Steam Library rendering XML or lower meta rows are patched by KPM.')
    lines.append('')
    lines.append('Versions:')
    lines.append(json.dumps(runtime.get('versions', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Runtime LRS/HomeHub/ListItem/container state:')
    lines.append(json.dumps(runtime, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Steam Library target files:')
    lines.append(json.dumps(steam_report, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('AF3 XML context files:')
    lines.append(json.dumps(af3_report, indent=2, ensure_ascii=False))
    return '\n'.join(lines)


def _copy_text_file_to_diag(files_to_write: Dict[str, str], rel: str, path: str, max_chars: int = 3000000) -> None:
    if os.path.exists(path):
        files_to_write[rel] = _read_text_redacted_if_settings(path, max_chars)
    else:
        files_to_write[rel + '.missing.txt'] = f'Missing file: {path}'


def export_lrs_steam_diagnostics() -> Result:
    name = 'Export LRS / Steam Library Diagnostics'
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_dir = addon_data_dir('runtime', 'exports', 'lrs-steam-diagnostics', stamp)
    _delete_old_root_zips('kpm-lrs-steam-diagnostics-')
    zip_path = os.path.join(addon_data_dir(), f'kpm-lrs-steam-diagnostics-{stamp}.zip')
    runtime = _lrs_steam_runtime_state()
    steam_report = _steam_library_files_report()
    af3_report = _af3_lrs_xml_files_report()
    snippets = _xml_context_snippets()

    files_to_write: Dict[str, str] = {
        'summary.txt': _lrs_steam_summary(runtime, steam_report, af3_report),
        'runtime.json': json.dumps(runtime, indent=2, ensure_ascii=False),
        'target-files.json': json.dumps({
            'steam_library': steam_report,
            'af3_lrs_context_xml': af3_report,
            'lrs': {
                'addon.xml': _full_file_digest(norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml'))),
                'settings.xml': _full_file_digest(norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml'))),
            },
            'kpm': {
                'version': VERSION,
                'service.py': _full_file_digest(norm(os.path.join(translate(f'special://home/addons/{ADDON_ID}'), 'service.py'))),
                'main.py': _full_file_digest(norm(os.path.join(translate(f'special://home/addons/{ADDON_ID}'), 'resources', 'lib', 'main.py'))),
            },
        }, indent=2, ensure_ascii=False),
        'patch-status.txt': patch_status_summary(),
        'kodi-log-lrs-steam-filtered.txt': _lrs_steam_filtered_kodi_log(),
        'xml-context-snippets.json': json.dumps(snippets, indent=2, ensure_ascii=False),
        'versions.json': json.dumps(runtime.get('versions', {}), indent=2, ensure_ascii=False),
    }

    # Steam Library files: include text metadata/settings, DB digest only.
    steam_addon_dir = norm(translate('special://home/addons/plugin.program.steam.library'))
    steam_profile = norm(translate('special://profile/addon_data/plugin.program.steam.library'))
    _copy_text_file_to_diag(files_to_write, 'steam-library/addon.xml', norm(os.path.join(steam_addon_dir, 'addon.xml')), 300000)
    _copy_text_file_to_diag(files_to_write, 'steam-library/addon.py', norm(os.path.join(steam_addon_dir, 'addon.py')), 1200000)
    _copy_text_file_to_diag(files_to_write, 'steam-library/settings.xml', norm(os.path.join(steam_profile, 'settings.xml')), 300000)
    files_to_write['steam-library/steam_library.db.digest.json'] = json.dumps(
        _safe_db_digest(norm(os.path.join(steam_profile, 'steam_library.db'))), indent=2, ensure_ascii=False
    )

    # LRS text metadata/settings.
    _copy_text_file_to_diag(files_to_write, 'lrs/addon.xml', norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml')), 300000)
    _copy_text_file_to_diag(files_to_write, 'lrs/settings.xml', norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml')), 300000)

    # AF3 XML context files: Includes_Info full and requested windows/full context XMLs.
    for fname in AF3_LRS_CONTEXT_XMLS:
        _copy_text_file_to_diag(files_to_write, f'af3/1080i/{fname}', af3_path('1080i', fname), 5000000)
    try:
        for fname in sorted(os.listdir(af3_path('1080i'))):
            if re.match(r'Custom_.*_Hub\.xml$', fname, re.I) and f'af3/1080i/{fname}' not in files_to_write:
                _copy_text_file_to_diag(files_to_write, f'af3/1080i/{fname}', af3_path('1080i', fname), 2000000)
    except Exception:
        pass
    for fname, text in snippets.items():
        files_to_write[f'af3-snippets/{fname}.txt'] = text

    files_to_write['manifest.json'] = _diagnostic_manifest('lrs-steam', stamp, files_to_write)

    for rel, content in files_to_write.items():
        _write_diag_file(os.path.join(out_dir, rel.replace('/', os.sep)), content)

    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(out_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                zf.write(fpath, os.path.relpath(fpath, out_dir))

    log('[KPM_DIAG] Exported LRS / Steam Library diagnostics: {0}'.format(zip_path))
    return Result(name, 'Exported', zip_path)


def _target_files_report() -> Dict[str, object]:
    files = {
        'VideoFullScreen.xml': vfs_pause_target(),
        'DialogSeekBar.xml': seekbar_pause_target(),
        'Includes_Info.xml': af3_path('1080i', 'Includes_Info.xml'),
        'Includes_OSD.xml': af3_path('1080i', 'Includes_OSD.xml'),
        'Includes_Images.xml': includes_images_target(),
        'Includes_Furniture.xml': includes_furniture_target(),
        'KPM service.py': norm(os.path.join(translate('special://home/addons/script.kodi.patch.manager'), 'service.py')),
        'KPM settings.json': kpm_settings_file(),
        'TMDbHelper imgmon.py': tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'imgmon.py'),
        'TMDbHelper images.py': tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'images.py'),
        'LRS addon.xml': norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml')),
        'LRS settings.xml': norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml')),
        'Kodi log': _latest_kodi_log_path(),
    }
    files.update({
        'Home.xml': af3_path('1080i', 'Home.xml'),
        'MyPrograms.xml': af3_path('1080i', 'MyPrograms.xml'),
        'MyVideoNav.xml': af3_path('1080i', 'MyVideoNav.xml'),
        'Custom_1101_Hub.xml': af3_path('1080i', 'Custom_1101_Hub.xml'),
        'Custom_1102_Hub.xml': af3_path('1080i', 'Custom_1102_Hub.xml'),
        'Custom_1103_Hub.xml': af3_path('1080i', 'Custom_1103_Hub.xml'),
        'Steam Library addon.xml': norm(os.path.join(translate('special://home/addons/plugin.program.steam.library'), 'addon.xml')),
        'Steam Library addon.py': norm(os.path.join(translate('special://home/addons/plugin.program.steam.library'), 'addon.py')),
        'Steam Library settings.xml': norm(os.path.join(translate('special://profile/addon_data/plugin.program.steam.library'), 'settings.xml')),
        'Steam Library steam_library.db': norm(os.path.join(translate('special://profile/addon_data/plugin.program.steam.library'), 'steam_library.db')),
    })
    return {name: (_safe_db_digest(path) if name == 'Steam Library steam_library.db' else _full_file_digest(path)) for name, path in files.items()}



def _studio_home_props_report() -> Dict[str, object]:
    keys = [
        'KPM.StudioLogo.1', 'KPM.StudioLogoName.1',
        'KPM.StudioLogo.2', 'KPM.StudioLogoName.2',
        'KPM.StudioLogo.3', 'KPM.StudioLogoName.3',
        'KPM.StudioLogos.Count', 'KPM.StudioLogos.Available', 'KPM.StudioLogos.Status',
        'KPM.StudioLogos.Candidates', 'KPM.StudioLogos.Resolved', 'KPM.StudioLogos.Missing',
        'KPM.StudioLogos.UpdatedAt', 'KPM.StudioLogos.Show', 'KPM.StudioLogos.Context', 'KPM.StudioLogos.Cache', 'KPM.StudioLogos.IndexBuildMs',
        'KPM.StudioLogos.ResolveLastMs', 'KPM.StudioLogos.ResolveMaxMs', 'KPM.StudioLogos.ResolveCount',
        'KPM.StudioLogos.BrokenSkipped', 'KPM.StudioLogos.Debug',
        'KPM.StudioLogos.Source', 'KPM.StudioLogos.EpisodeParentShowId',
        'KPM.StudioLogos.EpisodeParentShowTitle', 'KPM.StudioLogos.DBLookupLastMs',
        'KPM.StudioLogos.DBLookupCount',
        'KPM.StudioLogos.LastMediaLabel', 'KPM.StudioLogos.LastMediaDBID',
        'KPM.StudioLogos.LastMediaDBTYPE', 'KPM.StudioLogos.LastMediaCandidates',
        'KPM.StudioLogos.LastMediaResolved', 'KPM.StudioLogos.LastMediaSource',
        'KPM.StudioLogos.LastMediaUpdatedAt',
    ]
    return {key: _window_prop(10000, key) for key in keys}


def _studio_resource_report() -> Dict[str, object]:
    addon_root = translate('special://home/addons')
    coloured_dir = norm(os.path.join(addon_root, 'resource.images.studios.coloured'))
    white_dir = norm(os.path.join(addon_root, 'resource.images.studios.white'))
    game_dir = norm(os.path.join(addon_root, 'resource.images.gamestudios.grayscale'))
    coloured_xbt = norm(os.path.join(coloured_dir, 'resources', 'Textures.xbt'))
    white_xbt = norm(os.path.join(white_dir, 'resources', 'Textures.xbt'))
    game_xbt = norm(os.path.join(game_dir, 'resources', 'Textures.xbt'))
    cache_root = norm(os.path.join(translate('special://profile/addon_data/script.kodi.patch.manager'), 'cache'))
    return {
        'coloured_addon_dir': coloured_dir,
        'coloured_addon_exists': os.path.isdir(coloured_dir),
        'coloured_textures_xbt': _full_file_digest(coloured_xbt),
        'index_cache': _full_file_digest(norm(os.path.join(cache_root, 'studio-logo-index-coloured-v2.json'))),
        'game_grayscale_addon_dir': game_dir,
        'game_grayscale_addon_exists': os.path.isdir(game_dir),
        'game_grayscale_textures_xbt': _full_file_digest(game_xbt),
        'game_grayscale_index_cache': _full_file_digest(norm(os.path.join(cache_root, 'studio-logo-index-gamestudios-grayscale-v1.json'))),
        'white_addon_dir': white_dir,
        'white_addon_exists': os.path.isdir(white_dir),
        'white_textures_xbt': _full_file_digest(white_xbt),
    }


def _latest_myvideos_db() -> str:
    db_dir = norm(translate('special://profile/Database'))
    if not os.path.isdir(db_dir):
        return ''
    best = ''
    best_num = -1
    for fname in os.listdir(db_dir):
        match = re.match(r'MyVideos(\d+)\.db$', fname, re.I)
        if match:
            num = int(match.group(1))
            if num > best_num:
                best_num = num
                best = os.path.join(db_dir, fname)
    return norm(best) if best else ''


def _studio_db_report() -> Dict[str, object]:
    path = _latest_myvideos_db()
    data: Dict[str, object] = {'path': path, 'exists': bool(path and os.path.exists(path))}
    if not path or not os.path.exists(path):
        return data
    try:
        con = sqlite3.connect(path)
        cur = con.cursor()
        tables = {row[0] for row in cur.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        data['has_studio_table'] = 'studio' in tables
        data['has_studio_link_table'] = 'studio_link' in tables
        if 'studio' in tables:
            data['studio_count'] = int(cur.execute('SELECT COUNT(*) FROM studio').fetchone()[0])
            data['sample_studios'] = [row[0] for row in cur.execute('SELECT name FROM studio ORDER BY name LIMIT 30')]
        if 'studio_link' in tables:
            data['studio_link_count'] = int(cur.execute('SELECT COUNT(*) FROM studio_link').fetchone()[0])
            data['media_with_studio_count'] = int(cur.execute('SELECT COUNT(*) FROM (SELECT media_type, media_id FROM studio_link GROUP BY media_type, media_id)').fetchone()[0])
            data['multi_studio_media_count'] = int(cur.execute('SELECT COUNT(*) FROM (SELECT media_type, media_id, COUNT(*) c FROM studio_link GROUP BY media_type, media_id HAVING c > 1)').fetchone()[0])
            sql = ('SELECT media_type, COUNT(*) AS items, '
                   'SUM(CASE WHEN c > 1 THEN 1 ELSE 0 END) AS multi_items '
                   'FROM (SELECT media_type, media_id, COUNT(*) c FROM studio_link GROUP BY media_type, media_id) '
                   'GROUP BY media_type ORDER BY media_type')
            data['by_media_type'] = [
                {'media_type': row[0], 'items': row[1], 'multi_studio_items': row[2]}
                for row in cur.execute(sql)
            ]
            try:
                data['episode_studio_link_count'] = int(cur.execute("SELECT COUNT(*) FROM studio_link WHERE media_type='episode'").fetchone()[0])
                data['tvshow_studio_link_count'] = int(cur.execute("SELECT COUNT(*) FROM studio_link WHERE media_type='tvshow'").fetchone()[0])
                data['episode_parent_studio_samples'] = [
                    {'idEpisode': row[0], 'episode': row[1], 'idShow': row[2], 'show': row[3], 'studio': row[4]}
                    for row in cur.execute("""
                        SELECT e.idEpisode, e.c00, e.idShow, t.c00, s.name
                        FROM episode e
                        JOIN tvshow t ON t.idShow=e.idShow
                        JOIN studio_link sl ON sl.media_type='tvshow' AND sl.media_id=e.idShow
                        JOIN studio s ON s.studio_id=sl.studio_id
                        ORDER BY e.idEpisode
                        LIMIT 20
                    """)
                ]
            except Exception as exc:
                data['episode_parent_studio_error'] = str(exc)
        con.close()
    except Exception as exc:  # pylint: disable=broad-except
        data['error'] = str(exc)
    return data


def _marked_snippet(path: str, start_marker: str, end_marker: str, max_chars: int = 120000) -> str:
    text = _read_file_if_exists(path, max_chars)
    return _line_numbered_snippet(text, start_marker, end_marker)


def _studio_log_filtered() -> str:
    path = _latest_kodi_log_path()
    text = _read_file_if_exists(path, 600000)
    keys = ('Kodi Patch Manager Service', 'KPM.StudioLogo', 'KPM.StudioLogos', 'studio logos:',
            'resource.images.studios', 'Image_CombinedStudio', 'Furniture_Studio', 'Misplaced [',
            'Error parsing boolean expression', 'CImageLoader::DoWork')
    out = []
    for line in text.splitlines():
        if any(k.lower() in line.lower() for k in keys):
            out.append(line)
    return '\n'.join(out[-2500:]) if out else 'No studio-logo related lines found in kodi.log tail.'


def _studio_last_events() -> List[str]:
    text = _studio_log_filtered()
    lines = []
    for line in text.splitlines():
        lower = line.lower()
        if 'studio logo index' in lower or 'studio logos:' in lower or 'cimageloader::dowork' in lower or 'failed to decompress' in lower or 'error parsing boolean expression' in lower:
            lines.append(line)
    return lines[-80:]



def _studio_context_report() -> Dict[str, object]:
    tmdb_listitem = {}
    tmdb_player = {}
    for idx in range(1, 11):
        tmdb_listitem[f'Studio.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.ListItem.Studio.{idx}.Name')
    for idx in range(1, 6):
        tmdb_listitem[f'Network.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.ListItem.Network.{idx}.Name')
        tmdb_player[f'Studio.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.Player.Studio.{idx}.Name')
        tmdb_player[f'Network.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.Player.Network.{idx}.Name')
    visibility = {
        'Furniture.DisableStudio': cond_visible('Skin.HasSetting(Footer.DisableStudio)'),
        'Furniture.EnableCodecs': cond_visible('Skin.HasSetting(Footer.EnableCodecs)'),
        'Furniture.DisableNowPlaying': cond_visible('Skin.HasSetting(Footer.DisableNowPlaying)'),
        'Footer condition - no now playing or disabled': cond_visible('!Player.HasMedia | Skin.HasSetting(Footer.DisableNowPlaying)'),
        'Footer condition - codec slot free': cond_visible('String.IsEmpty(ListItem.VideoCodec) | !Skin.HasSetting(Footer.EnableCodecs)'),
        'Footer condition - KPM logo 1 exists': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))'),
        'Footer condition - KPM studio show': cond_visible('String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)'),
    }
    return {
        'info_labels': {
            'ListItem.Label': info_label('ListItem.Label'),
            'ListItem.DBID': info_label('ListItem.DBID'),
            'ListItem.DBTYPE': info_label('ListItem.DBTYPE'),
            'ListItem.Studio': info_label('ListItem.Studio'),
            'ListItem.VideoCodec': info_label('ListItem.VideoCodec'),
            'Container.ListItem.Label': info_label('Container.ListItem.Label'),
            'Container.ListItem.DBID': info_label('Container.ListItem.DBID'),
            'Container.ListItem.DBTYPE': info_label('Container.ListItem.DBTYPE'),
            'Container.ListItem.Studio': info_label('Container.ListItem.Studio'),
            'Container.ListItem.VideoCodec': info_label('Container.ListItem.VideoCodec'),
            'VideoPlayer.Title': info_label('VideoPlayer.Title'),
            'VideoPlayer.DBID': info_label('VideoPlayer.DBID'),
            'VideoPlayer.DBTYPE': info_label('VideoPlayer.DBTYPE'),
            'VideoPlayer.Studio': info_label('VideoPlayer.Studio'),
            'VideoPlayer.Content(episodes)': cond_visible('VideoPlayer.Content(episodes)'),
        },
        'tmdbhelper_listitem_properties': tmdb_listitem,
        'tmdbhelper_player_properties': tmdb_player,
        'visibility_conditions': visibility,
        'known_broken_texture_blacklist': list(BROKEN_STUDIO_TEXTURE_NAMES),
    }


def studio_logo_diagnostics_report() -> Dict[str, object]:
    images = includes_images_target()
    furniture = includes_furniture_target()
    return {
        'generated': time.strftime('%Y-%m-%d %H:%M:%S'),
        'kpm_version': VERSION,
        'patch_status': status_reliable_studio_logos(),
        'settings': load_kpm_settings(),
        'state_exists': os.path.exists(state_file('reliable_studio_logos')),
        'state_file': state_file('reliable_studio_logos'),
        'home_properties': _studio_home_props_report(),
        'context': _studio_context_report(),
        'resource': _studio_resource_report(),
        'database': _studio_db_report(),
        'targets': {
            'Includes_Images.xml': _full_file_digest(images),
            'Includes_Furniture.xml': _full_file_digest(furniture),
        },
        'condition_checks': {
            '!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))'),
            'String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)': cond_visible('String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)'),
            '!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.2))': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.2))'),
            '!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.3))': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.3))'),
        },
        'last_events': _studio_last_events(),
    }


def _studio_diagnostic_text(report: Dict[str, object]) -> str:
    lines = []
    lines.append(f'{ADDON_NAME} studio logo diagnostics v{VERSION}')
    lines.append(f'Generated: {report.get("generated", "")}')
    lines.append('')
    lines.append('Status: ' + str(report.get('patch_status')))
    lines.append('Settings: ' + json.dumps(report.get('settings', {}), ensure_ascii=False))
    lines.append('')
    lines.append('Home properties:')
    lines.append(json.dumps(report.get('home_properties', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Context / visibility:')
    lines.append(json.dumps(report.get('context', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Resource:')
    lines.append(json.dumps(report.get('resource', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Database:')
    lines.append(json.dumps(report.get('database', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Condition checks:')
    lines.append(json.dumps(report.get('condition_checks', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Last studio events:')
    lines.extend(report.get('last_events', []) or ['No studio events found.'])
    return '\n'.join(lines)



def _delete_old_root_zips(prefix: str) -> None:
    try:
        root_dir = addon_data_dir()
        for name in os.listdir(root_dir):
            if name.startswith(prefix) and name.endswith('.zip'):
                try:
                    os.remove(os.path.join(root_dir, name))
                except Exception:
                    pass
    except Exception:
        pass


def _diagnostic_manifest(kind: str, stamp: str, files_to_write: Dict[str, str]) -> str:
    data = {
        'addon_id': ADDON_ID,
        'addon_name': ADDON_NAME,
        'addon_version': VERSION,
        'diagnostic_type': kind,
        'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'stamp': stamp,
        'storage': {
            'root_zip_location': 'special://profile/addon_data/{0}/'.format(ADDON_ID),
            'working_folder': 'runtime/exports/',
            'state_folder': 'runtime/state/',
            'diagnostics_folder': 'runtime/diagnostics/',
            'reports_folder': 'runtime/reports/',
            'logs_folder': 'runtime/logs/'
        },
        'included_files': sorted(files_to_write.keys()),
        'redacted': True
    }
    return json.dumps(data, indent=2, ensure_ascii=False)

def export_studio_logo_diagnostics() -> Result:
    name = 'Export Studio Logo Diagnostics'
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_dir = addon_data_dir('runtime', 'exports', 'studio_logo_diagnostics', stamp)
    _delete_old_root_zips('kpm-studio-logo-diagnostics-')
    zip_path = os.path.join(addon_data_dir(), f'kpm-studio-logo-diagnostics-{stamp}.zip')
    report = studio_logo_diagnostics_report()
    images = includes_images_target()
    furniture = includes_furniture_target()
    files_to_write = {
        'studio-logo-diagnostics.txt': _studio_diagnostic_text(report),
        'studio-logo-diagnostics.json': json.dumps(report, indent=2, ensure_ascii=False),
        'studio-context.json': json.dumps(report.get('context', {}), indent=2, ensure_ascii=False),
        'studio-home-properties.json': json.dumps(report.get('home_properties', {}), indent=2, ensure_ascii=False),
        'Includes_Images-Image_CombinedStudio-snippet.txt': _marked_snippet(images, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END),
        'Includes_Furniture-Furniture_Studio-snippet.txt': _marked_snippet(furniture, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END),
        'Includes_Images.xml': _read_file_if_exists(images, 400000),
        'Includes_Furniture.xml': _read_file_if_exists(furniture, 300000),
        'kodi-log-studio-filtered.txt': _studio_log_filtered(),
        'patch-status.txt': patch_status_summary(),
    }
    files_to_write['manifest.json'] = _diagnostic_manifest('studio_logo', stamp, files_to_write)
    for rel, content in files_to_write.items():
        _write_diag_file(os.path.join(out_dir, rel.replace('/', os.sep)), content)
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(out_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                zf.write(fpath, os.path.relpath(fpath, out_dir))
    log('[KPM_STUDIO_DIAG] Exported studio logo diagnostics: {0}'.format(zip_path))
    return Result(name, 'Exported', zip_path)



def _diagnostic_text(runtime: dict, target_report: dict, vfs_text: str, seekbar_text: str) -> str:
    lines = []
    lines.append(f'{ADDON_NAME} diagnostics v{VERSION}')
    lines.append(f'Generated: {time.strftime("%Y-%m-%d %H:%M:%S")}')
    lines.append('')
    lines.append('Patch status:')
    lines.append(patch_status_summary())
    lines.append('')
    lines.append('Runtime state:')
    lines.append(json.dumps(runtime, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Target files:')
    lines.append(json.dumps(target_report, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Studio logo diagnostics:')
    try:
        lines.append(_studio_diagnostic_text(studio_logo_diagnostics_report()))
    except Exception as exc:
        lines.append(f'Studio diagnostics error: {exc}')
    lines.append('')
    lines.append('DialogSeekBar marker snippet:')
    lines.append(_line_numbered_snippet(seekbar_text, DIALOG_SEEKBAR_PAUSE_RATINGS_START, DIALOG_SEEKBAR_PAUSE_RATINGS_END))
    lines.append('')
    lines.append('VideoFullScreen legacy marker snippet:')
    lines.append(_line_numbered_snippet(vfs_text, VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END))
    return '\n'.join(lines)


def _write_diag_file(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8', errors='replace') as handle:
        handle.write(content)


def export_diagnostics() -> Result:
    name = 'Export Full Diagnostics ZIP'
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_dir = addon_data_dir('runtime', 'exports', DIAG_EXPORT_DIRNAME, stamp)
    _delete_old_root_zips('kpm-full-diagnostics-')
    _delete_old_root_zips('kpm-diagnostics-')
    zip_path = os.path.join(addon_data_dir(), f'kpm-full-diagnostics-{stamp}.zip')
    runtime = _player_runtime_state()
    target_report = _target_files_report()
    vfs_target = vfs_pause_target()
    seekbar_target = seekbar_pause_target()
    vfs_text = _read_file_if_exists(vfs_target, 1000000)
    seekbar_text = _read_file_if_exists(seekbar_target, 1000000)
    diag_text = _diagnostic_text(runtime, target_report, vfs_text, seekbar_text)

    files_to_write = {
        'summary.txt': diag_text,
        'runtime.json': json.dumps(runtime, indent=2, ensure_ascii=False),
        'target-files.json': json.dumps(target_report, indent=2, ensure_ascii=False),
        'patch-status.txt': patch_status_summary(),
        'DialogSeekBar-marker-snippet.txt': _line_numbered_snippet(seekbar_text, DIALOG_SEEKBAR_PAUSE_RATINGS_START, DIALOG_SEEKBAR_PAUSE_RATINGS_END),
        'DialogSeekBar.xml': seekbar_text,
        'VideoFullScreen-legacy-marker-snippet.txt': _line_numbered_snippet(vfs_text, VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END),
        'VideoFullScreen.xml': vfs_text,
        'Includes_Info.xml': _read_file_if_exists(af3_path('1080i', 'Includes_Info.xml'), 5000000),
        'Home.xml': _read_file_if_exists(af3_path('1080i', 'Home.xml'), 3000000),
        'MyPrograms.xml': _read_file_if_exists(af3_path('1080i', 'MyPrograms.xml'), 3000000),
        'MyVideoNav.xml': _read_file_if_exists(af3_path('1080i', 'MyVideoNav.xml'), 3000000),
        'Custom_1101_Hub.xml': _read_file_if_exists(af3_path('1080i', 'Custom_1101_Hub.xml'), 3000000),
        'Custom_1102_Hub.xml': _read_file_if_exists(af3_path('1080i', 'Custom_1102_Hub.xml'), 3000000),
        'Custom_1103_Hub.xml': _read_file_if_exists(af3_path('1080i', 'Custom_1103_Hub.xml'), 3000000),
        'xml-context-snippets.json': json.dumps(_xml_context_snippets(), indent=2, ensure_ascii=False),
        'Includes_OSD.tail.txt': _read_file_if_exists(af3_path('1080i', 'Includes_OSD.xml'), 200000),
        'kodi-log-filtered.txt': _filtered_kodi_log(),
    }
    try:
        studio_report = studio_logo_diagnostics_report()
        files_to_write['studio-logo-diagnostics.txt'] = _studio_diagnostic_text(studio_report)
        files_to_write['studio-logo-diagnostics.json'] = json.dumps(studio_report, indent=2, ensure_ascii=False)
        files_to_write['studio-context.json'] = json.dumps(studio_report.get('context', {}), indent=2, ensure_ascii=False)
        files_to_write['studio-home-properties.json'] = json.dumps(studio_report.get('home_properties', {}), indent=2, ensure_ascii=False)
        files_to_write['Includes_Images-Image_CombinedStudio-snippet.txt'] = _marked_snippet(includes_images_target(), STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END)
        files_to_write['Includes_Furniture-Furniture_Studio-snippet.txt'] = _marked_snippet(includes_furniture_target(), STUDIO_FURNITURE_START, STUDIO_FURNITURE_END)
        files_to_write['kodi-log-studio-filtered.txt'] = _studio_log_filtered()
    except Exception as exc:
        files_to_write['studio-logo-diagnostics-error.txt'] = str(exc)
    lrs_settings = norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml'))
    if os.path.exists(lrs_settings):
        files_to_write['lrs-settings.xml'] = _read_text_redacted_if_settings(lrs_settings, 100000)
    lrs_addon = norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml'))
    if os.path.exists(lrs_addon):
        files_to_write['lrs-addon.xml'] = _read_file_if_exists(lrs_addon, 100000)

    steam_addon_dir = norm(translate('special://home/addons/plugin.program.steam.library'))
    steam_profile = norm(translate('special://profile/addon_data/plugin.program.steam.library'))
    _copy_text_file_to_diag(files_to_write, 'steam-library/addon.xml', norm(os.path.join(steam_addon_dir, 'addon.xml')), 300000)
    _copy_text_file_to_diag(files_to_write, 'steam-library/addon.py', norm(os.path.join(steam_addon_dir, 'addon.py')), 1200000)
    _copy_text_file_to_diag(files_to_write, 'steam-library/settings.xml', norm(os.path.join(steam_profile, 'settings.xml')), 300000)
    files_to_write['steam-library/steam_library.db.digest.json'] = json.dumps(_safe_db_digest(norm(os.path.join(steam_profile, 'steam_library.db'))), indent=2, ensure_ascii=False)

    try:
        _add_full_system_diagnostic_files(files_to_write, stamp)
    except Exception as exc:
        files_to_write['full-system-diagnostics-error.txt'] = str(exc) + '\n' + traceback.format_exc()

    live_dir = addon_data_dir('runtime', 'logs', DIAG_LIVE_DIRNAME)
    if os.path.isdir(live_dir):
        live_manifest = []
        for fname in sorted(os.listdir(live_dir)):
            if fname.startswith(DIAG_LIVE_PREFIX):
                fpath = os.path.join(live_dir, fname)
                live_manifest.append(_full_file_digest(fpath))
                files_to_write['live/' + fname] = _read_live_text_if_exists(fpath, 20000000)
        if live_manifest:
            files_to_write['live/_manifest.json'] = json.dumps(live_manifest, indent=2, ensure_ascii=False)

    files_to_write['manifest.json'] = _diagnostic_manifest('full', stamp, files_to_write)

    for rel, content in files_to_write.items():
        _write_diag_file(os.path.join(out_dir, rel.replace('/', os.sep)), content)

    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(out_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                zf.write(fpath, os.path.relpath(fpath, out_dir))

    log('[KPM_DIAG] Exported diagnostics: {0}'.format(zip_path))
    # Also log current key values into kodi.log for quick inspection.
    home_slots = runtime.get('lrs_properties', {}).get('10000', {}).get('Player', {}) if isinstance(runtime, dict) else {}
    for slot in range(1, 7):
        sd = home_slots.get(f'RatingSlot{slot}', {}) if isinstance(home_slots, dict) else {}
        log('[KPM_DIAG] Home Player Slot{0}: source={1!r} icon={2!r} label={3!r}'.format(slot, sd.get('Source'), sd.get('IconFile'), sd.get('Label')))
    return Result(name, 'Exported', zip_path)


def run_diag_live(duration_seconds: int = 90) -> None:
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_path = os.path.join(addon_data_dir('runtime', 'logs', DIAG_LIVE_DIRNAME), f'{DIAG_LIVE_PREFIX}-{stamp}.jsonl')
    end_time = time.time() + max(5, int(duration_seconds))
    notify('Live diagnostic started. Pause fullscreen video now.')
    log('[KPM_DIAG] Live fullscreen ratings diagnostic started for {0}s -> {1}'.format(duration_seconds, out_path))
    with open(out_path, 'w', encoding='utf-8') as handle:
        sample_no = 0
        while time.time() < end_time:
            if xbmc and xbmc.Monitor().abortRequested():
                break
            sample_no += 1
            data = _player_runtime_state()
            data['sample'] = sample_no
            handle.write(json.dumps(data, ensure_ascii=False) + '\n')
            handle.flush()
            conds = data.get('conditions', {})
            hp = data.get('lrs_properties', {}).get('10000', {}).get('Player', {})
            s1 = hp.get('RatingSlot1', {}) if isinstance(hp, dict) else {}
            log('[KPM_DIAG] sample={0} paused={1} seeking={2} fullscreen={3} title={4!r} slot1={5!r}/{6!r}/{7!r}'.format(
                sample_no,
                conds.get('Player.Paused'),
                conds.get('Player.Seeking'),
                conds.get('Window.IsActive(fullscreenvideo)'),
                data.get('videoplayer_labels', {}).get('Title'),
                s1.get('Source'), s1.get('IconFile'), s1.get('Label'),
            ))
            if xbmc:
                xbmc.sleep(1000)
            else:
                time.sleep(1)
    log('[KPM_DIAG] Live fullscreen ratings diagnostic finished: {0}'.format(out_path))
    notify('Live diagnostic finished. Export Diagnostics ZIP now.')


def start_live_diagnostics_menu() -> None:
    message = (
        'Start a 90 second live diagnostic logger now?\n\n'
        'After pressing Yes, go back to the video and pause it. The logger records Player.Paused, active windows, VideoPlayer labels, and all LibraryRatings.Player RatingSlot1-6 properties once per second.'
    )
    if not yesno(ADDON_NAME, message):
        return
    if xbmc:
        xbmc.executebuiltin(f'RunScript({ADDON_ID},diag_live,90)')
        ok(ADDON_NAME, 'Live diagnostic started for 90 seconds.\n\nNow go to the video, pause it, wait a few seconds, then come back here and run Export Diagnostics ZIP.')
    else:
        run_diag_live(10)


# -----------------------------------------------------------------------------
# UI and batch actions
# -----------------------------------------------------------------------------

def format_results(results: List[Result]) -> str:
    chunks = []
    for item in results:
        text = f'{item.name}: {item.status}'
        if item.detail:
            text += f'\n{item.detail}'
        chunks.append(text)
    return '\n\n'.join(chunks)


def run_single(func: Callable[[], Result]) -> None:
    try:
        result = func()
        notify(f'{result.name}: {result.status}')
        ok(ADDON_NAME, format_results([result]))
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
        ok(f'{ADDON_NAME} - Error', str(exc))


def _apply_patch_smart(patch_id: str, status_func: Callable[[], str], patch_func: Callable[[], Result]) -> Result:
    title = patch_title(patch_id, patch_id)
    try:
        status = status_func()
    except Exception as exc:
        return Result(title, 'Error', 'Status check failed before patching: {0}'.format(exc))
    if status == 'Patched':
        return Result(title, 'Skipped', 'Already current; no file was touched.')
    if status.startswith('Missing target'):
        return Result(title, 'Skipped', status)
    # Not patched, Partial, legacy, or old-version markers are intentionally sent
    # through the patcher. The patcher must update only its marked/anchored block.
    return patch_func()


def _remove_patch_smart(patch_id: str, status_func: Callable[[], str], remove_func: Callable[[], Result]) -> Result:
    title = patch_title(patch_id, patch_id)
    try:
        status = status_func()
    except Exception as exc:
        return Result(title, 'Error', 'Status check failed before removal: {0}'.format(exc))
    if status in ('Not patched', 'Unknown layout') or status.startswith('Missing target'):
        return Result(title, 'Skipped', 'Not installed; no file was touched.')
    return remove_func()


def apply_all() -> None:
    if not yesno(ADDON_NAME, 'Apply Full KPM Integration now?\n\nThis runs all KPM visual/XML patches in the correct order:\n- AF3 Unified Integration\n- Episode Thumb Up Next\n- Movies + Shows Screensaver\n- Pause Shows Full OSD\n- Reliable Studio Logos\n\nRule: status is checked first. Current patches are skipped. Old/partial patches are updated only inside their own marked/anchored blocks.'):
        return
    entries = [
        ('af3_unified_integration', status_af3_unified_integration, apply_af3_unified_integration),
        ('upnext_episode_thumb', status_upnext, patch_upnext),
        ('shw_random_movies_tvshows', status_shw, lambda: patch_shw(100)),
        ('vfs_pause_ratings', status_vfs_pause_ratings, patch_vfs_pause_ratings),
        ('reliable_studio_logos', status_reliable_studio_logos, patch_reliable_studio_logos),
    ]
    results: List[Result] = []
    for patch_id, status_func, patch_func in entries:
        try:
            results.append(_apply_patch_smart(patch_id, status_func, patch_func))
        except Exception as exc:
            log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
            results.append(Result(patch_title(patch_id, patch_id), 'Error', str(exc)))
    notify('Apply Full KPM Integration finished')
    ok(ADDON_NAME, format_results(results))


def remove_all() -> None:
    if not yesno(ADDON_NAME, 'Remove Full KPM Integration now?\n\nThis removes KPM visual/XML patches where possible:\n- AF3 Unified Integration\n- Episode Thumb Up Next\n- Movies + Shows Screensaver\n- Pause Shows Full OSD\n- Reliable Studio Logos\n\nRule: status is checked first. Missing/not-installed patches are skipped. Installed patches are removed by marker/block restore only.'):
        return
    entries = [
        ('af3_unified_integration', status_af3_unified_integration, remove_af3_unified_integration),
        ('upnext_episode_thumb', status_upnext, remove_upnext),
        ('shw_random_movies_tvshows', status_shw, remove_shw),
        ('vfs_pause_ratings', status_vfs_pause_ratings, remove_vfs_pause_ratings),
        ('reliable_studio_logos', status_reliable_studio_logos, remove_reliable_studio_logos),
    ]
    results: List[Result] = []
    for patch_id, status_func, remove_func in entries:
        try:
            results.append(_remove_patch_smart(patch_id, status_func, remove_func))
        except Exception as exc:
            log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
            results.append(Result(patch_title(patch_id, patch_id), 'Error', str(exc)))
    notify('Remove Full KPM Integration finished')
    ok(ADDON_NAME, format_results(results))


def patch_status_summary() -> str:
    lines = [f'Addon: {ADDON_NAME} v{VERSION}', '']
    lines.append('KPM Shared Icons: {0}'.format(shared_rating_icons_status()))
    lines.append('')
    for patch_id, status_name, _apply_name, _remove_name in PATCH_ORDER:
        data = patch_detail(patch_id)
        title = data.get('title', patch_id)
        status_func = globals().get(status_name)
        try:
            status = status_func() if status_func else 'Unknown'
        except Exception as exc:
            status = f'Error ({exc})'
        lines.append(f'{title}: {status}')
    return '\n'.join(lines)


def view_status() -> None:
    textviewer(f'{ADDON_NAME} - Patch Status', patch_status_summary())


def patch_message(patch_id: str, status: str) -> str:
    data = patch_detail(patch_id)
    return (
        f"Status in Kodi: {status}\n\n"
        f"Function:\n{data.get('function', '-')}\n\n"
        f"Target:\n{data.get('target', '-')}\n\n"
        f"Reference:\n{data.get('reference', '-')}\n\n"
        'Patch style:\nInject/remove selected blocks only. No full-file overwrite.'
    )


def choose_patch_action(patch_id: str, status_func: Callable[[], str]) -> str:
    data = patch_detail(patch_id)
    title = data.get('title', patch_id)
    try:
        status = status_func()
    except Exception as exc:
        status = f'Error ({exc})'
    message = patch_message(patch_id, status)

    dialog = xbmcgui.Dialog()

    # Kodi's yesnocustom labels are custom/no/yes. Use Patch as the YES button
    # and request YES as the default focused button on Kodi versions that support it.
    # Return values: -1=cancelled, 0=no, 1=yes, 2=custom.
    if hasattr(dialog, 'yesnocustom'):
        default_yes = getattr(xbmcgui, 'DLG_YESNO_YES_BTN', None)
        try:
            if default_yes is not None:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch', defaultbutton=default_yes)
            else:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
        except TypeError:
            try:
                if default_yes is not None:
                    result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch', 0, default_yes)
                else:
                    result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
            except TypeError:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
        if result == 1:
            return 'patch'
        if result == 0:
            return 'remove'
        return 'cancel'

    idx = dialog.select(title, [
        'Patch',
        'Remove',
        'Cancel',
    ], preselect=0)
    if idx == 0:
        return 'patch'
    if idx == 1:
        return 'remove'
    return 'cancel'


def run_patch_entry(patch_id: str, status_func: Callable[[], str], patch_func: Callable[[], Result], remove_func: Callable[[], Result]) -> None:
    action = choose_patch_action(patch_id, status_func)
    if action == 'patch':
        run_single(patch_func)
    elif action == 'remove':
        run_single(remove_func)


def run_console() -> None:
    print(f'{ADDON_NAME} v{VERSION}')
    print('This add-on is intended to run inside Kodi.')
    print('Status:')
    print('  Episode Thumb Up Next:', status_upnext())
    print('  Movies + Shows Screensaver:', status_shw())
    print('  Pause Shows Full OSD:', status_vfs_pause_ratings())
    print('  Reliable Studio Logos:', status_reliable_studio_logos())


def advanced_patches_menu(patch_entries) -> None:
    while True:
        items = [patch_detail(patch_id).get('title', patch_id) for patch_id, *_ in patch_entries]
        index = xbmcgui.Dialog().select(f'{ADDON_NAME} - Advanced Patches', items)
        if index < 0:
            return
        patch_id, status_func, patch_func, remove_func = patch_entries[index]
        run_patch_entry(patch_id, status_func, patch_func, remove_func)


def settings_menu() -> None:
    save_kpm_settings({'studio_logo_count': 1})
    if os.path.exists(state_file('reliable_studio_logos')):
        _start_resume_close_service()
    ok(ADDON_NAME, 'Reliable Studio Logos is now fixed to one best valid logo.\n\nKPM.StudioLogo.1 is the only render source. Movie/TV uses resource.images.studios.coloured; Steam games use resource.images.gamestudios.grayscale when installed. There is no fallback to AF3 raw studio paths, so combined labels like A / B / C.png cannot be used by the footer.')





def af3_unified_integration_menu() -> None:
    items = [
        'Apply AF3 Unified Integration',
        'Remove AF3 Unified Integration',
        'Status',
    ]
    index = xbmcgui.Dialog().select(f'{ADDON_NAME} - AF3 Unified Integration', items)
    if index < 0:
        return
    if index == 0:
        run_single(apply_af3_unified_integration)
    elif index == 1:
        run_single(remove_af3_unified_integration)
    elif index == 2:
        ok('AF3 Unified Integration', status_af3_unified_integration())


def diagnostics_menu() -> None:
    while True:
        items = [
            'Start Ratings Live Diagnostic',
            'Export Full Diagnostics ZIP',
            'Export Studio Logo Diagnostics',
        ]
        index = xbmcgui.Dialog().select(f'{ADDON_NAME} - Diagnostics', items)
        if index < 0:
            return
        if index == 0:
            start_live_diagnostics_menu()
        elif index == 1:
            run_single(export_diagnostics)
        elif index == 2:
            run_single(export_studio_logo_diagnostics)


def run() -> None:
    if not xbmcgui:
        run_console()
        return
    patch_entries = [
        ('af3_unified_integration', status_af3_unified_integration, apply_af3_unified_integration, remove_af3_unified_integration),
        ('upnext_episode_thumb', status_upnext, patch_upnext, remove_upnext),
        ('shw_random_movies_tvshows', status_shw, lambda: patch_shw(100), remove_shw),
        ('vfs_pause_ratings', status_vfs_pause_ratings, patch_vfs_pause_ratings, remove_vfs_pause_ratings),
        ('reliable_studio_logos', status_reliable_studio_logos, patch_reliable_studio_logos, remove_reliable_studio_logos),
    ]
    while True:
        items = [
            'Apply Full KPM Integration',
            'Remove Full KPM Integration',
            'Advanced Patches',
            'Patch Status',
            'Diagnostics',
            'Clear Add-on Icon Cache',
            'Settings',
            'Exit',
        ]
        index = xbmcgui.Dialog().select(ADDON_NAME, items)
        if index < 0 or index == len(items) - 1:
            return
        if index == 0:
            apply_all()
        elif index == 1:
            remove_all()
        elif index == 2:
            advanced_patches_menu(patch_entries)
        elif index == 3:
            view_status()
        elif index == 4:
            diagnostics_menu()
        elif index == 5:
            clear_addon_icon_cache_menu()
        elif index == 6:
            settings_menu()


# -----------------------------------------------------------------------------
# v0.1.83 - Clean AF3 integration owner (KPM-owned XML, no LRS/Steam patch calls)
# -----------------------------------------------------------------------------
KPM_AF3_ROW_CALL_START = '<!-- KPM-AF3-RATING-ROW-CALL-START-0183 -->'
KPM_AF3_ROW_CALL_END = '<!-- KPM-AF3-RATING-ROW-CALL-END-0183 -->'
KPM_AF3_ROW_DEF_START = '<!-- KPM-AF3-RATING-ROW-DEF-START-0183 -->'
KPM_AF3_ROW_DEF_END = '<!-- KPM-AF3-RATING-ROW-DEF-END-0183 -->'
KPM_STEAM_INFO_START = '<!-- KPM-AF3-STEAM-INFO-LINE-START-0183 -->'
KPM_STEAM_INFO_END = '<!-- KPM-AF3-STEAM-INFO-LINE-END-0183 -->'
KPM_STEAM_PLOT_START = '<!-- KPM-AF3-STEAM-PLOT-START-0183 -->'
KPM_STEAM_PLOT_END = '<!-- KPM-AF3-STEAM-PLOT-END-0183 -->'
LEGACY_LRS_CALL_START_RE = re.compile(r'\s*<!--\s*LRS-AF3-META-CALL-START[^>]*-->.*?<!--\s*LRS-AF3-META-CALL-END[^>]*-->\s*', re.I | re.S)
LEGACY_LRS_DEF_RE = re.compile(r'\s*<!--\s*LRS-AF3-INCLUDE-DEF-START\s*-->.*?<!--\s*LRS-AF3-INCLUDE-DEF-END\s*-->\s*', re.I | re.S)
LEGACY_KPM_ROW_CALL_RE = re.compile(r'\s*<!--\s*KPM-AF3-RATING-ROW-CALL-START-[^>]*-->.*?<!--\s*KPM-AF3-RATING-ROW-CALL-END-[^>]*-->\s*', re.I | re.S)
LEGACY_KPM_ROW_DEF_RE = re.compile(r'\s*<!--\s*KPM-AF3-RATING-ROW-DEF-START-[^>]*-->.*?<!--\s*KPM-AF3-RATING-ROW-DEF-END-[^>]*-->\s*', re.I | re.S)

def _kpm_row_call_block() -> str:
    return '''                    {start}
                    <include content="KPM_Info_Meta_RatingRow">
                        <param name="visible">$PARAM[visible]</param>
                        <param name="container">$PARAM[container]</param>
                        <param name="listitem">$PARAM[listitem]</param>
                    </include>
                    {end}
'''.format(start=KPM_AF3_ROW_CALL_START, end=KPM_AF3_ROW_CALL_END)

def _kpm_row_def_block() -> str:
    parts = [KPM_AF3_ROW_DEF_START, '    <include name="KPM_Info_Meta_RatingRow">', '        <definition>']
    for idx in range(1, 11):
        parts.append('''            <include content="Info_Meta_Object">
                <param name="icon">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(KPM.RatingRow.Slot{idx}_IconFile)]</param>
                <param name="label">$INFO[Window(Home).Property(KPM.RatingRow.Slot{idx}_Label)]</param>
                <param name="visible">[$PARAM[visible]] + String.IsEqual(Window(Home).Property(KPM.RatingRow.Visible),true) + !String.IsEmpty(Window(Home).Property(KPM.RatingRow.Slot{idx}_Label)) + !String.IsEmpty(Window(Home).Property(KPM.RatingRow.Slot{idx}_IconFile))</param>
                <param name="colordiffuse">main_fg</param>
            </include>'''.format(idx=idx))
    parts += ['        </definition>', '    </include>', KPM_AF3_ROW_DEF_END]
    return '\n'.join(parts) + '\n'

def _remove_legacy_rating_xml(text: str) -> str:
    text = LEGACY_KPM_ROW_CALL_RE.sub('', text)
    text = LEGACY_KPM_ROW_DEF_RE.sub('', text)
    text = LEGACY_LRS_CALL_START_RE.sub('\n', text)
    text = LEGACY_LRS_DEF_RE.sub('\n', text)
    return text

def _patch_kpm_rating_row_info_xml(text: str):
    original = text
    text = _remove_legacy_rating_xml(text)
    if '<!-- Ratings -->' in text:
        text = text.replace('                    <!-- Ratings -->', '                    <!-- Ratings -->\n' + _kpm_row_call_block().rstrip('\n'), 1)
    elif '<include name="Info_Meta">' in text:
        text = text.replace('<include name="Info_Meta">', '<include name="Info_Meta">\n' + _kpm_row_call_block(), 1)
    if '</includes>' in text:
        text = text.replace('</includes>', _kpm_row_def_block() + '</includes>', 1)
    return text, text != original

def _patch_kpm_steam_info_plot(text: str):
    original = text
    steam_info = '''                {start}
                <include content="Info_Line_Pill_Text">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">STEAM</param>
                    <param name="width">auto</param>
                    <param name="min_width">86</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</param>
                </include>
                <include content="Info_Line_StarRating" condition="!Skin.HasSetting(InfoTags.DisableStarRating)">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="rating">$PARAM[container]$PARAM[listitem].Rating</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].Rating)</param>
                </include>
                <include content="Info_Line_Label">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Property(steam_review_desc)]</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(steam_review_desc)) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(steam_review_desc),N/A)</param>
                </include>
                <include content="Info_Line_Label">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Year]</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].Year)</param>
                </include>
                <include content="Info_Line_Label">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Property(age_rating_display)]</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(age_rating_display)) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(age_rating_display),N/A)</param>
                </include>
                {end}
'''.format(start=KPM_STEAM_INFO_START, end=KPM_STEAM_INFO_END)
    text = re.sub(r'\s*<!--\s*KPM-AF3-STEAM-INFO-LINE-START-[^>]*-->.*?<!--\s*KPM-AF3-STEAM-INFO-LINE-END-[^>]*-->\s*', '\n', text, flags=re.I|re.S)
    text = re.sub(r'\s*<!--\s*Steam Game Info Line\s*-->.*?(?=\s*<!--\s*Info Pill\s*-->)', '\n', text, flags=re.I|re.S)
    if '                <!-- Info Pill -->' in text:
        text = text.replace('                <!-- Info Pill -->', steam_info + '                <!-- Info Pill -->', 1)
    steam_plot = '''        {start}
        <control type="group">
            <visible>$PARAM[visible]</visible>
            <visible>![$PARAM[override]]</visible>
            <visible>!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</visible>
            <height>120</height>
            <control type="label">
                <top>0</top><left>40</left><height>40</height><width>$PARAM[width]</width>
                <font>font_main_bold</font><textcolor>$PARAM[colordiffuse]_90</textcolor>
                <label>$INFO[$PARAM[container]$PARAM[listitem].Property(tagline_display)]</label>
                <visible>!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(tagline_display))</visible>
            </control>
            <include content="Info_Plot_TextBox">
                <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Plot]</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
                <param name="use_textbox">$PARAM[use_textbox]</param>
                <param name="height">80</param>
                <param name="width">$PARAM[width]</param>
                <param name="top">40</param>
            </include>
        </control>
        {end}
'''.format(start=KPM_STEAM_PLOT_START, end=KPM_STEAM_PLOT_END)
    text = re.sub(r'\s*<!--\s*KPM-AF3-STEAM-PLOT-START-[^>]*-->.*?<!--\s*KPM-AF3-STEAM-PLOT-END-[^>]*-->\s*', '\n', text, flags=re.I|re.S)
    text = re.sub(r'\s*<!--\s*Steam Game Plot\s*-->\s*<control type="group">.*?</control>\s*', '\n', text, flags=re.I|re.S)
    if '<include name="Info_Plot_Main">' in text and '        <!-- Movie -->' in text:
        text = text.replace('        <!-- Movie -->', steam_plot + '        <!-- Movie -->', 1)
    return text, text != original

def _patch_af3_info_xml_kpm_owned(text: str):
    t, c1 = _patch_kpm_rating_row_info_xml(text)
    t, c2 = _patch_kpm_steam_info_plot(t)
    return t, c1 or c2

def _patch_file_text(path: str, patcher, backup_suffix: str) -> bool:
    original = read_text(path)
    backup = path + backup_suffix
    if not os.path.exists(backup): write_text(backup, original)
    patched, changed = patcher(original)
    if changed: write_text(path, patched)
    return changed

def status_af3_unified_integration() -> str:
    info = af3_path('1080i', 'Includes_Info.xml')
    if os.path.exists(info):
        try:
            text = read_text(info)
            if KPM_AF3_ROW_CALL_START in text and KPM_AF3_ROW_DEF_START in text:
                return 'Patched (KPM-owned)'
        except Exception:
            pass
    return 'Not patched'

def apply_af3_unified_integration() -> Result:
    info_xml = af3_path('1080i', 'Includes_Info.xml')
    if not os.path.exists(info_xml):
        return Result('AF3 Unified Integration', 'Skipped', 'Includes_Info.xml not found:\n{0}'.format(info_xml))
    changed = _patch_file_text(info_xml, _patch_af3_info_xml_kpm_owned, '.kpm0183-unified.bak')
    save_state('af3_unified_integration', {'enabled': True, 'version': VERSION, 'owner': 'KPM', 'visual_properties': 'KPM.RatingRow.*', 'changed': bool(changed)})
    return Result('AF3 Unified Integration', 'Patched' if changed else 'Skipped', 'KPM-owned AF3 integration is active.' + ('' if changed else ' Already current.'))

def remove_af3_unified_integration() -> Result:
    info_xml = af3_path('1080i', 'Includes_Info.xml')
    changed = False
    if os.path.exists(info_xml):
        original = read_text(info_xml)
        text = _remove_legacy_rating_xml(original)
        text = re.sub(r'\s*<!--\s*KPM-AF3-STEAM-INFO-LINE-START-[^>]*-->.*?<!--\s*KPM-AF3-STEAM-INFO-LINE-END-[^>]*-->\s*', '\n', text, flags=re.I|re.S)
        text = re.sub(r'\s*<!--\s*KPM-AF3-STEAM-PLOT-START-[^>]*-->.*?<!--\s*KPM-AF3-STEAM-PLOT-END-[^>]*-->\s*', '\n', text, flags=re.I|re.S)
        if text != original:
            write_text(info_xml, text)
            changed = True
    delete_state('af3_unified_integration')
    return Result('AF3 Unified Integration', 'Removed' if changed else 'Skipped', 'KPM-owned AF3 integration removed.' if changed else 'Not installed; no file was touched.')

# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import re
import shutil
import sqlite3
import time
import traceback
import zipfile
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple
from urllib.parse import unquote

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # Allows syntax checks outside Kodi.
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

ADDON_ID = 'script.kodi.patch.manager'
ADDON_NAME = 'Kodi Patch Manager'
VERSION = '0.1.11'

# Markers: every injected/replaced block has an obvious marker.
UPNEXT_MARKER = '<!-- KPM-UPNEXT-EPISODE-THUMB -->'
SHW_METHOD_START = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-METHOD-START'
SHW_METHOD_END = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-METHOD-END'
SHW_ENTRY_MARKER = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-LISTING'
SHW_XML_MARKER = '<!-- KPM-SHW-RANDOM-MOVIES-TVSHOWS-XML -->'
LEGACY_SHW_METHOD_START = '# AFM-RANDOM-MOVIES-TVSHOWS-METHOD-START'
LEGACY_SHW_METHOD_END = '# AFM-RANDOM-MOVIES-TVSHOWS-METHOD-END'
LEGACY_SHW_ENTRY_MARKER = '# AFM-RANDOM-MOVIES-TVSHOWS-LISTING'
LEGACY_SHW_XML_MARKER = '<!-- AFM-RANDOM-MOVIES-TVSHOWS-XML-PATCH -->'
TMDB_ATTR_MARKER = '# KPM-TMDB-FOCUS-RANDOM-V11-ATTR'
TMDB_REFRESH_START = '# KPM-TMDB-FOCUS-RANDOM-V11-REFRESH-START'
TMDB_REFRESH_END = '# KPM-TMDB-FOCUS-RANDOM-V11-REFRESH-END'
TMDB_HELPER_START = '# KPM-TMDB-FOCUS-RANDOM-V11-HELPER-START'
TMDB_HELPER_END = '# KPM-TMDB-FOCUS-RANDOM-V11-HELPER-END'
TMDB_CALL_MARKER = '# KPM-TMDB-FOCUS-RANDOM-V11-CALL'
LEGACY_TMDB_MARKER = 'Focus-random sticky visit patch V11'
VFS_PAUSE_RATINGS_START = '<!-- KPM-VFS-PAUSE-RATINGS-START -->'
VFS_PAUSE_RATINGS_END = '<!-- KPM-VFS-PAUSE-RATINGS-END -->'


PATCH_DETAILS = {
    'upnext_episode_thumb': {
        'title': 'Episode Thumb Up Next',
        'apply_label': 'Patch Episode Thumb Up Next',
        'remove_label': 'Remove Episode Thumb Up Next',
        'summary': 'Use next episode thumbnail first.',
        'function': 'Makes the Up Next popup show the next episode thumbnail first, then falls back to landscape and fanart.',
        'target': 'skin.arctic.fuse.3/1080i/Includes_Images.xml -> variable Image_UpNext',
        'reference': 'Native Kodi patcher. No bundled standalone patch file.',
    },
    'tmdb_focus_random_v11': {
        'title': 'Stable Random Fanart',
        'apply_label': 'Patch Stable Random Fanart',
        'remove_label': 'Remove Stable Random Fanart',
        'summary': 'Lock random fanart per focused item.',
        'function': 'Keeps TMDbHelper random extra-fanart stable while focus stays on the same item, then refreshes only after a new item/window visit.',
        'target': 'plugin.video.themoviedb.helper -> imgmon.py and images.py',
        'reference': 'Converted to native Kodi patcher. No bundled standalone patch file.',
    },

    'af3_lrs_ratings_ui': {
        'title': 'AF3 x LRS Ratings UI',
        'apply_label': 'Patch AF3 x LRS Ratings UI',
        'remove_label': 'Remove AF3 x LRS Ratings UI',
        'summary': 'AF3 rating row, hub bridge, screensaver row.',
        'function': 'Injects Library Ratings Scraper display blocks into Arctic Fuse 3: info rating slots, hub active-item bridge, screensaver rating row, final clearlogo guard, Oscar/Emmy/status icons, and Oscar Best Picture icon path.',
        'target': 'skin.arctic.fuse.3/1080i -> Includes_Info.xml, Includes_Hubs.xml, screensaver-arctic-mirage.xml',
        'reference': 'Converted from the uploaded AF3 x LRS complete patch into native Kodi inject/remove logic. No standalone script file is bundled.',
    },
    'vfs_pause_ratings': {
        'title': 'Fullscreen Pause Ratings',
        'apply_label': 'Patch Fullscreen Pause Ratings',
        'remove_label': 'Remove Fullscreen Pause Ratings',
        'summary': 'Show LRS-only rating row beside Paused.',
        'function': 'Adds a compact LRS-only player rating row in VideoFullScreen.xml, positioned beside the Paused header during fullscreen pause. It reads LibraryRatings.Player.RatingSlot1-6 only.',
        'target': 'skin.arctic.fuse.3/1080i/VideoFullScreen.xml -> fullscreen pause overlay row',
        'reference': 'Native Kodi patcher. Reads LRS properties from LibraryRatings.Player.RatingSlot1-6 only.',
    },
    'shw_random_movies_tvshows': {
        'title': 'Movies + Shows Screensaver',
        'apply_label': 'Patch Movies + Shows Screensaver',
        'remove_label': 'Remove Movies + Shows Screensaver',
        'summary': 'Random movies + TV shows only; no episodes.',
        'function': 'Adds a Skin Helper Widgets random source that returns movies and TV shows only, then points AF3 screensaver widget to that source so episodes are excluded.',
        'target': 'script.skin.helper.widgets/resources/lib/media.py + skin.arctic.fuse.3/1080i/Includes_Defaults.xml',
        'reference': 'Converted to native Kodi patcher. No bundled standalone patch file.',
    },
}


def patch_detail(patch_id: str) -> dict:
    return PATCH_DETAILS.get(patch_id, {})


def patch_title(patch_id: str, fallback: str) -> str:
    return patch_detail(patch_id).get('title', fallback)


def menu_label(patch_id: str, mode: str) -> str:
    data = patch_detail(patch_id)
    return data.get('apply_label' if mode == 'apply' else 'remove_label', data.get('title', patch_id))


PATCH_ORDER = (
    ('upnext_episode_thumb', 'status_upnext', 'patch_upnext', 'remove_upnext'),
    ('tmdb_focus_random_v11', 'status_tmdb', 'patch_tmdb', 'remove_tmdb'),
    ('shw_random_movies_tvshows', 'status_shw', 'patch_shw', 'remove_shw'),
    ('af3_lrs_ratings_ui', 'status_lrs_af3', 'patch_lrs_af3', 'remove_lrs_af3'),
    ('vfs_pause_ratings', 'status_vfs_pause_ratings', 'patch_vfs_pause_ratings', 'remove_vfs_pause_ratings'),
)


def patch_details_summary(include_status: bool = False) -> str:
    chunks = []
    for patch_id, status_name, _apply_name, _remove_name in PATCH_ORDER:
        data = patch_detail(patch_id)
        heading = data.get('title', patch_id)
        if include_status:
            status_func = globals().get(status_name)
            if status_func:
                try:
                    heading += f': {status_func()}'
                except Exception as exc:
                    heading += f': Error ({exc})'
        chunks.append(
            f"{heading}\n"
            f"Function: {data.get('function', '-')}\n"
            f"Target: {data.get('target', '-')}\n"
            f"Reference: {data.get('reference', '-')}"
        )
    return '\n\n'.join(chunks)


def log(message: str, level=None) -> None:
    if xbmc:
        xbmc.log(f'[{ADDON_NAME}] {message}', level or xbmc.LOGINFO)
    else:
        print(f'[{ADDON_NAME}] {message}')


def notify(message: str, icon=None) -> None:
    if xbmcgui:
        xbmcgui.Dialog().notification(ADDON_NAME, message, icon or xbmcgui.NOTIFICATION_INFO, 3500)
    else:
        print(message)


def ok(title: str, message: str) -> None:
    if xbmcgui:
        xbmcgui.Dialog().ok(title, message)
    else:
        print('\n' + title + '\n' + message)


def yesno(title: str, message: str) -> bool:
    if xbmcgui:
        return xbmcgui.Dialog().yesno(title, message)
    return True


def translate(path: str) -> str:
    if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if xbmc and hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return (path
            .replace('special://home/', os.environ.get('KODI_HOME', 'E:/Kodi/portable_data/'))
            .replace('special://profile/', os.environ.get('KODI_PROFILE', 'E:/Kodi/portable_data/userdata/')))


def addon_data_dir(*parts: str) -> str:
    base = translate(f'special://profile/addon_data/{ADDON_ID}')
    path = os.path.join(base, *parts)
    os.makedirs(path, exist_ok=True)
    return path


def norm(path: str) -> str:
    return os.path.normpath(path)


def read_text(path: str) -> str:
    if not os.path.exists(path):
        raise FileNotFoundError(f'File not found: {path}')
    with open(path, 'r', encoding='utf-8-sig', errors='replace', newline='') as handle:
        return handle.read()


def write_text(path: str, text: str) -> None:
    # This writes the active file after a targeted text edit. It never copies a bundled full target file over it.
    with open(path, 'w', encoding='utf-8', errors='replace', newline='') as handle:
        handle.write(text)


def newline_of(text: str) -> str:
    return '\r\n' if '\r\n' in text else '\n'


def safe_name(path: str) -> str:
    drive, tail = os.path.splitdrive(path)
    value = (drive.replace(':', '') + tail).replace('\\', '__').replace('/', '__').strip('_')
    return value or 'file'


def save_json(path: str, data: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)


def load_json(path: str) -> dict:
    with open(path, 'r', encoding='utf-8') as handle:
        return json.load(handle)


def state_file(patch_id: str) -> str:
    return os.path.join(addon_data_dir('state'), f'{patch_id}.json')


def save_state(patch_id: str, data: dict) -> None:
    data.setdefault('patch_id', patch_id)
    data.setdefault('version', VERSION)
    data.setdefault('saved_at', time.strftime('%Y-%m-%d %H:%M:%S'))
    save_json(state_file(patch_id), data)


def load_state(patch_id: str) -> dict:
    path = state_file(patch_id)
    if not os.path.exists(path):
        raise FileNotFoundError(f'Patch state not found: {path}')
    return load_json(path)


def delete_state(patch_id: str) -> None:
    path = state_file(patch_id)
    if os.path.exists(path):
        os.remove(path)


def snapshot(patch_id: str, paths: List[str]) -> None:
    # Safety only. Normal restore/remove below is block-level and does not use this to overwrite target files.
    root = addon_data_dir('snapshots', patch_id, time.strftime('%Y%m%d-%H%M%S'))
    manifest = []
    for path in paths:
        if os.path.exists(path):
            dst_name = safe_name(path)
            shutil.copy2(path, os.path.join(root, dst_name))
            manifest.append({'source': path, 'snapshot': dst_name})
    save_json(os.path.join(root, 'manifest.json'), {'files': manifest})


def af3_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/skin.arctic.fuse.3'), *parts))


def tmdbhelper_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/plugin.video.themoviedb.helper'), *parts))


def skinhelper_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/script.skin.helper.widgets'), *parts))


def clear_pycache(folder: str, prefixes: Tuple[str, ...]) -> None:
    cache = os.path.join(folder, '__pycache__')
    if not os.path.isdir(cache):
        return
    for name in os.listdir(cache):
        if name.endswith('.pyc') and any(name.startswith(prefix + '.') for prefix in prefixes):
            try:
                os.remove(os.path.join(cache, name))
            except Exception:
                pass


@dataclass
class Result:
    name: str
    status: str
    detail: str = ''


# -----------------------------------------------------------------------------
# Patch 1: AF3 Up Next episode thumbnail priority
# -----------------------------------------------------------------------------

def upnext_target() -> str:
    return af3_path('1080i', 'Includes_Images.xml')


def status_upnext() -> str:
    target = upnext_target()
    if not os.path.exists(target):
        return 'Missing target'
    text = read_text(target)
    if UPNEXT_MARKER in text:
        return 'Patched'
    if '<variable name="Image_UpNext">' in text:
        return 'Not patched'
    return 'Unknown layout'


def patch_upnext() -> Result:
    name = patch_title('upnext_episode_thumb', 'Episode Thumb Up Next')
    target = upnext_target()
    text = read_text(target)
    if UPNEXT_MARKER in text:
        return Result(name, 'Skipped', 'Already patched.')

    pattern = r'(?ms)([ \t]*)<variable\s+name="Image_UpNext">.*?</variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Anchor not found: variable Image_UpNext in Includes_Images.xml')

    original = match.group(0)
    nl = newline_of(text)
    indent = match.group(1)
    inner = indent + '    '
    new_block = nl.join([
        f'{indent}<variable name="Image_UpNext">',
        f'{inner}{UPNEXT_MARKER}',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(thumb))">$INFO[Window.Property(thumb)]</value>',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(landscape))">$INFO[Window.Property(landscape)]</value>',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(fanart))">$INFO[Window.Property(fanart)]</value>',
        f'{indent}</variable>',
    ])

    snapshot('upnext_episode_thumb', [target])
    save_state('upnext_episode_thumb', {'target': target, 'original_block': original})
    text = text[:match.start()] + new_block + text[match.end():]
    write_text(target, text)
    return Result(name, 'Patched', 'Image_UpNext priority: thumb -> landscape -> fanart.')


def remove_upnext() -> Result:
    name = patch_title('upnext_episode_thumb', 'Episode Thumb Up Next')
    target = upnext_target()
    text = read_text(target)
    if UPNEXT_MARKER not in text:
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('upnext_episode_thumb')
    original = state.get('original_block')
    if not original:
        raise RuntimeError('Original Image_UpNext block is missing from saved state.')
    pattern = r'(?ms)[ \t]*<variable\s+name="Image_UpNext">(?:(?!</variable>).)*?' + re.escape(UPNEXT_MARKER) + r'.*?</variable>'
    if not re.search(pattern, text):
        raise RuntimeError('Patched Image_UpNext block not found.')
    text = re.sub(pattern, original, text, count=1)
    write_text(target, text)
    delete_state('upnext_episode_thumb')
    return Result(name, 'Removed', 'Original Image_UpNext block restored only.')


# -----------------------------------------------------------------------------
# Patch 2: TMDbHelper focus-random sticky visit V11
# -----------------------------------------------------------------------------

def tmdb_targets() -> Tuple[str, str]:
    imgmon = tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'imgmon.py')
    images = tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'images.py')
    return imgmon, images


def status_tmdb() -> str:
    imgmon, images = tmdb_targets()
    if not os.path.exists(imgmon) or not os.path.exists(images):
        return 'Missing target'
    t1 = read_text(imgmon)
    t2 = read_text(images)
    if TMDB_REFRESH_START in t1 and TMDB_HELPER_START in t2 and TMDB_CALL_MARKER in t2:
        return 'Patched'
    if LEGACY_TMDB_MARKER in t1 and '_focus_random_sticky_choose' in t2:
        return 'Patched (legacy)'
    return 'Not patched'


def patch_tmdb_imgmon(text: str) -> Tuple[str, Dict[str, str]]:
    nl = newline_of(text)
    state: Dict[str, str] = {}

    if TMDB_ATTR_MARKER not in text:
        pattern_attr = r'self\.properties\s*=\s*set\(\)'
        match_attr = re.search(pattern_attr, text)
        if not match_attr:
            raise RuntimeError('Anchor not found in imgmon.py: self.properties = set()')
        replacement_attr = match_attr.group(0) + nl + f'        self._focus_random_visit_id = 0  {TMDB_ATTR_MARKER}'
        text = text[:match_attr.start()] + replacement_attr + text[match_attr.end():]

    if TMDB_REFRESH_START not in text:
        pattern_refresh = (
            r'(?ms)(        # Check if the item has changed before retrieving details again\r?\n'
            r'        if not self\.is_same_item\(update=True\) or not self\.is_same_window\(update=True\):\r?\n)'
            r'(.*?)'
            r'(?=\r?\n    @kodi_try_except)'
        )
        match_refresh = re.search(pattern_refresh, text)
        if not match_refresh:
            raise RuntimeError('Anchor not found in imgmon.py: is_next_refresh block')
        original_block = match_refresh.group(0)
        state['original_refresh_block'] = original_block
        prefix = match_refresh.group(1)
        new_block = prefix + nl.join([
            f'            {TMDB_REFRESH_START}',
            '            # New item/window = new random visit.',
            '            try:',
            '                self._focus_random_visit_id += 1',
            '            except AttributeError:',
            '                self._focus_random_visit_id = 1',
            '            return True',
            '',
            '        # Disable idle extra-fanart refresh.',
            '        # Random only changes when Kodi focus moves to another item/window.',
            '        return False',
            f'        {TMDB_REFRESH_END}',
        ])
        text = text[:match_refresh.start()] + new_block + text[match_refresh.end():]
    return text, state


TMDB_HELPER_BLOCK = '''
# KPM-TMDB-FOCUS-RANDOM-V11-HELPER-START
# Keeps the random fanart choice stable while the same focused item is being processed.
# A new visit id from imgmon.py allows the same movie to get a new random fanart when you leave it and return.
_FOCUS_RANDOM_STICKY_BY_VISIT = {}
_FOCUS_RANDOM_STICKY_LAST_BY_ITEM = {}


def _focus_random_sticky_unique(values):
    output = []
    for value in values:
        if value and value not in output:
            output.append(value)
    return output


def _focus_random_sticky_attr(parent, name, default=None):
    try:
        return getattr(parent, name, default)
    except Exception:
        return default


def _focus_random_sticky_choose(item, artworks, parent=None):
    artworks = _focus_random_sticky_unique(artworks)
    if not artworks:
        return None
    if len(artworks) == 1:
        return artworks[0]

    parent_id = id(parent) if parent is not None else 0
    visit_id = _focus_random_sticky_attr(parent, '_focus_random_visit_id', 0)
    cur_item = repr(_focus_random_sticky_attr(parent, 'pre_item', None))
    cur_window = repr(_focus_random_sticky_attr(parent, 'pre_window', None))

    visit_key = (parent_id, visit_id, cur_item, cur_window, item)
    cached = _FOCUS_RANDOM_STICKY_BY_VISIT.get(visit_key)
    if cached in artworks:
        return cached

    item_key = (parent_id, cur_item, item)
    last = _FOCUS_RANDOM_STICKY_LAST_BY_ITEM.get(item_key)
    choices = [art for art in artworks if art != last] or artworks
    choice = random.choice(choices)

    _FOCUS_RANDOM_STICKY_BY_VISIT[visit_key] = choice
    _FOCUS_RANDOM_STICKY_LAST_BY_ITEM[item_key] = choice

    # Keep dictionaries small during long library browsing sessions.
    if len(_FOCUS_RANDOM_STICKY_BY_VISIT) > 500:
        _FOCUS_RANDOM_STICKY_BY_VISIT.clear()
        _FOCUS_RANDOM_STICKY_BY_VISIT[visit_key] = choice
    if len(_FOCUS_RANDOM_STICKY_LAST_BY_ITEM) > 500:
        _FOCUS_RANDOM_STICKY_LAST_BY_ITEM.clear()
        _FOCUS_RANDOM_STICKY_LAST_BY_ITEM[item_key] = choice

    return choice
# KPM-TMDB-FOCUS-RANDOM-V11-HELPER-END
'''.strip('\n')


def patch_tmdb_images(text: str) -> Tuple[str, Dict[str, str]]:
    nl = newline_of(text)
    state: Dict[str, str] = {}

    if TMDB_HELPER_START not in text:
        anchor = 'class ImageFunctions'
        index = text.find(anchor)
        if index < 0:
            raise RuntimeError('Anchor not found in images.py: class ImageFunctions')
        helper = TMDB_HELPER_BLOCK.replace('\n', nl) + nl + nl
        text = text[:index] + helper + text[index:]

    if TMDB_CALL_MARKER not in text:
        matches = list(re.finditer(r'return\s+random\.choice\(artworks\)', text))
        if len(matches) != 1:
            raise RuntimeError(f'Anchor mismatch in images.py: return random.choice(artworks) count={len(matches)}')
        match = matches[0]
        state['original_random_choice_line'] = match.group(0)
        new_line = f'return _focus_random_sticky_choose(item, artworks, self._parent)  {TMDB_CALL_MARKER}'
        text = text[:match.start()] + new_line + text[match.end():]
    return text, state


def patch_tmdb() -> Result:
    name = patch_title('tmdb_focus_random_v11', 'Stable Random Fanart')
    imgmon, images = tmdb_targets()
    t1 = read_text(imgmon)
    t2 = read_text(images)
    if TMDB_REFRESH_START in t1 and TMDB_HELPER_START in t2 and TMDB_CALL_MARKER in t2:
        return Result(name, 'Skipped', 'Already patched.')
    if LEGACY_TMDB_MARKER in t1 and '_focus_random_sticky_choose' in t2:
        return Result(name, 'Skipped', 'Legacy V11 patch already detected. Not injecting duplicate code.')

    snapshot('tmdb_focus_random_v11', [imgmon, images])
    n1, s1 = patch_tmdb_imgmon(t1)
    n2, s2 = patch_tmdb_images(t2)
    save_state('tmdb_focus_random_v11', {'imgmon': imgmon, 'images': images, 'imgmon_state': s1, 'images_state': s2})
    write_text(imgmon, n1)
    write_text(images, n2)
    clear_pycache(os.path.dirname(imgmon), ('imgmon', 'images'))
    return Result(name, 'Patched', 'Injected stable random fanart visit logic; pycache cleaned.')


def remove_tmdb() -> Result:
    name = patch_title('tmdb_focus_random_v11', 'Stable Random Fanart')
    imgmon, images = tmdb_targets()
    t1 = read_text(imgmon)
    t2 = read_text(images)
    has_kpm = TMDB_REFRESH_START in t1 or TMDB_HELPER_START in t2 or TMDB_CALL_MARKER in t2 or TMDB_ATTR_MARKER in t1
    if not has_kpm:
        if LEGACY_TMDB_MARKER in t1 and '_focus_random_sticky_choose' in t2:
            return Result(name, 'Skipped', 'Legacy V11 patch detected. It was not installed by this add-on, so block-level restore state is unavailable.')
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('tmdb_focus_random_v11') if os.path.exists(state_file('tmdb_focus_random_v11')) else {}

    # Remove inserted attribute line.
    t1 = re.sub(r'\r?\n[ \t]*self\._focus_random_visit_id\s*=\s*0\s*' + re.escape(TMDB_ATTR_MARKER), '', t1, count=1)

    # Restore only the original is_next_refresh block if state exists. Otherwise fail safely.
    if TMDB_REFRESH_START in t1:
        original = state.get('imgmon_state', {}).get('original_refresh_block')
        if not original:
            raise RuntimeError('Cannot remove TMDbHelper refresh patch: original block state is missing.')
        pattern = (
            r'(?ms)        # Check if the item has changed before retrieving details again\r?\n'
            r'        if not self\.is_same_item\(update=True\) or not self\.is_same_window\(update=True\):\r?\n'
            r'.*?' + re.escape(TMDB_REFRESH_END)
        )
        t1 = re.sub(pattern, original, t1, count=1)

    # Remove helper block and restore random.choice line.
    if TMDB_HELPER_START in t2:
        helper_pattern = r'(?ms)\r?\n?' + re.escape(TMDB_HELPER_START) + r'.*?' + re.escape(TMDB_HELPER_END) + r'\r?\n?'
        t2 = re.sub(helper_pattern, '\n', t2, count=1)
    if TMDB_CALL_MARKER in t2:
        t2 = re.sub(
            r'return\s+_focus_random_sticky_choose\(item, artworks, self\._parent\)\s*' + re.escape(TMDB_CALL_MARKER),
            'return random.choice(artworks)',
            t2,
            count=1,
        )

    write_text(imgmon, t1)
    write_text(images, t2)
    clear_pycache(os.path.dirname(imgmon), ('imgmon', 'images'))
    delete_state('tmdb_focus_random_v11')
    return Result(name, 'Removed', 'Injected helper/call/refresh blocks removed; original refresh block restored only.')


# -----------------------------------------------------------------------------
# Patch 3: Skin Helper Widgets random Movies + TV Shows screensaver for AF3
# -----------------------------------------------------------------------------

def shw_targets() -> Tuple[str, str]:
    media = skinhelper_path('resources', 'lib', 'media.py')
    defaults = af3_path('1080i', 'Includes_Defaults.xml')
    return media, defaults


def status_shw() -> str:
    media, defaults = shw_targets()
    if not os.path.exists(media) or not os.path.exists(defaults):
        return 'Missing target'
    t1 = read_text(media)
    t2 = read_text(defaults)
    method_ok = SHW_METHOD_START in t1 or LEGACY_SHW_METHOD_START in t1 or re.search(r'def\s+randommoviestvshows\s*\(\s*self\s*\)\s*:', t1)
    xml_ok = SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2
    if method_ok and xml_ok:
        return 'Patched'
    return 'Not patched'


def extract_variable_block(text: str, variable_name: str) -> Optional[str]:
    pattern = r'(?ms)[ \t]*<variable\s+name="' + re.escape(variable_name) + r'">.*?</variable>'
    match = re.search(pattern, text)
    return match.group(0) if match else None


def legacy_shw_xml_backup(defaults: str) -> Optional[str]:
    backup = defaults + '.afm-random-movies-tvshows-xml.bak'
    if os.path.exists(backup):
        try:
            return extract_variable_block(read_text(backup), 'Defs_ScreensaverWidget')
        except Exception:
            return None
    return None


def patch_shw_media(text: str) -> str:
    nl = newline_of(text)
    has_any_method = (SHW_METHOD_START in text or LEGACY_SHW_METHOD_START in text or
                      re.search(r'def\s+randommoviestvshows\s*\(\s*self\s*\)\s*:', text))
    if not has_any_method:
        method = nl.join([
            f'    {SHW_METHOD_START}',
            '    def randommoviestvshows(self):',
            '        """get random movies and tvshows only - no episodes, no music, no pvr"""',
            '        all_items = self.movies.random()',
            '        all_items += self.tvshows.random()',
            '        return sorted(all_items, key=lambda k: random.random())[:self.options["limit"]]',
            f'    {SHW_METHOD_END}',
            '',
        ]) + nl
        anchor = '    def inprogress(self):'
        if anchor not in text:
            raise RuntimeError('Anchor not found in media.py: def inprogress(self)')
        text = text.replace(anchor, method + anchor, 1)

    if SHW_ENTRY_MARKER not in text and LEGACY_SHW_ENTRY_MARKER not in text:
        old = '            (self.addon.getLocalizedString(32059), "random&mediatype=media", "DefaultMovies.png"),'
        if old in text:
            new = old + nl + f'            ("Random Movies + TV Shows", "randommoviestvshows&mediatype=media", "DefaultMovies.png"),  {SHW_ENTRY_MARKER}'
            text = text.replace(old, new, 1)
    return text


def patch_shw_xml(text: str, limit: int) -> Tuple[str, str]:
    pattern = r'(?ms)([ \t]*)<variable\s+name="Defs_ScreensaverWidget">.*?</variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_Defaults.xml: variable Defs_ScreensaverWidget')
    original = match.group(0)
    nl = newline_of(text)
    indent = match.group(1)
    inner = indent + '    '
    path = f'plugin://script.skin.helper.widgets/?action=randommoviestvshows&amp;mediatype=media&amp;limit={limit}'
    new_block = nl.join([
        f'{indent}<variable name="Defs_ScreensaverWidget">',
        f'{inner}{SHW_XML_MARKER}',
        f'{inner}<value>{path}</value>',
        f'{indent}</variable>',
    ])
    text = text[:match.start()] + new_block + text[match.end():]
    return text, original


def patch_shw(limit: int = 100) -> Result:
    name = patch_title('shw_random_movies_tvshows', 'Movies + Shows Screensaver')
    media, defaults = shw_targets()
    t1 = read_text(media)
    t2 = read_text(defaults)
    if (SHW_METHOD_START in t1 or LEGACY_SHW_METHOD_START in t1) and (SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2):
        return Result(name, 'Skipped', 'Already patched.')

    snapshot('shw_random_movies_tvshows', [media, defaults])
    n1 = patch_shw_media(t1)
    if SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2:
        n2 = t2
        original_xml = None
    else:
        n2, original_xml = patch_shw_xml(t2, limit)
    save_state('shw_random_movies_tvshows', {'media': media, 'defaults': defaults, 'original_xml_block': original_xml})
    write_text(media, n1)
    write_text(defaults, n2)
    clear_pycache(os.path.dirname(media), ('media',))
    return Result(name, 'Patched', f'Screensaver path: random movies + TV shows only, limit={limit}.')


def remove_shw() -> Result:
    name = patch_title('shw_random_movies_tvshows', 'Movies + Shows Screensaver')
    media, defaults = shw_targets()
    t1 = read_text(media)
    t2 = read_text(defaults)
    has_markers = any(marker in t1 for marker in (SHW_METHOD_START, LEGACY_SHW_METHOD_START, SHW_ENTRY_MARKER, LEGACY_SHW_ENTRY_MARKER)) or any(marker in t2 for marker in (SHW_XML_MARKER, LEGACY_SHW_XML_MARKER))
    if not has_markers:
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('shw_random_movies_tvshows') if os.path.exists(state_file('shw_random_movies_tvshows')) else {}

    # Remove method block by marker. Supports current KPM markers and the older uploaded AFM PowerShell markers.
    for start, end in ((SHW_METHOD_START, SHW_METHOD_END), (LEGACY_SHW_METHOD_START, LEGACY_SHW_METHOD_END)):
        method_pattern = r'(?ms)\r?\n?    ' + re.escape(start) + r'.*?    ' + re.escape(end) + r'\r?\n?'
        t1 = re.sub(method_pattern, '\n', t1, count=1)

    # Remove optional listing line by marker.
    for marker in (SHW_ENTRY_MARKER, LEGACY_SHW_ENTRY_MARKER):
        entry_pattern = r'(?m)^.*' + re.escape(marker) + r'.*(\r?\n)?'
        t1 = re.sub(entry_pattern, '', t1, count=1)

    # Restore only the original XML variable block. If this was an older PS1 patch, read its .bak file
    # and restore only the Defs_ScreensaverWidget variable from that backup, not the whole XML file.
    if SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2:
        original = state.get('original_xml_block') or legacy_shw_xml_backup(defaults)
        if not original:
            raise RuntimeError('Cannot remove SHW XML patch: original Defs_ScreensaverWidget block state/legacy backup is missing.')
        marker_pat = re.escape(SHW_XML_MARKER) + '|' + re.escape(LEGACY_SHW_XML_MARKER)
        pattern = r'(?ms)[ \t]*<variable\s+name="Defs_ScreensaverWidget">(?:(?!</variable>).)*?(?:' + marker_pat + r').*?</variable>'
        t2 = re.sub(pattern, original, t2, count=1)

    write_text(media, t1)
    write_text(defaults, t2)
    clear_pycache(os.path.dirname(media), ('media',))
    delete_state('shw_random_movies_tvshows')
    return Result(name, 'Removed', 'Injected method/listing removed; original XML variable restored only.')



# -----------------------------------------------------------------------------
# Patch 4: AF3 x LRS Ratings UI integration
# -----------------------------------------------------------------------------
LRS_RATINGCALL = '                    <!-- Ratings -->\n                    <!-- LRS-AF3-META-CALL-START-1.3.87 -->\n                    <include content="LRS_Info_Meta_Ratings">\n                        <param name="visible">String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,episode) | $PARAM[override_movie] | $PARAM[override_tvshow] | Window.IsActive(videoosd)</param>\n                        <param name="colordiffuse">main_fg</param>\n                    </include>\n                    <!-- LRS-AF3-META-CALL-END-1.3.87 -->'
LRS_LRSINCLUDEDEF = '    <!-- LRS-AF3-INCLUDE-DEF-START -->\n    <!-- LRS-AF3-1.3.87: AF3-native spacing. IMDb icon_w=52, all other icons default 32. -->\n    <include name="LRS_Info_Meta_Ratings">\n        <param name="visible">true</param>\n        <param name="colordiffuse">main_fg</param>\n        <definition>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot1_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot1_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot1_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot1_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot1_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n                <param name="icon_w">52</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot1_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot1_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot1_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot1_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot1_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot2_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot2_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot2_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot2_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot2_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n                <param name="icon_w">52</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot2_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot2_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot2_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot2_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot2_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot3_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot3_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot3_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot3_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot3_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n                <param name="icon_w">52</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot3_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot3_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot3_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot3_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot3_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot4_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot4_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot4_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot4_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot4_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n                <param name="icon_w">52</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot4_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot4_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot4_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot4_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot4_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot5_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot5_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot5_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot5_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot5_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n                <param name="icon_w">52</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot5_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot5_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot5_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot5_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot5_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot6_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot6_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot6_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot6_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot6_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n                <param name="icon_w">52</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot6_IconFile)]</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.RatingSlot6_Label)]</param>\n                <param name="visible">[$PARAM[visible]] + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot6_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.RatingSlot6_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.RatingSlot6_Source),imdb)</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/oscars.png</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.Oscar_Wins),x,]</param>\n                <param name="visible">[$PARAM[visible]] + String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.Oscar_Wins))</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/emmys.png</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.Emmy_Wins),x,]</param>\n                <param name="visible">[$PARAM[visible]] + String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.Emmy_Wins))</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n            </include>\n            <include content="Info_Meta_Object">\n                <param name="icon">flags/$VAR[Color_Directory]/ratings/ends.png</param>\n                <param name="label">$INFO[Window(Home).Property(LibraryRatings.ListItem.Series_StatusLabel)]</param>\n                <param name="visible">[$PARAM[visible]] + String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.ListItem.Series_StatusLabel))</param>\n                <param name="colordiffuse">$PARAM[colordiffuse]</param>\n            </include>\n        </definition>\n    </include>\n    <!-- LRS-AF3-INCLUDE-DEF-END -->'
LRS_R4_OLDCLEAR = '                    <control type="image">\n                        <texture background="true">$INFO[Container(1297).ListItem.Art(clearlogo)]</texture>\n                        <aspectratio aligny="bottom">keep</aspectratio>\n                        <visible>!String.IsEmpty(Container(1297).ListItem.Art(clearlogo))</visible>\n                    </control>'
LRS_R4_NEWCROP = '                    <!-- AFM-CLEARLOGO-FINAL-LRS-START-1.3.91-r7 -->\n                    <control type="image">\n                        <texture background="true">$INFO[Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinal)]</texture>\n                        <aspectratio aligny="bottom">keep</aspectratio>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinal)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinalTitle),Container(1297).ListItem.Title)</visible>\n                    </control>\n                    <!-- AFM-CLEARLOGO-FINAL-LRS-END-1.3.91-r7 -->'
LRS_R4_OLDSTAR = '                <include content="Info_StarRating">\n                    <param name="textcolor">yellow_star</param>\n                    <param name="rating">Container(1297).ListItem.Rating</param>\n                    <param name="size">64</param>\n                    <height>80</height>\n                    <align>center</align>\n                    <centertop>320</centertop>\n                    <itemgap>-16</itemgap>\n                    <visible>!String.IsEmpty(Container(1297).ListItem.Plot)</visible>\n                </include>'
LRS_R4_NEWROW = '                <!-- LRS-AF3-SCREENSAVER-AF3-ROW-START-1.3.87-r4-MERGED -->\n                <control type="grouplist">\n                    <orientation>horizontal</orientation>\n                    <align>center</align>\n                    <height>54</height>\n                    <centertop>332</centertop>\n                    <itemgap>12</itemgap>\n                    <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.HasData),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinalTitle),Container(1297).ListItem.Title)</visible>\n                    <!-- LRS RatingSlot1 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile))</visible>\n                    </control>\n                    <!-- LRS RatingSlot2 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile))</visible>\n                    </control>\n                    <!-- LRS RatingSlot3 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile))</visible>\n                    </control>\n                    <!-- LRS RatingSlot4 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile))</visible>\n                    </control>\n                    <!-- LRS RatingSlot5 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile))</visible>\n                    </control>\n                    <!-- LRS RatingSlot6 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile))</visible>\n                    </control>\n                    <!-- LRS Oscar -->\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/oscars.png</texture>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins),x,]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible>\n                    </control>\n                    <!-- LRS Emmy -->\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/emmys.png</texture>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins),x,]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible>\n                    </control>\n                    <!-- LRS TV status -->\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/ends.png</texture>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible>\n                    </control>\n                </control>\n                <!-- LRS-AF3-SCREENSAVER-AF3-ROW-END-1.3.87-r4-MERGED -->'
LRS_R4_OLDTITLEVISIBLE = '<visible>String.IsEmpty(Container(1297).ListItem.Art(clearlogo))</visible>'
LRS_R4_NEWTITLEVISIBLE = '<visible>String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinalMode),title) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinalTitle),Container(1297).ListItem.Title)</visible>'
LRS_R4_OLDPLOTBOX = '            <control type="textbox">\n                <font>font_main_plot</font>\n                <textcolor>main_fg_70</textcolor>\n                <label>$INFO[Container(1297).ListItem.Plot]</label>\n                <bottom>view_pad</bottom>\n                <height>120</height>\n                <align>center</align>\n            </control>'
LRS_R4_NEWPLOTBOX = '            <control type="textbox">\n                <font>font_main_plot</font>\n                <textcolor>main_fg_70</textcolor>\n                <label>$INFO[Container(1297).ListItem.Plot]</label>\n                <bottom>view_pad</bottom>\n                <height>120</height>\n                <align>center</align>\n                <autoscroll>false</autoscroll>\n            </control>'

LRS_INFO_DEF_START = '<!-- LRS-AF3-INCLUDE-DEF-START -->'
LRS_INFO_DEF_END = '<!-- LRS-AF3-INCLUDE-DEF-END -->'
LRS_META_CALL_START = '<!-- LRS-AF3-META-CALL-START'
LRS_META_CALL_END = '<!-- LRS-AF3-META-CALL-END'
LRS_HUB_MARKER = '<!-- LRS-AF3-ACTIVE-BRIDGE-1.3.87 -->'
LRS_SS_ROW_START_RE = r'<!-- LRS-AF3-SCREENSAVER-AF3-ROW-START.*?-->'
LRS_SS_ROW_END_RE = r'<!-- LRS-AF3-SCREENSAVER-AF3-ROW-END.*?-->'
LRS_CLEAR_START_RE = r'<!-- AFM-(?:CROPV2-CLEARLOGO|CLEARLOGO-FINAL)-LRS-START.*?-->'
LRS_CLEAR_END_RE = r'<!-- AFM-(?:CROPV2-CLEARLOGO|CLEARLOGO-FINAL)-LRS-END.*?-->'
LRS_LIST_VAR = '$VAR[LRS_ListItem_Oscar_Icon_Texture]'
LRS_SCREEN_VAR = '$VAR[LRS_Screensaver_Oscar_Icon_Texture]'
LRS_OSCAR_VAR_START = '<!-- LRS-OSCAR-BP-VARS-START -->'
LRS_OSCAR_VAR_END = '<!-- LRS-OSCAR-BP-VARS-END -->'
LRS_OLD_OSCAR_PATH = 'flags/$VAR[Color_Directory]/ratings/oscars.png'
LRS_BP_PATH = 'flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars_bp.png'
LRS_OSCAR_PATH = 'flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars.png'
LRS_BAD_LIST_DYNAMIC = 'flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.ListItem.Oscar_Icon)]'
LRS_BAD_SCREEN_DYNAMIC = 'flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property(LibraryRatings.Screensaver.Oscar_Icon)]'
LRS_OSCAR_VAR_BLOCK = '<!-- LRS-OSCAR-BP-VARS-START -->\n    <variable name="LRS_ListItem_Oscar_Icon_Texture">\n        <value condition="String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.Oscar_BestPicture),true)">flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars_bp.png</value>\n        <value condition="String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.OscarBestPicture),true)">flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars_bp.png</value>\n        <value condition="String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.Oscar_BestPicture),1)">flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars_bp.png</value>\n        <value condition="String.IsEqual(Window(Home).Property(LibraryRatings.ListItem.OscarBestPicture),1)">flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars_bp.png</value>\n        <value>flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars.png</value>\n    </variable>\n    <variable name="LRS_Screensaver_Oscar_Icon_Texture">\n        <value condition="String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.Oscar_BestPicture),true)">flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars_bp.png</value>\n        <value condition="String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.OscarBestPicture),true)">flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars_bp.png</value>\n        <value condition="String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.Oscar_BestPicture),1)">flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars_bp.png</value>\n        <value condition="String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.OscarBestPicture),1)">flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars_bp.png</value>\n        <value>flags/$VAR[Color_Directory]/ratings/LRS_AF3/oscars.png</value>\n    </variable>\n<!-- LRS-OSCAR-BP-VARS-END -->'
R7_PROGRESS_ACTIVE = 'Window.IsActive(extendedprogressdialog) | Window.IsVisible(extendedprogressdialog) | Window.IsActive(progressdialog) | Window.IsVisible(progressdialog) | Window.IsActive(dialogprogress) | Window.IsVisible(dialogprogress)'
R7_PROGRESS_INACTIVE = '!Window.IsActive(extendedprogressdialog) + !Window.IsVisible(extendedprogressdialog) + !Window.IsActive(progressdialog) + !Window.IsVisible(progressdialog) + !Window.IsActive(dialogprogress) + !Window.IsVisible(dialogprogress)'
R7_LEFT_VISIBLE = f'<visible>{R7_PROGRESS_ACTIVE} | !Integer.IsOdd(ListItem.CurrentItem)</visible>'
R7_RIGHT_VISIBLE = f'<visible>{R7_PROGRESS_INACTIVE} + Integer.IsOdd(ListItem.CurrentItem)</visible>'
R7_LEFT_BASE = '<visible>!Integer.IsOdd(ListItem.CurrentItem)</visible>'
R7_RIGHT_BASE = '<visible>Integer.IsOdd(ListItem.CurrentItem)</visible>'
R7_R5_MISMATCH_TITLE = '<visible>String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinal)) | !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinalTitle),Container(1297).ListItem.Title)</visible>'
R7_STRICT_TITLE = '<visible>String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinalMode),title) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinalTitle),Container(1297).ListItem.Title)</visible>'
R7_PLAIN_RATING = '<visible>String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.HasData),true)</visible>'
R7_OLD_TITLE_RATING = '<visible>String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.HasData),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.Title),Container(1297).ListItem.Title)</visible>'
R7_GUARD_RATING = '<visible>String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.HasData),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinalTitle),Container(1297).ListItem.Title)</visible>'


def lrs_targets() -> Tuple[str, str, str]:
    return (
        af3_path('1080i', 'Includes_Info.xml'),
        af3_path('1080i', 'Includes_Hubs.xml'),
        af3_path('1080i', 'screensaver-arctic-mirage.xml'),
    )


def _to_lf(value: str) -> str:
    return value.replace('\r\n', '\n').replace('\r', '\n')


def _norm_template(value: str) -> str:
    return _to_lf(value).strip('\n')


def _replace_regex_store(text: str, pattern: str, replacement: str, state: Dict[str, str], key: str, count: int = 1) -> str:
    match = re.search(pattern, text, flags=re.S | re.M)
    if not match:
        return text
    state[key] = match.group(0)
    return text[:match.start()] + replacement + text[match.end():] if count == 1 else re.sub(pattern, replacement, text, count=count, flags=re.S | re.M)


def _replace_in_marked_block(text: str, start: str, end: str, pairs: List[Tuple[str, str]]) -> str:
    start_i = text.find(start)
    if start_i < 0:
        return text
    end_i = text.find(end, start_i)
    if end_i < 0:
        return text
    end2 = end_i + len(end)
    block = text[start_i:end2]
    new_block = block
    for old, new in pairs:
        new_block = new_block.replace(old, new)
    return text[:start_i] + new_block + text[end2:]


def _ensure_lrs_icon_folders() -> None:
    skin_root = os.path.dirname(af3_path('1080i'))
    flags_root = os.path.join(skin_root, 'media', 'flags')
    if not os.path.isdir(flags_root):
        return
    for color in os.listdir(flags_root):
        ratings = os.path.join(flags_root, color, 'ratings')
        if not os.path.isdir(ratings):
            continue
        lrs_dir = os.path.join(ratings, 'LRS_AF3')
        os.makedirs(lrs_dir, exist_ok=True)
        for name in ('oscars.png', 'oscars_bp.png'):
            src = os.path.join(ratings, name)
            dst = os.path.join(lrs_dir, name)
            if os.path.exists(src) and not os.path.exists(dst):
                try:
                    shutil.copy2(src, dst)
                except Exception:
                    pass


def _normalize_lrs_icon_paths(text: str) -> str:
    return (text
            .replace('flags/$VAR[Color_Directory]/ratings/oscars_bp.png', LRS_BP_PATH)
            .replace('flags/$VAR[Color_Directory]/ratings/oscars.png', LRS_OSCAR_PATH)
            .replace('ratings/LRS_AF3/LRS_AF3/', 'ratings/LRS_AF3/'))


def status_lrs_af3() -> str:
    info, hubs, ss = lrs_targets()
    missing = [os.path.basename(p) for p in (info, hubs, ss) if not os.path.exists(p)]
    if missing:
        return 'Missing target: ' + ', '.join(missing)
    ti = read_text(info)
    th = read_text(hubs)
    ts = read_text(ss)
    checks = [
        LRS_INFO_DEF_START in ti and 'LibraryRatings.ListItem' in ti,
        'LRS-AF3-META-CALL-START' in ti,
        LRS_OSCAR_VAR_START in ti and 'ratings/LRS_AF3/oscars_bp.png' in ti,
        'LRS-AF3-ACTIVE-BRIDGE' in th and 'LRS.Active.ContainerID' in th,
        'LibraryRatings.Screensaver' in ts and 'LRS-AF3-SCREENSAVER-AF3-ROW-START' in ts,
        'ClearLogoFinal' in ts and 'AFM-CLEARLOGO-FINAL-LRS' in ts,
    ]
    if all(checks):
        return 'Patched'
    if any(checks):
        return 'Partial'
    return 'Not patched'


def _patch_lrs_includes_info(text: str, state: Dict[str, Any]) -> str:
    # Remove previous KPM/legacy include def, then inject the current one.
    text = re.sub(r'(?ms)\s*<!-- LRS-AF3-INCLUDE-DEF-START -->.*?<!-- LRS-AF3-INCLUDE-DEF-END -->\s*', '\n', text)
    rating_pattern = r'(?ms)^\s*<!-- Ratings -->.*?(?=^\s*<!-- Total Episodes)'
    match = re.search(rating_pattern, text)
    if match:
        state['original_rating_block'] = match.group(0)
        text = text[:match.start()] + LRS_RATINGCALL + text[match.end():]
    else:
        anchor = '                    <!-- Total Episodes'
        if anchor not in text:
            raise RuntimeError('Anchor not found in Includes_Info.xml: Ratings/Total Episodes')
        text = text.replace(anchor, LRS_RATINGCALL + anchor, 1)
    combined = r'(?ms)^\s*<!-- Status -->\s*\n?\s*<include content="Info_Meta_Object" condition="\$EXP\[Exp_TMDbHelper_IsData\]">.*?</include>\s*\n?\s*<!-- Awards -->\s*\n?\s*<include content="Info_Meta_Object" condition="\$EXP\[Exp_TMDbHelper_IsData\][^"]*">.*?</include>\s*'
    text = _replace_regex_store(text, combined, '                    <!-- LRS-AF3-NATIVE-STATUS-AWARDS-DISABLED-1.3.87 -->', state, 'native_status_awards_block')
    status_pat = r'(?ms)^\s*<!-- Status -->\s*\n?\s*<include content="Info_Meta_Object" condition="\$EXP\[Exp_TMDbHelper_IsData\]">.*?</include>\s*'
    text = _replace_regex_store(text, status_pat, '                    <!-- LRS-AF3-NATIVE-STATUS-DISABLED-1.3.87 -->', state, 'native_status_block')
    awards_pat = r'(?ms)^\s*<!-- Awards -->\s*\n?\s*<include content="Info_Meta_Object" condition="\$EXP\[Exp_TMDbHelper_IsData\][^"]*">.*?</include>\s*'
    text = _replace_regex_store(text, awards_pat, '                    <!-- LRS-AF3-NATIVE-AWARDS-DISABLED-1.3.87 -->', state, 'native_awards_block')
    if LRS_OSCAR_VAR_START in text:
        text = re.sub(r'(?ms)\s*' + re.escape(LRS_OSCAR_VAR_START) + r'.*?' + re.escape(LRS_OSCAR_VAR_END) + r'\s*', '\n', text)
    if '<includes>' in text:
        text = text.replace('<includes>', '<includes>\n' + LRS_OSCAR_VAR_BLOCK, 1)
    elif '</includes>' in text:
        text = text.replace('</includes>', LRS_OSCAR_VAR_BLOCK + '\n</includes>', 1)
    else:
        raise RuntimeError('Includes_Info.xml has no <includes> or </includes> anchor')
    text = text.replace('</includes>', LRS_LRSINCLUDEDEF + '\n</includes>', 1)
    # Oscar BP variable path inside LRS include block only, not inside the variable block.
    text = _replace_in_marked_block(text, LRS_INFO_DEF_START, LRS_INFO_DEF_END, [
        (LRS_BAD_LIST_DYNAMIC, LRS_LIST_VAR),
        (LRS_OLD_OSCAR_PATH, LRS_LIST_VAR),
        (LRS_OSCAR_PATH, LRS_LIST_VAR),
    ])
    return _normalize_lrs_icon_paths(text)


def _remove_lrs_includes_info(text: str, state: Dict[str, Any]) -> str:
    text = re.sub(r'(?ms)\s*<!-- LRS-AF3-INCLUDE-DEF-START -->.*?<!-- LRS-AF3-INCLUDE-DEF-END -->\s*', '\n', text)
    text = re.sub(r'(?ms)\s*' + re.escape(LRS_OSCAR_VAR_START) + r'.*?' + re.escape(LRS_OSCAR_VAR_END) + r'\s*', '\n', text)
    original_rating = state.get('includes_info', {}).get('original_rating_block') if isinstance(state.get('includes_info'), dict) else None
    if original_rating:
        pattern = r'(?ms)^\s*<!-- Ratings -->\s*<!-- LRS-AF3-META-CALL-START[^>]*-->.*?<!-- LRS-AF3-META-CALL-END[^>]*-->\s*'
        text = re.sub(pattern, lambda _m: original_rating, text, count=1)
    else:
        text = re.sub(r'(?ms)^\s*<!-- Ratings -->\s*<!-- LRS-AF3-META-CALL-START[^>]*-->.*?<!-- LRS-AF3-META-CALL-END[^>]*-->\s*', '                    <!-- Ratings -->\n', text, count=1)
    info_state = state.get('includes_info', {}) if isinstance(state.get('includes_info'), dict) else {}
    for marker, key in [
        ('                    <!-- LRS-AF3-NATIVE-STATUS-AWARDS-DISABLED-1.3.87 -->', 'native_status_awards_block'),
        ('                    <!-- LRS-AF3-NATIVE-STATUS-DISABLED-1.3.87 -->', 'native_status_block'),
        ('                    <!-- LRS-AF3-NATIVE-AWARDS-DISABLED-1.3.87 -->', 'native_awards_block'),
    ]:
        if key in info_state and marker in text:
            text = text.replace(marker, info_state[key], 1)
    text = text.replace(LRS_LIST_VAR, LRS_OLD_OSCAR_PATH)
    return text


def _patch_lrs_hubs(text: str) -> str:
    lines = re.split(r'\r?\n', text)
    out: List[str] = []
    anchors = 0
    for line in lines:
        if 'LRS-AF3-ACTIVE-BRIDGE' in line or 'LRS.Active.ContainerID' in line:
            continue
        out.append(line)
        if re.search(r'<on(focus|load)', line) and 'SetProperty(TMDbHelper.WidgetContainer' in line:
            anchors += 1
            indent = re.match(r'^\s*', line).group(0)
            new_line = line.replace('TMDbHelper.WidgetContainer', 'LRS.Active.ContainerID').replace('Property(TMDbHelper.WidgetContainer)', 'Property(LRS.Active.ContainerID)')
            out.append(indent + LRS_HUB_MARKER)
            out.append(new_line)
    new = '\n'.join(out)
    needle = '<ondown>SetFocus($INFO[Container(601).ListItem.Property(widget_id)])</ondown>'
    selector = needle + '\n                    ' + LRS_HUB_MARKER + '\n                    <onfocus condition="!String.IsEmpty(Container(601).ListItem.Property(widget_id))">SetProperty(LRS.Active.ContainerID,$INFO[Container(601).ListItem.Property(widget_id)])</onfocus>'
    if not re.search(r'SetProperty\(LRS\.Active\.ContainerID,\$INFO\[Container\(601\)', new):
        if needle in new:
            new = new.replace(needle, selector, 1)
        elif re.search(r'Container\(601\)\.ListItem\.Property\(widget_id\)', new):
            new = re.sub(r'(?m)^(\s*<on[^>]+Container\(601\)\.ListItem\.Property\(widget_id\).*?</on[^>]+>)', r'\1\n                    ' + LRS_HUB_MARKER + '\n                    <onfocus condition="!String.IsEmpty(Container(601).ListItem.Property(widget_id))">SetProperty(LRS.Active.ContainerID,$INFO[Container(601).ListItem.Property(widget_id)])</onfocus>', new, count=1)
    return new


def _remove_lrs_hubs(text: str) -> str:
    lines = re.split(r'\r?\n', text)
    out = [line for line in lines if 'LRS-AF3-ACTIVE-BRIDGE' not in line and 'LRS.Active.ContainerID' not in line]
    return '\n'.join(out)


def _normalize_lrs_screensaver(text: str) -> str:
    t = _to_lf(text)
    old_clear = _norm_template(LRS_R4_OLDCLEAR)
    t = re.sub(r'(?s)\s*' + LRS_CLEAR_START_RE + r'.*?' + LRS_CLEAR_END_RE + r'\s*', '\n' + old_clear + '\n', t)
    t = re.sub(r'(?s)\s*' + LRS_SS_ROW_START_RE + r'.*?' + LRS_SS_ROW_END_RE + r'\s*', '\n', t)
    t = re.sub(r'(?s)\s*<!-- LRS-AF3-SCREENSAVER-INLINE-START.*?<!-- LRS-AF3-SCREENSAVER-INLINE-END.*?-->\s*', '\n', t)
    t = t.replace(_norm_template(LRS_R4_NEWTITLEVISIBLE), _norm_template(LRS_R4_OLDTITLEVISIBLE))
    t = t.replace('<visible>String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.CropV2Image)) + String.IsEmpty(Container(1297).ListItem.Art(clearlogo))</visible>', _norm_template(LRS_R4_OLDTITLEVISIBLE))
    return t


def _apply_lrs_progress_left(text: str) -> str:
    t = text.replace(R7_R5_MISMATCH_TITLE, R7_STRICT_TITLE)
    t = t.replace(R7_PLAIN_RATING, R7_GUARD_RATING)
    t = t.replace(R7_OLD_TITLE_RATING, R7_GUARD_RATING)
    t = t.replace(R7_LEFT_VISIBLE, R7_LEFT_BASE)
    t = t.replace(R7_RIGHT_VISIBLE, R7_RIGHT_BASE)
    t = t.replace(R7_LEFT_BASE, R7_LEFT_VISIBLE)
    t = t.replace(R7_RIGHT_BASE, R7_RIGHT_VISIBLE)
    return t


def _remove_lrs_progress_left(text: str) -> str:
    return (text
            .replace(R7_LEFT_VISIBLE, R7_LEFT_BASE)
            .replace(R7_RIGHT_VISIBLE, R7_RIGHT_BASE)
            .replace(R7_STRICT_TITLE, R7_R5_MISMATCH_TITLE)
            .replace(R7_GUARD_RATING, R7_PLAIN_RATING))


def _patch_lrs_screensaver(text: str) -> str:
    # If a stable AF3 x LRS screensaver is already installed, do not tear it down.
    # Only normalize final paths / BP block / progress guards.
    if 'LRS-AF3-SCREENSAVER-AF3-ROW-START' in text and 'AFM-CLEARLOGO-FINAL-LRS' in text:
        t = _to_lf(text)
        t = _apply_lrs_progress_left(t)
        t = _normalize_lrs_icon_paths(t)
        t = _patch_screensaver_oscar_bp_blocks(t)
        return t.replace('\n', '\r\n')

    old_clear = _norm_template(LRS_R4_OLDCLEAR)
    new_crop = _norm_template(LRS_R4_NEWCROP)
    old_star = _norm_template(LRS_R4_OLDSTAR)
    new_row = _norm_template(LRS_R4_NEWROW)
    old_title = _norm_template(LRS_R4_OLDTITLEVISIBLE)
    new_title = _norm_template(LRS_R4_NEWTITLEVISIBLE)
    old_plot = _norm_template(LRS_R4_OLDPLOTBOX)
    new_plot = _norm_template(LRS_R4_NEWPLOTBOX)
    t = _normalize_lrs_screensaver(text)
    clear_count = t.count(old_clear)
    odd_count = len(re.findall(r'Integer\.IsOdd\(ListItem\.CurrentItem\)', t))
    expected = 2 if odd_count >= 4 else 1
    if clear_count != expected:
        raise RuntimeError(f'Screensaver clearlogo anchor mismatch: expected {expected}, found {clear_count}. Restore original AF3 screensaver XML first.')
    star_count = t.count(old_star)
    include_rows = len(re.findall(r'(?s)<control type="grouplist"[^>]*>\s*<orientation>horizontal</orientation>.*?<include content="LRS_Info_Meta_Ratings">.*?</include>\s*</control>', t))
    existing_rows = len(re.findall(r'LRS-AF3-SCREENSAVER-AF3-ROW-START', t))
    if star_count > 0 and star_count != expected:
        raise RuntimeError(f'Screensaver Info_StarRating anchor mismatch: expected {expected} or 0, found {star_count}.')
    if star_count == 0 and existing_rows < expected and include_rows < expected:
        raise RuntimeError('Screensaver rating row anchor not found. Restore original AF3 screensaver XML first.')
    t = t.replace(old_clear, new_crop)
    if star_count > 0:
        t = t.replace(old_star, new_row)
    if include_rows > 0:
        t = re.sub(r'(?s)\s*<control type="grouplist"[^>]*>\s*<orientation>horizontal</orientation>.*?<include content="LRS_Info_Meta_Ratings">.*?</include>\s*</control>\s*', '\n' + new_row + '\n', t)
    t = t.replace(old_title, new_title)
    if old_plot in t:
        t = t.replace(old_plot, new_plot)
    t = _apply_lrs_progress_left(t)
    t = _normalize_lrs_icon_paths(t)
    t = _patch_screensaver_oscar_bp_blocks(t)
    return t.replace('\n', '\r\n')


def _patch_screensaver_oscar_bp_blocks(text: str) -> str:
    if 'LRS-OSCAR-BP-SCREENSAVER-START' in text:
        return text
    bp_cond = 'String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.Oscar_BestPicture),true) | String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.OscarBestPicture),true) | String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.Oscar_BestPicture),1) | String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.OscarBestPicture),1)'
    def repl(match: re.Match) -> str:
        visible = match.group('vis').strip()
        return (
            '<!-- LRS-OSCAR-BP-SCREENSAVER-START -->\n'
            '<!-- LRS Oscar Best Picture -->\n'
            '<control type="image">\n'
            '    <width>32</width>\n    <height>32</height>\n    <aspectratio>keep</aspectratio>\n    <centertop>50%</centertop>\n'
            f'    <texture colordiffuse="main_fg_90">{LRS_BP_PATH}</texture>\n'
            f'    <visible>{visible} + [{bp_cond}]</visible>\n'
            '</control>\n'
            '<!-- LRS Oscar -->\n'
            '<control type="image">\n'
            '    <width>32</width>\n    <height>32</height>\n    <aspectratio>keep</aspectratio>\n    <centertop>50%</centertop>\n'
            f'    <texture colordiffuse="main_fg_90">{LRS_OSCAR_PATH}</texture>\n'
            f'    <visible>{visible} + ![{bp_cond}]</visible>\n'
            '</control>\n'
            '<!-- LRS-OSCAR-BP-SCREENSAVER-END -->'
        )
    pattern = r'(?s)<!--\s*LRS Oscar\s*-->\s*<control type="image">\s*<width>32</width>\s*<height>32</height>\s*<aspectratio>keep</aspectratio>\s*<centertop>50%</centertop>\s*<texture colordiffuse="main_fg_90">flags/\$VAR\[Color_Directory\]/ratings(?:/LRS_AF3)?/oscars\.png</texture>\s*<visible>(?P<vis>.*?)</visible>\s*</control>'
    return re.sub(pattern, repl, text)


def _remove_screensaver_oscar_bp_blocks(text: str) -> str:
    default_visible = 'String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))'
    replacement = (
        '<!-- LRS Oscar -->\n'
        '<control type="image">\n'
        '    <width>32</width>\n    <height>32</height>\n    <aspectratio>keep</aspectratio>\n    <centertop>50%</centertop>\n'
        f'    <texture colordiffuse="main_fg_90">{LRS_OSCAR_PATH}</texture>\n'
        f'    <visible>{default_visible}</visible>\n'
        '</control>'
    )
    return re.sub(r'(?s)<!-- LRS-OSCAR-BP-SCREENSAVER-START -->.*?<!-- LRS-OSCAR-BP-SCREENSAVER-END -->', replacement, text)


def _remove_lrs_screensaver(text: str) -> str:
    t = _to_lf(text)
    old_clear = _norm_template(LRS_R4_OLDCLEAR)
    old_star = _norm_template(LRS_R4_OLDSTAR)
    t = _remove_screensaver_oscar_bp_blocks(t)
    t = re.sub(r'(?s)\s*' + LRS_CLEAR_START_RE + r'.*?' + LRS_CLEAR_END_RE + r'\s*', '\n' + old_clear + '\n', t)
    t = re.sub(r'(?s)\s*' + LRS_SS_ROW_START_RE + r'.*?' + LRS_SS_ROW_END_RE + r'\s*', '\n' + old_star + '\n', t)
    t = re.sub(r'(?s)\s*<!-- LRS-AF3-SCREENSAVER-INLINE-START.*?<!-- LRS-AF3-SCREENSAVER-INLINE-END.*?-->\s*', '\n', t)
    t = t.replace(_norm_template(LRS_R4_NEWTITLEVISIBLE), _norm_template(LRS_R4_OLDTITLEVISIBLE))
    t = t.replace(_norm_template(LRS_R4_NEWPLOTBOX), _norm_template(LRS_R4_OLDPLOTBOX))
    t = _remove_lrs_progress_left(t)
    t = t.replace(LRS_SCREEN_VAR, LRS_OLD_OSCAR_PATH).replace(LRS_BAD_SCREEN_DYNAMIC, LRS_OLD_OSCAR_PATH)
    return t.replace('\n', '\r\n')


def patch_lrs_af3() -> Result:
    name = patch_title('af3_lrs_ratings_ui', 'AF3 x LRS Ratings UI')
    info, hubs, ss = lrs_targets()
    if status_lrs_af3() == 'Patched':
        return Result(name, 'Skipped', 'Already patched.')
    for target in (info, hubs, ss):
        if not os.path.exists(target):
            raise FileNotFoundError(f'Missing target: {target}')
    snapshot('af3_lrs_ratings_ui', [info, hubs, ss])
    state: Dict[str, Any] = {}
    ti = read_text(info)
    th = read_text(hubs)
    ts = read_text(ss)
    state['includes_info'] = {}
    ni = _patch_lrs_includes_info(ti, state['includes_info'])
    nh = _patch_lrs_hubs(th)
    ns = _patch_lrs_screensaver(ts)
    save_state('af3_lrs_ratings_ui', {'targets': {'info': info, 'hubs': hubs, 'screensaver': ss}, **state})
    _ensure_lrs_icon_folders()
    write_text(info, ni)
    write_text(hubs, nh)
    write_text(ss, ns)
    return Result(name, 'Patched', 'AF3 x LRS rating slots, hub bridge, screensaver row, final clearlogo, and Oscar BP icon path were injected.')


def remove_lrs_af3() -> Result:
    name = patch_title('af3_lrs_ratings_ui', 'AF3 x LRS Ratings UI')
    info, hubs, ss = lrs_targets()
    if status_lrs_af3() == 'Not patched':
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('af3_lrs_ratings_ui') if os.path.exists(state_file('af3_lrs_ratings_ui')) else {}
    if os.path.exists(info):
        write_text(info, _remove_lrs_includes_info(read_text(info), state))
    if os.path.exists(hubs):
        write_text(hubs, _remove_lrs_hubs(read_text(hubs)))
    if os.path.exists(ss):
        write_text(ss, _remove_lrs_screensaver(read_text(ss)))
    delete_state('af3_lrs_ratings_ui')
    return Result(name, 'Removed', 'AF3 x LRS injected blocks removed. Original stored rating/status blocks are restored when this add-on created them.')




# -----------------------------------------------------------------------------
# Patch 5: VideoFullScreen pause rating row beside Paused
# -----------------------------------------------------------------------------

def vfs_pause_target() -> str:
    return af3_path('1080i', 'VideoFullScreen.xml')


def status_vfs_pause_ratings() -> str:
    target = vfs_pause_target()
    if not os.path.exists(target):
        return 'Missing target'
    text = read_text(target)
    return 'Patched' if VFS_PAUSE_RATINGS_START in text and VFS_PAUSE_RATINGS_END in text else 'Not patched'


def _vfs_lrs_slot_include(slot: int, imdb_variant: bool, nl: str) -> str:
    """Return one LRS RatingSlot include for VideoFullScreen.

    LRS v1.5.4 publishes these exact properties via core.publish_af3_properties():
      Window(Home).Property(LibraryRatings.Player.RatingSlotN_Source)
      Window(Home).Property(LibraryRatings.Player.RatingSlotN_IconFile)
      Window(Home).Property(LibraryRatings.Player.RatingSlotN_Label)

    Only LibraryRatings.* properties are used here.
    """
    base = 'LibraryRatings.Player.RatingSlot{0}'.format(slot)
    visible = (
        '!String.IsEmpty(Window(Home).Property({0}_Label)) + '
        '!String.IsEmpty(Window(Home).Property({0}_IconFile)) + '
    ).format(base)
    if imdb_variant:
        visible += 'String.IsEqual(Window(Home).Property({0}_Source),imdb)'.format(base)
        extra = [
            '                <param name="icon_w">52</param>',
        ]
    else:
        visible += '!String.IsEqual(Window(Home).Property({0}_Source),imdb)'.format(base)
        extra = []
    lines = [
        '            <include content="Info_Meta_Object">',
        '                <param name="icon">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property({0}_IconFile)]</param>'.format(base),
        '                <param name="label">$INFO[Window(Home).Property({0}_Label)]</param>'.format(base),
        '                <param name="visible">{0}</param>'.format(visible),
        '                <param name="colordiffuse">panel_fg</param>',
    ]
    lines.extend(extra)
    lines.extend([
        '                <param name="font">font_main</param>',
        '            </include>',
    ])
    return nl.join(lines)


def _vfs_pause_ratings_block(nl: str) -> str:
    # This window is already VideoFullScreen.xml. Do not add Window.IsActive(...)
    # guards because filename/window-name checks are skin-version dependent and
    # can hide the row even when the block is loaded. Keep it to pause + not seeking.
    visible = 'Player.Paused + !Player.Seeking'
    lines = [
        '        ' + VFS_PAUSE_RATINGS_START,
        '        <control type="group">',
        '            <visible>' + visible + '</visible>',
        '            <left>165</left>',
        '            <top>748</top>',
        '            <height>44</height>',
        '            <width>1120</width>',
        '            <control type="grouplist">',
        '                <orientation>horizontal</orientation>',
        '                <height>40</height>',
        '                <width>1120</width>',
        '                <itemgap>10</itemgap>',
        '                <align>left</align>',
    ]
    for slot in range(1, 7):
        lines.append(_vfs_lrs_slot_include(slot, True, nl))
        lines.append(_vfs_lrs_slot_include(slot, False, nl))
    lines.extend([
        '            </control>',
        '        </control>',
        '        ' + VFS_PAUSE_RATINGS_END,
    ])
    return nl.join(lines)


def patch_vfs_pause_ratings() -> Result:
    name = patch_title('vfs_pause_ratings', 'Fullscreen Pause Ratings')
    target = vfs_pause_target()
    text = read_text(target)
    if '<controls>' not in text:
        raise RuntimeError('Anchor not found in VideoFullScreen.xml: <controls>')
    nl = newline_of(text)
    block = _vfs_pause_ratings_block(nl)
    snapshot('vfs_pause_ratings', [target])
    save_state('vfs_pause_ratings', {'target': target, 'source': 'LibraryRatings.Player.RatingSlot1-6'})
    if VFS_PAUSE_RATINGS_START in text and VFS_PAUSE_RATINGS_END in text:
        pattern = r'(?ms)\s*' + re.escape(VFS_PAUSE_RATINGS_START) + r'.*?' + re.escape(VFS_PAUSE_RATINGS_END)
        text = re.sub(pattern, nl + block, text, count=1)
        write_text(target, text)
        return Result(name, 'Updated', 'Replaced old pause row with LRS-only LibraryRatings.Player.RatingSlot1-6 row.')
    text = text.replace('<controls>', '<controls>' + nl + block, 1)
    write_text(target, text)
    return Result(name, 'Patched', 'Injected LRS-only LibraryRatings.Player.RatingSlot1-6 row beside the Paused header area.')


def remove_vfs_pause_ratings() -> Result:
    name = patch_title('vfs_pause_ratings', 'Fullscreen Pause Ratings')
    target = vfs_pause_target()
    text = read_text(target)
    if VFS_PAUSE_RATINGS_START not in text:
        return Result(name, 'Skipped', 'Patch marker not found.')
    pattern = r'(?ms)\s*' + re.escape(VFS_PAUSE_RATINGS_START) + r'.*?' + re.escape(VFS_PAUSE_RATINGS_END)
    text = re.sub(pattern, '', text, count=1)
    write_text(target, text)
    delete_state('vfs_pause_ratings')
    return Result(name, 'Removed', 'Injected VideoFullScreen pause rating row removed only.')


# -----------------------------------------------------------------------------
# Tool: clear Kodi add-on icon thumbnail cache
# -----------------------------------------------------------------------------

ADDON_ICON_EXTENSIONS = ('.png', '.jpg', '.jpeg', '.webp')


def profile_database_path() -> str:
    return norm(translate('special://profile/Database'))


def thumbnails_path() -> str:
    return norm(translate('special://profile/Thumbnails'))


def latest_textures_db() -> str:
    db_dir = profile_database_path()
    if not os.path.isdir(db_dir):
        return ''
    candidates = []
    for name in os.listdir(db_dir):
        match = re.match(r'^Textures(\d+)\.db$', name, re.I)
        if match:
            candidates.append((int(match.group(1)), os.path.join(db_dir, name)))
    if not candidates:
        return ''
    candidates.sort(reverse=True)
    return candidates[0][1]


def _normalize_texture_url(value: str) -> str:
    text = unquote(str(value or '')).replace('\\', '/').lower()
    # image:// URLs often add a trailing slash after the encoded source path.
    while text.endswith('/'):
        text = text[:-1]
    return text


def _texture_table_columns(conn: sqlite3.Connection, table: str) -> List[str]:
    try:
        return [str(row[1]) for row in conn.execute(f'PRAGMA table_info({table})').fetchall()]
    except sqlite3.Error:
        return []


def _texture_table_exists(conn: sqlite3.Connection, table: str) -> bool:
    try:
        row = conn.execute('SELECT name FROM sqlite_master WHERE type=\'table\' AND name=?', (table,)).fetchone()
        return row is not None
    except sqlite3.Error:
        return False


def _looks_like_addon_icon_url(url: str) -> bool:
    text = _normalize_texture_url(url)
    if '/addons/' not in text and 'special://home/addons/' not in text and 'special://xbmc/addons/' not in text:
        return False
    # Clear all add-on icon files, not video artwork. Most add-ons use icon.png,
    # but this also catches icon.jpg/icon.webp if an add-on uses them.
    return any(text.endswith('/icon' + ext) or '/icon' + ext + '/' in text for ext in ADDON_ICON_EXTENSIONS)


def clear_addon_icon_cache() -> Result:
    name = 'Add-on Icon Cache'
    db_path = latest_textures_db()
    thumb_root = thumbnails_path()
    if not db_path or not os.path.exists(db_path):
        return Result(name, 'Skipped', 'Textures database not found.')

    removed_files = 0
    removed_rows = 0
    matched_rows: List[Tuple[int, str, str]] = []
    conn = sqlite3.connect(db_path, timeout=30)
    try:
        conn.row_factory = sqlite3.Row
        cols = _texture_table_columns(conn, 'texture')
        if not cols or 'url' not in cols:
            return Result(name, 'Skipped', 'Textures DB has no texture.url table/column.')
        id_col = 'idtexture' if 'idtexture' in cols else ('id' if 'id' in cols else cols[0])
        cached_col = 'cachedurl' if 'cachedurl' in cols else ''
        query_cols = f'{id_col}, url' + (f', {cached_col}' if cached_col else '')
        for row in conn.execute(f'SELECT {query_cols} FROM texture').fetchall():
            url = str(row['url'] or '')
            if _looks_like_addon_icon_url(url):
                cached = str(row[cached_col] or '') if cached_col else ''
                matched_rows.append((int(row[id_col]), url, cached))

        if not matched_rows:
            return Result(name, 'Skipped', 'No cached add-on icon rows found.')

        for _id, _url, cached in matched_rows:
            if cached:
                cached_path = os.path.join(thumb_root, cached.replace('/', os.sep).replace('\\', os.sep))
                if os.path.exists(cached_path):
                    try:
                        os.remove(cached_path)
                        removed_files += 1
                    except OSError:
                        pass
                # Some Kodi installs also have sidecar DDS cache for the same base name.
                base, _ext = os.path.splitext(cached_path)
                dds_path = base + '.dds'
                if os.path.exists(dds_path):
                    try:
                        os.remove(dds_path)
                        removed_files += 1
                    except OSError:
                        pass

        ids = [row[0] for row in matched_rows]
        placeholders = ','.join('?' for _ in ids)
        try:
            if _texture_table_exists(conn, 'sizes') and 'idtexture' in _texture_table_columns(conn, 'sizes'):
                conn.execute(f'DELETE FROM sizes WHERE idtexture IN ({placeholders})', ids)
        except sqlite3.Error:
            pass
        conn.execute(f'DELETE FROM texture WHERE {id_col} IN ({placeholders})', ids)
        removed_rows = conn.total_changes
        conn.commit()
    finally:
        conn.close()

    return Result(name, 'Cleared', f'Removed {len(matched_rows)} add-on icon cache rows and {removed_files} thumbnail files from {os.path.basename(db_path)}. Restart Kodi or reload skin so icons rebuild.')


def clear_addon_icon_cache_menu() -> None:
    message = (
        'Clear cached icons for all installed Kodi add-ons?\n\n'
        'This deletes only add-on icon thumbnail cache rows/files from the latest Textures DB. '
        'Original add-on icon.png files are not touched. Kodi will rebuild icons automatically.'
    )
    if not yesno(ADDON_NAME, message):
        return
    run_single(clear_addon_icon_cache)



# -----------------------------------------------------------------------------
# Diagnostics: Fullscreen pause ratings live/static export
# -----------------------------------------------------------------------------

DIAG_LIVE_DIRNAME = 'diagnostics_live'
DIAG_EXPORT_DIRNAME = 'diagnostics'
DIAG_LIVE_PREFIX = 'fullscreen-pause-ratings-live'


def _safe_call(default, func, *args):
    try:
        return func(*args)
    except Exception as exc:  # pylint: disable=broad-except
        return default if default is not None else f'ERROR: {exc}'


def info_label(expr: str) -> str:
    if xbmc:
        return _safe_call('', xbmc.getInfoLabel, expr)
    return ''


def cond_visible(expr: str) -> bool:
    if xbmc:
        try:
            return bool(xbmc.getCondVisibility(expr))
        except Exception:  # pylint: disable=broad-except
            return False
    return False


def _window_obj(window_id: int):
    if xbmcgui:
        try:
            return xbmcgui.Window(window_id)
        except Exception:  # pylint: disable=broad-except
            return None
    return None


def _window_prop(window_id: int, name: str) -> str:
    win = _window_obj(window_id)
    if not win:
        return ''
    try:
        return str(win.getProperty(name) or '')
    except Exception:  # pylint: disable=broad-except
        return ''


def _current_window_ids() -> Dict[str, int]:
    data = {'current_window_id': 0, 'current_dialog_id': 0}
    if not xbmcgui:
        return data
    for key, getter_name in (('current_window_id', 'getCurrentWindowId'), ('current_dialog_id', 'getCurrentWindowDialogId')):
        getter = getattr(xbmcgui, getter_name, None)
        if getter:
            try:
                data[key] = int(getter())
            except Exception:  # pylint: disable=broad-except
                data[key] = 0
    return data


def _lrs_property_matrix(window_ids: Optional[List[int]] = None) -> Dict[str, dict]:
    if window_ids is None:
        ids = [10000]
        current = _current_window_ids().get('current_window_id', 0)
        if current and current not in ids:
            ids.append(current)
    else:
        ids = window_ids
    services = ('Player', 'VideoPlayer', 'ListItem', 'Screensaver')
    suffixes = ('Source', 'Icon', 'IconFile', 'Label', 'Value')
    matrix: Dict[str, dict] = {}
    for wid in ids:
        wkey = str(wid)
        matrix[wkey] = {}
        for service in services:
            skey = service
            matrix[wkey][skey] = {
                'HasData': _window_prop(wid, f'LibraryRatings.{service}.HasData'),
                'ItemKey': _window_prop(wid, f'LibraryRatings.{service}.ItemKey'),
                'Title': _window_prop(wid, f'LibraryRatings.{service}.Title'),
                'DBType': _window_prop(wid, f'LibraryRatings.{service}.DBType'),
                'Display_RatingSlots': _window_prop(wid, f'LibraryRatings.{service}.Display_RatingSlots'),
            }
            for slot in range(1, 7):
                slot_data = {}
                for suffix in suffixes:
                    slot_data[suffix] = _window_prop(wid, f'LibraryRatings.{service}.RatingSlot{slot}_{suffix}')
                matrix[wkey][skey][f'RatingSlot{slot}'] = slot_data
        matrix[wkey]['Display'] = {
            'RatingSlots': _window_prop(wid, 'LibraryRatings.Display.RatingSlots'),
            'Top250': _window_prop(wid, 'LibraryRatings.Display.Top250'),
            'Awards': _window_prop(wid, 'LibraryRatings.Display.Awards'),
            'TVStatus': _window_prop(wid, 'LibraryRatings.Display.TVStatus'),
        }
    return matrix


def _player_runtime_state() -> Dict[str, object]:
    ids = _current_window_ids()
    return {
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        **ids,
        'conditions': {
            'Player.HasMedia': cond_visible('Player.HasMedia'),
            'Player.HasVideo': cond_visible('Player.HasVideo'),
            'Player.Playing': cond_visible('Player.Playing'),
            'Player.Paused': cond_visible('Player.Paused'),
            'Player.Seeking': cond_visible('Player.Seeking'),
            'Player.Caching': cond_visible('Player.Caching'),
            'Window.IsActive(fullscreenvideo)': cond_visible('Window.IsActive(fullscreenvideo)'),
            'Window.IsActive(VideoFullScreen.xml)': cond_visible('Window.IsActive(VideoFullScreen.xml)'),
            'Window.IsActive(videoosd)': cond_visible('Window.IsActive(videoosd)'),
            'Window.IsVisible(1152)': cond_visible('Window.IsVisible(1152)'),
            'Window.IsVisible(1153)': cond_visible('Window.IsVisible(1153)'),
        },
        'videoplayer_labels': {
            'Title': info_label('VideoPlayer.Title'),
            'TVShowTitle': info_label('VideoPlayer.TVShowTitle'),
            'Season': info_label('VideoPlayer.Season'),
            'Episode': info_label('VideoPlayer.Episode'),
            'DBID': info_label('VideoPlayer.DBID'),
            'DBTYPE': info_label('VideoPlayer.DBTYPE'),
            'Rating': info_label('VideoPlayer.Rating'),
            'UserRating': info_label('VideoPlayer.UserRating'),
            'Year': info_label('VideoPlayer.Year'),
            'FileNameAndPath': info_label('VideoPlayer.FileNameAndPath'),
        },
        'lrs_properties': _lrs_property_matrix(),
    }


def _line_numbered_snippet(text: str, start_marker: str, end_marker: str, context: int = 8) -> str:
    lines = text.splitlines()
    start = end = -1
    for idx, line in enumerate(lines):
        if start_marker in line and start < 0:
            start = idx
        if end_marker in line:
            end = idx
            break
    if start < 0:
        return f'Marker not found: {start_marker}'
    if end < start:
        end = start
    lo = max(0, start - context)
    hi = min(len(lines), end + context + 1)
    return '\n'.join(f'{i + 1:05d}: {lines[i]}' for i in range(lo, hi))


def _full_file_digest(path: str) -> Dict[str, object]:
    data: Dict[str, object] = {'path': path, 'exists': os.path.exists(path)}
    if not os.path.exists(path):
        return data
    try:
        with open(path, 'rb') as handle:
            raw = handle.read()
        data['size'] = len(raw)
        data['mtime'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(path)))
        try:
            import hashlib
            data['sha256'] = hashlib.sha256(raw).hexdigest()
        except Exception:  # pylint: disable=broad-except
            pass
    except Exception as exc:  # pylint: disable=broad-except
        data['error'] = str(exc)
    return data


def _read_file_if_exists(path: str, max_chars: int = 300000) -> str:
    if not os.path.exists(path):
        return f'File not found: {path}'
    try:
        text = read_text(path)
    except Exception as exc:  # pylint: disable=broad-except
        return f'Could not read {path}: {exc}'
    if len(text) > max_chars:
        return text[-max_chars:]
    return text


def _latest_kodi_log_path() -> str:
    return norm(translate('special://logpath/kodi.log'))


def _filtered_kodi_log() -> str:
    path = _latest_kodi_log_path()
    text = _read_file_if_exists(path, 500000)
    keys = ('Kodi Patch Manager', 'KPM', 'Library Ratings Scraper', 'LibraryRatings', 'script.library.ratings.scraper', 'VideoFullScreen', 'fullscreenvideo', 'ERROR', 'Traceback', 'Skin Helper Service')
    out = []
    for line in text.splitlines():
        if any(k.lower() in line.lower() for k in keys):
            out.append(line)
    return '\n'.join(out[-2000:]) if out else 'No matching lines found in kodi.log tail.'


def _target_files_report() -> Dict[str, object]:
    files = {
        'VideoFullScreen.xml': vfs_pause_target(),
        'Includes_Info.xml': af3_path('1080i', 'Includes_Info.xml'),
        'Includes_OSD.xml': af3_path('1080i', 'Includes_OSD.xml'),
        'LRS addon.xml': norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml')),
        'LRS settings.xml': norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml')),
        'Kodi log': _latest_kodi_log_path(),
    }
    return {name: _full_file_digest(path) for name, path in files.items()}


def _diagnostic_text(runtime: dict, target_report: dict, vfs_text: str) -> str:
    lines = []
    lines.append(f'{ADDON_NAME} diagnostics v{VERSION}')
    lines.append(f'Generated: {time.strftime("%Y-%m-%d %H:%M:%S")}')
    lines.append('')
    lines.append('Patch status:')
    lines.append(patch_status_summary())
    lines.append('')
    lines.append('Runtime state:')
    lines.append(json.dumps(runtime, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Target files:')
    lines.append(json.dumps(target_report, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('VideoFullScreen marker snippet:')
    lines.append(_line_numbered_snippet(vfs_text, VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END))
    return '\n'.join(lines)


def _write_diag_file(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8', errors='replace') as handle:
        handle.write(content)


def export_diagnostics() -> Result:
    name = 'Export Diagnostics ZIP'
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_dir = addon_data_dir(DIAG_EXPORT_DIRNAME, stamp)
    zip_path = os.path.join(addon_data_dir(DIAG_EXPORT_DIRNAME), f'kpm-diagnostics-{stamp}.zip')
    runtime = _player_runtime_state()
    target_report = _target_files_report()
    vfs_target = vfs_pause_target()
    vfs_text = _read_file_if_exists(vfs_target, 1000000)
    diag_text = _diagnostic_text(runtime, target_report, vfs_text)

    files_to_write = {
        'summary.txt': diag_text,
        'runtime.json': json.dumps(runtime, indent=2, ensure_ascii=False),
        'target-files.json': json.dumps(target_report, indent=2, ensure_ascii=False),
        'patch-status.txt': patch_status_summary(),
        'VideoFullScreen-marker-snippet.txt': _line_numbered_snippet(vfs_text, VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END),
        'VideoFullScreen.xml': vfs_text,
        'Includes_Info.head.txt': _read_file_if_exists(af3_path('1080i', 'Includes_Info.xml'), 150000),
        'Includes_OSD.tail.txt': _read_file_if_exists(af3_path('1080i', 'Includes_OSD.xml'), 200000),
        'kodi-log-filtered.txt': _filtered_kodi_log(),
    }
    lrs_settings = norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml'))
    if os.path.exists(lrs_settings):
        files_to_write['lrs-settings.xml'] = _read_file_if_exists(lrs_settings, 100000)
    lrs_addon = norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml'))
    if os.path.exists(lrs_addon):
        files_to_write['lrs-addon.xml'] = _read_file_if_exists(lrs_addon, 100000)

    live_dir = addon_data_dir(DIAG_LIVE_DIRNAME)
    if os.path.isdir(live_dir):
        for fname in sorted(os.listdir(live_dir)):
            if fname.startswith(DIAG_LIVE_PREFIX):
                files_to_write['live/' + fname] = _read_file_if_exists(os.path.join(live_dir, fname), 300000)

    for rel, content in files_to_write.items():
        _write_diag_file(os.path.join(out_dir, rel.replace('/', os.sep)), content)

    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(out_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                zf.write(fpath, os.path.relpath(fpath, out_dir))

    log('[KPM_DIAG] Exported diagnostics: {0}'.format(zip_path))
    # Also log current key values into kodi.log for quick inspection.
    home_slots = runtime.get('lrs_properties', {}).get('10000', {}).get('Player', {}) if isinstance(runtime, dict) else {}
    for slot in range(1, 7):
        sd = home_slots.get(f'RatingSlot{slot}', {}) if isinstance(home_slots, dict) else {}
        log('[KPM_DIAG] Home Player Slot{0}: source={1!r} icon={2!r} label={3!r}'.format(slot, sd.get('Source'), sd.get('IconFile'), sd.get('Label')))
    return Result(name, 'Exported', zip_path)


def run_diag_live(duration_seconds: int = 90) -> None:
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_path = os.path.join(addon_data_dir(DIAG_LIVE_DIRNAME), f'{DIAG_LIVE_PREFIX}-{stamp}.jsonl')
    end_time = time.time() + max(5, int(duration_seconds))
    notify('Live diagnostic started. Pause fullscreen video now.')
    log('[KPM_DIAG] Live fullscreen ratings diagnostic started for {0}s -> {1}'.format(duration_seconds, out_path))
    with open(out_path, 'w', encoding='utf-8') as handle:
        sample_no = 0
        while time.time() < end_time:
            if xbmc and xbmc.Monitor().abortRequested():
                break
            sample_no += 1
            data = _player_runtime_state()
            data['sample'] = sample_no
            handle.write(json.dumps(data, ensure_ascii=False) + '\n')
            handle.flush()
            conds = data.get('conditions', {})
            hp = data.get('lrs_properties', {}).get('10000', {}).get('Player', {})
            s1 = hp.get('RatingSlot1', {}) if isinstance(hp, dict) else {}
            log('[KPM_DIAG] sample={0} paused={1} seeking={2} fullscreen={3} title={4!r} slot1={5!r}/{6!r}/{7!r}'.format(
                sample_no,
                conds.get('Player.Paused'),
                conds.get('Player.Seeking'),
                conds.get('Window.IsActive(fullscreenvideo)'),
                data.get('videoplayer_labels', {}).get('Title'),
                s1.get('Source'), s1.get('IconFile'), s1.get('Label'),
            ))
            if xbmc:
                xbmc.sleep(1000)
            else:
                time.sleep(1)
    log('[KPM_DIAG] Live fullscreen ratings diagnostic finished: {0}'.format(out_path))
    notify('Live diagnostic finished. Export Diagnostics ZIP now.')


def start_live_diagnostics_menu() -> None:
    message = (
        'Start a 90 second live diagnostic logger now?\n\n'
        'After pressing Yes, go back to the video and pause it. The logger records Player.Paused, active windows, VideoPlayer labels, and all LibraryRatings.Player RatingSlot1-6 properties once per second.'
    )
    if not yesno(ADDON_NAME, message):
        return
    if xbmc:
        xbmc.executebuiltin(f'RunScript({ADDON_ID},diag_live,90)')
        ok(ADDON_NAME, 'Live diagnostic started for 90 seconds.\n\nNow go to the video, pause it, wait a few seconds, then come back here and run Export Diagnostics ZIP.')
    else:
        run_diag_live(10)


# -----------------------------------------------------------------------------
# UI and batch actions
# -----------------------------------------------------------------------------

def format_results(results: List[Result]) -> str:
    chunks = []
    for item in results:
        text = f'{item.name}: {item.status}'
        if item.detail:
            text += f'\n{item.detail}'
        chunks.append(text)
    return '\n\n'.join(chunks)


def run_single(func: Callable[[], Result]) -> None:
    try:
        result = func()
        notify(f'{result.name}: {result.status}')
        ok(ADDON_NAME, format_results([result]))
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
        ok(f'{ADDON_NAME} - Error', str(exc))


def apply_all() -> None:
    if not yesno(ADDON_NAME, 'Apply all stable patches now?\n\n' + patch_details_summary(False) + '\n\nPatch style: inject/replace only selected blocks, with block-level remove/restore.'):
        return
    funcs = [patch_upnext, patch_tmdb, lambda: patch_shw(100), patch_lrs_af3, patch_vfs_pause_ratings]
    results: List[Result] = []
    for func in funcs:
        try:
            results.append(func())
        except Exception as exc:
            log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
            results.append(Result(getattr(func, '__name__', 'patch'), 'Error', str(exc)))
    notify('Apply all finished')
    ok(ADDON_NAME, format_results(results))


def remove_all() -> None:
    if not yesno(ADDON_NAME, 'Remove all patches now?\n\n' + patch_details_summary(True) + '\n\nNormal remove restores only the edited blocks, not whole files.'):
        return
    funcs = [remove_upnext, remove_tmdb, remove_shw, remove_lrs_af3, remove_vfs_pause_ratings]
    results: List[Result] = []
    for func in funcs:
        try:
            results.append(func())
        except Exception as exc:
            log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
            results.append(Result(getattr(func, '__name__', 'remove'), 'Error', str(exc)))
    notify('Remove all finished')
    ok(ADDON_NAME, format_results(results))


def patch_status_summary() -> str:
    lines = [f'Addon: {ADDON_NAME} v{VERSION}', '']
    for patch_id, status_name, _apply_name, _remove_name in PATCH_ORDER:
        data = patch_detail(patch_id)
        title = data.get('title', patch_id)
        status_func = globals().get(status_name)
        try:
            status = status_func() if status_func else 'Unknown'
        except Exception as exc:
            status = f'Error ({exc})'
        lines.append(f'{title}: {status}')
    return '\n'.join(lines)


def view_status() -> None:
    ok(f'{ADDON_NAME} - Patch Status', patch_status_summary())


def patch_message(patch_id: str, status: str) -> str:
    data = patch_detail(patch_id)
    return (
        f"Status in Kodi: {status}\n\n"
        f"Function:\n{data.get('function', '-')}\n\n"
        f"Target:\n{data.get('target', '-')}\n\n"
        f"Reference:\n{data.get('reference', '-')}\n\n"
        'Patch style:\nInject/remove selected blocks only. No full-file overwrite.'
    )


def choose_patch_action(patch_id: str, status_func: Callable[[], str]) -> str:
    data = patch_detail(patch_id)
    title = data.get('title', patch_id)
    try:
        status = status_func()
    except Exception as exc:
        status = f'Error ({exc})'
    message = patch_message(patch_id, status)

    dialog = xbmcgui.Dialog()
    # Kodi's yesnocustom labels are custom/no/yes. Use Patch as the YES button
    # and request YES as the default focused button on Kodi versions that support it.
    # Return values: -1=cancelled, 0=no, 1=yes, 2=custom.
    if hasattr(dialog, 'yesnocustom'):
        default_yes = getattr(xbmcgui, 'DLG_YESNO_YES_BTN', None)
        try:
            if default_yes is not None:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch', defaultbutton=default_yes)
            else:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
        except TypeError:
            try:
                if default_yes is not None:
                    result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch', 0, default_yes)
                else:
                    result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
            except TypeError:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
        if result == 1:
            return 'patch'
        if result == 0:
            return 'remove'
        return 'cancel'

    idx = dialog.select(title, [
        'Patch',
        'Remove',
        'Cancel',
    ], preselect=0)
    if idx == 0:
        return 'patch'
    if idx == 1:
        return 'remove'
    return 'cancel'


def run_patch_entry(patch_id: str, status_func: Callable[[], str], patch_func: Callable[[], Result], remove_func: Callable[[], Result]) -> None:
    action = choose_patch_action(patch_id, status_func)
    if action == 'patch':
        run_single(patch_func)
    elif action == 'remove':
        run_single(remove_func)


def run_console() -> None:
    print(f'{ADDON_NAME} v{VERSION}')
    print('This add-on is intended to run inside Kodi.')
    print('Status:')
    print('  Episode Thumb Up Next:', status_upnext())
    print('  Stable Random Fanart:', status_tmdb())
    print('  Movies + Shows Screensaver:', status_shw())
    print('  AF3 x LRS Ratings UI:', status_lrs_af3())
    print('  Fullscreen Pause Ratings:', status_vfs_pause_ratings())


def run() -> None:
    if not xbmcgui:
        run_console()
        return
    patch_entries = [
        ('upnext_episode_thumb', status_upnext, patch_upnext, remove_upnext),
        ('tmdb_focus_random_v11', status_tmdb, patch_tmdb, remove_tmdb),
        ('shw_random_movies_tvshows', status_shw, lambda: patch_shw(100), remove_shw),
        ('af3_lrs_ratings_ui', status_lrs_af3, patch_lrs_af3, remove_lrs_af3),
        ('vfs_pause_ratings', status_vfs_pause_ratings, patch_vfs_pause_ratings, remove_vfs_pause_ratings),
    ]
    while True:
        items = [
            'Apply All Patches',
            'Remove All Patches',
        ] + [patch_detail(patch_id).get('title', patch_id) for patch_id, *_ in patch_entries] + [
            'Patch Status',
            'Start Ratings Live Diagnostic',
            'Export Diagnostics ZIP',
            'Clear Add-on Icon Cache',
            'Exit',
        ]
        index = xbmcgui.Dialog().select(ADDON_NAME, items)
        if index < 0 or index == len(items) - 1:
            return
        if index == 0:
            apply_all()
        elif index == 1:
            remove_all()
        elif 2 <= index < 2 + len(patch_entries):
            patch_id, status_func, patch_func, remove_func = patch_entries[index - 2]
            run_patch_entry(patch_id, status_func, patch_func, remove_func)
        elif index == 2 + len(patch_entries):
            view_status()
        elif index == 3 + len(patch_entries):
            start_live_diagnostics_menu()
        elif index == 4 + len(patch_entries):
            run_single(export_diagnostics)
        elif index == 5 + len(patch_entries):
            clear_addon_icon_cache_menu()

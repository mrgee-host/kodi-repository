Kodi Patch Manager 0.2.32

Normal Arctic Mirage placement follows AF3 CurrentItem parity after random sorting:
left, right, left, right.

While Kodi notification or progress dialogs are visible, the active metadata panel
and matching vignette are forced to the left. Bundle A/B selects only the frozen
metadata snapshot. Plot, rating, awards/status, title fallback, and logo retain
400 ms fade-in and 400 ms fade-out.

Kodi Patch Manager 0.2.31

Arctic Mirage placement contract:
- AF3 CurrentItem parity owns placement after random sorting.
- Even item: left.
- Odd item: right.
- MediaHub mediahub_bundle_slot A/B only selects the frozen metadata snapshot.
- Each parity has an A and B variant guarded by matching item_key.
- Title, plot, rating, awards/status, and final logo fade in/out together for 400 ms.
- The older notification-dependent left duplicate is removed to keep strict alternation.

Kodi Patch Manager 0.2.33

- Current-only fresh-install AF3 integration.
- No screensaver, info-row, or landscape migration from older KPM/Steam Library patches.
- Clean AF3 files are patched directly to the current layout.
- Older or partial patch markers are rejected without modifying the source file.
- Current behavior remains: normal left/right parity, notification forces metadata and vignette left, A/B metadata snapshots, 400 ms fades, KPM row, compact Steam landscape, progress spacing, and Cinema Pre-roll fonts.

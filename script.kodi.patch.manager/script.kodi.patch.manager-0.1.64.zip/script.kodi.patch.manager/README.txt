Kodi Patch Manager v0.1.64

New in v0.1.64:
- Fixes the v0.1.63 direct URL bug where TMDbHelper could preserve the KPM URL as a broken value like Container(301).ListItem(0).https://image.tmdb.org/... instead of a real texture URL.
- Patches TMDbHelper images.py so any container/listitem-prefixed texture URI is sanitized back to the real URL before blur generation.
- KPM still only chooses the source fanart. AF3/TMDbHelper remain responsible for blur, diffuse, tiled and blur_v3 cache output.
- KPM also publishes a lowercase kpm.fanart.sourceimage alias so old/lowercased property expressions do not resolve empty.
- No-repeat fanart bag per item remains enabled.

Expected flow:
1. KPM selects one original fanart URL per media visit.
2. KPM writes that URL into TMDbHelper.Blur.SourceImage.
3. TMDbHelper sanitizes the source if Kodi/AF3 prefixes it with Container(...).ListItem(...).
4. TMDbHelper generates/uses the normal blur_v3 cache.
5. AF3 displays the normal TMDbHelper blur output.

Install:
1. Install this ZIP.
2. Restart Kodi.
3. Open Kodi Patch Manager > Advanced Patches > KPM Visit Random Fanart Source > Patch.
4. Restart Kodi again so service.py and TMDbHelper images.py reload.

Notes:
- KPM does not manage clearlogo. Clearlogo remains native AF3/Kodi/TMDbHelper artwork. If clearlogo art is empty for an item, the skin falls back to title text.
- KPM.Fanart.BlurImage remains diagnostic only and should not be used as the visible texture.

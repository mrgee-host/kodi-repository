Kodi Patch Manager v0.1.13

New in v0.1.13:
- Adds Start Ratings Live Diagnostic. It logs fullscreen pause state and LibraryRatings.Player RatingSlot1-6 once per second.
- Adds Export Diagnostics ZIP.


Safe patch style:
- Does not ship full replacement XML/PY target files.
- Uses anchor-based injection/replacement only.
- Adds clear markers to every injected block.
- Normal Remove/Restore is block-level: it removes injected blocks or restores only the saved original XML variable block, not the whole file.
- A safety snapshot is also stored before patching, but normal restore does not overwrite the whole target file.

Included patches:
1. Episode Thumb Up Next
   Target: skin.arctic.fuse.3/1080i/Includes_Images.xml
   Change: Image_UpNext becomes thumb -> landscape -> fanart.

2. Stable Random Fanart
   Target: plugin.video.themoviedb.helper/resources/tmdbhelper/lib/monitor/imgmon.py
   Target: plugin.video.themoviedb.helper/resources/tmdbhelper/lib/monitor/images.py
   Change: random extra-fanart stays stable while focus stays on the same item.

3. Movies + Shows Screensaver
   Target: script.skin.helper.widgets/resources/lib/media.py
   Target: skin.arctic.fuse.3/1080i/Includes_Defaults.xml
   Change: adds randommoviestvshows path and points AF3 screensaver widget to movies + TV shows only.

Reference uploads:
- Original uploaded PowerShell/XML reference files are included under resources/reference/uploads.
- The add-on uses native Python patchers inside Kodi; it does not call PowerShell.

Backups/state:
- special://profile/addon_data/script.kodi.patch.manager/state
- special://profile/addon_data/script.kodi.patch.manager/snapshots

After patch/remove:
- Fully close Kodi and open it again for Python helper patches.
- Reload Skin may be enough for XML-only changes, but full restart is safest.

v0.1.7 changes:
- Main menu now shows patch titles only.
- Selecting a patch opens a detail popup with current Kodi status and Patch / Remove / Cancel.
- Details show function, target file, and bundled standalone reference file where relevant.
- Add-on icon updated to the new Patch Manager icon.


0.1.4:
- Added AF3 x LRS Ratings UI patch entry.
- Removed standalone patch-file references from addon package; patch logic is native Kodi Python.
- Main menu still uses title-only entries with Patch / Remove / Cancel detail popup.


v0.1.7:
- Patch Status is compact: status only, no long function/target details.
- Patch detail dialog defaults to Patch instead of Remove.
- Add-on icon replaced with the user-provided Kodi Patch Manager artwork.


v0.1.7: Patch action now uses Patch as YES/default button when supported. Added Clear Add-on Icon Cache tool for all Kodi add-on icons.


v0.1.10
- Fullscreen Pause Ratings now reads only LibraryRatings.Player.RatingSlot1-6 from LRS.
- Removed TMDbHelper and Kodi rating fallback from that pause row patch.
- Replaces old KPM-VFS-PAUSE-RATINGS block when Patch is selected.


0.1.13
- Fullscreen Pause Ratings now patches DialogSeekBar.xml, the real AF3 Paused header overlay, not VideoFullScreen.xml.
- Cleans legacy VideoFullScreen marker, hard-renders image/label controls from LibraryRatings.Player.RatingSlot1-6 only, and requests ReloadSkin after patch/remove.

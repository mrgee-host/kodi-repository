script.kodi.patch.manager 0.2.22 - R4

MrGee Kodi Family R4 runtime and consistency fixes.

Kodi Patch Manager 0.2.14

- Patch result summaries and AF3 unified status now use DialogTextViewer, so long output is scrollable.
- Existing Arctic Mirage identity guards and random fanart path remain unchanged.

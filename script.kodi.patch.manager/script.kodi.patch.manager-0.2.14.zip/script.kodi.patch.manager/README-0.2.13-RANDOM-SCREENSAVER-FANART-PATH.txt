Kodi Patch Manager 0.2.13
=========================

- Default Arctic Mirage MediaHub path now uses mode=screensaver_mix.
- This explicitly activates MediaHub Widget 0.1.24 random-one-fanart-per-item behavior.
- Existing strict clearlogo item-key guard and blank-while-pending behavior remain unchanged.

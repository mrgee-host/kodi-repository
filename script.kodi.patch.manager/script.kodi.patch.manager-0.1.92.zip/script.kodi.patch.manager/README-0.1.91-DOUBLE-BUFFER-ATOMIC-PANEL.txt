Kodi Patch Manager 0.1.91

- Adds a true two-bank AF3 information panel for Home, Hubs and media/program browsing contexts.
- The active bank remains fully visible while the next canonical item is stabilized.
- Logo/title, top metadata, plot heading/body and lower rating row are staged in the inactive bank.
- Window(Home).Property(KPM.Panel.ActiveBank) is written last and is the only visual commit point.
- Missing logo, plot or ratings use bounded grace periods; the old panel remains visible while providers finish.
- Collection/set items bypass the atomic panel and use native AF3 without stale rating rows.
- Live/full diagnostics include both panel banks, commit pointer, generations, signatures, pending item key and hold reason.

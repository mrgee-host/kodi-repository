Kodi Patch Manager 0.1.92 - Texture-preloaded atomic panel

- Keeps the previously committed logo, metadata, plot and rating row visible while the next item is resolved.
- Stages the inactive bank, warms its logo texture in a hidden AF3 image control, then commits the prepared bank only after the preload interval.
- Uses synchronous loading for the visible logo control, preventing the reused bank from flashing the logo that occupied it two items earlier.
- Atomic bank groups now require KPM.Panel.Enabled=true, preventing native collection/set panels and stale KPM banks from overlapping.
- Does not take over fanart; AF3 keeps its native fanart crossfade.
- Uses AF3’s exact flags/$VAR[Color_Directory]/status/calendar-*.png status icon family and freezes the chosen icon in the active bank.
- Prevents a stale bank from reappearing outside visual media contexts.
- Imports hashlib for live diagnostics and records staging/preload fields for both banks.

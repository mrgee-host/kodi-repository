Kodi Patch Manager v0.1.58

New in v0.1.58:
- Replaces the failed TMDbHelper internal random fanart patch direction with Option B: KPM Visit Random Fanart Source.
- Does NOT edit plugin.video.themoviedb.helper internals (no imgmon.py/images.py patch, no restore, no repair).
- KPM service chooses exactly one fanart URL per valid media visit and publishes it as KPM.Fanart.SourceImage.
- AF3 blur source is patched to use Property(KPM.Fanart.SourceImage) first, then non-cycle native fanart fallback.
- TMDbHelper still renders blur_v3/foreground/overlay normally, but receives one final source URL instead of Art(fanart{x}).
- Designed for AF3 Cycle Fanart OFF.

Important behavior:
- A enters -> KPM chooses one fanart.
- Staying on A -> same fanart remains locked.
- A -> B -> A -> A is allowed to choose a new fanart because it is a new visit.
- Play/More/tab/menu transient focus does not create a new random choice.
- TMDbHelper old KPM markers are refused; restore TMDbHelper manually to default first.

Menu:
- Apply Recommended Patch
- Remove Recommended Patch
- Advanced Patches
- Patch Status
- Diagnostics
- Clear Add-on Icon Cache
- Settings
- Exit

Recommended workflow:
1. Restore TMDbHelper manually to default.
2. Install this zip.
3. Restart Kodi.
4. Advanced Patches > KPM Visit Random Fanart Source > Patch.
5. Set AF3 Cycle Fanart OFF.
6. Restart Kodi.
7. Run Diagnostics > Start Fanart Live Diagnostic and test hub movies, hub series, library movies, library series.

Fanart diagnostic records every 100 ms:
- Native ListItem and Container.ListItem art.
- Common AF3 containers such as 301/501/502/503/504/601.
- LRS/TMDbHelper/KPM bridge properties.
- KPM.Fanart.SourceImage and selected/candidates/reason/status.
- TMDbHelper.Blur.SourceImage, Blur.Fallback, and BlurImage output properties.

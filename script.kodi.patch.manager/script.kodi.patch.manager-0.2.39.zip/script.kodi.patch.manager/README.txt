Kodi Patch Manager 0.2.39

Runtime-only AF3 update
- Does not bundle or directly replace AF3 XML files.
- Full KPM Integration remains an idempotent partial patch at Kodi startup while enabled.
- Screensaver A/B bundle flow, Up Next thumb priority, Steam plot, poster 2:3, and startup-weather fallback are unchanged.

Combined Expanded episodes
- Uses AF3 native Object_StarRating, including its native dimensions and selected/unselected coloring.
- IMDb rating first; TMDb only when IMDb is empty.
- No star or rating number when both ratings are empty.
- Shows ListItem.Year (YYYY) instead of the full premiered date.
- Episode title uses the AF3 font/color structure, does not scroll, and uses right=400 only in Combined Expanded episodes.
- Existing AF3 watched/library indicator and duration controls are untouched.

Startup contract
- Apply Full KPM Integration writes the master enabled state.
- Startup silently restores the same six-patch integration only while that state is enabled.
- Remove Full KPM Integration disables startup restoration.
- No all/day or all/night folder is created or referenced.

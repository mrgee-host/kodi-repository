Kodi Patch Manager 0.2.29

- Arctic Mirage metadata fade-in: 400 ms.
- Arctic Mirage metadata fade-out: 400 ms.
- Bundle A and Bundle B own separate title, plot, rating, awards/status, and logo snapshots.
- The outgoing snapshot cannot change while fading out.
- The incoming snapshot appears only after every component matches its item key.

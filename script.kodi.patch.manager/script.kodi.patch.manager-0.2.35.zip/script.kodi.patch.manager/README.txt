Kodi Patch Manager 0.2.35

Base
----
Rebuilt from the 0.2.33 current-only fresh-install AF3 integration. No 0.2.34 Controller Companion full-keymap behavior is retained.

Only new runtime changes
------------------------
1. Installs resources/keymaps/kpm_subtitle_delay.xml to special://profile/keymaps/kpm_subtitle_delay.xml.
2. In FullscreenVideo, game.controller.default leftbumper runs subtitledelayminus and rightbumper runs subtitledelayplus.
3. Disables the single active <include>Part_Dim_Overlay</include> in special://home/addons/skin.arctic.fuse.3/1080i/DialogSlider.xml by replacing it with one XML comment marker.

0.2.35 current AF3 corrections
------------------------------
- Background progress dialogs no longer hide or freeze the Home/Library rating row.
- Arctic Mirage metadata fade-out is 1 ms in all six current panels.
- An enabled or already KPM-marked AF3 Unified Integration is refreshed automatically after update.

Safety
------
- Dedicated keymap contains only LB and RB mappings.
- Different existing targets are backed up before atomic replacement.
- Identical/current files are not rewritten.
- XML and duplicate counts are validated before replacement.
- No GUI sound, guisettings.xml, other add-on, or unrelated KPM behavior is changed.
- The skin is not forcibly reloaded.

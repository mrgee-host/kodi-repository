KPM 0.1.82 clean integration owner

Role: AF3 XML patch code owner, KPM.RatingRow visual service owner, shared icons, full diagnostics/cropV2 diagnostics. Not a scraper; it reads LRS/Steam/LAC settings and data outputs.

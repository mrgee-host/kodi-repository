Kodi Patch Manager v0.1.45

New in v0.1.45:
- Independent Fanart Engine removed from KPM menus, Apply Recommended, Remove Recommended, Advanced Patches, and service runtime.
- AF3 x LRS Ratings UI patch removed from KPM menus and recommended patch actions.
- Fanart Live Diagnostic is kept, but it is diagnostic-only: it observes default Kodi/AF3/TMDbHelper fanart and blur state without changing fanart.
- Add-on icon resized to 256x256.
- Main menu order changed: Advanced Patches is now position 3, and Settings is right before Exit.

Main menu:
- Apply Recommended Patch
- Remove Recommended Patch
- Advanced Patches
- Patch Status
- Diagnostics
- Clear Add-on Icon Cache
- Settings
- Exit

Recommended workflow:
1. Hard reset/restore your AF3 and related XML files as planned.
2. Install this zip.
3. Run only the patches you still want from KPM.
4. For fanart debugging, use Diagnostics > Start Fanart Live Diagnostic, move focus A → B → A → B, then Export Diagnostics ZIP.

Fanart diagnostic records every 100 ms:
- Native ListItem and Container.ListItem art.
- Common AF3 containers such as 502/503/504/601 plus active containers from LRS/TMDbHelper.
- TMDbHelper.WidgetContainer.
- TMDbHelper.Blur.SourceImage, Blur.Fallback, and BlurImage output properties.
- Any stale KPM fanart properties if old runtime state still exists.

Notes:
- KPM v0.1.45 does not install or clean fanart patches.
- KPM v0.1.45 does not install or clean AF3 x LRS patches.
- Reliable Studio Logos remains single-logo only through KPM.StudioLogo.1.


v0.1.45: Adds Advanced Patches > TMDbHelper Visit Random Fanart. This patches TMDbHelper only: AF3 Cycle Fanart must be ON, fanart randoms once per valid media visit, stays sticky while idle, and restores from KPM state backup.


v0.1.47: TMDbHelper Visit Random Fanart V13 primes the new source immediately on media visit to reduce stale old-item fanart flashes during fast focus changes.

Kodi Patch Manager v0.1.41

New in v0.1.41:
- Independent Fanart Engine is corrected to be a source selector only.
- KPM feeds AF3/TMDbHelper Blur.SourceImage and Blur.Fallback.
- KPM no longer writes raw artwork URLs into TMDbHelper.ListItem.BlurImage or .Original outputs.
- AF3/TMDbHelper keep generating/using blur_v3 files, including tiled/diffuse/original layers.
- Add-ons/settings/KPM screens are not forced to use random movie launch fanart.

Main menu:
- Apply Recommended Patch
- Remove Recommended Patch
- Patch Status
- Diagnostics
- Clear Add-on Icon Cache
- Advanced Patches
- Settings
- Exit

Recommended workflow:
1. Install this zip.
2. Run Kodi Patch Manager > Apply Recommended Patch.
3. Restart Kodi once so service.py v0.1.41 replaces any older running service.

Notes:
- Independent fanart uses Artwork Curator / LAC artwork-cache.db read-only.
- Episode and season fanart fall back to parent TV show fanart through MyVideos DB mapping.
- Launch fallback can use random movie/TV fanart URL from artwork-cache.db; Kodi handles texture cache normally.
- Reliable Studio Logos remains single-logo only through KPM.StudioLogo.1.

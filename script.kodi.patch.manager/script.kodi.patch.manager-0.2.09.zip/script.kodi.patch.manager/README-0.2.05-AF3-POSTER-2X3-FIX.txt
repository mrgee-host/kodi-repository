Kodi Patch Manager 0.2.05
=============================

Fix:
KPM 0.2.04 looked for non-existent AF3 constants:
- view_poster_item_w_neg
- view_poster_itemlayout_w_neg

AF3 actually uses:
- -view_poster_item_w
- -view_poster_itemlayout_w

The corrected patch now changes:
- view_poster_item_w
- -view_poster_item_w
- view_poster_itemlayout_w
- -view_poster_itemlayout_w

For the supplied AF3 constants:
Poster: 217.14 × 310 -> 206.67 × 310
Cell:   257.14 × 350 -> 246.67 × 350
Gap:    40.00 -> 40.00

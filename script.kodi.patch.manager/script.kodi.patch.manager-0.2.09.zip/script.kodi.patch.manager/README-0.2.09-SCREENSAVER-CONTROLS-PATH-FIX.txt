Kodi Patch Manager 0.2.09
=============================

- Repairs leading >plugin:// picker artifacts.
- Converts MediaHub screensaver paths to limit=0.
- Default MediaHub path is unlimited.
- Adds screensaver duration presets/custom seconds to KPM Settings.
- Explicitly writes plot autoscroll=false to both plot textboxes.

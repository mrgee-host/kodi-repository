Kodi Patch Manager 0.2.03 - Restore lifetime playtime clock icon

Base: clean 0.2.01 Skin Shortcuts v3 screensaver picker.

- Keeps the manual screensaver widget path chooser.
- Keeps lifetime playtime on the established ends.png clock icon.
- Does not add or reference steam-playtime.png.
- Corrective upgrade for the mistaken 0.2.02 icon change.

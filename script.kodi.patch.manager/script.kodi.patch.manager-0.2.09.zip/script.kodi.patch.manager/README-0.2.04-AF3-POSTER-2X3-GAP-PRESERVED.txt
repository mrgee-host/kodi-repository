Kodi Patch Manager 0.2.04
=============================

New Advanced Patch:
AF3 Poster Ratio 2:3

Method:
- Reads active values from AF3 1080i/Includes_Constants.xml.
- Keeps view_poster_item_h unchanged.
- Calculates new poster width = current poster height × 2 ÷ 3.
- Preserves the current horizontal gap:
  current gap = current layout width - current poster width.
- Calculates new layout width = new poster width + current gap.
- Updates positive and negative width constants together.
- Saves the exact original values for reversible restore.
- Does not change poster height or layout height.

For AF3 3.2.13:
Poster 217.14 × 310 -> 206.67 × 310
Cell   257.14 × 350 -> 246.67 × 350
Gap remains 40.

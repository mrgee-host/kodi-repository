Kodi Patch Manager 0.1.84

Migration-parity pass after the clean data-owner split.

Fixes/changes:
- KPM-owned AF3 lower row now removes conflicting native AF3/LRS/Steam rating blocks instead of merely inserting beside them.
- Prevents duplicate Ends at / duplicate lower row from native AF3 EndTime/Info_Meta_Ratings/Awards/Status renderers.
- Adds stricter set/collection guard in XML and service clear path.
- Restores LRS-style source formatting:
  - IMDb/TMDb/Trakt keep one decimal, e.g. 6.0.
  - Rotten Tomatoes / Popcorn use %.
  - Metacritic is integer.
- Restores Oscar Best Picture icon selection: oscars_bp.png with xN label.
- Adds Home/Hub resolver fallbacks using ListItem, Container.ListItem, and common TMDbHelper properties.
- Adds game lower row from current game properties: Steam, Metacritic, achievements, completed, finished.
- Copies/normalizes shared icons in KPM, including IMDb 64x64 and Steam completed/finished icons.
- Ports mature Steam game Info_Line/plot visibility guards into KPM so game top line can show and generic plot does not duplicate.
- KPM remains visual/XML/diagnostics owner. LRS, Steam Library, LAC, and MediaHub remain data/provider owners.

Install order:
1. MediaHub Widget 0.1.13
2. LRS 1.5.34
3. Steam Library 0.3.70
4. KPM 0.1.84
5. Restart Kodi
6. KPM > Apply Full KPM Integration
7. Reload skin or restart Kodi again

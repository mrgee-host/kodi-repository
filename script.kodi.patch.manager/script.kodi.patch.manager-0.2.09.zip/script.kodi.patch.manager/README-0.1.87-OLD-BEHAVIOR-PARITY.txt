KPM 0.1.87 - Old Behavior Parity

Copied from the known-good previous implementations, not newly estimated:
- Steam Library 0.3.67 Layout_Landscape game height: exactly 192 px.
- LRS 1.5.31 IMDb-only XML icon width: exactly icon_w 52.
- Arctic Mirage legacy row geometry: height 54, centertop 332, itemgap 12.

Runtime parity:
- KPM bridges mature LibraryRatings.HomeHub.DisplaySlot output.
- Episode row uses IMDb + TMDb when available.
- Fill-empty slots, TMDb-after-IMDb fallback, merged IMDb Top250, awards,
  series status and EndsAt follow LRS settings/logic.
- Lower row publishes atomically and only republishes when payload changes.
- Busy/updating XML guards prevent partial half-visible rows.

Assets:
- All rating icons were copied byte-for-byte from the supplied ikon.zip.
- No icon resizing or normalization was performed.
- Poster completed/finished badge assets remain KPM-only.

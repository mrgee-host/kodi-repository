Kodi Patch Manager 0.1.96

- Rebased from 0.1.95; all non-logo behavior is unchanged.
- Moves the 505 KPM studio/game logos out of the script add-on into dependency resource.images.kpm.studiologos 1.0.0.
- The resource contains one XBTF2 archive with 374 movie/series studio logos and 131 game developer/publisher logos.
- Movie/series provider order per candidate: resource.images.studios.coloured, then KPM XBT.
- Game provider order per candidate: KPM XBT, then resource.images.gamestudios.grayscale.
- KPM reads manifest/aliases once when the service starts and builds in-memory dictionaries. Focus changes only normalize candidate names and perform dictionary lookups; no folder or XBT scan happens per focus.
- Diagnostic exports include the resource add-on, XBT digest, manifest, aliases, build report and resolved provider.

KPM 0.1.97

- Requires resource.images.kpm.studiologos 1.0.1 (505 centered 161x109 logos).
- Removes unmarked and marked direct Steam Info_Meta_Object lower rows.
- Clears pre-0.1.97 A/B/public row state once after upgrade.
- Locks game row order: Steam, Metacritic, Achievement, lifetime playtime.
- Uses Steam Library SQLite fallback by AppID when MediaHub/ListItem properties are incomplete.
- Adds playtime/provider completeness to canonical item scoring and fingerprinting.

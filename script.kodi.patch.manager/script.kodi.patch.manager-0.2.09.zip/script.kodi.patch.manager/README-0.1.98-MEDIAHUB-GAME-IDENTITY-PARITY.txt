Kodi Patch Manager 0.1.98

- Treats explicit MediaHub game items as games even when Kodi DBType is movie for
  AF3 furniture compatibility.
- Locks MediaHub and Steam Library to the identical row:
  Steam + Steam250 -> Metacritic -> Achievement -> lifetime playtime.
- Reads Steam250 rank from item properties before SQLite fallback.
- Strengthens removal of historical direct game-row XML includes/groups.
- Keeps KPM as the sole lower-row renderer; logo, plot and fanart stay native AF3.

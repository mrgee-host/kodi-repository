KPM 0.1.94

No panel banks. Atomic lower-row slot snapshot only; fixed Steam-Metacritic-Achievement-playtime order; compact playtime with ends.png; live diagnostics retained.

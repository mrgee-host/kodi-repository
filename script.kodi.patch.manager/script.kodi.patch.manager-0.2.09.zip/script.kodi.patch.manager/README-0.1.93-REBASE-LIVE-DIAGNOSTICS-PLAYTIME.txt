KPM 0.1.93 is rebuilt from 0.1.90, not from the experimental panel-bank releases.
- Keeps AF3 native logo/fanart/plot transitions.
- Repairs 60 ms live diagnostics (global hashlib import, resilient output directory).
- Adds Steam Play Time as the last game row slot using ends.png.
- Normalizes TV status display to Returning / Ended / Cancelled without dates.
- Adds playtime and slot-order checks to live diagnostics.

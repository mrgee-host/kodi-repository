Kodi Patch Manager 0.1.83

Clean integration owner. Main menu uses Apply Full KPM Integration / Remove Full KPM Integration. Individual patchers, including AF3 Unified Integration, are under Advanced Patches. Full diagnostics remain in KPM. Scraping remains in LRS/Steam/LAC/MediaHub.

Kodi Patch Manager v0.1.79
- Fixes studio resolver crash introduced in the game studio logo branch: restored missing _split_studio_label helper used by movie/TV and Steam game studio candidate parsing.
- Keeps v0.1.78 packaging fix: addon icon restored; trakt.png remains in resources/media/shared-icons/trakt.png.
- Keeps v0.1.77 LRS / Steam Library diagnostics/status-only export.
- No LRS rendering XML changes, no Steam Library lower meta row injection/removal, no fanart bridge.

Kodi Patch Manager v0.1.78
- Fixes v0.1.77 packaging mistake: addon icon.png is restored to the base KPM icon.
- Adds trakt.png to resources/media/shared-icons/trakt.png.
- Diagnostics/status only for LRS + Steam Library coordination remains unchanged.
- No LRS/Steam Library render XML changes, no Steam lower meta row injection/removal.

Kodi Patch Manager v0.1.76
- Reliable Studio Logos now also resolves Steam game developer/publisher logos via resource.images.gamestudios.grayscale when that image resource is installed.
- Movie/TV studio logos still use resource.images.studios.coloured. No fanart/random bridge is added.

Kodi Patch Manager v0.1.71

Built from v0.1.67 clean-no-fanart base. Unified runtime/diagnostics storage added. No v0.1.69 screensaver-games plugin-source changes are included.

Included modules:
- Episode Thumb Up Next
- Movies + Shows Screensaver
- Pause Shows Full OSD
- Reliable Studio Logos

Removed from this build:
- Background random/source bridge module
- Related runtime engine in service.py
- Related patch menu entries
- Related diagnostic menu entries
- Related bridge/status/state handling
- One-time cleanup/restore routines that touch AF3/TMDbHelper files

Install notes:
1. Install this ZIP over the previous KPM version.
2. Restart Kodi.
3. Because this build does not run cleanup routines, it will not alter restored AF3/TMDbHelper files.


Unified runtime update in v0.1.71:
- Patch state now uses runtime/state/.
- Snapshots and diagnostics staging use runtime/exports/.
- Live diagnostic JSONL files use runtime/logs/diagnostics_live/.
- Diagnostics ZIP files are written to the addon_data root.
- Older KPM diagnostics ZIP files in the root are automatically removed before a new one is written.
- Patch Status opens in a text viewer for easier reading.


Shared icon policy:
- KPM is the only canonical shared icon path.
- Uses only the fixed icon filenames supplied in ikon fix.zip.
- No local fallback icons in companion addons.


0.1.76
- Fix Reliable Studio Logos game pack crash: restore missing _is_broken_studio_texture helper and guard movie/game index builds so one failed resource cannot stop the KPM service.

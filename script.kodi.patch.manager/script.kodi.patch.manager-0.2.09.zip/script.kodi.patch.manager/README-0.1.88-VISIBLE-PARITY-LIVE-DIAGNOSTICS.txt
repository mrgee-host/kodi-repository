Kodi Patch Manager 0.1.88

- TV status is no longer formatted as Ends at.
- TV status uses AF3 default flags/$VAR[Color_Directory]/ratings/ends.png.
- Arctic Mirage row keeps the proven 54px / centertop 332 / itemgap 12 geometry and adds ItemKey-first identity matching.
- Full diagnostics now include screensaver-arctic-mirage.xml, Includes_Layouts.xml, Custom_1104_Hub.xml and context-wide runtime snapshots.
- Live diagnostic runs 120 seconds at 250ms and records all visual contexts plus automatic consistency warnings.

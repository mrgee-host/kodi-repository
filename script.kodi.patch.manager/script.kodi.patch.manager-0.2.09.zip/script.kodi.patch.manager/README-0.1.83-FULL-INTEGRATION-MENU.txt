KPM 0.1.83

- Main menu now uses Apply Full KPM Integration / Remove Full KPM Integration.
- AF3 Unified Integration and all single patchers moved under Advanced Patches.
- Full apply runs AF3 Unified Integration, UpNext thumb, Movies+Shows screensaver, Pause Full OSD, and Reliable Studio Logos.
- Fixes service NameError: _safe_int not defined.
- KPM remains visual/XML/diagnostics owner; LRS/Steam/LAC/MediaHub remain data owners.

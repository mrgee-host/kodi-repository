Kodi Patch Manager 0.2.08
=============================

Arctic Mirage clearlogo renderer:
- Explicit group size: 680 × 280
- Explicit image size: 680 × 280
- Explicit bottom anchor: bottom=0
- Aspect: keep, horizontal center, vertical bottom
- Uses LRS ClearLogoFinal
- Matches current slide by ItemKey first, title second
- Same geometry for movie, TV show, and game
- Native clearlogo remains only when LRS has no screensaver data

This fixes the ambiguity in v0.2.07, where the image control did not have its
own width, height, or bottom coordinate.

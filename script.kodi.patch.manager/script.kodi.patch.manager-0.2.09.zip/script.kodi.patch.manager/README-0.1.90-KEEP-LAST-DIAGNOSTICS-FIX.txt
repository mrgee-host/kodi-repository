Kodi Patch Manager 0.1.90

- Replaces the hard blanking Info_Panel transition gate with non-destructive keep-last behavior.
- Preserves the previous KPM rating row while a new canonical item is loading/stabilizing.
- Native AF3 panel remains visible; KPM never deliberately blanks it during navigation.
- Adds KPM.Visual.HasCommitted, Transitioning, HoldReason and Suppress diagnostics.
- Fixes live and full diagnostic NameError by using cond_visible().
- Live diagnostic now catches per-sample exceptions and continues recording instead of producing a zero-byte file.

Kodi Patch Manager 0.2.07
=============================

Responsive timing restored
--------------------------
- Fast GUI poll: 0.05 s
- Active GUI poll: 0.20 s
- Studio resolver: 0.15 s
- The 350 ms state gate no longer delays VideoOSD actions.
- Numeric window/dialog detection, DEBUG deduplication, removal of "files"
  and "dialogprogress", and safe VideoOSD closing remain active.

Arctic Mirage clearlogo correction
----------------------------------
The exported AF3 XML was still rendering:
Container(1297).ListItem.Art(clearlogo)

That bypassed LRS ClearLogoFinal even when LRS had selected CropV2.

KPM now patches both left/right clearlogo groups to render:
Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinal)

Rules:
- Same 280-high AF3 box for movie, series, and game.
- Same aspectratio keep, aligny bottom.
- No game-specific top/left/bottom offset.
- LRS result is shown only when its title matches the current slide.
- During slide transition, stale LRS logo is hidden instead of flashing.
- Native Container clearlogo is retained only when LRS has no data.
- Text title remains the fallback when no final logo exists.

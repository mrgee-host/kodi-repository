Kodi Patch Manager 0.2.06
=============================

- Active GUI polling is capped at four checks per second (250 ms).
- Window/dialog state must stay unchanged for 350 ms before automatic
  VideoOSD open/close actions.
- Foreign-dialog messages are DEBUG, state-deduplicated, and only generated
  while a video session is active.
- Correctly preserves xbmc.LOGDEBUG instead of promoting it to LOGINFO.
- Removes Window.IsActive(files).
- Removes Window.IsVisible(dialogprogress) from runtime and generated AF3 XML.
- Repairs the old KPM-owned Includes_Info.xml condition on service startup.
- Does not force ActivateWindow(fullscreenvideo) while VideoOSD closes.

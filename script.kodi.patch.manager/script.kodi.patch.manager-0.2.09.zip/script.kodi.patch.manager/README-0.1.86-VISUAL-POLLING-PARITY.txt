KPM 0.1.86
- Fast visual polling in AF3 browse/Home/Hub/Programs instead of 1s idle fallback.
- Broader AF3 Home/Hub resolver containers/window properties for game ratings.
- Removed completed/finished from game text rating row; poster badges remain.
- Merge IMDb Top250 rank into IMDb slot label.
- Optional marker-scoped Arctic Mirage screensaver rating row using LibraryRatings.Screensaver.*.

Kodi Patch Manager 0.2.01 - Skin Shortcuts v3 picker fix

Fixes:
- Replaces the removed Skin Shortcuts v2 call: type=shortcuts + skinList.
- Uses the supported Skin Shortcuts v3 standalone picker: type=skinstring.
- Reads the selected path from skinPath and the display name from skinLabel.
- Uses comma-separated RunScript arguments required by the v3 entry point.
- Correctly distinguishes Cancel from selecting None; None writes noop.
- Keeps manual path entry and MediaHub default restore unchanged.
- Updates the KPM service log version to 0.2.01.

Target:
skin.arctic.fuse.3/1080i/Includes_Defaults.xml
variable Defs_ScreensaverWidget

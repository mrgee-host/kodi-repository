Kodi Patch Manager 0.1.89

- Adds a panel-wide AF3 transition gate around Info_Panel so clearlogo/title, top info line, plot and lower rating row are hidden during an item identity transition and committed together after a coherent canonical item is stable.
- Canonical resolver chooses one ListItem/container source and never mixes Steam properties from one item with movie ratings from another.
- Game row invariant is Steam -> Metacritic -> Achievement.
- Series status icon uses native AF3 $VAR[Image_$PARAM[service]_Status]. Ends-at continues to use KPM ends.png.
- Screensaver status uses AF3 Image_ListItem_Status and keeps the proven 54px / centertop 332 geometry.
- Fast visual polling is 0.05s. Stable commit requires 4 coherent polls and at least 0.15s.
- Live diagnostic samples every 60ms and writes changed states plus one heartbeat per second. It records canonical source, panel gate, native clearlogo/title/plot identities, row generation and game slot order.

Kodi Patch Manager 0.1.95

- Adds 505 exact-unique local logos: 374 movie/series studios and 131 game developers/publishers.
- Removes ChatGPT Image Jul 11, 2026, 02_46_44 PM (2).png entirely.
- Movie/TV provider order per candidate: resource.images.studios.coloured -> KPM local studio.
- Game provider order per candidate: KPM local game -> resource.images.gamestudios.grayscale.
- Candidate order remains movie studio/network order; games remain all developer candidates before publisher candidates.
- Specific/regional keys are checked before generic fallbacks.
- Single rendered logo remains KPM.StudioLogo.1.
- No changes to fanart, clearlogo, plot, metadata databases, rating row, LRS, MediaHub, Steam Library, or LAC.

KPM 0.1.85 repairs malformed Includes_Info.xml caused by 0.1.84 native row removal, then reapplies KPM-owned AF3 rating/game row with safer complete-block cleanup.

Kodi Patch Manager 0.2.00 - Selectable Screensaver Widget Path

Base: clean 0.1.98. The incorrect screenshot-folder experiment is not included.

Changes:
- KPM Settings opens the native script.skinshortcuts Shortcuts selector shown by AF3.
- Selected skinList/content path is saved in KPM runtime/state/settings.json.
- The path is applied only to AF3 Includes_Defaults.xml -> Defs_ScreensaverWidget.
- XML ampersands are escaped safely.
- The current AF3 path is adopted when no KPM choice has been saved.
- Manual path entry, MediaHub default restore, and explicit re-apply are available.
- Default: plugin://plugin.video.mediahub.widget/?mode=mix&limit=100&random=true
- Skin reload is offered after a path change.

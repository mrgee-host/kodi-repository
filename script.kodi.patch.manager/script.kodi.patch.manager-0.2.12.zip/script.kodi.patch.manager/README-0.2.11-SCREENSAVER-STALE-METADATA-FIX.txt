Kodi Patch Manager 0.2.11
=============================

Observed in the supplied recording:
- Dark Souls III entered while Coffee Talk metadata still remained.
- Prey entered while Dark Souls III metadata still remained.

Cause:
The two alternating metadata panels had a 400 ms Visible fade and no explicit
Hidden animation. Kodi reverses the Visible fade when hiding the old panel.

Fix:
- Incoming panel: fade in 400 ms, unchanged.
- Outgoing panel: explicit Hidden fade of 1 ms.
- Applies to clearlogo/title, ratings, and plot together.
- Marker-scoped and idempotent.

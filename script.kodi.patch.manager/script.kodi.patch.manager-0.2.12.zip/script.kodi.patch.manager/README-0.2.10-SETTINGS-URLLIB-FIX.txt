Kodi Patch Manager 0.2.10
=============================

Fixes KPM Settings crashing with:

NameError: name 'urllib' is not defined

KPM 0.2.09 added MediaHub path normalization using urllib.parse.urlsplit(),
parse_qsl(), urlencode(), and urlunsplit(), but the urllib.parse module itself
was not imported.

No patch behavior was otherwise changed.

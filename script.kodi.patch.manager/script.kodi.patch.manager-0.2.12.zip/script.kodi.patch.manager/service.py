# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import hashlib
import random
import os
import re
import sqlite3
import time
import traceback
import xml.etree.ElementTree as ET
from urllib.parse import unquote

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # pragma: no cover outside Kodi
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

ADDON_ID = 'script.kodi.patch.manager'
ADDON_NAME = 'Kodi Patch Manager'
ACTIVE_PROP = 'KPM.Service.Active.v0184'
ARMED_PROP = 'KPM.ResumeCloseService.Armed'
ARMED_DIALOG_PROP = 'KPM.ResumeCloseService.ArmedDialogId'
PAUSE_SINCE_PROP = 'KPM.ResumeCloseService.PauseSince'
LAST_FOREIGN_DIALOG_PROP = 'KPM.ResumeCloseService.LastForeignDialogId'
LOG_PREFIX = '[Kodi Patch Manager Service v0.2.12] '

NO_DIALOG_ID = 9999
KNOWN_OSD_DIALOG_IDS = {9999, 12901, 10142}
AUTO_OPEN_GRACE_SECONDS = 0.0
STARTUP_AUTO_DIALOG_GUARD_SECONDS = 0.85
STARTUP_GUARD_WINDOW_SECONDS = 3.0
# Responsive timing restored from KPM 0.2.05.
# Stable-state tracking remains for deduplicated DEBUG diagnostics only.
# It no longer delays automatic VideoOSD actions.
KPM_WAIT_FAST_SECONDS = 0.05
KPM_WAIT_ACTIVE_SECONDS = 0.20
KPM_WAIT_PLAYBACK_SECONDS = 0.25
KPM_WAIT_IDLE_SECONDS = 1.00
KPM_WAIT_DEEP_IDLE_SECONDS = 5.00
GUI_STATE_STABLE_SECONDS = 0.35
STUDIO_RESOURCE_ID = 'resource.images.studios.coloured'
GAME_STUDIO_RESOURCE_ID = 'resource.images.gamestudios.grayscale'
KPM_LOGO_RESOURCE_ID = 'resource.images.kpm.studiologos'
KPM_ROW_SCHEMA_VERSION = '0198'
KPM_ROW_SCHEMA_PROP = 'KPM.RatingRow.SchemaVersion'
STEAM_LIBRARY_DB = 'special://profile/addon_data/plugin.program.steam.library/steam_library.db'
_KPM_STEAM_ROW_CACHE = {'mtime': None, 'rows': {}}
LOCAL_STUDIO_KIND = 'studio'
LOCAL_GAME_STUDIO_KIND = 'game'
STUDIO_PROP_PREFIX = 'KPM.StudioLogo.'
STUDIO_NAME_PROP_PREFIX = 'KPM.StudioLogoName.'
STUDIO_COUNT_PROP = 'KPM.StudioLogos.Count'
STUDIO_AVAILABLE_PROP = 'KPM.StudioLogos.Available'
STUDIO_STATUS_PROP = 'KPM.StudioLogos.Status'
STUDIO_CANDIDATES_PROP = 'KPM.StudioLogos.Candidates'
STUDIO_RESOLVED_PROP = 'KPM.StudioLogos.Resolved'
STUDIO_MISSING_PROP = 'KPM.StudioLogos.Missing'
STUDIO_UPDATED_AT_PROP = 'KPM.StudioLogos.UpdatedAt'
STUDIO_SHOW_PROP = 'KPM.StudioLogos.Show'
STUDIO_CONTEXT_PROP = 'KPM.StudioLogos.Context'
STUDIO_CACHE_PROP = 'KPM.StudioLogos.Cache'
GAME_STUDIO_AVAILABLE_PROP = 'KPM.StudioLogos.GameAvailable'
GAME_STUDIO_STATUS_PROP = 'KPM.StudioLogos.GameStatus'
GAME_STUDIO_CACHE_PROP = 'KPM.StudioLogos.GameCache'
GAME_STUDIO_INDEX_BUILD_MS_PROP = 'KPM.StudioLogos.GameIndexBuildMs'
STUDIO_INDEX_BUILD_MS_PROP = 'KPM.StudioLogos.IndexBuildMs'
STUDIO_RESOLVE_LAST_MS_PROP = 'KPM.StudioLogos.ResolveLastMs'
STUDIO_RESOLVE_MAX_MS_PROP = 'KPM.StudioLogos.ResolveMaxMs'
STUDIO_RESOLVE_COUNT_PROP = 'KPM.StudioLogos.ResolveCount'
STUDIO_BROKEN_SKIPPED_PROP = 'KPM.StudioLogos.BrokenSkipped'
STUDIO_DEBUG_PROP = 'KPM.StudioLogos.Debug'
STUDIO_SOURCE_PROP = 'KPM.StudioLogos.Source'
STUDIO_EPISODE_PARENT_SHOW_ID_PROP = 'KPM.StudioLogos.EpisodeParentShowId'
STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP = 'KPM.StudioLogos.EpisodeParentShowTitle'
STUDIO_DB_LOOKUP_LAST_MS_PROP = 'KPM.StudioLogos.DBLookupLastMs'
STUDIO_DB_LOOKUP_COUNT_PROP = 'KPM.StudioLogos.DBLookupCount'
STUDIO_LAST_MEDIA_LABEL_PROP = 'KPM.StudioLogos.LastMediaLabel'
STUDIO_LAST_MEDIA_DBID_PROP = 'KPM.StudioLogos.LastMediaDBID'
STUDIO_LAST_MEDIA_DBTYPE_PROP = 'KPM.StudioLogos.LastMediaDBTYPE'
STUDIO_LAST_MEDIA_CANDIDATES_PROP = 'KPM.StudioLogos.LastMediaCandidates'
STUDIO_LAST_MEDIA_RESOLVED_PROP = 'KPM.StudioLogos.LastMediaResolved'
STUDIO_LAST_MEDIA_SOURCE_PROP = 'KPM.StudioLogos.LastMediaSource'
STUDIO_LAST_MEDIA_UPDATED_AT_PROP = 'KPM.StudioLogos.LastMediaUpdatedAt'
STUDIO_RESOLVED_PROVIDER_PROP = 'KPM.StudioLogos.ResolvedProvider'
LOCAL_STUDIO_AVAILABLE_PROP = 'KPM.StudioLogos.LocalStudioAvailable'
LOCAL_GAME_STUDIO_AVAILABLE_PROP = 'KPM.StudioLogos.LocalGameAvailable'
LOCAL_STUDIO_STATUS_PROP = 'KPM.StudioLogos.LocalStudioStatus'
LOCAL_GAME_STUDIO_STATUS_PROP = 'KPM.StudioLogos.LocalGameStatus'
KPM_LOGO_RESOURCE_ID_PROP = 'KPM.StudioLogos.KPMResourceId'
KPM_LOGO_RESOURCE_STATUS_PROP = 'KPM.StudioLogos.KPMResourceStatus'
KPM_LOGO_RESOURCE_XBT_PROP = 'KPM.StudioLogos.KPMResourceXBT'
KPM_LOGO_RESOURCE_MANIFEST_PROP = 'KPM.StudioLogos.KPMResourceManifest'
STUDIO_RESOLVE_INTERVAL_SECONDS = 0.15
STUDIO_EMPTY_CLEAR_SECONDS = 999999.0
BROKEN_STUDIO_TEXTURE_NAMES = {
    'centropolis entertainment.png',
    'dune entertainment.png',
    'gk films.png',
    'thunder road.png',
}



def _is_broken_studio_texture(filename_or_uri: str) -> bool:
    base = os.path.basename(unquote(str(filename_or_uri or '')).replace('\\', '/')).lower().strip()
    return base in BROKEN_STUDIO_TEXTURE_NAMES


def translate(path: str) -> str:
    if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if xbmc and hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return path


def log(message: str, level=None) -> None:
    if xbmc:
        actual_level = xbmc.LOGINFO if level is None else level
        xbmc.log(LOG_PREFIX + message, actual_level)
    else:
        print(LOG_PREFIX + message)


def cond(expression: str) -> bool:
    try:
        return bool(xbmc.getCondVisibility(expression)) if xbmc else False
    except Exception:
        return False


def info(label: str) -> str:
    try:
        return xbmc.getInfoLabel(label).strip() if xbmc else ''
    except Exception:
        return ''


def _safe_int(value, default: int = 0) -> int:
    try:
        text = str(value or '').strip()
        if not text:
            return default
        return int(float(text))
    except Exception:
        return default


def home_prop(name: str) -> str:
    try:
        return xbmcgui.Window(10000).getProperty(name) if xbmcgui else ''
    except Exception:
        return ''


def window_prop(window_id: int, name: str) -> str:
    try:
        return xbmcgui.Window(window_id).getProperty(name).strip() if xbmcgui else ''
    except Exception:
        return ''


def any_window_prop(*names: str) -> str:
    window_ids = []
    for wid in (10000, current_window_id()):
        if isinstance(wid, int) and wid > 0 and wid not in window_ids:
            window_ids.append(wid)
    for wid in window_ids:
        for name in names:
            value = window_prop(wid, name)
            if value:
                return value
    return ''


def set_home_prop(name: str, value: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).setProperty(name, value)
    except Exception:
        pass


def clear_home_prop(name: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).clearProperty(name)
    except Exception:
        pass


def set_current_window_prop(name: str, value: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(current_window_id()).setProperty(name, value)
    except Exception:
        pass


def clear_current_window_prop(name: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(current_window_id()).clearProperty(name)
    except Exception:
        pass


def current_window_id() -> int:
    try:
        return int(xbmcgui.getCurrentWindowId()) if xbmcgui else -1
    except Exception:
        return -1


def current_dialog_id() -> int:
    try:
        return int(xbmcgui.getCurrentWindowDialogId()) if xbmcgui else NO_DIALOG_ID
    except Exception:
        return NO_DIALOG_ID


def addon_data_path(*parts: str) -> str:
    base = translate(f'special://profile/addon_data/{ADDON_ID}')
    return os.path.join(base, *parts)


def state_file(patch_id: str) -> str:
    return addon_data_path('runtime', 'state', f'{patch_id}.json')


def load_json_file(path: str) -> dict:
    with open(path, 'r', encoding='utf-8', errors='replace') as handle:
        return json.load(handle)


def patch_state_enabled(patch_id: str) -> bool:
    return os.path.exists(state_file(patch_id))


def pause_patch_enabled() -> bool:
    path = state_file('vfs_pause_ratings')
    if not os.path.exists(path):
        return False
    try:
        data = load_json_file(path)
        return bool(data.get('auto_videoosd') and data.get('pause_stay_until_resume'))
    except Exception:
        return True


def studio_patch_enabled() -> bool:
    return patch_state_enabled('reliable_studio_logos')


def load_kpm_settings() -> dict:
    data = {'studio_logo_count': 1, 'studio_debug': False}
    path = addon_data_path('settings.json')
    if os.path.exists(path):
        try:
            loaded = load_json_file(path)
            if isinstance(loaded, dict):
                data.update(loaded)
        except Exception:
            pass
    try:
        count = int(data.get('studio_logo_count', 1))
    except Exception:
        count = 1
    data['studio_logo_count'] = 1
    return data


def is_foreign_dialog(active_dialog_id: int) -> bool:
    return active_dialog_id not in KNOWN_OSD_DIALOG_IDS


def close_video_osd_safely() -> None:
    try:
        xbmc.executebuiltin('CancelAlarm(osd_timeout,true)')
        # Kodi naturally returns to the underlying fullscreen window. Forcing
        # a second window activation during closing animation can race focus.
        xbmc.executebuiltin('Dialog.Close(videoosd,true)')
    except Exception:
        log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def _repair_kpm_invalid_window_conditions_0206() -> bool:
    """Remove KPM's old invalid dialogprogress condition from AF3 XML."""
    target = translate(
        'special://home/addons/skin.arctic.fuse.3/1080i/Includes_Info.xml'
    )
    if not os.path.isfile(target):
        return False
    temp = target + '.kpm0206.tmp'
    try:
        with open(target, 'r', encoding='utf-8', errors='replace') as handle:
            source = handle.read()

        token = 'Window.IsVisible(dialogprogress)'
        if token not in source or 'KPM-AF3-RATING-ROW' not in source:
            return False

        updated = source
        updated = updated.replace(
            '', ''
        )
        updated = updated.replace(
            '!Window.IsVisible(dialogprogress) + ', ''
        )
        updated = updated.replace(
            '!Window.IsVisible(dialogprogress)', 'true'
        )
        if updated == source:
            return False

        ET.fromstring(updated)
        with open(temp, 'w', encoding='utf-8', newline='\n') as handle:
            handle.write(updated)
        os.replace(temp, target)
        log(
            'removed invalid dialogprogress condition from KPM-owned '
            'Includes_Info.xml',
            xbmc.LOGDEBUG if xbmc else None,
        )
        return True
    except Exception:
        try:
            if os.path.exists(temp):
                os.remove(temp)
        except Exception:
            pass
        log(
            'AF3 invalid-window-condition repair failed:\n'
            + traceback.format_exc(),
            xbmc.LOGWARNING if xbmc else None,
        )
        return False


def _read_xbt_filenames(path: str) -> list[str]:
    try:
        with open(path, 'rb') as handle:
            data = handle.read()
    except Exception:
        return []
    names = []
    # Kodi XBTF2 texture packs used by the studio resources have a 5-byte magic,
    # a 4-byte little-endian file count, then 304-byte file records with a
    # null-terminated 256-byte filename at the start of each record.
    if data.startswith(b'XBTF2') and len(data) >= 9:
        try:
            count = int.from_bytes(data[5:9], 'little')
            step = 304
            start = 9
            for idx in range(count):
                off = start + idx * step
                raw = data[off:off + 256]
                if not raw:
                    break
                name = raw.split(b'\x00', 1)[0].decode('utf-8', 'ignore').strip()
                if name.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                    names.append(name.replace('\\', '/'))
            if names:
                return names
        except Exception:
            pass
    # Conservative fallback: scan the header/table for image-looking strings.
    for match in re.finditer(rb'([A-Za-z0-9][A-Za-z0-9 _.,&+!\'()\-]{1,180}\.(?:png|jpg|jpeg|webp))\x00', data[:4_000_000], re.I):
        try:
            names.append(match.group(1).decode('utf-8', 'ignore').strip().replace('\\', '/'))
        except Exception:
            pass
    return list(dict.fromkeys(names))


def _walk_resource_images(resource_dir: str) -> list[str]:
    found = []
    for root, _dirs, files in os.walk(resource_dir):
        for filename in files:
            if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                rel = os.path.relpath(os.path.join(root, filename), resource_dir).replace('\\', '/')
                found.append(rel)
    return found


def _strip_ext(name: str) -> str:
    base = os.path.basename(name.replace('\\', '/'))
    return re.sub(r'\.(png|jpg|jpeg|webp)$', '', base, flags=re.I).strip()


def _specific_key(value: str) -> str:
    """Normalize while preserving qualifier words inside parentheses.

    Example: ``Universal Pictures (Spain)`` -> ``universal pictures spain``.
    This key is used before generic fallback keys so a regional logo can win.
    """
    value = unquote(value or '').lower().strip()
    value = value.replace('&', ' and ').replace('+', ' plus ')
    value = value.replace('(', ' ').replace(')', ' ')
    value = re.sub(r'[^a-z0-9]+', ' ', value)
    return re.sub(r'\s+', ' ', value).strip()


def _simple_key(value: str) -> str:
    """Generic normalized key that removes parenthetical qualifiers."""
    value = unquote(value or '').lower().strip()
    value = value.replace('&', ' and ').replace('+', ' plus ')
    value = re.sub(r'\([^)]*\)', ' ', value)
    value = re.sub(r'[^a-z0-9]+', ' ', value)
    value = re.sub(r'\s+', ' ', value).strip()
    return value


_REGION_TOKENS = {
    'africa','america','argentina','asia','australia','austria','belgium','brazil','canada','china','colombia',
    'denmark','europe','finland','france','germany','hong kong','india','indonesia','ireland','italy','japan',
    'korea','latin america','malaysia','mexico','netherlands','new zealand','norway','philippines','poland',
    'portugal','russia','singapore','south africa','south korea','spain','sweden','switzerland','taiwan',
    'thailand','turkey','uk','united kingdom','usa','united states','vietnam','worldwide','emea','apac'
}


def _has_regional_qualifier(value: str) -> bool:
    key = _specific_key(value)
    return any(token in key for token in _REGION_TOKENS)


def _split_studio_label(value: str) -> list[str]:
    value = (value or '').strip()
    if not value:
        return []
    parts = re.split(r'\s+/\s+|\s*\|\s*|\s*;\s*', value)
    return [p.strip() for p in parts if p and p.strip()]


def _drop_company_suffixes(key: str) -> str:
    suffixes = {
        'ltd', 'limited', 'inc', 'llc', 'gmbh', 'ag', 's a', 'sa', 's r l', 'srl',
        'co', 'company', 'corp', 'corporation', 'productions', 'production',
        'pictures', 'picture', 'films', 'film', 'studios', 'studio', 'entertainment'
    }
    parts = key.split()
    while parts and ' '.join(parts[-3:]) in suffixes:
        parts = parts[:-3]
    while parts and ' '.join(parts[-2:]) in suffixes:
        parts = parts[:-2]
    while parts and parts[-1] in suffixes:
        parts = parts[:-1]
    return ' '.join(parts).strip()


_BUILTIN_LOGO_ALIASES = {
    'prime video': 'amazon prime video',
    'amazon video': 'amazon prime video',
    'fox searchlight': 'fox searchlight pictures',
    'searchlight': 'searchlight pictures',
    'lucasfilm ltd': 'lucasfilm',
    'ea': 'electronic arts',
    'ea games': 'electronic arts',
    'ea sports': 'electronic arts',
    'rockstar games inc': 'rockstar games',
    'rockstar north ltd': 'rockstar north',
    'valve': 'valve corporation',
    'valve software': 'valve corporation',
    'microsoft studios': 'microsoft game studios',
    'sony interactive entertainment': 'playstation',
    'sony interactive entertainment llc': 'playstation',
    'bethesda softworks': 'bethesda',
    'bethesda softworks llc': 'bethesda',
    'square enix ltd': 'square enix',
    'square enix inc': 'square enix',
    'square enix co ltd': 'square enix',
}


def _logo_key_tiers(name: str) -> tuple[list[str], list[str]]:
    """Return (specific keys, generic fallback keys), in lookup order."""
    raw = unquote(_strip_ext(name)).strip()
    specific: list[str] = []
    generic: list[str] = []

    def add(bucket: list[str], value: str) -> None:
        value = (value or '').strip()
        if value and value not in bucket:
            bucket.append(value)

    exact = _specific_key(raw)
    broad = _simple_key(raw)
    add(specific, exact)
    if broad and broad != exact:
        add(generic, broad)
    elif broad:
        add(specific, broad)

    # Company-suffix fallback, but keep the exact regional qualifier tier first.
    short_exact = _drop_company_suffixes(exact)
    short_broad = _drop_company_suffixes(broad)
    if short_exact and short_exact != exact:
        add(specific, short_exact)
    if short_broad and short_broad not in specific:
        add(generic, short_broad)

    for key in list(specific) + list(generic):
        alias = _BUILTIN_LOGO_ALIASES.get(key)
        if alias:
            add(generic, alias)
            alias_short = _drop_company_suffixes(alias)
            if alias_short and alias_short != alias:
                add(generic, alias_short)
    return specific, generic


def _logo_keys(name: str) -> list[str]:
    specific, generic = _logo_key_tiers(name)
    return specific + generic


def _index_key_entries(filename: str) -> list[tuple[str, int]]:
    """Build indexed keys with scores; lower is better for the same key.

    Regional variants get an exact regional key. They do not claim the generic
    company key, preventing generic metadata from selecting an arbitrary region.
    """
    clean = filename.replace('\\', '/')
    stem = _strip_ext(clean)
    entries: list[tuple[str, int]] = []
    seen = set()

    def add(key: str, score: int) -> None:
        if key and key not in seen:
            seen.add(key)
            entries.append((key, score))

    specific = _specific_key(stem)
    generic = _simple_key(stem)
    path_parts = [p for p in clean.split('/')[:-1] if p and p.lower() not in ('resources','media','studio','game','logos','studio-logos')]
    path_context = ' '.join(path_parts[-2:])
    context_specific = _specific_key(path_context)
    regional = _has_regional_qualifier(stem) or _has_regional_qualifier(path_context)
    subfolder_penalty = 5 if path_parts else 0

    add(specific, subfolder_penalty)
    if context_specific:
        add(_specific_key(f'{stem} {context_specific}'), 1 + subfolder_penalty)
        add(_specific_key(f'{context_specific} {stem}'), 2 + subfolder_penalty)

    short_specific = _drop_company_suffixes(specific)
    if short_specific and short_specific != specific:
        add(short_specific, 8 + subfolder_penalty)

    if generic and generic != specific and not regional:
        add(generic, 20 + subfolder_penalty)
        short_generic = _drop_company_suffixes(generic)
        if short_generic and short_generic != generic:
            add(short_generic, 28 + subfolder_penalty)
    elif generic == specific:
        add(generic, subfolder_penalty)
        short_generic = _drop_company_suffixes(generic)
        if short_generic and short_generic != generic:
            add(short_generic, 8 + subfolder_penalty)
    return entries


def _studio_index_cache_path(resource_id: str = STUDIO_RESOURCE_ID) -> str:
    suffix = 'gamestudios-grayscale-v2' if resource_id == GAME_STUDIO_RESOURCE_ID else 'coloured-v3'
    return addon_data_path('cache', f'studio-logo-index-{suffix}.json')


def _set_index_status_props(resource_id: str, *, file_count: int = 0, status: str = '', cache: str = '', build_ms: str = '', broken_skipped: int | None = None) -> None:
    if resource_id == GAME_STUDIO_RESOURCE_ID:
        set_home_prop(GAME_STUDIO_AVAILABLE_PROP, str(file_count))
        if status:
            set_home_prop(GAME_STUDIO_STATUS_PROP, status)
        if cache:
            set_home_prop(GAME_STUDIO_CACHE_PROP, cache)
        if build_ms:
            set_home_prop(GAME_STUDIO_INDEX_BUILD_MS_PROP, build_ms)
        return
    set_home_prop(STUDIO_AVAILABLE_PROP, str(file_count))
    if status:
        set_home_prop(STUDIO_STATUS_PROP, status)
    if cache:
        set_home_prop(STUDIO_CACHE_PROP, cache)
    if build_ms:
        set_home_prop(STUDIO_INDEX_BUILD_MS_PROP, build_ms)
    if broken_skipped is not None:
        set_home_prop(STUDIO_BROKEN_SKIPPED_PROP, str(broken_skipped))


def _file_signature(path: str) -> dict:
    try:
        return {
            'path': path,
            'size': int(os.path.getsize(path)),
            'mtime': float(os.path.getmtime(path)),
        }
    except Exception:
        return {'path': path, 'size': -1, 'mtime': -1.0}


def _load_cached_studio_index(texture_path: str, resource_id: str = STUDIO_RESOURCE_ID) -> dict[str, str]:
    cache_path = _studio_index_cache_path(resource_id)
    if not os.path.exists(cache_path):
        return {}
    try:
        data = load_json_file(cache_path)
        if not isinstance(data, dict):
            return {}
        if data.get('resource_id') != resource_id:
            return {}
        if data.get('texture_signature') != _file_signature(texture_path):
            return {}
        index = data.get('index')
        if not isinstance(index, dict):
            return {}
        _set_index_status_props(
            resource_id,
            file_count=int(data.get('file_count', 0)),
            status='ready',
            cache='hit',
            build_ms='0',
            broken_skipped=int(data.get('broken_skipped', 0)),
        )
        log(f'studio logo index cache hit; resource={resource_id}; files={data.get("file_count", 0)}, keys={len(index)}')
        return {str(k): str(v) for k, v in index.items()}
    except Exception:
        return {}


def _save_cached_studio_index(texture_path: str, filenames_count: int, index: dict[str, str], broken_skipped: int, resource_id: str = STUDIO_RESOURCE_ID) -> None:
    cache_path = _studio_index_cache_path(resource_id)
    try:
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        payload = {
            'resource_id': resource_id,
            'generated': time.strftime('%Y-%m-%d %H:%M:%S'),
            'texture_signature': _file_signature(texture_path),
            'file_count': filenames_count,
            'key_count': len(index),
            'broken_skipped': broken_skipped,
            'index': index,
        }
        with open(cache_path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, separators=(',', ':'))
    except Exception:
        pass


def build_studio_logo_index(resource_id: str = STUDIO_RESOURCE_ID) -> dict[str, str]:
    started = time.time()
    addon_dir = translate(f'special://home/addons/{resource_id}')
    resource_dir = os.path.join(addon_dir, 'resources')
    texture_path = os.path.join(resource_dir, 'Textures.xbt')
    cached = _load_cached_studio_index(texture_path, resource_id)
    if cached:
        return cached

    filenames = []
    if os.path.exists(texture_path):
        filenames.extend(_read_xbt_filenames(texture_path))
    if os.path.isdir(resource_dir):
        filenames.extend(_walk_resource_images(resource_dir))
    filenames = list(dict.fromkeys(filenames))
    ranked: dict[str, tuple[int, str]] = {}
    broken_skipped = 0
    for filename in filenames:
        clean = filename.replace('\\', '/')
        if _is_broken_studio_texture(clean):
            broken_skipped += 1
            continue
        uri = f'resource://{resource_id}/{clean}'
        for key, score in _index_key_entries(clean):
            old = ranked.get(key)
            if old is None or score < old[0]:
                ranked[key] = (score, uri)
    index = {key: uri for key, (_score, uri) in ranked.items()}
    elapsed_ms = int((time.time() - started) * 1000)
    _set_index_status_props(
        resource_id,
        file_count=len(filenames),
        status='ready' if index else 'no-resource',
        cache='rebuilt',
        build_ms=str(elapsed_ms),
        broken_skipped=broken_skipped,
    )
    _save_cached_studio_index(texture_path, len(filenames), index, broken_skipped, resource_id)
    log(f'studio logo index ready; resource={resource_id}; files={len(filenames)}, keys={len(index)}, skipped_broken={broken_skipped}, build_ms={elapsed_ms}')
    return index



def _kpm_logo_resource_paths() -> tuple[str, str, str, str]:
    addon_dir = translate(f'special://home/addons/{KPM_LOGO_RESOURCE_ID}')
    resource_dir = os.path.join(addon_dir, 'resources')
    return (
        addon_dir,
        os.path.join(resource_dir, 'Textures.xbt'),
        os.path.join(resource_dir, 'manifest.json'),
        os.path.join(resource_dir, 'aliases.json'),
    )


def _load_json_dict(path: str) -> dict:
    try:
        with open(path, 'r', encoding='utf-8-sig') as handle:
            data = json.load(handle)
        return data if isinstance(data, dict) else {}
    except Exception:
        return {}


def build_kpm_resource_logo_index(kind: str) -> dict[str, str]:
    """Build one in-memory name->resource URI map from the KPM XBTF2 pack.

    The XBT is never searched on each focus change. At service startup this
    function reads the manifest (or XBT filename table as fallback), applies
    aliases, and returns a dictionary used by the focus resolver.
    """
    if kind not in (LOCAL_STUDIO_KIND, LOCAL_GAME_STUDIO_KIND):
        return {}
    started = time.time()
    addon_dir, texture_path, manifest_path, aliases_path = _kpm_logo_resource_paths()
    status_prop = LOCAL_GAME_STUDIO_STATUS_PROP if kind == LOCAL_GAME_STUDIO_KIND else LOCAL_STUDIO_STATUS_PROP
    available_prop = LOCAL_GAME_STUDIO_AVAILABLE_PROP if kind == LOCAL_GAME_STUDIO_KIND else LOCAL_STUDIO_AVAILABLE_PROP
    set_home_prop(KPM_LOGO_RESOURCE_ID_PROP, KPM_LOGO_RESOURCE_ID)
    set_home_prop(KPM_LOGO_RESOURCE_XBT_PROP, texture_path)
    set_home_prop(KPM_LOGO_RESOURCE_MANIFEST_PROP, manifest_path)
    if not os.path.isdir(addon_dir) or not os.path.isfile(texture_path):
        set_home_prop(status_prop, 'missing-resource-addon')
        set_home_prop(available_prop, '0')
        set_home_prop(KPM_LOGO_RESOURCE_STATUS_PROP, 'missing')
        return {}

    manifest = _load_json_dict(manifest_path)
    aliases_all = _load_json_dict(aliases_path)
    filenames: list[str] = []
    entries = manifest.get('files') if isinstance(manifest, dict) else None
    if isinstance(entries, list):
        for entry in entries:
            if isinstance(entry, dict):
                path = str(entry.get('path') or '').replace('\\', '/').lstrip('/').lower()
                if path:
                    filenames.append(path)
    if not filenames:
        filenames = [str(x).replace('\\', '/').lstrip('/').lower() for x in _read_xbt_filenames(texture_path)]
    filenames = list(dict.fromkeys(filenames))
    prefix = kind + '/'
    kind_files = [name for name in filenames if name.startswith(prefix) and name.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))]
    target_set = set(kind_files)
    ranked: dict[str, tuple[int, str]] = {}
    for clean in kind_files:
        uri = f'resource://{KPM_LOGO_RESOURCE_ID}/{clean}'
        for key, score in _index_key_entries(clean):
            old = ranked.get(key)
            if old is None or score < old[0]:
                ranked[key] = (score, uri)

    aliases = aliases_all.get(kind, {}) if isinstance(aliases_all, dict) else {}
    if isinstance(aliases, dict):
        for alias_name, target in aliases.items():
            target = str(target or '').replace('\\', '/').lstrip('/').lower()
            if not target.startswith(prefix):
                target = prefix + target
            if target not in target_set:
                continue
            uri = f'resource://{KPM_LOGO_RESOURCE_ID}/{target}'
            specific, generic = _logo_key_tiers(str(alias_name))
            for pos, key in enumerate(specific + generic):
                score = 3 + pos
                old = ranked.get(key)
                if old is None or score < old[0]:
                    ranked[key] = (score, uri)

    index = {key: uri for key, (_score, uri) in ranked.items()}
    elapsed_ms = int((time.time() - started) * 1000)
    set_home_prop(available_prop, str(len(kind_files)))
    set_home_prop(status_prop, 'ready-xbt' if index else 'empty-xbt')
    set_home_prop(KPM_LOGO_RESOURCE_STATUS_PROP, 'ready' if index else 'empty')
    log(f'KPM XBT logo index ready; kind={kind}; files={len(kind_files)}, keys={len(index)}, build_ms={elapsed_ms}')
    return index


def _resolve_logo_candidate(name: str, providers: list[tuple[str, dict[str, str]]]) -> tuple[str, str]:
    """Resolve exact/specific tier first, then generic fallback tier.

    Provider order is honored inside each tier. This lets a KPM-local regional
    logo beat a generic provider logo while still preserving the requested
    provider priority for equivalent matches.
    """
    specific, generic = _logo_key_tiers(name)
    for keys in (specific, generic):
        for provider_name, index in providers:
            if not index:
                continue
            for key in keys:
                uri = index.get(key, '')
                if uri:
                    return uri, provider_name
    return '', ''


def _latest_video_db_path() -> str:
    db_dir = translate('special://profile/Database')
    if not os.path.isdir(db_dir):
        db_dir = translate('special://database')
    if not os.path.isdir(db_dir):
        return ''
    best_path = ''
    best_num = -1
    try:
        for fname in os.listdir(db_dir):
            match = re.match(r'MyVideos(\d+)\.db$', fname, re.I)
            if not match:
                continue
            num = int(match.group(1))
            if num > best_num:
                best_num = num
                best_path = os.path.join(db_dir, fname)
    except Exception:
        return ''
    return best_path


def _episode_contexts() -> list[tuple[str, int]]:
    contexts: list[tuple[str, int]] = []
    for prefix in ('ListItem', 'Container.ListItem', 'VideoPlayer'):
        dbtype = (info(f'{prefix}.DBTYPE') or '').lower().strip()
        dbid = _safe_int(info(f'{prefix}.DBID'))
        is_episode = dbtype == 'episode'
        if prefix == 'VideoPlayer' and not is_episode and cond('VideoPlayer.Content(episodes)'):
            is_episode = True
        if dbid > 0 and is_episode:
            contexts.append((prefix, dbid))
    seen = set()
    deduped = []
    for prefix, dbid in contexts:
        if dbid not in seen:
            seen.add(dbid)
            deduped.append((prefix, dbid))
    return deduped


def _media_contexts() -> list[tuple[str, str, int, str]]:
    contexts: list[tuple[str, str, int, str]] = []
    for prefix in ('ListItem', 'Container.ListItem', 'VideoPlayer'):
        dbtype = (info(f'{prefix}.DBTYPE') or '').lower().strip()
        dbid = _safe_int(info(f'{prefix}.DBID'))
        label = info(f'{prefix}.Label') if prefix != 'VideoPlayer' else info('VideoPlayer.Title')
        if prefix == 'VideoPlayer' and not dbtype:
            if cond('VideoPlayer.Content(movies)'):
                dbtype = 'movie'
            elif cond('VideoPlayer.Content(tvshows)'):
                dbtype = 'tvshow'
            elif cond('VideoPlayer.Content(episodes)'):
                dbtype = 'episode'
        if dbid > 0 and dbtype in ('movie', 'tvshow', 'episode', 'season', 'set'):
            contexts.append((prefix, dbtype, dbid, label))
    seen = set()
    deduped = []
    for item in contexts:
        key = (item[1], item[2])
        if key not in seen:
            seen.add(key)
            deduped.append(item)
    return deduped


def _set_last_media_props(candidates: list[str], resolved: list[tuple]) -> None:
    contexts = _media_contexts()
    label = dbtype = dbid = ''
    if contexts:
        _prefix, dbtype, dbid_int, label = contexts[0]
        dbid = str(dbid_int)
    else:
        game_contexts = _game_contexts()
        if game_contexts:
            gctx = game_contexts[0]
            label = gctx.get('label', '')
            dbtype = 'game'
            dbid = gctx.get('appid', '')
    source = home_prop(STUDIO_SOURCE_PROP)
    set_home_prop(STUDIO_LAST_MEDIA_LABEL_PROP, label)
    set_home_prop(STUDIO_LAST_MEDIA_DBID_PROP, dbid)
    set_home_prop(STUDIO_LAST_MEDIA_DBTYPE_PROP, dbtype)
    set_home_prop(STUDIO_LAST_MEDIA_CANDIDATES_PROP, ' | '.join(candidates[:20]))
    set_home_prop(STUDIO_LAST_MEDIA_RESOLVED_PROP, ' | '.join([f'{item[0]} => {item[1]}' for item in resolved[:1]]))
    set_home_prop(STUDIO_LAST_MEDIA_SOURCE_PROP, source)
    set_home_prop(STUDIO_LAST_MEDIA_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))


def _load_media_studios(media_type: str, media_id: int, media_cache: dict[tuple[str, int], dict], stats: dict | None = None) -> dict:
    if media_type not in ('movie', 'tvshow') or media_id <= 0:
        return {'media_type': media_type, 'media_id': media_id, 'studios': [], 'source': 'invalid_media'}
    key = (media_type, media_id)
    cached = media_cache.get(key)
    if cached is not None:
        return cached
    started = time.time()
    result = {'media_type': media_type, 'media_id': media_id, 'studios': [], 'source': f'{media_type}_db'}
    db_path = _latest_video_db_path()
    if not db_path or not os.path.exists(db_path):
        result['source'] = 'no_video_db'
        media_cache[key] = result
        return result
    try:
        con = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=0.15)
        cur = con.cursor()
        try:
            studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type=? AND sl.media_id=? ORDER BY sl.rowid", (media_type, media_id)) if r and r[0]]
        except Exception:
            studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type=? AND sl.media_id=?", (media_type, media_id)) if r and r[0]]
        result['studios'] = studios
        if not studios:
            result['source'] = f'{media_type}_db_no_studio'
        con.close()
    except Exception as exc:
        result['source'] = 'db_error'
        result['error'] = str(exc)
    elapsed_ms = int((time.time() - started) * 1000)
    set_home_prop(STUDIO_DB_LOOKUP_LAST_MS_PROP, str(elapsed_ms))
    if stats is not None:
        stats['db_lookup_count'] = int(stats.get('db_lookup_count', 0)) + 1
        set_home_prop(STUDIO_DB_LOOKUP_COUNT_PROP, str(stats['db_lookup_count']))
    media_cache[key] = result
    if len(media_cache) > 500:
        for old_key in list(media_cache.keys())[:100]:
            media_cache.pop(old_key, None)
    return result


def _load_parent_tvshow_studios_for_episode(episode_id: int, episode_cache: dict[int, dict], stats: dict | None = None) -> dict:
    if episode_id <= 0:
        return {'episode_id': episode_id, 'id_show': 0, 'show_title': '', 'studios': [], 'source': 'invalid_episode_id'}
    cached = episode_cache.get(episode_id)
    if cached is not None:
        return cached

    started = time.time()
    result = {'episode_id': episode_id, 'id_show': 0, 'show_title': '', 'studios': [], 'source': 'parent_tvshow_db'}
    db_path = _latest_video_db_path()
    if not db_path or not os.path.exists(db_path):
        result['source'] = 'no_video_db'
        episode_cache[episode_id] = result
        return result
    try:
        con = sqlite3.connect(f'file:{db_path}?mode=ro', uri=True, timeout=0.15)
        cur = con.cursor()
        row = cur.execute('SELECT e.idShow, COALESCE(t.c00, \'\') FROM episode e LEFT JOIN tvshow t ON t.idShow=e.idShow WHERE e.idEpisode=?', (episode_id,)).fetchone()
        if not row:
            result['source'] = 'episode_not_found'
        else:
            id_show = int(row[0] or 0)
            result['id_show'] = id_show
            result['show_title'] = row[1] or ''
            if id_show > 0:
                try:
                    studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type='tvshow' AND sl.media_id=? ORDER BY sl.rowid", (id_show,)) if r and r[0]]
                except Exception:
                    studios = [r[0] for r in cur.execute("SELECT s.name FROM studio_link sl JOIN studio s ON s.studio_id=sl.studio_id WHERE sl.media_type='tvshow' AND sl.media_id=?", (id_show,)) if r and r[0]]
                result['studios'] = studios
                if not studios:
                    result['source'] = 'parent_tvshow_no_studio'
        con.close()
    except Exception as exc:
        result['source'] = 'db_error'
        result['error'] = str(exc)
    elapsed_ms = int((time.time() - started) * 1000)
    set_home_prop(STUDIO_DB_LOOKUP_LAST_MS_PROP, str(elapsed_ms))
    if stats is not None:
        stats['db_lookup_count'] = int(stats.get('db_lookup_count', 0)) + 1
        set_home_prop(STUDIO_DB_LOOKUP_COUNT_PROP, str(stats['db_lookup_count']))
    episode_cache[episode_id] = result
    # Keep the cache bounded because focus can move through many episode widgets.
    if len(episode_cache) > 500:
        for key in list(episode_cache.keys())[:100]:
            episode_cache.pop(key, None)
    return result



def _info_prop(prefix: str, name: str) -> str:
    return info(f'{prefix}.Property({name})')


def _game_contexts() -> list[dict[str, str]]:
    contexts: list[dict[str, str]] = []
    for prefix in ('Container.ListItem', 'ListItem'):
        appid = _info_prop(prefix, 'steam_appid') or _info_prop(prefix, 'appid')
        platform = (_info_prop(prefix, 'platform') or _info_prop(prefix, 'steam_platform')).lower().strip()
        is_steam = (_info_prop(prefix, 'is_steam_library') or '').lower().strip() == 'true'
        dbtype = (info(f'{prefix}.DBTYPE') or '').lower().strip()
        path = info(f'{prefix}.FileNameAndPath') or info(f'{prefix}.FolderPath')
        if not (is_steam or platform == 'steam' or appid or dbtype == 'game' or 'plugin.program.steam.library' in path):
            continue
        label = info(f'{prefix}.Label') or info(f'{prefix}.Title')
        developer = _info_prop(prefix, 'developer') or _info_prop(prefix, 'developer_display')
        publisher = _info_prop(prefix, 'publisher') or _info_prop(prefix, 'publisher_display')
        contexts.append({
            'prefix': prefix,
            'appid': appid,
            'label': label,
            'developer': developer,
            'publisher': publisher,
            'platform': platform or ('steam' if is_steam or appid else ''),
        })
    seen = set()
    deduped = []
    for ctx in contexts:
        key = (ctx.get('appid') or '', _simple_key(ctx.get('label') or ''))
        if key not in seen:
            seen.add(key)
            deduped.append(ctx)
    return deduped


def _split_game_credit_label(value: str) -> list[str]:
    value = (value or '').strip()
    if not value or value.upper() == 'N/A':
        return []
    parts = _split_studio_label(value)
    expanded = []
    for part in parts:
        expanded.append(part)
        # Steam metadata commonly stores multiple developers/publishers as comma
        # separated text. Keep the full credit too so names like "2015, Inc." can
        # still match, but also try each comma piece as a candidate.
        for comma_part in re.split(r'\s*,\s*', part):
            comma_part = comma_part.strip()
            if comma_part and comma_part.upper() != 'N/A':
                expanded.append(comma_part)
    deduped = []
    seen = set()
    for item in expanded:
        key = _simple_key(item)
        if key and key not in seen:
            seen.add(key)
            deduped.append(item)
    return deduped


def collect_game_studio_candidates() -> list[str]:
    contexts = _game_contexts()
    if not contexts:
        return []
    ctx = contexts[0]
    candidates: list[str] = []
    dev_count = 0
    pub_count = 0
    before = len(candidates)
    candidates.extend(_split_game_credit_label(ctx.get('developer', '')))
    dev_count = len(candidates) - before
    before = len(candidates)
    candidates.extend(_split_game_credit_label(ctx.get('publisher', '')))
    pub_count = len(candidates) - before
    deduped = []
    seen = set()
    for item in candidates:
        key = _simple_key(item)
        if key and key not in seen:
            seen.add(key)
            deduped.append(item)
    if dev_count and pub_count:
        source = 'game_developer+publisher'
    elif dev_count:
        source = 'game_developer'
    elif pub_count:
        source = 'game_publisher'
    else:
        source = 'game_no_credit'
    set_home_prop(STUDIO_SOURCE_PROP, source)
    clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_ID_PROP)
    clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP)
    return deduped


def collect_studio_candidates(episode_cache: dict[int, dict] | None = None, stats: dict | None = None, media_cache: dict[tuple[str, int], dict] | None = None) -> list[str]:
    candidates: list[str] = []
    direct_count = 0
    for label in ('Container.ListItem.Studio', 'ListItem.Studio', 'VideoPlayer.Studio'):
        before = len(candidates)
        candidates.extend(_split_studio_label(info(label)))
        direct_count += len(candidates) - before
    for idx in range(1, 11):
        before = len(candidates)
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.ListItem.Studio.{idx}.Name')))
        direct_count += len(candidates) - before
    for idx in range(1, 6):
        before = len(candidates)
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.ListItem.Network.{idx}.Name')))
        direct_count += len(candidates) - before
    for idx in range(1, 6):
        before = len(candidates)
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.Player.Studio.{idx}.Name')))
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.Player.Network.{idx}.Name')))
        direct_count += len(candidates) - before

    db_direct_count = 0
    db_direct_source = ''
    if media_cache is not None:
        for _prefix, dbtype, dbid, _label in _media_contexts():
            if dbtype in ('movie', 'tvshow'):
                db_res = _load_media_studios(dbtype, dbid, media_cache, stats)
                db_direct_source = db_res.get('source', '') or f'{dbtype}_db'
                before = len(candidates)
                candidates.extend(_split_studio_label(' / '.join(db_res.get('studios') or [])))
                db_direct_count += len(candidates) - before
                if db_direct_count:
                    break

    parent_count = 0
    parent_source = ''
    parent_show_id = 0
    parent_show_title = ''
    if episode_cache is not None:
        for prefix, episode_id in _episode_contexts():
            parent = _load_parent_tvshow_studios_for_episode(episode_id, episode_cache, stats)
            parent_source = parent.get('source', '') or 'parent_tvshow_db'
            parent_show_id = int(parent.get('id_show') or 0)
            parent_show_title = parent.get('show_title', '') or ''
            before = len(candidates)
            candidates.extend(_split_studio_label(' / '.join(parent.get('studios') or [])))
            parent_count += len(candidates) - before
            if parent_count:
                break

    deduped = []
    seen = set()
    for item in candidates:
        key = _simple_key(item)
        if key and key not in seen:
            seen.add(key)
            deduped.append(item)

    if direct_count and db_direct_count and parent_count:
        source = 'direct+media_db+parent_tvshow_db'
    elif direct_count and db_direct_count:
        source = 'direct+media_db'
    elif direct_count and parent_count:
        source = 'direct+parent_tvshow_db'
    elif db_direct_count and parent_count:
        source = 'media_db+parent_tvshow_db'
    elif parent_count:
        source = 'parent_tvshow_db'
    elif db_direct_count:
        source = db_direct_source or 'media_db'
    elif direct_count:
        source = 'direct'
    elif parent_source:
        source = parent_source
    else:
        source = 'none'
    set_home_prop(STUDIO_SOURCE_PROP, source)
    if parent_show_id > 0:
        set_home_prop(STUDIO_EPISODE_PARENT_SHOW_ID_PROP, str(parent_show_id))
        set_home_prop(STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP, parent_show_title)
    else:
        clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_ID_PROP)
        clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP)
    return deduped

def resolve_studio_logos(index: dict[str, str], count: int) -> list[tuple[str, str]]:
    resolved: list[tuple[str, str]] = []
    seen_uris = set()
    for name in collect_studio_candidates():
        uri, _provider = _resolve_logo_candidate(name, [('resource_coloured', index)])
        if uri and uri not in seen_uris:
            resolved.append((name, uri))
            seen_uris.add(uri)
        if len(resolved) >= count:
            break
    return resolved


def clear_studio_props() -> None:
    for idx in range(1, 4):
        clear_home_prop(f'{STUDIO_PROP_PREFIX}{idx}')
        clear_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}')
    clear_home_prop(STUDIO_COUNT_PROP)
    clear_home_prop(STUDIO_CANDIDATES_PROP)
    clear_home_prop(STUDIO_RESOLVED_PROP)
    clear_home_prop(STUDIO_MISSING_PROP)
    clear_home_prop(STUDIO_UPDATED_AT_PROP)
    clear_home_prop(STUDIO_SHOW_PROP)
    clear_home_prop(STUDIO_CONTEXT_PROP)
    clear_home_prop(STUDIO_RESOLVE_LAST_MS_PROP)
    clear_home_prop(STUDIO_RESOLVE_MAX_MS_PROP)
    clear_home_prop(STUDIO_RESOLVE_COUNT_PROP)
    clear_home_prop(STUDIO_SOURCE_PROP)
    clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_ID_PROP)
    clear_home_prop(STUDIO_EPISODE_PARENT_SHOW_TITLE_PROP)
    clear_home_prop(STUDIO_DB_LOOKUP_LAST_MS_PROP)
    clear_home_prop(STUDIO_DB_LOOKUP_COUNT_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_LABEL_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_DBID_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_DBTYPE_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_CANDIDATES_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_RESOLVED_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_SOURCE_PROP)
    clear_home_prop(STUDIO_LAST_MEDIA_UPDATED_AT_PROP)
    clear_home_prop(STUDIO_RESOLVED_PROVIDER_PROP)


def update_studio_logo_props(
    index: dict[str, str],
    game_index: dict[str, str] | None,
    kpm_studio_index: dict[str, str] | None,
    kpm_game_index: dict[str, str] | None,
    count: int,
    force: bool = False,
    last_key: str = '',
    empty_since: float = 0.0,
    debug: bool = False,
    stats: dict | None = None,
    episode_cache: dict[int, dict] | None = None,
    media_cache: dict[tuple[str, int], dict] | None = None,
) -> tuple[str, float]:
    started = time.time()
    count = 1
    game_contexts = _game_contexts()
    if game_contexts:
        studios = collect_game_studio_candidates()
        # Game priority: KPM XBTF2 resource, then grayscale resource pack.
        provider_chain = [
            ('kpm_xbt_game', kpm_game_index or {}),
            ('resource_game_grayscale', game_index or {}),
        ]
        active_resource_id = 'game:kpm-xbt>grayscale'
    else:
        studios = collect_studio_candidates(episode_cache, stats, media_cache)
        # Movie/series priority: coloured resource pack, then KPM XBTF2 fallback.
        provider_chain = [
            ('resource_studios_coloured', index or {}),
            ('kpm_xbt_studio', kpm_studio_index or {}),
        ]
        active_resource_id = 'video:coloured>kpm-xbt'
    now = time.time()

    if not studios:
        # No active media context, usually because focus moved into an add-on/menu/dialog.
        # Keep KPM.StudioLogo.1 cached, but hide the furniture logo through a separate
        # visibility flag. This avoids stale logos in non-media menus without clearing
        # the last valid resolved logo needed by diagnostics and quick focus returns.
        set_home_prop(STUDIO_SHOW_PROP, 'false')
        set_home_prop(STUDIO_CONTEXT_PROP, 'non_media')
        set_home_prop(STUDIO_CANDIDATES_PROP, '')
        set_home_prop(STUDIO_RESOLVED_PROP, home_prop(STUDIO_LAST_MEDIA_RESOLVED_PROP))
        set_home_prop(STUDIO_MISSING_PROP, '')
        set_home_prop(STUDIO_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))
        set_home_prop(STUDIO_COUNT_PROP, '1')
        if empty_since <= 0.0:
            empty_since = now
        return last_key, empty_since

    empty_since = 0.0
    key = active_resource_id + '|' + '|'.join(studios) + f'|count={count}'
    if not force and key == last_key:
        # Same focused media after a menu/dialog temporarily hid the footer: do not
        # wait for a later focus change. If a valid logo is already cached, make it
        # visible immediately; otherwise keep it hidden for this media item.
        if home_prop(f'{STUDIO_PROP_PREFIX}1'):
            set_home_prop(STUDIO_SHOW_PROP, 'true')
            set_home_prop(STUDIO_CONTEXT_PROP, 'media_cached_logo')
            if not home_prop(STUDIO_CANDIDATES_PROP):
                set_home_prop(STUDIO_CANDIDATES_PROP, ' | '.join(studios[:20]))
        else:
            set_home_prop(STUDIO_SHOW_PROP, 'false')
            set_home_prop(STUDIO_CONTEXT_PROP, 'media_no_logo')
        return last_key, empty_since

    resolved: list[tuple[str, str, str]] = []
    missing: list[str] = []
    broken: list[str] = []
    seen_uris = set()
    for name in studios:
        uri, provider = _resolve_logo_candidate(name, provider_chain)
        if uri and _is_broken_studio_texture(uri):
            broken.append(name)
            uri = ''
            provider = ''
        if uri:
            if uri not in seen_uris and len(resolved) < count:
                resolved.append((name, uri, provider))
            seen_uris.add(uri)
        else:
            missing.append(name)

    for idx in range(1, 4):
        if idx <= len(resolved):
            name, uri, _provider = resolved[idx - 1]
            set_home_prop(f'{STUDIO_PROP_PREFIX}{idx}', uri)
            set_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}', name)
        else:
            clear_home_prop(f'{STUDIO_PROP_PREFIX}{idx}')
            clear_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}')
    elapsed_ms = int((time.time() - started) * 1000)
    if stats is not None:
        stats['resolve_count'] = int(stats.get('resolve_count', 0)) + 1
        stats['resolve_max_ms'] = max(int(stats.get('resolve_max_ms', 0)), elapsed_ms)
        set_home_prop(STUDIO_RESOLVE_COUNT_PROP, str(stats['resolve_count']))
        set_home_prop(STUDIO_RESOLVE_MAX_MS_PROP, str(stats['resolve_max_ms']))
    set_home_prop(STUDIO_RESOLVE_LAST_MS_PROP, str(elapsed_ms))
    set_home_prop(STUDIO_COUNT_PROP, str(count))
    set_home_prop(STUDIO_SHOW_PROP, 'true' if resolved else 'false')
    set_home_prop(STUDIO_CONTEXT_PROP, 'media_with_logo' if resolved else 'media_no_logo')
    set_home_prop(STUDIO_CANDIDATES_PROP, ' | '.join(studios[:20]))
    set_home_prop(STUDIO_RESOLVED_PROP, ' | '.join([f'{name} => {uri}' for name, uri, _provider in resolved[:3]]))
    set_home_prop(STUDIO_RESOLVED_PROVIDER_PROP, ' | '.join([provider for _name, _uri, provider in resolved[:3]]))
    missing_all = missing[:20]
    if broken:
        missing_all = (missing_all + [f'BROKEN_TEXTURE:{x}' for x in broken])[:20]
    set_home_prop(STUDIO_MISSING_PROP, ' | '.join(missing_all))
    set_home_prop(STUDIO_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))
    if studios:
        _set_last_media_props(studios, resolved)
    if debug:
        if resolved:
            log('studio logos: ' + ' | '.join([f'{name} -> {uri} [{provider}]' for name, uri, provider in resolved]) + f' ({elapsed_ms}ms)')
        elif studios:
            log('studio logos: no valid match; candidates=' + ' | '.join(studios[:6]) + f' ({elapsed_ms}ms)')
    return key, empty_since






# -----------------------------------------------------------------------------
# v0.1.86 - KPM visual row service. Scrapers/providers remain data owners.
# Behavior parity targets:
# - KPM-only AF3 lower row (native AF3/LRS/Steam renderers disabled by XML patch)
# - LRS-style per-source formatting (IMDb/TMDb decimal, RT/Popcorn %, MC integer)
# - Oscar BP icon rule, Top250, awards, EndsAt once only
# - Home/Hub resolver fallbacks: ListItem + Container.ListItem + TMDbHelper properties
# - Steam/MediaHub game row with Steam, MC, achievements, completed/finished
# -----------------------------------------------------------------------------
KPM_ROW_PREFIX = 'KPM.RatingRow.'
KPM_ROW_SLOTS = 10
# AF3 visual containers observed in Home/Hub/Programs. Focus may be on
# buttons/tabs (300/311/312), while visible media lives in 301/50x.
KPM_AF3_MEDIA_CONTAINERS = (301, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 50, 51, 52, 9000)
KPM_LRS_ROW_CACHE = {}
LRS_ADDON_DATA = 'special://profile/addon_data/script.library.ratings.scraper'


def _setting_xml(addon_id: str, setting_id: str, default: str = '') -> str:
    path = translate(f'special://profile/addon_data/{addon_id}/settings.xml')
    if not os.path.exists(path):
        return default
    try:
        text = open(path, 'r', encoding='utf-8-sig', errors='replace').read()
        m = re.search(r'<setting\s+id=["\']%s["\'][^>]*>(.*?)</setting>' % re.escape(setting_id), text, re.I | re.S)
        if m:
            return re.sub(r'<.*?>', '', m.group(1)).strip() or default
        m = re.search(r'<setting\s+id=["\']%s["\'][^>]*value=["\']([^"\']*)["\']' % re.escape(setting_id), text, re.I)
        if m:
            return m.group(1).strip() or default
    except Exception:
        pass
    return default


def _bool_setting(addon_id: str, setting_id: str, default: bool) -> bool:
    return (_setting_xml(addon_id, setting_id, 'true' if default else 'false').strip().lower() in ('true', '1', 'yes', 'on'))


def _int_setting(addon_id: str, setting_id: str, default: int) -> int:
    try:
        return int(_setting_xml(addon_id, setting_id, str(default)))
    except Exception:
        return default


def _clean_value(v) -> str:
    t = str(v or '').strip()
    if not t or t.upper() in ('N/A', 'NA', 'NONE', 'NULL', '-'):
        return ''
    return t


def _truthy(v) -> bool:
    return str(v or '').strip().lower() in ('1', 'true', 'yes', 'on', 'best_picture', 'best-picture', 'bp', 'completed', 'complete', 'finished', 'finish', 'done')


def _percent(v) -> str:
    t = _clean_value(v)
    if not t:
        return ''
    if t.endswith('%'):
        return t
    try:
        f = float(t)
        body = str(int(f)) if f.is_integer() else ('%.1f' % f).rstrip('0').rstrip('.')
        return body + '%'
    except Exception:
        return t


def _decimal_rating(v) -> str:
    t = _clean_value(v)
    if not t:
        return ''
    try:
        return '%.1f' % float(t)
    except Exception:
        return t


def _integer_rating(v) -> str:
    t = _clean_value(v)
    if not t:
        return ''
    try:
        return str(int(round(float(t))))
    except Exception:
        return t


def _first_info(labels) -> str:
    for lab in labels:
        try:
            val = info(lab)
            val = _clean_value(val)
            if val:
                return val
        except Exception:
            pass
    return ''


def _prop_candidates(prop: str):
    labels = [
        f'ListItem.Property({prop})',
        f'Container.ListItem.Property({prop})',
        f'Window.Property({prop})',
    ]
    for cid in KPM_AF3_MEDIA_CONTAINERS:
        labels.append(f'Container({cid}).ListItem.Property({prop})')
    labels.extend([
        f'Window.Property(TMDBHelper.ListItem.{prop})',
        f'Window.Property(TMDbHelper.ListItem.{prop})',
        f'Window.Property(MediaHub.ListItem.{prop})',
        f'Window.Property(SteamLibrary.ListItem.{prop})',
        f'Window(Home).Property(TMDBHelper.ListItem.{prop})',
        f'Window(Home).Property(TMDbHelper.ListItem.{prop})',
        f'Window(Home).Property(MediaHub.ListItem.{prop})',
        f'Window(Home).Property(SteamLibrary.ListItem.{prop})',
        f'Window(Home).Property(LRS.Active.{prop})',
        f'Window.Property(LRS.Active.{prop})',
    ])
    return labels

def _get_prop(*props: str) -> str:
    labels = []
    for prop in props:
        labels.extend(_prop_candidates(prop))
    return _first_info(labels)


def _current_title() -> str:
    labels = [
        'ListItem.Title', 'ListItem.Label',
        'Container.ListItem.Title', 'Container.ListItem.Label',
        'Window.Property(Title)', 'Window.Property(Label)',
        'Window.Property(TMDBHelper.ListItem.Title)', 'Window.Property(TMDbHelper.ListItem.Title)',
        'Window.Property(MediaHub.ListItem.Title)', 'Window.Property(SteamLibrary.ListItem.Title)',
    ]
    for cid in KPM_AF3_MEDIA_CONTAINERS:
        labels.extend([f'Container({cid}).ListItem.Title', f'Container({cid}).ListItem.Label'])
    labels.extend([
        'Window(Home).Property(TMDBHelper.ListItem.Title)', 'Window(Home).Property(TMDbHelper.ListItem.Title)',
        'Window(Home).Property(MediaHub.ListItem.Title)', 'Window(Home).Property(SteamLibrary.ListItem.Title)',
    ])
    return _first_info(labels)

def _current_year() -> str:
    labels = [
        'ListItem.Year', 'Container.ListItem.Year',
        'ListItem.Property(year)', 'Container.ListItem.Property(year)',
        'Window.Property(Year)', 'Window.Property(year)',
        'Window.Property(TMDBHelper.ListItem.Year)', 'Window.Property(TMDbHelper.ListItem.Year)',
        'Window.Property(MediaHub.ListItem.Year)', 'Window.Property(SteamLibrary.ListItem.Year)',
    ]
    for cid in KPM_AF3_MEDIA_CONTAINERS:
        labels.extend([f'Container({cid}).ListItem.Year', f'Container({cid}).ListItem.Property(year)'])
    labels.extend([
        'Window(Home).Property(TMDBHelper.ListItem.Year)', 'Window(Home).Property(TMDbHelper.ListItem.Year)',
        'Window(Home).Property(MediaHub.ListItem.Year)', 'Window(Home).Property(SteamLibrary.ListItem.Year)',
    ])
    return _first_info(labels)

def _is_game_item() -> bool:
    direct = [
        _get_prop('platform', 'steam_platform', 'steam_appid', 'appid', 'is_steam_library', 'lrs_game', 'kpm_item_type', 'library_ratings_type'),
        _first_info(['ListItem.DBType', 'Container.ListItem.DBType', 'ListItem.Property(DBTYPE)', 'Container.ListItem.Property(DBTYPE)', 'ListItem.Property(MediaType)', 'Container.ListItem.Property(MediaType)']),
    ]
    for x in direct:
        low = str(x or '').strip().lower()
        if low in ('steam', 'game', 'games', 'true'):
            return True
        if low and 'steam' in low:
            return True
    return False


def _item_type() -> str:
    if _is_game_item():
        return 'game'
    labels = [
        'ListItem.DBType', 'Container.ListItem.DBType',
        'ListItem.Property(DBTYPE)', 'Container.ListItem.Property(DBTYPE)',
        'ListItem.Property(dbtype)', 'Container.ListItem.Property(dbtype)',
        'ListItem.Property(MediaType)', 'Container.ListItem.Property(MediaType)',
        'ListItem.Property(mediatype)', 'Container.ListItem.Property(mediatype)',
        'ListItem.Property(kpm_item_type)', 'Container.ListItem.Property(kpm_item_type)',
        'Window.Property(DBTYPE)', 'Window.Property(DBType)', 'Window.Property(MediaType)', 'Window.Property(kpm_item_type)',
        'Window.Property(TMDBHelper.ListItem.DBTYPE)', 'Window.Property(TMDbHelper.ListItem.DBTYPE)',
        'Window.Property(MediaHub.ListItem.DBTYPE)', 'Window.Property(SteamLibrary.ListItem.DBTYPE)',
    ]
    for cid in KPM_AF3_MEDIA_CONTAINERS:
        labels.extend([
            f'Container({cid}).ListItem.DBType',
            f'Container({cid}).ListItem.Property(DBTYPE)',
            f'Container({cid}).ListItem.Property(MediaType)',
            f'Container({cid}).ListItem.Property(kpm_item_type)',
        ])
    labels.extend([
        'Window(Home).Property(TMDBHelper.ListItem.DBTYPE)', 'Window(Home).Property(TMDbHelper.ListItem.DBTYPE)',
        'Window(Home).Property(MediaHub.ListItem.DBTYPE)', 'Window(Home).Property(SteamLibrary.ListItem.DBTYPE)',
    ])
    v = _first_info(labels).strip().lower()
    aliases = {'movies': 'movie', 'tvshows': 'tvshow', 'show': 'tvshow', 'series': 'tvshow', 'episodes': 'episode', 'sets': 'set', 'collection': 'set'}
    return aliases.get(v, v)

def _dbid_value() -> str:
    labels = [
        'ListItem.DBID', 'Container.ListItem.DBID',
        'ListItem.Property(DBID)', 'Container.ListItem.Property(DBID)',
        'ListItem.Property(dbid)', 'Container.ListItem.Property(dbid)',
        'Window.Property(DBID)', 'Window.Property(dbid)',
        'Window.Property(TMDBHelper.ListItem.DBID)', 'Window.Property(TMDbHelper.ListItem.DBID)',
        'Window.Property(MediaHub.ListItem.DBID)', 'Window.Property(SteamLibrary.ListItem.DBID)',
    ]
    for cid in KPM_AF3_MEDIA_CONTAINERS:
        labels.extend([f'Container({cid}).ListItem.DBID', f'Container({cid}).ListItem.Property(DBID)', f'Container({cid}).ListItem.Property(dbid)'])
    labels.extend([
        'Window(Home).Property(TMDBHelper.ListItem.DBID)', 'Window(Home).Property(TMDbHelper.ListItem.DBID)',
        'Window(Home).Property(MediaHub.ListItem.DBID)', 'Window(Home).Property(SteamLibrary.ListItem.DBID)',
    ])
    return _first_info(labels)

def _is_collection_or_nonmedia(dbtype: str) -> bool:
    dbtype = (dbtype or '').lower()
    if dbtype in ('set', 'sets', 'collection', 'folder', 'addon', 'program', 'plugin', 'files'):
        return True
    title = (_current_title() or '').strip().lower()
    if title in ('clean video library', 'update video library', 'reload skin', 'my add-ons', 'favourites', 'favorites'):
        return True
    try:
        if cond('ListItem.IsFolder') and not _is_game_item() and dbtype not in ('movie', 'tvshow', 'season', 'episode', 'video'):
            return True
    except Exception:
        pass
    if not dbtype and not _is_game_item():
        return True
    return False


def _game_slots():
    steam = _percent(_get_prop('steam_rating_display', 'steam_review_percent'))
    # steam_rating_display may contain "94% #250"; keep as-is if it contains a rank.
    raw_display = _get_prop('steam_rating_display')
    if raw_display and ('#' in raw_display or '%' in raw_display):
        steam = raw_display
    mc = _integer_rating(_get_prop('metacritic_score'))
    ach = _clean_value(_get_prop('achievement_display'))
    if not ach:
        unlocked = _clean_value(_get_prop('achievement_unlocked'))
        total = _clean_value(_get_prop('achievement_total'))
        if total:
            ach = (unlocked or '0') + '/' + total
    slots = []
    if steam:
        slots.append({'source': 'steam', 'icon': 'steam.png', 'label': steam})
    if mc and mc != '0':
        slots.append({'source': 'metacritic', 'icon': 'metacritic.png', 'label': mc})
    if ach:
        slots.append({'source': 'achievement', 'icon': 'steam-ach.png', 'label': ach})
    # Completed/Finished are poster badges owned by Steam Library. Do not
    # duplicate them in the upper/lower text rating row.
    return slots


def _lrs_db_path() -> str:
    for name in ('ratings-cache.db', 'ratings.db', 'library-ratings.db'):
        p = translate(LRS_ADDON_DATA + '/' + name)
        if os.path.exists(p):
            return p
    return translate(LRS_ADDON_DATA + '/ratings-cache.db')


def _lrs_db_row(dbtype: str, dbid: str, title: str = '', year: str = ''):
    db = _lrs_db_path()
    if not os.path.exists(db):
        return None
    try:
        cache_key = (dbtype, str(dbid or ''), str(title or '').strip().lower(), str(year or ''), os.path.getmtime(db))
        if cache_key in KPM_LRS_ROW_CACHE:
            cached = KPM_LRS_ROW_CACHE.get(cache_key)
            return dict(cached) if isinstance(cached, dict) else cached
    except Exception:
        cache_key = None
    media_types = [dbtype]
    if dbtype == 'season':
        media_types += ['tvshow']
    try:
        conn = sqlite3.connect(db, timeout=0.3)
        conn.row_factory = sqlite3.Row
        try:
            cols = [r[1] for r in conn.execute('PRAGMA table_info(ratings)').fetchall()]
            if dbid and 'dbid' in cols and 'media_type' in cols:
                for mt in media_types:
                    row = conn.execute('SELECT * FROM ratings WHERE media_type=? AND dbid=? LIMIT 1', (mt, str(dbid))).fetchone()
                    if row:
                        result = dict(row)
                        if cache_key is not None:
                            if len(KPM_LRS_ROW_CACHE) > 96:
                                KPM_LRS_ROW_CACHE.clear()
                            KPM_LRS_ROW_CACHE[cache_key] = result
                        return result
            if title and 'title' in cols and 'media_type' in cols:
                title_norm = str(title).strip().lower()
                for mt in media_types:
                    if year and 'year' in cols:
                        row = conn.execute('SELECT * FROM ratings WHERE media_type=? AND lower(title)=? AND CAST(year AS TEXT)=? LIMIT 1', (mt, title_norm, str(year))).fetchone()
                        if row:
                            result = dict(row)
                        if cache_key is not None:
                            if len(KPM_LRS_ROW_CACHE) > 96:
                                KPM_LRS_ROW_CACHE.clear()
                            KPM_LRS_ROW_CACHE[cache_key] = result
                        return result
                    row = conn.execute('SELECT * FROM ratings WHERE media_type=? AND lower(title)=? ORDER BY updated_at DESC LIMIT 1', (mt, title_norm)).fetchone()
                    if row:
                        result = dict(row)
                        if cache_key is not None:
                            if len(KPM_LRS_ROW_CACHE) > 96:
                                KPM_LRS_ROW_CACHE.clear()
                            KPM_LRS_ROW_CACHE[cache_key] = result
                        return result
        finally:
            conn.close()
    except Exception:
        return None
    return None


def _duration_minutes(text: str) -> int:
    t = str(text or '').lower().strip()
    if not t:
        return 0
    h = re.search(r'(\d+)\s*(?:h|hr|hour)', t)
    m = re.search(r'(\d+)\s*(?:m|min)', t)
    if ':' in t and not h and not m:
        parts = [p for p in t.split(':') if p.isdigit()]
        if len(parts) == 2:
            return int(parts[0]) * 60 + int(parts[1])
        if len(parts) == 3:
            return int(parts[0]) * 60 + int(parts[1])
    return (int(h.group(1)) * 60 if h else 0) + (int(m.group(1)) if m else 0)


def _ends_at_label(dbtype: str) -> str:
    if dbtype not in ('movie', 'episode', 'video') and not cond('Window.IsActive(videoosd)'):
        return ''
    v = _first_info(['ListItem.FinishTime', 'ListItem.EndTimeResume', 'VideoPlayer.FinishTime', 'Player.FinishTime'])
    if v and 'ListItem.' not in v and 'Container(' not in v and '$INFO' not in v:
        return 'Ends at ' + v.replace('Ends at', '').strip()
    minutes = _duration_minutes(_first_info(['ListItem.Duration', 'Container.ListItem.Duration', 'VideoPlayer.Duration']))
    if minutes > 0:
        return 'Ends at ' + time.strftime('%H:%M', time.localtime(time.time() + minutes * 60))
    return ''


def _format_lrs_source(source: str, value) -> str:
    if source in ('rt_critic', 'rt_audience'):
        return _percent(value)
    if source in ('imdb', 'tmdb', 'trakt'):
        return _decimal_rating(value)
    if source == 'metacritic':
        return _integer_rating(value)
    return _clean_value(value)


def _lrs_slots(dbtype: str, dbid: str):
    title = _current_title()
    year = _current_year()
    row = _lrs_db_row(dbtype, dbid, title, year)
    if not row:
        return []
    count = max(1, min(6, _int_setting('script.library.ratings.scraper', 'display_rating_slot_count', 3)))
    defaults = ['imdb', 'rt_critic', 'rt_audience', 'metacritic', 'tmdb', 'trakt']
    wanted = [_setting_xml('script.library.ratings.scraper', f'display_rating_slot_{i}', defaults[i - 1] if i - 1 < len(defaults) else 'none') or 'none' for i in range(1, count + 1)]
    colmap = {
        'imdb': ('imdb', 'imdb.png'),
        'tmdb': ('tmdb', 'tmdb.png'),
        'rt_critic': ('rottentomatoes', 'rtfresh.png'),
        'rt_audience': ('rottentomatoes_user', 'popcorn.png'),
        'metacritic': ('metacritic', 'metacritic.png'),
        'trakt': ('trakt', 'trakt.png'),
    }
    slots = []
    for source in wanted:
        if source == 'none' or source not in colmap:
            continue
        col, icon = colmap[source]
        label = _format_lrs_source(source, row.get(col) or '')
        if label:
            if source == 'rt_critic' and 'rotten' in str(row.get('rottentomatoes_image') or '').lower():
                icon = 'rtrotten.png'
            if source == 'rt_audience' and ('spilt' in str(row.get('rottentomatoes_userimage') or '').lower() or 'rotten' in str(row.get('rottentomatoes_userimage') or '').lower()):
                icon = 'popcorn_spilt.png'
            slots.append({'source': source, 'icon': icon, 'label': label})
    if _bool_setting('script.library.ratings.scraper', 'display_top250', True):
        rank = _clean_value(str(row.get('top250') or row.get('imdb_top250') or ''))
        if rank and rank != '0':
            rank_label = '#' + rank.lstrip('#')
            merged = False
            for slot in slots:
                if slot.get('source') == 'imdb':
                    if rank_label not in slot.get('label', ''):
                        slot['label'] = (slot.get('label', '').strip() + ' ' + rank_label).strip()
                    merged = True
                    break
            if not merged:
                slots.append({'source': 'top250', 'icon': 'imdb.png', 'label': rank_label})
    if _bool_setting('script.library.ratings.scraper', 'display_awards', True):
        osc = _clean_value(str(row.get('oscar_wins') or ''))
        em = _clean_value(str(row.get('emmy_wins') or ''))
        if osc and osc != '0':
            icon = 'oscars_bp.png' if _truthy(row.get('oscar_best_picture')) else 'oscars.png'
            slots.append({'source': 'oscars_bp' if icon == 'oscars_bp.png' else 'oscars', 'icon': icon, 'label': 'x' + osc.lstrip('x')})
        if em and em != '0':
            slots.append({'source': 'emmys', 'icon': 'emmys.png', 'label': 'x' + em.lstrip('x')})
    if dbtype in ('tvshow', 'season') and _bool_setting('script.library.ratings.scraper', 'display_tv_status', False):
        status = _clean_value(row.get('series_status') or row.get('status') or '')
        date = _clean_value(row.get('series_status_date') or row.get('status_date') or '')
        if status:
            slots.append({'source': 'tv_status', 'icon': 'ends.png', 'label': (status + (' ' + date if date else '')).strip()})
    ea = _ends_at_label(dbtype)
    if ea:
        slots.append({'source': 'endsat', 'icon': 'ends.png', 'label': ea})
    return slots


def _row_clear() -> None:
    set_home_prop(KPM_ROW_PREFIX + 'Visible', 'false')
    for i in range(1, KPM_ROW_SLOTS + 1):
        for suf in ('Source', 'IconFile', 'Label', 'Value'):
            clear_home_prop(f'{KPM_ROW_PREFIX}Slot{i}_{suf}')
    for key in ('ItemKey', 'ItemType', 'Window', 'Reason', 'UpdatedAt', 'ResolverTitle', 'ResolverDBID'):
        clear_home_prop(KPM_ROW_PREFIX + key)


def _row_publish(slots, item_key: str, item_type: str, reason: str) -> None:
    slots = [s for s in slots if s.get('label') and s.get('icon')]
    if not slots:
        _row_clear()
        return
    set_home_prop(KPM_ROW_PREFIX + 'Visible', 'true')
    set_home_prop(KPM_ROW_PREFIX + 'ItemKey', item_key)
    set_home_prop(KPM_ROW_PREFIX + 'ItemType', item_type)
    set_home_prop(KPM_ROW_PREFIX + 'Window', info('Window.Property(xmlfile)') or str(current_window_id()))
    set_home_prop(KPM_ROW_PREFIX + 'Reason', reason)
    set_home_prop(KPM_ROW_PREFIX + 'ResolverTitle', _current_title())
    set_home_prop(KPM_ROW_PREFIX + 'ResolverDBID', _dbid_value())
    set_home_prop(KPM_ROW_PREFIX + 'UpdatedAt', time.strftime('%Y-%m-%d %H:%M:%S'))
    for i in range(1, KPM_ROW_SLOTS + 1):
        if i <= len(slots):
            s = slots[i - 1]
            set_home_prop(f'{KPM_ROW_PREFIX}Slot{i}_Source', s.get('source', ''))
            set_home_prop(f'{KPM_ROW_PREFIX}Slot{i}_IconFile', s.get('icon', ''))
            set_home_prop(f'{KPM_ROW_PREFIX}Slot{i}_Label', s.get('label', ''))
            set_home_prop(f'{KPM_ROW_PREFIX}Slot{i}_Value', s.get('value', s.get('label', '')))
        else:
            for suf in ('Source', 'IconFile', 'Label', 'Value'):
                clear_home_prop(f'{KPM_ROW_PREFIX}Slot{i}_{suf}')


def update_kpm_rating_row() -> None:
    if not patch_state_enabled('af3_unified_integration'):
        _row_clear()
        return
    # Mirror the LRS display setting for XML diagnostics/guards.
    set_home_prop('KPM.Display.TVStatus', 'true' if _bool_setting('script.library.ratings.scraper', 'display_tv_status', False) else 'false')
    dbtype = _item_type()
    if _is_collection_or_nonmedia(dbtype):
        _row_clear()
        return
    title = _current_title()
    dbid = _dbid_value()
    if dbtype == 'game':
        appid = _get_prop('steam_appid', 'appid') or dbid or title
        _row_publish(_game_slots(), 'game|steam|' + str(appid), 'game', 'kpm_game_current')
        return
    if dbtype in ('movie', 'tvshow', 'season', 'episode', 'video'):
        _row_publish(_lrs_slots(dbtype, dbid), f'{dbtype}|{dbid or title}', dbtype, 'kpm_lrs_db_current')
        return
    _row_clear()



def _kpm_visual_context_active() -> bool:
    """Detect AF3 visual browsing without Window Translator aliases."""
    try:
        if cond('System.ScreenSaverActive'):
            return True
        return current_window_id() in (
            10000,  # Home
            10001,  # Programs
            10025,  # Videos
            10500,
            11101, 11102, 11103, 11104,  # AF3 hubs
        )
    except Exception:
        return False

def main() -> None:
    if not xbmc:
        return

    if home_prop(ACTIVE_PROP) == 'true':
        log('already running; exiting duplicate instance')
        return

    set_home_prop(ACTIVE_PROP, 'true')
    _repair_kpm_invalid_window_conditions_0206()
    # Clear any lower-row slot state left by pre-0.1.98 services. This prevents
    # an old Steam->Achievement->Metacritic snapshot from surviving an upgrade.
    if home_prop(KPM_ROW_SCHEMA_PROP) != KPM_ROW_SCHEMA_VERSION:
        try:
            _row_clear()
        except Exception:
            pass
        set_home_prop(KPM_ROW_SCHEMA_PROP, KPM_ROW_SCHEMA_VERSION)
    monitor = xbmc.Monitor()
    armed = home_prop(ARMED_PROP) == 'true'
    try:
        armed_dialog_id = int(home_prop(ARMED_DIALOG_PROP) or '0')
    except Exception:
        armed_dialog_id = 0

    log('started; movie/tv/game studio resolver and pause monitor')
    pause_since = 0.0
    last_foreign_dialog = 0
    last_logged_foreign_state = None
    last_gui_state = None
    gui_state_changed_at = time.monotonic()
    playback_started_at = 0.0
    last_has_video = False
    studio_index: dict[str, str] = {}
    game_studio_index: dict[str, str] = {}
    kpm_studio_index: dict[str, str] = {}
    kpm_game_studio_index: dict[str, str] = {}
    studio_last_key = ''
    studio_empty_since = 0.0
    studio_stats = {'resolve_count': 0, 'resolve_max_ms': 0, 'db_lookup_count': 0}
    episode_studio_cache: dict[int, dict] = {}
    media_studio_cache: dict[tuple[str, int], dict] = {}
    studio_enabled_cached = False
    studio_count_cached = 1
    studio_debug_cached = False
    last_config_check = 0.0
    last_studio_update = 0.0
    try:
        while not monitor.abortRequested():
            now = time.time()
            if now - last_config_check >= 1.0:
                last_config_check = now
                studio_enabled_cached = studio_patch_enabled()
                settings_cached = load_kpm_settings()
                studio_count_cached = 1
                studio_debug_cached = bool(settings_cached.get('studio_debug')) or home_prop(STUDIO_DEBUG_PROP).lower() == 'true'
                if studio_enabled_cached and not studio_index:
                    try:
                        studio_index = build_studio_logo_index(STUDIO_RESOURCE_ID)
                    except Exception:
                        log('movie/tv studio index build error:\n' + traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
                        studio_index = {}
                if studio_enabled_cached and not game_studio_index:
                    try:
                        game_studio_index = build_studio_logo_index(GAME_STUDIO_RESOURCE_ID)
                    except Exception:
                        log('game studio index build error:\n' + traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
                        game_studio_index = {}
                        _set_index_status_props(GAME_STUDIO_RESOURCE_ID, file_count=0, status='error', cache='error', build_ms='', broken_skipped=0)
                if studio_enabled_cached and not kpm_studio_index:
                    try:
                        kpm_studio_index = build_kpm_resource_logo_index(LOCAL_STUDIO_KIND)
                    except Exception:
                        log('KPM XBT movie/TV studio index build error:\n' + traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
                        kpm_studio_index = {}
                if studio_enabled_cached and not kpm_game_studio_index:
                    try:
                        kpm_game_studio_index = build_kpm_resource_logo_index(LOCAL_GAME_STUDIO_KIND)
                    except Exception:
                        log('KPM XBT game studio index build error:\n' + traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
                        kpm_game_studio_index = {}
                if not studio_enabled_cached:
                    studio_last_key = ''
                    studio_empty_since = 0.0
                    clear_studio_props()

            if studio_enabled_cached and (studio_index or game_studio_index or kpm_studio_index or kpm_game_studio_index) and now - last_studio_update >= STUDIO_RESOLVE_INTERVAL_SECONDS:
                last_studio_update = now
                try:
                    studio_last_key, studio_empty_since = update_studio_logo_props(studio_index, game_studio_index, kpm_studio_index, kpm_game_studio_index, 1, False, studio_last_key, studio_empty_since, studio_debug_cached, studio_stats, episode_studio_cache, media_studio_cache)
                except Exception:
                    log('studio resolver error:\n' + traceback.format_exc(), xbmc.LOGWARNING)

            try:
                update_kpm_rating_row()
            except Exception:
                log('rating row visual error:\n' + traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)

            if not pause_patch_enabled():
                armed = False
                armed_dialog_id = 0
                pause_since = 0.0
                last_foreign_dialog = 0
                last_logged_foreign_state = None
                playback_started_at = 0.0
                last_has_video = False
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                clear_home_prop(PAUSE_SINCE_PROP)
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)
                monitor.waitForAbort(KPM_WAIT_IDLE_SECONDS if studio_enabled_cached else KPM_WAIT_DEEP_IDLE_SECONDS)
                continue

            paused = cond('Player.Paused')
            playing = cond('Player.Playing')
            seeking = cond('Player.Seeking')
            has_video = cond('Player.HasVideo') or cond('Player.HasMedia')
            fullscreen_video = (
                cond('Window.IsActive(VideoFullScreen.xml)')
                or cond('Window.IsActive(fullscreenvideo)')
            )
            videoosd = (
                cond('Window.IsActive(videoosd)')
                or cond('Window.IsVisible(videoosd)')
            )

            window_id = current_window_id()
            dialog_id = current_dialog_id()
            gui_state = (window_id, dialog_id)
            monotonic_now = time.monotonic()
            if gui_state != last_gui_state:
                last_gui_state = gui_state
                gui_state_changed_at = monotonic_now
                gui_state_stable = False
            else:
                gui_state_stable = (
                    monotonic_now - gui_state_changed_at
                    >= GUI_STATE_STABLE_SECONDS
                )

            foreign_dialog = is_foreign_dialog(dialog_id)
            ui_action_blocked = foreign_dialog

            if has_video and not last_has_video:
                playback_started_at = now
                log(
                    'video session detected; startup guard active for '
                    f'{STARTUP_GUARD_WINDOW_SECONDS:.1f}s'
                )
            elif not has_video:
                playback_started_at = 0.0
            last_has_video = has_video

            if has_video and gui_state_stable and foreign_dialog:
                if gui_state != last_logged_foreign_state:
                    last_logged_foreign_state = gui_state
                    last_foreign_dialog = dialog_id
                    set_home_prop(
                        LAST_FOREIGN_DIALOG_PROP, str(dialog_id)
                    )
                    log(
                        'foreign dialog active; automatic VideoOSD actions '
                        f'blocked; dialog_id={dialog_id}, '
                        f'window_id={window_id}',
                        xbmc.LOGDEBUG if xbmc else None,
                    )
            elif gui_state_stable and not foreign_dialog:
                last_logged_foreign_state = None
                last_foreign_dialog = 0
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)

            if has_video and paused and not seeking:
                if pause_since <= 0:
                    pause_since = time.time()
                    set_home_prop(PAUSE_SINCE_PROP, str(pause_since))
                if fullscreen_video and not videoosd and not ui_action_blocked:
                    startup_age = (time.time() - playback_started_at) if playback_started_at > 0 else 999.0
                    grace = AUTO_OPEN_GRACE_SECONDS
                    grace_reason = 'normal-pause-no-delay'
                    if startup_age < STARTUP_GUARD_WINDOW_SECONDS:
                        grace = STARTUP_AUTO_DIALOG_GUARD_SECONDS
                        grace_reason = 'startup-dialog-guard'
                    if time.time() - pause_since >= grace:
                        log(f'paused with no foreign dialog; opening VideoOSD; grace={grace:.2f}s/{grace_reason}; dialog_id={dialog_id}, window_id={window_id}')
                        try:
                            xbmc.executebuiltin('CancelAlarm(osd_timeout,true)')
                            xbmc.executebuiltin('ActivateWindow(videoosd)')
                        except Exception:
                            log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
                        monitor.waitForAbort(KPM_WAIT_FAST_SECONDS)
                        continue
            else:
                pause_since = 0.0
                clear_home_prop(PAUSE_SINCE_PROP)

            if has_video and paused and videoosd:
                if not armed:
                    armed_dialog_id = dialog_id
                    set_home_prop(ARMED_DIALOG_PROP, str(armed_dialog_id))
                    log(f'armed while paused; dialog_id={armed_dialog_id}, window_id={current_window_id()}')
                armed = True
                set_home_prop(ARMED_PROP, 'true')

            if armed and has_video and playing and videoosd:
                if ui_action_blocked:
                    monitor.waitForAbort(KPM_WAIT_PLAYBACK_SECONDS)
                    continue
                log(f'pause->play detected; closing VideoOSD safely; dialog_id={dialog_id}, armed_dialog_id={armed_dialog_id}')
                close_video_osd_safely()
                armed = False
                armed_dialog_id = 0
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                monitor.waitForAbort(0.50)
                continue

            if not has_video or (not paused and not playing):
                armed = False
                armed_dialog_id = 0
                pause_since = 0.0
                last_foreign_dialog = 0
                playback_started_at = 0.0
                last_has_video = False
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                clear_home_prop(PAUSE_SINCE_PROP)
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)

            if has_video:
                if paused or videoosd or armed:
                    wait_seconds = KPM_WAIT_FAST_SECONDS
                elif playing:
                    wait_seconds = KPM_WAIT_ACTIVE_SECONDS
                else:
                    wait_seconds = KPM_WAIT_PLAYBACK_SECONDS
            else:
                # Rating/studio rows are UI-visual work. In Home/Hub/Programs,
                # v0.1.85 fell back to 1.0s idle polling, so ratings appeared
                # late after focus changes. Keep visual browsing fast, but still
                # deep-idle outside AF3 media contexts.
                wait_seconds = KPM_WAIT_FAST_SECONDS if _kpm_visual_context_active() else (KPM_WAIT_IDLE_SECONDS if studio_enabled_cached else KPM_WAIT_DEEP_IDLE_SECONDS)
            monitor.waitForAbort(wait_seconds)
    finally:
        clear_home_prop(ACTIVE_PROP)
        clear_home_prop(ARMED_PROP)
        clear_home_prop(ARMED_DIALOG_PROP)
        clear_home_prop(PAUSE_SINCE_PROP)
        clear_home_prop(LAST_FOREIGN_DIALOG_PROP)
        log('stopped')


# -----------------------------------------------------------------------------
# v0.1.87 - bridge mature LRS DisplaySlot output and publish atomically
# -----------------------------------------------------------------------------
def _lrs_display_prop_0187(suffix: str) -> str:
    name = 'LibraryRatings.HomeHub.' + suffix
    return any_window_prop(name) or home_prop(name)


def _lrs_display_slots_bridge_0187():
    if str(_lrs_display_prop_0187('DisplayActive') or '').strip().lower() != 'true':
        return []
    slots = []
    for idx in range(1, KPM_ROW_SLOTS + 1):
        source = _clean_value(_lrs_display_prop_0187('DisplaySlot{0}_Source'.format(idx)))
        icon = _clean_value(_lrs_display_prop_0187('DisplaySlot{0}_IconFile'.format(idx)) or _lrs_display_prop_0187('DisplaySlot{0}_Icon'.format(idx)))
        label = _clean_value(_lrs_display_prop_0187('DisplaySlot{0}_Label'.format(idx)) or _lrs_display_prop_0187('DisplaySlot{0}_Value'.format(idx)))
        value = _clean_value(_lrs_display_prop_0187('DisplaySlot{0}_Value'.format(idx)) or label)
        source_norm = str(source or '').strip().lower().replace('-', '_').replace(' ', '_')
        # Defensive compatibility: older LRS classified tvstatus as Ends-at
        # because both used ends.png. Status text must never carry the prefix.
        if source_norm in ('tvstatus', 'tv_status', 'series_status', 'status') and label.lower().startswith('ends at'):
            label = label[7:].strip(' :-')
            value = label
        if label and icon:
            slots.append({'source': source_norm or source, 'icon': icon, 'label': label, 'value': value})
    return slots


def _lrs_icon_0187(source: str, row) -> str:
    if source == 'rt_critic':
        token = str(row.get('rottentomatoes_image') or '').strip().lower()
        if 'certified' in token:
            return 'certified.png'
        if 'rotten' in token:
            return 'rtrotten.png'
        return 'rtfresh.png'
    if source == 'rt_audience':
        token = str(row.get('rottentomatoes_userimage') or '').strip().lower()
        if 'verified' in token or 'hot' in token:
            return 'verified.png'
        if 'spilt' in token or 'spill' in token or 'rotten' in token:
            return 'popcorn_spilt.png'
        return 'popcorn.png'
    return {
        'imdb': 'imdb.png',
        'tmdb': 'tmdb.png',
        'metacritic': 'metacritic.png',
        'trakt': 'trakt.png',
    }.get(source, '')


def _lrs_fallback_source_row_0187(source: str, row, top250: str = ''):
    colmap = {
        'imdb': 'imdb',
        'tmdb': 'tmdb',
        'rt_critic': 'rottentomatoes',
        'rt_audience': 'rottentomatoes_user',
        'metacritic': 'metacritic',
        'trakt': 'trakt',
    }
    col = colmap.get(source)
    if not col:
        return None
    raw = row.get(col)
    if source in ('rt_critic', 'rt_audience'):
        label = _percent(raw)
    elif source in ('imdb', 'tmdb'):
        label = _decimal_rating(raw)
    elif source in ('metacritic', 'trakt'):
        label = _integer_rating(raw)
    else:
        label = _clean_value(raw)
    if not label:
        return None
    if source == 'imdb' and top250:
        label = (label + ' #' + str(top250).lstrip('#')).strip()
    return {
        'source': source,
        'icon': _lrs_icon_0187(source, row),
        'label': label,
        'value': label.split(' #', 1)[0],
    }


def _lrs_slots(dbtype: str, dbid: str):
    # Primary path: LRS already owns settings, fill-empty, episode rules,
    # Home/Hub keep-last, EndsAt, awards and TV status.
    bridged = _lrs_display_slots_bridge_0187()
    if bridged:
        return bridged

    # Startup fallback mirrors the final LRS algorithm instead of using the
    # incomplete 0.1.86 first-N-selected implementation.
    title = _current_title()
    year = _current_year()
    row = _lrs_db_row(dbtype, dbid, title, year)
    if not row:
        return []
    top250 = ''
    if _bool_setting('script.library.ratings.scraper', 'display_top250', True):
        top250 = _clean_value(str(row.get('top250') or row.get('imdb_top250') or ''))
        if top250 == '0':
            top250 = ''

    if dbtype == 'episode':
        out = []
        for source in ('imdb', 'tmdb'):
            slot = _lrs_fallback_source_row_0187(source, row, '')
            if slot:
                out.append(slot)
        return out[:2]

    defaults = ['imdb', 'rt_audience', 'rt_critic', 'metacritic', 'tmdb', 'trakt']
    order = []
    for idx, default in enumerate(defaults, 1):
        source = (_setting_xml('script.library.ratings.scraper', 'display_rating_slot_{0}'.format(idx), default) or default).strip().lower()
        if source not in ('none', '') and source not in order:
            order.append(source)
    count = max(1, min(6, _int_setting('script.library.ratings.scraper', 'display_rating_slot_count', 3)))
    fill_empty = _bool_setting('script.library.ratings.scraper', 'display_fill_empty_slots', True)
    selected_sources = order[:count]
    candidates = order if fill_empty else selected_sources
    out = []
    for source in candidates:
        slot = _lrs_fallback_source_row_0187(source, row, top250)
        if slot:
            out.append(slot)
        if len(out) >= count:
            break

    if fill_empty and _bool_setting('script.library.ratings.scraper', 'display_tmdb_after_imdb_fallback', True):
        sources = [slot.get('source', '') for slot in out]
        if 'imdb' in sources and 'tmdb' in sources and 'tmdb' not in selected_sources:
            imdb_idx = sources.index('imdb')
            tmdb_idx = sources.index('tmdb')
            if tmdb_idx != imdb_idx + 1:
                tmdb_slot = out.pop(tmdb_idx)
                if tmdb_idx < imdb_idx:
                    imdb_idx -= 1
                out.insert(imdb_idx + 1, tmdb_slot)

    if _bool_setting('script.library.ratings.scraper', 'display_awards', True):
        oscars = _clean_value(str(row.get('oscar_wins') or ''))
        emmys = _clean_value(str(row.get('emmy_wins') or ''))
        if oscars and oscars != '0':
            icon = 'oscars_bp.png' if _truthy(row.get('oscar_best_picture')) else 'oscars.png'
            out.append({'source': 'oscars_bp' if icon == 'oscars_bp.png' else 'oscars', 'icon': icon, 'label': 'x' + oscars.lstrip('x')})
        if emmys and emmys != '0':
            out.append({'source': 'emmys', 'icon': 'emmys.png', 'label': 'x' + emmys.lstrip('x')})

    if dbtype in ('tvshow', 'season') and _bool_setting('script.library.ratings.scraper', 'display_tv_status', False):
        status = _clean_value(row.get('series_status') or row.get('status') or '')
        date = _clean_value(row.get('series_status_date') or row.get('status_date') or '')
        if status:
            out.append({'source': 'tv_status', 'icon': 'ends.png', 'label': (status + (' ' + date if date else '')).strip()})

    ends_at = _ends_at_label(dbtype)
    if ends_at:
        out.append({'source': 'endsat', 'icon': 'ends.png', 'label': ends_at})
    return out


def _row_publish(slots, item_key: str, item_type: str, reason: str) -> None:
    # Hide first, update every slot, and expose the completed generation last.
    slots = [slot for slot in slots if slot.get('label') and slot.get('icon')]
    if not slots:
        _row_clear()
        return
    signature_payload = {
        'item_key': item_key,
        'item_type': item_type,
        'slots': [
            {
                'source': slot.get('source', ''),
                'icon': slot.get('icon', ''),
                'label': slot.get('label', ''),
                'value': slot.get('value', slot.get('label', '')),
            }
            for slot in slots
        ],
    }
    signature = hashlib.sha1(json.dumps(signature_payload, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()
    if (home_prop(KPM_ROW_PREFIX + 'Visible') == 'true' and
            home_prop(KPM_ROW_PREFIX + 'Signature') == signature and
            home_prop(KPM_ROW_PREFIX + 'ItemKey') == item_key):
        return
    set_home_prop(KPM_ROW_PREFIX + 'Visible', 'false')
    generation = str(time.time_ns() if hasattr(time, 'time_ns') else int(time.time() * 1000000))
    set_home_prop(KPM_ROW_PREFIX + 'Generation', generation)
    set_home_prop(KPM_ROW_PREFIX + 'Signature', signature)
    set_home_prop(KPM_ROW_PREFIX + 'ItemKey', item_key)
    set_home_prop(KPM_ROW_PREFIX + 'ItemType', item_type)
    set_home_prop(KPM_ROW_PREFIX + 'Window', info('Window.Property(xmlfile)') or str(current_window_id()))
    set_home_prop(KPM_ROW_PREFIX + 'Reason', reason)
    set_home_prop(KPM_ROW_PREFIX + 'ResolverTitle', _current_title())
    set_home_prop(KPM_ROW_PREFIX + 'ResolverDBID', _dbid_value())
    set_home_prop(KPM_ROW_PREFIX + 'UpdatedAt', time.strftime('%Y-%m-%d %H:%M:%S'))
    for idx in range(1, KPM_ROW_SLOTS + 1):
        if idx <= len(slots):
            slot = slots[idx - 1]
            set_home_prop('{0}Slot{1}_Source'.format(KPM_ROW_PREFIX, idx), slot.get('source', ''))
            set_home_prop('{0}Slot{1}_IconFile'.format(KPM_ROW_PREFIX, idx), slot.get('icon', ''))
            set_home_prop('{0}Slot{1}_Label'.format(KPM_ROW_PREFIX, idx), slot.get('label', ''))
            set_home_prop('{0}Slot{1}_Value'.format(KPM_ROW_PREFIX, idx), slot.get('value', slot.get('label', '')))
        else:
            for suffix in ('Source', 'IconFile', 'Label', 'Value'):
                clear_home_prop('{0}Slot{1}_{2}'.format(KPM_ROW_PREFIX, idx, suffix))
    set_home_prop(KPM_ROW_PREFIX + 'Visible', 'true')


def update_kpm_rating_row() -> None:
    if not patch_state_enabled('af3_unified_integration'):
        _row_clear()
        return
    set_home_prop('KPM.Display.TVStatus', 'true' if _bool_setting('script.library.ratings.scraper', 'display_tv_status', False) else 'false')
    dbtype = _item_type()
    if _is_collection_or_nonmedia(dbtype):
        _row_clear()
        return
    title = _current_title()
    dbid = _dbid_value()
    if dbtype == 'game':
        appid = _get_prop('steam_appid', 'appid') or dbid or title
        _row_publish(_game_slots(), 'game|steam|' + str(appid), 'game', 'kpm_game_current')
        return
    if dbtype in ('movie', 'tvshow', 'season', 'episode', 'video'):
        bridged = _lrs_display_slots_bridge_0187()
        slots = bridged or _lrs_slots(dbtype, dbid)
        reason = 'lrs_displayslot_bridge' if bridged else 'kpm_lrs_db_fallback'
        _row_publish(slots, '{0}|{1}'.format(dbtype, dbid or title), dbtype, reason)
        return
    _row_clear()


# Final 0.1.87 clear also resets atomic-publish bookkeeping.
def _row_clear() -> None:
    set_home_prop(KPM_ROW_PREFIX + 'Visible', 'false')
    for idx in range(1, KPM_ROW_SLOTS + 1):
        for suffix in ('Source', 'IconFile', 'Label', 'Value'):
            clear_home_prop('{0}Slot{1}_{2}'.format(KPM_ROW_PREFIX, idx, suffix))
    for key in ('ItemKey', 'ItemType', 'Window', 'Reason', 'UpdatedAt', 'ResolverTitle', 'ResolverDBID', 'Generation', 'Signature'):
        clear_home_prop(KPM_ROW_PREFIX + key)


# -----------------------------------------------------------------------------
# v0.1.89 - coherent canonical item + panel-wide transition gate
# -----------------------------------------------------------------------------
KPM_VISUAL_PREFIX = 'KPM.Visual.'
KPM_VISUAL_STABLE_POLLS = 4
KPM_VISUAL_MIN_STABLE_SECONDS = 0.15
KPM_VISUAL_MEDIA_TYPES = {'movie', 'tvshow', 'season', 'episode', 'video', 'game'}
KPM_VISUAL_PREFIXES = (
    'ListItem', 'Container.ListItem',
    'Container(50).ListItem', 'Container(51).ListItem', 'Container(52).ListItem',
    'Container(301).ListItem',
    'Container(500).ListItem', 'Container(501).ListItem', 'Container(502).ListItem',
    'Container(503).ListItem', 'Container(504).ListItem', 'Container(505).ListItem',
    'Container(506).ListItem', 'Container(507).ListItem', 'Container(508).ListItem',
    'Container(509).ListItem', 'Container(510).ListItem', 'Container(9000).ListItem',
)
_KPM_VISUAL_STATE = {
    'key': '', 'fingerprint': '', 'count': 0, 'since': 0.0,
    'ready_key': '', 'generation': '', 'snapshot': None,
}


def _norm_0189(value: str) -> str:
    return re.sub(r'\s+', ' ', str(value or '').strip()).casefold()


def _normalize_dbtype_0189(value: str) -> str:
    low = _norm_0189(value)
    aliases = {'movies': 'movie', 'tvshows': 'tvshow', 'show': 'tvshow', 'series': 'tvshow', 'episodes': 'episode', 'games': 'game', 'collection': 'set', 'sets': 'set'}
    return aliases.get(low, low)


def _prefix_value_0189(prefix: str, label: str) -> str:
    return _clean_value(info(prefix + '.' + label))


def _prefix_prop_0189(prefix: str, *names: str) -> str:
    for name in names:
        value = _prefix_value_0189(prefix, 'Property({0})'.format(name))
        if value:
            return value
    return ''


def _snapshot_prefix_0189(prefix: str) -> dict:
    title = _prefix_value_0189(prefix, 'Title') or _prefix_value_0189(prefix, 'Label')
    dbtype = _normalize_dbtype_0189(
        _prefix_value_0189(prefix, 'DBType') or _prefix_prop_0189(prefix, 'DBTYPE', 'dbtype', 'MediaType', 'mediatype', 'kpm_item_type', 'lrs_item_type')
    )
    dbid = _prefix_value_0189(prefix, 'DBID') or _prefix_prop_0189(prefix, 'DBID', 'dbid')
    year = _prefix_value_0189(prefix, 'Year') or _prefix_prop_0189(prefix, 'year')
    platform = _prefix_prop_0189(prefix, 'platform', 'steam_platform')
    appid = _prefix_prop_0189(prefix, 'steam_appid', 'appid')
    explicit_types = [
        _prefix_prop_0189(prefix, 'kpm_item_type'),
        _prefix_prop_0189(prefix, 'mediahub_type'),
        _prefix_prop_0189(prefix, 'lrs_item_type'),
        _prefix_prop_0189(prefix, 'DBTYPE', 'dbtype', 'MediaType', 'mediatype'),
    ]
    explicit_game = any(_normalize_dbtype_0189(x) == 'game' for x in explicit_types if x)
    # MediaHub deliberately uses Kodi's movie mediatype to reuse AF3 furniture.
    # Explicit game properties and a Steam AppID must override that native DBType.
    if explicit_game or (appid and _norm_0189(platform) == 'steam'):
        dbtype = 'game'
    elif (platform or appid or dbtype == 'game') and dbtype not in ('movie', 'tvshow', 'season', 'episode', 'video'):
        dbtype = 'game'
    props = {}
    for name in (
        'steam_rating_display', 'steam_review_percent', 'steam250_rank', 'steam250_rank_display', 'top250_display',
        'metacritic_score', 'achievement_display', 'playtime_forever', 'playtime_display',
        'achievement_unlocked', 'achievement_total', 'completed_bool', 'finished_bool',
        'kpm_game_row_ready', 'kpm_game_row_schema', 'kpm_game_row_order',
        'kpm_item_type', 'mediahub_type', 'lrs_item_type', 'DBTYPE', 'dbtype', 'MediaType', 'mediatype',
        'developer', 'developer_display', 'publisher', 'publisher_display', 'tagline', 'plot',
    ):
        props[name] = _prefix_prop_0189(prefix, name)
    plot = _prefix_value_0189(prefix, 'Plot') or props.get('plot', '')
    tagline = _prefix_value_0189(prefix, 'Tagline') or props.get('tagline', '')
    clearlogo = _prefix_value_0189(prefix, 'Art(clearlogo)') or _prefix_prop_0189(prefix, 'clearlogo', 'logo')
    fanart = _prefix_value_0189(prefix, 'Art(fanart)') or _prefix_prop_0189(prefix, 'fanart')
    if dbtype == 'game':
        identity = appid or dbid or (_norm_0189(title) + '|' + str(year or ''))
        item_key = 'game|steam|' + identity
    elif dbtype:
        identity = dbid or (_norm_0189(title) + '|' + str(year or ''))
        item_key = dbtype + '|' + identity
    else:
        item_key = ''
    return {
        'prefix': prefix, 'title': title, 'dbtype': dbtype, 'dbid': dbid, 'year': year,
        'platform': platform, 'appid': appid, 'plot': plot, 'tagline': tagline,
        'clearlogo': clearlogo, 'fanart': fanart, 'props': props, 'item_key': item_key,
        'explicit_game': bool(explicit_game),
    }


def _service_identity_0189() -> dict:
    title = _first_info([
        'Window(Home).Property(TMDbHelper.ListItem.Title)', 'Window.Property(TMDbHelper.ListItem.Title)',
        'Window(Home).Property(MediaHub.ListItem.Title)', 'Window.Property(MediaHub.ListItem.Title)',
        'Window(Home).Property(SteamLibrary.ListItem.Title)', 'Window.Property(SteamLibrary.ListItem.Title)',
    ])
    dbid = _first_info([
        'Window(Home).Property(TMDbHelper.ListItem.DBID)', 'Window.Property(TMDbHelper.ListItem.DBID)',
        'Window(Home).Property(MediaHub.ListItem.DBID)', 'Window.Property(MediaHub.ListItem.DBID)',
        'Window(Home).Property(SteamLibrary.ListItem.DBID)', 'Window.Property(SteamLibrary.ListItem.DBID)',
    ])
    dbtype = _normalize_dbtype_0189(_first_info([
        'Window(Home).Property(TMDbHelper.ListItem.DBTYPE)', 'Window.Property(TMDbHelper.ListItem.DBTYPE)',
        'Window(Home).Property(MediaHub.ListItem.DBTYPE)', 'Window.Property(MediaHub.ListItem.DBTYPE)',
        'Window(Home).Property(SteamLibrary.ListItem.DBTYPE)', 'Window.Property(SteamLibrary.ListItem.DBTYPE)',
    ]))
    appid = _first_info([
        'Window(Home).Property(MediaHub.ListItem.steam_appid)', 'Window.Property(MediaHub.ListItem.steam_appid)',
        'Window(Home).Property(SteamLibrary.ListItem.steam_appid)', 'Window.Property(SteamLibrary.ListItem.steam_appid)',
    ])
    return {'title': title, 'dbid': dbid, 'dbtype': dbtype, 'appid': appid}


def _focused_control_id_0189() -> int:
    try:
        return int(float(info('System.CurrentControlId') or '0'))
    except Exception:
        return 0


def _canonical_item_0189() -> tuple[dict | None, list[dict]]:
    service = _service_identity_0189()
    focused = _focused_control_id_0189()
    prefixes = []
    if focused > 0:
        prefixes.append('Container({0}).ListItem'.format(focused))
    prefixes.extend(KPM_VISUAL_PREFIXES)
    seen, candidates = set(), []
    for order, prefix in enumerate(prefixes):
        if prefix in seen:
            continue
        seen.add(prefix)
        snap = _snapshot_prefix_0189(prefix)
        if not snap.get('title') or snap.get('dbtype') not in KPM_VISUAL_MEDIA_TYPES:
            continue
        score = 20
        if prefix == 'Container({0}).ListItem'.format(focused):
            score += 500
        if service.get('title') and _norm_0189(snap.get('title')) == _norm_0189(service.get('title')):
            score += 240
        if service.get('appid') and snap.get('appid') and str(service.get('appid')) == str(snap.get('appid')):
            score += 220
        if service.get('dbid') and snap.get('dbid') and str(service.get('dbid')) == str(snap.get('dbid')):
            score += 180
        if service.get('dbtype') and snap.get('dbtype') == service.get('dbtype'):
            score += 80
        if snap.get('appid') or snap.get('dbid'):
            score += 35
        if snap.get('plot') or snap.get('tagline'):
            score += 15
        if snap.get('dbtype') == 'game':
            props = snap.get('props') or {}
            if snap.get('explicit_game'):
                score += 120
            if str(props.get('kpm_game_row_ready') or '').strip().lower() == 'true':
                score += 80
            if props.get('playtime_display') or props.get('playtime_forever'):
                score += 25
            if props.get('steam_rating_display') or props.get('steam_review_percent'):
                score += 10
            if props.get('metacritic_score'):
                score += 10
            if props.get('achievement_display') or props.get('achievement_total'):
                score += 10
        # Earlier known prefixes win only as the final tiebreaker.
        score += max(0, 20 - order)
        snap['score'] = score
        candidates.append(snap)
    candidates.sort(key=lambda x: (-int(x.get('score') or 0), str(x.get('prefix') or '')))
    return (candidates[0] if candidates else None), candidates[:8]


def _visual_fingerprint_0189(snapshot: dict) -> str:
    props = snapshot.get('props') or {}
    payload = {
        'key': snapshot.get('item_key'), 'title': snapshot.get('title'), 'dbtype': snapshot.get('dbtype'),
        'dbid': snapshot.get('dbid'), 'appid': snapshot.get('appid'), 'year': snapshot.get('year'),
        'plot': snapshot.get('plot'), 'tagline': snapshot.get('tagline'),
        'clearlogo': snapshot.get('clearlogo'), 'fanart': snapshot.get('fanart'),
        'steam': props.get('steam_rating_display') or props.get('steam_review_percent'),
        'steam_rank': props.get('steam250_rank') or props.get('steam250_rank_display') or props.get('top250_display'),
        'mc': props.get('metacritic_score'), 'ach': props.get('achievement_display'),
        'playtime': props.get('playtime_display') or props.get('playtime_forever'),
        'row_ready': props.get('kpm_game_row_ready'), 'row_schema': props.get('kpm_game_row_schema'),
    }
    return hashlib.sha1(json.dumps(payload, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()


def _set_visual_candidates_0189(candidates: list[dict]) -> None:
    compact = []
    for c in candidates[:6]:
        compact.append({'prefix': c.get('prefix'), 'score': c.get('score'), 'key': c.get('item_key'), 'title': c.get('title'), 'dbtype': c.get('dbtype')})
    set_home_prop(KPM_VISUAL_PREFIX + 'CandidatesJSON', json.dumps(compact, ensure_ascii=False, separators=(',', ':')))


def _visual_gate_reset_0189(gate_active: bool) -> None:
    # 0.1.90: never hard-blank an already visible AF3 panel. Existing committed
    # properties survive a transient resolver/loading state and are replaced only
    # after the next canonical item is stable.
    existing_key = home_prop(KPM_VISUAL_PREFIX + 'ItemKey')
    has_committed = bool(existing_key or home_prop(KPM_ROW_PREFIX + 'ItemKey'))
    set_home_prop(KPM_VISUAL_PREFIX + 'GateActive', 'true' if gate_active else 'false')
    set_home_prop(KPM_VISUAL_PREFIX + 'HasCommitted', 'true' if has_committed else 'false')
    set_home_prop(KPM_VISUAL_PREFIX + 'Ready', 'true' if (not gate_active or has_committed) else 'false')
    set_home_prop(KPM_VISUAL_PREFIX + 'Transitioning', 'false')
    set_home_prop(KPM_VISUAL_PREFIX + 'Suppress', 'false')
    clear_home_prop(KPM_VISUAL_PREFIX + 'HoldReason')
    _KPM_VISUAL_STATE.update({'key': '', 'fingerprint': '', 'count': 0, 'since': 0.0, 'ready_key': existing_key if has_committed else '', 'snapshot': None})


def _update_visual_transition_0189() -> dict | None:
    gate_active = bool(patch_state_enabled('af3_unified_integration') and _kpm_visual_context_active() and not cond('System.ScreenSaverActive'))
    set_home_prop(KPM_VISUAL_PREFIX + 'GateActive', 'true' if gate_active else 'false')
    # Suppress is intentionally false in 0.1.90. AF3's current panel is never
    # hidden while KPM validates a new item; KPM-owned values use keep-last.
    set_home_prop(KPM_VISUAL_PREFIX + 'Suppress', 'false')
    if not gate_active:
        set_home_prop(KPM_VISUAL_PREFIX + 'Ready', 'true')
        set_home_prop(KPM_VISUAL_PREFIX + 'Transitioning', 'false')
        clear_home_prop(KPM_VISUAL_PREFIX + 'HoldReason')
        return None

    committed_key = str(_KPM_VISUAL_STATE.get('ready_key') or home_prop(KPM_VISUAL_PREFIX + 'ItemKey') or '')
    has_committed = bool(committed_key or home_prop(KPM_ROW_PREFIX + 'ItemKey'))
    set_home_prop(KPM_VISUAL_PREFIX + 'HasCommitted', 'true' if has_committed else 'false')

    loading = any(cond(expr) for expr in (
        'Container.IsUpdating', 'Window.IsVisible(busydialog)', 'Window.IsVisible(busydialognocancel)',
        'Window.IsVisible(extendedprogressdialog)', 'Window.IsVisible(progressdialog)',
    ))
    snapshot, candidates = _canonical_item_0189()
    _set_visual_candidates_0189(candidates)
    if loading or not snapshot or not snapshot.get('item_key'):
        # Hold the last committed row/panel instead of hiding it. Only the very
        # first unresolved frame has no KPM row yet; native AF3 remains visible.
        set_home_prop(KPM_VISUAL_PREFIX + 'Ready', 'true' if has_committed else 'false')
        set_home_prop(KPM_VISUAL_PREFIX + 'Transitioning', 'true' if has_committed else 'false')
        set_home_prop(KPM_VISUAL_PREFIX + 'HoldReason', 'loading' if loading else 'no_canonical_item')
        return None

    now = time.time()
    key = str(snapshot.get('item_key') or '')
    fingerprint = _visual_fingerprint_0189(snapshot)
    changed = key != _KPM_VISUAL_STATE.get('key') or fingerprint != _KPM_VISUAL_STATE.get('fingerprint')
    if changed:
        _KPM_VISUAL_STATE.update({'key': key, 'fingerprint': fingerprint, 'count': 1, 'since': now, 'snapshot': snapshot})
        set_home_prop(KPM_VISUAL_PREFIX + 'PendingItemKey', key)
        set_home_prop(KPM_VISUAL_PREFIX + 'ChangedAt', time.strftime('%Y-%m-%d %H:%M:%S'))
        set_home_prop(KPM_VISUAL_PREFIX + 'Transitioning', 'true')
        set_home_prop(KPM_VISUAL_PREFIX + 'HoldReason', 'candidate_stabilizing')
        # Keep Ready true only when an older item is already committed.
        set_home_prop(KPM_VISUAL_PREFIX + 'Ready', 'true' if has_committed else 'false')
    else:
        _KPM_VISUAL_STATE['count'] = int(_KPM_VISUAL_STATE.get('count') or 0) + 1
        _KPM_VISUAL_STATE['snapshot'] = snapshot

    stable_seconds = max(0.0, now - float(_KPM_VISUAL_STATE.get('since') or now))
    ready = int(_KPM_VISUAL_STATE.get('count') or 0) >= KPM_VISUAL_STABLE_POLLS and stable_seconds >= KPM_VISUAL_MIN_STABLE_SECONDS
    set_home_prop(KPM_VISUAL_PREFIX + 'CanonicalPrefix', str(snapshot.get('prefix') or ''))
    set_home_prop(KPM_VISUAL_PREFIX + 'CanonicalTitle', str(snapshot.get('title') or ''))
    set_home_prop(KPM_VISUAL_PREFIX + 'CanonicalDBID', str(snapshot.get('dbid') or ''))
    set_home_prop(KPM_VISUAL_PREFIX + 'CanonicalAppID', str(snapshot.get('appid') or ''))
    set_home_prop(KPM_VISUAL_PREFIX + 'ItemType', str(snapshot.get('dbtype') or ''))
    set_home_prop(KPM_VISUAL_PREFIX + 'StableCount', str(_KPM_VISUAL_STATE.get('count') or 0))
    set_home_prop(KPM_VISUAL_PREFIX + 'StableMs', str(int(stable_seconds * 1000)))
    if not ready:
        set_home_prop(KPM_VISUAL_PREFIX + 'Ready', 'true' if has_committed else 'false')
        set_home_prop(KPM_VISUAL_PREFIX + 'Transitioning', 'true')
        return None

    if _KPM_VISUAL_STATE.get('ready_key') != key:
        generation = str(time.time_ns() if hasattr(time, 'time_ns') else int(time.time() * 1000000))
        _KPM_VISUAL_STATE['ready_key'] = key
        _KPM_VISUAL_STATE['generation'] = generation
        set_home_prop(KPM_VISUAL_PREFIX + 'Generation', generation)
    set_home_prop(KPM_VISUAL_PREFIX + 'ItemKey', key)
    set_home_prop(KPM_VISUAL_PREFIX + 'PendingItemKey', '')
    set_home_prop(KPM_VISUAL_PREFIX + 'HasCommitted', 'true')
    set_home_prop(KPM_VISUAL_PREFIX + 'Ready', 'true')
    set_home_prop(KPM_VISUAL_PREFIX + 'Transitioning', 'false')
    clear_home_prop(KPM_VISUAL_PREFIX + 'HoldReason')
    return snapshot


def _snapshot_prop_0189(snapshot: dict, *names: str) -> str:
    props = snapshot.get('props') or {}
    for name in names:
        value = _clean_value(props.get(name))
        if value:
            return value
    return ''


def _steam_playtime_label_0193(display_value: str, minute_value: str) -> str:
    display = _clean_value(display_value)
    if display:
        return re.sub(r'^\s*play\s*time\s+', '', display, flags=re.I).strip()
    try:
        minutes = int(float(str(minute_value or '').strip()))
    except Exception:
        minutes = 0
    if minutes <= 0:
        return ''
    if minutes < 120:
        return '{0} minutes'.format(minutes)
    hours = round(minutes / 60.0, 1)
    return '{0} hours'.format(int(hours) if float(hours).is_integer() else '{0:.1f}'.format(hours))


def _series_status_label_0193(value: str) -> str:
    text = _clean_value(value)
    if not text:
        return ''
    # Strip legacy Ends-at prefix and any appended date.
    text = re.sub(r'^\s*ends\s+at\s+', '', text, flags=re.I)
    text = re.sub(r'\s+-\s+\d{1,4}[-/]\d{1,2}[-/]\d{1,4}\s*$', '', text)
    text = re.sub(r'\s+\d{1,2}[-/]\d{1,2}[-/]\d{2,4}\s*$', '', text)
    text = re.sub(r'\s+\d{4}[-/]\d{1,2}[-/]\d{1,2}\s*$', '', text)
    norm = text.strip().lower()
    if norm in ('returning series', 'returning'):
        return 'Returning'
    if norm in ('ended', 'end'):
        return 'Ended'
    if norm in ('canceled', 'cancelled'):
        return 'Cancelled'
    return text.strip()


def _steam_game_db_row_0197(appid: str) -> dict:
    appid = _clean_value(appid)
    if not appid:
        return {}
    db = translate(STEAM_LIBRARY_DB)
    if not os.path.exists(db):
        return {}
    try:
        mtime = os.path.getmtime(db)
    except Exception:
        mtime = None
    if _KPM_STEAM_ROW_CACHE.get('mtime') != mtime:
        _KPM_STEAM_ROW_CACHE['mtime'] = mtime
        _KPM_STEAM_ROW_CACHE['rows'] = {}
    rows = _KPM_STEAM_ROW_CACHE.setdefault('rows', {})
    if appid in rows:
        return dict(rows.get(appid) or {})
    row = {}
    try:
        con = sqlite3.connect(db, timeout=0.25)
        con.row_factory = sqlite3.Row
        try:
            found = con.execute(
                'SELECT appid, steam_review_percent, steam250_rank, metacritic_score, '
                'achievement_unlocked, achievement_total, playtime_forever '
                'FROM games WHERE appid=? LIMIT 1', (appid,)
            ).fetchone()
            if found:
                row = dict(found)
        finally:
            con.close()
    except Exception:
        row = {}
    rows[appid] = dict(row)
    return row


def _game_slots_0189(snapshot: dict):
    props = snapshot.get('props') or {}
    appid = _clean_value(snapshot.get('appid')) or _clean_value(props.get('steam_appid')) or _clean_value(props.get('appid'))
    dbrow = _steam_game_db_row_0197(appid)

    raw_display = _snapshot_prop_0189(snapshot, 'steam_rating_display')
    steam_raw = raw_display or _snapshot_prop_0189(snapshot, 'steam_review_percent') or _clean_value(dbrow.get('steam_review_percent'))
    steam = raw_display if raw_display and ('%' in raw_display or '#' in raw_display) else _percent(steam_raw)
    rank = (
        _snapshot_prop_0189(snapshot, 'steam250_rank')
        or _snapshot_prop_0189(snapshot, 'steam250_rank_display', 'top250_display')
        or _clean_value(dbrow.get('steam250_rank'))
    )
    rank = _clean_value(rank).lstrip('#')
    if steam and rank and '#' not in steam and rank not in ('0', 'N/A'):
        steam = '{0} #{1}'.format(steam, rank)

    mc_raw = _snapshot_prop_0189(snapshot, 'metacritic_score') or _clean_value(dbrow.get('metacritic_score'))
    mc = _integer_rating(mc_raw)

    ach = _snapshot_prop_0189(snapshot, 'achievement_display')
    unlocked = _snapshot_prop_0189(snapshot, 'achievement_unlocked') or _clean_value(dbrow.get('achievement_unlocked'))
    total = _snapshot_prop_0189(snapshot, 'achievement_total') or _clean_value(dbrow.get('achievement_total'))
    if not ach and total:
        ach = (unlocked or '0') + '/' + total

    playtime_display = _snapshot_prop_0189(snapshot, 'playtime_display')
    playtime_minutes = _snapshot_prop_0189(snapshot, 'playtime_forever') or _clean_value(dbrow.get('playtime_forever'))
    playtime = _steam_playtime_label_0193(playtime_display, playtime_minutes)

    slots = []
    # Locked invariant, regardless of provider property arrival order:
    # Steam -> Metacritic -> Achievement -> lifetime playtime.
    if steam:
        slots.append({'source': 'steam', 'icon': 'steam.png', 'label': steam})
    if mc and mc != '0':
        slots.append({'source': 'metacritic', 'icon': 'metacritic.png', 'label': mc})
    if ach:
        slots.append({'source': 'achievement', 'icon': 'steam-ach.png', 'label': ach})
    if playtime:
        slots.append({'source': 'steam_playtime', 'icon': 'ends.png', 'label': playtime})
    return slots


def _lrs_bridge_for_snapshot_0189(snapshot: dict):
    if str(_lrs_display_prop_0187('DisplayActive') or '').strip().lower() != 'true':
        return []
    lrs_key = _clean_value(_lrs_display_prop_0187('ItemKey'))
    lrs_title = _clean_value(_lrs_display_prop_0187('Title'))
    lrs_type = _normalize_dbtype_0189(_lrs_display_prop_0187('DBType'))
    if lrs_key and lrs_key != snapshot.get('item_key'):
        # LRS commonly uses movie|DBID, which should match KPM exactly.
        return []
    if lrs_title and _norm_0189(lrs_title) != _norm_0189(snapshot.get('title')):
        return []
    if lrs_type and lrs_type != snapshot.get('dbtype'):
        return []
    return _lrs_display_slots_bridge_0187()


def _lrs_slots_for_snapshot_0189(snapshot: dict):
    dbtype = str(snapshot.get('dbtype') or '')
    dbid = str(snapshot.get('dbid') or '')
    title = str(snapshot.get('title') or '')
    year = str(snapshot.get('year') or '')
    row = _lrs_db_row(dbtype, dbid, title, year)
    if not row:
        return []
    top250 = ''
    if _bool_setting('script.library.ratings.scraper', 'display_top250', True):
        top250 = _clean_value(str(row.get('top250') or row.get('imdb_top250') or ''))
        if top250 == '0':
            top250 = ''
    if dbtype == 'episode':
        out = []
        for source in ('imdb', 'tmdb'):
            slot = _lrs_fallback_source_row_0187(source, row, '')
            if slot:
                out.append(slot)
        return out[:2]
    defaults = ['imdb', 'rt_audience', 'rt_critic', 'metacritic', 'tmdb', 'trakt']
    order = []
    for idx, default in enumerate(defaults, 1):
        source = (_setting_xml('script.library.ratings.scraper', 'display_rating_slot_{0}'.format(idx), default) or default).strip().lower()
        if source not in ('none', '') and source not in order:
            order.append(source)
    count = max(1, min(6, _int_setting('script.library.ratings.scraper', 'display_rating_slot_count', 3)))
    fill_empty = _bool_setting('script.library.ratings.scraper', 'display_fill_empty_slots', True)
    selected_sources = order[:count]
    out = []
    for source in (order if fill_empty else selected_sources):
        slot = _lrs_fallback_source_row_0187(source, row, top250)
        if slot:
            out.append(slot)
        if len(out) >= count:
            break
    if fill_empty and _bool_setting('script.library.ratings.scraper', 'display_tmdb_after_imdb_fallback', True):
        sources = [slot.get('source', '') for slot in out]
        if 'imdb' in sources and 'tmdb' in sources and 'tmdb' not in selected_sources:
            imdb_idx, tmdb_idx = sources.index('imdb'), sources.index('tmdb')
            if tmdb_idx != imdb_idx + 1:
                tmdb_slot = out.pop(tmdb_idx)
                if tmdb_idx < imdb_idx:
                    imdb_idx -= 1
                out.insert(imdb_idx + 1, tmdb_slot)
    if _bool_setting('script.library.ratings.scraper', 'display_awards', True):
        oscars = _clean_value(str(row.get('oscar_wins') or ''))
        emmys = _clean_value(str(row.get('emmy_wins') or ''))
        if oscars and oscars != '0':
            icon = 'oscars_bp.png' if _truthy(row.get('oscar_best_picture')) else 'oscars.png'
            out.append({'source': 'oscars_bp' if icon == 'oscars_bp.png' else 'oscars', 'icon': icon, 'label': 'x' + oscars.lstrip('x')})
        if emmys and emmys != '0':
            out.append({'source': 'emmys', 'icon': 'emmys.png', 'label': 'x' + emmys.lstrip('x')})
    if dbtype in ('tvshow', 'season') and _bool_setting('script.library.ratings.scraper', 'display_tv_status', False):
        status = _series_status_label_0193(row.get('series_status') or row.get('status') or '')
        if status:
            out.append({'source': 'tv_status', 'icon': 'ends.png', 'label': status})
    ends_at = _ends_at_label(dbtype)
    if ends_at:
        out.append({'source': 'endsat', 'icon': 'ends.png', 'label': ends_at})
    return out


def _row_hide_0189() -> None:
    set_home_prop(KPM_ROW_PREFIX + 'Visible', 'false')


def _row_publish(slots, item_key: str, item_type: str, reason: str) -> None:
    normalized_slots = []
    for slot in (slots or []):
        slot = dict(slot)
        if str(slot.get('source') or '').lower() in ('tvstatus', 'tv_status', 'series_status', 'status'):
            slot['label'] = _series_status_label_0193(slot.get('label'))
        normalized_slots.append(slot)
    slots = [slot for slot in normalized_slots if slot.get('label') and slot.get('icon')]
    if not slots:
        _row_clear()
        return
    visual_generation = home_prop(KPM_VISUAL_PREFIX + 'Generation')
    signature_payload = {'item_key': item_key, 'item_type': item_type, 'visual_generation': visual_generation, 'slots': slots}
    signature = hashlib.sha1(json.dumps(signature_payload, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()
    if home_prop(KPM_ROW_PREFIX + 'Visible') == 'true' and home_prop(KPM_ROW_PREFIX + 'Signature') == signature and home_prop(KPM_ROW_PREFIX + 'ItemKey') == item_key:
        return
    had_visible = home_prop(KPM_ROW_PREFIX + 'Visible') == 'true'
    # Keep the previous row visible while the replacement properties are staged.
    # On first publication there is no prior row, so Visible remains false until commit.
    if not had_visible:
        set_home_prop(KPM_ROW_PREFIX + 'Visible', 'false')
    generation = str(time.time_ns() if hasattr(time, 'time_ns') else int(time.time() * 1000000))
    set_home_prop(KPM_ROW_PREFIX + 'Generation', generation)
    set_home_prop(KPM_ROW_PREFIX + 'VisualGeneration', visual_generation)
    set_home_prop(KPM_ROW_PREFIX + 'Signature', signature)
    set_home_prop(KPM_ROW_PREFIX + 'ItemKey', item_key)
    set_home_prop(KPM_ROW_PREFIX + 'ItemType', item_type)
    set_home_prop(KPM_ROW_PREFIX + 'Window', info('Window.Property(xmlfile)') or str(current_window_id()))
    set_home_prop(KPM_ROW_PREFIX + 'Reason', reason)
    snap = _KPM_VISUAL_STATE.get('snapshot') or {}
    set_home_prop(KPM_ROW_PREFIX + 'ResolverTitle', str(snap.get('title') or ''))
    set_home_prop(KPM_ROW_PREFIX + 'ResolverDBID', str(snap.get('dbid') or ''))
    set_home_prop(KPM_ROW_PREFIX + 'ResolverPrefix', str(snap.get('prefix') or ''))
    set_home_prop(KPM_ROW_PREFIX + 'UpdatedAt', time.strftime('%Y-%m-%d %H:%M:%S'))
    for idx in range(1, KPM_ROW_SLOTS + 1):
        if idx <= len(slots):
            slot = slots[idx - 1]
            set_home_prop('{0}Slot{1}_Source'.format(KPM_ROW_PREFIX, idx), slot.get('source', ''))
            set_home_prop('{0}Slot{1}_IconFile'.format(KPM_ROW_PREFIX, idx), slot.get('icon', ''))
            set_home_prop('{0}Slot{1}_Label'.format(KPM_ROW_PREFIX, idx), slot.get('label', ''))
            set_home_prop('{0}Slot{1}_Value'.format(KPM_ROW_PREFIX, idx), slot.get('value', slot.get('label', '')))
        else:
            for suffix in ('Source', 'IconFile', 'Label', 'Value'):
                clear_home_prop('{0}Slot{1}_{2}'.format(KPM_ROW_PREFIX, idx, suffix))
    # Commit last and only when the panel gate has committed the same item.
    if home_prop(KPM_VISUAL_PREFIX + 'Ready') == 'true' and home_prop(KPM_VISUAL_PREFIX + 'ItemKey') == item_key:
        set_home_prop(KPM_ROW_PREFIX + 'Visible', 'true')


def update_kpm_rating_row() -> None:
    if not patch_state_enabled('af3_unified_integration'):
        _visual_gate_reset_0189(False)
        _row_clear()
        return
    set_home_prop('KPM.Display.TVStatus', 'true' if _bool_setting('script.library.ratings.scraper', 'display_tv_status', False) else 'false')
    snapshot = _update_visual_transition_0189()
    if not snapshot:
        # Non-destructive transition hold: preserve the previously committed row.
        # Hide only before the first valid publication exists.
        if home_prop(KPM_VISUAL_PREFIX + 'HasCommitted') != 'true':
            _row_hide_0189()
        return
    dbtype = str(snapshot.get('dbtype') or '')
    if dbtype not in KPM_VISUAL_MEDIA_TYPES:
        _row_clear()
        return
    item_key = str(snapshot.get('item_key') or '')
    if dbtype == 'game':
        _row_publish(_game_slots_0189(snapshot), item_key, 'game', 'canonical_game_panel_0189')
        return
    bridged = _lrs_bridge_for_snapshot_0189(snapshot)
    slots = bridged or _lrs_slots_for_snapshot_0189(snapshot)
    _row_publish(slots, item_key, dbtype, 'canonical_lrs_bridge_0189' if bridged else 'canonical_lrs_db_0189')


# Extend final clear for v0.1.89 bookkeeping.
def _row_clear() -> None:
    set_home_prop(KPM_ROW_PREFIX + 'Visible', 'false')
    for idx in range(1, KPM_ROW_SLOTS + 1):
        for suffix in ('Source', 'IconFile', 'Label', 'Value'):
            clear_home_prop('{0}Slot{1}_{2}'.format(KPM_ROW_PREFIX, idx, suffix))
    for key in ('ItemKey', 'ItemType', 'Window', 'Reason', 'UpdatedAt', 'ResolverTitle', 'ResolverDBID', 'ResolverPrefix', 'Generation', 'VisualGeneration', 'Signature'):
        clear_home_prop(KPM_ROW_PREFIX + key)

# v0.1.94 - atomic lower-row slot set only (no logo/plot/fanart panel banks).
_KPM_ROW_SETS_0194 = ('A', 'B')


def _row_set_prefix_0194(set_name: str) -> str:
    return KPM_ROW_PREFIX + str(set_name) + '.'


def _row_publish(slots, item_key: str, item_type: str, reason: str) -> None:
    normalized = []
    for raw in (slots or []):
        slot = dict(raw)
        if str(slot.get('source') or '').lower() in ('tvstatus', 'tv_status', 'series_status', 'status'):
            slot['label'] = _series_status_label_0193(slot.get('label'))
        if str(slot.get('source') or '').lower() == 'steam_playtime':
            slot['label'] = re.sub(r'^\s*play\s*time\s+', '', str(slot.get('label') or ''), flags=re.I).strip()
        if slot.get('label') and slot.get('icon'):
            normalized.append(slot)
    slots = normalized
    if not slots:
        _row_clear()
        return
    visual_generation = home_prop(KPM_VISUAL_PREFIX + 'Generation')
    signature_payload = {'item_key': item_key, 'item_type': item_type, 'visual_generation': visual_generation, 'slots': slots}
    signature = hashlib.sha1(json.dumps(signature_payload, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()
    if home_prop(KPM_ROW_PREFIX + 'Visible') == 'true' and home_prop(KPM_ROW_PREFIX + 'Signature') == signature and home_prop(KPM_ROW_PREFIX + 'ItemKey') == item_key:
        return
    active = home_prop(KPM_ROW_PREFIX + 'ActiveSet')
    target = 'B' if active == 'A' else 'A'
    prefix = _row_set_prefix_0194(target)
    generation = str(time.time_ns() if hasattr(time, 'time_ns') else int(time.time() * 1000000))
    for idx in range(1, KPM_ROW_SLOTS + 1):
        if idx <= len(slots):
            slot = slots[idx - 1]
            set_home_prop('{0}Slot{1}_Source'.format(prefix, idx), slot.get('source', ''))
            set_home_prop('{0}Slot{1}_IconFile'.format(prefix, idx), slot.get('icon', ''))
            set_home_prop('{0}Slot{1}_Label'.format(prefix, idx), slot.get('label', ''))
            set_home_prop('{0}Slot{1}_Value'.format(prefix, idx), slot.get('value', slot.get('label', '')))
        else:
            for suffix in ('Source', 'IconFile', 'Label', 'Value'):
                clear_home_prop('{0}Slot{1}_{2}'.format(prefix, idx, suffix))
    set_home_prop(prefix + 'ItemKey', item_key)
    set_home_prop(prefix + 'ItemType', item_type)
    set_home_prop(prefix + 'Generation', generation)
    set_home_prop(prefix + 'Signature', signature)
    if home_prop(KPM_VISUAL_PREFIX + 'Ready') == 'true' and home_prop(KPM_VISUAL_PREFIX + 'ItemKey') == item_key:
        set_home_prop(KPM_ROW_SCHEMA_PROP, KPM_ROW_SCHEMA_VERSION)
        set_home_prop(KPM_ROW_PREFIX + 'ActiveSet', target)
        set_home_prop(KPM_ROW_PREFIX + 'Visible', 'true')
        set_home_prop(KPM_ROW_PREFIX + 'Generation', generation)
        set_home_prop(KPM_ROW_PREFIX + 'VisualGeneration', visual_generation)
        set_home_prop(KPM_ROW_PREFIX + 'Signature', signature)
        set_home_prop(KPM_ROW_PREFIX + 'ItemKey', item_key)
        set_home_prop(KPM_ROW_PREFIX + 'ItemType', item_type)
        set_home_prop(KPM_ROW_PREFIX + 'Window', info('Window.Property(xmlfile)') or str(current_window_id()))
        set_home_prop(KPM_ROW_PREFIX + 'Reason', reason)
        snap = _KPM_VISUAL_STATE.get('snapshot') or {}
        set_home_prop(KPM_ROW_PREFIX + 'ResolverTitle', str(snap.get('title') or ''))
        set_home_prop(KPM_ROW_PREFIX + 'ResolverDBID', str(snap.get('dbid') or ''))
        set_home_prop(KPM_ROW_PREFIX + 'ResolverPrefix', str(snap.get('prefix') or ''))
        set_home_prop(KPM_ROW_PREFIX + 'UpdatedAt', time.strftime('%Y-%m-%d %H:%M:%S'))
        for idx in range(1, KPM_ROW_SLOTS + 1):
            for suffix in ('Source', 'IconFile', 'Label', 'Value'):
                value = home_prop('{0}Slot{1}_{2}'.format(prefix, idx, suffix))
                if value:
                    set_home_prop('{0}Slot{1}_{2}'.format(KPM_ROW_PREFIX, idx, suffix), value)
                else:
                    clear_home_prop('{0}Slot{1}_{2}'.format(KPM_ROW_PREFIX, idx, suffix))


def _row_clear() -> None:
    set_home_prop(KPM_ROW_PREFIX + 'Visible', 'false')
    clear_home_prop(KPM_ROW_PREFIX + 'ActiveSet')
    for set_name in _KPM_ROW_SETS_0194:
        prefix = _row_set_prefix_0194(set_name)
        for idx in range(1, KPM_ROW_SLOTS + 1):
            for suffix in ('Source', 'IconFile', 'Label', 'Value'):
                clear_home_prop('{0}Slot{1}_{2}'.format(prefix, idx, suffix))
        for key in ('ItemKey', 'ItemType', 'Generation', 'Signature'):
            clear_home_prop(prefix + key)
    for idx in range(1, KPM_ROW_SLOTS + 1):
        for suffix in ('Source', 'IconFile', 'Label', 'Value'):
            clear_home_prop('{0}Slot{1}_{2}'.format(KPM_ROW_PREFIX, idx, suffix))
    for key in ('ItemKey', 'ItemType', 'Window', 'Reason', 'UpdatedAt', 'ResolverTitle', 'ResolverDBID', 'ResolverPrefix', 'Generation', 'VisualGeneration', 'Signature'):
        clear_home_prop(KPM_ROW_PREFIX + key)

if __name__ == '__main__':
    main()

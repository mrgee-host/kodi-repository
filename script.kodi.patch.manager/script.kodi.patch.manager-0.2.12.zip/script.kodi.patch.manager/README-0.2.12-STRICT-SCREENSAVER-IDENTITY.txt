Kodi Patch Manager 0.2.12
=========================

- Arctic Mirage clearlogo visibility now compares Container(1297).ListItem.Property(mediahub_item_key) directly with LibraryRatings.Screensaver.ClearLogoFinalItemKey.
- Rating row visibility compares the same current ListItem key directly with LibraryRatings.Screensaver.ItemKey.
- Removed stale-compatible title and LRS-to-LRS identity fallbacks.
- Removed the native clearlogo fallback from the KPM-owned screensaver logo group.
- A title is shown only after LRS marks the persistent resolver result ready with mode=title.
- A CropV2 image is shown only after resolver-ready=true, mode=cropv2, and the current item key matches.
- Pending, unbuilt, stale, or mismatched resolver states remain blank.
- Existing 1 ms outgoing-panel hide behavior remains active.

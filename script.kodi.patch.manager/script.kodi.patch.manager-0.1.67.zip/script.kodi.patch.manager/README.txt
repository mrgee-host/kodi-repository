Kodi Patch Manager v0.1.67

Clean build.

Included modules:
- Episode Thumb Up Next
- Movies + Shows Screensaver
- Pause Shows Full OSD
- Reliable Studio Logos

Removed from this build:
- Background random/source bridge module
- Related runtime engine in service.py
- Related patch menu entries
- Related diagnostic menu entries
- Related bridge/status/state handling
- One-time cleanup/restore routines that touch AF3/TMDbHelper files

Install notes:
1. Install this ZIP over the previous KPM version.
2. Restart Kodi.
3. Because this build does not run cleanup routines, it will not alter restored AF3/TMDbHelper files.

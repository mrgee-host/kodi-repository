KPM 0.2.21
- Clears rating rows on stable folder/non-media focus while preserving loading transitions.
- Export diagnostics and terminal tools close their menu.
- Full apply/remove batches request ReloadSkin once.
- Owns the clearlogo resolver database and Artwork Runtime Tools entry.
- Notification maximum remains 58 characters.

KPM 0.2.20
- AF3 extended-progress percent spacing is part of KPM Unified.
- Unified changes "$INFO[..., - ,%]" to "$INFO[...,- ,%]" so addon text and percent have one visual separator space.
- Apply, remove, and status include the progress-spacing patch.
- Diagnostics ZIPs are validated before previous KPM diagnostics ZIP variants are removed.
- Notifications are uppercase and limited to 58 characters.
- Short results use normal dialogs and long reports remain scrollable.
- Common footer: View Status, Export diagnostics ZIP, Settings, Exit.

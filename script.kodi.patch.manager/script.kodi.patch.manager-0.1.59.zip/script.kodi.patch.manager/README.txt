Kodi Patch Manager v0.1.59

New in v0.1.59:
- Fixes KPM Visit Random Fanart Source on AF3 hub windows observed as 11101/11102 in diagnostics.
- Keeps v0.1.58 Option B: KPM Visit Random Fanart Source, without editing TMDbHelper internals.
- Does NOT edit plugin.video.themoviedb.helper internals (no imgmon.py/images.py patch, no restore, no repair).
- KPM service chooses exactly one fanart URL per valid media visit and publishes it as KPM.Fanart.SourceImage.
- AF3 blur source is patched to use Property(KPM.Fanart.SourceImage) first, then non-cycle native fanart fallback.
- TMDbHelper still renders blur_v3/foreground/overlay normally, but receives one final source URL instead of Art(fanart{x}).
- Designed for AF3 Cycle Fanart OFF.

Important behavior:
- A enters -> KPM chooses one fanart.
- Staying on A -> same fanart remains locked.
- A -> B -> A -> A is allowed to choose a new fanart because it is a new visit.
- Play/More/tab/menu transient focus does not create a new random choice.
- TMDbHelper old KPM markers are refused; restore TMDbHelper manually to default first.

Menu:
- Apply Recommended Patch
- Remove Recommended Patch
- Advanced Patches
- Patch Status
- Diagnostics
- Clear Add-on Icon Cache
- Settings
- Exit

Recommended workflow:
1. Restore TMDbHelper manually to default.
2. Install this zip.
3. Restart Kodi.
4. Advanced Patches > KPM Visit Random Fanart Source > Patch.
5. Set AF3 Cycle Fanart OFF.
6. Restart Kodi.
7. Run Diagnostics > Start Fanart Live Diagnostic and test hub movies, hub series, library movies, library series.

Fanart diagnostic records every 100 ms:
- Native ListItem and Container.ListItem art.
- Common AF3 containers such as 301/501/502/503/504/601.
- LRS/TMDbHelper/KPM bridge properties.
- KPM.Fanart.SourceImage and selected/candidates/reason/status.
- TMDbHelper.Blur.SourceImage, Blur.Fallback, and BlurImage output properties.


Fix in v0.1.59:
- v0.1.58 allowed hub media-window IDs 1101/1102/etc., but the supplied diagnostics showed AF3 running media hubs on 11101 and 11102.
- Because those windows were not allowed, KPM skipped active Container(301/502/503) media and wrote no_media_context_keep_until_timeout, so the previous fanart stayed visible.
- v0.1.59 adds the observed 111xx AF3 hub windows and uses the same window set when reading bridge properties.
- The same-media lock remains intentional: staying on one item keeps the selected fanart stable; moving A -> B -> A is treated as a new visit and can select a different fanart when more than one candidate exists.

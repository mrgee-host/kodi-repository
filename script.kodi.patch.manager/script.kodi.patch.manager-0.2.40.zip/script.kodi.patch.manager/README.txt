Kodi Patch Manager 0.2.40

Runtime-only AF3 update
- Does not bundle or directly replace AF3 XML files.
- Full KPM Integration remains an idempotent partial patch at Kodi startup while enabled.
- Screensaver A/B bundle flow, Up Next thumb priority, Steam plot, poster 2:3, and startup-weather fallback are unchanged.

Combined Expanded episodes
- Uses AF3 native Object_StarRating at its native 48x48 dimensions.
- IMDb rating first; TMDb only when IMDb is empty.
- Star-to-rating visual gap is exactly 14 px: star centerright=346 and rating right=260 width=48 align=left.
- Shows ListItem.Year with width=68 so YYYY is not ellipsized.
- Episode title remains non-scrolling with right=400.
- Existing AF3 watched/library indicator and duration controls are untouched.

Startup contract
- Apply Full KPM Integration writes the master enabled state.
- Startup silently restores the same six-patch integration only while that state is enabled.
- Remove Full KPM Integration disables startup restoration.
- No all/day or all/night folder is created or referenced.

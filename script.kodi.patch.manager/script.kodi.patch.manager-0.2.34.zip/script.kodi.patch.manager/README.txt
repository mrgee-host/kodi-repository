Kodi Patch Manager 0.2.34

Base
----
Rebuilt from the 0.2.33 current-only fresh-install AF3 integration. No 0.2.34 Controller Companion full-keymap behavior is retained.

Only new runtime changes
------------------------
1. Installs resources/keymaps/kpm_subtitle_delay.xml to special://profile/keymaps/kpm_subtitle_delay.xml.
2. In FullscreenVideo, game.controller.default leftbumper runs subtitledelayminus and rightbumper runs subtitledelayplus.
3. Disables the single active <include>Part_Dim_Overlay</include> in special://home/addons/skin.arctic.fuse.3/1080i/DialogSlider.xml by replacing it with one XML comment marker.

Safety
------
- Dedicated keymap contains only LB and RB mappings.
- Different existing targets are backed up before atomic replacement.
- Identical/current files are not rewritten.
- XML and duplicate counts are validated before replacement.
- No GUI sound, guisettings.xml, other add-on, or unrelated KPM behavior is changed.
- The skin is not forcibly reloaded.

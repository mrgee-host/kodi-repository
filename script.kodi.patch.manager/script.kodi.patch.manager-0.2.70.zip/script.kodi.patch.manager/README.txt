Kodi Patch Manager 0.2.70

Runtime patch manager for the MrGee Kodi family.

Combined Expanded episodes
- AF3 native Object_StarRating.
- IMDb rating with TMDb fallback.
- Four-digit ListItem.Year.
- Episode title right=400 with no scrolling.
- Equal rendered spacing target across: star -> rating -> bullet -> year -> native indicator -> duration.
- Native Object_Indicator_List and duration remain untouched and act as the 21 px visual spacing reference.
- Geometry: star centerright=319; rating right=241 width=48 align=left; bullet right=220 width=24; year right=149 width=68.

All AF3 changes are partial runtime patches. No complete skin XML file is bundled or replaced.


0.2.46: KPM lower rating rows now receive the exact owner-container loading state from AF3 media, hub, spotlight, and combined views. This prevents stale half-rows during ReloadSkin/widget refresh without hiding committed rows for DialogBusy.


0.2.68: Restores the native AF3 info line exactly as in 0.2.66. The persistent rating row remains unchanged. Only the previous movie tagline/plotline and plot are kept during the short movie-to-set readiness gap.


0.2.69: Keeps the previous movie AF3 information line in native format during the short movie-to-set readiness gap. The native line remains unchanged outside that gap; clearlogo, title, plot, rating row, spacing, and layout are not modified.


0.2.70: Uses the active AF3 panel owner container for held movie resolution/audio fields in Home, Hub, and Library. Collection and movie information-icon pills both use 60 px width.

Kodi Patch Manager 0.2.19

- Arctic Mirage keeps its normal left/right alternation while no overlay is visible.
- Kodi toast notification, extended background progress, and normal progress windows reserve the right side.
- When an odd item would normally render on the right, KPM renders an identical left-anchored metadata snapshot instead.
- Fanart does not move. Clearlogo, rating row, plot, awards, status, and other metadata move together.
- The patch is XML-condition driven. There is no Python polling.
- Reapplying KPM is idempotent: the temporary duplicate is stripped before the mature two-panel patch is normalized, then rebuilt.

Kodi Patch Manager v0.1.62

New in v0.1.62:
- Reverts the v0.1.61 display strategy that tried to use KPM.Fanart.BlurImage as a real blur texture.
- KPM now owns only the selected original fanart URL: KPM.Fanart.SourceImage.
- AF3/TMDbHelper keep their default BlurImage, diffuse, tiled, and blur_v3 cache pipeline.
- Adds a small TMDbHelper images.py reader helper so Blur.SourceImage can resolve Window(Home).Property(KPM.Fanart.SourceImage) without lowercasing the property name.
- Adds per-item no-repeat bag selection so hub/home revisits cycle through available fanarts before repeating where possible.

Important behavior:
- A enters -> KPM chooses one fanart URL.
- Staying on A -> same fanart remains locked to avoid flicker.
- A -> B -> A -> A is treated as a new visit and should choose the next URL from that item's no-repeat bag.
- Blur/diffuse/tiled/cache files remain handled by TMDbHelper under userdata/addon_data/plugin.video.themoviedb.helper/blur_v3.
- KPM does not write blur_v3 files and no longer overrides TMDbHelper.ListItem.BlurImage/SimpleBackground output properties.
- Designed for AF3 Cycle Fanart OFF.

Recommended workflow:
1. Install this zip.
2. Restart Kodi.
3. Advanced Patches > KPM Visit Random Fanart Source > Patch.
4. Restart Kodi again so service.py and TMDbHelper images.py reload.
5. Test A -> B -> A on items with more than one fanart candidate.

Fix history:
- v0.1.59 added AF3 hub windows 11101/11102 after diagnostics showed valid Container(301/502/503) media was being skipped.
- v0.1.60 tried to force KPM through Blur.Fallback; diagnostics showed TMDbHelper output could stay stale/pink.
- v0.1.61 tried to publish concrete KPM blur_v3 paths; diagnostics showed the blur path resolver could miss and leave KPM.Fanart.BlurImage empty/black.
- v0.1.62 makes KPM source-only and lets the original AF3/TMDbHelper blur pipeline follow the KPM-selected source.

Diagnostics record:
- Native ListItem and Container.ListItem art.
- Common AF3 containers such as 301/501/502/503/504/601.
- KPM.Fanart.SourceImage, candidates, reason, status, selected index, and no-repeat bag state.
- TMDbHelper.Blur.SourceImage, TMDbHelper.Blur.Fallback, and TMDbHelper blur output properties.

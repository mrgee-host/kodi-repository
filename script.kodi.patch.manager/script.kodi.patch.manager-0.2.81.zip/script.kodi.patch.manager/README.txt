0.2.81: Adds a validated partial AF3 Custom Hub fanart no-carry patch. On Hub entry, retained BlurImage state is cleared and previous Home Current fanart is not used as a temporary fallback in hubs 1101-1104. Metadata and native AF3 blur/effects stay untouched. Games documentation now follows native Art(fanartN).

0.2.80: Corrects the TMDbHelper Fanart 10s Hold validator while keeping the patch partial and version/digest locked; exact original span is stored for safe removal.
Kodi Patch Manager 0.2.81
0.2.79: Adds a validated partial TMDbHelper images.py random {x} hold patch. Same item is stable for 10 seconds; item changes select immediately; Games fanart properties and AF3 native image effects remain untouched. No TMDbHelper add-on/file is bundled.

Runtime patch manager for the MrGee Kodi family.

Combined Expanded episodes
- AF3 native Object_StarRating.
- IMDb rating with TMDb fallback.
- Four-digit ListItem.Year.
- Episode title right=400 with no scrolling.
- Equal rendered spacing target across: star -> rating -> bullet -> year -> native indicator -> duration.
- Native Object_Indicator_List and duration remain untouched and act as the 21 px visual spacing reference.
- Geometry: star centerright=319; rating right=241 width=48 align=left; bullet right=220 width=24; year right=149 width=68.

All AF3 changes are partial runtime patches. No complete skin XML file is bundled or replaced.


0.2.77: Adds one top-level AF2 Colour Style ON/OFF switch. OFF is native AF3; ON ports AF2 original two-colour preset pairs and TextureMaker highlight rendering through partial KPM-owned AF3 hooks. No migration or cleanup.
0.2.76: Clears stale KPM rating rows on explicit non-media navigation, hides the lower rating row while Spotlight 301 updates, changes collection member count to Movie/Movies, removes the Settings menu, and fixes Arctic Mirage to MediaHub screensaver_mix (limit=0, random=true), 5-second item duration, plot autoscroll OFF. Historical settings state is not migrated or cleaned.

0.2.46: KPM lower rating rows now receive the exact owner-container loading state from AF3 media, hub, spotlight, and combined views. This prevents stale half-rows during ReloadSkin/widget refresh without hiding committed rows for DialogBusy.


0.2.68: Restores the native AF3 info line exactly as in 0.2.66. The persistent rating row remains unchanged. Only the previous movie tagline/plotline and plot are kept during the short movie-to-set readiness gap.


0.2.69: Keeps the previous movie AF3 information line in native format during the short movie-to-set readiness gap. The native line remains unchanged outside that gap; clearlogo, title, plot, rating row, spacing, and layout are not modified.


0.2.73: Rebuilt directly from 0.2.69. Movie-to-set rating, information line, tagline, and plot keep-last behavior is unchanged. Hub behavior is unchanged. Only the collection information-icon pill width changes from the inherited 48 px default to 60 px, matching the movie pill.


0.2.74: Keeps the complete R68 visual patch unchanged. In AF3 Custom Hubs, KPM follows the active TMDbHelper.WidgetContainer owner instead of scanning hidden Spotlight and widget containers every 50 ms. The selected owner also receives an owner-specific IsUpdating hold. MWH itself is not modified.
0.2.75: Keeps 0.2.74 runtime owner scoping. UpperHold PlotlineLabel no longer appears in XML include conditions; both plot layouts remain structurally loaded and runtime visibility selects the 80 px + label or 120 px plot form. This prevents Custom Hub KEEP_IN_MEMORY reloads caused by UpperHold empty/non-empty state changes while preserving movie-to-set keep-last behavior.

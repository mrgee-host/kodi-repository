Kodi Patch Manager v0.1.69

Clean no-fanart build.

Included modules:
- Episode Thumb Up Next
- Movies + Shows + Games Screensaver
- Pause Shows Full OSD
- Reliable Studio Logos

Screensaver update in v0.1.69:
- AF3 Defs_ScreensaverWidget can now point to KPM's own plugin source.
- The source mixes Kodi movies, Kodi TV shows, and Steam Library games.
- Games are read from plugin.program.steam.library's steam_library.db and hidden games are excluded.
- Old Skin Helper Widgets randommoviestvshows injection is cleaned if present.
- KPM does not touch fanart/blur/background bridges. Artwork rendering remains native to AF3/Kodi/TMDbHelper/Steam Library item art.

Still removed from this build:
- Background random/source bridge module
- Related runtime engine in service.py
- Related patch menu entries
- Related diagnostic menu entries
- Related bridge/status/state handling
- One-time cleanup/restore routines that touch AF3/TMDbHelper files for fanart

Install notes:
1. Install this ZIP over the previous KPM version.
2. Restart Kodi.
3. Open KPM > Advanced Patches > Movies + Shows + Games Screensaver > Patch.
4. Restart Kodi once more if the old Skin Helper Widgets source was active.


v0.1.69: Fixes Movies + Shows + Games Screensaver plugin imports (sys/random/quote/parse_qsl) and isolates source buckets so games cannot crash the full listing. No fanart-random code is included.

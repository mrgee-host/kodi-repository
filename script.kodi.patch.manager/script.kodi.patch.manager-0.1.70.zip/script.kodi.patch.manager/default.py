# -*- coding: utf-8 -*-
from __future__ import annotations

import sys

from resources.lib.main import run, run_diag_live, run_plugin

def _is_plugin_call() -> bool:
    try:
        return len(sys.argv) > 2 and (str(sys.argv[0]).startswith('plugin://') or str(sys.argv[1]).isdigit())
    except Exception:
        return False


if __name__ == '__main__':
    if _is_plugin_call():
        run_plugin()
    elif len(sys.argv) > 1 and sys.argv[1] == 'diag_live':
        try:
            duration = int(sys.argv[2]) if len(sys.argv) > 2 else 90
        except Exception:
            duration = 90
        run_diag_live(duration)
    else:
        run()

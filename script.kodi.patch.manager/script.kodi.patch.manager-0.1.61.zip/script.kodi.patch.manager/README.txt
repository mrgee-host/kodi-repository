Kodi Patch Manager v0.1.61

New in v0.1.61:
- Replaces the failed v0.1.60 force-fallback visual strategy with a cache-aware blur bridge.
- KPM still chooses exactly one fanart URL per valid media visit, but now computes the matching TMDbHelper blur_v3 filename from md5(source)-radius-size.
- KPM publishes KPM.Fanart.BlurImage plus TMDbHelper.ListItem/Current/SimpleBackground BlurImage outputs when the blur_v3 file exists.
- If the blur file is missing, KPM keeps the last good blur while TMDbHelper/AF3 generates the cache from KPM's selected URL.
- AF3/TMDbHelper remain the blur generator/cache system; KPM only selects the source and points the skin at the correct existing blur_v3 file.

Previous v0.1.60:
- Keeps AF3/TMDbHelper blur_v3 rendering/cache pipeline default.
- Changes only the input source priority for KPM Visit Random Fanart Source.
- Removes native Art(tvshow.fanart)/Art(fanart) fallback from the AF3 source bridge.
- KPM now publishes the selected visit-random fanart URL as TMDbHelper.Blur.Fallback, and TMDbHelper uses that URL to generate/use the normal blur_v3 cache files.
- This fixes diagnostics where KPM.Fanart.SourceImage changed per visit but TMDbHelper output still used native Art(fanart) instead of the KPM-selected URL.

Important behavior:
- A enters -> KPM chooses one fanart URL.
- Staying on A -> same fanart remains locked.
- A -> B -> A -> A is allowed to choose a new fanart because it is a new visit.
- AF3/TMDbHelper still create/read files under userdata/addon_data/plugin.video.themoviedb.helper/blur_v3.
- KPM does not write blur_v3 files and does not patch TMDbHelper Python internals.
- Designed for AF3 Cycle Fanart OFF.

Recommended workflow:
1. Install this zip.
2. Restart Kodi.
3. Advanced Patches > KPM Visit Random Fanart Source > Patch.
4. Restart Kodi again.
5. Test A -> B -> A on items with more than one fanart candidate.

Fix history:
- v0.1.59 added AF3 hub windows 11101/11102 after diagnostics showed valid Container(301/502/503) media was being skipped.
- v0.1.60 fixes the remaining visual mismatch: KPM had already selected different URLs, but the AF3/TMDbHelper source chain still allowed native Art(fanart) to win before KPM fallback. The bridge is now KPM-only, so the selected KPM URL becomes the blur input while the blur processing itself remains AF3/TMDbHelper default.

Diagnostics still record:
- Native ListItem and Container.ListItem art.
- Common AF3 containers such as 301/501/502/503/504/601.
- KPM.Fanart.SourceImage, candidates, reason, status, and selected index.
- TMDbHelper.Blur.SourceImage, TMDbHelper.Blur.Fallback, and TMDbHelper blur output properties.

- v0.1.61 fixes the v0.1.60 regression where Blur.Fallback changed but visual output properties could stay stale or pink. KPM now resolves and publishes the concrete blur_v3 cache path that belongs to the KPM-selected fanart.

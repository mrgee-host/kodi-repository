Kodi Patch Manager v0.1.38

Kodi Patch Manager v0.1.38

New in v0.1.38:
- Fixed Fanart Live Diagnostic crash from undefined cond() by using cond_visible().
- Fanart live JSONL now also records KPM.Fanart.Display and KPM.Fanart.Show.
- Diagnostic note: v0.1.35 logs mean the old addon/service was still running and must be updated/restarted.

- Fix Apply Recommended crash: missing _remove_tmdb_v11_blocks cleanup helper.
- Old TMDbHelper fanart V11/V12 cleanup is now safe while Independent Fanart Engine stays AF3 + KPM service only.


Kodi Patch Manager v0.1.35 v0.1.23

New in v0.1.23:
- Pause Shows Full OSD now opens VideoOSD from service.py with no intentional delay on normal pause, then stays open while playback is paused; AF3 osd_timeout is disabled only during pause.
- VideoOSD closes fast when playback resumes from pause, but service.py does not touch focus while subtitle/audio/other foreign dialogs are active.
- Playback-start guard remains 0.85 seconds during the first 3 seconds of a new video so auto subtitle dialogs can take focus safely.
- Clearart is moved from VideoOSD into DialogSeekBar behind the progress layer, so the progress line/time render over it.
- Clearart is slightly smaller while keeping the same bottom-right anchor.
- Chapter/cutlist tick markers on the progress line are hidden.
- OSD plot width remains shortened so text stops before the clearart area.

Safe patch style:
- Does not ship full replacement XML/PY target files.
- Uses anchor-based injection/replacement only.
- Adds clear markers to every injected block.
- Normal Remove/Restore is block-level: it removes injected blocks or restores only the saved original XML variable block, not the whole file.
- A safety snapshot is also stored before patching, but normal restore does not overwrite the whole target file.

Included patches:
1. Episode Thumb Up Next
   Target: skin.arctic.fuse.3/1080i/Includes_Images.xml
   Change: Image_UpNext becomes thumb -> landscape -> fanart.

2. Independent Fanart Engine
   Target: skin.arctic.fuse.3/1080i/Includes_Images.xml
   Source: Artwork Curator artwork-cache.db (read-only), no TMDbHelper fanart patch
   Change: random extra-fanart stays stable while focus stays on the same item.

3. Movies + Shows Screensaver
   Target: script.skin.helper.widgets/resources/lib/media.py
   Target: skin.arctic.fuse.3/1080i/Includes_Defaults.xml
   Change: adds randommoviestvshows path and points AF3 screensaver widget to movies + TV shows only.

4. AF3 x LRS Ratings UI
   Target: skin.arctic.fuse.3/1080i/Includes_Info.xml, Includes_Hubs.xml, screensaver-arctic-mirage.xml
   Change: injects LRS rating/status/award display blocks into AF3.

5. Pause Shows Full OSD
   Target: DialogSeekBar.xml, VideoOSD.xml, Includes_OSD.xml, Includes_Actions.xml
   Change: pause opens full VideoOSD, stays open until playback resumes, shows clearart behind progress, hides chapter ticks, shortens plot, and closes fast on resume.

Backups/state:
- special://profile/addon_data/script.kodi.patch.manager/state
- special://profile/addon_data/script.kodi.patch.manager/snapshots

After patch/remove:
- Reload Skin is requested automatically for XML patches.
- Full Kodi restart is safest if Kodi keeps an old XML window in memory.


0.1.24
- Added Reliable Studio Logos patch.
- KPM service resolves valid studio logo files from resource.images.studios.coloured.
- Footer can show 1, 2, or 3 auto-matched studio logos based on KPM Settings.
- Metadata/database studio links are not changed.


0.1.30
- Optimized Reliable Studio Logos: cached studio XBT index, reduced per-item logging, slower/debounced resolver checks, broken texture blacklist, expanded studio diagnostics and timing properties.


0.1.30
- Reliable Studio Logos is now single-logo only. KPM.StudioLogo.1 is the only render source for footer studio logos.
- Removed raw AF3/TMDbHelper/ListItem fallback from Image_CombinedStudio to prevent invalid combined paths like A / B / C.png.
- Keeps the last valid media logo when context temporarily moves to KPM menus/dialogs instead of clearing KPM.StudioLogo.1.
- Adds direct MyVideos DB fallback for movie/tvshow studios and keeps parent TV show fallback for episodes.
- Studio diagnostics now include last media candidates/resolved/source so exports from the KPM menu still show the last media item resolve.


Version 0.1.30
- Reliable Studio Logos keeps the original AF3 Furniture_Studio right-aligned grouplist placement.
- Adds KPM.StudioLogos.Show so non-media menus can hide stale studio logos without clearing KPM.StudioLogo.1.

0.1.30
- Apply Recommended / Remove Recommended now checks status first.
- Current patches are skipped without touching files.
- Old or partial KPM patches are updated only inside their own marked/anchored blocks.
- AF3 x LRS rating block is normalized to prevent duplicate rating rows.
- Reliable Studio Logos patches the original Furniture_Studio layout instead of rebuilding/moving it.
- Studio logo Show state is restored immediately when returning from menu/dialog to the same media item.


v0.1.35
- Replaces TMDbHelper fanart patch with independent KPM fanart engine.
- AF3 reads KPM.Fanart.Display first.
- KPM reads Artwork Curator artwork-cache.db read-only and uses MyVideos DB only for episode/season parent TV show mapping.


v0.1.38: Independent fanart atomic switch. Old KPM item fanart is hidden immediately on focus mismatch, new item fanart is published before Show=true, and KPM.Fanart.Launch is active only when no media item is focused.

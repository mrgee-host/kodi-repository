# -*- coding: utf-8 -*-
from __future__ import annotations

import sys

from resources.lib.main import run, run_diag_live, run_fanart_diag_live

if __name__ == '__main__':
    if len(sys.argv) > 1 and sys.argv[1] == 'diag_live':
        try:
            duration = int(sys.argv[2]) if len(sys.argv) > 2 else 90
        except Exception:
            duration = 90
        run_diag_live(duration)
    elif len(sys.argv) > 1 and sys.argv[1] == 'fanart_diag_live':
        try:
            duration = int(sys.argv[2]) if len(sys.argv) > 2 else 60
        except Exception:
            duration = 60
        run_fanart_diag_live(duration)
    else:
        run()

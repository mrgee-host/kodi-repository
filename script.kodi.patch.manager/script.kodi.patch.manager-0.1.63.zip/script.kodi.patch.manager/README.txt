Kodi Patch Manager v0.1.63

New in v0.1.63:
- Fixes the v0.1.62 source bridge bug where Window(Home).Property(KPM.Fanart.SourceImage) could be preserved by TMDbHelper as a literal Container(...).window(home).property(...) string instead of resolving to the selected URL.
- KPM now writes the selected TMDb fanart URL directly into TMDbHelper.Blur.SourceImage, with the native AF3/TMDbHelper fanart chain as fallback.
- KPM still does not own blur output paths; blur_v3/diffuse/tiled/cache remain default TMDbHelper/AF3 behavior.
- Keeps the no-repeat fanart bag from v0.1.62.

Important behavior:
- A enters -> KPM chooses one fanart URL.
- Staying on A -> same fanart remains locked to avoid flicker.
- A -> B -> A -> A is treated as a new visit and should choose the next URL from that item's no-repeat bag.
- Blur/diffuse/tiled/cache files remain handled by TMDbHelper under userdata/addon_data/plugin.video.themoviedb.helper/blur_v3.
- KPM does not write blur_v3 files and does not override TMDbHelper.ListItem.BlurImage/SimpleBackground output properties.
- Designed for AF3 Cycle Fanart OFF.

Recommended workflow:
1. Install this zip.
2. Restart Kodi.
3. Advanced Patches > KPM Visit Random Fanart Source > Patch.
4. Restart Kodi again so service.py and TMDbHelper images.py reload.
5. Test A -> B -> A on items with more than one fanart candidate.

Fix history:
- v0.1.59 added AF3 hub windows 11101/11102 after diagnostics showed valid Container(301/502/503) media was being skipped.
- v0.1.60 tried to force KPM through Blur.Fallback; diagnostics showed TMDbHelper output could stay stale/pink.
- v0.1.61 tried to publish concrete KPM blur_v3 paths; diagnostics showed the blur path resolver could miss and leave KPM.Fanart.BlurImage empty/black.
- v0.1.62 made KPM source-only, but its Window(Home).Property(KPM.Fanart.SourceImage) bridge could be preserved literally by TMDbHelper.
- v0.1.63 writes the selected URL directly to TMDbHelper.Blur.SourceImage and lets the original AF3/TMDbHelper blur pipeline follow that source.

Diagnostics record:
- Native ListItem and Container.ListItem art.
- Common AF3 containers such as 301/501/502/503/504/601.
- KPM.Fanart.SourceImage, candidates, reason, status, selected index, and no-repeat bag state.
- TMDbHelper.Blur.SourceImage, TMDbHelper.Blur.Fallback, and TMDbHelper blur output properties.

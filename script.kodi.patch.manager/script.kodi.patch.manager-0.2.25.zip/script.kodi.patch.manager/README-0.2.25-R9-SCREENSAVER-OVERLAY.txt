Kodi Patch Manager 0.2.25

Screensaver-only update: direct MWH ListItem CropV2 and rating properties.
The normal panel rating row continues to hold the previous row until the new row is ready.
No blank-frame transition was introduced.

# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import re
import shutil
import sqlite3
import time
import traceback
import zipfile
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple
from urllib.parse import unquote

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # Allows syntax checks outside Kodi.
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

ADDON_ID = 'script.kodi.patch.manager'
ADDON_NAME = 'Kodi Patch Manager'
VERSION = '0.1.50'

# Markers: every injected/replaced block has an obvious marker.
UPNEXT_MARKER = '<!-- KPM-UPNEXT-EPISODE-THUMB -->'
SHW_METHOD_START = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-METHOD-START'
SHW_METHOD_END = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-METHOD-END'
SHW_ENTRY_MARKER = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-LISTING'
SHW_XML_MARKER = '<!-- KPM-SHW-RANDOM-MOVIES-TVSHOWS-XML -->'
LEGACY_SHW_METHOD_START = '# AFM-RANDOM-MOVIES-TVSHOWS-METHOD-START'
LEGACY_SHW_METHOD_END = '# AFM-RANDOM-MOVIES-TVSHOWS-METHOD-END'
LEGACY_SHW_ENTRY_MARKER = '# AFM-RANDOM-MOVIES-TVSHOWS-LISTING'
LEGACY_SHW_XML_MARKER = '<!-- AFM-RANDOM-MOVIES-TVSHOWS-XML-PATCH -->'
TMDB_ATTR_MARKER = '# KPM-TMDB-FOCUS-RANDOM-V16-ATTR'
TMDB_V11_ATTR_MARKER = '# KPM-TMDB-FOCUS-RANDOM-V11-ATTR'
TMDB_REFRESH_START = '# KPM-TMDB-FOCUS-RANDOM-V16-REFRESH-START'
TMDB_V11_REFRESH_START = '# KPM-TMDB-FOCUS-RANDOM-V11-REFRESH-START'
TMDB_REFRESH_END = '# KPM-TMDB-FOCUS-RANDOM-V16-REFRESH-END'
TMDB_V11_REFRESH_END = '# KPM-TMDB-FOCUS-RANDOM-V11-REFRESH-END'
TMDB_HELPER_START = '# KPM-TMDB-FOCUS-RANDOM-V16-HELPER-START'
TMDB_V11_HELPER_START = '# KPM-TMDB-FOCUS-RANDOM-V11-HELPER-START'
TMDB_HELPER_END = '# KPM-TMDB-FOCUS-RANDOM-V16-HELPER-END'
TMDB_V11_HELPER_END = '# KPM-TMDB-FOCUS-RANDOM-V11-HELPER-END'
TMDB_CALL_MARKER = '# KPM-TMDB-FOCUS-RANDOM-V16-CALL'
TMDB_V11_CALL_MARKER = '# KPM-TMDB-FOCUS-RANDOM-V11-CALL'
TMDB_V12_ATTR_MARKER = '# KPM-TMDB-FOCUS-RANDOM-V12-ATTR'
TMDB_V12_REFRESH_START = '# KPM-TMDB-FOCUS-RANDOM-V12-REFRESH-START'
TMDB_V12_REFRESH_END = '# KPM-TMDB-FOCUS-RANDOM-V12-REFRESH-END'
TMDB_V12_HELPER_START = '# KPM-TMDB-FOCUS-RANDOM-V12-HELPER-START'
TMDB_V12_HELPER_END = '# KPM-TMDB-FOCUS-RANDOM-V12-HELPER-END'
TMDB_V12_CALL_MARKER = '# KPM-TMDB-FOCUS-RANDOM-V12-CALL'
LEGACY_TMDB_MARKER = 'Focus-random sticky visit patch V11'
VFS_PAUSE_RATINGS_START = '<!-- KPM-VFS-PAUSE-RATINGS-START -->'
VFS_PAUSE_RATINGS_END = '<!-- KPM-VFS-PAUSE-RATINGS-END -->'
DIALOG_SEEKBAR_PAUSE_RATINGS_START = '<!-- KPM-DIALOG-SEEKBAR-PAUSE-RATINGS-START -->'
DIALOG_SEEKBAR_PAUSE_RATINGS_END = '<!-- KPM-DIALOG-SEEKBAR-PAUSE-RATINGS-END -->'
DIALOG_SEEKBAR_AUTO_OSD_MARKER = '<!-- KPM-DIALOG-SEEKBAR-AUTO-VIDEOOSD -->'
VIDEOOSD_CLEARART_START = '<!-- KPM-VIDEOOSD-CLEARART-RIGHT-START -->'
VIDEOOSD_CLEARART_END = '<!-- KPM-VIDEOOSD-CLEARART-RIGHT-END -->'
VIDEOOSD_FAST_CLOSE_START = '<!-- KPM-VIDEOOSD-FAST-CLOSE-RESUME-START -->'
VIDEOOSD_FAST_CLOSE_END = '<!-- KPM-VIDEOOSD-FAST-CLOSE-RESUME-END -->'
OSD_PLOT_WIDTH_START = '<!-- KPM-OSD-PLOT-WIDTH-START -->'
OSD_PLOT_WIDTH_END = '<!-- KPM-OSD-PLOT-WIDTH-END -->'
DIALOG_SEEKBAR_CLEARART_START = '<!-- KPM-DIALOG-SEEKBAR-CLEARART-BEHIND-PROGRESS-START -->'
DIALOG_SEEKBAR_CLEARART_END = '<!-- KPM-DIALOG-SEEKBAR-CLEARART-BEHIND-PROGRESS-END -->'
OSD_RANGE_MARKERS_START = '<!-- KPM-OSD-RANGE-MARKERS-HIDDEN-START -->'
OSD_RANGE_MARKERS_END = '<!-- KPM-OSD-RANGE-MARKERS-HIDDEN-END -->'
ACTION_OSD_PAUSE_STAY_START = '<!-- KPM-ACTION-OSD-PAUSE-STAY-START -->'
ACTION_OSD_PAUSE_STAY_END = '<!-- KPM-ACTION-OSD-PAUSE-STAY-END -->'
STUDIO_IMAGE_VAR_START = '<!-- KPM-STUDIO-LOGOS-IMAGE-VAR-START -->'
STUDIO_IMAGE_VAR_END = '<!-- KPM-STUDIO-LOGOS-IMAGE-VAR-END -->'
STUDIO_FURNITURE_START = '<!-- KPM-STUDIO-LOGOS-FURNITURE-START -->'
STUDIO_FURNITURE_END = '<!-- KPM-STUDIO-LOGOS-FURNITURE-END -->'
STUDIO_FURNITURE_CURRENT_MARKER = '<!-- KPM-STUDIO-LOGOS-FURNITURE-v0.1.30-SINGLE -->'
BROKEN_STUDIO_TEXTURE_NAMES = ('centropolis entertainment.png', 'dune entertainment.png', 'gk films.png', 'thunder road.png')

INDEPENDENT_FANART_VALUE_MARKER = '<!-- KPM-INDEPENDENT-FANART-V1 -->'
INDEPENDENT_FANART_LAUNCH_VALUE_MARKER = '<!-- KPM-INDEPENDENT-FANART-LAUNCH-V2 -->'
KPM_FANART_SOURCE_BRIDGE_MARKER = '<!-- KPM-FANART-AF3-SOURCE-BRIDGE-V1 -->'
KPM_FANART_SOURCE_BRIDGE_END = '<!-- KPM-FANART-AF3-SOURCE-BRIDGE-END -->'
KPM_FANART_FOCUS_BRIDGE_MARKER = '<!-- KPM-FANART-FOCUS-BRIDGE-V1 -->'
KPM_FANART_FOCUS_BRIDGE_END = '<!-- KPM-FANART-FOCUS-BRIDGE-END -->'
KPM_FANART_FOCUS_CLEAR_MARKER = '<!-- KPM-FANART-FOCUS-CLEAR-V1 -->'
KPM_FANART_FOCUS_CLEAR_END = '<!-- KPM-FANART-FOCUS-CLEAR-END -->'
KPM_FANART_FOCUS_FILES = ('Includes_Hubs.xml', 'Includes_Widgets.xml', 'Includes_Lists.xml', 'Includes_Views_Combined.xml')
INDEPENDENT_FANART_PATCH_ID = 'tmdb_focus_random_v11'
INDEPENDENT_FANART_VARIABLES = (
    'Image_Current_Background',
    'Image_Background',
    'Image_Foreground_NoService',
    'Image_Foreground',
    'Image_FanartFallback',
)
INDEPENDENT_FANART_LAUNCH_VARIABLES = (
    'Image_StartUp',
    'Image_FanartFallback',
)


PATCH_DETAILS = {
    'upnext_episode_thumb': {
        'title': 'Episode Thumb Up Next',
        'apply_label': 'Patch Episode Thumb Up Next',
        'remove_label': 'Remove Episode Thumb Up Next',
        'summary': 'Use next episode thumbnail first.',
        'function': 'Makes the Up Next popup show the next episode thumbnail first, then falls back to landscape and fanart.',
        'target': 'skin.arctic.fuse.3/1080i/Includes_Images.xml -> variable Image_UpNext',
        'reference': 'Native Kodi patcher. No bundled standalone patch file.',
    },
    'vfs_pause_ratings': {
        'title': 'Pause Shows Full OSD',
        'apply_label': 'Patch Pause Shows Full OSD',
        'remove_label': 'Remove Pause Shows Full OSD',
        'summary': 'Open full VideoOSD on pause through a dialog-safe service, keep it behind dialogs, hide chapter ticks, shorten OSD plot, close safely after resume.',
        'function': 'Marks DialogSeekBar.xml as KPM-managed and uses service.py so a normal pause opens videoosd quickly on normal pause with a longer playback-start guard, matching the result of pressing M; normal pause opens fast while playback-start auto subtitle dialogs are still guarded. It removes the old minimalist inline Paused rating fallback, draws a native/TMDbHelper clearart panel behind the progress line in DialogSeekBar, hides chapter/cutlist marker ticks, shortens the OSD plot width in Includes_OSD.xml, prevents OSD timeout while paused, patches the main play button, and starts the KPM lightweight resume monitor. The monitor no longer uses Action(Back); it keeps VideoOSD behind foreign dialogs and only closes VideoOSD safely after resume when no other dialog has focus.',
        'target': 'skin.arctic.fuse.3/1080i/DialogSeekBar.xml + VideoOSD.xml + Includes_OSD.xml + Includes_Actions.xml; old VideoFullScreen.xml and old inline DialogSeekBar/VideoOSD clearart markers are cleaned if present; service.py monitors pause→play only while this patch is enabled and does not steal focus from other dialogs',
        'reference': 'Native Kodi patcher. Pause opens VideoOSD by Kodi window action. A lightweight KPM service only closes VideoOSD after resume and avoids Action(Back). Clearart may use Kodi native artwork first and TMDbHelper.Player.ClearArt as fallback.',
    },
    'reliable_studio_logos': {
        'title': 'Reliable Studio Logos',
        'apply_label': 'Patch Reliable Studio Logos',
        'remove_label': 'Remove Reliable Studio Logos',
        'summary': 'Show one reliable valid studio logo only, including parent TV show studios for episodes.',
        'function': 'Replaces AF3 raw studio texture lookup with a single KPM resolved studio logo property. KPM scans/caches the installed resource.images.studios.coloured pack, splits multi-studio labels, uses database studios and parent TV show studios for episode items, skips missing or known-broken logos, and fills KPM.StudioLogo.1 with the first valid match. Metadata in MyVideos is not changed.',
        'target': 'skin.arctic.fuse.3/1080i -> Includes_Images.xml variable Image_CombinedStudio and Includes_Furniture.xml include Furniture_Studio; service.py fills Window(Home).Property(KPM.StudioLogo.1)',
        'reference': 'Native Kodi patcher using installed studio resource names. Single-logo mode only; no raw AF3 fallback.',
    },
    'tmdb_focus_random_v12': {
        'title': 'TMDbHelper Visit Random Fanart',
        'apply_label': 'Patch TMDbHelper Visit Random Fanart',
        'remove_label': 'Restore TMDbHelper Visit Random Fanart',
        'summary': 'With AF3 Cycle Fanart ON, choose one random extra fanart per media visit and keep it sticky while the same item remains focused.',
        'function': 'Patches TMDbHelper monitor images so Art(fanart{x}) still chooses from extra fanart, but only when a valid media item changes. The chosen fanart is sticky while the same media key remains active. Non-media/transient focus states do not open a new random visit. A -> B -> A is allowed to random A again. V15 resolves Home/Hub from the current-window visual container first (focused media container, then current TMDbHelper/LRS WidgetContainer, then Home fallbacks), so stale KPM Home containers cannot beat the actual AF3/TMDbHelper visual item, so Play/More/tab focus does not create false visits. It also primes the current blur property with the newly selected source immediately, reducing the stale old-item fanart flash while blur_v3 is generated.',
        'target': 'plugin.video.themoviedb.helper/resources/tmdbhelper/lib/monitor/imgmon.py + images.py',
        'reference': 'Advanced patch only. Requires AF3 Cycle Fanart ON. AF3 blur/render pipeline remains untouched; TMDbHelper blur_v3 still renders the output.',
    },
    'shw_random_movies_tvshows': {
        'title': 'Movies + Shows Screensaver',
        'apply_label': 'Patch Movies + Shows Screensaver',
        'remove_label': 'Remove Movies + Shows Screensaver',
        'summary': 'Random movies + TV shows only; no episodes.',
        'function': 'Adds a Skin Helper Widgets random source that returns movies and TV shows only, then points AF3 screensaver widget to that source so episodes are excluded.',
        'target': 'script.skin.helper.widgets/resources/lib/media.py + skin.arctic.fuse.3/1080i/Includes_Defaults.xml',
        'reference': 'Converted to native Kodi patcher. No bundled standalone patch file.',
    },
}


def patch_detail(patch_id: str) -> dict:
    return PATCH_DETAILS.get(patch_id, {})


def patch_title(patch_id: str, fallback: str) -> str:
    return patch_detail(patch_id).get('title', fallback)


def menu_label(patch_id: str, mode: str) -> str:
    data = patch_detail(patch_id)
    return data.get('apply_label' if mode == 'apply' else 'remove_label', data.get('title', patch_id))


PATCH_ORDER = (
    ('upnext_episode_thumb', 'status_upnext', 'patch_upnext', 'remove_upnext'),
    ('shw_random_movies_tvshows', 'status_shw', 'patch_shw', 'remove_shw'),
    ('vfs_pause_ratings', 'status_vfs_pause_ratings', 'patch_vfs_pause_ratings', 'remove_vfs_pause_ratings'),
    ('reliable_studio_logos', 'status_reliable_studio_logos', 'patch_reliable_studio_logos', 'remove_reliable_studio_logos'),
)

# v0.1.44 keeps fanart diagnostics only; KPM no longer installs fanart or AF3 x LRS patches.


def patch_details_summary(include_status: bool = False) -> str:
    chunks = []
    for patch_id, status_name, _apply_name, _remove_name in PATCH_ORDER:
        data = patch_detail(patch_id)
        heading = data.get('title', patch_id)
        if include_status:
            status_func = globals().get(status_name)
            if status_func:
                try:
                    heading += f': {status_func()}'
                except Exception as exc:
                    heading += f': Error ({exc})'
        chunks.append(
            f"{heading}\n"
            f"Function: {data.get('function', '-')}\n"
            f"Target: {data.get('target', '-')}\n"
            f"Reference: {data.get('reference', '-')}"
        )
    return '\n\n'.join(chunks)


def log(message: str, level=None) -> None:
    if xbmc:
        xbmc.log(f'[{ADDON_NAME}] {message}', level or xbmc.LOGINFO)
    else:
        print(f'[{ADDON_NAME}] {message}')


def notify(message: str, icon=None) -> None:
    if xbmcgui:
        xbmcgui.Dialog().notification(ADDON_NAME, message, icon or xbmcgui.NOTIFICATION_INFO, 3500)
    else:
        print(message)


def ok(title: str, message: str) -> None:
    if xbmcgui:
        xbmcgui.Dialog().ok(title, message)
    else:
        print('\n' + title + '\n' + message)


def yesno(title: str, message: str) -> bool:
    if xbmcgui:
        return xbmcgui.Dialog().yesno(title, message)
    return True


def translate(path: str) -> str:
    if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if xbmc and hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return (path
            .replace('special://home/', os.environ.get('KODI_HOME', 'E:/Kodi/portable_data/'))
            .replace('special://profile/', os.environ.get('KODI_PROFILE', 'E:/Kodi/portable_data/userdata/')))


def addon_data_dir(*parts: str) -> str:
    base = translate(f'special://profile/addon_data/{ADDON_ID}')
    path = os.path.join(base, *parts)
    os.makedirs(path, exist_ok=True)
    return path


def norm(path: str) -> str:
    return os.path.normpath(path)


def read_text(path: str) -> str:
    if not os.path.exists(path):
        raise FileNotFoundError(f'File not found: {path}')
    with open(path, 'r', encoding='utf-8-sig', errors='replace', newline='') as handle:
        return handle.read()


def write_text(path: str, text: str) -> None:
    # This writes the active file after a targeted text edit. It never copies a bundled full target file over it.
    with open(path, 'w', encoding='utf-8', errors='replace', newline='') as handle:
        handle.write(text)


def newline_of(text: str) -> str:
    return '\r\n' if '\r\n' in text else '\n'


def safe_name(path: str) -> str:
    drive, tail = os.path.splitdrive(path)
    value = (drive.replace(':', '') + tail).replace('\\', '__').replace('/', '__').strip('_')
    return value or 'file'


def save_json(path: str, data: dict) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8') as handle:
        json.dump(data, handle, indent=2, ensure_ascii=False)


def load_json(path: str) -> dict:
    with open(path, 'r', encoding='utf-8') as handle:
        return json.load(handle)


def state_file(patch_id: str) -> str:
    return os.path.join(addon_data_dir('state'), f'{patch_id}.json')


def save_state(patch_id: str, data: dict) -> None:
    data.setdefault('patch_id', patch_id)
    data.setdefault('version', VERSION)
    data.setdefault('saved_at', time.strftime('%Y-%m-%d %H:%M:%S'))
    save_json(state_file(patch_id), data)


def load_state(patch_id: str) -> dict:
    path = state_file(patch_id)
    if not os.path.exists(path):
        raise FileNotFoundError(f'Patch state not found: {path}')
    return load_json(path)


def delete_state(patch_id: str) -> None:
    path = state_file(patch_id)
    if os.path.exists(path):
        os.remove(path)


def kpm_settings_file() -> str:
    return os.path.join(addon_data_dir(), 'settings.json')


def load_kpm_settings() -> dict:
    path = kpm_settings_file()
    data = {'studio_logo_count': 1, 'studio_debug': False}
    if os.path.exists(path):
        try:
            loaded = load_json(path)
            if isinstance(loaded, dict):
                data.update(loaded)
        except Exception:
            pass
    try:
        count = int(data.get('studio_logo_count', 1))
    except Exception:
        count = 1
    data['studio_logo_count'] = 1
    return data


def save_kpm_settings(data: dict) -> None:
    current = load_kpm_settings()
    current.update(data or {})
    try:
        current['studio_logo_count'] = 1
    except Exception:
        current['studio_logo_count'] = 1
    save_json(kpm_settings_file(), current)


def snapshot(patch_id: str, paths: List[str]) -> None:
    # Safety only. Normal restore/remove below is block-level and does not use this to overwrite target files.
    root = addon_data_dir('snapshots', patch_id, time.strftime('%Y%m%d-%H%M%S'))
    manifest = []
    for path in paths:
        if os.path.exists(path):
            dst_name = safe_name(path)
            shutil.copy2(path, os.path.join(root, dst_name))
            manifest.append({'source': path, 'snapshot': dst_name})
    save_json(os.path.join(root, 'manifest.json'), {'files': manifest})


def af3_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/skin.arctic.fuse.3'), *parts))


def tmdbhelper_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/plugin.video.themoviedb.helper'), *parts))


def skinhelper_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/script.skin.helper.widgets'), *parts))


def clear_pycache(folder: str, prefixes: Tuple[str, ...]) -> None:
    cache = os.path.join(folder, '__pycache__')
    if not os.path.isdir(cache):
        return
    for name in os.listdir(cache):
        if name.endswith('.pyc') and any(name.startswith(prefix + '.') for prefix in prefixes):
            try:
                os.remove(os.path.join(cache, name))
            except Exception:
                pass


@dataclass
class Result:
    name: str
    status: str
    detail: str = ''


# -----------------------------------------------------------------------------
# Patch 1: AF3 Up Next episode thumbnail priority
# -----------------------------------------------------------------------------

def upnext_target() -> str:
    return af3_path('1080i', 'Includes_Images.xml')


def status_upnext() -> str:
    target = upnext_target()
    if not os.path.exists(target):
        return 'Missing target'
    text = read_text(target)
    if UPNEXT_MARKER in text:
        return 'Patched'
    if '<variable name="Image_UpNext">' in text:
        return 'Not patched'
    return 'Unknown layout'


def patch_upnext() -> Result:
    name = patch_title('upnext_episode_thumb', 'Episode Thumb Up Next')
    target = upnext_target()
    text = read_text(target)
    if UPNEXT_MARKER in text:
        return Result(name, 'Skipped', 'Already patched.')

    pattern = r'(?ms)([ \t]*)<variable\s+name="Image_UpNext">.*?</variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Anchor not found: variable Image_UpNext in Includes_Images.xml')

    original = match.group(0)
    nl = newline_of(text)
    indent = match.group(1)
    inner = indent + '    '
    new_block = nl.join([
        f'{indent}<variable name="Image_UpNext">',
        f'{inner}{UPNEXT_MARKER}',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(thumb))">$INFO[Window.Property(thumb)]</value>',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(landscape))">$INFO[Window.Property(landscape)]</value>',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(fanart))">$INFO[Window.Property(fanart)]</value>',
        f'{indent}</variable>',
    ])

    snapshot('upnext_episode_thumb', [target])
    save_state('upnext_episode_thumb', {'target': target, 'original_block': original})
    text = text[:match.start()] + new_block + text[match.end():]
    write_text(target, text)
    return Result(name, 'Patched', 'Image_UpNext priority: thumb -> landscape -> fanart.')


def remove_upnext() -> Result:
    name = patch_title('upnext_episode_thumb', 'Episode Thumb Up Next')
    target = upnext_target()
    text = read_text(target)
    if UPNEXT_MARKER not in text:
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('upnext_episode_thumb')
    original = state.get('original_block')
    if not original:
        raise RuntimeError('Original Image_UpNext block is missing from saved state.')
    pattern = r'(?ms)[ \t]*<variable\s+name="Image_UpNext">(?:(?!</variable>).)*?' + re.escape(UPNEXT_MARKER) + r'.*?</variable>'
    if not re.search(pattern, text):
        raise RuntimeError('Patched Image_UpNext block not found.')
    text = re.sub(pattern, original, text, count=1)
    write_text(target, text)
    delete_state('upnext_episode_thumb')
    return Result(name, 'Removed', 'Original Image_UpNext block restored only.')


# -----------------------------------------------------------------------------
# Patch 2 removed in v0.1.44: fanart patch engine is no longer installed/removed by KPM.


# Patch 3: Skin Helper Widgets random Movies + TV Shows screensaver for AF3
# -----------------------------------------------------------------------------

def shw_targets() -> Tuple[str, str]:
    media = skinhelper_path('resources', 'lib', 'media.py')
    defaults = af3_path('1080i', 'Includes_Defaults.xml')
    return media, defaults


def status_shw() -> str:
    media, defaults = shw_targets()
    if not os.path.exists(media) or not os.path.exists(defaults):
        return 'Missing target'
    t1 = read_text(media)
    t2 = read_text(defaults)
    method_ok = SHW_METHOD_START in t1 or LEGACY_SHW_METHOD_START in t1 or re.search(r'def\s+randommoviestvshows\s*\(\s*self\s*\)\s*:', t1)
    xml_ok = SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2
    if method_ok and xml_ok:
        return 'Patched'
    return 'Not patched'


def extract_variable_block(text: str, variable_name: str) -> Optional[str]:
    pattern = r'(?ms)[ \t]*<variable\s+name="' + re.escape(variable_name) + r'">.*?</variable>'
    match = re.search(pattern, text)
    return match.group(0) if match else None


def legacy_shw_xml_backup(defaults: str) -> Optional[str]:
    backup = defaults + '.afm-random-movies-tvshows-xml.bak'
    if os.path.exists(backup):
        try:
            return extract_variable_block(read_text(backup), 'Defs_ScreensaverWidget')
        except Exception:
            return None
    return None


def patch_shw_media(text: str) -> str:
    nl = newline_of(text)
    has_any_method = (SHW_METHOD_START in text or LEGACY_SHW_METHOD_START in text or
                      re.search(r'def\s+randommoviestvshows\s*\(\s*self\s*\)\s*:', text))
    if not has_any_method:
        method = nl.join([
            f'    {SHW_METHOD_START}',
            '    def randommoviestvshows(self):',
            '        """get random movies and tvshows only - no episodes, no music, no pvr"""',
            '        all_items = self.movies.random()',
            '        all_items += self.tvshows.random()',
            '        return sorted(all_items, key=lambda k: random.random())[:self.options["limit"]]',
            f'    {SHW_METHOD_END}',
            '',
        ]) + nl
        anchor = '    def inprogress(self):'
        if anchor not in text:
            raise RuntimeError('Anchor not found in media.py: def inprogress(self)')
        text = text.replace(anchor, method + anchor, 1)

    if SHW_ENTRY_MARKER not in text and LEGACY_SHW_ENTRY_MARKER not in text:
        old = '            (self.addon.getLocalizedString(32059), "random&mediatype=media", "DefaultMovies.png"),'
        if old in text:
            new = old + nl + f'            ("Random Movies + TV Shows", "randommoviestvshows&mediatype=media", "DefaultMovies.png"),  {SHW_ENTRY_MARKER}'
            text = text.replace(old, new, 1)
    return text


def patch_shw_xml(text: str, limit: int) -> Tuple[str, str]:
    pattern = r'(?ms)([ \t]*)<variable\s+name="Defs_ScreensaverWidget">.*?</variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_Defaults.xml: variable Defs_ScreensaverWidget')
    original = match.group(0)
    nl = newline_of(text)
    indent = match.group(1)
    inner = indent + '    '
    path = f'plugin://script.skin.helper.widgets/?action=randommoviestvshows&amp;mediatype=media&amp;limit={limit}'
    new_block = nl.join([
        f'{indent}<variable name="Defs_ScreensaverWidget">',
        f'{inner}{SHW_XML_MARKER}',
        f'{inner}<value>{path}</value>',
        f'{indent}</variable>',
    ])
    text = text[:match.start()] + new_block + text[match.end():]
    return text, original


def patch_shw(limit: int = 100) -> Result:
    name = patch_title('shw_random_movies_tvshows', 'Movies + Shows Screensaver')
    media, defaults = shw_targets()
    t1 = read_text(media)
    t2 = read_text(defaults)
    if (SHW_METHOD_START in t1 or LEGACY_SHW_METHOD_START in t1) and (SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2):
        return Result(name, 'Skipped', 'Already patched.')

    snapshot('shw_random_movies_tvshows', [media, defaults])
    n1 = patch_shw_media(t1)
    if SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2:
        n2 = t2
        original_xml = None
    else:
        n2, original_xml = patch_shw_xml(t2, limit)
    save_state('shw_random_movies_tvshows', {'media': media, 'defaults': defaults, 'original_xml_block': original_xml})
    write_text(media, n1)
    write_text(defaults, n2)
    clear_pycache(os.path.dirname(media), ('media',))
    return Result(name, 'Patched', f'Screensaver path: random movies + TV shows only, limit={limit}.')


def remove_shw() -> Result:
    name = patch_title('shw_random_movies_tvshows', 'Movies + Shows Screensaver')
    media, defaults = shw_targets()
    t1 = read_text(media)
    t2 = read_text(defaults)
    has_markers = any(marker in t1 for marker in (SHW_METHOD_START, LEGACY_SHW_METHOD_START, SHW_ENTRY_MARKER, LEGACY_SHW_ENTRY_MARKER)) or any(marker in t2 for marker in (SHW_XML_MARKER, LEGACY_SHW_XML_MARKER))
    if not has_markers:
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('shw_random_movies_tvshows') if os.path.exists(state_file('shw_random_movies_tvshows')) else {}

    # Remove method block by marker. Supports current KPM markers and the older uploaded AFM PowerShell markers.
    for start, end in ((SHW_METHOD_START, SHW_METHOD_END), (LEGACY_SHW_METHOD_START, LEGACY_SHW_METHOD_END)):
        method_pattern = r'(?ms)\r?\n?    ' + re.escape(start) + r'.*?    ' + re.escape(end) + r'\r?\n?'
        t1 = re.sub(method_pattern, '\n', t1, count=1)

    # Remove optional listing line by marker.
    for marker in (SHW_ENTRY_MARKER, LEGACY_SHW_ENTRY_MARKER):
        entry_pattern = r'(?m)^.*' + re.escape(marker) + r'.*(\r?\n)?'
        t1 = re.sub(entry_pattern, '', t1, count=1)

    # Restore only the original XML variable block. If this was an older PS1 patch, read its .bak file
    # and restore only the Defs_ScreensaverWidget variable from that backup, not the whole XML file.
    if SHW_XML_MARKER in t2 or LEGACY_SHW_XML_MARKER in t2:
        original = state.get('original_xml_block') or legacy_shw_xml_backup(defaults)
        if not original:
            raise RuntimeError('Cannot remove SHW XML patch: original Defs_ScreensaverWidget block state/legacy backup is missing.')
        marker_pat = re.escape(SHW_XML_MARKER) + '|' + re.escape(LEGACY_SHW_XML_MARKER)
        pattern = r'(?ms)[ \t]*<variable\s+name="Defs_ScreensaverWidget">(?:(?!</variable>).)*?(?:' + marker_pat + r').*?</variable>'
        t2 = re.sub(pattern, original, t2, count=1)

    write_text(media, t1)
    write_text(defaults, t2)
    clear_pycache(os.path.dirname(media), ('media',))
    delete_state('shw_random_movies_tvshows')
    return Result(name, 'Removed', 'Injected method/listing removed; original XML variable restored only.')



# -----------------------------------------------------------------------------
# Patch 4 removed in v0.1.44: AF3 x LRS Ratings UI is no longer installed/removed by KPM.


# Patch 5: fullscreen pause rating row beside Paused
# -----------------------------------------------------------------------------

def vfs_pause_target() -> str:
    # Legacy target from v0.1.8-v0.1.11. Kept so remove/patch can clean old blocks.
    return af3_path('1080i', 'VideoFullScreen.xml')


def seekbar_pause_target() -> str:
    # Actual AF3 pause overlay with the Paused header is DialogSeekBar.xml.
    return af3_path('1080i', 'DialogSeekBar.xml')


def video_osd_target() -> str:
    # Full OSD window shown by pressing M / videoosd.
    return af3_path('1080i', 'VideoOSD.xml')


def includes_osd_target() -> str:
    # OSD detail layout includes title / plot / metadata area used by VideoOSD.
    return af3_path('1080i', 'Includes_OSD.xml')


def includes_actions_target() -> str:
    # AF3 OSD timeout actions live here.
    return af3_path('1080i', 'Includes_Actions.xml')


def includes_images_target() -> str:
    return af3_path('1080i', 'Includes_Images.xml')


def includes_furniture_target() -> str:
    return af3_path('1080i', 'Includes_Furniture.xml')


def _has_marked_block(text: str, start: str, end: str) -> bool:
    return start in text and end in text


def status_vfs_pause_ratings() -> str:
    seekbar = seekbar_pause_target()
    videoosd = video_osd_target()
    includes_osd = includes_osd_target()
    includes_actions = includes_actions_target()
    vfs = vfs_pause_target()
    if not os.path.exists(seekbar):
        return 'Missing DialogSeekBar.xml'
    if not os.path.exists(videoosd):
        return 'Missing VideoOSD.xml'
    if not os.path.exists(includes_osd):
        return 'Missing Includes_OSD.xml'
    if not os.path.exists(includes_actions):
        return 'Missing Includes_Actions.xml'
    seekbar_text = read_text(seekbar)
    videoosd_text = read_text(videoosd)
    includes_osd_text = read_text(includes_osd)
    includes_actions_text = read_text(includes_actions)
    has_auto_osd = DIALOG_SEEKBAR_AUTO_OSD_MARKER in seekbar_text
    has_seekbar_clearart = _has_marked_block(seekbar_text, DIALOG_SEEKBAR_CLEARART_START, DIALOG_SEEKBAR_CLEARART_END)
    has_seekbar_inline = _has_marked_block(seekbar_text, DIALOG_SEEKBAR_PAUSE_RATINGS_START, DIALOG_SEEKBAR_PAUSE_RATINGS_END)
    has_videoosd_clearart = _has_marked_block(videoosd_text, VIDEOOSD_CLEARART_START, VIDEOOSD_CLEARART_END)
    has_fast_close = _has_marked_block(videoosd_text, VIDEOOSD_FAST_CLOSE_START, VIDEOOSD_FAST_CLOSE_END)
    has_plot_width = _has_marked_block(includes_osd_text, OSD_PLOT_WIDTH_START, OSD_PLOT_WIDTH_END)
    has_range_hidden = _has_marked_block(includes_osd_text, OSD_RANGE_MARKERS_START, OSD_RANGE_MARKERS_END)
    has_pause_stay = _has_marked_block(includes_actions_text, ACTION_OSD_PAUSE_STAY_START, ACTION_OSD_PAUSE_STAY_END)
    has_legacy = os.path.exists(vfs) and _has_marked_block(read_text(vfs), VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END)
    if has_auto_osd and has_seekbar_clearart and has_fast_close and has_plot_width and has_range_hidden and has_pause_stay and not has_seekbar_inline and not has_videoosd_clearart and not has_legacy:
        return 'Patched'
    parts = []
    if has_auto_osd:
        parts.append('Auto OSD')
    if has_seekbar_clearart:
        parts.append('clearart behind progress')
    if has_videoosd_clearart:
        parts.append('old front clearart cleanup available')
    if has_fast_close:
        parts.append('fast close')
    if has_plot_width:
        parts.append('plot width')
    if has_range_hidden:
        parts.append('chapter ticks hidden')
    if has_pause_stay:
        parts.append('pause stay')
    if has_seekbar_inline:
        parts.append('old inline rating cleanup available')
    if has_legacy:
        parts.append('legacy VideoFullScreen cleanup available')
    return 'Partial: ' + ', '.join(parts) if parts else 'Not patched'


def _remove_marked_block(text: str, start: str, end: str) -> Tuple[str, bool]:
    if start not in text or end not in text:
        return text, False
    pattern = r'(?ms)\s*' + re.escape(start) + r'.*?' + re.escape(end)
    new_text = re.sub(pattern, '', text, count=1)
    return new_text, new_text != text


def _remove_seekbar_auto_videoosd(text: str) -> Tuple[str, bool]:
    if DIALOG_SEEKBAR_AUTO_OSD_MARKER not in text:
        return text, False
    # v0.1.14-v0.1.20 used an immediate DialogSeekBar onload ActivateWindow(videoosd).
    # v0.1.21 keeps only a marker/comment and lets service.py open VideoOSD after a
    # short dialog-safe pause grace. Remove either shape cleanly.
    pattern = (
        r'(?ms)\s*' + re.escape(DIALOG_SEEKBAR_AUTO_OSD_MARKER) +
        r'(?:\s*<!--.*?-->)?' +
        r'(?:\s*<onload[^>]*>ActivateWindow\(videoosd\)</onload>)?'
    )
    new_text = re.sub(pattern, '', text, count=1)
    return new_text, new_text != text


def _inject_seekbar_auto_videoosd(text: str, nl: str) -> Tuple[str, bool]:
    """Mark DialogSeekBar as KPM pause-OSD managed without stealing focus.

    Earlier builds fired ActivateWindow(videoosd) directly from DialogSeekBar onload.
    That raced with automatic subtitle/add-on dialogs at playback startup and could
    leave focus on the underlying OSD. Since v0.1.21, service.py opens VideoOSD
    with no intentional normal-pause delay and only when no foreign dialog has focus; a longer guard is used only during playback startup.
    """
    text, removed = _remove_seekbar_auto_videoosd(text)
    block = nl.join([
        '    ' + DIALOG_SEEKBAR_AUTO_OSD_MARKER,
        '    <!-- KPM v0.1.23+: service.py opens videoosd with no intentional normal-pause delay; startup guard remains for auto subtitle dialogs. -->',
    ])
    if '<zorder>0</zorder>' in text:
        return text.replace('<zorder>0</zorder>', '<zorder>0</zorder>' + nl + block, 1), True
    if '<window>' in text:
        return text.replace('<window>', '<window>' + nl + block, 1), True
    raise RuntimeError('Anchor not found in DialogSeekBar.xml: <zorder>0</zorder> or <window>')




def _videoosd_clearart_block(nl: str) -> str:
    return nl.join([
        '            ' + VIDEOOSD_CLEARART_START,
        '            <!-- KPM right-side clearart panel for full VideoOSD. Kodi artwork first, TMDbHelper fallback allowed. -->',
        '            <control type="group">',
        '                <visible>Window.IsActive(videoosd) + Player.HasMedia + !Pvr.IsPlayingTv</visible>',
        '                <visible>!Window.IsVisible(DialogPlayerProcessInfo.xml) + !Window.IsVisible(DialogSlider.xml)</visible>',
        '                <right>view_osd_r</right>',
        '                <bottom>180</bottom>',
        '                <width>520</width>',
        '                <height>300</height>',
        '                <animation effect="fade" start="0" end="100" time="200">WindowOpen</animation>',
        '                <control type="image">',
        '                    <width>100%</width>',
        '                    <height>100%</height>',
        '                    <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                    <texture background="true">$INFO[VideoPlayer.Art(clearart)]</texture>',
        '                    <visible>!String.IsEmpty(VideoPlayer.Art(clearart))</visible>',
        '                </control>',
        '                <control type="image">',
        '                    <width>100%</width>',
        '                    <height>100%</height>',
        '                    <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                    <texture background="true">$INFO[VideoPlayer.Art(tvshow.clearart)]</texture>',
        '                    <visible>String.IsEmpty(VideoPlayer.Art(clearart)) + !String.IsEmpty(VideoPlayer.Art(tvshow.clearart))</visible>',
        '                </control>',
        '                <control type="image">',
        '                    <width>100%</width>',
        '                    <height>100%</height>',
        '                    <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                    <texture background="true">$INFO[Window(Home).Property(TMDbHelper.Player.ClearArt)]</texture>',
        '                    <visible>String.IsEmpty(VideoPlayer.Art(clearart)) + String.IsEmpty(VideoPlayer.Art(tvshow.clearart)) + !String.IsEmpty(Window(Home).Property(TMDbHelper.Player.ClearArt))</visible>',
        '                </control>',
        '            </control>',
        '            ' + VIDEOOSD_CLEARART_END,
    ])


def _remove_videoosd_clearart(text: str) -> Tuple[str, bool]:
    return _remove_marked_block(text, VIDEOOSD_CLEARART_START, VIDEOOSD_CLEARART_END)


def _seekbar_clearart_block(nl: str) -> str:
    return nl.join([
        '                        ' + DIALOG_SEEKBAR_CLEARART_START,
        '                        <!-- KPM clearart is intentionally drawn inside DialogSeekBar before OSD_Progress_Bar, so the progress line and time labels render above it. -->',
        '                        <control type="group">',
        '                            <visible>Window.IsActive(videoosd) + Player.HasMedia + !Pvr.IsPlayingTv</visible>',
        '                            <visible>!Window.IsVisible(DialogPlayerProcessInfo.xml) + !Window.IsVisible(DialogSlider.xml)</visible>',
        '                            <right>view_osd_r</right>',
        '                            <bottom>180</bottom>',
        '                            <width>480</width>',
        '                            <height>270</height>',
        '                            <animation effect="fade" start="0" end="100" time="200">WindowOpen</animation>',
        '                            <control type="image">',
        '                                <width>100%</width>',
        '                                <height>100%</height>',
        '                                <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                                <texture background="true">$INFO[VideoPlayer.Art(clearart)]</texture>',
        '                                <visible>!String.IsEmpty(VideoPlayer.Art(clearart))</visible>',
        '                            </control>',
        '                            <control type="image">',
        '                                <width>100%</width>',
        '                                <height>100%</height>',
        '                                <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                                <texture background="true">$INFO[VideoPlayer.Art(tvshow.clearart)]</texture>',
        '                                <visible>String.IsEmpty(VideoPlayer.Art(clearart)) + !String.IsEmpty(VideoPlayer.Art(tvshow.clearart))</visible>',
        '                            </control>',
        '                            <control type="image">',
        '                                <width>100%</width>',
        '                                <height>100%</height>',
        '                                <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                                <texture background="true">$INFO[Window(Home).Property(TMDbHelper.Player.ClearArt)]</texture>',
        '                                <visible>String.IsEmpty(VideoPlayer.Art(clearart)) + String.IsEmpty(VideoPlayer.Art(tvshow.clearart)) + !String.IsEmpty(Window(Home).Property(TMDbHelper.Player.ClearArt))</visible>',
        '                            </control>',
        '                        </control>',
        '                        ' + DIALOG_SEEKBAR_CLEARART_END,
    ])


def _remove_seekbar_clearart(text: str) -> Tuple[str, bool]:
    return _remove_marked_block(text, DIALOG_SEEKBAR_CLEARART_START, DIALOG_SEEKBAR_CLEARART_END)


def _inject_seekbar_clearart(text: str, nl: str) -> Tuple[str, bool]:
    text, _ = _remove_seekbar_clearart(text)
    block = _seekbar_clearart_block(nl)
    anchor = '                        <include>OSD_Progress_Labels</include>'
    if anchor not in text:
        raise RuntimeError('Anchor not found in DialogSeekBar.xml: OSD_Progress_Labels include')
    return text.replace(anchor, block + nl + anchor, 1), True


def _inject_videoosd_clearart(text: str, nl: str) -> Tuple[str, bool]:
    text, removed = _remove_videoosd_clearart(text)
    block = _videoosd_clearart_block(nl)
    anchor = nl + '    </controls>'
    if anchor not in text:
        raise RuntimeError('Anchor not found in VideoOSD.xml: closing </controls>')
    text = text.replace(anchor, nl + block + anchor, 1)
    return text, True


def _fast_close_block(nl: str, indent: str = '                            ') -> str:
    return nl.join([
        indent + VIDEOOSD_FAST_CLOSE_START,
        indent + '<onclick condition="Player.Paused">Close</onclick>',
        indent + '<onclick>PlayerControl(Play)</onclick>',
        indent + VIDEOOSD_FAST_CLOSE_END,
    ])


def _restore_videoosd_fast_close(text: str, nl: str) -> Tuple[str, bool]:
    if VIDEOOSD_FAST_CLOSE_START not in text or VIDEOOSD_FAST_CLOSE_END not in text:
        return text, False
    pattern = re.compile(r'(?ms)\s*' + re.escape(VIDEOOSD_FAST_CLOSE_START) + r'.*?' + re.escape(VIDEOOSD_FAST_CLOSE_END))
    new_text = pattern.sub(nl + '                            <onclick>PlayerControl(Play)</onclick>', text, count=1)
    return new_text, new_text != text


def _inject_videoosd_fast_close(text: str, nl: str) -> Tuple[str, bool]:
    text, _ = _restore_videoosd_fast_close(text, nl)
    pattern = re.compile(
        r'(?ms)(<control type="button" id="6001">.*?)(\s*<onclick>PlayerControl\(Play\)</onclick>)(.*?</control>)'
    )
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in VideoOSD.xml: button id 6001 PlayerControl(Play)')
    block = nl + _fast_close_block(nl)
    return text[:match.start(2)] + block + text[match.end(2):], True


def _restore_osd_plot_width(text: str, nl: str) -> Tuple[str, bool]:
    """Restore the OSD plot width parameter modified by KPM."""
    if OSD_PLOT_WIDTH_START not in text or OSD_PLOT_WIDTH_END not in text:
        return text, False
    pattern = re.compile(
        r'(?ms)\s*' + re.escape(OSD_PLOT_WIDTH_START) + r'.*?' + re.escape(OSD_PLOT_WIDTH_END)
    )
    replacement = nl + '                    <param name="width">info_panel_w</param>'
    new_text = pattern.sub(replacement, text, count=1)
    return new_text, new_text != text


def _inject_osd_plot_width(text: str, nl: str) -> Tuple[str, bool]:
    """Shorten only the plot width inside OSD_Progress_Details_Extended.

    This keeps title, info line, ratings, and buttons unchanged, but stops the
    plot text before the clearart area on the right.
    """
    text, _ = _restore_osd_plot_width(text, nl)
    pattern = re.compile(
        r'(?ms)(<include name="OSD_Progress_Details_Extended">.*?'
        r'<include content="Info_Plot" condition="\$PARAM\[plot_visible\]">.*?)'
        r'(\s*<param name="width">info_panel_w</param>)'
    )
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_OSD.xml: OSD_Progress_Details_Extended Info_Plot width')
    block = nl.join([
        '                    ' + OSD_PLOT_WIDTH_START,
        '                    <param name="width">900</param>',
        '                    ' + OSD_PLOT_WIDTH_END,
    ])
    return text[:match.start(2)] + nl + block + text[match.end(2):], True


def _restore_osd_range_markers(text: str, nl: str) -> Tuple[str, bool]:
    """Restore cutlist/chapter range marker controls hidden by KPM."""
    if OSD_RANGE_MARKERS_START not in text or OSD_RANGE_MARKERS_END not in text:
        return text, False
    pattern = re.compile(
        r'(?ms)\s*' + re.escape(OSD_RANGE_MARKERS_START) + r'.*?' + re.escape(OSD_RANGE_MARKERS_END)
    )
    replacement = nl.join([
        '        <!-- CutList and Chapters Range -->',
        '        <control type="ranges">',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="panel_fg_50">progress/marker.png</righttexture>',
        '            <info>Player.CutList</info>',
        '        </control>',
        '        <control type="ranges">',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="panel_fg_50">progress/marker.png</righttexture>',
        '            <info>Player.Chapters</info>',
        '        </control>',
    ])
    new_text = pattern.sub(nl + replacement, text, count=1)
    return new_text, new_text != text


def _inject_osd_range_markers_hidden(text: str, nl: str) -> Tuple[str, bool]:
    """Hide chapter/cutlist tick markers on the progress line.

    The orange progress and time labels remain intact. Only the small white
    range/chapter marker ticks are suppressed.
    """
    text, _ = _restore_osd_range_markers(text, nl)
    pattern = re.compile(
        r'(?ms)(\s*<!-- CutList and Chapters Range -->\s*'
        r'<control type="ranges">.*?<info>Player\.CutList</info>\s*</control>\s*'
        r'<control type="ranges">.*?<info>Player\.Chapters</info>\s*</control>)'
    )
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_OSD.xml: CutList and Chapters Range controls')
    block = nl.join([
        '        ' + OSD_RANGE_MARKERS_START,
        '        <!-- KPM hides the small cutlist/chapter marker ticks on the progress line. -->',
        '        <control type="ranges">',
        '            <visible>false</visible>',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="00ffffff">progress/marker.png</righttexture>',
        '            <info>Player.CutList</info>',
        '        </control>',
        '        <control type="ranges">',
        '            <visible>false</visible>',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="00ffffff">progress/marker.png</righttexture>',
        '            <info>Player.Chapters</info>',
        '        </control>',
        '        ' + OSD_RANGE_MARKERS_END,
    ])
    return text[:match.start()] + nl + block + text[match.end():], True


def _original_action_osd_button_block(nl: str) -> str:
    return nl.join([
        '    <include name="Action_OSD_Button">',
        '        <onfocus condition="!String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onfocus>',
        '        <onunfocus>CancelAlarm(osd_timeout,true)</onunfocus>',
        '',
        '        <onclick condition="!String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onclick>',
        '    </include>',
    ])


def _pause_stay_action_osd_button_block(nl: str) -> str:
    return nl.join([
        '    ' + ACTION_OSD_PAUSE_STAY_START,
        '    <!-- KPM: while paused, do not start AF3 osd_timeout; the full OSD stays until playback resumes or user closes it. -->',
        '    <include name="Action_OSD_Button">',
        '        <onfocus condition="!Player.Paused + !String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onfocus>',
        '        <onfocus condition="Player.Paused">CancelAlarm(osd_timeout,true)</onfocus>',
        '        <onunfocus>CancelAlarm(osd_timeout,true)</onunfocus>',
        '',
        '        <onclick condition="!Player.Paused + !String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onclick>',
        '        <onclick condition="Player.Paused">CancelAlarm(osd_timeout,true)</onclick>',
        '    </include>',
        '    ' + ACTION_OSD_PAUSE_STAY_END,
    ])


def _restore_action_osd_pause_stay(text: str, nl: str) -> Tuple[str, bool]:
    if ACTION_OSD_PAUSE_STAY_START not in text or ACTION_OSD_PAUSE_STAY_END not in text:
        return text, False
    pattern = re.compile(
        r'(?ms)\s*' + re.escape(ACTION_OSD_PAUSE_STAY_START) + r'.*?' + re.escape(ACTION_OSD_PAUSE_STAY_END)
    )
    replacement = nl + _original_action_osd_button_block(nl)
    new_text = pattern.sub(replacement, text, count=1)
    return new_text, new_text != text


def _inject_action_osd_pause_stay(text: str, nl: str) -> Tuple[str, bool]:
    text, _ = _restore_action_osd_pause_stay(text, nl)
    pattern = re.compile(r'(?ms)\s*<include name="Action_OSD_Button">.*?</include>')
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_Actions.xml: include Action_OSD_Button')
    block = nl + _pause_stay_action_osd_button_block(nl)
    return text[:match.start()] + block + text[match.end():], True

def _seekbar_lrs_slot_controls(slot: int, nl: str, indent: str = '                                ') -> str:
    """Hard-render one LRS player rating slot for DialogSeekBar.xml.

    No TMDbHelper, no Info_Meta_Object. It reads only:
      LibraryRatings.Player.RatingSlotN_Source
      LibraryRatings.Player.RatingSlotN_IconFile
      LibraryRatings.Player.RatingSlotN_Label
    """
    base = 'LibraryRatings.Player.RatingSlot{0}'.format(slot)
    has_data = (
        '!String.IsEmpty(Window(Home).Property({0}_Label)) + '
        '!String.IsEmpty(Window(Home).Property({0}_IconFile))'
    ).format(base)
    imdb_visible = has_data + ' + String.IsEqual(Window(Home).Property({0}_Source),imdb)'.format(base)
    other_visible = has_data + ' + !String.IsEqual(Window(Home).Property({0}_Source),imdb)'.format(base)
    return nl.join([
        indent + '<!-- LRS Player RatingSlot{0} -->'.format(slot),
        indent + '<control type="image">',
        indent + '    <width>52</width>',
        indent + '    <height>32</height>',
        indent + '    <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        indent + '    <centertop>50%</centertop>',
        indent + '    <texture colordiffuse="panel_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property({0}_IconFile)]</texture>'.format(base),
        indent + '    <visible>{0}</visible>'.format(imdb_visible),
        indent + '</control>',
        indent + '<control type="image">',
        indent + '    <width>32</width>',
        indent + '    <height>32</height>',
        indent + '    <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        indent + '    <centertop>50%</centertop>',
        indent + '    <texture colordiffuse="panel_fg_90">flags/$VAR[Color_Directory]/ratings/$INFO[Window(Home).Property({0}_IconFile)]</texture>'.format(base),
        indent + '    <visible>{0}</visible>'.format(other_visible),
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <height>80</height>',
        indent + '    <aligny>center</aligny>',
        indent + '    <label>$INFO[Window(Home).Property({0}_Label)]</label>'.format(base),
        indent + '    <textcolor>panel_fg_90</textcolor>',
        indent + '    <font>font_main</font>',
        indent + '    <width max="90">auto</width>',
        indent + '    <textoffsetx>0</textoffsetx>',
        indent + '    <visible>{0}</visible>'.format(has_data),
        indent + '</control>',
        indent + '<control type="group">',
        indent + '    <width>10</width>',
        indent + '    <visible>{0}</visible>'.format(has_data),
        indent + '</control>',
    ])


def _seekbar_original_header_include(nl: str, indent: str = '                            ') -> str:
    return nl.join([
        indent + '<include content="Furniture_Header">',
        indent + '    <param name="label">$VAR[Label_OSD_Header]</param>',
        indent + '    <param name="include_right">false</param>',
        indent + '    <param name="textcolor">panel_fg_90</param>',
        indent + '    <param name="top">780</param>',
        indent + '</include>',
    ])


def _seekbar_inline_header_block(nl: str) -> str:
    # Same header line as AF3 Furniture_Header, but the left side is a single
    # horizontal grouplist: [Paused] [IMDb 8.4] [TMDb 8.5] ...
    pause_visible = 'Player.Paused + !Player.Seeking + !Window.IsActive(videoosd) + !Window.IsVisible(1152) + !Window.IsVisible(1153)'
    fallback_visible = '!Player.Paused | Player.Seeking | Window.IsActive(videoosd) | Window.IsVisible(1152) | Window.IsVisible(1153)'
    lines = [
        '                            ' + DIALOG_SEEKBAR_PAUSE_RATINGS_START,
        '                            <!-- KPM inline Paused header replacement -->',
        '                            <control type="group">',
        '                                <visible>' + fallback_visible + '</visible>',
        _seekbar_original_header_include(nl, '                                '),
        '                            </control>',
        '                            <control type="group">',
        '                                <visible>' + pause_visible + '</visible>',
        '                                <top>780</top>',
        '                                <height>80</height>',
        '                                <left>view_pad</left>',
        '                                <right>view_pad</right>',
        '                                <include content="View_Line_Divider">',
        '                                    <param name="align">left</param>',
        '                                </include>',
        '                                <control type="grouplist">',
        '                                    <orientation>horizontal</orientation>',
        '                                    <height>80</height>',
        '                                    <width>720</width>',
        '                                    <itemgap>8</itemgap>',
        '                                    <align>left</align>',
        '                                    <control type="label">',
        '                                        <label>$VAR[Label_OSD_Header]</label>',
        '                                        <align>left</align>',
        '                                        <aligny>center</aligny>',
        '                                        <textcolor>panel_fg_90</textcolor>',
        '                                        <font>font_midi_bold</font>',
        '                                        <height>80</height>',
        '                                        <width>auto</width>',
        '                                    </control>',
        '                                    <control type="group">',
        '                                        <width>6</width>',
        '                                    </control>',
    ]
    for slot in range(1, 7):
        lines.append(_seekbar_lrs_slot_controls(slot, nl, '                                    '))
    lines.extend([
        '                                </control>',
        '                            </control>',
        '                            ' + DIALOG_SEEKBAR_PAUSE_RATINGS_END,
    ])
    return nl.join(lines)


def _restore_seekbar_pause_block(text: str, nl: str) -> Tuple[str, bool]:
    """Remove the KPM DialogSeekBar marker safely.

    v0.1.12 inserted a separate rating row after the original header. That can
    be removed directly. v0.1.13 replaces the original header include with a
    marked custom block, so removal must restore the original include instead
    of deleting the header entirely.
    """
    if DIALOG_SEEKBAR_PAUSE_RATINGS_START not in text or DIALOG_SEEKBAR_PAUSE_RATINGS_END not in text:
        return text, False
    pattern = re.compile(
        r'(?ms)\s*' + re.escape(DIALOG_SEEKBAR_PAUSE_RATINGS_START) + r'.*?' + re.escape(DIALOG_SEEKBAR_PAUSE_RATINGS_END)
    )
    m = pattern.search(text)
    if not m:
        return text, False
    block = m.group(0)
    replacement = ''
    if 'KPM inline Paused header replacement' in block:
        replacement = nl + _seekbar_original_header_include(nl)
    return text[:m.start()] + replacement + text[m.end():], True


def _inject_seekbar_pause_block(text: str, block: str, nl: str) -> str:
    # Replace the exact Furniture_Header instance that renders $VAR[Label_OSD_Header]
    # (Paused / Caching / Seeking) at top 780 in DialogSeekBar.xml.
    pattern = re.compile(
        r'(?ms)(\s*<include content="Furniture_Header">\s*'
        r'<param name="label">\$VAR\[Label_OSD_Header\]</param>.*?'
        r'<param name="top">780</param>\s*'
        r'</include>)'
    )
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in DialogSeekBar.xml: Furniture_Header with $VAR[Label_OSD_Header] and top 780')
    return text[:match.start()] + nl + block + text[match.end():]


def _reload_skin_after_patch() -> None:
    if xbmc:
        try:
            xbmc.executebuiltin('ReloadSkin()')
            log('[KPM] ReloadSkin requested after Fullscreen Pause Ratings patch')
        except Exception:
            log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def addon_install_path() -> str:
    return norm(translate(f'special://home/addons/{ADDON_ID}'))


def _start_resume_close_service() -> None:
    """Start the tiny service immediately after patching.

    Kodi will also start it at login because addon.xml declares xbmc.service.
    This RunScript path is only for the current session after the user patches
    without restarting Kodi. The service exits if another instance is already
    running.
    """
    if not xbmc:
        return
    try:
        service_path = os.path.join(addon_install_path(), 'service.py')
        xbmc.executebuiltin('RunScript({0})'.format(service_path))
        log('[KPM] Resume-close service start requested')
    except Exception:
        log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def patch_vfs_pause_ratings() -> Result:
    name = patch_title('vfs_pause_ratings', 'Pause Shows Full OSD')
    if status_vfs_pause_ratings() == 'Patched':
        _start_resume_close_service()
        return Result(name, 'Skipped', 'Already patched with current pause/full OSD layout.')
    seekbar = seekbar_pause_target()
    videoosd = video_osd_target()
    includes_osd = includes_osd_target()
    includes_actions = includes_actions_target()
    vfs = vfs_pause_target()
    targets = [seekbar, videoosd, includes_osd, includes_actions]
    if os.path.exists(vfs):
        targets.append(vfs)
    snapshot('vfs_pause_ratings', targets)

    # Clean legacy VideoFullScreen injection from v0.1.8-v0.1.11.
    legacy_removed = False
    if os.path.exists(vfs):
        vfs_text = read_text(vfs)
        vfs_new, legacy_removed = _remove_marked_block(vfs_text, VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END)
        if legacy_removed:
            write_text(vfs, vfs_new)

    # DialogSeekBar opens VideoOSD on pause and now owns the clearart layer.
    # Clearart is drawn BEFORE progress labels/bar so the line and times stay on top.
    seek_text = read_text(seekbar)
    seek_nl = newline_of(seek_text)
    seek_text, old_inline_removed = _restore_seekbar_pause_block(seek_text, seek_nl)
    seek_text, old_auto_removed = _remove_seekbar_auto_videoosd(seek_text)
    seek_text, old_seekbar_clearart_removed = _remove_seekbar_clearart(seek_text)
    seek_text, auto_inserted = _inject_seekbar_auto_videoosd(seek_text, seek_nl)
    seek_text, seekbar_clearart_inserted = _inject_seekbar_clearart(seek_text, seek_nl)
    write_text(seekbar, seek_text)

    # VideoOSD keeps the fast close-on-resume behavior. The old front-layer clearart
    # is removed because it covered the progress line.
    osd_text = read_text(videoosd)
    osd_nl = newline_of(osd_text)
    osd_text, old_videoosd_clearart_removed = _remove_videoosd_clearart(osd_text)
    osd_text, old_fast_removed = _restore_videoosd_fast_close(osd_text, osd_nl)
    osd_text, fast_inserted = _inject_videoosd_fast_close(osd_text, osd_nl)
    write_text(videoosd, osd_text)

    # OSD details plot width is shortened and the small cutlist/chapter marker ticks are hidden.
    includes_text = read_text(includes_osd)
    includes_nl = newline_of(includes_text)
    includes_text, old_plot_width_removed = _restore_osd_plot_width(includes_text, includes_nl)
    includes_text, plot_width_inserted = _inject_osd_plot_width(includes_text, includes_nl)
    includes_text, old_range_removed = _restore_osd_range_markers(includes_text, includes_nl)
    includes_text, range_inserted = _inject_osd_range_markers_hidden(includes_text, includes_nl)
    write_text(includes_osd, includes_text)

    # Prevent AF3 native OSD timeout from closing VideoOSD while playback is paused.
    actions_text = read_text(includes_actions)
    actions_nl = newline_of(actions_text)
    actions_text, old_pause_stay_removed = _restore_action_osd_pause_stay(actions_text, actions_nl)
    actions_text, pause_stay_inserted = _inject_action_osd_pause_stay(actions_text, actions_nl)
    write_text(includes_actions, actions_text)

    save_state('vfs_pause_ratings', {
        'seekbar_target': seekbar,
        'videoosd_target': videoosd,
        'includes_osd_target': includes_osd,
        'includes_actions_target': includes_actions,
        'legacy_cleanup': legacy_removed,
        'layout': 'service_managed_fast_auto_videoosd_clearart_behind_progress_pause_stay_chapter_ticks_hidden_plot_short_safe_resume_close',
        'auto_videoosd': True,
        'auto_videoosd_mode': 'service_fast_pause_startup_guard',
        'clearart_layer': 'DialogSeekBar before OSD_Progress_Bar',
        'clearart_box': {'right': 'view_osd_r', 'bottom': 180, 'width': 480, 'height': 270},
        'clearart_sources': ['VideoPlayer.Art(clearart)', 'VideoPlayer.Art(tvshow.clearart)', 'TMDbHelper.Player.ClearArt'],
        'fast_close_resume': True,
        'resume_close_service': True,
        'resume_close_no_action_back': True,
        'resume_close_dialog_safe': True,
        'pause_stay_until_resume': True,
        'hide_chapter_ticks': True,
        'plot_width': 900,
    })
    _reload_skin_after_patch()
    _start_resume_close_service()

    changed = any([
        legacy_removed, old_inline_removed, old_auto_removed, old_seekbar_clearart_removed,
        auto_inserted, seekbar_clearart_inserted, old_videoosd_clearart_removed,
        old_fast_removed, fast_inserted, old_plot_width_removed, plot_width_inserted,
        old_range_removed, range_inserted, old_pause_stay_removed, pause_stay_inserted,
    ])
    detail = 'Pause now opens full VideoOSD via the KPM service quickly on normal pause and stays open while paused; a longer startup guard is kept only for auto subtitle dialogs at playback start. Minimalist inline rating is removed, clearart is drawn behind the progress line, chapter/cutlist tick markers are hidden, OSD plot width is shortened, and KPM resume monitor closes OSD after playback resumes without Action(Back). VideoOSD can stay behind subtitle/audio/other dialogs without KPM stealing focus; auto subtitle dialogs at playback start are still guarded, but normal manual pause opens faster. ReloadSkin and service start requested.'
    if legacy_removed:
        detail += ' Legacy VideoFullScreen block was removed.'
    if old_videoosd_clearart_removed:
        detail += ' Old front-layer VideoOSD clearart block was removed.'
    return Result(name, 'Patched' if changed else 'Skipped', detail)


def remove_vfs_pause_ratings() -> Result:
    name = patch_title('vfs_pause_ratings', 'Pause Shows Full OSD')
    removed = []
    seekbar = seekbar_pause_target()
    if os.path.exists(seekbar):
        text = read_text(seekbar)
        nl = newline_of(text)
        text_new, did_header = _restore_seekbar_pause_block(text, nl)
        text_new, did_auto = _remove_seekbar_auto_videoosd(text_new)
        text_new, did_seekbar_clearart = _remove_seekbar_clearart(text_new)
        if did_header or did_auto or did_seekbar_clearart:
            write_text(seekbar, text_new)
            removed.append('DialogSeekBar.xml')

    videoosd = video_osd_target()
    if os.path.exists(videoosd):
        text = read_text(videoosd)
        nl = newline_of(text)
        text_new, did_clearart = _remove_videoosd_clearart(text)
        text_new, did_fast = _restore_videoosd_fast_close(text_new, nl)
        if did_clearart or did_fast:
            write_text(videoosd, text_new)
            removed.append('VideoOSD.xml')

    includes_osd = includes_osd_target()
    if os.path.exists(includes_osd):
        text = read_text(includes_osd)
        nl = newline_of(text)
        text_new, did_plot = _restore_osd_plot_width(text, nl)
        text_new, did_ranges = _restore_osd_range_markers(text_new, nl)
        if did_plot or did_ranges:
            write_text(includes_osd, text_new)
            removed.append('Includes_OSD.xml')

    includes_actions = includes_actions_target()
    if os.path.exists(includes_actions):
        text = read_text(includes_actions)
        nl = newline_of(text)
        text_new, did_pause_stay = _restore_action_osd_pause_stay(text, nl)
        if did_pause_stay:
            write_text(includes_actions, text_new)
            removed.append('Includes_Actions.xml')

    vfs = vfs_pause_target()
    if os.path.exists(vfs):
        text = read_text(vfs)
        text_new, did = _remove_marked_block(text, VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END)
        if did:
            write_text(vfs, text_new)
            removed.append('VideoFullScreen.xml legacy')
    delete_state('vfs_pause_ratings')
    if removed:
        _reload_skin_after_patch()
        return Result(name, 'Removed', 'Removed pause/full OSD edits from: {0}. ReloadSkin requested.'.format(', '.join(removed)))
    return Result(name, 'Skipped', 'Patch marker not found.')



# -----------------------------------------------------------------------------
# Patch 6: reliable studio logos
# -----------------------------------------------------------------------------


def _studio_image_var_block(nl: str) -> str:
    lines = [
        f'    {STUDIO_IMAGE_VAR_START}',
        '    <variable name="Image_CombinedStudio">',
        '        <value condition="!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))">$INFO[Window(Home).Property(KPM.StudioLogo.1)]</value>',
        '    </variable>',
        f'    {STUDIO_IMAGE_VAR_END}',
    ]
    return nl.join(lines)


def _studio_furniture_block_from_original(original: str, nl: str) -> str:
    """Patch Furniture_Studio without rebuilding its layout.

    The original AF3 block owns the exact position/size/animation. KPM only swaps
    the studio texture source and adds KPM visibility guards. This prevents the
    footer studio logo from moving when KPM is updated.
    """
    block = original.rstrip('\r\n')
    # Remove any stale KPM guards if the original came from an old KPM block.
    block = re.sub(r'(?m)^\s*<visible>String\.IsEqual\(Window\(Home\)\.Property\(KPM\.StudioLogos\.Show\),true\)</visible>\s*\r?\n?', '', block)
    block = re.sub(r'(?m)^\s*<visible>!String\.IsEmpty\(Window\(Home\)\.Property\(KPM\.StudioLogo\.1\)\)</visible>\s*\r?\n?', '', block)
    block = block.replace(STUDIO_FURNITURE_CURRENT_MARKER + nl, '').replace(STUDIO_FURNITURE_CURRENT_MARKER, '')

    texture_re = r'(<texture(?=[^>]*background="true")[^>]*>).*?(</texture>)'
    block_new, count = re.subn(texture_re, r'\1$INFO[Window(Home).Property(KPM.StudioLogo.1)]\2', block, count=1, flags=re.S)
    if count == 0:
        block_new, count = re.subn(r'(<texture[^>]*>).*?(</texture>)', r'\1$INFO[Window(Home).Property(KPM.StudioLogo.1)]\2', block, count=1, flags=re.S)
    if count == 0:
        raise RuntimeError('Cannot patch Furniture_Studio: texture line not found')
    block = block_new

    guards = nl.join([
        '            ' + STUDIO_FURNITURE_CURRENT_MARKER,
        '            <visible>String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)</visible>',
        '            <visible>!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))</visible>',
    ])
    # Put visibility on the existing outer control, right before the first image.
    if '<control type="image">' in block:
        block = block.replace('            <control type="image">', guards + nl + '            <control type="image">', 1)
    else:
        block = block.replace('        </control>', guards + nl + '        </control>', 1)
    return nl.join([f'    {STUDIO_FURNITURE_START}', block, f'    {STUDIO_FURNITURE_END}'])


def _studio_furniture_block(nl: str) -> str:
    # Fallback template only used when no saved original exists. It mirrors AF3's
    # stock Furniture_Studio layout and still uses only KPM.StudioLogo.1.
    original = nl.join([
        '    <include name="Furniture_Studio">',
        '        <control type="grouplist">',
        '            <align>right</align>',
        '            <orientation>horizontal</orientation>',
        '            <itemgap>20</itemgap>',
        '            <include>Furniture_SlidesOver</include>',
        '            <visible>!Player.HasMedia | Skin.HasSetting(Footer.DisableNowPlaying)</visible>',
        '            <visible>String.IsEmpty(ListItem.VideoCodec) | !Skin.HasSetting(Footer.EnableCodecs)</visible>',
        '            <control type="image">',
        '                <width>300</width>',
        '                <height>80</height>',
        '                <aspectratio align="right">keep</aspectratio>',
        '                <texture background="true">$VAR[Image_CombinedStudio]</texture>',
        '                <centertop>50%</centertop>',
        '            </control>',
        '        </control>',
        '    </include>',
    ])
    return _studio_furniture_block_from_original(original, nl)

def _replace_marked_block_only(text: str, start: str, end: str, replacement: str) -> Tuple[str, bool]:
    pattern = r'(?ms)\s*' + re.escape(start) + r'.*?' + re.escape(end)
    new_text, count = re.subn(pattern, '\n' + replacement, text, count=1)
    return new_text, count > 0


def _replace_studio_image_var(text: str, nl: str, state: dict) -> Tuple[str, bool]:
    replacement = _studio_image_var_block(nl)
    if STUDIO_IMAGE_VAR_START in text and STUDIO_IMAGE_VAR_END in text:
        text, did = _replace_marked_block_only(text, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END, replacement)
        if os.path.exists(state_file('reliable_studio_logos')):
            try:
                old_state = load_state('reliable_studio_logos')
                if old_state.get('original_image_var'):
                    state['original_image_var'] = old_state.get('original_image_var')
            except Exception:
                pass
        return text, did
    pattern = r'(?s)    <variable name="Image_CombinedStudio">.*?    </variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Cannot find Image_CombinedStudio variable in Includes_Images.xml')
    state['original_image_var'] = match.group(0)
    return text[:match.start()] + replacement + text[match.end():], True


def _replace_studio_furniture(text: str, nl: str, state: dict) -> Tuple[str, bool]:
    original_from_state = ''
    if os.path.exists(state_file('reliable_studio_logos')):
        try:
            old_state = load_state('reliable_studio_logos')
            original_from_state = old_state.get('original_furniture') or ''
        except Exception:
            original_from_state = ''

    if STUDIO_FURNITURE_START in text and STUDIO_FURNITURE_END in text:
        # Updating an older KPM studio patch: rebuild from the saved stock AF3 block
        # if possible, not from the previously rebuilt KPM block.
        original = original_from_state
        if not original:
            marked = re.search(r'(?ms)' + re.escape(STUDIO_FURNITURE_START) + r'.*?' + re.escape(STUDIO_FURNITURE_END), text)
            original = marked.group(0) if marked else ''
        replacement = _studio_furniture_block_from_original(original, nl) if original else _studio_furniture_block(nl)
        text, did = _replace_marked_block_only(text, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END, replacement)
        if original_from_state:
            state['original_furniture'] = original_from_state
        return text, did

    pattern = r'(?s)    <include name="Furniture_Studio">.*?(?=\n    <include name="Furniture_Codecs">)'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Cannot find Furniture_Studio include in Includes_Furniture.xml')
    original = match.group(0).rstrip('\r\n')
    state['original_furniture'] = original
    replacement = _studio_furniture_block_from_original(original, nl)
    return text[:match.start()] + replacement + text[match.end():], True


def status_reliable_studio_logos() -> str:
    images = includes_images_target()
    furniture = includes_furniture_target()
    if not os.path.exists(images) or not os.path.exists(furniture):
        return 'Missing target'
    ti = read_text(images)
    tf = read_text(furniture)
    if STUDIO_IMAGE_VAR_START in ti and STUDIO_FURNITURE_START in tf and os.path.exists(state_file('reliable_studio_logos')):
        if STUDIO_FURNITURE_CURRENT_MARKER in tf and 'KPM.StudioLogo.2' not in tf and 'KPM.StudioLogo.3' not in tf:
            return 'Patched'
        return 'Patched (old version; update needed)'
    if '<variable name="Image_CombinedStudio">' in ti and '<include name="Furniture_Studio">' in tf:
        return 'Not patched'
    return 'Unknown layout'


def patch_reliable_studio_logos() -> Result:
    name = patch_title('reliable_studio_logos', 'Reliable Studio Logos')
    if status_reliable_studio_logos() == 'Patched':
        _start_resume_close_service()
        return Result(name, 'Skipped', 'Already patched with current single-logo layout.')
    images = includes_images_target()
    furniture = includes_furniture_target()
    missing = [p for p in (images, furniture) if not os.path.exists(p)]
    if missing:
        raise FileNotFoundError('Missing target: ' + ', '.join(missing))
    snapshot('reliable_studio_logos', [images, furniture])
    state: Dict[str, object] = {'targets': {'images': images, 'furniture': furniture}}

    ti = read_text(images)
    ni = newline_of(ti)
    ti_new, did_images = _replace_studio_image_var(ti, ni, state)
    write_text(images, ti_new)

    tf = read_text(furniture)
    nf = newline_of(tf)
    tf_new, did_furniture = _replace_studio_furniture(tf, nf, state)
    write_text(furniture, tf_new)

    save_state('reliable_studio_logos', {
        **state,
        'max_logos': 1,
        'properties': ['KPM.StudioLogo.1'],
        'resource': 'resource.images.studios.coloured',
        'metadata_changed': False,
    })
    _reload_skin_after_patch()
    _start_resume_close_service()
    return Result(name, 'Patched' if (did_images or did_furniture) else 'Skipped', 'AF3 now uses one KPM resolved studio logo only. Raw AF3/TMDbHelper/ListItem fallback is disabled, multi-studio labels are split in the service, episode items can use parent TV show studios, missing/broken logos are skipped, and MyVideos metadata is unchanged. ReloadSkin and service start requested.')


def remove_reliable_studio_logos() -> Result:
    name = patch_title('reliable_studio_logos', 'Reliable Studio Logos')
    images = includes_images_target()
    furniture = includes_furniture_target()
    state = load_state('reliable_studio_logos') if os.path.exists(state_file('reliable_studio_logos')) else {}
    removed = []
    if os.path.exists(images):
        text = read_text(images)
        original = state.get('original_image_var') if isinstance(state, dict) else None
        if original and STUDIO_IMAGE_VAR_START in text:
            text, _ = _remove_marked_block(text, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END)
            # Insert original variable where the marked block was removed by matching a nearby double newline.
            # The removal leaves no Image_CombinedStudio variable, so put it back before Image_OSD_CombinedStudio.
            if '<variable name="Image_OSD_CombinedStudio">' in text:
                text = text.replace('    <variable name="Image_OSD_CombinedStudio">', original.rstrip('\r\n') + newline_of(text) + newline_of(text) + '    <variable name="Image_OSD_CombinedStudio">', 1)
                write_text(images, text)
                removed.append('Includes_Images.xml')
        elif STUDIO_IMAGE_VAR_START in text:
            text, did = _remove_marked_block(text, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END)
            if did:
                write_text(images, text)
                removed.append('Includes_Images.xml marker-only')

    if os.path.exists(furniture):
        text = read_text(furniture)
        original = state.get('original_furniture') if isinstance(state, dict) else None
        if original and STUDIO_FURNITURE_START in text:
            text, _ = _remove_marked_block(text, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END)
            if '    <include name="Furniture_Codecs">' in text:
                text = text.replace('    <include name="Furniture_Codecs">', original.rstrip('\r\n') + newline_of(text) + '    <include name="Furniture_Codecs">', 1)
                write_text(furniture, text)
                removed.append('Includes_Furniture.xml')
        elif STUDIO_FURNITURE_START in text:
            text, did = _remove_marked_block(text, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END)
            if did:
                write_text(furniture, text)
                removed.append('Includes_Furniture.xml marker-only')

    delete_state('reliable_studio_logos')
    if removed:
        _reload_skin_after_patch()
        return Result(name, 'Removed', 'Restored studio logo XML blocks from: {0}. ReloadSkin requested.'.format(', '.join(removed)))
    return Result(name, 'Skipped', 'Patch marker not found.')


# -----------------------------------------------------------------------------
# Tool: clear Kodi add-on icon thumbnail cache
# -----------------------------------------------------------------------------

ADDON_ICON_EXTENSIONS = ('.png', '.jpg', '.jpeg', '.webp')


def profile_database_path() -> str:
    return norm(translate('special://profile/Database'))


def thumbnails_path() -> str:
    return norm(translate('special://profile/Thumbnails'))


def latest_textures_db() -> str:
    db_dir = profile_database_path()
    if not os.path.isdir(db_dir):
        return ''
    candidates = []
    for name in os.listdir(db_dir):
        match = re.match(r'^Textures(\d+)\.db$', name, re.I)
        if match:
            candidates.append((int(match.group(1)), os.path.join(db_dir, name)))
    if not candidates:
        return ''
    candidates.sort(reverse=True)
    return candidates[0][1]


def _normalize_texture_url(value: str) -> str:
    text = unquote(str(value or '')).replace('\\', '/').lower()
    # image:// URLs often add a trailing slash after the encoded source path.
    while text.endswith('/'):
        text = text[:-1]
    return text


def _texture_table_columns(conn: sqlite3.Connection, table: str) -> List[str]:
    try:
        return [str(row[1]) for row in conn.execute(f'PRAGMA table_info({table})').fetchall()]
    except sqlite3.Error:
        return []


def _texture_table_exists(conn: sqlite3.Connection, table: str) -> bool:
    try:
        row = conn.execute('SELECT name FROM sqlite_master WHERE type=\'table\' AND name=?', (table,)).fetchone()
        return row is not None
    except sqlite3.Error:
        return False


def _looks_like_addon_icon_url(url: str) -> bool:
    text = _normalize_texture_url(url)
    if '/addons/' not in text and 'special://home/addons/' not in text and 'special://xbmc/addons/' not in text:
        return False
    # Clear all add-on icon files, not video artwork. Most add-ons use icon.png,
    # but this also catches icon.jpg/icon.webp if an add-on uses them.
    return any(text.endswith('/icon' + ext) or '/icon' + ext + '/' in text for ext in ADDON_ICON_EXTENSIONS)


def clear_addon_icon_cache() -> Result:
    name = 'Add-on Icon Cache'
    db_path = latest_textures_db()
    thumb_root = thumbnails_path()
    if not db_path or not os.path.exists(db_path):
        return Result(name, 'Skipped', 'Textures database not found.')

    removed_files = 0
    removed_rows = 0
    matched_rows: List[Tuple[int, str, str]] = []
    conn = sqlite3.connect(db_path, timeout=30)
    try:
        conn.row_factory = sqlite3.Row
        cols = _texture_table_columns(conn, 'texture')
        if not cols or 'url' not in cols:
            return Result(name, 'Skipped', 'Textures DB has no texture.url table/column.')
        id_col = 'idtexture' if 'idtexture' in cols else ('id' if 'id' in cols else cols[0])
        cached_col = 'cachedurl' if 'cachedurl' in cols else ''
        query_cols = f'{id_col}, url' + (f', {cached_col}' if cached_col else '')
        for row in conn.execute(f'SELECT {query_cols} FROM texture').fetchall():
            url = str(row['url'] or '')
            if _looks_like_addon_icon_url(url):
                cached = str(row[cached_col] or '') if cached_col else ''
                matched_rows.append((int(row[id_col]), url, cached))

        if not matched_rows:
            return Result(name, 'Skipped', 'No cached add-on icon rows found.')

        for _id, _url, cached in matched_rows:
            if cached:
                cached_path = os.path.join(thumb_root, cached.replace('/', os.sep).replace('\\', os.sep))
                if os.path.exists(cached_path):
                    try:
                        os.remove(cached_path)
                        removed_files += 1
                    except OSError:
                        pass
                # Some Kodi installs also have sidecar DDS cache for the same base name.
                base, _ext = os.path.splitext(cached_path)
                dds_path = base + '.dds'
                if os.path.exists(dds_path):
                    try:
                        os.remove(dds_path)
                        removed_files += 1
                    except OSError:
                        pass

        ids = [row[0] for row in matched_rows]
        placeholders = ','.join('?' for _ in ids)
        try:
            if _texture_table_exists(conn, 'sizes') and 'idtexture' in _texture_table_columns(conn, 'sizes'):
                conn.execute(f'DELETE FROM sizes WHERE idtexture IN ({placeholders})', ids)
        except sqlite3.Error:
            pass
        conn.execute(f'DELETE FROM texture WHERE {id_col} IN ({placeholders})', ids)
        removed_rows = conn.total_changes
        conn.commit()
    finally:
        conn.close()

    return Result(name, 'Cleared', f'Removed {len(matched_rows)} add-on icon cache rows and {removed_files} thumbnail files from {os.path.basename(db_path)}. Restart Kodi or reload skin so icons rebuild.')


def clear_addon_icon_cache_menu() -> None:
    message = (
        'Clear cached icons for all installed Kodi add-ons?\n\n'
        'This deletes only add-on icon thumbnail cache rows/files from the latest Textures DB. '
        'Original add-on icon.png files are not touched. Kodi will rebuild icons automatically.'
    )
    if not yesno(ADDON_NAME, message):
        return
    run_single(clear_addon_icon_cache)



# -----------------------------------------------------------------------------
# Diagnostics: Fullscreen pause ratings live/static export
# -----------------------------------------------------------------------------

DIAG_LIVE_DIRNAME = 'diagnostics_live'
DIAG_EXPORT_DIRNAME = 'diagnostics'
DIAG_LIVE_PREFIX = 'fullscreen-pause-ratings-live'
FANART_DIAG_LIVE_PREFIX = 'fanart-focus-live'


def _safe_call(default, func, *args):
    try:
        return func(*args)
    except Exception as exc:  # pylint: disable=broad-except
        return default if default is not None else f'ERROR: {exc}'


def info_label(expr: str) -> str:
    if xbmc:
        return _safe_call('', xbmc.getInfoLabel, expr)
    return ''


def cond_visible(expr: str) -> bool:
    if xbmc:
        try:
            return bool(xbmc.getCondVisibility(expr))
        except Exception:  # pylint: disable=broad-except
            return False
    return False


def _window_obj(window_id: int):
    if xbmcgui:
        try:
            return xbmcgui.Window(window_id)
        except Exception:  # pylint: disable=broad-except
            return None
    return None


def _window_prop(window_id: int, name: str) -> str:
    win = _window_obj(window_id)
    if not win:
        return ''
    try:
        return str(win.getProperty(name) or '')
    except Exception:  # pylint: disable=broad-except
        return ''


def _current_window_ids() -> Dict[str, int]:
    data = {'current_window_id': 0, 'current_dialog_id': 0}
    if not xbmcgui:
        return data
    for key, getter_name in (('current_window_id', 'getCurrentWindowId'), ('current_dialog_id', 'getCurrentWindowDialogId')):
        getter = getattr(xbmcgui, getter_name, None)
        if getter:
            try:
                data[key] = int(getter())
            except Exception:  # pylint: disable=broad-except
                data[key] = 0
    return data


def _lrs_property_matrix(window_ids: Optional[List[int]] = None) -> Dict[str, dict]:
    if window_ids is None:
        ids = [10000]
        current = _current_window_ids().get('current_window_id', 0)
        if current and current not in ids:
            ids.append(current)
    else:
        ids = window_ids
    services = ('Player', 'VideoPlayer', 'ListItem', 'Screensaver')
    suffixes = ('Source', 'Icon', 'IconFile', 'Label', 'Value')
    matrix: Dict[str, dict] = {}
    for wid in ids:
        wkey = str(wid)
        matrix[wkey] = {}
        for service in services:
            skey = service
            matrix[wkey][skey] = {
                'HasData': _window_prop(wid, f'LibraryRatings.{service}.HasData'),
                'ItemKey': _window_prop(wid, f'LibraryRatings.{service}.ItemKey'),
                'Title': _window_prop(wid, f'LibraryRatings.{service}.Title'),
                'DBType': _window_prop(wid, f'LibraryRatings.{service}.DBType'),
                'Display_RatingSlots': _window_prop(wid, f'LibraryRatings.{service}.Display_RatingSlots'),
            }
            for slot in range(1, 7):
                slot_data = {}
                for suffix in suffixes:
                    slot_data[suffix] = _window_prop(wid, f'LibraryRatings.{service}.RatingSlot{slot}_{suffix}')
                matrix[wkey][skey][f'RatingSlot{slot}'] = slot_data
        matrix[wkey]['Display'] = {
            'RatingSlots': _window_prop(wid, 'LibraryRatings.Display.RatingSlots'),
            'Top250': _window_prop(wid, 'LibraryRatings.Display.Top250'),
            'Awards': _window_prop(wid, 'LibraryRatings.Display.Awards'),
            'TVStatus': _window_prop(wid, 'LibraryRatings.Display.TVStatus'),
        }
    return matrix


def _player_runtime_state() -> Dict[str, object]:
    ids = _current_window_ids()
    return {
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        **ids,
        'conditions': {
            'Player.HasMedia': cond_visible('Player.HasMedia'),
            'Player.HasVideo': cond_visible('Player.HasVideo'),
            'Player.Playing': cond_visible('Player.Playing'),
            'Player.Paused': cond_visible('Player.Paused'),
            'Player.Seeking': cond_visible('Player.Seeking'),
            'Player.Caching': cond_visible('Player.Caching'),
            'Window.IsActive(fullscreenvideo)': cond_visible('Window.IsActive(fullscreenvideo)'),
            'Window.IsActive(VideoFullScreen.xml)': cond_visible('Window.IsActive(VideoFullScreen.xml)'),
            'Window.IsActive(videoosd)': cond_visible('Window.IsActive(videoosd)'),
            'Window.IsActive(DialogSeekBar.xml)': cond_visible('Window.IsActive(DialogSeekBar.xml)'),
            'Window.IsVisible(DialogSeekBar.xml)': cond_visible('Window.IsVisible(DialogSeekBar.xml)'),
            'Window.IsVisible(1152)': cond_visible('Window.IsVisible(1152)'),
            'Window.IsVisible(1153)': cond_visible('Window.IsVisible(1153)'),
        },
        'videoplayer_labels': {
            'Title': info_label('VideoPlayer.Title'),
            'TVShowTitle': info_label('VideoPlayer.TVShowTitle'),
            'Season': info_label('VideoPlayer.Season'),
            'Episode': info_label('VideoPlayer.Episode'),
            'DBID': info_label('VideoPlayer.DBID'),
            'DBTYPE': info_label('VideoPlayer.DBTYPE'),
            'Rating': info_label('VideoPlayer.Rating'),
            'UserRating': info_label('VideoPlayer.UserRating'),
            'Year': info_label('VideoPlayer.Year'),
            'FileNameAndPath': info_label('VideoPlayer.FileNameAndPath'),
        },
        'lrs_properties': _lrs_property_matrix(),
    }


def _line_numbered_snippet(text: str, start_marker: str, end_marker: str, context: int = 8) -> str:
    lines = text.splitlines()
    start = end = -1
    for idx, line in enumerate(lines):
        if start_marker in line and start < 0:
            start = idx
        if end_marker in line:
            end = idx
            break
    if start < 0:
        return f'Marker not found: {start_marker}'
    if end < start:
        end = start
    lo = max(0, start - context)
    hi = min(len(lines), end + context + 1)
    return '\n'.join(f'{i + 1:05d}: {lines[i]}' for i in range(lo, hi))


def _full_file_digest(path: str) -> Dict[str, object]:
    data: Dict[str, object] = {'path': path, 'exists': os.path.exists(path)}
    if not os.path.exists(path):
        return data
    try:
        with open(path, 'rb') as handle:
            raw = handle.read()
        data['size'] = len(raw)
        data['mtime'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(path)))
        try:
            import hashlib
            data['sha256'] = hashlib.sha256(raw).hexdigest()
        except Exception:  # pylint: disable=broad-except
            pass
    except Exception as exc:  # pylint: disable=broad-except
        data['error'] = str(exc)
    return data


def _read_file_if_exists(path: str, max_chars: int = 300000) -> str:
    if not os.path.exists(path):
        return f'File not found: {path}'
    try:
        text = read_text(path)
    except Exception as exc:  # pylint: disable=broad-except
        return f'Could not read {path}: {exc}'
    if len(text) > max_chars:
        return text[-max_chars:]
    return text


def _read_live_text_if_exists(path: str, max_chars: int = 20000000) -> str:
    """Read live JSONL without corrupting the first line.

    Old diagnostics used a raw character tail, so exported JSONL could start in the
    middle of a JSON object. Fanart diagnostics need valid per-line records, so we
    either export the full file or tail only complete lines with a marker.
    """
    if not os.path.exists(path):
        return f'File not found: {path}'
    try:
        text = read_text(path)
    except Exception as exc:  # pylint: disable=broad-except
        return f'Could not read {path}: {exc}'
    if len(text) <= max_chars:
        return text
    tail = text[-max_chars:]
    first_nl = tail.find('\n')
    if first_nl >= 0:
        tail = tail[first_nl + 1:]
    return '# KPM diagnostic note: file was too large; exported tail starts at the next complete JSONL line.\n' + tail


def _latest_kodi_log_path() -> str:
    return norm(translate('special://logpath/kodi.log'))


def _filtered_kodi_log() -> str:
    path = _latest_kodi_log_path()
    text = _read_file_if_exists(path, 500000)
    keys = ('Kodi Patch Manager', 'KPM', 'StudioLogo', 'Image_CombinedStudio', 'resource.images.studios', 'Misplaced [', 'Library Ratings Scraper', 'LibraryRatings', 'script.library.ratings.scraper', 'VideoFullScreen', 'fullscreenvideo', 'ERROR', 'Traceback', 'Skin Helper Service')
    out = []
    for line in text.splitlines():
        if any(k.lower() in line.lower() for k in keys):
            out.append(line)
    return '\n'.join(out[-2000:]) if out else 'No matching lines found in kodi.log tail.'


def _target_files_report() -> Dict[str, object]:
    files = {
        'VideoFullScreen.xml': vfs_pause_target(),
        'DialogSeekBar.xml': seekbar_pause_target(),
        'Includes_Info.xml': af3_path('1080i', 'Includes_Info.xml'),
        'Includes_OSD.xml': af3_path('1080i', 'Includes_OSD.xml'),
        'Includes_Images.xml': includes_images_target(),
        'Includes_Furniture.xml': includes_furniture_target(),
        'KPM service.py': norm(os.path.join(translate('special://home/addons/script.kodi.patch.manager'), 'service.py')),
        'KPM settings.json': kpm_settings_file(),
        'TMDbHelper imgmon.py': tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'imgmon.py'),
        'TMDbHelper images.py': tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'images.py'),
        'LRS addon.xml': norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml')),
        'LRS settings.xml': norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml')),
        'Kodi log': _latest_kodi_log_path(),
    }
    return {name: _full_file_digest(path) for name, path in files.items()}



def _studio_home_props_report() -> Dict[str, object]:
    keys = [
        'KPM.StudioLogo.1', 'KPM.StudioLogoName.1',
        'KPM.StudioLogo.2', 'KPM.StudioLogoName.2',
        'KPM.StudioLogo.3', 'KPM.StudioLogoName.3',
        'KPM.StudioLogos.Count', 'KPM.StudioLogos.Available', 'KPM.StudioLogos.Status',
        'KPM.StudioLogos.Candidates', 'KPM.StudioLogos.Resolved', 'KPM.StudioLogos.Missing',
        'KPM.StudioLogos.UpdatedAt', 'KPM.StudioLogos.Show', 'KPM.StudioLogos.Context', 'KPM.StudioLogos.Cache', 'KPM.StudioLogos.IndexBuildMs',
        'KPM.StudioLogos.ResolveLastMs', 'KPM.StudioLogos.ResolveMaxMs', 'KPM.StudioLogos.ResolveCount',
        'KPM.StudioLogos.BrokenSkipped', 'KPM.StudioLogos.Debug',
        'KPM.StudioLogos.Source', 'KPM.StudioLogos.EpisodeParentShowId',
        'KPM.StudioLogos.EpisodeParentShowTitle', 'KPM.StudioLogos.DBLookupLastMs',
        'KPM.StudioLogos.DBLookupCount',
        'KPM.StudioLogos.LastMediaLabel', 'KPM.StudioLogos.LastMediaDBID',
        'KPM.StudioLogos.LastMediaDBTYPE', 'KPM.StudioLogos.LastMediaCandidates',
        'KPM.StudioLogos.LastMediaResolved', 'KPM.StudioLogos.LastMediaSource',
        'KPM.StudioLogos.LastMediaUpdatedAt',
    ]
    return {key: _window_prop(10000, key) for key in keys}


def _studio_resource_report() -> Dict[str, object]:
    addon_dir = norm(os.path.join(translate('special://home/addons'), 'resource.images.studios.coloured'))
    white_dir = norm(os.path.join(translate('special://home/addons'), 'resource.images.studios.white'))
    coloured_xbt = norm(os.path.join(addon_dir, 'resources', 'Textures.xbt'))
    white_xbt = norm(os.path.join(white_dir, 'resources', 'Textures.xbt'))
    return {
        'coloured_addon_dir': addon_dir,
        'coloured_addon_exists': os.path.isdir(addon_dir),
        'coloured_textures_xbt': _full_file_digest(coloured_xbt),
        'index_cache': _full_file_digest(norm(os.path.join(translate('special://profile/addon_data/script.kodi.patch.manager'), 'cache', 'studio-logo-index-coloured-v2.json'))),
        'white_addon_dir': white_dir,
        'white_addon_exists': os.path.isdir(white_dir),
        'white_textures_xbt': _full_file_digest(white_xbt),
    }


def _latest_myvideos_db() -> str:
    db_dir = norm(translate('special://profile/Database'))
    if not os.path.isdir(db_dir):
        return ''
    best = ''
    best_num = -1
    for fname in os.listdir(db_dir):
        match = re.match(r'MyVideos(\d+)\.db$', fname, re.I)
        if match:
            num = int(match.group(1))
            if num > best_num:
                best_num = num
                best = os.path.join(db_dir, fname)
    return norm(best) if best else ''


def _studio_db_report() -> Dict[str, object]:
    path = _latest_myvideos_db()
    data: Dict[str, object] = {'path': path, 'exists': bool(path and os.path.exists(path))}
    if not path or not os.path.exists(path):
        return data
    try:
        con = sqlite3.connect(path)
        cur = con.cursor()
        tables = {row[0] for row in cur.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        data['has_studio_table'] = 'studio' in tables
        data['has_studio_link_table'] = 'studio_link' in tables
        if 'studio' in tables:
            data['studio_count'] = int(cur.execute('SELECT COUNT(*) FROM studio').fetchone()[0])
            data['sample_studios'] = [row[0] for row in cur.execute('SELECT name FROM studio ORDER BY name LIMIT 30')]
        if 'studio_link' in tables:
            data['studio_link_count'] = int(cur.execute('SELECT COUNT(*) FROM studio_link').fetchone()[0])
            data['media_with_studio_count'] = int(cur.execute('SELECT COUNT(*) FROM (SELECT media_type, media_id FROM studio_link GROUP BY media_type, media_id)').fetchone()[0])
            data['multi_studio_media_count'] = int(cur.execute('SELECT COUNT(*) FROM (SELECT media_type, media_id, COUNT(*) c FROM studio_link GROUP BY media_type, media_id HAVING c > 1)').fetchone()[0])
            sql = ('SELECT media_type, COUNT(*) AS items, '
                   'SUM(CASE WHEN c > 1 THEN 1 ELSE 0 END) AS multi_items '
                   'FROM (SELECT media_type, media_id, COUNT(*) c FROM studio_link GROUP BY media_type, media_id) '
                   'GROUP BY media_type ORDER BY media_type')
            data['by_media_type'] = [
                {'media_type': row[0], 'items': row[1], 'multi_studio_items': row[2]}
                for row in cur.execute(sql)
            ]
            try:
                data['episode_studio_link_count'] = int(cur.execute("SELECT COUNT(*) FROM studio_link WHERE media_type='episode'").fetchone()[0])
                data['tvshow_studio_link_count'] = int(cur.execute("SELECT COUNT(*) FROM studio_link WHERE media_type='tvshow'").fetchone()[0])
                data['episode_parent_studio_samples'] = [
                    {'idEpisode': row[0], 'episode': row[1], 'idShow': row[2], 'show': row[3], 'studio': row[4]}
                    for row in cur.execute("""
                        SELECT e.idEpisode, e.c00, e.idShow, t.c00, s.name
                        FROM episode e
                        JOIN tvshow t ON t.idShow=e.idShow
                        JOIN studio_link sl ON sl.media_type='tvshow' AND sl.media_id=e.idShow
                        JOIN studio s ON s.studio_id=sl.studio_id
                        ORDER BY e.idEpisode
                        LIMIT 20
                    """)
                ]
            except Exception as exc:
                data['episode_parent_studio_error'] = str(exc)
        con.close()
    except Exception as exc:  # pylint: disable=broad-except
        data['error'] = str(exc)
    return data


def _marked_snippet(path: str, start_marker: str, end_marker: str, max_chars: int = 120000) -> str:
    text = _read_file_if_exists(path, max_chars)
    return _line_numbered_snippet(text, start_marker, end_marker)


def _studio_log_filtered() -> str:
    path = _latest_kodi_log_path()
    text = _read_file_if_exists(path, 600000)
    keys = ('Kodi Patch Manager Service', 'KPM.StudioLogo', 'KPM.StudioLogos', 'studio logos:',
            'resource.images.studios', 'Image_CombinedStudio', 'Furniture_Studio', 'Misplaced [',
            'Error parsing boolean expression', 'CImageLoader::DoWork')
    out = []
    for line in text.splitlines():
        if any(k.lower() in line.lower() for k in keys):
            out.append(line)
    return '\n'.join(out[-2500:]) if out else 'No studio-logo related lines found in kodi.log tail.'


def _studio_last_events() -> List[str]:
    text = _studio_log_filtered()
    lines = []
    for line in text.splitlines():
        lower = line.lower()
        if 'studio logo index' in lower or 'studio logos:' in lower or 'cimageloader::dowork' in lower or 'failed to decompress' in lower or 'error parsing boolean expression' in lower:
            lines.append(line)
    return lines[-80:]



def _studio_context_report() -> Dict[str, object]:
    tmdb_listitem = {}
    tmdb_player = {}
    for idx in range(1, 11):
        tmdb_listitem[f'Studio.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.ListItem.Studio.{idx}.Name')
    for idx in range(1, 6):
        tmdb_listitem[f'Network.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.ListItem.Network.{idx}.Name')
        tmdb_player[f'Studio.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.Player.Studio.{idx}.Name')
        tmdb_player[f'Network.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.Player.Network.{idx}.Name')
    visibility = {
        'Furniture.DisableStudio': cond_visible('Skin.HasSetting(Footer.DisableStudio)'),
        'Furniture.EnableCodecs': cond_visible('Skin.HasSetting(Footer.EnableCodecs)'),
        'Furniture.DisableNowPlaying': cond_visible('Skin.HasSetting(Footer.DisableNowPlaying)'),
        'Footer condition - no now playing or disabled': cond_visible('!Player.HasMedia | Skin.HasSetting(Footer.DisableNowPlaying)'),
        'Footer condition - codec slot free': cond_visible('String.IsEmpty(ListItem.VideoCodec) | !Skin.HasSetting(Footer.EnableCodecs)'),
        'Footer condition - KPM logo 1 exists': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))'),
        'Footer condition - KPM studio show': cond_visible('String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)'),
    }
    return {
        'info_labels': {
            'ListItem.Label': info_label('ListItem.Label'),
            'ListItem.DBID': info_label('ListItem.DBID'),
            'ListItem.DBTYPE': info_label('ListItem.DBTYPE'),
            'ListItem.Studio': info_label('ListItem.Studio'),
            'ListItem.VideoCodec': info_label('ListItem.VideoCodec'),
            'Container.ListItem.Label': info_label('Container.ListItem.Label'),
            'Container.ListItem.DBID': info_label('Container.ListItem.DBID'),
            'Container.ListItem.DBTYPE': info_label('Container.ListItem.DBTYPE'),
            'Container.ListItem.Studio': info_label('Container.ListItem.Studio'),
            'Container.ListItem.VideoCodec': info_label('Container.ListItem.VideoCodec'),
            'VideoPlayer.Title': info_label('VideoPlayer.Title'),
            'VideoPlayer.DBID': info_label('VideoPlayer.DBID'),
            'VideoPlayer.DBTYPE': info_label('VideoPlayer.DBTYPE'),
            'VideoPlayer.Studio': info_label('VideoPlayer.Studio'),
            'VideoPlayer.Content(episodes)': cond_visible('VideoPlayer.Content(episodes)'),
        },
        'tmdbhelper_listitem_properties': tmdb_listitem,
        'tmdbhelper_player_properties': tmdb_player,
        'visibility_conditions': visibility,
        'known_broken_texture_blacklist': list(BROKEN_STUDIO_TEXTURE_NAMES),
    }


def studio_logo_diagnostics_report() -> Dict[str, object]:
    images = includes_images_target()
    furniture = includes_furniture_target()
    return {
        'generated': time.strftime('%Y-%m-%d %H:%M:%S'),
        'kpm_version': VERSION,
        'patch_status': status_reliable_studio_logos(),
        'settings': load_kpm_settings(),
        'state_exists': os.path.exists(state_file('reliable_studio_logos')),
        'state_file': state_file('reliable_studio_logos'),
        'home_properties': _studio_home_props_report(),
        'context': _studio_context_report(),
        'resource': _studio_resource_report(),
        'database': _studio_db_report(),
        'targets': {
            'Includes_Images.xml': _full_file_digest(images),
            'Includes_Furniture.xml': _full_file_digest(furniture),
        },
        'condition_checks': {
            '!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))'),
            'String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)': cond_visible('String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)'),
            '!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.2))': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.2))'),
            '!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.3))': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.3))'),
        },
        'last_events': _studio_last_events(),
    }


def _studio_diagnostic_text(report: Dict[str, object]) -> str:
    lines = []
    lines.append(f'{ADDON_NAME} studio logo diagnostics v{VERSION}')
    lines.append(f'Generated: {report.get("generated", "")}')
    lines.append('')
    lines.append('Status: ' + str(report.get('patch_status')))
    lines.append('Settings: ' + json.dumps(report.get('settings', {}), ensure_ascii=False))
    lines.append('')
    lines.append('Home properties:')
    lines.append(json.dumps(report.get('home_properties', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Context / visibility:')
    lines.append(json.dumps(report.get('context', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Resource:')
    lines.append(json.dumps(report.get('resource', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Database:')
    lines.append(json.dumps(report.get('database', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Condition checks:')
    lines.append(json.dumps(report.get('condition_checks', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Last studio events:')
    lines.extend(report.get('last_events', []) or ['No studio events found.'])
    return '\n'.join(lines)


def export_studio_logo_diagnostics() -> Result:
    name = 'Export Studio Logo Diagnostics'
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_dir = addon_data_dir('studio_logo_diagnostics', stamp)
    zip_path = os.path.join(addon_data_dir('studio_logo_diagnostics'), f'kpm-studio-logo-diagnostics-{stamp}.zip')
    report = studio_logo_diagnostics_report()
    images = includes_images_target()
    furniture = includes_furniture_target()
    files_to_write = {
        'studio-logo-diagnostics.txt': _studio_diagnostic_text(report),
        'studio-logo-diagnostics.json': json.dumps(report, indent=2, ensure_ascii=False),
        'studio-context.json': json.dumps(report.get('context', {}), indent=2, ensure_ascii=False),
        'studio-home-properties.json': json.dumps(report.get('home_properties', {}), indent=2, ensure_ascii=False),
        'Includes_Images-Image_CombinedStudio-snippet.txt': _marked_snippet(images, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END),
        'Includes_Furniture-Furniture_Studio-snippet.txt': _marked_snippet(furniture, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END),
        'Includes_Images.xml': _read_file_if_exists(images, 400000),
        'Includes_Furniture.xml': _read_file_if_exists(furniture, 300000),
        'kodi-log-studio-filtered.txt': _studio_log_filtered(),
        'patch-status.txt': patch_status_summary(),
    }
    for rel, content in files_to_write.items():
        _write_diag_file(os.path.join(out_dir, rel.replace('/', os.sep)), content)
    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(out_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                zf.write(fpath, os.path.relpath(fpath, out_dir))
    log('[KPM_STUDIO_DIAG] Exported studio logo diagnostics: {0}'.format(zip_path))
    return Result(name, 'Exported', zip_path)


# -----------------------------------------------------------------------------
# Advanced patch: TMDbHelper visit-random fanart, sticky while idle
# -----------------------------------------------------------------------------

def tmdb_focus_random_targets() -> Tuple[str, str]:
    imgmon = tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'imgmon.py')
    images = tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'images.py')
    return imgmon, images


def _tmdb_focus_text_has_v12(imgmon_text: str, images_text: str) -> bool:
    return (
        'Focus-random on-visit sticky idle patch V16' in imgmon_text and
        'Focus-random on-visit sticky idle patch V16' in images_text and
        '_focus_random_onvisit_choose' in images_text and
        '_focus_random_open_media_visit' in imgmon_text
    )


def status_tmdb_focus_random_v12() -> str:
    imgmon, images = tmdb_focus_random_targets()
    if not os.path.exists(imgmon) or not os.path.exists(images):
        return 'Missing target'
    imgmon_text = read_text(imgmon)
    images_text = read_text(images)
    if _tmdb_focus_text_has_v12(imgmon_text, images_text):
        return 'Patched'
    if (TMDB_V11_ATTR_MARKER in imgmon_text or TMDB_V11_REFRESH_START in imgmon_text or
            TMDB_V11_HELPER_START in images_text or LEGACY_TMDB_MARKER in imgmon_text or
            'Focus-random sticky visit patch V11' in images_text or
            '_focus_random_sticky_choose' in images_text or
            TMDB_V12_ATTR_MARKER in imgmon_text or TMDB_V12_REFRESH_START in imgmon_text or
            TMDB_V12_HELPER_START in images_text or TMDB_V12_CALL_MARKER in images_text or
            'Focus-random on-visit sticky idle patch V12' in imgmon_text or
            'Focus-random on-visit sticky idle patch V12' in images_text or
            'Focus-random on-visit sticky idle patch V13' in imgmon_text or
            'Focus-random on-visit sticky idle patch V13' in images_text or
            'KPM-TMDB-FOCUS-RANDOM-V13' in imgmon_text or
            'KPM-TMDB-FOCUS-RANDOM-V13' in images_text or
            'Focus-random on-visit sticky idle patch V14' in imgmon_text or
            'Focus-random on-visit sticky idle patch V14' in images_text or
            'KPM-TMDB-FOCUS-RANDOM-V14' in imgmon_text or
            'KPM-TMDB-FOCUS-RANDOM-V14' in images_text or
            'Focus-random on-visit sticky idle patch V15' in imgmon_text or
            'Focus-random on-visit sticky idle patch V15' in images_text or
            'KPM-TMDB-FOCUS-RANDOM-V15' in imgmon_text or
            'KPM-TMDB-FOCUS-RANDOM-V15' in images_text):
        return 'Update available'
    return 'Not patched'


def _tmdb_focus_strip_old_imgmon(text: str) -> str:
    # Remove old standalone/KPM V11/V12/V13 init lines and helper methods.
    text = re.sub(r'(?ms)^        self\._focus_random_visit_id\s*=.*?(?=^    def _focus_random_norm\(|^    def is_next_refresh\()', '', text)
    text = re.sub(r'(?ms)^    def _focus_random_norm\(self, value\):.*?(?=^    def is_next_refresh\(self\):)', '', text)
    return text


def _patch_tmdb_focus_imgmon_text(text: str) -> str:
    nl = newline_of(text)
    text = _tmdb_focus_strip_old_imgmon(text)

    if 'self.properties = set()' not in text:
        raise RuntimeError('Anchor not found in imgmon.py: self.properties = set()')

    init = nl.join([
        'self.properties = set()',
        f'        self._focus_random_visit_id = 0  {TMDB_ATTR_MARKER}  # Focus-random on-visit sticky idle patch V16',
        "        self._focus_random_media_key_current = ''  # Stable media key for current visit",
        "        self._focus_random_media_key_source = ''  # Container/listitem source that produced the key",
        "        self._focus_random_art_sig_current = ''  # Fanart candidate signature for current media visit",
        "        self._focus_random_visit_started_at = 0.0  # Timestamp for short transition corrections",
        "        self._focus_random_art_correction_count = 0  # Limit same-visit art correction refreshes",
    ])
    text = re.sub(r'self\.properties\s*=\s*set\(\)', init, text, count=1)

    method_pattern = r'(?ms)^    def is_next_refresh\(self\):.*?(?=^    @kodi_try_except\()'
    if not re.search(method_pattern, text):
        raise RuntimeError('Anchor not found in imgmon.py: def is_next_refresh(self) before @kodi_try_except')

    replacement = """    def _focus_random_norm(self, value):
        try:
            value = str(value or '').strip()
        except Exception:
            return ''
        return value

    def _focus_random_now(self):
        try:
            return __import__('time').time()
        except Exception:
            return 0.0

    def _focus_random_get_label(self, label):
        # Use Kodi's raw InfoLabel resolver for Window(...).Property and Container(...).ListItem labels.
        try:
            from tmdbhelper.lib.addon.plugin import get_infolabel as _kpm_get_infolabel
            return self._focus_random_norm(_kpm_get_infolabel(label))
        except Exception:
            pass
        try:
            return self._focus_random_norm(self.get_infolabel(label))
        except Exception:
            return ''

    def _focus_random_parse_container_ids(self, *values):
        ids = []
        for value in values:
            for found in __import__('re').findall(r'\\d+', str(value or '')):
                try:
                    number = int(found)
                except Exception:
                    continue
                if 0 < number < 10000 and number not in ids:
                    ids.append(number)
        return ids

    def _focus_random_container_candidates(self):
        # Home/Hub often focuses Play/More/tab buttons, so global ListItem.* is empty.
        # V16 priority:
        # 1) focused media container if the focused control itself is media,
        # 2) current-window TMDbHelper/LRS visual container (what AF3 is actually rendering),
        # 3) current-window KPM bridge,
        # 4) Home-window fallbacks.
        values = [
            self._focus_random_get_label('System.CurrentControlID'),
            self._focus_random_get_label('Window.Property(TMDbHelper.WidgetContainer)'),
            self._focus_random_get_label('Window.Property(LRS.Active.ContainerID)'),
            self._focus_random_get_label('Window.Property(KPM.Active.ContainerID)'),
            self._focus_random_get_label('Window.Property(KPM.Focus.Container)'),
            self._focus_random_get_label('Window(Home).Property(TMDbHelper.WidgetContainer)'),
            self._focus_random_get_label('Window(Home).Property(LRS.Active.ContainerID)'),
            self._focus_random_get_label('Window(Home).Property(KPM.Active.ContainerID)'),
            self._focus_random_get_label('Window(Home).Property(KPM.Focus.Container)'),
        ]
        ids = self._focus_random_parse_container_ids(*values)
        # Common AF3 hub/library containers. These are only fallback probes; valid media is still required.
        for number in (501, 301, 502, 503, 504, 500, 601, 300, 311, 312, 950, 951, 952, 1297):
            if number not in ids:
                ids.append(number)
        return ids

    def _focus_random_key_from_values(self, source, dbtype, dbid, tmdb, imdb, tvdb, path, label):
        dbtype = self._focus_random_norm(dbtype).lower()
        if dbtype not in ('movie', 'tvshow', 'episode', 'season', 'set'):
            return ''
        dbid = self._focus_random_norm(dbid)
        tmdb = self._focus_random_norm(tmdb)
        imdb = self._focus_random_norm(imdb)
        tvdb = self._focus_random_norm(tvdb)
        path = self._focus_random_norm(path)
        label = self._focus_random_norm(label)
        if dbid and dbid not in ('0', '-1'):
            return f'{dbtype}:dbid:{dbid}'
        if tmdb:
            return f'{dbtype}:tmdb:{tmdb}'
        if imdb:
            return f'{dbtype}:imdb:{imdb}'
        if tvdb:
            return f'{dbtype}:tvdb:{tvdb}'
        if path and label:
            return f'{dbtype}:path:{path}'
        if label:
            return f'{dbtype}:label:{label}'
        return ''

    def _focus_random_art_signature(self, prefix):
        # Kodi can update DBID/label/path one monitor pass before Art(fanart*) catches up.
        # Track a compact art signature so V16 can run one short correction refresh when
        # stale old art turns into the real art for the new media item.
        values = []
        art_names = ['fanart'] + [f'fanart{i}' for i in range(1, 11)]
        tvshow_names = ['tvshow.fanart'] + [f'tvshow.fanart{i}' for i in range(1, 11)]
        for name in tvshow_names + art_names:
            value = self._focus_random_get_label(f'{prefix}.Art({name})')
            if value and value not in values:
                values.append(value)
        return '|'.join(values)

    def _focus_random_container_media_context(self, container_id):
        prefix = f'Container({container_id}).ListItem'
        key = self._focus_random_key_from_values(
            f'container:{container_id}',
            self._focus_random_get_label(f'{prefix}.DBTYPE'),
            self._focus_random_get_label(f'{prefix}.DBID'),
            self._focus_random_get_label(f'{prefix}.UniqueID(tmdb)'),
            self._focus_random_get_label(f'{prefix}.UniqueID(imdb)'),
            self._focus_random_get_label(f'{prefix}.UniqueID(tvdb)'),
            self._focus_random_get_label(f'{prefix}.FileNameAndPath') or self._focus_random_get_label(f'{prefix}.Path'),
            self._focus_random_get_label(f'{prefix}.Label') or self._focus_random_get_label(f'{prefix}.Title'),
        )
        if key:
            return key, f'container:{container_id}', self._focus_random_art_signature(prefix)
        return '', '', ''

    def _focus_random_listitem_media_context(self):
        key = self._focus_random_key_from_values(
            'listitem',
            self.get_infolabel('dbtype') or self._focus_random_get_label('ListItem.DBTYPE'),
            self.get_infolabel('dbid') or self._focus_random_get_label('ListItem.DBID'),
            self.get_infolabel('UniqueID(tmdb)') or self._focus_random_get_label('ListItem.UniqueID(tmdb)'),
            self.get_infolabel('UniqueID(imdb)') or self.get_infolabel('imdbnumber') or self._focus_random_get_label('ListItem.UniqueID(imdb)') or self._focus_random_get_label('ListItem.IMDBNumber'),
            self.get_infolabel('UniqueID(tvdb)') or self._focus_random_get_label('ListItem.UniqueID(tvdb)'),
            self.get_infolabel('filenameandpath') or self.get_infolabel('path') or self._focus_random_get_label('ListItem.FileNameAndPath') or self._focus_random_get_label('ListItem.Path'),
            self.get_infolabel('label') or self._focus_random_get_label('ListItem.Label') or self._focus_random_get_label('ListItem.Title'),
        )
        if key:
            return key, 'listitem', self._focus_random_art_signature('ListItem')
        return '', '', ''

    def _focus_random_get_media_context(self):
        \"\"\"Return (media_key, source, art_signature) for V16.

        Home/Hub is container-first because focus often sits on Play/More/tab buttons.
        This method is intentionally polled every monitor pass; AF3 visual containers
        can change without TMDbHelper's native is_same_item() changing.
        \"\"\"
        for container_id in self._focus_random_container_candidates():
            key, source, art_sig = self._focus_random_container_media_context(container_id)
            if key:
                return key, source, art_sig
        return self._focus_random_listitem_media_context()

    def _focus_random_get_media_key(self):
        key, source, art_sig = self._focus_random_get_media_context()
        self._focus_random_media_key_source = source
        if art_sig:
            self._focus_random_art_sig_current = getattr(self, '_focus_random_art_sig_current', '')
        return key

    def _focus_random_open_media_visit(self, media_key=None, media_source=None, art_sig=None):
        if media_key is None:
            media_key, media_source, art_sig = self._focus_random_get_media_context()
        if not media_key:
            # Button/menu/selector/transient focus: keep current fanart, no new random visit.
            return False

        if media_key == getattr(self, '_focus_random_media_key_current', ''):
            # Same media item: keep sticky fanart.
            return False

        self._focus_random_media_key_current = media_key
        self._focus_random_media_key_source = media_source or ''
        self._focus_random_art_sig_current = art_sig or ''
        self._focus_random_visit_started_at = self._focus_random_now()
        self._focus_random_art_correction_count = 0
        try:
            self._focus_random_visit_id += 1
        except AttributeError:
            self._focus_random_visit_id = 1
        self._focus_random_prime_blur_source()
        return True

    def _focus_random_should_correct_art_signature(self, media_key, art_sig):
        if not media_key or media_key != getattr(self, '_focus_random_media_key_current', ''):
            return False
        if not art_sig:
            return False
        previous = getattr(self, '_focus_random_art_sig_current', '') or ''
        if art_sig == previous:
            return False

        # Only allow short correction refreshes right after a media change.
        # This catches Kodi's 1-pass stale Art(fanart*) lag without re-enabling
        # idle cycle/random changes while the user stays on one item.
        try:
            elapsed = self._focus_random_now() - float(getattr(self, '_focus_random_visit_started_at', 0.0) or 0.0)
        except Exception:
            elapsed = 999.0
        if elapsed > 1.8:
            return False

        count = int(getattr(self, '_focus_random_art_correction_count', 0) or 0)
        if count >= 2:
            return False

        self._focus_random_art_sig_current = art_sig
        self._focus_random_art_correction_count = count + 1
        return True

    def _focus_random_prime_blur_source(self):
        # Prime current blur props with the new chosen source image.
        # TMDbHelper normally leaves the previous item's BlurImage in place while
        # the new blur_v3 file is being created. AF3 can show that stale image for
        # one or two frames during fast focus changes. This primes the properties
        # with the newly selected source immediately; the normal blur output
        # overwrites it moments later.
        try:
            source = self.get_artwork(
                source=self.get_property('Blur.SourceImage'),
                build_fallback=True,
                built_artwork=self.remote_artwork.get(self.pre_item)
            ) or self.get_property('Blur.Fallback')
        except Exception:
            source = ''
        if not source:
            return
        try:
            if self.is_current_window_images:
                self.get_property('ListItem.BlurImage', set_property=source, use_current_window=True)
                self.get_property('ListItem.BlurImage.Original', set_property=source, use_current_window=True)
                self.add_property('ListItem.Current.BlurImage', source)
                self.add_property('ListItem.Current.BlurImage.Original', source)
            else:
                self.add_property('ListItem.BlurImage', source)
                self.add_property('ListItem.BlurImage.Original', source)
        except Exception:
            return

    def is_next_refresh(self):
        # V16 polls the AF3 visual container every monitor pass. In Home/Hub,
        # TMDbHelper's native item identity can stay the same while WidgetContainer
        # moves to a new movie/show.
        media_key, media_source, art_sig = self._focus_random_get_media_context()
        if media_key:
            if media_key != getattr(self, '_focus_random_media_key_current', ''):
                return self._focus_random_open_media_visit(media_key, media_source, art_sig)
            if self._focus_random_should_correct_art_signature(media_key, art_sig):
                return True

        # Check we can actually get something from underlying item. Keep this after
        # the container poll so Home/Hub visual media can still refresh even when
        # global ListItem is empty because focus is on Play/More/tab.
        if self.is_same_base_window(update=True) and not self.get_cur_info():
            return False

        # {refresh_start}
        # Idle extra-fanart refresh is intentionally disabled. Native TMDbHelper
        # item/window changes are still accepted as a fallback for non-hub views.
        item_changed = not self.is_same_item(update=True)
        window_changed = not self.is_same_window(update=True)
        if item_changed or window_changed:
            return self._focus_random_open_media_visit(media_key, media_source, art_sig)

        # {refresh_end}
        return False

"""
    replacement = replacement.replace('{refresh_start}', TMDB_REFRESH_START).replace('{refresh_end}', TMDB_REFRESH_END)
    replacement = replacement.replace('\n', nl)
    return re.sub(method_pattern, lambda _m: replacement, text, count=1)


def _tmdb_focus_strip_old_images(text: str) -> str:
    # Remove helper blocks from standalone V11/V12/V13 or prior KPM builds if they were inserted before ImageFunctions.
    text = re.sub(r'(?ms)\r?\n' + re.escape(TMDB_V12_HELPER_START) + r'.*?' + re.escape(TMDB_V12_HELPER_END) + r'\r?\n', '\n', text)
    text = re.sub(r'(?ms)\r?\n' + re.escape(TMDB_HELPER_START) + r'.*?' + re.escape(TMDB_HELPER_END) + r'\r?\n', '\n', text)
    text = re.sub(r'(?ms)\r?\n# Focus-random sticky visit patch V11.*?(?=class ImageFunctions)', '\n', text)
    text = re.sub(r'(?ms)\r?\n# Focus-random on-visit sticky idle patch V12.*?(?=class ImageFunctions)', '\n', text)
    text = re.sub(r'(?ms)\r?\n# Focus-random on-visit sticky idle patch V13.*?(?=class ImageFunctions)', '\n', text)
    text = re.sub(r'(?ms)\r?\n# Focus-random on-visit sticky idle patch V14.*?(?=class ImageFunctions)', '\n', text)
    text = re.sub(r'(?ms)\r?\n# Focus-random on-visit sticky idle patch V16.*?(?=class ImageFunctions)', '\n', text)
    text = re.sub(r'(?ms)\r?\n# Focus-random on-visit sticky idle patch V15.*?(?=class ImageFunctions)', '\n', text)
    text = re.sub(r'(?ms)^# KPM-TMDB-FOCUS-RANDOM-V12-HELPER-START\r?\n?', '', text)
    text = re.sub(r'(?ms)^# KPM-TMDB-FOCUS-RANDOM-V13-HELPER-START\r?\n?', '', text)
    text = re.sub(r'(?ms)^# KPM-TMDB-FOCUS-RANDOM-V14-HELPER-START\r?\n?', '', text)
    text = re.sub(r'(?ms)^# KPM-TMDB-FOCUS-RANDOM-V16-HELPER-START\r?\n?', '', text)
    text = re.sub(r'(?ms)^# KPM-TMDB-FOCUS-RANDOM-V15-HELPER-START\r?\n?', '', text)
    return text


def _patch_tmdb_focus_images_text(text: str) -> str:
    nl = newline_of(text)
    text = _tmdb_focus_strip_old_images(text)

    helper = """
{helper_start}
# Focus-random on-visit sticky idle patch V16
# Random fanart is chosen once per stable media visit and then kept sticky while the same media item remains active.
# A real media change opens a new visit. A -> B -> A, even quickly, is allowed to random A again.
_FOCUS_RANDOM_ONVISIT_BY_VISIT = {{}}
_FOCUS_RANDOM_ONVISIT_LAST_BY_MEDIA = {{}}


def _focus_random_onvisit_unique(values):
    output = []
    for value in values:
        if value and value not in output:
            output.append(value)
    return output


def _focus_random_onvisit_attr(parent, name, default=None):
    try:
        return getattr(parent, name, default)
    except Exception:
        return default


def _focus_random_onvisit_choose(item, artworks, parent=None):
    artworks = _focus_random_onvisit_unique(artworks)
    if not artworks:
        return None
    if len(artworks) == 1:
        return artworks[0]

    parent_id = id(parent) if parent is not None else 0
    visit_id = _focus_random_onvisit_attr(parent, '_focus_random_visit_id', 0)
    media_key = _focus_random_onvisit_attr(parent, '_focus_random_media_key_current', '') or ''

    # If imgmon has no stable media key yet, fall back to the current TMDbHelper item identity.
    # Normal V15 path should use media_key.
    if not media_key:
        media_key = repr(_focus_random_onvisit_attr(parent, 'pre_item', None))

    visit_key = (parent_id, visit_id, media_key, item)
    cached = _FOCUS_RANDOM_ONVISIT_BY_VISIT.get(visit_key)
    if cached in artworks:
        return cached

    media_item_key = (parent_id, media_key, item)
    last = _FOCUS_RANDOM_ONVISIT_LAST_BY_MEDIA.get(media_item_key)
    choices = [art for art in artworks if art != last] or artworks
    choice = random.choice(choices)

    _FOCUS_RANDOM_ONVISIT_BY_VISIT[visit_key] = choice
    _FOCUS_RANDOM_ONVISIT_LAST_BY_MEDIA[media_item_key] = choice

    # Keep dictionaries small during long browsing sessions.
    if len(_FOCUS_RANDOM_ONVISIT_BY_VISIT) > 800:
        _FOCUS_RANDOM_ONVISIT_BY_VISIT.clear()
        _FOCUS_RANDOM_ONVISIT_BY_VISIT[visit_key] = choice
    if len(_FOCUS_RANDOM_ONVISIT_LAST_BY_MEDIA) > 800:
        _FOCUS_RANDOM_ONVISIT_LAST_BY_MEDIA.clear()
        _FOCUS_RANDOM_ONVISIT_LAST_BY_MEDIA[media_item_key] = choice

    return choice
{helper_end}
""".format(helper_start=TMDB_HELPER_START, helper_end=TMDB_HELPER_END)
    helper = helper.replace('\n', nl)

    anchor = 'class ImageFunctions'
    idx = text.find(anchor)
    if idx < 0:
        raise RuntimeError('Anchor not found in images.py: class ImageFunctions')
    text = text[:idx] + helper + nl + text[idx:]

    # Replace old V11 call first, then original random.choice. Avoid duplicate replacement.
    text = re.sub(r'return\s+_focus_random_sticky_choose\(item, artworks, self\._parent\).*',
                  'return _focus_random_onvisit_choose(item, artworks, self._parent)  ' + TMDB_CALL_MARKER,
                  text)
    text = re.sub(r'return\s+_focus_random_onvisit_choose\(item, artworks, self\._parent\).*',
                  'return _focus_random_onvisit_choose(item, artworks, self._parent)  ' + TMDB_CALL_MARKER,
                  text)
    if re.search(r'return\s+_focus_random_onvisit_choose\(item, artworks, self\._parent\)', text):
        return text

    matches = list(re.finditer(r'return\s+random\.choice\(artworks\)', text))
    if len(matches) != 1:
        raise RuntimeError(f'Anchor not found uniquely in images.py: return random.choice(artworks) count={len(matches)}')
    return re.sub(r'return\s+random\.choice\(artworks\)',
                  'return _focus_random_onvisit_choose(item, artworks, self._parent)  ' + TMDB_CALL_MARKER,
                  text, count=1)


def patch_tmdb_focus_random_v12() -> Result:
    title = patch_title('tmdb_focus_random_v12', 'TMDbHelper Visit Random Fanart')
    imgmon, images = tmdb_focus_random_targets()
    imgmon_text = read_text(imgmon)
    images_text = read_text(images)
    if _tmdb_focus_text_has_v12(imgmon_text, images_text):
        return Result(title, 'Skipped', 'V16 is already patched.')

    new_imgmon = _patch_tmdb_focus_imgmon_text(imgmon_text)
    new_images = _patch_tmdb_focus_images_text(images_text)
    if new_imgmon == imgmon_text and new_images == images_text:
        return Result(title, 'Skipped', 'No change was required.')

    original_imgmon_for_restore = imgmon_text
    original_images_for_restore = images_text
    try:
        previous_state = load_state('tmdb_focus_random_v12')
        original_imgmon_for_restore = previous_state.get('original_imgmon') or original_imgmon_for_restore
        original_images_for_restore = previous_state.get('original_images') or original_images_for_restore
    except Exception:
        pass
    snapshot('tmdb_focus_random_v12', [imgmon, images])
    save_state('tmdb_focus_random_v12', {
        'imgmon': imgmon,
        'images': images,
        'original_imgmon': original_imgmon_for_restore,
        'original_images': original_images_for_restore,
    })
    write_text(imgmon, new_imgmon)
    write_text(images, new_images)
    clear_pycache(os.path.dirname(imgmon), ('imgmon', 'images'))
    return Result(title, 'Patched', 'TMDbHelper now randoms once per valid media visit, stays sticky while idle, and primes the new source immediately to reduce stale old-item flashes. Restart Kodi/TMDbHelper after patching.')


def remove_tmdb_focus_random_v12() -> Result:
    title = patch_title('tmdb_focus_random_v12', 'TMDbHelper Visit Random Fanart')
    imgmon, images = tmdb_focus_random_targets()
    if status_tmdb_focus_random_v12() != 'Patched':
        return Result(title, 'Skipped', 'V15 marker is not installed.')
    try:
        state = load_state('tmdb_focus_random_v12')
    except Exception:
        raise RuntimeError('V15 is patched but KPM state backup is missing. Reinstall TMDbHelper or restore from your previous backup before removing this patch.')
    original_imgmon = state.get('original_imgmon')
    original_images = state.get('original_images')
    if not original_imgmon or not original_images:
        raise RuntimeError('KPM state backup is incomplete for TMDbHelper V15.')
    write_text(imgmon, original_imgmon)
    write_text(images, original_images)
    clear_pycache(os.path.dirname(imgmon), ('imgmon', 'images'))
    delete_state('tmdb_focus_random_v12')
    return Result(title, 'Restored', 'TMDbHelper imgmon.py and images.py were restored from KPM state backup. Restart Kodi/TMDbHelper.')


def _diagnostic_text(runtime: dict, target_report: dict, vfs_text: str, seekbar_text: str) -> str:
    lines = []
    lines.append(f'{ADDON_NAME} diagnostics v{VERSION}')
    lines.append(f'Generated: {time.strftime("%Y-%m-%d %H:%M:%S")}')
    lines.append('')
    lines.append('Patch status:')
    lines.append(patch_status_summary())
    lines.append('')
    lines.append('Runtime state:')
    lines.append(json.dumps(runtime, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Target files:')
    lines.append(json.dumps(target_report, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Studio logo diagnostics:')
    try:
        lines.append(_studio_diagnostic_text(studio_logo_diagnostics_report()))
    except Exception as exc:
        lines.append(f'Studio diagnostics error: {exc}')
    lines.append('')
    lines.append('DialogSeekBar marker snippet:')
    lines.append(_line_numbered_snippet(seekbar_text, DIALOG_SEEKBAR_PAUSE_RATINGS_START, DIALOG_SEEKBAR_PAUSE_RATINGS_END))
    lines.append('')
    lines.append('VideoFullScreen legacy marker snippet:')
    lines.append(_line_numbered_snippet(vfs_text, VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END))
    return '\n'.join(lines)


def _write_diag_file(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8', errors='replace') as handle:
        handle.write(content)


def export_diagnostics() -> Result:
    name = 'Export Diagnostics ZIP'
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_dir = addon_data_dir(DIAG_EXPORT_DIRNAME, stamp)
    zip_path = os.path.join(addon_data_dir(DIAG_EXPORT_DIRNAME), f'kpm-diagnostics-{stamp}.zip')
    runtime = _player_runtime_state()
    target_report = _target_files_report()
    vfs_target = vfs_pause_target()
    seekbar_target = seekbar_pause_target()
    vfs_text = _read_file_if_exists(vfs_target, 1000000)
    seekbar_text = _read_file_if_exists(seekbar_target, 1000000)
    diag_text = _diagnostic_text(runtime, target_report, vfs_text, seekbar_text)

    files_to_write = {
        'summary.txt': diag_text,
        'runtime.json': json.dumps(runtime, indent=2, ensure_ascii=False),
        'target-files.json': json.dumps(target_report, indent=2, ensure_ascii=False),
        'patch-status.txt': patch_status_summary(),
        'DialogSeekBar-marker-snippet.txt': _line_numbered_snippet(seekbar_text, DIALOG_SEEKBAR_PAUSE_RATINGS_START, DIALOG_SEEKBAR_PAUSE_RATINGS_END),
        'DialogSeekBar.xml': seekbar_text,
        'VideoFullScreen-legacy-marker-snippet.txt': _line_numbered_snippet(vfs_text, VFS_PAUSE_RATINGS_START, VFS_PAUSE_RATINGS_END),
        'VideoFullScreen.xml': vfs_text,
        'Includes_Info.head.txt': _read_file_if_exists(af3_path('1080i', 'Includes_Info.xml'), 150000),
        'Includes_OSD.tail.txt': _read_file_if_exists(af3_path('1080i', 'Includes_OSD.xml'), 200000),
        'kodi-log-filtered.txt': _filtered_kodi_log(),
    }
    try:
        studio_report = studio_logo_diagnostics_report()
        files_to_write['studio-logo-diagnostics.txt'] = _studio_diagnostic_text(studio_report)
        files_to_write['studio-logo-diagnostics.json'] = json.dumps(studio_report, indent=2, ensure_ascii=False)
        files_to_write['studio-context.json'] = json.dumps(studio_report.get('context', {}), indent=2, ensure_ascii=False)
        files_to_write['studio-home-properties.json'] = json.dumps(studio_report.get('home_properties', {}), indent=2, ensure_ascii=False)
        files_to_write['Includes_Images-Image_CombinedStudio-snippet.txt'] = _marked_snippet(includes_images_target(), STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END)
        files_to_write['Includes_Furniture-Furniture_Studio-snippet.txt'] = _marked_snippet(includes_furniture_target(), STUDIO_FURNITURE_START, STUDIO_FURNITURE_END)
        files_to_write['kodi-log-studio-filtered.txt'] = _studio_log_filtered()
    except Exception as exc:
        files_to_write['studio-logo-diagnostics-error.txt'] = str(exc)
    lrs_settings = norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml'))
    if os.path.exists(lrs_settings):
        files_to_write['lrs-settings.xml'] = _read_file_if_exists(lrs_settings, 100000)
    lrs_addon = norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml'))
    if os.path.exists(lrs_addon):
        files_to_write['lrs-addon.xml'] = _read_file_if_exists(lrs_addon, 100000)

    live_dir = addon_data_dir(DIAG_LIVE_DIRNAME)
    if os.path.isdir(live_dir):
        live_manifest = []
        for fname in sorted(os.listdir(live_dir)):
            if fname.startswith(DIAG_LIVE_PREFIX) or fname.startswith(FANART_DIAG_LIVE_PREFIX):
                fpath = os.path.join(live_dir, fname)
                live_manifest.append(_full_file_digest(fpath))
                files_to_write['live/' + fname] = _read_live_text_if_exists(fpath, 20000000)
        if live_manifest:
            files_to_write['live/_manifest.json'] = json.dumps(live_manifest, indent=2, ensure_ascii=False)

    try:
        imgmon, images = tmdb_focus_random_targets()
        if os.path.exists(imgmon):
            imgmon_text = _read_file_if_exists(imgmon, 1000000)
            files_to_write['tmdbhelper-monitor/imgmon.py'] = imgmon_text
            files_to_write['tmdbhelper-monitor/imgmon-v16-snippet.txt'] = _marked_snippet(imgmon, TMDB_REFRESH_START, TMDB_REFRESH_END, 200000)
        if os.path.exists(images):
            images_text = _read_file_if_exists(images, 1000000)
            files_to_write['tmdbhelper-monitor/images.py'] = images_text
            files_to_write['tmdbhelper-monitor/images-v16-snippet.txt'] = _marked_snippet(images, TMDB_HELPER_START, TMDB_HELPER_END, 300000)
    except Exception as exc:
        files_to_write['tmdbhelper-monitor/error.txt'] = str(exc)

    for rel, content in files_to_write.items():
        _write_diag_file(os.path.join(out_dir, rel.replace('/', os.sep)), content)

    with zipfile.ZipFile(zip_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
        for root, _dirs, files in os.walk(out_dir):
            for fname in files:
                fpath = os.path.join(root, fname)
                zf.write(fpath, os.path.relpath(fpath, out_dir))

    log('[KPM_DIAG] Exported diagnostics: {0}'.format(zip_path))
    # Also log current key values into kodi.log for quick inspection.
    home_slots = runtime.get('lrs_properties', {}).get('10000', {}).get('Player', {}) if isinstance(runtime, dict) else {}
    for slot in range(1, 7):
        sd = home_slots.get(f'RatingSlot{slot}', {}) if isinstance(home_slots, dict) else {}
        log('[KPM_DIAG] Home Player Slot{0}: source={1!r} icon={2!r} label={3!r}'.format(slot, sd.get('Source'), sd.get('IconFile'), sd.get('Label')))
    return Result(name, 'Exported', zip_path)


def run_diag_live(duration_seconds: int = 90) -> None:
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_path = os.path.join(addon_data_dir(DIAG_LIVE_DIRNAME), f'{DIAG_LIVE_PREFIX}-{stamp}.jsonl')
    end_time = time.time() + max(5, int(duration_seconds))
    notify('Live diagnostic started. Pause fullscreen video now.')
    log('[KPM_DIAG] Live fullscreen ratings diagnostic started for {0}s -> {1}'.format(duration_seconds, out_path))
    with open(out_path, 'w', encoding='utf-8') as handle:
        sample_no = 0
        while time.time() < end_time:
            if xbmc and xbmc.Monitor().abortRequested():
                break
            sample_no += 1
            data = _player_runtime_state()
            data['sample'] = sample_no
            handle.write(json.dumps(data, ensure_ascii=False) + '\n')
            handle.flush()
            conds = data.get('conditions', {})
            hp = data.get('lrs_properties', {}).get('10000', {}).get('Player', {})
            s1 = hp.get('RatingSlot1', {}) if isinstance(hp, dict) else {}
            log('[KPM_DIAG] sample={0} paused={1} seeking={2} fullscreen={3} title={4!r} slot1={5!r}/{6!r}/{7!r}'.format(
                sample_no,
                conds.get('Player.Paused'),
                conds.get('Player.Seeking'),
                conds.get('Window.IsActive(fullscreenvideo)'),
                data.get('videoplayer_labels', {}).get('Title'),
                s1.get('Source'), s1.get('IconFile'), s1.get('Label'),
            ))
            if xbmc:
                xbmc.sleep(1000)
            else:
                time.sleep(1)
    log('[KPM_DIAG] Live fullscreen ratings diagnostic finished: {0}'.format(out_path))
    notify('Live diagnostic finished. Export Diagnostics ZIP now.')


def start_live_diagnostics_menu() -> None:
    message = (
        'Start a 90 second live diagnostic logger now?\n\n'
        'After pressing Yes, go back to the video and pause it. The logger records Player.Paused, active windows, VideoPlayer labels, and all LibraryRatings.Player RatingSlot1-6 properties once per second.'
    )
    if not yesno(ADDON_NAME, message):
        return
    if xbmc:
        xbmc.executebuiltin(f'RunScript({ADDON_ID},diag_live,90)')
        ok(ADDON_NAME, 'Live diagnostic started for 90 seconds.\n\nNow go to the video, pause it, wait a few seconds, then come back here and run Export Diagnostics ZIP.')
    else:
        run_diag_live(10)


FANART_DIAG_COMMON_CONTAINERS = (300, 311, 312, 500, 501, 502, 503, 504, 601, 950, 951, 952, 1297)
FANART_DIAG_HOME_PROPS = (
    'TMDbHelper.WidgetContainer',
    'TMDbHelper.Blur.SourceImage',
    'TMDbHelper.Blur.Fallback',
    'TMDbHelper.ListItem.Fanart',
    'TMDbHelper.ListItem.Fanart.1',
    'TMDbHelper.ListItem.Fanart.2',
    'TMDbHelper.ListItem.Fanart.3',
    'TMDbHelper.ListItem.Backdrop',
    'TMDbHelper.ListItem.Backdrop.1',
    'TMDbHelper.ListItem.Backdrop.2',
    'TMDbHelper.ListItem.Backdrop.3',
    'TMDbHelper.ListItem.Art.Fanart',
    'TMDbHelper.ListItem.Art.Landscape',
    'TMDbHelper.ListItem.BlurImage',
    'TMDbHelper.ListItem.BlurImage.Original',
    'TMDbHelper.ListItem.Current.BlurImage',
    'TMDbHelper.ListItem.Current.BlurImage.Original',
    'TMDbHelper.SimpleBackground.BlurImage',
    'TMDbHelper.SimpleBackground.BlurImage.Original',
    'LRS.Active.ContainerID',
    'KPM.Active.ContainerID',
    'KPM.Focus.Container',
    'KPM.Fanart.Display',
    'KPM.Fanart.Ready',
    'KPM.Fanart.SourceImage',
    'KPM.Fanart.Selected',
    'KPM.Fanart.Reason',
    'KPM.Fanart.CacheResult',
    'KPM.Fanart.ItemKey',
    'KPM.Fanart.CurrentFocusKey',
)
FANART_DIAG_CURRENT_WINDOW_PROPS = (
    'TMDbHelper.WidgetContainer',
    'LRS.Active.ContainerID',
    'KPM.Active.ContainerID',
    'KPM.Focus.Container',
    'TMDbHelper.Blur.SourceImage',
    'TMDbHelper.Blur.Fallback',
    'TMDbHelper.ListItem.BlurImage',
    'TMDbHelper.ListItem.BlurImage.Original',
    'TMDbHelper.ListItem.Current.BlurImage',
    'TMDbHelper.ListItem.Current.BlurImage.Original',
    'fanart',
)
FANART_DIAG_LISTITEM_LABELS = (
    'System.CurrentWindow',
    'System.CurrentControl',
    'System.CurrentControlID',
    'ListItem.Label',
    'ListItem.Title',
    'ListItem.DBID',
    'ListItem.DBTYPE',
    'ListItem.Year',
    'ListItem.UniqueID(tmdb)',
    'ListItem.UniqueID(imdb)',
    'ListItem.Art(fanart)',
    'ListItem.Art(fanart1)',
    'ListItem.Art(fanart2)',
    'ListItem.Art(fanart3)',
    'ListItem.Art(fanart4)',
    'ListItem.Art(fanart5)',
    'ListItem.Art(fanart6)',
    'ListItem.Art(fanart7)',
    'ListItem.Art(fanart8)',
    'ListItem.Art(fanart9)',
    'ListItem.Art(fanart10)',
    'ListItem.Art(landscape)',
    'ListItem.Art(poster)',
    'ListItem.Path',
    'ListItem.FileNameAndPath',
    'Container.FolderPath',
    'Container.ListItem.Label',
    'Container.ListItem.Title',
    'Container.ListItem.DBID',
    'Container.ListItem.DBTYPE',
    'Container.ListItem.Year',
    'Container.ListItem.UniqueID(tmdb)',
    'Container.ListItem.UniqueID(imdb)',
    'Container.ListItem.Art(fanart)',
    'Container.ListItem.Art(fanart1)',
    'Container.ListItem.Art(fanart2)',
    'Container.ListItem.Art(fanart3)',
    'Container.ListItem.Art(fanart4)',
    'Container.ListItem.Art(fanart5)',
    'Container.ListItem.Art(fanart6)',
    'Container.ListItem.Art(fanart7)',
    'Container.ListItem.Art(fanart8)',
    'Container.ListItem.Art(fanart9)',
    'Container.ListItem.Art(fanart10)',
    'Container.ListItem.Art(landscape)',
    'Container.ListItem.Art(poster)',
    'Window.Property(fanart)',
    'Window(Home).Property(fanart)',
    'Window(Home).Property(TMDbHelper.WidgetContainer)',
    'Window.Property(TMDbHelper.WidgetContainer)',
    'Window(Home).Property(TMDbHelper.Blur.SourceImage)',
    'Window(Home).Property(TMDbHelper.Blur.Fallback)',
    'Window.Property(TMDbHelper.Blur.SourceImage)',
    'Window.Property(TMDbHelper.Blur.Fallback)',
    'Window.Property(TMDbHelper.ListItem.BlurImage)',
    'Window.Property(TMDbHelper.ListItem.BlurImage.Original)',
    'Window(Home).Property(TMDbHelper.ListItem.BlurImage)',
    'Window(Home).Property(TMDbHelper.ListItem.BlurImage.Original)',
    'Window(Home).Property(TMDbHelper.ListItem.Current.BlurImage)',
    'Window(Home).Property(TMDbHelper.ListItem.Current.BlurImage.Original)',
    'Window(Home).Property(TMDbHelper.SimpleBackground.BlurImage)',
    'Window(Home).Property(TMDbHelper.SimpleBackground.BlurImage.Original)',
)


def _fanart_diag_parse_container_ids(*values: str) -> List[int]:
    ids: List[int] = []
    for value in values:
        for found in __import__('re').findall(r'\d+', str(value or '')):
            try:
                number = int(found)
            except Exception:
                continue
            if 0 < number < 10000 and number not in ids:
                ids.append(number)
    return ids




def _fanart_diag_media_key_from_snapshot(snapshot: Dict[str, object]) -> str:
    dbtype = str(snapshot.get('dbtype') or '').strip().lower()
    if dbtype not in ('movie', 'tvshow', 'episode', 'season', 'set'):
        return ''
    dbid = str(snapshot.get('dbid') or '').strip()
    tmdb = str(snapshot.get('uniqueid_tmdb') or '').strip()
    imdb = str(snapshot.get('uniqueid_imdb') or '').strip()
    path = str(snapshot.get('filename_and_path') or snapshot.get('path') or '').strip()
    label = str(snapshot.get('label') or snapshot.get('title') or '').strip()
    if dbid and dbid not in ('0', '-1'):
        return f'{dbtype}:dbid:{dbid}'
    if tmdb:
        return f'{dbtype}:tmdb:{tmdb}'
    if imdb:
        return f'{dbtype}:imdb:{imdb}'
    if path and label:
        return f'{dbtype}:path:{path}'
    if label:
        return f'{dbtype}:label:{label}'
    return ''


def _fanart_diag_fanart_candidates_from_art(art: Dict[str, str]) -> List[str]:
    values: List[str] = []
    for key in ['fanart'] + [f'fanart{x}' for x in range(1, 11)]:
        value = str(art.get(key) or '').strip()
        if value and value not in values:
            values.append(value)
    return values

def _fanart_diag_container_snapshot(container_id: int) -> Dict[str, object]:
    prefix = f'Container({container_id}).ListItem'
    art = {f'fanart{x if x else ""}': info_label(f'{prefix}.Art(fanart{x if x else ""})') for x in range(0, 11)}
    art['landscape'] = info_label(f'{prefix}.Art(landscape)')
    art['poster'] = info_label(f'{prefix}.Art(poster)')
    snapshot = {
        'control_has_focus': cond_visible(f'Control.HasFocus({container_id})'),
        'container_position': info_label(f'Container({container_id}).Position'),
        'container_current_item': info_label(f'Container({container_id}).CurrentItem'),
        'container_num_items': info_label(f'Container({container_id}).NumItems'),
        'label': info_label(f'{prefix}.Label'),
        'title': info_label(f'{prefix}.Title'),
        'dbid': info_label(f'{prefix}.DBID'),
        'dbtype': info_label(f'{prefix}.DBTYPE'),
        'year': info_label(f'{prefix}.Year'),
        'uniqueid_tmdb': info_label(f'{prefix}.UniqueID(tmdb)'),
        'uniqueid_imdb': info_label(f'{prefix}.UniqueID(imdb)'),
        'uniqueid_tvdb': info_label(f'{prefix}.UniqueID(tvdb)'),
        'property_widget_id': info_label(f'{prefix}.Property(widget_id)'),
        'property_item_id': info_label(f'{prefix}.Property(item_id)'),
        'property_tmdb_id': info_label(f'{prefix}.Property(tmdb_id)'),
        'property_imdb_id': info_label(f'{prefix}.Property(imdb_id)'),
        'path': info_label(f'{prefix}.Path'),
        'filename_and_path': info_label(f'{prefix}.FileNameAndPath'),
        'art': art,
    }
    snapshot['media_key'] = _fanart_diag_media_key_from_snapshot(snapshot)
    snapshot['fanart_candidates'] = _fanart_diag_fanart_candidates_from_art(art)
    return snapshot

def _fanart_diag_is_valid_media_snapshot(snapshot: Dict[str, object]) -> bool:
    dbtype = str(snapshot.get('dbtype') or '').strip().lower()
    if dbtype not in ('movie', 'tvshow', 'episode', 'season', 'set'):
        return False
    dbid = str(snapshot.get('dbid') or '').strip()
    if dbid and dbid not in ('0', '-1'):
        return True
    return bool(str(snapshot.get('uniqueid_tmdb') or snapshot.get('uniqueid_imdb') or snapshot.get('label') or '').strip())


def _fanart_diag_resolve_active_container_id(labels: Dict[str, str], home_props: Dict[str, str], current_props: Dict[str, str], containers: Dict[str, Dict[str, object]]) -> str:
    # In normal Videos/library views the focused control is the truthful visual container.
    current_ctrl = ''.join(re.findall(r'\d+', str(labels.get('System.CurrentControlID') or '')))
    if current_ctrl and _fanart_diag_is_valid_media_snapshot(containers.get(current_ctrl, {})):
        return current_ctrl

    focused = [cid for cid, snap in containers.items() if snap.get('control_has_focus') and _fanart_diag_is_valid_media_snapshot(snap)]
    if focused:
        return focused[0]

    # AF3 hub/home: the current window's TMDbHelper.WidgetContainer follows the visual
    # item being rendered. Window(Home).KPM.Active.ContainerID can be a stale hero/list
    # bridge, so it is only a fallback.
    for value in (
            current_props.get('TMDbHelper.WidgetContainer', ''),
            current_props.get('LRS.Active.ContainerID', ''),
            current_props.get('KPM.Active.ContainerID', ''),
            current_props.get('KPM.Focus.Container', ''),
            labels.get('Window.Property(TMDbHelper.WidgetContainer)', ''),
            home_props.get('TMDbHelper.WidgetContainer', ''),
            home_props.get('LRS.Active.ContainerID', ''),
            home_props.get('KPM.Active.ContainerID', ''),
            home_props.get('KPM.Focus.Container', ''),
            labels.get('Window(Home).Property(TMDbHelper.WidgetContainer)', ''),
    ):
        for cid in _fanart_diag_parse_container_ids(value):
            key = str(cid)
            if _fanart_diag_is_valid_media_snapshot(containers.get(key, {})):
                return key

    for cid, snap in containers.items():
        if _fanart_diag_is_valid_media_snapshot(snap):
            return cid
    return current_ctrl or ''



def _fanart_diag_bridge_props_by_window(current_window_id: int) -> Dict[str, Dict[str, str]]:
    prop_names = (
        'KPM.Active.ContainerID',
        'KPM.Focus.Container',
        'LRS.Active.ContainerID',
        'TMDbHelper.WidgetContainer',
        'TMDbHelper.Blur.SourceImage',
        'TMDbHelper.Blur.Fallback',
        'TMDbHelper.ListItem.BlurImage',
        'TMDbHelper.ListItem.BlurImage.Original',
        'TMDbHelper.ListItem.Current.BlurImage',
        'TMDbHelper.ListItem.Current.BlurImage.Original',
    )
    # Only inspect Home and the actual current window. Probing guessed AF3 ids can
    # make Kodi log "Window id does not exist" hundreds of times.
    window_ids: List[int] = []
    for wid in (10000, current_window_id):
        if isinstance(wid, int) and wid > 0 and wid not in window_ids:
            window_ids.append(wid)
    output: Dict[str, Dict[str, str]] = {}
    for wid in window_ids:
        output[str(wid)] = {name: _window_prop(wid, name) for name in prop_names}
    return output


def _fanart_diag_resolution_candidates(labels: Dict[str, str], home_props: Dict[str, str], current_props: Dict[str, str], containers: Dict[str, Dict[str, object]]) -> List[Dict[str, object]]:
    raw_sources: List[Tuple[str, str]] = [
        ('current_control', labels.get('System.CurrentControlID', '')),
        ('current.TMDbHelper.WidgetContainer', current_props.get('TMDbHelper.WidgetContainer', '')),
        ('current.LRS.Active.ContainerID', current_props.get('LRS.Active.ContainerID', '')),
        ('current.KPM.Active.ContainerID', current_props.get('KPM.Active.ContainerID', '')),
        ('current.KPM.Focus.Container', current_props.get('KPM.Focus.Container', '')),
        ('label.Window.TMDbHelper.WidgetContainer', labels.get('Window.Property(TMDbHelper.WidgetContainer)', '')),
        ('home.TMDbHelper.WidgetContainer', home_props.get('TMDbHelper.WidgetContainer', '')),
        ('home.LRS.Active.ContainerID', home_props.get('LRS.Active.ContainerID', '')),
        ('home.KPM.Active.ContainerID', home_props.get('KPM.Active.ContainerID', '')),
        ('home.KPM.Focus.Container', home_props.get('KPM.Focus.Container', '')),
        ('label.Window(Home).TMDbHelper.WidgetContainer', labels.get('Window(Home).Property(TMDbHelper.WidgetContainer)', '')),
    ]
    seen: set = set()
    out: List[Dict[str, object]] = []
    for source, value in raw_sources:
        for cid in _fanart_diag_parse_container_ids(value):
            key = (source, str(cid))
            if key in seen:
                continue
            seen.add(key)
            snap = containers.get(str(cid), {})
            out.append({
                'source': source,
                'container_id': str(cid),
                'raw_value': value,
                'valid_media': _fanart_diag_is_valid_media_snapshot(snap),
                'media_key': snap.get('media_key', ''),
                'label': snap.get('label') or snap.get('title') or '',
                'dbtype': snap.get('dbtype', ''),
                'dbid': snap.get('dbid', ''),
                'control_has_focus': snap.get('control_has_focus', False),
                'fanart_candidates_count': len(snap.get('fanart_candidates') or []),
                'fanart_candidates': snap.get('fanart_candidates') or [],
            })
    return out


def _fanart_diag_match_url_to_containers(url: str, containers: Dict[str, Dict[str, object]]) -> List[Dict[str, str]]:
    url = str(url or '')
    if not url:
        return []
    matches: List[Dict[str, str]] = []
    for cid, snap in containers.items():
        art = snap.get('art') or {}
        for key, value in art.items():
            if value and value == url:
                matches.append({
                    'container_id': cid,
                    'art_key': key,
                    'media_key': str(snap.get('media_key') or ''),
                    'label': str(snap.get('label') or snap.get('title') or ''),
                })
    return matches

def _fanart_runtime_state() -> dict:
    ids = _current_window_ids()
    current_window_id = int(ids.get('current_window_id', 0) or 0)
    labels = {key: info_label(key) for key in FANART_DIAG_LISTITEM_LABELS}
    home_props = {key: _window_prop(10000, key) for key in FANART_DIAG_HOME_PROPS}
    current_props = {key: _window_prop(current_window_id, key) for key in FANART_DIAG_CURRENT_WINDOW_PROPS} if current_window_id else {}

    container_ids: List[int] = []
    for cid in _fanart_diag_parse_container_ids(
        labels.get('System.CurrentControlID', ''),
        current_props.get('TMDbHelper.WidgetContainer', ''),
        current_props.get('LRS.Active.ContainerID', ''),
        current_props.get('KPM.Active.ContainerID', ''),
        current_props.get('KPM.Focus.Container', ''),
        labels.get('Window.Property(TMDbHelper.WidgetContainer)', ''),
        home_props.get('TMDbHelper.WidgetContainer', ''),
        home_props.get('LRS.Active.ContainerID', ''),
        home_props.get('KPM.Active.ContainerID', ''),
        home_props.get('KPM.Focus.Container', ''),
        labels.get('Window(Home).Property(TMDbHelper.WidgetContainer)', ''),
    ):
        if cid not in container_ids:
            container_ids.append(cid)
    for cid in FANART_DIAG_COMMON_CONTAINERS:
        if cid not in container_ids:
            container_ids.append(cid)

    container_snapshots = {str(cid): _fanart_diag_container_snapshot(cid) for cid in container_ids}
    active_container_id = _fanart_diag_resolve_active_container_id(labels, home_props, current_props, container_snapshots)
    bridge_props_by_window = _fanart_diag_bridge_props_by_window(current_window_id)
    resolution_candidates = _fanart_diag_resolution_candidates(labels, home_props, current_props, container_snapshots)

    blur_values = {
        'source_image_home_prop': home_props.get('TMDbHelper.Blur.SourceImage', ''),
        'fallback_home_prop': home_props.get('TMDbHelper.Blur.Fallback', ''),
        'source_image_current_prop': current_props.get('TMDbHelper.Blur.SourceImage', ''),
        'fallback_current_prop': current_props.get('TMDbHelper.Blur.Fallback', ''),
        'source_image_home_infolabel': labels.get('Window(Home).Property(TMDbHelper.Blur.SourceImage)', ''),
        'fallback_home_infolabel': labels.get('Window(Home).Property(TMDbHelper.Blur.Fallback)', ''),
        'source_image_current_infolabel': labels.get('Window.Property(TMDbHelper.Blur.SourceImage)', ''),
        'fallback_current_infolabel': labels.get('Window.Property(TMDbHelper.Blur.Fallback)', ''),
        'listitem_blur_current': labels.get('Window.Property(TMDbHelper.ListItem.BlurImage)', ''),
        'listitem_blur_original_current': labels.get('Window.Property(TMDbHelper.ListItem.BlurImage.Original)', ''),
        'listitem_blur_home': home_props.get('TMDbHelper.ListItem.BlurImage', '') or labels.get('Window(Home).Property(TMDbHelper.ListItem.BlurImage)', ''),
        'listitem_blur_original_home': home_props.get('TMDbHelper.ListItem.BlurImage.Original', '') or labels.get('Window(Home).Property(TMDbHelper.ListItem.BlurImage.Original)', ''),
        'current_blur_home': home_props.get('TMDbHelper.ListItem.Current.BlurImage', '') or labels.get('Window(Home).Property(TMDbHelper.ListItem.Current.BlurImage)', ''),
        'current_blur_original_home': home_props.get('TMDbHelper.ListItem.Current.BlurImage.Original', '') or labels.get('Window(Home).Property(TMDbHelper.ListItem.Current.BlurImage.Original)', ''),
        'simple_background_blur': home_props.get('TMDbHelper.SimpleBackground.BlurImage', '') or labels.get('Window(Home).Property(TMDbHelper.SimpleBackground.BlurImage)', ''),
        'simple_background_blur_original': home_props.get('TMDbHelper.SimpleBackground.BlurImage.Original', '') or labels.get('Window(Home).Property(TMDbHelper.SimpleBackground.BlurImage.Original)', ''),
    }
    blur_match_sources = {
        'source_image': blur_values.get('source_image_home_prop') or blur_values.get('source_image_home_infolabel') or blur_values.get('source_image_current_prop') or blur_values.get('source_image_current_infolabel'),
        'current_blur': blur_values.get('current_blur_home') or blur_values.get('listitem_blur_current') or blur_values.get('listitem_blur_home') or blur_values.get('simple_background_blur'),
        'current_blur_original': blur_values.get('current_blur_original_home') or blur_values.get('listitem_blur_original_current') or blur_values.get('listitem_blur_original_home') or blur_values.get('simple_background_blur_original'),
        'fallback': blur_values.get('fallback_home_prop') or blur_values.get('fallback_home_infolabel') or blur_values.get('fallback_current_prop') or blur_values.get('fallback_current_infolabel'),
    }
    blur_url_matches = {name: _fanart_diag_match_url_to_containers(value, container_snapshots) for name, value in blur_match_sources.items()}

    return {
        'ts': time.time(),
        'window_id': current_window_id,
        'dialog_id': ids.get('current_dialog_id', 0),
        'conditions': {
            'Player.HasMedia': cond_visible('Player.HasMedia'),
            'Player.HasVideo': cond_visible('Player.HasVideo'),
            'Player.Paused': cond_visible('Player.Paused'),
            'Player.Playing': cond_visible('Player.Playing'),
            'Window.IsActive(home)': cond_visible('Window.IsActive(home)'),
            'Window.IsActive(videos)': cond_visible('Window.IsActive(videos)'),
            'Window.IsActive(videoosd)': cond_visible('Window.IsActive(videoosd)'),
            'Window.IsActive(fullscreenvideo)': cond_visible('Window.IsActive(fullscreenvideo)'),
        },
        'native_labels': labels,
        'home_properties': home_props,
        'current_window_properties': current_props,
        'tmdbhelper_blur_values': blur_values,
        'container_probe_order': container_ids,
        'active_container_id': active_container_id,
        'active_container_snapshot': container_snapshots.get(str(active_container_id), {}) if active_container_id else {},
        'container_snapshots': container_snapshots,
        'home_hub_diagnostics': {
            'bridge_properties_by_window': bridge_props_by_window,
            'resolution_candidates': resolution_candidates,
            'blur_match_sources': blur_match_sources,
            'blur_url_matches': blur_url_matches,
            'active_container_media_key': (container_snapshots.get(str(active_container_id), {}) or {}).get('media_key', '') if active_container_id else '',
            'active_container_fanart_candidates': (container_snapshots.get(str(active_container_id), {}) or {}).get('fanart_candidates', []) if active_container_id else [],
        },
        'notes': 'Fanart engine is removed from KPM. This live log observes native AF3/TMDbHelper/Kodi state, TMDbHelper visit-random patch state, and stale KPM props if any still exist.',
    }
def run_fanart_diag_live(duration_seconds: int = 60) -> None:
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_path = os.path.join(addon_data_dir(DIAG_LIVE_DIRNAME), f'{FANART_DIAG_LIVE_PREFIX}-{stamp}.jsonl')
    end_time = time.time() + max(10, int(duration_seconds))
    notify('Fanart live diagnostic started')
    log('[KPM_FANART_DIAG] Fanart live diagnostic started for {0}s -> {1}'.format(duration_seconds, out_path))
    with open(out_path, 'w', encoding='utf-8') as handle:
        sample_no = 0
        while time.time() < end_time:
            if xbmc and xbmc.Monitor().abortRequested():
                break
            sample_no += 1
            data = _fanart_runtime_state()
            data['sample'] = sample_no
            handle.write(json.dumps(data, ensure_ascii=False) + '\n')
            handle.flush()
            if sample_no % 10 == 1:
                labels = data.get('native_labels', {})
                blur = data.get('tmdbhelper_blur_values', {})
                props = data.get('home_properties', {})
                containers = data.get('container_snapshots', {})
                active_id = str(data.get('active_container_id') or '')
                active = data.get('active_container_snapshot') or (containers.get(active_id, {}) if active_id else {})
                active_art = active.get('art') or {}
                blur_out = (
                    blur.get('current_blur_home')
                    or blur.get('listitem_blur_current')
                    or blur.get('listitem_blur_home')
                    or blur.get('simple_background_blur')
                )
                log('[KPM_FANART_DIAG] sample={0} win={1} ctrl={2!r} active_container={3!r} item={4!r} db={5!r}/{6!r} fanart0={7!r} fanart1={8!r} fanart2={9!r} fanart3={10!r} current_blur={11!r} blur_source={12!r} blur_fallback={13!r} media_key={14!r} candidates={15!r}'.format(
                    sample_no,
                    data.get('window_id'),
                    labels.get('System.CurrentControlID') or labels.get('System.CurrentControl'),
                    active_id,
                    active.get('label') or labels.get('ListItem.Label') or labels.get('Container.ListItem.Label'),
                    active.get('dbtype') or labels.get('ListItem.DBTYPE') or labels.get('Container.ListItem.DBTYPE'),
                    active.get('dbid') or labels.get('ListItem.DBID') or labels.get('Container.ListItem.DBID'),
                    active_art.get('fanart') or labels.get('ListItem.Art(fanart)') or labels.get('Container.ListItem.Art(fanart)'),
                    active_art.get('fanart1') or labels.get('ListItem.Art(fanart1)') or labels.get('Container.ListItem.Art(fanart1)'),
                    active_art.get('fanart2') or labels.get('ListItem.Art(fanart2)') or labels.get('Container.ListItem.Art(fanart2)'),
                    active_art.get('fanart3') or labels.get('ListItem.Art(fanart3)') or labels.get('Container.ListItem.Art(fanart3)'),
                    blur_out,
                    blur.get('source_image_home_prop') or blur.get('source_image_home_infolabel') or blur.get('source_image_current_prop') or blur.get('source_image_current_infolabel'),
                    blur.get('fallback_home_prop') or blur.get('fallback_home_infolabel') or blur.get('fallback_current_prop') or blur.get('fallback_current_infolabel'),
                    active.get('media_key', ''),
                    len(active.get('fanart_candidates') or []),
                ))
            if xbmc:
                xbmc.sleep(100)
            else:
                time.sleep(0.1)
    log('[KPM_FANART_DIAG] Fanart live diagnostic finished: {0}'.format(out_path))
    notify('Fanart diagnostic finished. Export Diagnostics ZIP now.')


def start_fanart_live_diagnostics_menu() -> None:
    message = (
        'Start a 60 second fanart live diagnostic now?\n\n'
        'After pressing Yes, go to the library/hub and move focus A → B → A → B. It records native Kodi ListItem/Container fanart, AF3 Home/Hub bridge properties across Home/current windows, LRS/TMDbHelper.WidgetContainer, active-container resolution candidates, fanart0-fanart10, TMDbHelper blur source/fallback/output properties, and any stale KPM fanart props every 100 ms. It does not patch or change fanart.'
    )
    if not yesno(ADDON_NAME, message):
        return
    if xbmc:
        xbmc.executebuiltin(f'RunScript({ADDON_ID},fanart_diag_live,60)')
        ok(ADDON_NAME, 'Fanart live diagnostic started for 60 seconds.\n\nMove focus A → B → A → B, then run Export Diagnostics ZIP.')
    else:
        run_fanart_diag_live(10)


# -----------------------------------------------------------------------------
# UI and batch actions
# -----------------------------------------------------------------------------

def format_results(results: List[Result]) -> str:
    chunks = []
    for item in results:
        text = f'{item.name}: {item.status}'
        if item.detail:
            text += f'\n{item.detail}'
        chunks.append(text)
    return '\n\n'.join(chunks)


def run_single(func: Callable[[], Result]) -> None:
    try:
        result = func()
        notify(f'{result.name}: {result.status}')
        ok(ADDON_NAME, format_results([result]))
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
        ok(f'{ADDON_NAME} - Error', str(exc))


def _apply_patch_smart(patch_id: str, status_func: Callable[[], str], patch_func: Callable[[], Result]) -> Result:
    title = patch_title(patch_id, patch_id)
    try:
        status = status_func()
    except Exception as exc:
        return Result(title, 'Error', 'Status check failed before patching: {0}'.format(exc))
    if status == 'Patched':
        return Result(title, 'Skipped', 'Already current; no file was touched.')
    if status.startswith('Missing target'):
        return Result(title, 'Skipped', status)
    # Not patched, Partial, legacy, or old-version markers are intentionally sent
    # through the patcher. The patcher must update only its marked/anchored block.
    return patch_func()


def _remove_patch_smart(patch_id: str, status_func: Callable[[], str], remove_func: Callable[[], Result]) -> Result:
    title = patch_title(patch_id, patch_id)
    try:
        status = status_func()
    except Exception as exc:
        return Result(title, 'Error', 'Status check failed before removal: {0}'.format(exc))
    if status in ('Not patched', 'Unknown layout') or status.startswith('Missing target'):
        return Result(title, 'Skipped', 'Not installed; no file was touched.')
    return remove_func()


def apply_all() -> None:
    if not yesno(ADDON_NAME, 'Apply recommended patches now?\n\n' + patch_details_summary(True) + '\n\nRule: status is checked first. Current patches are skipped. Old/partial patches are updated only inside their own marked/anchored blocks.'):
        return
    entries = [
        ('upnext_episode_thumb', status_upnext, patch_upnext),
        ('shw_random_movies_tvshows', status_shw, lambda: patch_shw(100)),
        ('vfs_pause_ratings', status_vfs_pause_ratings, patch_vfs_pause_ratings),
        ('reliable_studio_logos', status_reliable_studio_logos, patch_reliable_studio_logos),
    ]
    results: List[Result] = []
    for patch_id, status_func, patch_func in entries:
        try:
            results.append(_apply_patch_smart(patch_id, status_func, patch_func))
        except Exception as exc:
            log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
            results.append(Result(patch_title(patch_id, patch_id), 'Error', str(exc)))
    notify('Apply recommended finished')
    ok(ADDON_NAME, format_results(results))


def remove_all() -> None:
    if not yesno(ADDON_NAME, 'Remove recommended patches now?\n\n' + patch_details_summary(True) + '\n\nRule: status is checked first. Missing/not-installed patches are skipped. Installed patches are removed by marker/block restore only.'):
        return
    entries = [
        ('upnext_episode_thumb', status_upnext, remove_upnext),
        ('shw_random_movies_tvshows', status_shw, remove_shw),
        ('vfs_pause_ratings', status_vfs_pause_ratings, remove_vfs_pause_ratings),
        ('reliable_studio_logos', status_reliable_studio_logos, remove_reliable_studio_logos),
    ]
    results: List[Result] = []
    for patch_id, status_func, remove_func in entries:
        try:
            results.append(_remove_patch_smart(patch_id, status_func, remove_func))
        except Exception as exc:
            log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
            results.append(Result(patch_title(patch_id, patch_id), 'Error', str(exc)))
    notify('Remove recommended finished')
    ok(ADDON_NAME, format_results(results))


def patch_status_summary() -> str:
    lines = [f'Addon: {ADDON_NAME} v{VERSION}', '']
    for patch_id, status_name, _apply_name, _remove_name in PATCH_ORDER:
        data = patch_detail(patch_id)
        title = data.get('title', patch_id)
        status_func = globals().get(status_name)
        try:
            status = status_func() if status_func else 'Unknown'
        except Exception as exc:
            status = f'Error ({exc})'
        lines.append(f'{title}: {status}')
    try:
        lines.append(f"{patch_title('tmdb_focus_random_v12', 'TMDbHelper Visit Random Fanart')}: {status_tmdb_focus_random_v12()}")
    except Exception as exc:
        lines.append(f"TMDbHelper Visit Random Fanart: Error ({exc})")
    return '\n'.join(lines)


def view_status() -> None:
    ok(f'{ADDON_NAME} - Patch Status', patch_status_summary())


def patch_message(patch_id: str, status: str) -> str:
    data = patch_detail(patch_id)
    return (
        f"Status in Kodi: {status}\n\n"
        f"Function:\n{data.get('function', '-')}\n\n"
        f"Target:\n{data.get('target', '-')}\n\n"
        f"Reference:\n{data.get('reference', '-')}\n\n"
        'Patch style:\nInject/remove selected blocks only. No full-file overwrite.'
    )


def choose_patch_action(patch_id: str, status_func: Callable[[], str]) -> str:
    data = patch_detail(patch_id)
    title = data.get('title', patch_id)
    try:
        status = status_func()
    except Exception as exc:
        status = f'Error ({exc})'
    message = patch_message(patch_id, status)

    dialog = xbmcgui.Dialog()
    # Kodi's yesnocustom labels are custom/no/yes. Use Patch as the YES button
    # and request YES as the default focused button on Kodi versions that support it.
    # Return values: -1=cancelled, 0=no, 1=yes, 2=custom.
    if hasattr(dialog, 'yesnocustom'):
        default_yes = getattr(xbmcgui, 'DLG_YESNO_YES_BTN', None)
        try:
            if default_yes is not None:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch', defaultbutton=default_yes)
            else:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
        except TypeError:
            try:
                if default_yes is not None:
                    result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch', 0, default_yes)
                else:
                    result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
            except TypeError:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
        if result == 1:
            return 'patch'
        if result == 0:
            return 'remove'
        return 'cancel'

    idx = dialog.select(title, [
        'Patch',
        'Remove',
        'Cancel',
    ], preselect=0)
    if idx == 0:
        return 'patch'
    if idx == 1:
        return 'remove'
    return 'cancel'


def run_patch_entry(patch_id: str, status_func: Callable[[], str], patch_func: Callable[[], Result], remove_func: Callable[[], Result]) -> None:
    action = choose_patch_action(patch_id, status_func)
    if action == 'patch':
        run_single(patch_func)
    elif action == 'remove':
        run_single(remove_func)


def run_console() -> None:
    print(f'{ADDON_NAME} v{VERSION}')
    print('This add-on is intended to run inside Kodi.')
    print('Status:')
    print('  Episode Thumb Up Next:', status_upnext())
    print('  Movies + Shows Screensaver:', status_shw())
    print('  TMDbHelper Visit Random Fanart:', status_tmdb_focus_random_v12())
    print('  Pause Shows Full OSD:', status_vfs_pause_ratings())
    print('  Reliable Studio Logos:', status_reliable_studio_logos())


def advanced_patches_menu(patch_entries) -> None:
    while True:
        items = [patch_detail(patch_id).get('title', patch_id) for patch_id, *_ in patch_entries]
        index = xbmcgui.Dialog().select(f'{ADDON_NAME} - Advanced Patches', items)
        if index < 0:
            return
        patch_id, status_func, patch_func, remove_func = patch_entries[index]
        run_patch_entry(patch_id, status_func, patch_func, remove_func)


def settings_menu() -> None:
    save_kpm_settings({'studio_logo_count': 1})
    if os.path.exists(state_file('reliable_studio_logos')):
        _start_resume_close_service()
    ok(ADDON_NAME, 'Reliable Studio Logos is now fixed to one best valid logo.\n\nKPM.StudioLogo.1 is the only render source. There is no fallback to AF3 raw studio paths, so combined labels like A / B / C.png cannot be used by the footer.')


def diagnostics_menu() -> None:
    while True:
        items = [
            'Start Ratings Live Diagnostic',
            'Start Fanart Live Diagnostic',
            'Export Diagnostics ZIP',
            'Export Studio Logo Diagnostics',
        ]
        index = xbmcgui.Dialog().select(f'{ADDON_NAME} - Diagnostics', items)
        if index < 0:
            return
        if index == 0:
            start_live_diagnostics_menu()
        elif index == 1:
            start_fanart_live_diagnostics_menu()
        elif index == 2:
            run_single(export_diagnostics)
        elif index == 3:
            run_single(export_studio_logo_diagnostics)


def run() -> None:
    if not xbmcgui:
        run_console()
        return
    patch_entries = [
        ('upnext_episode_thumb', status_upnext, patch_upnext, remove_upnext),
        ('shw_random_movies_tvshows', status_shw, lambda: patch_shw(100), remove_shw),
        ('tmdb_focus_random_v12', status_tmdb_focus_random_v12, patch_tmdb_focus_random_v12, remove_tmdb_focus_random_v12),
        ('vfs_pause_ratings', status_vfs_pause_ratings, patch_vfs_pause_ratings, remove_vfs_pause_ratings),
        ('reliable_studio_logos', status_reliable_studio_logos, patch_reliable_studio_logos, remove_reliable_studio_logos),
    ]
    while True:
        items = [
            'Apply Recommended Patch',
            'Remove Recommended Patch',
            'Advanced Patches',
            'Patch Status',
            'Diagnostics',
            'Clear Add-on Icon Cache',
            'Settings',
            'Exit',
        ]
        index = xbmcgui.Dialog().select(ADDON_NAME, items)
        if index < 0 or index == len(items) - 1:
            return
        if index == 0:
            apply_all()
        elif index == 1:
            remove_all()
        elif index == 2:
            advanced_patches_menu(patch_entries)
        elif index == 3:
            view_status()
        elif index == 4:
            diagnostics_menu()
        elif index == 5:
            clear_addon_icon_cache_menu()
        elif index == 6:
            settings_menu()

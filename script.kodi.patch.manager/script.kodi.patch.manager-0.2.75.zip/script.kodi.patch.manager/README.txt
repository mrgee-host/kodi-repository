Kodi Patch Manager 0.2.75

Runtime patch manager for the MrGee Kodi family.

Combined Expanded episodes
- AF3 native Object_StarRating.
- IMDb rating with TMDb fallback.
- Four-digit ListItem.Year.
- Episode title right=400 with no scrolling.
- Equal rendered spacing target across: star -> rating -> bullet -> year -> native indicator -> duration.
- Native Object_Indicator_List and duration remain untouched and act as the 21 px visual spacing reference.
- Geometry: star centerright=319; rating right=241 width=48 align=left; bullet right=220 width=24; year right=149 width=68.

All AF3 changes are partial runtime patches. No complete skin XML file is bundled or replaced.


0.2.46: KPM lower rating rows now receive the exact owner-container loading state from AF3 media, hub, spotlight, and combined views. This prevents stale half-rows during ReloadSkin/widget refresh without hiding committed rows for DialogBusy.


0.2.68: Restores the native AF3 info line exactly as in 0.2.66. The persistent rating row remains unchanged. Only the previous movie tagline/plotline and plot are kept during the short movie-to-set readiness gap.


0.2.69: Keeps the previous movie AF3 information line in native format during the short movie-to-set readiness gap. The native line remains unchanged outside that gap; clearlogo, title, plot, rating row, spacing, and layout are not modified.


0.2.73: Rebuilt directly from 0.2.69. Movie-to-set rating, information line, tagline, and plot keep-last behavior is unchanged. Hub behavior is unchanged. Only the collection information-icon pill width changes from the inherited 48 px default to 60 px, matching the movie pill.


0.2.74: Keeps the complete R68 visual patch unchanged. In AF3 Custom Hubs, KPM follows the active TMDbHelper.WidgetContainer owner instead of scanning hidden Spotlight and widget containers every 50 ms. The selected owner also receives an owner-specific IsUpdating hold. MWH itself is not modified.
0.2.75: Keeps 0.2.74 runtime owner scoping. UpperHold PlotlineLabel no longer appears in XML include conditions; both plot layouts remain structurally loaded and runtime visibility selects the 80 px + label or 120 px plot form. This prevents Custom Hub KEEP_IN_MEMORY reloads caused by UpperHold empty/non-empty state changes while preserving movie-to-set keep-last behavior.

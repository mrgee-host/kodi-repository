Kodi Patch Manager v0.1.77
- Diagnostics/status only update for LRS + Steam Library coordination.
- Adds focused Export LRS / Steam Library Diagnostics menu item.
- Captures HomeHub DisplaySlot1-10, EndsAt fields, strict-current ListItem/container game bridge properties, Steam Library metadata/settings/DB digest, AF3 XML context files, and filtered Kodi log keys.
- Does not inject/remove Steam Library lower meta rows.
- Does not touch LRS/Steam Library rendering XML or logic.
- Keeps v0.1.76 game studio crash fix behavior.

Kodi Patch Manager v0.1.76
- Reliable Studio Logos now also resolves Steam game developer/publisher logos via resource.images.gamestudios.grayscale when that image resource is installed.
- Movie/TV studio logos still use resource.images.studios.coloured. No fanart/random bridge is added.

Kodi Patch Manager v0.1.71

Built from v0.1.67 clean-no-fanart base. Unified runtime/diagnostics storage added. No v0.1.69 screensaver-games plugin-source changes are included.

Included modules:
- Episode Thumb Up Next
- Movies + Shows Screensaver
- Pause Shows Full OSD
- Reliable Studio Logos

Removed from this build:
- Background random/source bridge module
- Related runtime engine in service.py
- Related patch menu entries
- Related diagnostic menu entries
- Related bridge/status/state handling
- One-time cleanup/restore routines that touch AF3/TMDbHelper files

Install notes:
1. Install this ZIP over the previous KPM version.
2. Restart Kodi.
3. Because this build does not run cleanup routines, it will not alter restored AF3/TMDbHelper files.


Unified runtime update in v0.1.71:
- Patch state now uses runtime/state/.
- Snapshots and diagnostics staging use runtime/exports/.
- Live diagnostic JSONL files use runtime/logs/diagnostics_live/.
- Diagnostics ZIP files are written to the addon_data root.
- Older KPM diagnostics ZIP files in the root are automatically removed before a new one is written.
- Patch Status opens in a text viewer for easier reading.


Shared icon policy:
- KPM is the only canonical shared icon path.
- Uses only the fixed icon filenames supplied in ikon fix.zip.
- No local fallback icons in companion addons.


0.1.76
- Fix Reliable Studio Logos game pack crash: restore missing _is_broken_studio_texture helper and guard movie/game index builds so one failed resource cannot stop the KPM service.

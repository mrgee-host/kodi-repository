Kodi Patch Manager 0.1.99
================================

New KPM Settings options:
- Screenshot folder: opens a manual folder picker.
- The selected folder is applied to Kodi's global screenshot setting through JSON-RPC and saved in KPM settings.json for diagnostics.
- Take test screenshot: calls Kodi TakeScreenshot so the selected destination can be verified immediately.
- Patch Status now reports the active screenshot folder.

No AF3 visual patch behavior from 0.1.98 was removed or changed.

# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import time
import traceback

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # pragma: no cover outside Kodi
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

ADDON_ID = 'script.kodi.patch.manager'
ADDON_NAME = 'Kodi Patch Manager'
ACTIVE_PROP = 'KPM.ResumeCloseService.Active'
ARMED_PROP = 'KPM.ResumeCloseService.Armed'
ARMED_DIALOG_PROP = 'KPM.ResumeCloseService.ArmedDialogId'
LOG_PREFIX = '[Kodi Patch Manager ResumeClose] '

# Kodi commonly reports no modal dialog as 9999. On the user's AF3 build,
# normal video OSD/seekbar states have appeared as 12901/10142 in diagnostics.
# These are treated as KPM-controlled OSD layers, not foreign dialogs.
NO_DIALOG_ID = 9999
KNOWN_OSD_DIALOG_IDS = {9999, 12901, 10142}


def translate(path: str) -> str:
    if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if xbmc and hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return path


def log(message: str, level=None) -> None:
    if xbmc:
        xbmc.log(LOG_PREFIX + message, level or xbmc.LOGINFO)
    else:
        print(LOG_PREFIX + message)


def cond(expression: str) -> bool:
    try:
        return bool(xbmc.getCondVisibility(expression)) if xbmc else False
    except Exception:
        return False


def home_prop(name: str) -> str:
    try:
        return xbmcgui.Window(10000).getProperty(name) if xbmcgui else ''
    except Exception:
        return ''


def set_home_prop(name: str, value: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).setProperty(name, value)
    except Exception:
        pass


def clear_home_prop(name: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).clearProperty(name)
    except Exception:
        pass


def current_window_id() -> int:
    try:
        return int(xbmcgui.getCurrentWindowId()) if xbmcgui else -1
    except Exception:
        return -1


def current_dialog_id() -> int:
    try:
        return int(xbmcgui.getCurrentWindowDialogId()) if xbmcgui else NO_DIALOG_ID
    except Exception:
        return NO_DIALOG_ID


def state_file() -> str:
    return os.path.join(translate(f'special://profile/addon_data/{ADDON_ID}'), 'state', 'vfs_pause_ratings.json')


def patch_enabled() -> bool:
    path = state_file()
    if not os.path.exists(path):
        return False
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as handle:
            data = json.load(handle)
        return bool(data.get('auto_videoosd') and data.get('pause_stay_until_resume'))
    except Exception:
        return True


def is_foreign_dialog(active_dialog_id: int, armed_dialog_id: int) -> bool:
    """Return True when another modal/add-on/settings dialog is in front.

    The full OSD is allowed to remain visible behind that dialog, but this
    service must not close, Back out of, or force-focus anything while the
    foreign dialog is active. This preserves normal behavior for subtitle,
    audio, video settings, bookmarks, dialog-select, context menu, and add-on
    dialogs.
    """
    if active_dialog_id in KNOWN_OSD_DIALOG_IDS:
        return False
    if armed_dialog_id > 0 and active_dialog_id == armed_dialog_id:
        return False
    return active_dialog_id != NO_DIALOG_ID


def close_video_osd_safely() -> None:
    """Hide the KPM-opened VideoOSD without navigating back to the library.

    Never use Action(Back) here. It can pop the fullscreen video window and
    return to the library while playback continues in the background.
    """
    try:
        xbmc.executebuiltin('CancelAlarm(osd_timeout,true)')
        xbmc.executebuiltin('Dialog.Close(videoosd,true)')
        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
    except Exception:
        log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def main() -> None:
    if not xbmc:
        return

    if home_prop(ACTIVE_PROP) == 'true':
        log('already running; exiting duplicate instance')
        return

    set_home_prop(ACTIVE_PROP, 'true')
    monitor = xbmc.Monitor()
    armed = home_prop(ARMED_PROP) == 'true'
    try:
        armed_dialog_id = int(home_prop(ARMED_DIALOG_PROP) or '0')
    except Exception:
        armed_dialog_id = 0

    log('started')
    try:
        while not monitor.abortRequested():
            if not patch_enabled():
                armed = False
                armed_dialog_id = 0
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                monitor.waitForAbort(1.0)
                continue

            paused = cond('Player.Paused')
            playing = cond('Player.Playing')
            has_video = cond('Player.HasVideo') or cond('Player.HasMedia')
            videoosd = cond('Window.IsActive(videoosd)') or cond('Window.IsVisible(videoosd)')
            dialog_id = current_dialog_id()

            if has_video and paused and videoosd:
                if not armed:
                    armed_dialog_id = dialog_id
                    set_home_prop(ARMED_DIALOG_PROP, str(armed_dialog_id))
                    log(f'armed while paused; dialog_id={armed_dialog_id}, window_id={current_window_id()}')
                armed = True
                set_home_prop(ARMED_PROP, 'true')

            if armed and has_video and playing and videoosd:
                if is_foreign_dialog(dialog_id, armed_dialog_id):
                    # Keep VideoOSD in the background and let the front dialog own focus.
                    # We will close VideoOSD after that dialog is gone.
                    monitor.waitForAbort(0.25)
                    continue
                log(f'pause->play detected; closing VideoOSD safely; dialog_id={dialog_id}, armed_dialog_id={armed_dialog_id}')
                close_video_osd_safely()
                armed = False
                armed_dialog_id = 0
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                monitor.waitForAbort(0.4)
                continue

            if not has_video or (not paused and not playing):
                armed = False
                armed_dialog_id = 0
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)

            monitor.waitForAbort(0.2)
    finally:
        clear_home_prop(ACTIVE_PROP)
        clear_home_prop(ARMED_PROP)
        clear_home_prop(ARMED_DIALOG_PROP)
        log('stopped')


if __name__ == '__main__':
    main()

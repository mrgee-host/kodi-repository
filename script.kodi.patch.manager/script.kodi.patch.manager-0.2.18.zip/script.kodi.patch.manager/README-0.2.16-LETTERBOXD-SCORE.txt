KPM 0.2.16 - Letterboxd MDBList score
=======================================

- Displays Letterboxd as a whole 0-100 score.
- Example LRS/MDBList value 3.1, score 62 is shown as 62.
- No percent sign is appended.
- Converts legacy LRS 1.5.51 values (0-5) with x20 as a compatibility fallback.
- Keeps the supplied letterboxd.png icon.

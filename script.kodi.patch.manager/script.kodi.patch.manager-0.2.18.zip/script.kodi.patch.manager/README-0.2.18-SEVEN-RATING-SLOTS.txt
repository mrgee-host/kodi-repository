Kodi Patch Manager 0.2.18

- Carries LibraryRatings RatingSlot7 through Home, Hub, library, games, player/OSD, screensaver and diagnostics.
- Renders Slot 7 with the same spacing and icon rules as Slots 1-6.
- Letterboxd icon remains resources/media/shared-icons/letterboxd.png.

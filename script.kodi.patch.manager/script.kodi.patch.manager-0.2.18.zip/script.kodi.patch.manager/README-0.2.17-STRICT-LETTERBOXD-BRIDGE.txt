KPM 0.2.17 - Strict Letterboxd bridge

- Accepts only a whole-number Letterboxd label from 1 to 100.
- Does not convert 0-5 values with x20.
- Does not pass through invalid text.
- Does not read Letterboxd directly from the LRS SQLite database.
- Letterboxd is displayed only from the LRS DisplaySlot bridge.

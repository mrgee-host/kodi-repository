KPM 0.2.15 - Letterboxd rating display
========================================

- Adds resources/media/shared-icons/letterboxd.png.
- Accepts LRS DisplaySlot source=letterboxd.
- Recovers letterboxd.png when an older bridge omits IconFile.
- Direct LRS SQLite fallback reads the letterboxd column and formats it as one decimal.
- Home/Hub/library/screensaver rows keep the same layout and spacing.

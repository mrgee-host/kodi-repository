Kodi Patch Manager 0.2.53

Runtime patch manager for the MrGee Kodi family.

Collection handoff
- Keeps Arctic Fuse 3 native layout geometry.
- Uses committed info, tagline, plot, and complete rating-row snapshots while a collection target is pending.
- Requires LibraryRatings.Collection Visible, Ready, and exact ItemKey identity before exposing the target collection panel.
- Starts the service only after every handoff override is defined, preventing the blank collection panel bug from 0.2.52.

All AF3 changes are partial runtime patches. No complete skin XML file is bundled or replaced.
No database, schema, profile, state, settings, or historical-data migration is included.

# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import hashlib
import html
import os
import re
import shutil
import sqlite3
import time
import traceback
import zipfile
import xml.etree.ElementTree as ET
import urllib.parse
from dataclasses import dataclass
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP
from typing import Callable, Dict, List, Optional, Tuple
from urllib.parse import unquote, quote

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # Allows syntax checks outside Kodi.
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

ADDON_ID = 'script.kodi.patch.manager'
ADDON_NAME = 'Kodi Patch Manager'
VERSION = '0.2.50'

# Markers: every injected/replaced block has an obvious marker.
UPNEXT_MARKER = '<!-- KPM-UPNEXT-EPISODE-THUMB -->'
SHW_METHOD_START = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-METHOD-START'
SHW_METHOD_END = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-METHOD-END'
SHW_ENTRY_MARKER = '# KPM-SHW-RANDOM-MOVIES-TVSHOWS-LISTING'
SHW_XML_MARKER = '<!-- KPM-SHW-RANDOM-MOVIES-TVSHOWS-XML -->'
DEFAULT_SCREENSAVER_WIDGET_PATH = 'plugin://plugin.video.mediahub.widget/?mode=screensaver_mix&limit=0&random=true'
DIALOG_SEEKBAR_AUTO_OSD_MARKER = '<!-- KPM-DIALOG-SEEKBAR-AUTO-VIDEOOSD -->'
VIDEOOSD_FAST_CLOSE_START = '<!-- KPM-VIDEOOSD-FAST-CLOSE-RESUME-START -->'
VIDEOOSD_FAST_CLOSE_END = '<!-- KPM-VIDEOOSD-FAST-CLOSE-RESUME-END -->'
OSD_PLOT_WIDTH_START = '<!-- KPM-OSD-PLOT-WIDTH-START -->'
OSD_PLOT_WIDTH_END = '<!-- KPM-OSD-PLOT-WIDTH-END -->'
DIALOG_SEEKBAR_CLEARART_START = '<!-- KPM-DIALOG-SEEKBAR-CLEARART-BEHIND-PROGRESS-START -->'
DIALOG_SEEKBAR_CLEARART_END = '<!-- KPM-DIALOG-SEEKBAR-CLEARART-BEHIND-PROGRESS-END -->'
OSD_RANGE_MARKERS_START = '<!-- KPM-OSD-RANGE-MARKERS-HIDDEN-START -->'
OSD_RANGE_MARKERS_END = '<!-- KPM-OSD-RANGE-MARKERS-HIDDEN-END -->'
ACTION_OSD_PAUSE_STAY_START = '<!-- KPM-ACTION-OSD-PAUSE-STAY-START -->'
ACTION_OSD_PAUSE_STAY_END = '<!-- KPM-ACTION-OSD-PAUSE-STAY-END -->'
STUDIO_IMAGE_VAR_START = '<!-- KPM-STUDIO-LOGOS-IMAGE-VAR-START -->'
STUDIO_IMAGE_VAR_END = '<!-- KPM-STUDIO-LOGOS-IMAGE-VAR-END -->'
STUDIO_FURNITURE_START = '<!-- KPM-STUDIO-LOGOS-FURNITURE-START -->'
STUDIO_FURNITURE_END = '<!-- KPM-STUDIO-LOGOS-FURNITURE-END -->'
STUDIO_FURNITURE_CURRENT_MARKER = '<!-- KPM-STUDIO-LOGOS-FURNITURE-CURRENT-SINGLE -->'
BROKEN_STUDIO_TEXTURE_NAMES = ('centropolis entertainment.png', 'dune entertainment.png', 'gk films.png', 'thunder road.png')


PATCH_DETAILS = {
    'af3_unified_integration': {
        'title': 'AF3 Unified Integration',
        'apply_label': 'Apply AF3 Unified Integration',
        'remove_label': 'Remove AF3 Unified Integration',
        'summary': 'KPM-owned AF3 visual integration: stable rating row, Steam game top meta and plot, Expanded episode rating parity, startup-weather fallback, and strict Arctic Mirage parity.',
        'function': 'Patches the active AF3 XML files at runtime. Includes_Info.xml reads KPM.RatingRow.*, owns the lower rating row, restores the Steam game plot, and reads collection tagline/plot from LibraryRatings.Collection properties rather than native ListItem.Plot. Includes_Views.xml, Includes_Hubs.xml, and Includes_Views_Combined.xml pass the exact owner-container loading state so stale rating rows are hidden during ReloadSkin and widget refresh. Includes_Layouts.xml adds the native AF3 Object_StarRating with IMDb-to-TMDb fallback and episode year to List Expanded and Combined Expanded. Includes_Images.xml uses a custom-only Image_StartUp variable that reads KPM.AF3StartupFallbackPath first and direct local-clock custom paths before the service is ready. Arctic Mirage keeps the current six-panel layout and 1 ms metadata fade-out. No complete AF3 XML file is bundled or replaced.',
        'target': 'skin.arctic.fuse.3/1080i/Includes_Info.xml + Includes_Views.xml + Includes_Hubs.xml + Includes_Views_Combined.xml + Includes_Layouts.xml + Includes_Images.xml + Includes_Background.xml + screensaver-arctic-mirage.xml + Font.xml (Cinema Pre-roll fonts)',
        'reference': 'Clean architecture integration owner. No calls to LRS/Steam patchers.',
    },
    'af3_poster_ratio_2_3': {
        'title': 'AF3 Poster Ratio 2:3',
        'apply_label': 'Patch AF3 Poster Ratio 2:3',
        'remove_label': 'Restore AF3 Poster Ratio',
        'summary': 'Make the AF3 poster box exactly 2:3 by reducing width while preserving the current horizontal gap.',
        'function': 'Reads the active AF3 poster height, poster width, and layout width from Includes_Constants.xml. It calculates poster width as height × 2 ÷ 3, then changes layout width by the same amount so the existing horizontal gap is preserved. Poster and layout heights are not changed.',
        'target': 'skin.arctic.fuse.3/1080i/Includes_Constants.xml -> view_poster_item_w and view_poster_itemlayout_w, including their negative constants',
        'reference': 'Dynamic partial XML edit. On AF3 3.2.13 this changes 217.14×310 to 206.67×310 and 257.14×350 to 246.67×350, preserving the 40-unit gap.',
    },
    'upnext_episode_thumb': {
        'title': 'Episode Thumb Up Next',
        'apply_label': 'Patch Episode Thumb Up Next',
        'remove_label': 'Remove Episode Thumb Up Next',
        'summary': 'Use next episode thumbnail first.',
        'function': 'Makes the Up Next popup show the next episode thumbnail first, then falls back to landscape.',
        'target': 'skin.arctic.fuse.3/1080i/Includes_Images.xml -> variable Image_UpNext',
        'reference': 'Native Kodi patcher. No bundled standalone patch file.',
    },
    'vfs_pause_ratings': {
        'title': 'Pause Shows Full OSD',
        'apply_label': 'Patch Pause Shows Full OSD',
        'remove_label': 'Remove Pause Shows Full OSD',
        'summary': 'Open full VideoOSD on pause through a dialog-safe service, keep it behind dialogs, hide chapter ticks, shorten OSD plot, close safely after resume.',
        'function': 'Marks DialogSeekBar.xml as KPM-managed and uses service.py so a normal pause opens videoosd quickly on normal pause with a longer playback-start guard, matching the result of pressing M; normal pause opens fast while playback-start auto subtitle dialogs are still guarded. It draws a native/TMDbHelper clearart panel behind the progress line in DialogSeekBar, hides chapter/cutlist marker ticks, shortens the OSD plot width in Includes_OSD.xml, prevents OSD timeout while paused, patches the main play button, and starts the KPM lightweight resume monitor. The monitor no longer uses Action(Back); it keeps VideoOSD behind foreign dialogs and only closes VideoOSD safely after resume when no other dialog has focus.',
        'target': 'skin.arctic.fuse.3/1080i/DialogSeekBar.xml + VideoOSD.xml + Includes_OSD.xml + Includes_Actions.xml; service.py monitors pause→play only while this patch is enabled and does not steal focus from other dialogs',
        'reference': 'Native Kodi patcher. Pause opens VideoOSD by Kodi window action. A lightweight KPM service only closes VideoOSD after resume and avoids Action(Back). Clearart may use Kodi native artwork first and TMDbHelper.Player.ClearArt as fallback.',
    },
    'reliable_studio_logos': {
        'title': 'Reliable Studio Logos',
        'apply_label': 'Patch Reliable Studio Logos',
        'remove_label': 'Remove Reliable Studio Logos',
        'summary': 'Show one reliable valid studio logo with provider-aware KPM XBT resource fallbacks for movie/TV and game developer/publisher credits.',
        'function': 'Replaces AF3 raw studio texture lookup with one KPM-resolved logo. For each movie/TV candidate it checks resource.images.studios.coloured first and then the KPM XBTF2 studio resource. For each game developer/publisher candidate it checks the KPM XBTF2 game resource first and then resource.images.gamestudios.grayscale. Specific/regional names are resolved before generic fallbacks. Metadata is not changed.',
        'target': 'skin.arctic.fuse.3/1080i -> Includes_Images.xml variable Image_CombinedStudio and Includes_Furniture.xml include Furniture_Studio; service.py fills Window(Home).Property(KPM.StudioLogo.1)',
        'reference': 'Single-logo mode only; no raw AF3 fallback. Dependency resource.images.kpm.studiologos 1.0.3 contains 374 movie/series studio logos and 131 game developer/publisher logos on AF3-sized 161×109 centered canvases in one XBTF2 archive.',
    },
    'shw_random_movies_tvshows': {
        'title': 'Movies + Shows Screensaver',
        'apply_label': 'Patch Movies + Shows Screensaver',
        'remove_label': 'Remove Movies + Shows Screensaver',
        'summary': 'Selectable AF3 screensaver widget source with MediaHub mixed content as the default.',
        'function': 'Keeps the Skin Helper random movies + TV shows provider available, but lets KPM Settings choose a library, playlist, source, or add-on folder through the native Skin Shortcuts selector. The selected content path is written only to Defs_ScreensaverWidget.',
        'target': 'skin.arctic.fuse.3/1080i/Includes_Defaults.xml -> variable Defs_ScreensaverWidget; script.skin.helper.widgets remains supported as a current provider',
        'reference': 'Native Skin Shortcuts Just Select shortcut picker using skinList, plus manual path entry and MediaHub default restore.',
    },
}


def patch_detail(patch_id: str) -> dict:
    return PATCH_DETAILS.get(patch_id, {})


def patch_title(patch_id: str, fallback: str) -> str:
    return patch_detail(patch_id).get('title', fallback)


def menu_label(patch_id: str, mode: str) -> str:
    data = patch_detail(patch_id)
    return data.get('apply_label' if mode == 'apply' else 'remove_label', data.get('title', patch_id))


PATCH_ORDER = (
    ('af3_unified_integration', 'status_af3_unified_integration', 'apply_af3_unified_integration', 'remove_af3_unified_integration'),
    ('af3_poster_ratio_2_3', 'status_af3_poster_ratio_2_3', 'patch_af3_poster_ratio_2_3', 'remove_af3_poster_ratio_2_3'),
    ('upnext_episode_thumb', 'status_upnext', 'patch_upnext', 'remove_upnext'),
    ('shw_random_movies_tvshows', 'status_shw', 'patch_shw', 'remove_shw'),
    ('vfs_pause_ratings', 'status_vfs_pause_ratings', 'patch_vfs_pause_ratings', 'remove_vfs_pause_ratings'),
    ('reliable_studio_logos', 'status_reliable_studio_logos', 'patch_reliable_studio_logos', 'remove_reliable_studio_logos'),
)



def patch_details_summary(include_status: bool = False) -> str:
    chunks = []
    for patch_id, status_name, _apply_name, _remove_name in PATCH_ORDER:
        data = patch_detail(patch_id)
        heading = data.get('title', patch_id)
        if include_status:
            status_func = globals().get(status_name)
            if status_func:
                try:
                    heading += f': {status_func()}'
                except Exception as exc:
                    heading += f': Error ({exc})'
        chunks.append(
            f"{heading}\n"
            f"Function: {data.get('function', '-')}\n"
            f"Target: {data.get('target', '-')}\n"
            f"Reference: {data.get('reference', '-')}"
        )
    return '\n\n'.join(chunks)


def log(message: str, level=None) -> None:
    if xbmc:
        xbmc.log(f'[{ADDON_NAME}] {message}', level or xbmc.LOGINFO)
    else:
        print(f'[{ADDON_NAME}] {message}')


def _family_compact_result_0222(message, limit=58):
    text = ' '.join(str(message or '').split()).upper().rstrip()
    if len(text) <= int(limit):
        return text
    parts = text.replace(" • ", " - ").split(" - ")
    protected = ("ERROR", "FAILED", "UPDATED", "ARTWORK", "ITEM", "CACHED", "MOVED", "SCRAPED", "N/A")
    if len(parts) > 1 and any(token in " - ".join(parts[1:]) for token in protected):
        suffix = " - " + " - ".join(parts[1:])
        budget = max(4, int(limit) - len(suffix))
        action = parts[0]
        if len(action) > budget:
            action = action[:max(1, budget - 3)].rstrip() + "..."
        return (action + suffix)[:int(limit)].rstrip()
    raw = text[:max(1, int(limit) - 3)].rstrip()
    return (raw.rsplit(" ", 1)[0] if " " in raw else raw) + "..."


def notify(message: str, icon=None) -> None:
    text = _family_compact_result_0222(message, 58)
    if xbmcgui:
        xbmcgui.Dialog().notification(ADDON_NAME, text, icon or xbmcgui.NOTIFICATION_INFO, 5000)
    else:
        print(text)


def ok(title: str, message: str) -> None:
    if xbmcgui:
        xbmcgui.Dialog().ok(title, message)
    else:
        print('\n' + title + '\n' + message)


def textviewer(title: str, message: str) -> None:
    text = str(message or '').strip()
    if xbmcgui and len(text) <= 520 and len(text.splitlines()) <= 7:
        xbmcgui.Dialog().ok(title, text or 'NO DETAILS')
    elif xbmcgui and hasattr(xbmcgui.Dialog(), 'textviewer'):
        xbmcgui.Dialog().textviewer(title, text)
    else:
        ok(title, text)


def yesno(title: str, message: str) -> bool:
    if xbmcgui:
        return xbmcgui.Dialog().yesno(title, message)
    return True


def translate(path: str) -> str:
    if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if xbmc and hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return (path
            .replace('special://home/', os.environ.get('KODI_HOME', 'E:/Kodi/portable_data/'))
            .replace('special://profile/', os.environ.get('KODI_PROFILE', 'E:/Kodi/portable_data/userdata/')))


def addon_data_dir(*parts: str) -> str:
    base = translate(f'special://profile/addon_data/{ADDON_ID}')
    path = os.path.join(base, *parts)
    os.makedirs(path, exist_ok=True)
    return path


def norm(path: str) -> str:
    return os.path.normpath(path)


def read_text(path: str) -> str:
    if not os.path.exists(path):
        raise FileNotFoundError(f'File not found: {path}')
    with open(path, 'r', encoding='utf-8-sig', errors='replace', newline='') as handle:
        return handle.read()


def write_text(path: str, text: str) -> None:
    """Atomically replace a targeted text file in its existing directory."""
    parent = os.path.dirname(path)
    if parent:
        os.makedirs(parent, exist_ok=True)
    temp = '{0}.tmp.{1}.{2}'.format(path, os.getpid(), int(time.time() * 1000000))
    mode = None
    try:
        if os.path.exists(path):
            mode = os.stat(path).st_mode
        with open(temp, 'w', encoding='utf-8', errors='replace', newline='') as handle:
            handle.write(text)
            handle.flush()
            os.fsync(handle.fileno())
        if mode is not None:
            try:
                os.chmod(temp, mode)
            except Exception:
                pass
        os.replace(temp, path)
    finally:
        if os.path.exists(temp):
            try:
                os.remove(temp)
            except Exception:
                pass


def newline_of(text: str) -> str:
    return '\r\n' if '\r\n' in text else '\n'


def safe_name(path: str) -> str:
    drive, tail = os.path.splitdrive(path)
    value = (drive.replace(':', '') + tail).replace('\\', '__').replace('/', '__').strip('_')
    return value or 'file'


def save_json(path: str, data: dict) -> None:
    write_text(path, json.dumps(data, indent=2, ensure_ascii=False))


def load_json(path: str) -> dict:
    with open(path, 'r', encoding='utf-8') as handle:
        return json.load(handle)


def state_file(patch_id: str) -> str:
    return os.path.join(addon_data_dir('runtime', 'state'), f'{patch_id}.json')


def save_state(patch_id: str, data: dict) -> None:
    data.setdefault('patch_id', patch_id)
    data.setdefault('version', VERSION)
    data.setdefault('saved_at', time.strftime('%Y-%m-%d %H:%M:%S'))
    save_json(state_file(patch_id), data)


def load_state(patch_id: str) -> dict:
    path = state_file(patch_id)
    if not os.path.exists(path):
        raise FileNotFoundError(f'Patch state not found: {path}')
    return load_json(path)


def delete_state(patch_id: str) -> None:
    path = state_file(patch_id)
    if os.path.exists(path):
        os.remove(path)


def kpm_settings_file() -> str:
    return os.path.join(addon_data_dir('runtime', 'state'), 'settings.json')


def load_kpm_settings() -> dict:
    path = kpm_settings_file()
    data = {
        'studio_logo_count': 1,
        'studio_debug': False,
        'screensaver_widget_path': '',
        'screensaver_widget_name': '',
        'screensaver_scroll_time_ms': 0,
    }
    if os.path.exists(path):
        try:
            loaded = load_json(path)
            if isinstance(loaded, dict):
                data.update(loaded)
        except Exception:
            pass
    try:
        count = int(data.get('studio_logo_count', 1))
    except Exception:
        count = 1
    data['studio_logo_count'] = 1
    return data


def save_kpm_settings(data: dict) -> None:
    current = load_kpm_settings()
    current.update(data or {})
    try:
        current['studio_logo_count'] = 1
    except Exception:
        current['studio_logo_count'] = 1
    save_json(kpm_settings_file(), current)



def _xml_text(value: str) -> str:
    """Escape a Kodi path exactly once for use as XML element text."""
    return html.escape(html.unescape(str(value or '').strip()), quote=False)


def _xml_value(value: str) -> str:
    """Return decoded XML text from an existing <value> element."""
    return html.unescape(str(value or '').strip())


def _normalize_screensaver_widget_path_0209(value: str) -> str:
    path = html.unescape(str(value or "").strip())
    while path.startswith(">"):
        path = path[1:].lstrip()

    if path.lower().startswith("plugin://plugin.video.mediahub.widget"):
        parsed = urllib.parse.urlsplit(path)
        pairs = urllib.parse.parse_qsl(
            parsed.query, keep_blank_values=True
        )
        normalized = []
        seen_limit = False
        seen_mode = False
        screensaver_modes = {
            "mix": "screensaver_mix",
            "movies": "screensaver_movies",
            "series": "screensaver_series",
            "games": "screensaver_games",
        }
        for key, item_value in pairs:
            key_lower = key.lower()
            if key_lower == "limit":
                if not seen_limit:
                    normalized.append((key, "0"))
                    seen_limit = True
                continue
            if key_lower == "mode":
                mode_value = screensaver_modes.get(str(item_value).strip().lower(), item_value)
                normalized.append((key, mode_value))
                seen_mode = True
                continue
            normalized.append((key, item_value))
        if not seen_mode:
            normalized.append(("mode", "screensaver_mix"))
        if not seen_limit:
            normalized.append(("limit", "0"))
        path = urllib.parse.urlunsplit(
            (
                parsed.scheme,
                parsed.netloc,
                parsed.path or "/",
                urllib.parse.urlencode(normalized),
                parsed.fragment,
            )
        )
    return path


def _screensaver_xml_path_0209() -> str:
    return af3_path('1080i', 'screensaver-arctic-mirage.xml')


def screensaver_scroll_time_from_xml_0209() -> int:
    path = _screensaver_xml_path_0209()
    if not os.path.exists(path):
        return 20000
    try:
        text = read_text(path)
        match = re.search(
            r'(?is)<control\s+type=["\']list["\']\s+id=["\']1297["\']>'
            r'.*?<autoscroll\s+time=["\'](\d+)["\'][^>]*>'
            r'\s*true\s*</autoscroll>',
            text,
        )
        if match:
            return max(50, int(match.group(1)))
    except Exception:
        pass
    return 20000


def current_screensaver_scroll_time_ms_0209() -> int:
    try:
        saved = int(
            load_kpm_settings().get('screensaver_scroll_time_ms') or 0
        )
    except Exception:
        saved = 0
    return (
        max(50, saved)
        if saved > 0
        else screensaver_scroll_time_from_xml_0209()
    )


def _format_scroll_duration_0209(milliseconds: int) -> str:
    seconds = float(milliseconds) / 1000.0
    if abs(seconds - round(seconds)) < 0.001:
        return '{0:.0f} seconds'.format(seconds)
    return '{0:.1f} seconds'.format(seconds)


def _patch_screensaver_runtime_settings_0209(
    text: str,
) -> Tuple[str, bool]:
    original = text
    scroll_ms = current_screensaver_scroll_time_ms_0209()

    list_pattern = re.compile(
        r'(?is)(<control\s+type=["\']list["\']\s+id=["\']1297["\']>'
        r'.*?<autoscroll\s+time=["\'])\d+'
        r'(["\'][^>]*>\s*true\s*</autoscroll>)'
    )
    text, count = list_pattern.subn(
        lambda match: (
            match.group(1) + str(scroll_ms) + match.group(2)
        ),
        text,
        count=1,
    )
    if count != 1:
        raise ValueError(
            'Could not patch Arctic Mirage list 1297 autoscroll time'
        )

    plot_pattern = re.compile(
        r'(?P<block><control\s+type=["\']textbox["\']>.*?'
        r'<label>\$INFO\[Container\(1297\)\.ListItem\.Plot\]</label>'
        r'.*?</control>)',
        re.I | re.S,
    )
    matches = list(plot_pattern.finditer(text))
    if len(matches) != 2:
        raise ValueError(
            'Expected two Arctic Mirage plot textboxes; found {0}'.format(
                len(matches)
            )
        )

    def patch_plot(match: re.Match) -> str:
        block = match.group('block')
        if re.search(r'<autoscroll\b', block, flags=re.I):
            return re.sub(
                r'<autoscroll\b[^>]*>.*?</autoscroll>',
                '<autoscroll>false</autoscroll>',
                block,
                count=1,
                flags=re.I | re.S,
            )
        return block.replace(
            '<label>$INFO[Container(1297).ListItem.Plot]</label>',
            '<label>$INFO[Container(1297).ListItem.Plot]</label>\n'
            '                <autoscroll>false</autoscroll>',
            1,
        )

    text = plot_pattern.sub(patch_plot, text)
    if text.count('<autoscroll>false</autoscroll>') < 2:
        raise ValueError('Plot autoscroll=false was not applied twice')

    ET.fromstring(text)
    return text, text != original


def apply_screensaver_runtime_settings_0209(
    reload_skin: bool = False,
) -> Result:
    name = 'Screensaver Runtime Settings'
    path = _screensaver_xml_path_0209()
    if not os.path.exists(path):
        return Result(name, 'Error', 'Arctic Mirage XML was not found.')

    text = read_text(path)
    updated, changed = _patch_screensaver_runtime_settings_0209(text)
    detail = 'Duration: {0}\nPlot autoscroll: OFF'.format(
        _format_scroll_duration_0209(
            current_screensaver_scroll_time_ms_0209()
        )
    )
    if not changed:
        return Result(name, 'Skipped', detail)

    snapshot('screensaver_runtime_settings_0209', [path])
    write_text(path, updated)
    if reload_skin and xbmc:
        xbmc.executebuiltin('ReloadSkin()')
    return Result(name, 'Applied', detail)


def choose_screensaver_scroll_time_0209() -> None:
    current = current_screensaver_scroll_time_ms_0209()
    presets = [5000, 10000, 15000, 20000, 30000, 45000, 60000]
    labels = [
        '5 seconds', '10 seconds', '15 seconds', '20 seconds',
        '30 seconds', '45 seconds', '60 seconds', 'Custom...'
    ]
    preselect = presets.index(current) if current in presets else 3
    index = xbmcgui.Dialog().select(
        ADDON_NAME + ' - Screensaver item duration',
        labels,
        preselect=preselect,
    )
    if index < 0:
        return

    if index < len(presets):
        selected = presets[index]
    else:
        current_seconds = max(1, int(round(current / 1000.0)))
        try:
            raw = xbmcgui.Dialog().numeric(
                0,
                'Screensaver item duration in seconds',
                str(current_seconds),
            )
        except Exception:
            raw = xbmcgui.Dialog().input(
                'Screensaver item duration in seconds',
                str(current_seconds),
                type=getattr(xbmcgui, 'INPUT_NUMERIC', 1),
            )
        try:
            selected = max(1, int(str(raw or '').strip())) * 1000
        except Exception:
            return

    save_kpm_settings({'screensaver_scroll_time_ms': selected})
    result = apply_screensaver_runtime_settings_0209(False)
    notify(
        'Screensaver duration: {0}'.format(
            _format_scroll_duration_0209(selected)
        )
    )
    if yesno(
        ADDON_NAME,
        '{0}\n\nReload skin now?'.format(result.detail),
    ):
        xbmc.executebuiltin('ReloadSkin()')


def _screensaver_variable_block(text: str) -> Optional[re.Match]:
    return re.search(r'(?ms)([ \t]*)<variable\s+name="Defs_ScreensaverWidget">.*?</variable>', text)


def screensaver_widget_path_from_xml() -> str:
    """Read the active value directly from AF3 Includes_Defaults.xml."""
    defaults = af3_path('1080i', 'Includes_Defaults.xml')
    if not os.path.exists(defaults):
        return ''
    try:
        text = read_text(defaults)
        match = _screensaver_variable_block(text)
        if not match:
            return ''
        value = re.search(r'(?ms)<value(?:\s+[^>]*)?>(.*?)</value>', match.group(0))
        return _xml_value(value.group(1)) if value else ''
    except Exception:
        return ''


def current_screensaver_widget_path() -> str:
    """Prefer saved choice, repair it, then adopt the active AF3 path."""
    saved = str(
        load_kpm_settings().get('screensaver_widget_path') or ''
    ).strip()
    raw = (
        saved
        or screensaver_widget_path_from_xml()
        or DEFAULT_SCREENSAVER_WIDGET_PATH
    )
    return _normalize_screensaver_widget_path_0209(raw)


def current_screensaver_widget_name() -> str:
    settings = load_kpm_settings()
    name = str(settings.get('screensaver_widget_name') or '').strip()
    if name:
        return name
    path = current_screensaver_widget_path()
    if path == DEFAULT_SCREENSAVER_WIDGET_PATH:
        return 'MediaHub: Mixed Movies + TV Shows'
    return 'Current AF3 path'


def _update_screensaver_variable(text: str, path: str, add_marker: bool = False) -> Tuple[str, Optional[str]]:
    """Replace only Defs_ScreensaverWidget and preserve its original block."""
    match = _screensaver_variable_block(text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_Defaults.xml: variable Defs_ScreensaverWidget')
    original = match.group(0)
    nl = newline_of(text)
    indent = match.group(1)
    inner = indent + '    '
    has_marker = add_marker or SHW_XML_MARKER in original
    lines = [f'{indent}<variable name="Defs_ScreensaverWidget">']
    if has_marker:
        lines.append(f'{inner}{SHW_XML_MARKER}')
    lines.append(f'{inner}<value>{_xml_text(path)}</value>')
    lines.append(f'{indent}</variable>')
    new_block = nl.join(lines)
    return text[:match.start()] + new_block + text[match.end():], original


def apply_saved_screensaver_widget_path(reload_skin: bool = False) -> Result:
    """Apply KPM's chosen widget path to AF3 immediately."""
    result_name = 'Screensaver Widget Path'
    defaults = af3_path('1080i', 'Includes_Defaults.xml')
    if not os.path.exists(defaults):
        return Result(result_name, 'Error', 'AF3 Includes_Defaults.xml was not found.')
    path = _normalize_screensaver_widget_path_0209(
        current_screensaver_widget_path()
    )
    save_kpm_settings({'screensaver_widget_path': path})
    text = read_text(defaults)
    had_marker = SHW_XML_MARKER in text
    new_text, original = _update_screensaver_variable(text, path, add_marker=True)
    if not had_marker:
        snapshot('shw_random_movies_tvshows', [defaults])
        state = {}
        if os.path.exists(state_file('shw_random_movies_tvshows')):
            try:
                state = load_state('shw_random_movies_tvshows')
            except Exception:
                state = {}
        state.update({'defaults': defaults, 'original_xml_block': original})
        save_state('shw_random_movies_tvshows', state)
    if new_text == text:
        return Result(result_name, 'Skipped', f'Already using: {path}')
    write_text(defaults, new_text)
    if reload_skin and xbmc:
        xbmc.executebuiltin('ReloadSkin()')
    return Result(result_name, 'Applied', path)


def _skin_shortcuts_available() -> bool:
    if not xbmc:
        return False
    try:
        return bool(xbmc.getCondVisibility('System.HasAddon(script.skinshortcuts)'))
    except Exception:
        return False


def _reset_skin_string(name: str) -> None:
    if xbmc:
        try:
            xbmc.executebuiltin(f'Skin.Reset({name})')
        except Exception:
            pass


def choose_screensaver_path_with_skinshortcuts() -> None:
    """Open Skin Shortcuts v3's standalone widget picker and save its content path."""
    if not _skin_shortcuts_available():
        ok(ADDON_NAME, 'Skin Shortcuts is not installed or enabled.\n\nUse Enter path manually instead.')
        return

    # Skin Shortcuts v3 removed the old type=shortcuts / skinList API.
    # Its supported standalone picker is type=skinstring and returns the
    # selected widget through skinPath, skinLabel, skinType, and skinTarget.
    keys = {
        'path': 'KPM.ScreensaverWidgetPath',
        'label': 'KPM.ScreensaverWidgetLabel',
        'type': 'KPM.ScreensaverWidgetType',
        'target': 'KPM.ScreensaverWidgetTarget',
    }
    cancel_sentinel = f'__KPM_PICKER_CANCEL_{int(time.time() * 1000)}__'

    for key in keys.values():
        _reset_skin_string(key)

    # A sentinel distinguishes Cancel (strings remain untouched) from None
    # (Skin Shortcuts explicitly resets the output strings).
    xbmc.executebuiltin(f'Skin.SetString({keys["path"]},{cancel_sentinel})')
    xbmc.executebuiltin(f'Skin.SetString({keys["label"]},{cancel_sentinel})')

    command = (
        'RunScript(script.skinshortcuts,'
        'type=skinstring,'
        f'skinPath={keys["path"]},'
        f'skinLabel={keys["label"]},'
        f'skinType={keys["type"]},'
        f'skinTarget={keys["target"]})'
    )
    try:
        xbmc.executebuiltin(command, True)
    except TypeError:
        # Compatibility with Kodi builds whose Python binding has no wait arg.
        xbmc.executebuiltin(command)
        monitor = xbmc.Monitor()
        for _ in range(1200):
            if monitor.waitForAbort(0.05):
                break
            path_now = str(xbmc.getInfoLabel(f'Skin.String({keys["path"]})') or '').strip()
            if path_now != cancel_sentinel:
                break

    selected_path = str(xbmc.getInfoLabel(f'Skin.String({keys["path"]})') or '').strip()
    selected_name = str(xbmc.getInfoLabel(f'Skin.String({keys["label"]})') or '').strip()

    for key in keys.values():
        _reset_skin_string(key)

    # Cancel leaves the sentinel unchanged. None resets all output strings.
    if selected_path == cancel_sentinel:
        return
    if not selected_path:
        selected_path = 'noop'
        selected_name = 'None'

    selected_path = _normalize_screensaver_widget_path_0209(_xml_value(selected_path))
    is_content_path = (
        selected_path == 'noop'
        or '://' in selected_path
        or selected_path.lower().endswith(('.xsp', '.xml', '.m3u', '.m3u8'))
    )
    if not is_content_path:
        ok(
            ADDON_NAME,
            'The selected item is not a widget/content path.\n\n'
            f'Selected value:\n{selected_path}\n\n'
            'Choose a library, playlist, source, or add-on folder instead.',
        )
        return

    save_kpm_settings({
        'screensaver_widget_path': selected_path,
        'screensaver_widget_name': selected_name or ('None' if selected_path == 'noop' else 'Selected path'),
    })
    result = apply_saved_screensaver_widget_path(False)
    notify('Screensaver path updated')
    message = (
        f'Selected: {selected_name or "Path"}\n\n'
        f'Path:\n{selected_path}\n\n'
        f'AF3: {result.status}\n\nReload skin now?'
    )
    if yesno(ADDON_NAME, message):
        xbmc.executebuiltin('ReloadSkin()')


def enter_screensaver_widget_path_manually() -> None:
    current = current_screensaver_widget_path()
    try:
        selected = xbmcgui.Dialog().input(
            'Screensaver widget path',
            defaultt=current,
            type=getattr(xbmcgui, 'INPUT_ALPHANUM', 0),
        )
    except TypeError:
        selected = xbmcgui.Dialog().input('Screensaver widget path', current)
    selected = str(selected or '').strip()
    if not selected or selected == current:
        return
    save_kpm_settings({
        'screensaver_widget_path': _normalize_screensaver_widget_path_0209(_xml_value(selected)),
        'screensaver_widget_name': 'Manual path',
    })
    result = apply_saved_screensaver_widget_path(False)
    notify('Screensaver widget path updated')
    if yesno(ADDON_NAME, f'Path applied to AF3.\n\n{result.detail}\n\nReload skin now?'):
        xbmc.executebuiltin('ReloadSkin()')


def restore_default_screensaver_widget_path() -> None:
    save_kpm_settings({
        'screensaver_widget_path': DEFAULT_SCREENSAVER_WIDGET_PATH,
        'screensaver_widget_name': 'MediaHub: Mixed Movies + TV Shows',
    })
    result = apply_saved_screensaver_widget_path(False)
    notify('MediaHub screensaver default restored')
    if yesno(ADDON_NAME, f'Default path restored.\n\n{result.detail}\n\nReload skin now?'):
        xbmc.executebuiltin('ReloadSkin()')

def snapshot(patch_id: str, paths: List[str]) -> None:
    # Safety only. Normal restore/remove below is block-level and does not use this to overwrite target files.
    root = addon_data_dir('runtime', 'exports', 'snapshots', patch_id, time.strftime('%Y%m%d-%H%M%S'))
    manifest = []
    for path in paths:
        if os.path.exists(path):
            dst_name = safe_name(path)
            shutil.copy2(path, os.path.join(root, dst_name))
            manifest.append({'source': path, 'snapshot': dst_name})
    save_json(os.path.join(root, 'manifest.json'), {'files': manifest})


def af3_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/skin.arctic.fuse.3'), *parts))


def tmdbhelper_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/plugin.video.themoviedb.helper'), *parts))


def skinhelper_path(*parts: str) -> str:
    return norm(os.path.join(translate('special://home/addons/script.skin.helper.widgets'), *parts))


SHARED_ICON_FILENAMES = (
    'certified.png', 'emmys.png', 'ends.png', 'sets.png', 'imdb.png', 'letterboxd.png', 'metacritic.png',
    'oscars.png', 'oscars_bp.png', 'popcorn.png', 'popcorn_spilt.png',
    'rtfresh.png', 'rtrotten.png', 'steam.png', 'steam-dev.png', 'steam-pub.png',
    'steam-ach.png', 'tmdb.png', 'verified.png',
)


def kpm_shared_icon_dir() -> str:
    return norm(os.path.join(translate('special://home/addons/{0}'.format(ADDON_ID)), 'resources', 'media', 'shared-icons'))


def kpm_shared_icon_path(filename: str) -> str:
    return norm(os.path.join(kpm_shared_icon_dir(), filename))


def _af3_rating_icon_dirs() -> List[str]:
    """Return AF3 rating icon folders that can consume KPM shared icons.

    AF3 textures reference flags/$VAR[Color_Directory]/ratings/<file>.png.
    Depending on skin packaging, that can exist under skin/media/flags or a
    development/unpacked skin flags folder, so keep both targets safe.
    """
    skin_root = af3_path()
    dirs: List[str] = []
    roots = [os.path.join(skin_root, 'media', 'flags'), os.path.join(skin_root, 'flags')]
    for flags_root in roots:
        if os.path.isdir(flags_root):
            try:
                for color in os.listdir(flags_root):
                    ratings_dir = os.path.join(flags_root, color, 'ratings')
                    if os.path.isdir(ratings_dir):
                        dirs.append(norm(ratings_dir))
            except Exception:
                pass
    # Fallback for the default AF3 color folder used by the Steam/KPM patches.
    for fallback in (os.path.join(skin_root, 'media', 'flags', 'color', 'ratings'),
                     os.path.join(skin_root, 'flags', 'color', 'ratings')):
        if os.path.isdir(os.path.dirname(fallback)) and norm(fallback) not in dirs:
            dirs.append(norm(fallback))
    # Stable order, no duplicates.
    out: List[str] = []
    for path in dirs:
        if path not in out:
            out.append(path)
    return out


def shared_rating_icons_status() -> str:
    src_dir = kpm_shared_icon_dir()
    bundled = [name for name in SHARED_ICON_FILENAMES if os.path.exists(os.path.join(src_dir, name))]
    return 'KPM source {0}/{1}; AF3 target dirs {2}'.format(len(bundled), len(SHARED_ICON_FILENAMES), len(_af3_rating_icon_dirs()))


def clear_pycache(folder: str, prefixes: Tuple[str, ...]) -> None:
    cache = os.path.join(folder, '__pycache__')
    if not os.path.isdir(cache):
        return
    for name in os.listdir(cache):
        if name.endswith('.pyc') and any(name.startswith(prefix + '.') for prefix in prefixes):
            try:
                os.remove(os.path.join(cache, name))
            except Exception:
                pass


@dataclass
class Result:
    name: str
    status: str
    detail: str = ''


# -----------------------------------------------------------------------------
# Patch 1: AF3 Up Next episode thumbnail priority
# -----------------------------------------------------------------------------

def upnext_target() -> str:
    return af3_path('1080i', 'Includes_Images.xml')


def status_upnext() -> str:
    target = upnext_target()
    if not os.path.exists(target):
        return 'Missing target'
    text = read_text(target)
    if UPNEXT_MARKER in text:
        return 'Patched'
    if '<variable name="Image_UpNext">' in text:
        return 'Not patched'
    return 'Unknown layout'


def patch_upnext() -> Result:
    name = patch_title('upnext_episode_thumb', 'Episode Thumb Up Next')
    target = upnext_target()
    text = read_text(target)
    if UPNEXT_MARKER in text:
        return Result(name, 'Skipped', 'Already patched.')

    pattern = r'(?ms)([ \t]*)<variable\s+name="Image_UpNext">.*?</variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Anchor not found: variable Image_UpNext in Includes_Images.xml')

    original = match.group(0)
    nl = newline_of(text)
    indent = match.group(1)
    inner = indent + '    '
    new_block = nl.join([
        f'{indent}<variable name="Image_UpNext">',
        f'{inner}{UPNEXT_MARKER}',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(thumb))">$INFO[Window.Property(thumb)]</value>',
        f'{inner}<value condition="!String.IsEmpty(Window.Property(landscape))">$INFO[Window.Property(landscape)]</value>',
        f'{indent}</variable>',
    ])

    snapshot('upnext_episode_thumb', [target])
    save_state('upnext_episode_thumb', {'target': target, 'original_block': original})
    text = text[:match.start()] + new_block + text[match.end():]
    write_text(target, text)
    return Result(name, 'Patched', 'Image_UpNext priority: thumb -> landscape.')


def remove_upnext() -> Result:
    name = patch_title('upnext_episode_thumb', 'Episode Thumb Up Next')
    target = upnext_target()
    text = read_text(target)
    if UPNEXT_MARKER not in text:
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('upnext_episode_thumb')
    original = state.get('original_block')
    if not original:
        raise RuntimeError('Original Image_UpNext block is missing from saved state.')
    pattern = r'(?ms)[ \t]*<variable\s+name="Image_UpNext">(?:(?!</variable>).)*?' + re.escape(UPNEXT_MARKER) + r'.*?</variable>'
    if not re.search(pattern, text):
        raise RuntimeError('Patched Image_UpNext block not found.')
    text = re.sub(pattern, original, text, count=1)
    write_text(target, text)
    delete_state('upnext_episode_thumb')
    return Result(name, 'Removed', 'Original Image_UpNext block restored only.')


# -----------------------------------------------------------------------------


# Patch 3: Skin Helper Widgets random Movies + TV Shows screensaver for AF3
# -----------------------------------------------------------------------------

def shw_targets() -> Tuple[str, str]:
    media = skinhelper_path('resources', 'lib', 'media.py')
    defaults = af3_path('1080i', 'Includes_Defaults.xml')
    return media, defaults


def status_shw() -> str:
    media, defaults = shw_targets()
    if not os.path.exists(media) or not os.path.exists(defaults):
        return 'Missing target'
    t1 = read_text(media)
    t2 = read_text(defaults)
    method_ok = SHW_METHOD_START in t1 or re.search(r'def\s+randommoviestvshows\s*\(\s*self\s*\)\s*:', t1)
    xml_ok = SHW_XML_MARKER in t2
    if method_ok and xml_ok:
        return 'Patched'
    return 'Not patched'


def extract_variable_block(text: str, variable_name: str) -> Optional[str]:
    pattern = r'(?ms)[ \t]*<variable\s+name="' + re.escape(variable_name) + r'">.*?</variable>'
    match = re.search(pattern, text)
    return match.group(0) if match else None


def patch_shw_media(text: str) -> str:
    nl = newline_of(text)
    has_any_method = (SHW_METHOD_START in text or
                      re.search(r'def\s+randommoviestvshows\s*\(\s*self\s*\)\s*:', text))
    if not has_any_method:
        method = nl.join([
            f'    {SHW_METHOD_START}',
            '    def randommoviestvshows(self):',
            '        """get random movies and tvshows only - no episodes, no music, no pvr"""',
            '        all_items = self.movies.random()',
            '        all_items += self.tvshows.random()',
            '        return sorted(all_items, key=lambda k: random.random())[:self.options["limit"]]',
            f'    {SHW_METHOD_END}',
            '',
        ]) + nl
        anchor = '    def inprogress(self):'
        if anchor not in text:
            raise RuntimeError('Anchor not found in media.py: def inprogress(self)')
        text = text.replace(anchor, method + anchor, 1)

    if SHW_ENTRY_MARKER not in text:
        old = '            (self.addon.getLocalizedString(32059), "random&mediatype=media", "DefaultMovies.png"),'
        if old in text:
            new = old + nl + f'            ("Random Movies + TV Shows", "randommoviestvshows&mediatype=media", "DefaultMovies.png"),  {SHW_ENTRY_MARKER}'
            text = text.replace(old, new, 1)
    return text


def patch_shw_xml(text: str, limit: int) -> Tuple[str, str]:
    path = current_screensaver_widget_path()
    updated, original = _update_screensaver_variable(text, path, add_marker=True)
    return updated, original


def patch_shw(limit: int = 100) -> Result:
    name = patch_title('shw_random_movies_tvshows', 'Movies + Shows Screensaver')
    media, defaults = shw_targets()
    t1 = read_text(media)
    t2 = read_text(defaults)
    selected_path = current_screensaver_widget_path()
    if (SHW_METHOD_START in t1) and (SHW_XML_MARKER in t2):
        n2, _ = _update_screensaver_variable(t2, selected_path, add_marker=True)
        if n2 != t2:
            write_text(defaults, n2)
            return Result(name, 'Updated', f'Screensaver path: {selected_path}')
        return Result(name, 'Skipped', f'Already patched. Screensaver path: {selected_path}')

    snapshot('shw_random_movies_tvshows', [media, defaults])
    n1 = patch_shw_media(t1)
    if SHW_XML_MARKER in t2:
        n2 = t2
        original_xml = None
    else:
        n2, original_xml = patch_shw_xml(t2, limit)
    state = {}
    if os.path.exists(state_file('shw_random_movies_tvshows')):
        try:
            state = load_state('shw_random_movies_tvshows')
        except Exception:
            state = {}
    state.update({'media': media, 'defaults': defaults})
    if original_xml is not None:
        state['original_xml_block'] = original_xml
    save_state('shw_random_movies_tvshows', state)
    write_text(media, n1)
    write_text(defaults, n2)
    clear_pycache(os.path.dirname(media), ('media',))
    return Result(name, 'Patched', f'Screensaver path: {selected_path}')


def remove_shw() -> Result:
    name = patch_title('shw_random_movies_tvshows', 'Movies + Shows Screensaver')
    media, defaults = shw_targets()
    t1 = read_text(media)
    t2 = read_text(defaults)
    has_markers = any(marker in t1 for marker in (SHW_METHOD_START, SHW_ENTRY_MARKER)) or any(marker in t2 for marker in (SHW_XML_MARKER,))
    if not has_markers:
        return Result(name, 'Skipped', 'Patch marker not found.')
    state = load_state('shw_random_movies_tvshows') if os.path.exists(state_file('shw_random_movies_tvshows')) else {}

    # Remove the current KPM method block by marker.
    for start, end in ((SHW_METHOD_START, SHW_METHOD_END),):
        method_pattern = r'(?ms)\r?\n?    ' + re.escape(start) + r'.*?    ' + re.escape(end) + r'\r?\n?'
        t1 = re.sub(method_pattern, '\n', t1, count=1)

    # Remove optional listing line by marker.
    for marker in (SHW_ENTRY_MARKER,):
        entry_pattern = r'(?m)^.*' + re.escape(marker) + r'.*(\r?\n)?'
        t1 = re.sub(entry_pattern, '', t1, count=1)

    # Restore only the original XML variable block saved by the current patch.
    if SHW_XML_MARKER in t2:
        original = state.get('original_xml_block')
        if not original:
            raise RuntimeError('Cannot remove SHW XML patch: original Defs_ScreensaverWidget state is missing.')
        marker_pat = re.escape(SHW_XML_MARKER)
        pattern = r'(?ms)[ \t]*<variable\s+name="Defs_ScreensaverWidget">(?:(?!</variable>).)*?(?:' + marker_pat + r').*?</variable>'
        t2 = re.sub(pattern, original, t2, count=1)

    write_text(media, t1)
    write_text(defaults, t2)
    clear_pycache(os.path.dirname(media), ('media',))
    delete_state('shw_random_movies_tvshows')
    return Result(name, 'Removed', 'Injected method/listing removed; original XML variable restored only.')



# -----------------------------------------------------------------------------
# LRS remains the rating data owner; KPM installs only the current visual bridge.


# Patch 5: fullscreen pause rating row beside Paused
# -----------------------------------------------------------------------------

def seekbar_pause_target() -> str:
    # Actual AF3 pause overlay with the Paused header is DialogSeekBar.xml.
    return af3_path('1080i', 'DialogSeekBar.xml')


def video_osd_target() -> str:
    # Full OSD window shown by pressing M / videoosd.
    return af3_path('1080i', 'VideoOSD.xml')


def includes_osd_target() -> str:
    # OSD detail layout includes title / plot / metadata area used by VideoOSD.
    return af3_path('1080i', 'Includes_OSD.xml')


def includes_actions_target() -> str:
    # AF3 OSD timeout actions live here.
    return af3_path('1080i', 'Includes_Actions.xml')


def includes_images_target() -> str:
    return af3_path('1080i', 'Includes_Images.xml')


def includes_furniture_target() -> str:
    return af3_path('1080i', 'Includes_Furniture.xml')


def _has_marked_block(text: str, start: str, end: str) -> bool:
    return start in text and end in text


def status_vfs_pause_ratings() -> str:
    seekbar = seekbar_pause_target()
    videoosd = video_osd_target()
    includes_osd = includes_osd_target()
    includes_actions = includes_actions_target()
    if not os.path.exists(seekbar):
        return 'Missing DialogSeekBar.xml'
    if not os.path.exists(videoosd):
        return 'Missing VideoOSD.xml'
    if not os.path.exists(includes_osd):
        return 'Missing Includes_OSD.xml'
    if not os.path.exists(includes_actions):
        return 'Missing Includes_Actions.xml'
    seekbar_text = read_text(seekbar)
    videoosd_text = read_text(videoosd)
    includes_osd_text = read_text(includes_osd)
    includes_actions_text = read_text(includes_actions)
    has_auto_osd = DIALOG_SEEKBAR_AUTO_OSD_MARKER in seekbar_text
    has_seekbar_clearart = _has_marked_block(seekbar_text, DIALOG_SEEKBAR_CLEARART_START, DIALOG_SEEKBAR_CLEARART_END)
    has_fast_close = _has_marked_block(videoosd_text, VIDEOOSD_FAST_CLOSE_START, VIDEOOSD_FAST_CLOSE_END)
    has_plot_width = _has_marked_block(includes_osd_text, OSD_PLOT_WIDTH_START, OSD_PLOT_WIDTH_END)
    has_range_hidden = _has_marked_block(includes_osd_text, OSD_RANGE_MARKERS_START, OSD_RANGE_MARKERS_END)
    has_pause_stay = _has_marked_block(includes_actions_text, ACTION_OSD_PAUSE_STAY_START, ACTION_OSD_PAUSE_STAY_END)
    if has_auto_osd and has_seekbar_clearart and has_fast_close and has_plot_width and has_range_hidden and has_pause_stay:
        return 'Patched'
    parts = []
    if has_auto_osd:
        parts.append('Auto OSD')
    if has_seekbar_clearart:
        parts.append('clearart behind progress')
    if has_fast_close:
        parts.append('fast close')
    if has_plot_width:
        parts.append('plot width')
    if has_range_hidden:
        parts.append('chapter ticks hidden')
    if has_pause_stay:
        parts.append('pause stay')
    return 'Partial: ' + ', '.join(parts) if parts else 'Not patched'


def _remove_marked_block(text: str, start: str, end: str) -> Tuple[str, bool]:
    if start not in text or end not in text:
        return text, False
    pattern = r'(?ms)\s*' + re.escape(start) + r'.*?' + re.escape(end)
    new_text = re.sub(pattern, '', text, count=1)
    return new_text, new_text != text


def _remove_seekbar_auto_videoosd(text: str) -> Tuple[str, bool]:
    if DIALOG_SEEKBAR_AUTO_OSD_MARKER not in text:
        return text, False
    pattern = r'(?ms)\s*' + re.escape(DIALOG_SEEKBAR_AUTO_OSD_MARKER) + r'(?:\s*<!-- KPM current pause service marker\. -->)?'
    new_text = re.sub(pattern, '', text, count=1)
    return new_text, new_text != text


def _inject_seekbar_auto_videoosd(text: str, nl: str) -> Tuple[str, bool]:
    """Mark DialogSeekBar for the current dialog-safe pause OSD service."""
    text, removed = _remove_seekbar_auto_videoosd(text)
    block = nl.join([
        '    ' + DIALOG_SEEKBAR_AUTO_OSD_MARKER,
        '    <!-- KPM current pause service marker. -->',
    ])
    if '<zorder>0</zorder>' in text:
        return text.replace('<zorder>0</zorder>', '<zorder>0</zorder>' + nl + block, 1), True
    if '<window>' in text:
        return text.replace('<window>', '<window>' + nl + block, 1), True
    raise RuntimeError('Anchor not found in DialogSeekBar.xml: <zorder>0</zorder> or <window>')




def _seekbar_clearart_block(nl: str) -> str:
    return nl.join([
        '                        ' + DIALOG_SEEKBAR_CLEARART_START,
        '                        <!-- KPM clearart is intentionally drawn inside DialogSeekBar before OSD_Progress_Bar, so the progress line and time labels render above it. -->',
        '                        <control type="group">',
        '                            <visible>Window.IsActive(videoosd) + Player.HasMedia + !Pvr.IsPlayingTv</visible>',
        '                            <visible>!Window.IsVisible(DialogPlayerProcessInfo.xml) + !Window.IsVisible(DialogSlider.xml)</visible>',
        '                            <right>view_osd_r</right>',
        '                            <bottom>180</bottom>',
        '                            <width>480</width>',
        '                            <height>270</height>',
        '                            <animation effect="fade" start="0" end="100" time="200">WindowOpen</animation>',
        '                            <control type="image">',
        '                                <width>100%</width>',
        '                                <height>100%</height>',
        '                                <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                                <texture background="true">$INFO[VideoPlayer.Art(clearart)]</texture>',
        '                                <visible>!String.IsEmpty(VideoPlayer.Art(clearart))</visible>',
        '                            </control>',
        '                            <control type="image">',
        '                                <width>100%</width>',
        '                                <height>100%</height>',
        '                                <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                                <texture background="true">$INFO[VideoPlayer.Art(tvshow.clearart)]</texture>',
        '                                <visible>String.IsEmpty(VideoPlayer.Art(clearart)) + !String.IsEmpty(VideoPlayer.Art(tvshow.clearart))</visible>',
        '                            </control>',
        '                            <control type="image">',
        '                                <width>100%</width>',
        '                                <height>100%</height>',
        '                                <aspectratio align="right" aligny="bottom">keep</aspectratio>',
        '                                <texture background="true">$INFO[Window(Home).Property(TMDbHelper.Player.ClearArt)]</texture>',
        '                                <visible>String.IsEmpty(VideoPlayer.Art(clearart)) + String.IsEmpty(VideoPlayer.Art(tvshow.clearart)) + !String.IsEmpty(Window(Home).Property(TMDbHelper.Player.ClearArt))</visible>',
        '                            </control>',
        '                        </control>',
        '                        ' + DIALOG_SEEKBAR_CLEARART_END,
    ])


def _remove_seekbar_clearart(text: str) -> Tuple[str, bool]:
    return _remove_marked_block(text, DIALOG_SEEKBAR_CLEARART_START, DIALOG_SEEKBAR_CLEARART_END)


def _inject_seekbar_clearart(text: str, nl: str) -> Tuple[str, bool]:
    text, _ = _remove_seekbar_clearart(text)
    block = _seekbar_clearart_block(nl)
    anchor = '                        <include>OSD_Progress_Labels</include>'
    if anchor not in text:
        raise RuntimeError('Anchor not found in DialogSeekBar.xml: OSD_Progress_Labels include')
    return text.replace(anchor, block + nl + anchor, 1), True


def _fast_close_block(nl: str, indent: str = '                            ') -> str:
    return nl.join([
        indent + VIDEOOSD_FAST_CLOSE_START,
        indent + '<onclick condition="Player.Paused">Close</onclick>',
        indent + '<onclick>PlayerControl(Play)</onclick>',
        indent + VIDEOOSD_FAST_CLOSE_END,
    ])


def _restore_videoosd_fast_close(text: str, nl: str) -> Tuple[str, bool]:
    if VIDEOOSD_FAST_CLOSE_START not in text or VIDEOOSD_FAST_CLOSE_END not in text:
        return text, False
    pattern = re.compile(r'(?ms)\s*' + re.escape(VIDEOOSD_FAST_CLOSE_START) + r'.*?' + re.escape(VIDEOOSD_FAST_CLOSE_END))
    new_text = pattern.sub(nl + '                            <onclick>PlayerControl(Play)</onclick>', text, count=1)
    return new_text, new_text != text


def _inject_videoosd_fast_close(text: str, nl: str) -> Tuple[str, bool]:
    text, _ = _restore_videoosd_fast_close(text, nl)
    pattern = re.compile(
        r'(?ms)(<control type="button" id="6001">.*?)(\s*<onclick>PlayerControl\(Play\)</onclick>)(.*?</control>)'
    )
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in VideoOSD.xml: button id 6001 PlayerControl(Play)')
    block = nl + _fast_close_block(nl)
    return text[:match.start(2)] + block + text[match.end(2):], True


def _restore_osd_plot_width(text: str, nl: str) -> Tuple[str, bool]:
    """Restore the OSD plot width parameter modified by KPM."""
    if OSD_PLOT_WIDTH_START not in text or OSD_PLOT_WIDTH_END not in text:
        return text, False
    pattern = re.compile(
        r'(?ms)\s*' + re.escape(OSD_PLOT_WIDTH_START) + r'.*?' + re.escape(OSD_PLOT_WIDTH_END)
    )
    replacement = nl + '                    <param name="width">info_panel_w</param>'
    new_text = pattern.sub(replacement, text, count=1)
    return new_text, new_text != text


def _inject_osd_plot_width(text: str, nl: str) -> Tuple[str, bool]:
    """Shorten only the plot width inside OSD_Progress_Details_Extended.

    This keeps title, info line, ratings, and buttons unchanged, but stops the
    plot text before the clearart area on the right.
    """
    text, _ = _restore_osd_plot_width(text, nl)
    pattern = re.compile(
        r'(?ms)(<include name="OSD_Progress_Details_Extended">.*?'
        r'<include content="Info_Plot" condition="\$PARAM\[plot_visible\]">.*?)'
        r'(\s*<param name="width">info_panel_w</param>)'
    )
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_OSD.xml: OSD_Progress_Details_Extended Info_Plot width')
    block = nl.join([
        '                    ' + OSD_PLOT_WIDTH_START,
        '                    <param name="width">900</param>',
        '                    ' + OSD_PLOT_WIDTH_END,
    ])
    return text[:match.start(2)] + nl + block + text[match.end(2):], True


def _restore_osd_range_markers(text: str, nl: str) -> Tuple[str, bool]:
    """Restore cutlist/chapter range marker controls hidden by KPM."""
    if OSD_RANGE_MARKERS_START not in text or OSD_RANGE_MARKERS_END not in text:
        return text, False
    pattern = re.compile(
        r'(?ms)\s*' + re.escape(OSD_RANGE_MARKERS_START) + r'.*?' + re.escape(OSD_RANGE_MARKERS_END)
    )
    replacement = nl.join([
        '        <!-- CutList and Chapters Range -->',
        '        <control type="ranges">',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="panel_fg_50">progress/marker.png</righttexture>',
        '            <info>Player.CutList</info>',
        '        </control>',
        '        <control type="ranges">',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="panel_fg_50">progress/marker.png</righttexture>',
        '            <info>Player.Chapters</info>',
        '        </control>',
    ])
    new_text = pattern.sub(nl + replacement, text, count=1)
    return new_text, new_text != text


def _inject_osd_range_markers_hidden(text: str, nl: str) -> Tuple[str, bool]:
    """Hide chapter/cutlist tick markers on the progress line.

    The orange progress and time labels remain intact. Only the small white
    range/chapter marker ticks are suppressed.
    """
    text, _ = _restore_osd_range_markers(text, nl)
    pattern = re.compile(
        r'(?ms)(\s*<!-- CutList and Chapters Range -->\s*'
        r'<control type="ranges">.*?<info>Player\.CutList</info>\s*</control>\s*'
        r'<control type="ranges">.*?<info>Player\.Chapters</info>\s*</control>)'
    )
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_OSD.xml: CutList and Chapters Range controls')
    block = nl.join([
        '        ' + OSD_RANGE_MARKERS_START,
        '        <!-- KPM hides the small cutlist/chapter marker ticks on the progress line. -->',
        '        <control type="ranges">',
        '            <visible>false</visible>',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="00ffffff">progress/marker.png</righttexture>',
        '            <info>Player.CutList</info>',
        '        </control>',
        '        <control type="ranges">',
        '            <visible>false</visible>',
        '            <width>100%</width>',
        '            <height>12</height>',
        '            <texturebg colordiffuse="00ffffff">progress/marker-bg.png</texturebg>',
        '            <righttexture colordiffuse="00ffffff">progress/marker.png</righttexture>',
        '            <info>Player.Chapters</info>',
        '        </control>',
        '        ' + OSD_RANGE_MARKERS_END,
    ])
    return text[:match.start()] + nl + block + text[match.end():], True


def _original_action_osd_button_block(nl: str) -> str:
    return nl.join([
        '    <include name="Action_OSD_Button">',
        '        <onfocus condition="!String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onfocus>',
        '        <onunfocus>CancelAlarm(osd_timeout,true)</onunfocus>',
        '',
        '        <onclick condition="!String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onclick>',
        '    </include>',
    ])


def _pause_stay_action_osd_button_block(nl: str) -> str:
    return nl.join([
        '    ' + ACTION_OSD_PAUSE_STAY_START,
        '    <!-- KPM: while paused, do not start AF3 osd_timeout; the full OSD stays until playback resumes or user closes it. -->',
        '    <include name="Action_OSD_Button">',
        '        <onfocus condition="!Player.Paused + !String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onfocus>',
        '        <onfocus condition="Player.Paused">CancelAlarm(osd_timeout,true)</onfocus>',
        '        <onunfocus>CancelAlarm(osd_timeout,true)</onunfocus>',
        '',
        '        <onclick condition="!Player.Paused + !String.IsEmpty(Skin.String(OSD_Timeout)) + [Window.IsVisible(videoosd) | Window.IsVisible(musicosd)]">AlarmClock(osd_timeout,RunScript(script.skinvariables,run_executebuiltin=special://skin/shortcuts/builtins/skinvariables-closeosd.json,use_rules=True),$INFO[Skin.String(OSD_Timeout),00:,],silent)</onclick>',
        '        <onclick condition="Player.Paused">CancelAlarm(osd_timeout,true)</onclick>',
        '    </include>',
        '    ' + ACTION_OSD_PAUSE_STAY_END,
    ])


def _restore_action_osd_pause_stay(text: str, nl: str) -> Tuple[str, bool]:
    if ACTION_OSD_PAUSE_STAY_START not in text or ACTION_OSD_PAUSE_STAY_END not in text:
        return text, False
    pattern = re.compile(
        r'(?ms)\s*' + re.escape(ACTION_OSD_PAUSE_STAY_START) + r'.*?' + re.escape(ACTION_OSD_PAUSE_STAY_END)
    )
    replacement = nl + _original_action_osd_button_block(nl)
    new_text = pattern.sub(replacement, text, count=1)
    return new_text, new_text != text


def _inject_action_osd_pause_stay(text: str, nl: str) -> Tuple[str, bool]:
    text, _ = _restore_action_osd_pause_stay(text, nl)
    pattern = re.compile(r'(?ms)\s*<include name="Action_OSD_Button">.*?</include>')
    match = pattern.search(text)
    if not match:
        raise RuntimeError('Anchor not found in Includes_Actions.xml: include Action_OSD_Button')
    block = nl + _pause_stay_action_osd_button_block(nl)
    return text[:match.start()] + block + text[match.end():], True

_KPM_BATCH_PATCH_MODE = False
_KPM_BATCH_RELOAD_NEEDED = False

def _reload_skin_after_patch() -> None:
    global _KPM_BATCH_RELOAD_NEEDED
    if _KPM_BATCH_PATCH_MODE:
        _KPM_BATCH_RELOAD_NEEDED = True
        log('[KPM] ReloadSkin deferred until the full integration batch finishes')
        return
    if xbmc:
        try:
            xbmc.executebuiltin('ReloadSkin()')
            log('[KPM] ReloadSkin requested after patch')
        except Exception:
            log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)

def _finish_deferred_reload() -> None:
    global _KPM_BATCH_RELOAD_NEEDED
    if not _KPM_BATCH_RELOAD_NEEDED or not xbmc:
        return
    _KPM_BATCH_RELOAD_NEEDED = False
    try:
        xbmc.executebuiltin('ReloadSkin()')
        log('[KPM] One ReloadSkin requested after the full integration batch')
    except Exception:
        log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def addon_install_path() -> str:
    return norm(translate(f'special://home/addons/{ADDON_ID}'))


def _start_resume_close_service() -> None:
    """Start the tiny service immediately after patching.

    Kodi will also start it at login because addon.xml declares xbmc.service.
    This RunScript path is only for the current session after the user patches
    without restarting Kodi. The service exits if another instance is already
    running.
    """
    if not xbmc:
        return
    try:
        service_path = os.path.join(addon_install_path(), 'service.py')
        xbmc.executebuiltin('RunScript({0})'.format(service_path))
        log('[KPM] Resume-close service start requested')
    except Exception:
        log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def patch_vfs_pause_ratings() -> Result:
    name = patch_title('vfs_pause_ratings', 'Pause Shows Full OSD')
    if status_vfs_pause_ratings() == 'Patched':
        _start_resume_close_service()
        return Result(name, 'Skipped', 'Already patched with current pause/full OSD layout.')
    seekbar = seekbar_pause_target()
    videoosd = video_osd_target()
    includes_osd = includes_osd_target()
    includes_actions = includes_actions_target()
    targets = [seekbar, videoosd, includes_osd, includes_actions]
    snapshot('vfs_pause_ratings', targets)


    # DialogSeekBar opens VideoOSD on pause and now owns the clearart layer.
    # Clearart is drawn BEFORE progress labels/bar so the line and times stay on top.
    seek_text = read_text(seekbar)
    seek_nl = newline_of(seek_text)
    seek_text, existing_auto_removed = _remove_seekbar_auto_videoosd(seek_text)
    seek_text, existing_seekbar_clearart_removed = _remove_seekbar_clearart(seek_text)
    seek_text, auto_inserted = _inject_seekbar_auto_videoosd(seek_text, seek_nl)
    seek_text, seekbar_clearart_inserted = _inject_seekbar_clearart(seek_text, seek_nl)
    write_text(seekbar, seek_text)

    # VideoOSD keeps the current fast close-on-resume behavior.
    osd_text = read_text(videoosd)
    osd_nl = newline_of(osd_text)
    osd_text, existing_fast_removed = _restore_videoosd_fast_close(osd_text, osd_nl)
    osd_text, fast_inserted = _inject_videoosd_fast_close(osd_text, osd_nl)
    write_text(videoosd, osd_text)

    # OSD details plot width is shortened and the small cutlist/chapter marker ticks are hidden.
    includes_text = read_text(includes_osd)
    includes_nl = newline_of(includes_text)
    includes_text, existing_plot_width_removed = _restore_osd_plot_width(includes_text, includes_nl)
    includes_text, plot_width_inserted = _inject_osd_plot_width(includes_text, includes_nl)
    includes_text, existing_range_removed = _restore_osd_range_markers(includes_text, includes_nl)
    includes_text, range_inserted = _inject_osd_range_markers_hidden(includes_text, includes_nl)
    write_text(includes_osd, includes_text)

    # Prevent AF3 native OSD timeout from closing VideoOSD while playback is paused.
    actions_text = read_text(includes_actions)
    actions_nl = newline_of(actions_text)
    actions_text, existing_pause_stay_removed = _restore_action_osd_pause_stay(actions_text, actions_nl)
    actions_text, pause_stay_inserted = _inject_action_osd_pause_stay(actions_text, actions_nl)
    write_text(includes_actions, actions_text)

    save_state('vfs_pause_ratings', {
        'seekbar_target': seekbar,
        'videoosd_target': videoosd,
        'includes_osd_target': includes_osd,
        'includes_actions_target': includes_actions,
        'layout': 'service_managed_fast_auto_videoosd_clearart_behind_progress_pause_stay_chapter_ticks_hidden_plot_short_safe_resume_close',
        'auto_videoosd': True,
        'auto_videoosd_mode': 'service_fast_pause_startup_guard',
        'clearart_layer': 'DialogSeekBar before OSD_Progress_Bar',
        'clearart_box': {'right': 'view_osd_r', 'bottom': 180, 'width': 480, 'height': 270},
        'clearart_sources': ['VideoPlayer.Art(clearart)', 'VideoPlayer.Art(tvshow.clearart)', 'TMDbHelper.Player.ClearArt'],
        'fast_close_resume': True,
        'resume_close_service': True,
        'resume_close_no_action_back': True,
        'resume_close_dialog_safe': True,
        'pause_stay_until_resume': True,
        'hide_chapter_ticks': True,
        'plot_width': 900,
    })
    _reload_skin_after_patch()
    _start_resume_close_service()

    changed = any([
        existing_auto_removed, existing_seekbar_clearart_removed,
        auto_inserted, seekbar_clearart_inserted,
        existing_fast_removed, fast_inserted, existing_plot_width_removed, plot_width_inserted,
        existing_range_removed, range_inserted, existing_pause_stay_removed, pause_stay_inserted,
    ])
    detail = 'Pause now opens full VideoOSD via the KPM service quickly on normal pause and stays open while paused; a longer startup guard is kept only for auto subtitle dialogs at playback start. clearart is drawn behind the progress line, chapter/cutlist tick markers are hidden, OSD plot width is shortened, and KPM resume monitor closes OSD after playback resumes without Action(Back). VideoOSD can stay behind subtitle/audio/other dialogs without KPM stealing focus; auto subtitle dialogs at playback start are still guarded, but normal manual pause opens faster. ReloadSkin and service start requested.'
    return Result(name, 'Patched' if changed else 'Skipped', detail)


def remove_vfs_pause_ratings() -> Result:
    name = patch_title('vfs_pause_ratings', 'Pause Shows Full OSD')
    removed = []
    seekbar = seekbar_pause_target()
    if os.path.exists(seekbar):
        text = read_text(seekbar)
        nl = newline_of(text)
        text_new, did_auto = _remove_seekbar_auto_videoosd(text)
        text_new, did_seekbar_clearart = _remove_seekbar_clearart(text_new)
        if did_auto or did_seekbar_clearart:
            write_text(seekbar, text_new)
            removed.append('DialogSeekBar.xml')

    videoosd = video_osd_target()
    if os.path.exists(videoosd):
        text = read_text(videoosd)
        nl = newline_of(text)
        text_new, did_fast = _restore_videoosd_fast_close(text, nl)
        if did_fast:
            write_text(videoosd, text_new)
            removed.append('VideoOSD.xml')

    includes_osd = includes_osd_target()
    if os.path.exists(includes_osd):
        text = read_text(includes_osd)
        nl = newline_of(text)
        text_new, did_plot = _restore_osd_plot_width(text, nl)
        text_new, did_ranges = _restore_osd_range_markers(text_new, nl)
        if did_plot or did_ranges:
            write_text(includes_osd, text_new)
            removed.append('Includes_OSD.xml')

    includes_actions = includes_actions_target()
    if os.path.exists(includes_actions):
        text = read_text(includes_actions)
        nl = newline_of(text)
        text_new, did_pause_stay = _restore_action_osd_pause_stay(text, nl)
        if did_pause_stay:
            write_text(includes_actions, text_new)
            removed.append('Includes_Actions.xml')

    delete_state('vfs_pause_ratings')
    if removed:
        _reload_skin_after_patch()
        return Result(name, 'Removed', 'Removed pause/full OSD edits from: {0}. ReloadSkin requested.'.format(', '.join(removed)))
    return Result(name, 'Skipped', 'Patch marker not found.')



# -----------------------------------------------------------------------------
# Patch 6: reliable studio logos
# -----------------------------------------------------------------------------


def _studio_image_var_block(nl: str) -> str:
    lines = [
        f'    {STUDIO_IMAGE_VAR_START}',
        '    <variable name="Image_CombinedStudio">',
        '        <value condition="!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))">$INFO[Window(Home).Property(KPM.StudioLogo.1)]</value>',
        '    </variable>',
        f'    {STUDIO_IMAGE_VAR_END}',
    ]
    return nl.join(lines)


def _studio_furniture_block_from_original(original: str, nl: str) -> str:
    """Patch Furniture_Studio without rebuilding its layout.

    The original AF3 block owns the exact position/size/animation. KPM only swaps
    the studio texture source and adds KPM visibility guards. This prevents the
    footer studio logo from moving when KPM is updated.
    """
    block = original.rstrip('\r\n')
    # Normalize the current KPM guards before rebuilding the marked block.
    block = re.sub(r'(?m)^\s*<visible>String\.IsEqual\(Window\(Home\)\.Property\(KPM\.StudioLogos\.Show\),true\)</visible>\s*\r?\n?', '', block)
    block = re.sub(r'(?m)^\s*<visible>!String\.IsEmpty\(Window\(Home\)\.Property\(KPM\.StudioLogo\.1\)\)</visible>\s*\r?\n?', '', block)
    block = block.replace(STUDIO_FURNITURE_CURRENT_MARKER + nl, '').replace(STUDIO_FURNITURE_CURRENT_MARKER, '')

    texture_re = r'(<texture(?=[^>]*background="true")[^>]*>).*?(</texture>)'
    block_new, count = re.subn(texture_re, r'\1$INFO[Window(Home).Property(KPM.StudioLogo.1)]\2', block, count=1, flags=re.S)
    if count == 0:
        block_new, count = re.subn(r'(<texture[^>]*>).*?(</texture>)', r'\1$INFO[Window(Home).Property(KPM.StudioLogo.1)]\2', block, count=1, flags=re.S)
    if count == 0:
        raise RuntimeError('Cannot patch Furniture_Studio: texture line not found')
    block = block_new

    guards = nl.join([
        '            ' + STUDIO_FURNITURE_CURRENT_MARKER,
        '            <visible>String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)</visible>',
        '            <visible>!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))</visible>',
    ])
    # Put visibility on the existing outer control, right before the first image.
    if '<control type="image">' in block:
        block = block.replace('            <control type="image">', guards + nl + '            <control type="image">', 1)
    else:
        block = block.replace('        </control>', guards + nl + '        </control>', 1)
    return nl.join([f'    {STUDIO_FURNITURE_START}', block, f'    {STUDIO_FURNITURE_END}'])


def _studio_furniture_block(nl: str) -> str:
    # Fallback template only used when no saved original exists. It mirrors AF3's
    # stock Furniture_Studio layout and still uses only KPM.StudioLogo.1.
    original = nl.join([
        '    <include name="Furniture_Studio">',
        '        <control type="grouplist">',
        '            <align>right</align>',
        '            <orientation>horizontal</orientation>',
        '            <itemgap>20</itemgap>',
        '            <include>Furniture_SlidesOver</include>',
        '            <visible>!Player.HasMedia | Skin.HasSetting(Footer.DisableNowPlaying)</visible>',
        '            <visible>String.IsEmpty(ListItem.VideoCodec) | !Skin.HasSetting(Footer.EnableCodecs)</visible>',
        '            <control type="image">',
        '                <width>300</width>',
        '                <height>80</height>',
        '                <aspectratio align="right">keep</aspectratio>',
        '                <texture background="true">$VAR[Image_CombinedStudio]</texture>',
        '                <centertop>50%</centertop>',
        '            </control>',
        '        </control>',
        '    </include>',
    ])
    return _studio_furniture_block_from_original(original, nl)

def _replace_marked_block_only(text: str, start: str, end: str, replacement: str) -> Tuple[str, bool]:
    pattern = r'(?ms)\s*' + re.escape(start) + r'.*?' + re.escape(end)
    new_text, count = re.subn(pattern, '\n' + replacement, text, count=1)
    return new_text, count > 0


def _replace_studio_image_var(text: str, nl: str, state: dict) -> Tuple[str, bool]:
    replacement = _studio_image_var_block(nl)
    if STUDIO_IMAGE_VAR_START in text and STUDIO_IMAGE_VAR_END in text:
        text, did = _replace_marked_block_only(text, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END, replacement)
        if os.path.exists(state_file('reliable_studio_logos')):
            try:
                old_state = load_state('reliable_studio_logos')
                if old_state.get('original_image_var'):
                    state['original_image_var'] = old_state.get('original_image_var')
            except Exception:
                pass
        return text, did
    pattern = r'(?s)    <variable name="Image_CombinedStudio">.*?    </variable>'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Cannot find Image_CombinedStudio variable in Includes_Images.xml')
    state['original_image_var'] = match.group(0)
    return text[:match.start()] + replacement + text[match.end():], True


def _replace_studio_furniture(text: str, nl: str, state: dict) -> Tuple[str, bool]:
    original_from_state = ''
    if os.path.exists(state_file('reliable_studio_logos')):
        try:
            old_state = load_state('reliable_studio_logos')
            original_from_state = old_state.get('original_furniture') or ''
        except Exception:
            original_from_state = ''

    if STUDIO_FURNITURE_START in text and STUDIO_FURNITURE_END in text:
        # Reapply the current marked studio patch from the saved stock AF3 block
        # if possible, not from the previously rebuilt KPM block.
        original = original_from_state
        if not original:
            marked = re.search(r'(?ms)' + re.escape(STUDIO_FURNITURE_START) + r'.*?' + re.escape(STUDIO_FURNITURE_END), text)
            original = marked.group(0) if marked else ''
        replacement = _studio_furniture_block_from_original(original, nl) if original else _studio_furniture_block(nl)
        text, did = _replace_marked_block_only(text, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END, replacement)
        if original_from_state:
            state['original_furniture'] = original_from_state
        return text, did

    pattern = r'(?s)    <include name="Furniture_Studio">.*?(?=\n    <include name="Furniture_Codecs">)'
    match = re.search(pattern, text)
    if not match:
        raise RuntimeError('Cannot find Furniture_Studio include in Includes_Furniture.xml')
    original = match.group(0).rstrip('\r\n')
    state['original_furniture'] = original
    replacement = _studio_furniture_block_from_original(original, nl)
    return text[:match.start()] + replacement + text[match.end():], True


def status_reliable_studio_logos() -> str:
    images = includes_images_target()
    furniture = includes_furniture_target()
    if not os.path.exists(images) or not os.path.exists(furniture):
        return 'Missing target'
    ti = read_text(images)
    tf = read_text(furniture)
    if STUDIO_IMAGE_VAR_START in ti and STUDIO_FURNITURE_START in tf and os.path.exists(state_file('reliable_studio_logos')):
        if STUDIO_FURNITURE_CURRENT_MARKER in tf and 'KPM.StudioLogo.2' not in tf and 'KPM.StudioLogo.3' not in tf:
            return 'Patched'
        return 'Incomplete patch'
    if '<variable name="Image_CombinedStudio">' in ti and '<include name="Furniture_Studio">' in tf:
        return 'Not patched'
    return 'Unknown layout'


def patch_reliable_studio_logos() -> Result:
    name = patch_title('reliable_studio_logos', 'Reliable Studio Logos')
    if status_reliable_studio_logos() == 'Patched':
        _start_resume_close_service()
        return Result(name, 'Skipped', 'Already patched with current single-logo layout.')
    images = includes_images_target()
    furniture = includes_furniture_target()
    missing = [p for p in (images, furniture) if not os.path.exists(p)]
    if missing:
        raise FileNotFoundError('Missing target: ' + ', '.join(missing))
    snapshot('reliable_studio_logos', [images, furniture])
    state: Dict[str, object] = {'targets': {'images': images, 'furniture': furniture}}

    ti = read_text(images)
    ni = newline_of(ti)
    ti_new, did_images = _replace_studio_image_var(ti, ni, state)
    write_text(images, ti_new)

    tf = read_text(furniture)
    nf = newline_of(tf)
    tf_new, did_furniture = _replace_studio_furniture(tf, nf, state)
    write_text(furniture, tf_new)

    save_state('reliable_studio_logos', {
        **state,
        'max_logos': 1,
        'properties': ['KPM.StudioLogo.1'],
        'resource': 'resource.images.studios.coloured',
        'game_resource': 'resource.images.gamestudios.grayscale',
        'kpm_logo_resource': 'resource.images.kpm.studiologos',
        'metadata_changed': False,
    })
    _reload_skin_after_patch()
    _start_resume_close_service()
    return Result(name, 'Patched' if (did_images or did_furniture) else 'Skipped', 'AF3 now uses one KPM resolved studio logo. Movie/TV resolves coloured resource then KPM XBT per candidate; games resolve KPM XBT then grayscale per developer/publisher candidate. Regional/specific keys precede generic fallback. ReloadSkin and service start requested.')


def remove_reliable_studio_logos() -> Result:
    name = patch_title('reliable_studio_logos', 'Reliable Studio Logos')
    images = includes_images_target()
    furniture = includes_furniture_target()
    state = load_state('reliable_studio_logos') if os.path.exists(state_file('reliable_studio_logos')) else {}
    removed = []
    if os.path.exists(images):
        text = read_text(images)
        original = state.get('original_image_var') if isinstance(state, dict) else None
        if original and STUDIO_IMAGE_VAR_START in text:
            text, _ = _remove_marked_block(text, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END)
            # Insert original variable where the marked block was removed by matching a nearby double newline.
            # The removal leaves no Image_CombinedStudio variable, so put it back before Image_OSD_CombinedStudio.
            if '<variable name="Image_OSD_CombinedStudio">' in text:
                text = text.replace('    <variable name="Image_OSD_CombinedStudio">', original.rstrip('\r\n') + newline_of(text) + newline_of(text) + '    <variable name="Image_OSD_CombinedStudio">', 1)
                write_text(images, text)
                removed.append('Includes_Images.xml')
        elif STUDIO_IMAGE_VAR_START in text:
            text, did = _remove_marked_block(text, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END)
            if did:
                write_text(images, text)
                removed.append('Includes_Images.xml marker-only')

    if os.path.exists(furniture):
        text = read_text(furniture)
        original = state.get('original_furniture') if isinstance(state, dict) else None
        if original and STUDIO_FURNITURE_START in text:
            text, _ = _remove_marked_block(text, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END)
            if '    <include name="Furniture_Codecs">' in text:
                text = text.replace('    <include name="Furniture_Codecs">', original.rstrip('\r\n') + newline_of(text) + '    <include name="Furniture_Codecs">', 1)
                write_text(furniture, text)
                removed.append('Includes_Furniture.xml')
        elif STUDIO_FURNITURE_START in text:
            text, did = _remove_marked_block(text, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END)
            if did:
                write_text(furniture, text)
                removed.append('Includes_Furniture.xml marker-only')

    delete_state('reliable_studio_logos')
    if removed:
        _reload_skin_after_patch()
        return Result(name, 'Removed', 'Restored studio logo XML blocks from: {0}. ReloadSkin requested.'.format(', '.join(removed)))
    return Result(name, 'Skipped', 'Patch marker not found.')


# -----------------------------------------------------------------------------
# Tool: clear Kodi add-on icon thumbnail cache
# -----------------------------------------------------------------------------

ADDON_ICON_EXTENSIONS = ('.png', '.jpg', '.jpeg', '.webp')


def profile_database_path() -> str:
    return norm(translate('special://profile/Database'))


def thumbnails_path() -> str:
    return norm(translate('special://profile/Thumbnails'))


def latest_textures_db() -> str:
    db_dir = profile_database_path()
    if not os.path.isdir(db_dir):
        return ''
    candidates = []
    for name in os.listdir(db_dir):
        match = re.match(r'^Textures(\d+)\.db$', name, re.I)
        if match:
            candidates.append((int(match.group(1)), os.path.join(db_dir, name)))
    if not candidates:
        return ''
    candidates.sort(reverse=True)
    return candidates[0][1]


def _normalize_texture_url(value: str) -> str:
    text = unquote(str(value or '')).replace('\\', '/').lower()
    # image:// URLs often add a trailing slash after the encoded source path.
    while text.endswith('/'):
        text = text[:-1]
    return text


def _texture_table_columns(conn: sqlite3.Connection, table: str) -> List[str]:
    try:
        return [str(row[1]) for row in conn.execute(f'PRAGMA table_info({table})').fetchall()]
    except sqlite3.Error:
        return []


def _texture_table_exists(conn: sqlite3.Connection, table: str) -> bool:
    try:
        row = conn.execute('SELECT name FROM sqlite_master WHERE type=\'table\' AND name=?', (table,)).fetchone()
        return row is not None
    except sqlite3.Error:
        return False


def _looks_like_addon_icon_url(url: str) -> bool:
    text = _normalize_texture_url(url)
    if '/addons/' not in text and 'special://home/addons/' not in text and 'special://xbmc/addons/' not in text:
        return False
    # Clear all add-on icon files, not video artwork. Most add-ons use icon.png,
    # but this also catches icon.jpg/icon.webp if an add-on uses them.
    return any(text.endswith('/icon' + ext) or '/icon' + ext + '/' in text for ext in ADDON_ICON_EXTENSIONS)


def clear_addon_icon_cache() -> Result:
    name = 'Add-on Icon Cache'
    db_path = latest_textures_db()
    thumb_root = thumbnails_path()
    if not db_path or not os.path.exists(db_path):
        return Result(name, 'Skipped', 'Textures database not found.')

    removed_files = 0
    removed_rows = 0
    matched_rows: List[Tuple[int, str, str]] = []
    conn = sqlite3.connect(db_path, timeout=30)
    try:
        conn.row_factory = sqlite3.Row
        cols = _texture_table_columns(conn, 'texture')
        if not cols or 'url' not in cols:
            return Result(name, 'Skipped', 'Textures DB has no texture.url table/column.')
        id_col = 'idtexture' if 'idtexture' in cols else ('id' if 'id' in cols else cols[0])
        cached_col = 'cachedurl' if 'cachedurl' in cols else ''
        query_cols = f'{id_col}, url' + (f', {cached_col}' if cached_col else '')
        for row in conn.execute(f'SELECT {query_cols} FROM texture').fetchall():
            url = str(row['url'] or '')
            if _looks_like_addon_icon_url(url):
                cached = str(row[cached_col] or '') if cached_col else ''
                matched_rows.append((int(row[id_col]), url, cached))

        if not matched_rows:
            return Result(name, 'Skipped', 'No cached add-on icon rows found.')

        for _id, _url, cached in matched_rows:
            if cached:
                cached_path = os.path.join(thumb_root, cached.replace('/', os.sep).replace('\\', os.sep))
                if os.path.exists(cached_path):
                    try:
                        os.remove(cached_path)
                        removed_files += 1
                    except OSError:
                        pass
                # Some Kodi installs also have sidecar DDS cache for the same base name.
                base, _ext = os.path.splitext(cached_path)
                dds_path = base + '.dds'
                if os.path.exists(dds_path):
                    try:
                        os.remove(dds_path)
                        removed_files += 1
                    except OSError:
                        pass

        ids = [row[0] for row in matched_rows]
        placeholders = ','.join('?' for _ in ids)
        try:
            if _texture_table_exists(conn, 'sizes') and 'idtexture' in _texture_table_columns(conn, 'sizes'):
                conn.execute(f'DELETE FROM sizes WHERE idtexture IN ({placeholders})', ids)
        except sqlite3.Error:
            pass
        conn.execute(f'DELETE FROM texture WHERE {id_col} IN ({placeholders})', ids)
        removed_rows = conn.total_changes
        conn.commit()
    finally:
        conn.close()

    return Result(name, 'Cleared', f'Removed {len(matched_rows)} add-on icon cache rows and {removed_files} thumbnail files from {os.path.basename(db_path)}. Restart Kodi or reload skin so icons rebuild.')


def clear_addon_icon_cache_menu() -> None:
    message = (
        'Clear cached icons for all installed Kodi add-ons?\n\n'
        'This deletes only add-on icon thumbnail cache rows/files from the latest Textures DB. '
        'Original add-on icon.png files are not touched. Kodi will rebuild icons automatically.'
    )
    if not yesno(ADDON_NAME, message):
        return
    run_single(clear_addon_icon_cache)



# -----------------------------------------------------------------------------
# Diagnostics: Fullscreen pause ratings live/static export
# -----------------------------------------------------------------------------

DIAG_LIVE_DIRNAME = 'diagnostics_live'
DIAG_EXPORT_DIRNAME = 'diagnostics'
DIAG_LIVE_PREFIX = 'fullscreen-pause-ratings-live'


def _safe_call(default, func, *args):
    try:
        return func(*args)
    except Exception as exc:  # pylint: disable=broad-except
        return default if default is not None else f'ERROR: {exc}'


def info_label(expr: str) -> str:
    if xbmc:
        return _safe_call('', xbmc.getInfoLabel, expr)
    return ''


def cond_visible(expr: str) -> bool:
    if xbmc:
        try:
            return bool(xbmc.getCondVisibility(expr))
        except Exception:  # pylint: disable=broad-except
            return False
    return False


def _window_obj(window_id: int):
    if xbmcgui:
        try:
            return xbmcgui.Window(window_id)
        except Exception:  # pylint: disable=broad-except
            return None
    return None


def _window_prop(window_id: int, name: str) -> str:
    win = _window_obj(window_id)
    if not win:
        return ''
    try:
        return str(win.getProperty(name) or '')
    except Exception:  # pylint: disable=broad-except
        return ''


def _current_window_ids() -> Dict[str, int]:
    data = {'current_window_id': 0, 'current_dialog_id': 0}
    if not xbmcgui:
        return data
    for key, getter_name in (('current_window_id', 'getCurrentWindowId'), ('current_dialog_id', 'getCurrentWindowDialogId')):
        getter = getattr(xbmcgui, getter_name, None)
        if getter:
            try:
                data[key] = int(getter())
            except Exception:  # pylint: disable=broad-except
                data[key] = 0
    return data


def _lrs_property_matrix(window_ids: Optional[List[int]] = None) -> Dict[str, dict]:
    if window_ids is None:
        ids = [10000]
        current = _current_window_ids().get('current_window_id', 0)
        if current and current not in ids:
            ids.append(current)
    else:
        ids = window_ids
    services = ('Player', 'VideoPlayer', 'ListItem', 'Screensaver')
    suffixes = ('Source', 'Icon', 'IconFile', 'Label', 'Value')
    matrix: Dict[str, dict] = {}
    for wid in ids:
        wkey = str(wid)
        matrix[wkey] = {}
        for service in services:
            skey = service
            matrix[wkey][skey] = {
                'HasData': _window_prop(wid, f'LibraryRatings.{service}.HasData'),
                'ItemKey': _window_prop(wid, f'LibraryRatings.{service}.ItemKey'),
                'Title': _window_prop(wid, f'LibraryRatings.{service}.Title'),
                'DBType': _window_prop(wid, f'LibraryRatings.{service}.DBType'),
                'Display_RatingSlots': _window_prop(wid, f'LibraryRatings.{service}.Display_RatingSlots'),
                'EndsAt': {suffix: _window_prop(wid, f'LibraryRatings.{service}.EndsAt_{suffix}') for suffix in LRS_ENDSAT_SUFFIXES},
            }
            for slot in range(1, 8):
                slot_data = {}
                for suffix in suffixes:
                    slot_data[suffix] = _window_prop(wid, f'LibraryRatings.{service}.RatingSlot{slot}_{suffix}')
                matrix[wkey][skey][f'RatingSlot{slot}'] = slot_data
        matrix[wkey]['Display'] = {
            'RatingSlots': _window_prop(wid, 'LibraryRatings.Display.RatingSlots'),
            'Top250': _window_prop(wid, 'LibraryRatings.Display.Top250'),
            'Awards': _window_prop(wid, 'LibraryRatings.Display.Awards'),
            'TVStatus': _window_prop(wid, 'LibraryRatings.Display.TVStatus'),
        }
        matrix[wkey]['HomeHub'] = _lrs_homehub_display_props([wid]).get(str(wid), {})
    return matrix


def _player_runtime_state() -> Dict[str, object]:
    ids = _current_window_ids()
    return {
        'timestamp': time.strftime('%Y-%m-%d %H:%M:%S'),
        **ids,
        'conditions': {
            'Player.HasMedia': cond_visible('Player.HasMedia'),
            'Player.HasVideo': cond_visible('Player.HasVideo'),
            'Player.Playing': cond_visible('Player.Playing'),
            'Player.Paused': cond_visible('Player.Paused'),
            'Player.Seeking': cond_visible('Player.Seeking'),
            'Player.Caching': cond_visible('Player.Caching'),
            'Window.IsActive(fullscreenvideo)': cond_visible('Window.IsActive(fullscreenvideo)'),
            'Window.IsActive(VideoFullScreen.xml)': cond_visible('Window.IsActive(VideoFullScreen.xml)'),
            'Window.IsActive(videoosd)': cond_visible('Window.IsActive(videoosd)'),
            'Window.IsActive(DialogSeekBar.xml)': cond_visible('Window.IsActive(DialogSeekBar.xml)'),
            'Window.IsVisible(DialogSeekBar.xml)': cond_visible('Window.IsVisible(DialogSeekBar.xml)'),
            'Window.IsVisible(1152)': cond_visible('Window.IsVisible(1152)'),
            'Window.IsVisible(1153)': cond_visible('Window.IsVisible(1153)'),
        },
        'videoplayer_labels': {
            'Title': info_label('VideoPlayer.Title'),
            'TVShowTitle': info_label('VideoPlayer.TVShowTitle'),
            'Season': info_label('VideoPlayer.Season'),
            'Episode': info_label('VideoPlayer.Episode'),
            'DBID': info_label('VideoPlayer.DBID'),
            'DBTYPE': info_label('VideoPlayer.DBTYPE'),
            'Rating': info_label('VideoPlayer.Rating'),
            'UserRating': info_label('VideoPlayer.UserRating'),
            'Year': info_label('VideoPlayer.Year'),
            'FileNameAndPath': info_label('VideoPlayer.FileNameAndPath'),
        },
        'lrs_properties': _lrs_property_matrix(),
        'lrs_homehub_display': _lrs_homehub_display_props(),
        'lrs_strict_current_endsat': _lrs_strict_current_endsat_props(),
        'current_game_bridge': _current_game_bridge_report(),
    }


def _line_numbered_snippet(text: str, start_marker: str, end_marker: str, context: int = 8) -> str:
    lines = text.splitlines()
    start = end = -1
    for idx, line in enumerate(lines):
        if start_marker in line and start < 0:
            start = idx
        if end_marker in line:
            end = idx
            break
    if start < 0:
        return f'Marker not found: {start_marker}'
    if end < start:
        end = start
    lo = max(0, start - context)
    hi = min(len(lines), end + context + 1)
    return '\n'.join(f'{i + 1:05d}: {lines[i]}' for i in range(lo, hi))


def _full_file_digest(path: str) -> Dict[str, object]:
    data: Dict[str, object] = {'path': path, 'exists': os.path.exists(path)}
    if not os.path.exists(path):
        return data
    try:
        with open(path, 'rb') as handle:
            raw = handle.read()
        data['size'] = len(raw)
        data['mtime'] = time.strftime('%Y-%m-%d %H:%M:%S', time.localtime(os.path.getmtime(path)))
        try:
            import hashlib
            data['sha256'] = hashlib.sha256(raw).hexdigest()
        except Exception:  # pylint: disable=broad-except
            pass
    except Exception as exc:  # pylint: disable=broad-except
        data['error'] = str(exc)
    return data


def _read_file_if_exists(path: str, max_chars: int = 300000) -> str:
    if not os.path.exists(path):
        return f'File not found: {path}'
    try:
        text = read_text(path)
    except Exception as exc:  # pylint: disable=broad-except
        return f'Could not read {path}: {exc}'
    if len(text) > max_chars:
        return text[-max_chars:]
    return text


def _read_live_text_if_exists(path: str, max_chars: int = 20000000) -> str:
    """Read live JSONL without corrupting the first line.

    Old diagnostics used a raw character tail, so exported JSONL could start in the
    middle of a JSON object. Export the full file when possible or tail only
    complete lines with a marker.
    """
    if not os.path.exists(path):
        return f'File not found: {path}'
    try:
        text = read_text(path)
    except Exception as exc:  # pylint: disable=broad-except
        return f'Could not read {path}: {exc}'
    if len(text) <= max_chars:
        return text
    tail = text[-max_chars:]
    first_nl = tail.find('\n')
    if first_nl >= 0:
        tail = tail[first_nl + 1:]
    return '# KPM diagnostic note: file was too large; exported tail starts at the next complete JSONL line.\n' + tail


def _latest_kodi_log_path() -> str:
    return norm(translate('special://logpath/kodi.log'))


def _filtered_kodi_log() -> str:
    keys = ('Kodi Patch Manager', 'KPM', 'StudioLogo', 'Image_CombinedStudio', 'resource.images.studios', 'resource.images.gamestudios', 'Misplaced [', 'Library Ratings Scraper', 'LibraryRatings', 'script.library.ratings.scraper', 'Steam Library', 'plugin.program.steam.library', 'steam_rating_display', 'achievement_display', 'metacritic_score', 'DisplaySlot', 'HomeHub', 'MyPrograms.xml', 'MyVideoNav.xml', 'Custom_1101_Hub.xml', 'Custom_1103_Hub.xml', 'Includes_Info.xml', 'RatingSlot', 'EndsAt', 'FinishTime', 'fullscreenvideo', 'ERROR', 'Traceback', 'Skin Helper Service')
    return _filtered_kodi_log_for_keys(keys)




# -----------------------------------------------------------------------------
# LRS / Steam Library focused diagnostics (v0.1.79)
# Diagnostics/status only: no rendering XML patch, no Steam lower meta row patch.
# -----------------------------------------------------------------------------

LRS_STEAM_LOG_KEYS = (
    'Kodi Patch Manager', 'KPM', 'Library Ratings Scraper', 'LibraryRatings',
    'script.library.ratings.scraper', 'Steam Library', 'plugin.program.steam.library',
    'steam_rating_display', 'achievement_display', 'metacritic_score',
    'DisplaySlot', 'HomeHub', 'MyPrograms.xml', 'MyVideoNav.xml',
    'Custom_1101_Hub.xml', 'Custom_1103_Hub.xml', 'Includes_Info.xml',
    'RatingSlot', 'EndsAt', 'FinishTime', 'ERROR', 'Traceback'
)

LRS_HOMEHUB_BASE_PROPS = (
    'DisplayActive', 'DisplayMode', 'ItemKey', 'Title', 'DBType', 'Context',
    'Display_RatingSlots'
)

LRS_SLOT_SUFFIXES = ('Source', 'Icon', 'IconFile', 'Label', 'Value')
LRS_ENDSAT_SUFFIXES = ('Label', 'IconFile', 'Value', 'Source')

GAME_BRIDGE_PROPS = (
    'platform', 'is_steam_library', 'mediahub_item_key', 'steam_appid', 'appid',
    'steam_rating_display', 'steam_review_percent', 'steam_review_desc', 'steam_review_total',
    'metacritic_score', 'achievement_display', 'achievement_unlocked', 'achievement_total',
    'lrs_game', 'lrs_item_type', 'library_ratings_type', 'DBTYPE', 'MediaType',
    'developer', 'developer_display', 'publisher', 'publisher_display'
)

AF3_LRS_CONTEXT_XMLS = (
    'Includes_Info.xml', 'Home.xml', 'MyPrograms.xml', 'MyVideoNav.xml',
    'Custom_1101_Hub.xml', 'Custom_1102_Hub.xml', 'Custom_1103_Hub.xml'
)


AF3_FULL_CONTEXT_XMLS = (
    'Includes_Info.xml', 'Home.xml', 'MyPrograms.xml', 'MyVideoNav.xml',
    'Custom_1101_Hub.xml', 'Custom_1102_Hub.xml', 'Custom_1103_Hub.xml',
    'Includes_Images.xml', 'Includes_Furniture.xml', 'Includes_OSD.xml',
    'VideoOSD.xml', 'DialogSeekBar.xml', 'Includes_Actions.xml', 'Includes_Defaults.xml'
)

FULL_SYSTEM_ADDONS = {
    'kpm': ADDON_ID,
    'lrs': 'script.library.ratings.scraper',
    'steam_library': 'plugin.program.steam.library',
    'lac': 'script.artwork.curator',
    'mediahub': 'plugin.video.mediahub.widget',
}

SENSITIVE_SETTING_RE = re.compile(r'(apikey|api_key|key|clientkey|client-key|token|secret|password|pass)', re.I)

FULL_SYSTEM_LOG_KEYS = (
    'Kodi Patch Manager', 'KPM',
    'Library Ratings Scraper', 'LibraryRatings', 'script.library.ratings.scraper',
    'Steam Library', 'plugin.program.steam.library', 'steam_rating_display', 'achievement_display', 'metacritic_score',
    'Library Artwork Curator', 'script.artwork.curator', 'ArtworkProcessor', 'LAC', 'cropv2', 'CropV2',
    'MediaHub', 'plugin.video.mediahub.widget', 'Artwork filters', 'clearlogo', 'fanart', 'Textures', 'Texture DB',
    'DisplaySlot', 'HomeHub', 'RatingSlot', 'EndsAt', 'FinishTime',
    'Home.xml', 'MyPrograms.xml', 'MyVideoNav.xml', 'Custom_1101_Hub.xml', 'Custom_1102_Hub.xml', 'Custom_1103_Hub.xml', 'Includes_Info.xml',
    'ERROR', 'WARNING', 'Traceback', 'Exception'
)

ART_LABELS = (
    'poster', 'thumb', 'fanart', 'landscape', 'clearlogo', 'logo', 'clearart', 'banner',
    'tvshow.poster', 'tvshow.thumb', 'tvshow.fanart', 'tvshow.landscape', 'tvshow.clearlogo', 'season.poster', 'season.thumb'
)

CROPV2_XML_PATTERNS = (
    'cropv2', 'CropV2', 'clearlogo', 'ClearLogo', 'fanart', 'Fanart', 'landscape',
    'Image_Crop', 'Image_Blur', 'Image_Fanart', 'KPM-CROP', 'MEDIAHUB', 'LAC'
)


def _redact_sensitive_settings_text(text: str) -> str:
    """Redact likely API keys/tokens in copied settings files while preserving structure."""
    if not text:
        return text

    def redact_value_attr(match: re.Match) -> str:
        whole = match.group(0)
        sid = match.group(1) or ''
        if SENSITIVE_SETTING_RE.search(sid):
            return re.sub(r'\bvalue=("|\')[^"\']*(\1)', 'value="[redacted]"', whole, flags=re.I)
        return whole

    # Kodi settings v2 style: <setting id="foo" value="bar" />
    text = re.sub(r'<setting\b[^>]*(?:id|name)=(?:"|\')([^"\']+)(?:"|\')[^>]*\bvalue=(?:"|\')[^"\']*(?:"|\')[^>]*/?>', redact_value_attr, text, flags=re.I)

    # Kodi settings v1 style: <setting id="foo">bar</setting>
    def redact_node(match: re.Match) -> str:
        open_tag, sid, value, close_tag = match.group(1), match.group(2), match.group(3), match.group(4)
        if SENSITIVE_SETTING_RE.search(sid or ''):
            return open_tag + '[redacted]' + close_tag
        return match.group(0)

    text = re.sub(r'(<setting\b[^>]*(?:id|name)=(?:"|\')([^"\']+)(?:"|\')[^>]*>)(.*?)(</setting>)', redact_node, text, flags=re.I | re.S)
    return text


def _read_text_redacted_if_settings(path: str, max_chars: int = 3000000) -> str:
    text = _read_file_if_exists(path, max_chars)
    if os.path.basename(path).lower() == 'settings.xml':
        return _redact_sensitive_settings_text(text)
    return text


def _addon_base_dirs(addon_id: str) -> Dict[str, str]:
    return {
        'addon_dir': norm(translate(f'special://home/addons/{addon_id}')),
        'profile_dir': norm(translate(f'special://profile/addon_data/{addon_id}')),
    }


def _addon_basic_report(addon_id: str) -> Dict[str, object]:
    dirs = _addon_base_dirs(addon_id)
    addon_xml = norm(os.path.join(dirs['addon_dir'], 'addon.xml'))
    settings_xml = norm(os.path.join(dirs['profile_dir'], 'settings.xml'))
    return {
        'addon_id': addon_id,
        'version': _addon_version_from_addon_xml(addon_id),
        'addon_dir': dirs['addon_dir'],
        'profile_dir': dirs['profile_dir'],
        'addon_xml': _full_file_digest(addon_xml),
        'profile_settings_xml': _full_file_digest(settings_xml),
    }


def _profile_db_digests(addon_id: str, max_files: int = 40) -> Dict[str, object]:
    profile = _addon_base_dirs(addon_id)['profile_dir']
    result: Dict[str, object] = {'profile_dir': profile, 'databases': []}
    if not os.path.isdir(profile):
        result['exists'] = False
        return result
    items = []
    for root, _dirs, files in os.walk(profile):
        for fname in files:
            if fname.lower().endswith(('.db', '.sqlite', '.sqlite3')):
                fpath = os.path.join(root, fname)
                try:
                    items.append((os.path.getmtime(fpath), fpath))
                except Exception:
                    items.append((0, fpath))
    items.sort(reverse=True)
    for _mtime, fpath in items[:max_files]:
        digest = _safe_db_digest(fpath)
        digest['relative_path'] = os.path.relpath(fpath, profile).replace(os.sep, '/')
        result['databases'].append(digest)
    return result


def _copy_recent_text_tree(files_to_write: Dict[str, str], root_dir: str, rel_prefix: str, max_files: int = 60, max_chars: int = 600000) -> None:
    if not os.path.isdir(root_dir):
        files_to_write[rel_prefix.rstrip('/') + '/_missing.txt'] = f'Missing directory: {root_dir}'
        return
    allowed_ext = ('.txt', '.log', '.json', '.jsonl', '.xml', '.csv', '.md')
    blocked_ext = ('.zip', '.db', '.sqlite', '.sqlite3', '.png', '.jpg', '.jpeg', '.webp', '.gif', '.mp4', '.mkv')
    candidates = []
    for root, _dirs, files in os.walk(root_dir):
        for fname in files:
            lower = fname.lower()
            if lower.endswith(blocked_ext):
                continue
            if not lower.endswith(allowed_ext):
                continue
            fpath = os.path.join(root, fname)
            try:
                candidates.append((os.path.getmtime(fpath), fpath))
            except Exception:
                candidates.append((0, fpath))
    candidates.sort(reverse=True)
    manifest = []
    for _mtime, fpath in candidates[:max_files]:
        rel = os.path.relpath(fpath, root_dir).replace(os.sep, '/')
        manifest.append(_full_file_digest(fpath))
        files_to_write[f'{rel_prefix.rstrip("/")}/{rel}'] = _read_text_redacted_if_settings(fpath, max_chars)
    files_to_write[rel_prefix.rstrip('/') + '/_manifest.json'] = json.dumps(manifest, indent=2, ensure_ascii=False)


def _copy_addon_snapshot(files_to_write: Dict[str, str], rel_root: str, addon_id: str, addon_files: Optional[List[str]] = None, profile_dirs: Optional[List[str]] = None) -> None:
    dirs = _addon_base_dirs(addon_id)
    files_to_write[f'{rel_root}/addon-basic.json'] = json.dumps(_addon_basic_report(addon_id), indent=2, ensure_ascii=False)
    files_to_write[f'{rel_root}/profile-db-digests.json'] = json.dumps(_profile_db_digests(addon_id), indent=2, ensure_ascii=False)
    addon_files = addon_files or ['addon.xml']
    for rel in addon_files:
        path = norm(os.path.join(dirs['addon_dir'], *rel.split('/')))
        if os.path.exists(path):
            files_to_write[f'{rel_root}/addon/{rel}'] = _read_text_redacted_if_settings(path, 1500000)
    settings = norm(os.path.join(dirs['profile_dir'], 'settings.xml'))
    if os.path.exists(settings):
        files_to_write[f'{rel_root}/profile/settings.xml'] = _read_text_redacted_if_settings(settings, 400000)
    for sub in (profile_dirs or ['runtime/logs', 'runtime/diagnostics', 'runtime/reports']):
        _copy_recent_text_tree(files_to_write, norm(os.path.join(dirs['profile_dir'], *sub.split('/'))), f'{rel_root}/profile/{sub}', max_files=40, max_chars=700000)


def _shared_icons_report() -> Dict[str, object]:
    root = norm(os.path.join(translate(f'special://home/addons/{ADDON_ID}'), 'resources', 'media', 'shared-icons'))
    report: Dict[str, object] = {'path': root, 'exists': os.path.isdir(root), 'icons': {}, 'invalid_alias_names': {}}
    expected = ('certified.png', 'emmys.png', 'ends.png', 'sets.png', 'imdb.png', 'letterboxd.png', 'metacritic.png', 'oscars.png', 'oscars_bp.png', 'popcorn.png', 'popcorn_spilt.png', 'rtfresh.png', 'rtrotten.png', 'steam-ach.png', 'steam-dev.png', 'steam-game-completed.png', 'steam-game-finished.png', 'steam-pub.png', 'steam.png', 'tmdb.png', 'trakt.png', 'verified.png')
    bad = ('stema-ach.png', 'oscars-bp.png', 'verifiedhot.png', 'verified-hot.png', 'verified_hot.png')
    for name in expected:
        report['icons'][name] = _full_file_digest(os.path.join(root, name))
    for name in bad:
        report['invalid_alias_names'][name] = os.path.exists(os.path.join(root, name))
    return report


def _info_art(prefix: str) -> Dict[str, str]:
    data: Dict[str, str] = {}
    for art in ART_LABELS:
        data[art] = info_label(f'{prefix}.Art({art})')
    return data


def _current_item_snapshot() -> Dict[str, object]:
    prefixes = ('ListItem', 'Container.ListItem', 'VideoPlayer')
    result: Dict[str, object] = {'window_ids': _current_window_ids(), 'prefixes': {}}
    base_labels = ('Label', 'Title', 'OriginalTitle', 'TVShowTitle', 'DBID', 'DBTYPE', 'MediaType', 'Year', 'Duration', 'Genre', 'FileNameAndPath', 'FolderPath', 'EndTimeResume', 'FinishTime')
    prop_names = tuple(dict.fromkeys(GAME_BRIDGE_PROPS + (
        'mediatype', 'dbtype', 'DBType', 'lrs_media_type', 'mediahub_type',
        'RatingSlot1_Label', 'RatingSlot1_Value', 'RatingSlot1_Source', 'RatingSlot1_IconFile',
        'RatingSlot2_Label', 'RatingSlot2_Value', 'RatingSlot2_Source', 'RatingSlot2_IconFile',
        'RatingSlot3_Label', 'RatingSlot3_Value', 'RatingSlot3_Source', 'RatingSlot3_IconFile',
    )))
    for prefix in prefixes:
        entry: Dict[str, object] = {}
        entry['labels'] = {name: info_label(f'{prefix}.{name}') for name in base_labels}
        entry['art'] = _info_art(prefix)
        entry['properties'] = {name: info_label(f'{prefix}.Property({name})') for name in prop_names}
        result['prefixes'][prefix] = entry
    return result


def _latest_textures_db_path() -> str:
    db_dir = norm(translate('special://profile/Database'))
    candidates = []
    if os.path.isdir(db_dir):
        for fname in os.listdir(db_dir):
            if re.match(r'Textures\d*\.db$', fname, re.I):
                path = os.path.join(db_dir, fname)
                try:
                    candidates.append((int(re.sub(r'\D', '', fname) or '0'), os.path.getmtime(path), path))
                except Exception:
                    candidates.append((0, 0, path))
    candidates.sort(reverse=True)
    return candidates[0][2] if candidates else ''


def _texture_lookup_for_art(uri: str, limit: int = 5) -> Dict[str, object]:
    uri = str(uri or '').strip()
    path = _latest_textures_db_path()
    result: Dict[str, object] = {'art': uri, 'textures_db': path, 'textures_db_digest': _safe_db_digest(path) if path else {'exists': False}, 'matches': []}
    if not uri or not path or not os.path.exists(path):
        return result
    needles = [uri, quote(uri, safe='')]
    try:
        con = sqlite3.connect(path)
        cur = con.cursor()
        rows = []
        for needle in needles:
            if not needle:
                continue
            try:
                rows.extend(cur.execute("SELECT url, cachedurl, width, height FROM texture WHERE url LIKE ? LIMIT ?", ('%' + needle + '%', limit)).fetchall())
            except Exception:
                # Some Kodi versions use slightly different texture schemas.
                rows.extend(cur.execute("SELECT url, cachedurl FROM texture WHERE url LIKE ? LIMIT ?", ('%' + needle + '%', limit)).fetchall())
        con.close()
        seen = set()
        for row in rows:
            key = repr(row)
            if key in seen:
                continue
            seen.add(key)
            item = {'url': row[0] if len(row) > 0 else '', 'cachedurl': row[1] if len(row) > 1 else ''}
            if len(row) > 3:
                item.update({'width': row[2], 'height': row[3]})
            result['matches'].append(item)
    except Exception as exc:
        result['error'] = str(exc)
    return result


def _mediahub_settings_snapshot() -> Dict[str, object]:
    profile = _addon_base_dirs('plugin.video.mediahub.widget')['profile_dir']
    settings = norm(os.path.join(profile, 'settings.xml'))
    result = {'settings_xml': _full_file_digest(settings), 'parsed': {}}
    text = _read_file_if_exists(settings, 300000) if os.path.exists(settings) else ''
    for sid in ('exclude_fanart_below_1080p', 'exclude_without_clearlogo', 'include_movies', 'include_series', 'include_games', 'default_limit', 'default_random', 'steam_addon_id'):
        m = re.search(r'<setting\b[^>]*id=["\']' + re.escape(sid) + r'["\'][^>]*value=["\']([^"\']*)["\']', text, re.I)
        if not m:
            m = re.search(r'<setting\b[^>]*id=["\']' + re.escape(sid) + r'["\'][^>]*>(.*?)</setting>', text, re.I | re.S)
        result['parsed'][sid] = (m.group(1).strip() if m else '')
    return result


def _lac_settings_snapshot() -> Dict[str, object]:
    profile = _addon_base_dirs('script.artwork.curator')['profile_dir']
    settings = norm(os.path.join(profile, 'settings.xml'))
    result = {'settings_xml': _full_file_digest(settings), 'parsed': {}}
    text = _read_file_if_exists(settings, 300000) if os.path.exists(settings) else ''
    for sid in ('minimum_fanart_resolution', 'titlefree_fanart', 'enable_fanarttv', 'enable_tmdb', 'enable_tvdb'):
        m = re.search(r'<setting\b[^>]*id=["\']' + re.escape(sid) + r'["\'][^>]*value=["\']([^"\']*)["\']', text, re.I)
        if not m:
            m = re.search(r'<setting\b[^>]*id=["\']' + re.escape(sid) + r'["\'][^>]*>(.*?)</setting>', text, re.I | re.S)
        result['parsed'][sid] = (m.group(1).strip() if m else '')
    return result


def _cropv2_diagnostics_report() -> Dict[str, object]:
    current = _current_item_snapshot()
    art_values = []
    for pdata in current.get('prefixes', {}).values():
        art = pdata.get('art', {}) if isinstance(pdata, dict) else {}
        if isinstance(art, dict):
            for key in ('fanart', 'landscape', 'thumb', 'poster', 'clearlogo', 'tvshow.fanart', 'tvshow.clearlogo'):
                val = art.get(key)
                if val and val not in art_values:
                    art_values.append(val)
    texture_lookups = {f'art_{idx+1}': _texture_lookup_for_art(uri) for idx, uri in enumerate(art_values[:12])}
    xml_markers: Dict[str, object] = {}
    for fname in AF3_FULL_CONTEXT_XMLS:
        path = af3_path('1080i', fname)
        text = _read_file_if_exists(path, 1500000)
        marker_lines = []
        for lineno, line in enumerate(text.splitlines(), 1):
            if any(pattern.lower() in line.lower() for pattern in CROPV2_XML_PATTERNS):
                marker_lines.append(f'{lineno:05d}: {line}')
                if len(marker_lines) >= 120:
                    break
        xml_markers[fname] = marker_lines
    return {
        'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'scope': 'cropV2 visual/path/filter diagnostics only; artwork scraping remains in LAC/MediaHub',
        'current_item': current,
        'mediahub_settings': _mediahub_settings_snapshot(),
        'lac_settings': _lac_settings_snapshot(),
        'texture_db_current_art_lookup': texture_lookups,
        'xml_cropv2_marker_lines': xml_markers,
        'expected_filter_policy': {
            'exclude_without_clearlogo_setting': 'plugin.video.mediahub.widget: exclude_without_clearlogo',
            'exclude_fanart_below_1080p_setting': 'plugin.video.mediahub.widget: exclude_fanart_below_1080p',
            'texture_db_source': 'special://profile/Database/Textures*.db',
            'visual_owner_target': 'KPM full diagnostics + future KPM visual patching; LAC/MediaHub remain data providers',
        },
    }


def _xml_marker_scan_report() -> Dict[str, object]:
    patterns = ('KPM-', 'LRS-', 'LRS-AF3', 'STEAM-LIBRARY', 'DisplaySlot', 'RatingSlot', 'cropv2', 'CropV2', 'KPM-CROP', 'LRS_AF3', 'steam_rating_display', 'achievement_display', 'metacritic_score')
    report: Dict[str, object] = {}
    for fname in AF3_FULL_CONTEXT_XMLS:
        path = af3_path('1080i', fname)
        text = _read_file_if_exists(path, 2500000)
        lines = []
        counts = {pattern: text.count(pattern) for pattern in patterns}
        for lineno, line in enumerate(text.splitlines(), 1):
            if any(pattern in line for pattern in patterns):
                lines.append(f'{lineno:05d}: {line}')
                if len(lines) >= 220:
                    break
        report[fname] = {'path': path, 'digest': _full_file_digest(path), 'counts': counts, 'marker_lines': lines}
    return report


def _full_system_versions_report() -> Dict[str, str]:
    return {key: _addon_version_from_addon_xml(addon_id) if key != 'kpm' else VERSION for key, addon_id in FULL_SYSTEM_ADDONS.items()}


def _full_system_runtime_report() -> Dict[str, object]:
    return {
        'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'versions': _full_system_versions_report(),
        'player_runtime': _player_runtime_state(),
        'current_item_snapshot': _current_item_snapshot(),
        'cropv2': _cropv2_diagnostics_report(),
        'shared_icons': _shared_icons_report(),
    }


def _filtered_full_system_kodi_log() -> str:
    return _filtered_kodi_log_for_keys(FULL_SYSTEM_LOG_KEYS)


def _full_system_summary(runtime: Dict[str, object]) -> str:
    lines = []
    lines.append(f'{ADDON_NAME} Full System Diagnostics v{VERSION}')
    lines.append(f'Generated: {time.strftime("%Y-%m-%d %H:%M:%S")}')
    lines.append('Scope: one ZIP for visual/XML/pathing/service integration. Scraping/provider internals remain owned by LRS, Steam Library, and LAC.')
    lines.append('')
    lines.append('Versions:')
    lines.append(json.dumps(runtime.get('versions', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Current item snapshot:')
    lines.append(json.dumps(runtime.get('current_item_snapshot', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('KPM/LRS visual runtime snapshot:')
    lines.append(json.dumps(runtime.get('player_runtime', {}), indent=2, ensure_ascii=False))
    return '\n'.join(lines)


def _add_full_system_diagnostic_files(files_to_write: Dict[str, str], stamp: str) -> None:
    runtime = _full_system_runtime_report()
    files_to_write['summary/full-system-summary.txt'] = _full_system_summary(runtime)
    files_to_write['kpm/runtime/full-system-runtime.json'] = json.dumps(runtime, indent=2, ensure_ascii=False)
    files_to_write['kpm/runtime/current-item-snapshot.json'] = json.dumps(runtime.get('current_item_snapshot', {}), indent=2, ensure_ascii=False)
    files_to_write['kpm/runtime/cropv2-diagnostics.json'] = json.dumps(runtime.get('cropv2', {}), indent=2, ensure_ascii=False)
    files_to_write['kpm/runtime/shared-icons.json'] = json.dumps(runtime.get('shared_icons', {}), indent=2, ensure_ascii=False)
    files_to_write['kpm/runtime/xml-marker-scan.json'] = json.dumps(_xml_marker_scan_report(), indent=2, ensure_ascii=False)
    files_to_write['kpm/logs/kodi-log-full-filtered.txt'] = _filtered_full_system_kodi_log()
    files_to_write['kpm/patch-status.txt'] = patch_status_summary()

    # Add-on snapshots: text/config/logs only; DBs are digests only.
    _copy_addon_snapshot(files_to_write, 'addons/kpm', ADDON_ID, ['addon.xml', 'default.py', 'service.py', 'resources/lib/main.py'], ['runtime/logs', 'runtime/diagnostics', 'runtime/reports'])
    _copy_addon_snapshot(files_to_write, 'addons/lrs', 'script.library.ratings.scraper', ['addon.xml', 'default.py', 'service.py', 'resources/lib/core.py'], ['runtime/logs', 'runtime/diagnostics', 'runtime/reports', 'logs', 'cache'])
    _copy_addon_snapshot(files_to_write, 'addons/steam_library', 'plugin.program.steam.library', ['addon.xml', 'addon.py'], ['runtime/logs', 'runtime/diagnostics', 'runtime/reports', 'reports', 'logs'])
    _copy_addon_snapshot(files_to_write, 'addons/lac', 'script.artwork.curator', ['addon.xml', 'default.py', 'service.py', 'lib/diagnostics.py', 'lib/artworkprocessor.py'], ['runtime/logs', 'runtime/diagnostics', 'runtime/reports', 'reports', 'logs'])
    _copy_addon_snapshot(files_to_write, 'addons/mediahub', 'plugin.video.mediahub.widget', ['addon.xml', 'addon.py'], ['runtime/logs', 'runtime/diagnostics', 'runtime/reports', 'logs'])

    # Full AF3 XML context files and every Custom_*_Hub.xml.
    for fname in AF3_FULL_CONTEXT_XMLS:
        _copy_text_file_to_diag(files_to_write, f'xml/1080i/{fname}', af3_path('1080i', fname), 6000000)
    try:
        for fname in sorted(os.listdir(af3_path('1080i'))):
            if re.match(r'Custom_.*_Hub\.xml$', fname, re.I) and f'xml/1080i/{fname}' not in files_to_write:
                _copy_text_file_to_diag(files_to_write, f'xml/1080i/{fname}', af3_path('1080i', fname), 3000000)
    except Exception:
        pass
    files_to_write['xml/xml-context-snippets.json'] = json.dumps(_xml_context_snippets(), indent=2, ensure_ascii=False)

def _addon_version_from_addon_xml(addon_id: str) -> str:
    path = norm(os.path.join(translate(f'special://home/addons/{addon_id}'), 'addon.xml'))
    try:
        text = read_text(path)
    except Exception:
        return ''
    match = re.search(r'<addon\b[^>]*\bversion=["\']([^"\']+)["\']', text, re.I)
    return match.group(1).strip() if match else ''


def _safe_db_digest(path: str) -> Dict[str, object]:
    data = _full_file_digest(path)
    data['raw_dumped'] = False
    data['policy'] = 'digest_only'
    return data


def _lrs_homehub_display_props(window_ids: Optional[List[int]] = None) -> Dict[str, dict]:
    if window_ids is None:
        ids = [10000]
        current = _current_window_ids().get('current_window_id', 0)
        if current and current not in ids:
            ids.append(current)
    else:
        ids = window_ids
    result: Dict[str, dict] = {}
    for wid in ids:
        entry: Dict[str, object] = {}
        for prop in LRS_HOMEHUB_BASE_PROPS:
            entry[prop] = _window_prop(wid, f'LibraryRatings.HomeHub.{prop}')
        for suffix in LRS_ENDSAT_SUFFIXES:
            entry[f'EndsAt_{suffix}'] = _window_prop(wid, f'LibraryRatings.HomeHub.EndsAt_{suffix}')
        for slot in range(1, 11):
            slot_data = {}
            for suffix in LRS_SLOT_SUFFIXES:
                slot_data[suffix] = _window_prop(wid, f'LibraryRatings.HomeHub.DisplaySlot{slot}_{suffix}')
            entry[f'DisplaySlot{slot}'] = slot_data
        result[str(wid)] = entry
    return result


def _lrs_strict_current_endsat_props(window_ids: Optional[List[int]] = None) -> Dict[str, dict]:
    if window_ids is None:
        ids = [10000]
        current = _current_window_ids().get('current_window_id', 0)
        if current and current not in ids:
            ids.append(current)
    else:
        ids = window_ids
    result: Dict[str, dict] = {}
    for wid in ids:
        entry: Dict[str, dict] = {}
        for service in ('ListItem', 'HomeHub'):
            ends = {}
            for suffix in LRS_ENDSAT_SUFFIXES:
                ends[suffix] = _window_prop(wid, f'LibraryRatings.{service}.EndsAt_{suffix}')
            entry[service] = ends
        result[str(wid)] = entry
    return result


def _game_bridge_for_prefix(prefix: str) -> Dict[str, object]:
    entry: Dict[str, object] = {
        'Label': info_label(f'{prefix}.Label'),
        'Title': info_label(f'{prefix}.Title'),
        'DBTYPE': info_label(f'{prefix}.DBTYPE'),
        'DBID': info_label(f'{prefix}.DBID'),
        'FileNameAndPath': info_label(f'{prefix}.FileNameAndPath'),
        'FolderPath': info_label(f'{prefix}.FolderPath'),
    }
    entry['properties'] = {prop: info_label(f'{prefix}.Property({prop})') for prop in GAME_BRIDGE_PROPS}
    slots: Dict[str, dict] = {}
    for slot in range(1, 8):
        slot_data = {}
        for suffix in LRS_SLOT_SUFFIXES:
            slot_data[suffix] = info_label(f'{prefix}.Property(RatingSlot{slot}_{suffix})')
        slots[f'RatingSlot{slot}'] = slot_data
    entry['rating_slots'] = slots
    return entry


def _current_game_bridge_report() -> Dict[str, object]:
    return {
        'Container.ListItem': _game_bridge_for_prefix('Container.ListItem'),
        'ListItem': _game_bridge_for_prefix('ListItem'),
    }


def _steam_library_files_report() -> Dict[str, object]:
    steam_addon_dir = norm(translate('special://home/addons/plugin.program.steam.library'))
    steam_profile = norm(translate('special://profile/addon_data/plugin.program.steam.library'))
    files = {
        'addon.xml': norm(os.path.join(steam_addon_dir, 'addon.xml')),
        'addon.py': norm(os.path.join(steam_addon_dir, 'addon.py')),
        'settings.xml': norm(os.path.join(steam_profile, 'settings.xml')),
        'steam_library.db': norm(os.path.join(steam_profile, 'steam_library.db')),
    }
    report: Dict[str, object] = {}
    for name, path in files.items():
        report[name] = _safe_db_digest(path) if name.endswith('.db') else _full_file_digest(path)
    return report


def _af3_lrs_xml_files_report() -> Dict[str, object]:
    report: Dict[str, object] = {}
    for fname in AF3_LRS_CONTEXT_XMLS:
        report[fname] = _full_file_digest(af3_path('1080i', fname))
    hub_dir = af3_path('1080i')
    custom_hubs = []
    try:
        for fname in sorted(os.listdir(hub_dir)):
            if re.match(r'Custom_.*_Hub\.xml$', fname, re.I):
                path = af3_path('1080i', fname)
                custom_hubs.append(_full_file_digest(path))
    except Exception:
        pass
    report['all_Custom_*_Hub.xml'] = custom_hubs
    return report


def _xml_context_snippets() -> Dict[str, str]:
    snippets: Dict[str, str] = {}
    names = list(AF3_LRS_CONTEXT_XMLS)
    try:
        for fname in sorted(os.listdir(af3_path('1080i'))):
            if re.match(r'Custom_.*_Hub\.xml$', fname, re.I) and fname not in names:
                names.append(fname)
    except Exception:
        pass
    for fname in names:
        path = af3_path('1080i', fname)
        text = _read_file_if_exists(path, 1000000)
        chunks = []
        for pattern in ('Info_Panel', 'Info_Meta', 'Includes_Info', 'RatingSlot', 'DisplaySlot', 'HomeHub', 'EndsAt', 'FinishTime'):
            snippet = _line_numbered_snippet(text, pattern, pattern)
            if snippet and 'Marker not found' not in snippet:
                chunks.append(f'--- {pattern} ---\n{snippet}')
        snippets[fname] = '\n\n'.join(chunks) if chunks else 'No focused Info_Panel/Info_Meta/LRS markers found.'
    return snippets


def _lrs_steam_versions_report() -> Dict[str, str]:
    return {
        'kpm': VERSION,
        'lrs': _addon_version_from_addon_xml('script.library.ratings.scraper'),
        'steam_library': _addon_version_from_addon_xml('plugin.program.steam.library'),
    }


def _lrs_steam_runtime_state() -> Dict[str, object]:
    runtime = _player_runtime_state()
    runtime['versions'] = _lrs_steam_versions_report()
    runtime['lrs_homehub_display'] = _lrs_homehub_display_props()
    runtime['lrs_strict_current_endsat'] = _lrs_strict_current_endsat_props()
    runtime['current_game_bridge'] = _current_game_bridge_report()
    runtime['notes'] = {
        'scope': 'diagnostics/status only',
        'no_lower_meta_row_patching': True,
        'no_lrs_render_xml_modifications': True,
    }
    return runtime


def _filtered_kodi_log_for_keys(keys: tuple[str, ...]) -> str:
    path = _latest_kodi_log_path()
    text = _read_file_if_exists(path, 700000)
    out = []
    lowered = tuple(k.lower() for k in keys)
    for line in text.splitlines():
        lline = line.lower()
        if any(k in lline for k in lowered):
            out.append(line)
    return '\n'.join(out[-3000:]) if out else 'No matching lines found in kodi.log tail.'


def _lrs_steam_filtered_kodi_log() -> str:
    return _filtered_kodi_log_for_keys(LRS_STEAM_LOG_KEYS)


def _lrs_steam_summary(runtime: dict, steam_report: dict, af3_report: dict) -> str:
    lines = []
    lines.append(f'{ADDON_NAME} LRS / Steam Library diagnostics v{VERSION}')
    lines.append(f'Generated: {time.strftime("%Y-%m-%d %H:%M:%S")}')
    lines.append('Scope: diagnostics/status only; no LRS/Steam Library rendering XML or lower meta rows are patched by KPM.')
    lines.append('')
    lines.append('Versions:')
    lines.append(json.dumps(runtime.get('versions', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Runtime LRS/HomeHub/ListItem/container state:')
    lines.append(json.dumps(runtime, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Steam Library target files:')
    lines.append(json.dumps(steam_report, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('AF3 XML context files:')
    lines.append(json.dumps(af3_report, indent=2, ensure_ascii=False))
    return '\n'.join(lines)


def _copy_text_file_to_diag(files_to_write: Dict[str, str], rel: str, path: str, max_chars: int = 3000000) -> None:
    if os.path.exists(path):
        files_to_write[rel] = _read_text_redacted_if_settings(path, max_chars)
    else:
        files_to_write[rel + '.missing.txt'] = f'Missing file: {path}'


def export_lrs_steam_diagnostics() -> Result:
    name = 'Export LRS / Steam Library Diagnostics'
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_dir = addon_data_dir('runtime', 'exports', 'lrs-steam-diagnostics', stamp)
    zip_path = os.path.join(addon_data_dir(), f'kpm-lrs-steam-diagnostics-{stamp}.zip')
    runtime = _lrs_steam_runtime_state()
    steam_report = _steam_library_files_report()
    af3_report = _af3_lrs_xml_files_report()
    snippets = _xml_context_snippets()

    files_to_write: Dict[str, str] = {
        'summary.txt': _lrs_steam_summary(runtime, steam_report, af3_report),
        'runtime.json': json.dumps(runtime, indent=2, ensure_ascii=False),
        'target-files.json': json.dumps({
            'steam_library': steam_report,
            'af3_lrs_context_xml': af3_report,
            'lrs': {
                'addon.xml': _full_file_digest(norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml'))),
                'settings.xml': _full_file_digest(norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml'))),
            },
            'kpm': {
                'version': VERSION,
                'service.py': _full_file_digest(norm(os.path.join(translate(f'special://home/addons/{ADDON_ID}'), 'service.py'))),
                'main.py': _full_file_digest(norm(os.path.join(translate(f'special://home/addons/{ADDON_ID}'), 'resources', 'lib', 'main.py'))),
            },
        }, indent=2, ensure_ascii=False),
        'patch-status.txt': patch_status_summary(),
        'kpm-xbt-resource-manifest.json': _read_file_if_exists(norm(os.path.join(translate('special://home/addons/resource.images.kpm.studiologos'), 'resources', 'manifest.json')), 5000000),
        'kpm-xbt-resource-aliases.json': _read_file_if_exists(norm(os.path.join(translate('special://home/addons/resource.images.kpm.studiologos'), 'resources', 'aliases.json')), 300000),
        'kpm-xbt-resource-build-report.json': _read_file_if_exists(norm(os.path.join(translate('special://home/addons/resource.images.kpm.studiologos'), 'resources', 'build-report.json')), 300000),
        'kodi-log-lrs-steam-filtered.txt': _lrs_steam_filtered_kodi_log(),
        'xml-context-snippets.json': json.dumps(snippets, indent=2, ensure_ascii=False),
        'versions.json': json.dumps(runtime.get('versions', {}), indent=2, ensure_ascii=False),
    }

    # Steam Library files: include text metadata/settings, DB digest only.
    steam_addon_dir = norm(translate('special://home/addons/plugin.program.steam.library'))
    steam_profile = norm(translate('special://profile/addon_data/plugin.program.steam.library'))
    _copy_text_file_to_diag(files_to_write, 'steam-library/addon.xml', norm(os.path.join(steam_addon_dir, 'addon.xml')), 300000)
    _copy_text_file_to_diag(files_to_write, 'steam-library/addon.py', norm(os.path.join(steam_addon_dir, 'addon.py')), 1200000)
    _copy_text_file_to_diag(files_to_write, 'steam-library/settings.xml', norm(os.path.join(steam_profile, 'settings.xml')), 300000)
    files_to_write['steam-library/steam_library.db.digest.json'] = json.dumps(
        _safe_db_digest(norm(os.path.join(steam_profile, 'steam_library.db'))), indent=2, ensure_ascii=False
    )

    # LRS text metadata/settings.
    _copy_text_file_to_diag(files_to_write, 'lrs/addon.xml', norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml')), 300000)
    _copy_text_file_to_diag(files_to_write, 'lrs/settings.xml', norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml')), 300000)

    # AF3 XML context files: Includes_Info full and requested windows/full context XMLs.
    for fname in AF3_LRS_CONTEXT_XMLS:
        _copy_text_file_to_diag(files_to_write, f'af3/1080i/{fname}', af3_path('1080i', fname), 5000000)
    try:
        for fname in sorted(os.listdir(af3_path('1080i'))):
            if re.match(r'Custom_.*_Hub\.xml$', fname, re.I) and f'af3/1080i/{fname}' not in files_to_write:
                _copy_text_file_to_diag(files_to_write, f'af3/1080i/{fname}', af3_path('1080i', fname), 2000000)
    except Exception:
        pass
    for fname, text in snippets.items():
        files_to_write[f'af3-snippets/{fname}.txt'] = text

    files_to_write['manifest.json'] = _diagnostic_manifest('lrs-steam', stamp, files_to_write)

    for rel, content in files_to_write.items():
        _write_diag_file(os.path.join(out_dir, rel.replace('/', os.sep)), content)

    _write_validated_diagnostics_zip_0249(out_dir, zip_path)
    _delete_old_root_zips('kpm-lrs-steam-diagnostics-', keep=zip_path)

    log('[KPM_DIAG] Exported LRS / Steam Library diagnostics: {0}'.format(zip_path))
    return Result(name, 'Exported', zip_path)


def _target_files_report() -> Dict[str, object]:
    files = {
        'DialogSeekBar.xml': seekbar_pause_target(),
        'Includes_Info.xml': af3_path('1080i', 'Includes_Info.xml'),
        'Includes_OSD.xml': af3_path('1080i', 'Includes_OSD.xml'),
        'Includes_Images.xml': includes_images_target(),
        'Includes_Furniture.xml': includes_furniture_target(),
        'KPM service.py': norm(os.path.join(translate('special://home/addons/script.kodi.patch.manager'), 'service.py')),
        'KPM settings.json': kpm_settings_file(),
        'TMDbHelper imgmon.py': tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'imgmon.py'),
        'TMDbHelper images.py': tmdbhelper_path('resources', 'tmdbhelper', 'lib', 'monitor', 'images.py'),
        'LRS addon.xml': norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml')),
        'LRS settings.xml': norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml')),
        'Kodi log': _latest_kodi_log_path(),
    }
    files.update({
        'Home.xml': af3_path('1080i', 'Home.xml'),
        'MyPrograms.xml': af3_path('1080i', 'MyPrograms.xml'),
        'MyVideoNav.xml': af3_path('1080i', 'MyVideoNav.xml'),
        'Custom_1101_Hub.xml': af3_path('1080i', 'Custom_1101_Hub.xml'),
        'Custom_1102_Hub.xml': af3_path('1080i', 'Custom_1102_Hub.xml'),
        'Custom_1103_Hub.xml': af3_path('1080i', 'Custom_1103_Hub.xml'),
        'Steam Library addon.xml': norm(os.path.join(translate('special://home/addons/plugin.program.steam.library'), 'addon.xml')),
        'Steam Library addon.py': norm(os.path.join(translate('special://home/addons/plugin.program.steam.library'), 'addon.py')),
        'Steam Library settings.xml': norm(os.path.join(translate('special://profile/addon_data/plugin.program.steam.library'), 'settings.xml')),
        'Steam Library steam_library.db': norm(os.path.join(translate('special://profile/addon_data/plugin.program.steam.library'), 'steam_library.db')),
    })
    return {name: (_safe_db_digest(path) if name == 'Steam Library steam_library.db' else _full_file_digest(path)) for name, path in files.items()}



def _studio_home_props_report() -> Dict[str, object]:
    keys = [
        'KPM.StudioLogo.1', 'KPM.StudioLogoName.1',
        'KPM.StudioLogo.2', 'KPM.StudioLogoName.2',
        'KPM.StudioLogo.3', 'KPM.StudioLogoName.3',
        'KPM.StudioLogos.Count', 'KPM.StudioLogos.Available', 'KPM.StudioLogos.Status',
        'KPM.StudioLogos.Candidates', 'KPM.StudioLogos.Resolved', 'KPM.StudioLogos.Missing',
        'KPM.StudioLogos.UpdatedAt', 'KPM.StudioLogos.Show', 'KPM.StudioLogos.Context', 'KPM.StudioLogos.Cache', 'KPM.StudioLogos.IndexBuildMs',
        'KPM.StudioLogos.ResolveLastMs', 'KPM.StudioLogos.ResolveMaxMs', 'KPM.StudioLogos.ResolveCount',
        'KPM.StudioLogos.BrokenSkipped', 'KPM.StudioLogos.Debug',
        'KPM.StudioLogos.Source', 'KPM.StudioLogos.EpisodeParentShowId',
        'KPM.StudioLogos.EpisodeParentShowTitle', 'KPM.StudioLogos.DBLookupLastMs',
        'KPM.StudioLogos.DBLookupCount',
        'KPM.StudioLogos.LastMediaLabel', 'KPM.StudioLogos.LastMediaDBID',
        'KPM.StudioLogos.LastMediaDBTYPE', 'KPM.StudioLogos.LastMediaCandidates',
        'KPM.StudioLogos.LastMediaResolved', 'KPM.StudioLogos.LastMediaSource',
        'KPM.StudioLogos.LastMediaUpdatedAt',
        'KPM.StudioLogos.ResolvedProvider', 'KPM.StudioLogos.LocalStudioAvailable',
        'KPM.StudioLogos.LocalGameAvailable', 'KPM.StudioLogos.LocalStudioStatus',
        'KPM.StudioLogos.LocalGameStatus', 'KPM.StudioLogos.KPMResourceId',
        'KPM.StudioLogos.KPMResourceStatus', 'KPM.StudioLogos.KPMResourceXBT',
        'KPM.StudioLogos.KPMResourceManifest',
    ]
    return {key: _window_prop(10000, key) for key in keys}


def _studio_resource_report() -> Dict[str, object]:
    addon_root = translate('special://home/addons')
    coloured_dir = norm(os.path.join(addon_root, 'resource.images.studios.coloured'))
    white_dir = norm(os.path.join(addon_root, 'resource.images.studios.white'))
    game_dir = norm(os.path.join(addon_root, 'resource.images.gamestudios.grayscale'))
    coloured_xbt = norm(os.path.join(coloured_dir, 'resources', 'Textures.xbt'))
    white_xbt = norm(os.path.join(white_dir, 'resources', 'Textures.xbt'))
    game_xbt = norm(os.path.join(game_dir, 'resources', 'Textures.xbt'))
    cache_root = norm(os.path.join(translate('special://profile/addon_data/script.kodi.patch.manager'), 'cache'))
    return {
        'coloured_addon_dir': coloured_dir,
        'coloured_addon_exists': os.path.isdir(coloured_dir),
        'coloured_textures_xbt': _full_file_digest(coloured_xbt),
        'index_cache': _full_file_digest(norm(os.path.join(cache_root, 'studio-logo-index-coloured-v3.json'))),
        'game_grayscale_addon_dir': game_dir,
        'game_grayscale_addon_exists': os.path.isdir(game_dir),
        'game_grayscale_textures_xbt': _full_file_digest(game_xbt),
        'game_grayscale_index_cache': _full_file_digest(norm(os.path.join(cache_root, 'studio-logo-index-gamestudios-grayscale-v2.json'))),
        'kpm_xbt_resource_addon_dir': norm(os.path.join(addon_root, 'resource.images.kpm.studiologos')),
        'kpm_xbt_resource_addon_exists': os.path.isdir(norm(os.path.join(addon_root, 'resource.images.kpm.studiologos'))),
        'kpm_xbt_resource_textures': _full_file_digest(norm(os.path.join(addon_root, 'resource.images.kpm.studiologos', 'resources', 'Textures.xbt'))),
        'kpm_xbt_resource_manifest': _full_file_digest(norm(os.path.join(addon_root, 'resource.images.kpm.studiologos', 'resources', 'manifest.json'))),
        'kpm_xbt_resource_aliases': _full_file_digest(norm(os.path.join(addon_root, 'resource.images.kpm.studiologos', 'resources', 'aliases.json'))),
        'kpm_xbt_resource_build_report': _full_file_digest(norm(os.path.join(addon_root, 'resource.images.kpm.studiologos', 'resources', 'build-report.json'))),
        'white_addon_dir': white_dir,
        'white_addon_exists': os.path.isdir(white_dir),
        'white_textures_xbt': _full_file_digest(white_xbt),
    }


def _latest_myvideos_db() -> str:
    db_dir = norm(translate('special://profile/Database'))
    if not os.path.isdir(db_dir):
        return ''
    best = ''
    best_num = -1
    for fname in os.listdir(db_dir):
        match = re.match(r'MyVideos(\d+)\.db$', fname, re.I)
        if match:
            num = int(match.group(1))
            if num > best_num:
                best_num = num
                best = os.path.join(db_dir, fname)
    return norm(best) if best else ''


def _studio_db_report() -> Dict[str, object]:
    path = _latest_myvideos_db()
    data: Dict[str, object] = {'path': path, 'exists': bool(path and os.path.exists(path))}
    if not path or not os.path.exists(path):
        return data
    try:
        con = sqlite3.connect(path)
        cur = con.cursor()
        tables = {row[0] for row in cur.execute("SELECT name FROM sqlite_master WHERE type='table'")}
        data['has_studio_table'] = 'studio' in tables
        data['has_studio_link_table'] = 'studio_link' in tables
        if 'studio' in tables:
            data['studio_count'] = int(cur.execute('SELECT COUNT(*) FROM studio').fetchone()[0])
            data['sample_studios'] = [row[0] for row in cur.execute('SELECT name FROM studio ORDER BY name LIMIT 30')]
        if 'studio_link' in tables:
            data['studio_link_count'] = int(cur.execute('SELECT COUNT(*) FROM studio_link').fetchone()[0])
            data['media_with_studio_count'] = int(cur.execute('SELECT COUNT(*) FROM (SELECT media_type, media_id FROM studio_link GROUP BY media_type, media_id)').fetchone()[0])
            data['multi_studio_media_count'] = int(cur.execute('SELECT COUNT(*) FROM (SELECT media_type, media_id, COUNT(*) c FROM studio_link GROUP BY media_type, media_id HAVING c > 1)').fetchone()[0])
            sql = ('SELECT media_type, COUNT(*) AS items, '
                   'SUM(CASE WHEN c > 1 THEN 1 ELSE 0 END) AS multi_items '
                   'FROM (SELECT media_type, media_id, COUNT(*) c FROM studio_link GROUP BY media_type, media_id) '
                   'GROUP BY media_type ORDER BY media_type')
            data['by_media_type'] = [
                {'media_type': row[0], 'items': row[1], 'multi_studio_items': row[2]}
                for row in cur.execute(sql)
            ]
            try:
                data['episode_studio_link_count'] = int(cur.execute("SELECT COUNT(*) FROM studio_link WHERE media_type='episode'").fetchone()[0])
                data['tvshow_studio_link_count'] = int(cur.execute("SELECT COUNT(*) FROM studio_link WHERE media_type='tvshow'").fetchone()[0])
                data['episode_parent_studio_samples'] = [
                    {'idEpisode': row[0], 'episode': row[1], 'idShow': row[2], 'show': row[3], 'studio': row[4]}
                    for row in cur.execute("""
                        SELECT e.idEpisode, e.c00, e.idShow, t.c00, s.name
                        FROM episode e
                        JOIN tvshow t ON t.idShow=e.idShow
                        JOIN studio_link sl ON sl.media_type='tvshow' AND sl.media_id=e.idShow
                        JOIN studio s ON s.studio_id=sl.studio_id
                        ORDER BY e.idEpisode
                        LIMIT 20
                    """)
                ]
            except Exception as exc:
                data['episode_parent_studio_error'] = str(exc)
        con.close()
    except Exception as exc:  # pylint: disable=broad-except
        data['error'] = str(exc)
    return data


def _marked_snippet(path: str, start_marker: str, end_marker: str, max_chars: int = 120000) -> str:
    text = _read_file_if_exists(path, max_chars)
    return _line_numbered_snippet(text, start_marker, end_marker)


def _studio_log_filtered() -> str:
    path = _latest_kodi_log_path()
    text = _read_file_if_exists(path, 600000)
    keys = ('Kodi Patch Manager Service', 'KPM.StudioLogo', 'KPM.StudioLogos', 'studio logos:',
            'resource.images.studios', 'Image_CombinedStudio', 'Furniture_Studio', 'Misplaced [',
            'Error parsing boolean expression', 'CImageLoader::DoWork')
    out = []
    for line in text.splitlines():
        if any(k.lower() in line.lower() for k in keys):
            out.append(line)
    return '\n'.join(out[-2500:]) if out else 'No studio-logo related lines found in kodi.log tail.'


def _studio_last_events() -> List[str]:
    text = _studio_log_filtered()
    lines = []
    for line in text.splitlines():
        lower = line.lower()
        if 'studio logo index' in lower or 'studio logos:' in lower or 'cimageloader::dowork' in lower or 'failed to decompress' in lower or 'error parsing boolean expression' in lower:
            lines.append(line)
    return lines[-80:]



def _studio_context_report() -> Dict[str, object]:
    tmdb_listitem = {}
    tmdb_player = {}
    for idx in range(1, 11):
        tmdb_listitem[f'Studio.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.ListItem.Studio.{idx}.Name')
    for idx in range(1, 6):
        tmdb_listitem[f'Network.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.ListItem.Network.{idx}.Name')
        tmdb_player[f'Studio.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.Player.Studio.{idx}.Name')
        tmdb_player[f'Network.{idx}.Name'] = _window_prop(10000, f'TMDbHelper.Player.Network.{idx}.Name')
    visibility = {
        'Furniture.DisableStudio': cond_visible('Skin.HasSetting(Footer.DisableStudio)'),
        'Furniture.EnableCodecs': cond_visible('Skin.HasSetting(Footer.EnableCodecs)'),
        'Furniture.DisableNowPlaying': cond_visible('Skin.HasSetting(Footer.DisableNowPlaying)'),
        'Footer condition - no now playing or disabled': cond_visible('!Player.HasMedia | Skin.HasSetting(Footer.DisableNowPlaying)'),
        'Footer condition - codec slot free': cond_visible('String.IsEmpty(ListItem.VideoCodec) | !Skin.HasSetting(Footer.EnableCodecs)'),
        'Footer condition - KPM logo 1 exists': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))'),
        'Footer condition - KPM studio show': cond_visible('String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)'),
    }
    return {
        'info_labels': {
            'ListItem.Label': info_label('ListItem.Label'),
            'ListItem.DBID': info_label('ListItem.DBID'),
            'ListItem.DBTYPE': info_label('ListItem.DBTYPE'),
            'ListItem.Studio': info_label('ListItem.Studio'),
            'ListItem.VideoCodec': info_label('ListItem.VideoCodec'),
            'Container.ListItem.Label': info_label('Container.ListItem.Label'),
            'Container.ListItem.DBID': info_label('Container.ListItem.DBID'),
            'Container.ListItem.DBTYPE': info_label('Container.ListItem.DBTYPE'),
            'Container.ListItem.Studio': info_label('Container.ListItem.Studio'),
            'Container.ListItem.VideoCodec': info_label('Container.ListItem.VideoCodec'),
            'VideoPlayer.Title': info_label('VideoPlayer.Title'),
            'VideoPlayer.DBID': info_label('VideoPlayer.DBID'),
            'VideoPlayer.DBTYPE': info_label('VideoPlayer.DBTYPE'),
            'VideoPlayer.Studio': info_label('VideoPlayer.Studio'),
            'VideoPlayer.Content(episodes)': cond_visible('VideoPlayer.Content(episodes)'),
        },
        'tmdbhelper_listitem_properties': tmdb_listitem,
        'tmdbhelper_player_properties': tmdb_player,
        'visibility_conditions': visibility,
        'known_broken_texture_blacklist': list(BROKEN_STUDIO_TEXTURE_NAMES),
    }


def studio_logo_diagnostics_report() -> Dict[str, object]:
    images = includes_images_target()
    furniture = includes_furniture_target()
    return {
        'generated': time.strftime('%Y-%m-%d %H:%M:%S'),
        'kpm_version': VERSION,
        'patch_status': status_reliable_studio_logos(),
        'settings': load_kpm_settings(),
        'state_exists': os.path.exists(state_file('reliable_studio_logos')),
        'state_file': state_file('reliable_studio_logos'),
        'home_properties': _studio_home_props_report(),
        'context': _studio_context_report(),
        'resource': _studio_resource_report(),
        'database': _studio_db_report(),
        'targets': {
            'Includes_Images.xml': _full_file_digest(images),
            'Includes_Furniture.xml': _full_file_digest(furniture),
        },
        'condition_checks': {
            '!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.1))'),
            'String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)': cond_visible('String.IsEqual(Window(Home).Property(KPM.StudioLogos.Show),true)'),
            '!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.2))': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.2))'),
            '!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.3))': cond_visible('!String.IsEmpty(Window(Home).Property(KPM.StudioLogo.3))'),
        },
        'last_events': _studio_last_events(),
    }


def _studio_diagnostic_text(report: Dict[str, object]) -> str:
    lines = []
    lines.append(f'{ADDON_NAME} studio logo diagnostics v{VERSION}')
    lines.append(f'Generated: {report.get("generated", "")}')
    lines.append('')
    lines.append('Status: ' + str(report.get('patch_status')))
    lines.append('Settings: ' + json.dumps(report.get('settings', {}), ensure_ascii=False))
    lines.append('')
    lines.append('Home properties:')
    lines.append(json.dumps(report.get('home_properties', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Context / visibility:')
    lines.append(json.dumps(report.get('context', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Resource:')
    lines.append(json.dumps(report.get('resource', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Database:')
    lines.append(json.dumps(report.get('database', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Condition checks:')
    lines.append(json.dumps(report.get('condition_checks', {}), indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Last studio events:')
    lines.extend(report.get('last_events', []) or ['No studio events found.'])
    return '\n'.join(lines)



def _delete_old_root_zips(prefix: str, keep: str = "") -> None:
    try:
        root_dir = addon_data_dir()
        for name in os.listdir(root_dir):
            if name.startswith(prefix) and name.endswith('.zip'):
                path = os.path.join(root_dir, name)
                if keep and os.path.abspath(path) == os.path.abspath(keep):
                    continue
                try:
                    os.remove(path)
                except Exception:
                    pass
    except Exception:
        pass


def _write_validated_diagnostics_zip_0249(out_dir: str, zip_path: str) -> str:
    """Build a validated temporary ZIP, then atomically install it.

    A previously healthy diagnostics archive is never opened or deleted until
    the replacement passes CRC and manifest validation.
    """
    os.makedirs(os.path.dirname(zip_path), exist_ok=True)
    nonce = str(time.time_ns() if hasattr(time, 'time_ns') else int(time.time() * 1000000))
    tmp_path = zip_path + '.tmp-' + str(os.getpid()) + '-' + nonce
    try:
        with zipfile.ZipFile(tmp_path, 'w', compression=zipfile.ZIP_DEFLATED) as zf:
            for root, _dirs, files in os.walk(out_dir):
                for fname in files:
                    fpath = os.path.join(root, fname)
                    zf.write(fpath, os.path.relpath(fpath, out_dir))
        with zipfile.ZipFile(tmp_path, 'r') as test_zf:
            bad = test_zf.testzip()
            if bad:
                raise RuntimeError('Diagnostics ZIP validation failed at {0}'.format(bad))
            if 'manifest.json' not in test_zf.namelist():
                raise RuntimeError('Diagnostics ZIP manifest.json is missing')
            json.loads(test_zf.read('manifest.json').decode('utf-8-sig'))
        os.replace(tmp_path, zip_path)
        return zip_path
    except Exception:
        try:
            if os.path.exists(tmp_path):
                os.remove(tmp_path)
        except Exception:
            pass
        raise


def _delete_all_kpm_diagnostic_zips(keep: str = "") -> None:
    try:
        root_dir = addon_data_dir()
        for name in os.listdir(root_dir):
            lower = name.lower()
            if lower.startswith('kpm-') and 'diagnostic' in lower and lower.endswith('.zip'):
                path = os.path.join(root_dir, name)
                if keep and os.path.abspath(path) == os.path.abspath(keep):
                    continue
                try:
                    os.remove(path)
                except Exception:
                    pass
    except Exception:
        pass


def _diagnostic_manifest(kind: str, stamp: str, files_to_write: Dict[str, str]) -> str:
    data = {
        'addon_id': ADDON_ID,
        'addon_name': ADDON_NAME,
        'addon_version': VERSION,
        'diagnostic_type': kind,
        'created_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'stamp': stamp,
        'storage': {
            'root_zip_location': 'special://profile/addon_data/{0}/'.format(ADDON_ID),
            'working_folder': 'runtime/exports/',
            'state_folder': 'runtime/state/',
            'diagnostics_folder': 'runtime/diagnostics/',
            'reports_folder': 'runtime/reports/',
            'logs_folder': 'runtime/logs/'
        },
        'included_files': sorted(files_to_write.keys()),
        'redacted': True
    }
    return json.dumps(data, indent=2, ensure_ascii=False)

def export_studio_logo_diagnostics() -> Result:
    name = 'Export Studio Logo Diagnostics'
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_dir = addon_data_dir('runtime', 'exports', 'studio_logo_diagnostics', stamp)
    zip_path = os.path.join(addon_data_dir(), f'kpm-studio-logo-diagnostics-{stamp}.zip')
    report = studio_logo_diagnostics_report()
    images = includes_images_target()
    furniture = includes_furniture_target()
    files_to_write = {
        'studio-logo-diagnostics.txt': _studio_diagnostic_text(report),
        'studio-logo-diagnostics.json': json.dumps(report, indent=2, ensure_ascii=False),
        'studio-context.json': json.dumps(report.get('context', {}), indent=2, ensure_ascii=False),
        'studio-home-properties.json': json.dumps(report.get('home_properties', {}), indent=2, ensure_ascii=False),
        'Includes_Images-Image_CombinedStudio-snippet.txt': _marked_snippet(images, STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END),
        'Includes_Furniture-Furniture_Studio-snippet.txt': _marked_snippet(furniture, STUDIO_FURNITURE_START, STUDIO_FURNITURE_END),
        'Includes_Images.xml': _read_file_if_exists(images, 400000),
        'Includes_Furniture.xml': _read_file_if_exists(furniture, 300000),
        'kodi-log-studio-filtered.txt': _studio_log_filtered(),
        'patch-status.txt': patch_status_summary(),
    }
    files_to_write['manifest.json'] = _diagnostic_manifest('studio_logo', stamp, files_to_write)
    for rel, content in files_to_write.items():
        _write_diag_file(os.path.join(out_dir, rel.replace('/', os.sep)), content)
    _write_validated_diagnostics_zip_0249(out_dir, zip_path)
    _delete_all_kpm_diagnostic_zips(keep=zip_path)
    log('[KPM_STUDIO_DIAG] Exported studio logo diagnostics: {0}'.format(zip_path))
    return Result(name, 'Exported', zip_path)



def _diagnostic_text(runtime: dict, target_report: dict, seekbar_text: str) -> str:
    lines = []
    lines.append(f'{ADDON_NAME} diagnostics v{VERSION}')
    lines.append(f'Generated: {time.strftime("%Y-%m-%d %H:%M:%S")}')
    lines.append('')
    lines.append('Patch status:')
    lines.append(patch_status_summary())
    lines.append('')
    lines.append('Runtime state:')
    lines.append(json.dumps(runtime, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Target files:')
    lines.append(json.dumps(target_report, indent=2, ensure_ascii=False))
    lines.append('')
    lines.append('Studio logo diagnostics:')
    try:
        lines.append(_studio_diagnostic_text(studio_logo_diagnostics_report()))
    except Exception as exc:
        lines.append(f'Studio diagnostics error: {exc}')
    lines.append('')
    lines.append('DialogSeekBar current clearart marker snippet:')
    lines.append(_line_numbered_snippet(seekbar_text, DIALOG_SEEKBAR_CLEARART_START, DIALOG_SEEKBAR_CLEARART_END))
    lines.append('')
    return '\n'.join(lines)


def _write_diag_file(path: str, content: str) -> None:
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w', encoding='utf-8', errors='replace') as handle:
        handle.write(content)


def export_diagnostics() -> Result:
    name = 'Export Full Diagnostics ZIP'
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_dir = addon_data_dir('runtime', 'exports', DIAG_EXPORT_DIRNAME, stamp)
    zip_path = os.path.join(addon_data_dir(), f'kpm-diagnostics-{stamp}.zip')
    runtime = _player_runtime_state()
    target_report = _target_files_report()
    seekbar_target = seekbar_pause_target()
    seekbar_text = _read_file_if_exists(seekbar_target, 1000000)
    diag_text = _diagnostic_text(runtime, target_report, seekbar_text)

    files_to_write = {
        'summary.txt': diag_text,
        'runtime.json': json.dumps(runtime, indent=2, ensure_ascii=False),
        'target-files.json': json.dumps(target_report, indent=2, ensure_ascii=False),
        'patch-status.txt': patch_status_summary(),
        'DialogSeekBar-current-clearart-snippet.txt': _line_numbered_snippet(seekbar_text, DIALOG_SEEKBAR_CLEARART_START, DIALOG_SEEKBAR_CLEARART_END),
        'DialogSeekBar.xml': seekbar_text,
        'Includes_Info.xml': _read_file_if_exists(af3_path('1080i', 'Includes_Info.xml'), 5000000),
        'Home.xml': _read_file_if_exists(af3_path('1080i', 'Home.xml'), 3000000),
        'MyPrograms.xml': _read_file_if_exists(af3_path('1080i', 'MyPrograms.xml'), 3000000),
        'MyVideoNav.xml': _read_file_if_exists(af3_path('1080i', 'MyVideoNav.xml'), 3000000),
        'Custom_1101_Hub.xml': _read_file_if_exists(af3_path('1080i', 'Custom_1101_Hub.xml'), 3000000),
        'Custom_1102_Hub.xml': _read_file_if_exists(af3_path('1080i', 'Custom_1102_Hub.xml'), 3000000),
        'Custom_1103_Hub.xml': _read_file_if_exists(af3_path('1080i', 'Custom_1103_Hub.xml'), 3000000),
        'xml-context-snippets.json': json.dumps(_xml_context_snippets(), indent=2, ensure_ascii=False),
        'Includes_OSD.tail.txt': _read_file_if_exists(af3_path('1080i', 'Includes_OSD.xml'), 200000),
        'kodi-log-filtered.txt': _filtered_kodi_log(),
    }
    try:
        studio_report = studio_logo_diagnostics_report()
        files_to_write['studio-logo-diagnostics.txt'] = _studio_diagnostic_text(studio_report)
        files_to_write['studio-logo-diagnostics.json'] = json.dumps(studio_report, indent=2, ensure_ascii=False)
        files_to_write['studio-context.json'] = json.dumps(studio_report.get('context', {}), indent=2, ensure_ascii=False)
        files_to_write['studio-home-properties.json'] = json.dumps(studio_report.get('home_properties', {}), indent=2, ensure_ascii=False)
        files_to_write['Includes_Images-Image_CombinedStudio-snippet.txt'] = _marked_snippet(includes_images_target(), STUDIO_IMAGE_VAR_START, STUDIO_IMAGE_VAR_END)
        files_to_write['Includes_Furniture-Furniture_Studio-snippet.txt'] = _marked_snippet(includes_furniture_target(), STUDIO_FURNITURE_START, STUDIO_FURNITURE_END)
        files_to_write['kodi-log-studio-filtered.txt'] = _studio_log_filtered()
    except Exception as exc:
        files_to_write['studio-logo-diagnostics-error.txt'] = str(exc)
    lrs_settings = norm(os.path.join(translate('special://profile/addon_data/script.library.ratings.scraper'), 'settings.xml'))
    if os.path.exists(lrs_settings):
        files_to_write['lrs-settings.xml'] = _read_text_redacted_if_settings(lrs_settings, 100000)
    lrs_addon = norm(os.path.join(translate('special://home/addons/script.library.ratings.scraper'), 'addon.xml'))
    if os.path.exists(lrs_addon):
        files_to_write['lrs-addon.xml'] = _read_file_if_exists(lrs_addon, 100000)

    steam_addon_dir = norm(translate('special://home/addons/plugin.program.steam.library'))
    steam_profile = norm(translate('special://profile/addon_data/plugin.program.steam.library'))
    _copy_text_file_to_diag(files_to_write, 'steam-library/addon.xml', norm(os.path.join(steam_addon_dir, 'addon.xml')), 300000)
    _copy_text_file_to_diag(files_to_write, 'steam-library/addon.py', norm(os.path.join(steam_addon_dir, 'addon.py')), 1200000)
    _copy_text_file_to_diag(files_to_write, 'steam-library/settings.xml', norm(os.path.join(steam_profile, 'settings.xml')), 300000)
    files_to_write['steam-library/steam_library.db.digest.json'] = json.dumps(_safe_db_digest(norm(os.path.join(steam_profile, 'steam_library.db'))), indent=2, ensure_ascii=False)

    try:
        _add_full_system_diagnostic_files(files_to_write, stamp)
    except Exception as exc:
        files_to_write['full-system-diagnostics-error.txt'] = str(exc) + '\n' + traceback.format_exc()

    live_dir = addon_data_dir('runtime', 'logs', DIAG_LIVE_DIRNAME)
    if os.path.isdir(live_dir):
        live_manifest = []
        for fname in sorted(os.listdir(live_dir)):
            if fname.startswith(DIAG_LIVE_PREFIX):
                fpath = os.path.join(live_dir, fname)
                live_manifest.append(_full_file_digest(fpath))
                files_to_write['live/' + fname] = _read_live_text_if_exists(fpath, 20000000)
        if live_manifest:
            files_to_write['live/_manifest.json'] = json.dumps(live_manifest, indent=2, ensure_ascii=False)

    files_to_write['manifest.json'] = _diagnostic_manifest('full', stamp, files_to_write)

    for rel, content in files_to_write.items():
        _write_diag_file(os.path.join(out_dir, rel.replace('/', os.sep)), content)

    _write_validated_diagnostics_zip_0249(out_dir, zip_path)
    _delete_all_kpm_diagnostic_zips(keep=zip_path)
    log('[KPM_DIAG] Exported diagnostics: {0}'.format(zip_path))
    # Also log current key values into kodi.log for quick inspection.
    home_slots = runtime.get('lrs_properties', {}).get('10000', {}).get('Player', {}) if isinstance(runtime, dict) else {}
    for slot in range(1, 8):
        sd = home_slots.get(f'RatingSlot{slot}', {}) if isinstance(home_slots, dict) else {}
        log('[KPM_DIAG] Home Player Slot{0}: source={1!r} icon={2!r} label={3!r}'.format(slot, sd.get('Source'), sd.get('IconFile'), sd.get('Label')))
    return Result(name, 'Exported', zip_path)


def run_diag_live(duration_seconds: int = 90) -> None:
    stamp = time.strftime('%Y%m%d-%H%M%S')
    out_path = os.path.join(addon_data_dir('runtime', 'logs', DIAG_LIVE_DIRNAME), f'{DIAG_LIVE_PREFIX}-{stamp}.jsonl')
    end_time = time.time() + max(5, int(duration_seconds))
    notify('Live diagnostic started. Pause fullscreen video now.')
    log('[KPM_DIAG] Live fullscreen ratings diagnostic started for {0}s -> {1}'.format(duration_seconds, out_path))
    os.makedirs(live_dir, exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as handle:
        sample_no = 0
        while time.time() < end_time:
            if xbmc and xbmc.Monitor().abortRequested():
                break
            sample_no += 1
            data = _player_runtime_state()
            data['sample'] = sample_no
            handle.write(json.dumps(data, ensure_ascii=False) + '\n')
            handle.flush()
            conds = data.get('conditions', {})
            hp = data.get('lrs_properties', {}).get('10000', {}).get('Player', {})
            s1 = hp.get('RatingSlot1', {}) if isinstance(hp, dict) else {}
            log('[KPM_DIAG] sample={0} paused={1} seeking={2} fullscreen={3} title={4!r} slot1={5!r}/{6!r}/{7!r}'.format(
                sample_no,
                conds.get('Player.Paused'),
                conds.get('Player.Seeking'),
                conds.get('Window.IsActive(fullscreenvideo)'),
                data.get('videoplayer_labels', {}).get('Title'),
                s1.get('Source'), s1.get('IconFile'), s1.get('Label'),
            ))
            if xbmc:
                xbmc.sleep(1000)
            else:
                time.sleep(1)
    log('[KPM_DIAG] Live fullscreen ratings diagnostic finished: {0}'.format(out_path))
    notify('Live diagnostic finished. Export Diagnostics ZIP now.')


def start_live_diagnostics_menu() -> None:
    message = (
        'Start a 90 second live diagnostic logger now?\n\n'
        'After pressing Yes, go back to the video and pause it. The logger records Player.Paused, active windows, VideoPlayer labels, and all LibraryRatings.Player RatingSlot1-6 properties once per second.'
    )
    if not yesno(ADDON_NAME, message):
        return
    if xbmc:
        xbmc.executebuiltin(f'RunScript({ADDON_ID},diag_live,90)')
        ok(ADDON_NAME, 'Live diagnostic started for 90 seconds.\n\nNow go to the video, pause it, wait a few seconds, then come back here and run Export Diagnostics ZIP.')
    else:
        run_diag_live(10)



# -----------------------------------------------------------------------------
# v0.2.05 - AF3 Poster Ratio 2:3, corrected AF3 negative constant names
# -----------------------------------------------------------------------------
POSTER_RATIO_PATCH_ID_0204 = 'af3_poster_ratio_2_3'
POSTER_RATIO_QUANT_0204 = Decimal('0.01')
POSTER_RATIO_TOLERANCE_0204 = Decimal('0.011')
POSTER_CONSTANTS_0204 = (
    'view_poster_item_w',
    '-view_poster_item_w',
    'view_poster_itemlayout_w',
    '-view_poster_itemlayout_w',
)
POSTER_REQUIRED_READ_CONSTANTS_0204 = POSTER_CONSTANTS_0204 + (
    'view_poster_item_h',
    'view_poster_itemlayout_h',
)


def af3_poster_constants_target_0204() -> str:
    return af3_path('1080i', 'Includes_Constants.xml')


def _poster_constant_pattern_0204(name: str) -> re.Pattern:
    return re.compile(
        r'(?P<open><constant\s+name=(?P<quote>["\'])'
        + re.escape(name)
        + r'(?P=quote)\s*>)(?P<value>[^<]+)(?P<close></constant>)',
        re.IGNORECASE,
    )


def _read_poster_constant_0204(text: str, name: str) -> str:
    match = _poster_constant_pattern_0204(name).search(text)
    if not match:
        raise RuntimeError('AF3 constant not found: {0}'.format(name))
    return str(match.group('value') or '').strip()


def _decimal_poster_constant_0204(text: str, name: str) -> Decimal:
    raw = _read_poster_constant_0204(text, name)
    try:
        return Decimal(raw)
    except InvalidOperation as exc:
        raise RuntimeError('AF3 constant is not numeric: {0}={1}'.format(name, raw)) from exc


def _format_poster_decimal_0204(value: Decimal) -> str:
    rounded = value.quantize(POSTER_RATIO_QUANT_0204, rounding=ROUND_HALF_UP)
    # Width values are deliberately kept to two decimals. That makes
    # 310 × 2 / 3 become 206.67 and keeps positive/negative pairs exact.
    return format(rounded, '.2f')


def _replace_poster_constant_0204(text: str, name: str, value: str) -> str:
    pattern = _poster_constant_pattern_0204(name)
    out, count = pattern.subn(
        lambda match: match.group('open') + str(value) + match.group('close'),
        text,
        count=1,
    )
    if count != 1:
        raise RuntimeError('Could not replace AF3 constant: {0}'.format(name))
    return out


def _poster_constants_snapshot_0204(text: str) -> Dict[str, str]:
    return {
        name: _read_poster_constant_0204(text, name)
        for name in POSTER_REQUIRED_READ_CONSTANTS_0204
    }


def _poster_ratio_values_0204(text: str) -> Dict[str, Decimal]:
    return {
        name: _decimal_poster_constant_0204(text, name)
        for name in POSTER_REQUIRED_READ_CONSTANTS_0204
    }


def _poster_ratio_expected_0204(values: Dict[str, Decimal]) -> Dict[str, Decimal]:
    item_h = values['view_poster_item_h']
    current_item_w = values['view_poster_item_w']
    current_layout_w = values['view_poster_itemlayout_w']
    gap = current_layout_w - current_item_w
    if item_h <= 0 or current_item_w <= 0 or current_layout_w <= 0:
        raise RuntimeError('AF3 poster constants must be positive.')
    if gap < 0:
        raise RuntimeError(
            'AF3 poster layout width is smaller than poster width; '
            'the current horizontal gap cannot be preserved safely.'
        )

    new_item_w = (item_h * Decimal(2) / Decimal(3)).quantize(
        POSTER_RATIO_QUANT_0204,
        rounding=ROUND_HALF_UP,
    )
    new_layout_w = (new_item_w + gap).quantize(
        POSTER_RATIO_QUANT_0204,
        rounding=ROUND_HALF_UP,
    )
    return {
        'item_w': new_item_w,
        'item_w_neg': -new_item_w,
        'layout_w': new_layout_w,
        'layout_w_neg': -new_layout_w,
        'gap': gap,
        'item_h': item_h,
        'layout_h': values['view_poster_itemlayout_h'],
    }


def _decimal_close_0204(left: Decimal, right: Decimal) -> bool:
    return abs(left - right) <= POSTER_RATIO_TOLERANCE_0204


def status_af3_poster_ratio_2_3() -> str:
    target = af3_poster_constants_target_0204()
    if not os.path.exists(target):
        return 'Missing target'
    try:
        text = read_text(target)
        values = _poster_ratio_values_0204(text)
        expected = _poster_ratio_expected_0204(values)
    except Exception:
        return 'Unknown layout'

    positive_ok = (
        _decimal_close_0204(values['view_poster_item_w'], expected['item_w'])
        and _decimal_close_0204(
            values['view_poster_itemlayout_w'] - values['view_poster_item_w'],
            expected['gap'],
        )
    )
    negative_ok = (
        _decimal_close_0204(values['-view_poster_item_w'], -values['view_poster_item_w'])
        and _decimal_close_0204(
            values['-view_poster_itemlayout_w'],
            -values['view_poster_itemlayout_w'],
        )
    )
    if positive_ok and negative_ok:
        return 'Patched'
    if positive_ok or negative_ok:
        return 'Partial'
    return 'Not patched'


def patch_af3_poster_ratio_2_3() -> Result:
    name = patch_title(POSTER_RATIO_PATCH_ID_0204, 'AF3 Poster Ratio 2:3')
    target = af3_poster_constants_target_0204()
    if not os.path.exists(target):
        return Result(name, 'Error', 'AF3 Includes_Constants.xml was not found.')

    text = read_text(target)
    values = _poster_ratio_values_0204(text)
    expected = _poster_ratio_expected_0204(values)

    if status_af3_poster_ratio_2_3() == 'Patched':
        return Result(
            name,
            'Skipped',
            'Already 2:3. Current poster: {0} × {1}; gap: {2}.'.format(
                _format_poster_decimal_0204(values['view_poster_item_w']),
                _format_poster_decimal_0204(values['view_poster_item_h']),
                _format_poster_decimal_0204(
                    values['view_poster_itemlayout_w'] - values['view_poster_item_w']
                ),
            ),
        )

    original = _poster_constants_snapshot_0204(text)
    replacements = {
        'view_poster_item_w': _format_poster_decimal_0204(expected['item_w']),
        '-view_poster_item_w': _format_poster_decimal_0204(expected['item_w_neg']),
        'view_poster_itemlayout_w': _format_poster_decimal_0204(expected['layout_w']),
        '-view_poster_itemlayout_w': _format_poster_decimal_0204(expected['layout_w_neg']),
    }

    new_text = text
    for constant_name, replacement in replacements.items():
        new_text = _replace_poster_constant_0204(new_text, constant_name, replacement)

    # Validate the complete edited XML before writing it.
    ET.fromstring(new_text)

    snapshot(POSTER_RATIO_PATCH_ID_0204, [target])
    save_state(
        POSTER_RATIO_PATCH_ID_0204,
        {
            'target': target,
            'original_values': {
                key: original[key]
                for key in POSTER_CONSTANTS_0204
            },
            'original_item_h': original['view_poster_item_h'],
            'original_layout_h': original['view_poster_itemlayout_h'],
            'patched_values': replacements,
            'preserved_gap': _format_poster_decimal_0204(expected['gap']),
            'calculation': 'new_item_w = current_item_h * 2 / 3; new_layout_w = new_item_w + current_gap',
        },
    )
    write_text(target, new_text)

    return Result(
        name,
        'Patched',
        (
            'Poster: {old_w} × {height} -> {new_w} × {height}\n'
            'Cell: {old_cell_w} × {cell_h} -> {new_cell_w} × {cell_h}\n'
            'Horizontal gap preserved: {gap}\n'
            'Poster and cell heights were not changed.\n'
            'Reload Skin or restart Kodi to apply the new geometry.'
        ).format(
            old_w=original['view_poster_item_w'],
            height=original['view_poster_item_h'],
            new_w=replacements['view_poster_item_w'],
            old_cell_w=original['view_poster_itemlayout_w'],
            cell_h=original['view_poster_itemlayout_h'],
            new_cell_w=replacements['view_poster_itemlayout_w'],
            gap=_format_poster_decimal_0204(expected['gap']),
        ),
    )


def remove_af3_poster_ratio_2_3() -> Result:
    name = patch_title(POSTER_RATIO_PATCH_ID_0204, 'AF3 Poster Ratio 2:3')
    target = af3_poster_constants_target_0204()
    try:
        state = load_state(POSTER_RATIO_PATCH_ID_0204)
    except FileNotFoundError:
        return Result(
            name,
            'Error',
            'Restore state is missing. KPM will not guess the original AF3 widths.',
        )

    original_values = state.get('original_values') or {}
    missing = [key for key in POSTER_CONSTANTS_0204 if key not in original_values]
    if missing:
        return Result(
            name,
            'Error',
            'Restore state is incomplete: {0}'.format(', '.join(missing)),
        )
    if not os.path.exists(target):
        return Result(name, 'Error', 'AF3 Includes_Constants.xml was not found.')

    text = read_text(target)
    new_text = text
    for constant_name in POSTER_CONSTANTS_0204:
        new_text = _replace_poster_constant_0204(
            new_text,
            constant_name,
            str(original_values[constant_name]),
        )

    ET.fromstring(new_text)
    write_text(target, new_text)
    delete_state(POSTER_RATIO_PATCH_ID_0204)

    return Result(
        name,
        'Restored',
        (
            'Original widths restored exactly from KPM state.\n'
            'Poster width: {0}\n'
            'Cell width: {1}\n'
            'Reload Skin or restart Kodi.'
        ).format(
            original_values['view_poster_item_w'],
            original_values['view_poster_itemlayout_w'],
        ),
    )


# -----------------------------------------------------------------------------
# UI and batch actions
# -----------------------------------------------------------------------------

def format_results(results: List[Result]) -> str:
    chunks = []
    for item in results:
        text = f'{item.name}: {item.status}'
        if item.detail:
            text += f'\n{item.detail}'
        chunks.append(text)
    return '\n\n'.join(chunks)


def run_single(func: Callable[[], Result]) -> None:
    try:
        result = func()
        if str(result.status).lower() == 'exported':
            notify('DIAGNOSTICS EXPORTED - {0}'.format(os.path.basename(str(result.detail or ''))))
        else:
            notify(f'{result.name}: {result.status}')
            textviewer(ADDON_NAME + " - Result", format_results([result]))
    except Exception as exc:
        log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
        ok(f'{ADDON_NAME} - Error', str(exc))


def _apply_patch_smart(patch_id: str, status_func: Callable[[], str], patch_func: Callable[[], Result]) -> Result:
    title = patch_title(patch_id, patch_id)
    try:
        status = status_func()
    except Exception as exc:
        return Result(title, 'Error', 'Status check failed before patching: {0}'.format(exc))
    if status == 'Patched':
        return Result(title, 'Skipped', 'Already current; no file was touched.')
    if status.startswith('Missing target'):
        return Result(title, 'Skipped', status)
    # Not-patched or partial states are sent through the current idempotent patcher.
    # The patcher updates only its marked or anchored block.
    return patch_func()


def _remove_patch_smart(patch_id: str, status_func: Callable[[], str], remove_func: Callable[[], Result]) -> Result:
    title = patch_title(patch_id, patch_id)
    try:
        status = status_func()
    except Exception as exc:
        return Result(title, 'Error', 'Status check failed before removal: {0}'.format(exc))
    if status in ('Not patched', 'Unknown layout') or status.startswith('Missing target'):
        return Result(title, 'Skipped', 'Not installed; no file was touched.')
    return remove_func()


def apply_all() -> None:
    global _KPM_BATCH_PATCH_MODE, _KPM_BATCH_RELOAD_NEEDED
    if not yesno(ADDON_NAME, 'Apply Full KPM Integration now?\n\nThis runs all KPM visual/XML patches in the correct order:\n- AF3 Unified Integration\n- AF3 Poster Ratio 2:3\n- Episode Thumb Up Next\n- Movies + Shows Screensaver\n- Pause Shows Full OSD\n- Reliable Studio Logos\n- Cinema Pre-roll Fonts\n\nRule: status is checked first. Current patches are skipped. Partial current patches are normalized only inside their own marked or anchored blocks.'):
        return
    entries = [
        ('af3_unified_integration', status_af3_unified_integration, apply_af3_unified_integration),
        ('af3_poster_ratio_2_3', status_af3_poster_ratio_2_3, patch_af3_poster_ratio_2_3),
        ('upnext_episode_thumb', status_upnext, patch_upnext),
        ('shw_random_movies_tvshows', status_shw, lambda: patch_shw(100)),
        ('vfs_pause_ratings', status_vfs_pause_ratings, patch_vfs_pause_ratings),
        ('reliable_studio_logos', status_reliable_studio_logos, patch_reliable_studio_logos),
    ]
    results: List[Result] = []
    _KPM_BATCH_PATCH_MODE = True
    _KPM_BATCH_RELOAD_NEEDED = False
    try:
        for patch_id, status_func, patch_func in entries:
            try:
                results.append(_apply_patch_smart(patch_id, status_func, patch_func))
            except Exception as exc:
                log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
                results.append(Result(patch_title(patch_id, patch_id), 'Error', str(exc)))
    finally:
        _KPM_BATCH_PATCH_MODE = False
        _finish_deferred_reload()
    notify('Apply Full KPM Integration finished')
    textviewer(ADDON_NAME + " - Results", format_results(results))


def remove_all() -> None:
    global _KPM_BATCH_PATCH_MODE, _KPM_BATCH_RELOAD_NEEDED
    if not yesno(ADDON_NAME, 'Remove Full KPM Integration now?\n\nThis removes KPM visual/XML patches where possible:\n- AF3 Unified Integration\n- AF3 Poster Ratio 2:3\n- Episode Thumb Up Next\n- Movies + Shows Screensaver\n- Pause Shows Full OSD\n- Reliable Studio Logos\n- Cinema Pre-roll Fonts\n\nRule: status is checked first. Missing/not-installed patches are skipped. Installed patches are removed by marker/block restore only.'):
        return
    entries = [
        ('af3_unified_integration', status_af3_unified_integration, remove_af3_unified_integration),
        ('af3_poster_ratio_2_3', status_af3_poster_ratio_2_3, remove_af3_poster_ratio_2_3),
        ('upnext_episode_thumb', status_upnext, remove_upnext),
        ('shw_random_movies_tvshows', status_shw, remove_shw),
        ('vfs_pause_ratings', status_vfs_pause_ratings, remove_vfs_pause_ratings),
        ('reliable_studio_logos', status_reliable_studio_logos, remove_reliable_studio_logos),
    ]
    results: List[Result] = []
    _KPM_BATCH_PATCH_MODE = True
    _KPM_BATCH_RELOAD_NEEDED = False
    try:
        for patch_id, status_func, remove_func in entries:
            try:
                results.append(_remove_patch_smart(patch_id, status_func, remove_func))
            except Exception as exc:
                log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
                results.append(Result(patch_title(patch_id, patch_id), 'Error', str(exc)))
    finally:
        _KPM_BATCH_PATCH_MODE = False
        _finish_deferred_reload()
    notify('Remove Full KPM Integration finished')
    textviewer(ADDON_NAME + " - Results", format_results(results))


def patch_status_summary() -> str:
    lines = [f'Addon: {ADDON_NAME} v{VERSION}', '']
    lines.append('KPM Shared Icons: {0}'.format(shared_rating_icons_status()))
    lines.append('Screensaver widget: {0}'.format(current_screensaver_widget_path()))
    lines.append('')
    for patch_id, status_name, _apply_name, _remove_name in PATCH_ORDER:
        data = patch_detail(patch_id)
        title = data.get('title', patch_id)
        status_func = globals().get(status_name)
        try:
            status = status_func() if status_func else 'Unknown'
        except Exception as exc:
            status = f'Error ({exc})'
        lines.append(f'{title}: {status}')
    return '\n'.join(lines)


def view_status() -> None:
    textviewer(f'{ADDON_NAME} - Patch Status', patch_status_summary())


def patch_message(patch_id: str, status: str) -> str:
    data = patch_detail(patch_id)
    return (
        f"Status in Kodi: {status}\n\n"
        f"Function:\n{data.get('function', '-')}\n\n"
        f"Target:\n{data.get('target', '-')}\n\n"
        f"Reference:\n{data.get('reference', '-')}\n\n"
        'Patch style:\nInject/remove selected blocks only. No full-file overwrite.'
    )


def choose_patch_action(patch_id: str, status_func: Callable[[], str]) -> str:
    data = patch_detail(patch_id)
    title = data.get('title', patch_id)
    try:
        status = status_func()
    except Exception as exc:
        status = f'Error ({exc})'
    message = patch_message(patch_id, status)

    dialog = xbmcgui.Dialog()

    # Kodi's yesnocustom labels are custom/no/yes. Use Patch as the YES button
    # and request YES as the default focused button on Kodi versions that support it.
    # Return values: -1=cancelled, 0=no, 1=yes, 2=custom.
    if hasattr(dialog, 'yesnocustom'):
        default_yes = getattr(xbmcgui, 'DLG_YESNO_YES_BTN', None)
        try:
            if default_yes is not None:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch', defaultbutton=default_yes)
            else:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
        except TypeError:
            try:
                if default_yes is not None:
                    result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch', 0, default_yes)
                else:
                    result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
            except TypeError:
                result = dialog.yesnocustom(title, message, 'Cancel', 'Remove', 'Patch')
        if result == 1:
            return 'patch'
        if result == 0:
            return 'remove'
        return 'cancel'

    idx = dialog.select(title, [
        'Patch',
        'Remove',
        'Cancel',
    ], preselect=0)
    if idx == 0:
        return 'patch'
    if idx == 1:
        return 'remove'
    return 'cancel'


def run_patch_entry(patch_id: str, status_func: Callable[[], str], patch_func: Callable[[], Result], remove_func: Callable[[], Result]) -> None:
    action = choose_patch_action(patch_id, status_func)
    if action == 'patch':
        run_single(patch_func)
    elif action == 'remove':
        run_single(remove_func)


def run_console() -> None:
    print(f'{ADDON_NAME} v{VERSION}')
    print('This add-on is intended to run inside Kodi.')
    print('Status:')
    print('  Episode Thumb Up Next:', status_upnext())
    print('  Movies + Shows Screensaver:', status_shw())
    print('  Pause Shows Full OSD:', status_vfs_pause_ratings())
    print('  Reliable Studio Logos:', status_reliable_studio_logos())


def advanced_patches_menu(patch_entries) -> None:
    while True:
        items = [patch_detail(patch_id).get('title', patch_id) for patch_id, *_ in patch_entries]
        index = xbmcgui.Dialog().select(f'{ADDON_NAME} - Advanced Patches', items)
        if index < 0:
            return
        patch_id, status_func, patch_func, remove_func = patch_entries[index]
        run_patch_entry(patch_id, status_func, patch_func, remove_func)


def settings_menu() -> None:
    save_kpm_settings({'studio_logo_count': 1})
    if os.path.exists(state_file('reliable_studio_logos')):
        _start_resume_close_service()

    while True:
        path = current_screensaver_widget_path()
        name = current_screensaver_widget_name()
        short_path = path if len(path) <= 92 else path[:45] + '...' + path[-44:]
        scroll_ms = current_screensaver_scroll_time_ms_0209()
        items = [
            f'Choose screensaver path: {name}',
            f'Current path: {short_path}',
            'Enter path manually',
            'Restore MediaHub default',
            'Apply saved path to AF3',
            'Screensaver item duration: {0}'.format(
                _format_scroll_duration_0209(scroll_ms)
            ),
            'Plot autoscroll: OFF',
            'Apply screensaver runtime settings',
            'Reliable Studio Logos info',
            'Back',
        ]
        index = xbmcgui.Dialog().select(f'{ADDON_NAME} - Settings', items)
        if index < 0 or index == 9:
            return
        if index == 0:
            choose_screensaver_path_with_skinshortcuts()
        elif index == 1:
            ok(ADDON_NAME, f'Current screensaver widget path:\n\n{path}')
        elif index == 2:
            enter_screensaver_widget_path_manually()
        elif index == 3:
            restore_default_screensaver_widget_path()
        elif index == 4:
            result = apply_saved_screensaver_widget_path(False)
            notify(f'Screensaver path: {result.status}')
            if yesno(ADDON_NAME, f'{result.status}\n\n{result.detail}\n\nReload skin now?'):
                xbmc.executebuiltin('ReloadSkin()')
        elif index == 5:
            choose_screensaver_scroll_time_0209()
        elif index == 6:
            ok(
                ADDON_NAME,
                'Arctic Mirage plot textbox autoscroll is forced OFF.\n\n'
                'The plot remains fixed and does not crawl vertically.'
            )
        elif index == 7:
            result = apply_screensaver_runtime_settings_0209(False)
            notify('Screensaver settings: {0}'.format(result.status))
            if yesno(
                ADDON_NAME,
                '{0}\n\nReload skin now?'.format(result.detail),
            ):
                xbmc.executebuiltin('ReloadSkin()')
        elif index == 8:
            ok(ADDON_NAME, 'Reliable Studio Logos uses one best valid logo.\n\nMovie/TV: coloured resource pack, then KPM XBT fallback. Games: KPM XBT first, then grayscale resource fallback. Matching is candidate-by-candidate and specific/regional names are checked before generic names. KPM.StudioLogo.1 remains the only render source.')




def af3_unified_integration_menu() -> None:
    items = [
        'Apply AF3 Unified Integration',
        'Remove AF3 Unified Integration',
        'Status',
    ]
    index = xbmcgui.Dialog().select(f'{ADDON_NAME} - AF3 Unified Integration', items)
    if index < 0:
        return
    if index == 0:
        run_single(apply_af3_unified_integration)
    elif index == 1:
        run_single(remove_af3_unified_integration)
    elif index == 2:
        textviewer('AF3 Unified Integration - Status', status_af3_unified_integration())


def diagnostics_menu() -> None:
    while True:
        items = [
            'Start Full Visual Live Diagnostic',
            'Export Full Diagnostics ZIP',
            'Export Studio Logo Diagnostics',
        ]
        index = xbmcgui.Dialog().select(f'{ADDON_NAME} - Diagnostics', items)
        if index < 0:
            return
        if index == 0:
            start_live_diagnostics_menu()
        elif index == 1:
            run_single(export_diagnostics)
            return
        elif index == 2:
            run_single(export_studio_logo_diagnostics)
            return


def _runtime_update_mode(title: str):
    """Return fill/rebuild/cancel using an AF3-friendly three-button dialog."""
    dialog = xbmcgui.Dialog()
    try:
        choice = dialog.yesnocustom(
            title,
            'Choose update mode',
            nolabel='Fill Missing',
            yeslabel='Rebuild',
            customlabel='Cancel',
        )
        return {0: 'fill', 1: 'rebuild'}.get(choice)
    except Exception:
        index = dialog.select(title, ['Fill Missing', 'Rebuild', 'Cancel'])
        return {0: 'fill', 1: 'rebuild'}.get(index)


def _run_lrs_runtime_engine(action: str) -> None:
    # Invoke by add-on ID so Kodi 22 supplies the correct xbmcaddon context.
    if action and xbmc:
        xbmc.executebuiltin('RunScript(script.library.ratings.scraper,{0})'.format(action))


def artwork_runtime_tools() -> None:
    items = [
        'Clearlogo Resolver',
        'CropV2',
        'View Runtime Status',
        'Exit',
    ]
    index = xbmcgui.Dialog().select(ADDON_NAME + ' - Artwork Runtime Tools', items)
    if index < 0 or index == len(items) - 1:
        return
    if index == 2:
        _run_lrs_runtime_engine('runtime_status_engine')
        return
    if index == 0:
        mode = _runtime_update_mode('Clearlogo Resolver')
        if mode:
            _run_lrs_runtime_engine('resolver_{0}_engine'.format('rebuild' if mode == 'rebuild' else 'fill'))
        return
    if index == 1:
        mode = _runtime_update_mode('CropV2')
        if mode:
            _run_lrs_runtime_engine('cropv2_{0}_engine'.format('rebuild' if mode == 'rebuild' else 'fill'))


def run() -> None:
    if not xbmcgui:
        run_console()
        return
    patch_entries = [
        ('af3_unified_integration', status_af3_unified_integration, apply_af3_unified_integration, remove_af3_unified_integration),
        ('af3_poster_ratio_2_3', status_af3_poster_ratio_2_3, patch_af3_poster_ratio_2_3, remove_af3_poster_ratio_2_3),
        ('upnext_episode_thumb', status_upnext, patch_upnext, remove_upnext),
        ('shw_random_movies_tvshows', status_shw, lambda: patch_shw(100), remove_shw),
        ('vfs_pause_ratings', status_vfs_pause_ratings, patch_vfs_pause_ratings, remove_vfs_pause_ratings),
        ('reliable_studio_logos', status_reliable_studio_logos, patch_reliable_studio_logos, remove_reliable_studio_logos),
    ]
    while True:
        items = [
            'Apply Full KPM Integration',
            'Remove Full KPM Integration',
            'Advanced Patches',
            'Artwork Runtime Tools',
            'View Status',
            'Export diagnostics ZIP',
            'Diagnostics Tools',
            'Clear Add-on Icon Cache',
            'Settings',
            'Exit',
        ]
        index = xbmcgui.Dialog().select(ADDON_NAME, items)
        if index < 0 or index == len(items) - 1:
            return
        if index == 0:
            apply_all()
        elif index == 1:
            remove_all()
        elif index == 2:
            advanced_patches_menu(patch_entries)
        elif index == 3:
            artwork_runtime_tools()
            return
        elif index == 4:
            view_status()
        elif index == 5:
            run_single(export_diagnostics)
            return
        elif index == 6:
            diagnostics_menu()
            return
        elif index == 7:
            clear_addon_icon_cache_menu()
            return
        elif index == 8:
            settings_menu()


# -----------------------------------------------------------------------------
# KPM-owned AF3 rating row
# -----------------------------------------------------------------------------
KPM_AF3_ROW_CALL_START = '<!-- KPM-AF3-RATING-ROW-CALL-START-0186 -->'
KPM_AF3_ROW_CALL_END = '<!-- KPM-AF3-RATING-ROW-CALL-END-0186 -->'
KPM_AF3_ROW_DEF_START = '<!-- KPM-AF3-RATING-ROW-DEF-START-0186 -->'
KPM_AF3_ROW_DEF_END = '<!-- KPM-AF3-RATING-ROW-DEF-END-0186 -->'
KPM_STEAM_INFO_START = '<!-- KPM-AF3-STEAM-INFO-LINE-START-0186 -->'
KPM_STEAM_INFO_END = '<!-- KPM-AF3-STEAM-INFO-LINE-END-0186 -->'
KPM_STEAM_PLOT_START = '<!-- KPM-AF3-STEAM-PLOT-START-0186 -->'
KPM_STEAM_PLOT_END = '<!-- KPM-AF3-STEAM-PLOT-END-0186 -->'
KPM_SCREENSAVER_RATING_START = '<!-- KPM-AF3-SCREENSAVER-RATING-ROW-START-0186 -->'
KPM_SCREENSAVER_RATING_END = '<!-- KPM-AF3-SCREENSAVER-RATING-ROW-END-0186 -->'
CURRENT_KPM_ROW_CALL_RE = re.compile(r'\s*<!--\s*KPM-AF3-RATING-ROW-CALL-START-[^>]*-->.*?<!--\s*KPM-AF3-RATING-ROW-CALL-END-[^>]*-->\s*', re.I | re.S)
CURRENT_KPM_ROW_DEF_RE = re.compile(r'\s*<!--\s*KPM-AF3-RATING-ROW-DEF-START-[^>]*-->.*?<!--\s*KPM-AF3-RATING-ROW-DEF-END-[^>]*-->\s*', re.I | re.S)

NATIVE_AF3_META_RE = re.compile(r'\n?\s*<include\s+content=["\']Info_Meta_Ratings["\'][^>]*(?:/>|>.*?</include>)', re.I | re.S)
NATIVE_DISABLED_MARKER_RE = re.compile(r'\n?\s*<!--\s*KPM-AF3-NATIVE-META-DISABLED-[^>]*-->\s*', re.I)


def _remove_info_meta_object_containing(text: str, needles) -> str:
    """Remove only complete Info_Meta_Object include blocks containing exact needles."""
    needles = tuple(str(x) for x in needles if x)
    if not needles:
        return text
    pat = re.compile(r'\n?\s*<include\s+content=["\']Info_Meta_Object["\'][^>]*>.*?</include>\s*', re.I | re.S)
    def repl(match):
        block = match.group(0)
        return '\n' if any(n in block for n in needles) else block
    return pat.sub(repl, text)


def _remove_native_comment_include(text: str, comment: str) -> str:
    """Remove a native AF3 comment plus the single include block after it.

    Remove a native AF3 comment together with its complete include block.
    """
    pat = re.compile(r'\n?\s*<!--\s*' + re.escape(comment) + r'\s*-->\s*<include\b[^>]*>.*?</include>\s*', re.I | re.S)
    return pat.sub('\n', text)


def _disable_native_af3_meta_conflicts(text: str) -> str:
    """Make AF3 lower row KPM-only without producing malformed XML."""
    original = text
    text = NATIVE_AF3_META_RE.sub('', text)
    # EndTime in AF3 may contain two adjacent objects; remove both by exact labels.
    text = _remove_native_comment_include(text, 'EndTime')
    text = _remove_info_meta_object_containing(text, ('EndTimeResume', 'FinishTime'))
    text = _remove_native_comment_include(text, 'Awards')
    text = _remove_native_comment_include(text, 'Status')
    if text != original and not re.search(r'KPM-AF3-NATIVE-META-DISABLED-', text, re.I):
        m = re.search(r'(?m)^([ \t]*)<!--\s*Ratings\s*-->\s*$', text)
        if m:
            marker = m.group(1) + '<!-- KPM-AF3-NATIVE-META-DISABLED-0186 -->\n'
            text = text[:m.start()] + marker + text[m.start():]
    return text


def _apply_steam_game_visibility_guards(text: str) -> str:
    """Apply the current Steam Library AF3 visibility guards in KPM.

    These guards keep Info_Line visible for games and hide generic plot/star furniture.
    """
    replacements = {
        '<visible>[String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,episode) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,album) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,song) | !String.IsEmpty($PARAM[container]$PARAM[listitem].ChannelNumberLabel) | $PARAM[override]]</visible>':
        '<visible>[String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,episode) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,album) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,song) | !String.IsEmpty($PARAM[container]$PARAM[listitem].ChannelNumberLabel) | !String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) | String.IsEqual($PARAM[container]$PARAM[listitem].Property(kpm_item_type),game) | String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),game) | $PARAM[override]]</visible>',
        '<visible>String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | $PARAM[override]</visible>':
        '<visible>String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + [String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | $PARAM[override]]</visible>',
        '<visible>String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow)</visible>':
        '<visible>String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + [String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow)]</visible>',
        '<visible>String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,album) | !String.IsEmpty($PARAM[container]$PARAM[listitem].ChannelNumberLabel)</visible>':
        '<visible>String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + [String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,album) | !String.IsEmpty($PARAM[container]$PARAM[listitem].ChannelNumberLabel)]</visible>',
        '<param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Rating) + String.IsEmpty($PARAM[container]$PARAM[listitem].UserRating)</param>':
        '<param name="visible">String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].Rating) + String.IsEmpty($PARAM[container]$PARAM[listitem].UserRating)</param>',
        '<param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].UserRating)</param>':
        '<param name="visible">String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].UserRating)</param>',
    }
    for old, new in replacements.items():
        if old in text and new not in text:
            text = text.replace(old, new, 1)
    # Hide AF3's fallback info/video-quality pill for Steam items.
    pill_visible = '<param name="visible">String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</param>'
    pattern = r'(<include content="Info_Line_VideoQuality_Resolution">\s*)(<param name="colordiffuse">\$PARAM\[colordiffuse\]</param>)'
    if pill_visible not in text:
        text = re.sub(pattern, r'\1                    ' + pill_visible + r'\n                    \2', text, count=1)
    # Guard Info_Plot_Other so game plot is not duplicated.
    old_other_visible = '<visible>![String.IsEqual($PARAM[container]$PARAM[listitem].DBType,movie) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,tvshow) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,season) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,episode) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,video) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,album) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,song) | !String.IsEmpty($PARAM[container]$PARAM[listitem].ChannelNumberLabel)]</visible>'
    other_platform_guard = '<visible>String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</visible>'
    other_open = '    <include name="Info_Plot_Other">'
    other_pos = text.find(other_open)
    if other_pos >= 0:
        other_end = text.find('    <include name="Info_Plot">', other_pos)
        other_chunk = text[other_pos:other_end] if other_end >= 0 else text[other_pos:]
        other_suffix = text[other_end:] if other_end >= 0 else ''
        if other_platform_guard not in other_chunk and old_other_visible in other_chunk:
            text = text[:other_pos] + other_chunk.replace(old_other_visible, other_platform_guard + '\n            ' + old_other_visible, 1) + other_suffix
    return text

def _kpm_row_call_block() -> str:
    return '''                    {start}
                    <include content="KPM_Info_Meta_RatingRow">
                        <param name="visible">$PARAM[visible]</param>
                        <param name="container">$PARAM[container]</param>
                        <param name="listitem">$PARAM[listitem]</param>
                    </include>
                    {end}
'''.format(start=KPM_AF3_ROW_CALL_START, end=KPM_AF3_ROW_CALL_END)

def _kpm_row_def_block() -> str:
    parts = [KPM_AF3_ROW_DEF_START, '    <include name="KPM_Info_Meta_RatingRow">', '        <definition>']
    for idx in range(1, 11):
        parts.append('''            <include content="Info_Meta_Object">
                <param name="icon">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(KPM.RatingRow.Slot{idx}_IconFile)]</param>
                <param name="label">$INFO[Window(Home).Property(KPM.RatingRow.Slot{idx}_Label)]</param>
                <param name="visible">[$PARAM[visible]] + String.IsEqual(Window(Home).Property(KPM.RatingRow.Visible),true) + !String.IsEmpty(Window(Home).Property(KPM.RatingRow.Slot{idx}_Label)) + !String.IsEmpty(Window(Home).Property(KPM.RatingRow.Slot{idx}_IconFile)) + !String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),set)</param>
                <param name="colordiffuse">main_fg</param>
            </include>'''.format(idx=idx))
    parts += ['        </definition>', '    </include>', KPM_AF3_ROW_DEF_END]
    return '\n'.join(parts) + '\n'

def _remove_direct_game_meta_rows_0197(text: str) -> str:
    """Normalize the lower-row renderer before applying the current KPM snapshot row.

    KPM owns the row exclusively through KPM.RatingRow.A/B snapshots.
    """
    section_markers = (
        'Steam Game Metadata: colored icons, compact labels',
        'Steam Game Metadata: developer / publisher / achievements',
        'Steam Game Metadata: ratings',
        'Steam Game Metadata: ratings + achievements',
        'AKL Steam Game Metadata: colored icons, compact labels',
    )
    for label in section_markers:
        pat = re.compile(r'\n?\s*<!--\s*' + re.escape(label) + r'\s*-->.*?(?=\n\s*<!--\s*Total Episodes)', re.I | re.S)
        text = pat.sub('\n', text)

    direct_props = ('steam_rating_display', 'steam_review_percent', 'metacritic_score',
                    'achievement_display', 'achievement_unlocked', 'achievement_total',
                    'playtime_display', 'playtime_forever')
    include_pattern = re.compile(r'\n?\s*<include\s+content=["\']Info_Meta_Object(?:_ColorIcon)?["\'][^>]*>.*?</include>\s*', re.I | re.S)
    def strip_block(match):
        block = match.group(0)
        # Keep the KPM A/B renderer and LRS bridges; only direct ListItem blocks go.
        if 'KPM.RatingRow.' in block or 'LibraryRatings.' in block or 'LRS_Info_Meta_Ratings' in block:
            return block
        if any(prop in block for prop in direct_props) and ('.Property(' in block or 'ListItem.Property(' in block):
            return '\n'
        return block
    text = include_pattern.sub(strip_block, text)
    text = re.sub(r'\n?\s*<!--\s*STEAM-LIBRARY-AF3-DIRECT-GAME-META-REMOVED[^>]*-->\s*', '\n', text, flags=re.I)
    marker = '                    <!-- KPM-AF3-DIRECT-GAME-META-CLEANED-0198 -->\n'
    if 'KPM-AF3-DIRECT-GAME-META-CLEANED-0198' not in text:
        if re.search(r'(?m)^[ \t]*<!--\s*Total Episodes', text):
            text = re.sub(r'(?m)^([ \t]*<!--\s*Total Episodes)', marker + r'\1', text, count=1)
        elif re.search(r'(?m)^[ \t]*<!--\s*Ratings\s*-->', text):
            text = re.sub(r'(?m)^([ \t]*<!--\s*Ratings\s*-->)', marker + r'\1', text, count=1)

    # Some pre-KPM Steam patches wrapped the direct row inside a standalone
    # group. Remove only groups that contain direct game properties and no KPM
    # or LibraryRatings snapshot reference. Repeat for adjacent/nested remnants.
    group_pattern = re.compile(r'\n?\s*<control\s+type=["\']group["\'][^>]*>.*?</control>\s*', re.I | re.S)
    for _ in range(3):
        changed = False
        def strip_group(match):
            nonlocal changed
            block = match.group(0)
            if 'KPM.RatingRow.' in block or 'LibraryRatings.' in block or 'LRS_Info_Meta_Ratings' in block:
                return block
            if any(prop in block for prop in direct_props) and ('.Property(' in block or 'ListItem.Property(' in block):
                changed = True
                return '\n'
            return block
        text2 = group_pattern.sub(strip_group, text)
        text = text2
        if not changed:
            break
    return text


def _normalize_current_rating_xml(text: str) -> str:
    """Remove only the current KPM row before an idempotent reapply."""
    text = CURRENT_KPM_ROW_CALL_RE.sub('', text)
    text = CURRENT_KPM_ROW_DEF_RE.sub('', text)
    text = _disable_native_af3_meta_conflicts(text)
    return text

def _patch_kpm_rating_row_info_xml(text: str):
    original = text
    text = _normalize_current_rating_xml(text)
    # Insert after the Ratings comment even if previous repair stripped indentation.
    def add_row_call(match):
        return match.group(0).rstrip() + '\n' + _kpm_row_call_block().rstrip('\n')
    text2, n = re.subn(r'(?m)^[ \t]*<!--\s*Ratings\s*-->\s*$', add_row_call, text, count=1)
    if n:
        text = text2
    elif '<include name="Info_Meta">' in text:
        text = text.replace('<include name="Info_Meta">', '<include name="Info_Meta">\n' + _kpm_row_call_block(), 1)
    if '</includes>' in text:
        text = text.replace('</includes>', _kpm_row_def_block() + '</includes>', 1)
    return text, text != original

def _patch_kpm_steam_info_plot(text: str):
    original = text
    text = _apply_steam_game_visibility_guards(text)
    steam_info = '''                {start}
                <include content="Info_Line_Pill_Text">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">STEAM</param>
                    <param name="width">auto</param>
                    <param name="min_width">86</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</param>
                </include>
                <include content="Info_Line_StarRating" condition="!Skin.HasSetting(InfoTags.DisableStarRating)">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="rating">$PARAM[container]$PARAM[listitem].Rating</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].Rating)</param>
                </include>
                <include content="Info_Line_Label">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Property(steam_review_desc)]</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(steam_review_desc)) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(steam_review_desc),N/A)</param>
                </include>
                <include content="Info_Line_Label">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Year]</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].Year)</param>
                </include>
                <include content="Info_Line_Label">
                    <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Property(age_rating_display)]</param>
                    <param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(age_rating_display)) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(age_rating_display),N/A)</param>
                </include>
                {end}
'''.format(start=KPM_STEAM_INFO_START, end=KPM_STEAM_INFO_END)
    text = re.sub(r'\s*<!--\s*KPM-AF3-STEAM-INFO-LINE-START-[^>]*-->.*?<!--\s*KPM-AF3-STEAM-INFO-LINE-END-[^>]*-->\s*', '\n', text, flags=re.I|re.S)
    text = re.sub(r'\s*<!--\s*Steam Game Info Line\s*-->.*?(?=\s*<!--\s*Info Pill\s*-->)', '\n', text, flags=re.I|re.S)
    if '                <!-- Info Pill -->' in text:
        text = text.replace('                <!-- Info Pill -->', steam_info + '                <!-- Info Pill -->', 1)
    steam_plot = '''        {start}
        <control type="group">
            <visible>$PARAM[visible]</visible>
            <visible>![$PARAM[override]]</visible>
            <visible>!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</visible>
            <height>120</height>
            <control type="label">
                <top>0</top><left>40</left><height>40</height><width>$PARAM[width]</width>
                <font>font_main_bold</font><textcolor>$PARAM[colordiffuse]_90</textcolor>
                <label>$INFO[$PARAM[container]$PARAM[listitem].Property(tagline_display)]</label>
                <visible>!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(tagline_display))</visible>
            </control>
            <include content="Info_Plot_TextBox">
                <param name="label">$INFO[$PARAM[container]$PARAM[listitem].Plot]</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
                <param name="use_textbox">$PARAM[use_textbox]</param>
                <param name="height">80</param>
                <param name="width">$PARAM[width]</param>
                <param name="top">40</param>
            </include>
        </control>
        {end}
'''.format(start=KPM_STEAM_PLOT_START, end=KPM_STEAM_PLOT_END)
    text = re.sub(r'\s*<!--\s*KPM-AF3-STEAM-PLOT-START-[^>]*-->.*?<!--\s*KPM-AF3-STEAM-PLOT-END-[^>]*-->\s*', '\n', text, flags=re.I|re.S)
    text = re.sub(r'\s*<!--\s*Steam Game Plot\s*-->\s*<control type="group">.*?</control>\s*', '\n', text, flags=re.I|re.S)
    if '<include name="Info_Plot_Main">' in text and '        <!-- Movie -->' in text:
        text = text.replace('        <!-- Movie -->', steam_plot + '        <!-- Movie -->', 1)
    text = _apply_steam_game_visibility_guards(text)
    return text, text != original


def _screensaver_rating_row_block() -> str:
    parts = [
        '        {start}',
        '        <control type="grouplist">',
        '            <left>90</left>',
        '            <top>900</top>',
        '            <width>1300</width>',
        '            <height>56</height>',
        '            <orientation>horizontal</orientation>',
        '            <itemgap>12</itemgap>',
        '            <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.Display_RatingSlots),true)</visible>',
        '            <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Value))</visible>',
    ]
    for idx in range(1, 8):
        parts.append("""            <include content=\"Info_Meta_Object\">
                <param name=\"icon\">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot{idx}_IconFile)]</param>
                <param name=\"label\">$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot{idx}_Value)]</param>
                <param name=\"visible\">!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot{idx}_Value)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot{idx}_IconFile))</param>
                <param name=\"colordiffuse\">main_fg</param>
            </include>""".format(idx=idx))
    parts.extend([
        '        </control>',
        '        {end}',
    ])
    return '\n'.join(parts).format(start=KPM_SCREENSAVER_RATING_START, end=KPM_SCREENSAVER_RATING_END) + '\n'



KPM_SCREENSAVER_CLEARLOGO_START_0207 = '<!-- KPM-AF3-SCREENSAVER-CLEARLOGO-FINAL-START-0207 -->'
KPM_SCREENSAVER_CLEARLOGO_END_0207 = '<!-- KPM-AF3-SCREENSAVER-CLEARLOGO-FINAL-END-0207 -->'


def _screensaver_clearlogo_group_0207(indent: str) -> str:
    """Strict current-item clearlogo layout for both Arctic Mirage panels."""
    i0 = indent
    i1 = indent + '    '
    i2 = indent + '        '
    i3 = indent + '            '

    current_key = (
        'Container(1297).ListItem.Property(mediahub_item_key)'
    )
    final_key = (
        'Window(Home).Property('
        'LibraryRatings.Screensaver.ClearLogoFinalItemKey)'
    )
    item_match = (
        '!String.IsEmpty({current_key}) + '
        'String.IsEqual({current_key},{final_key})'
    ).format(current_key=current_key, final_key=final_key)
    resolver_ready = (
        'String.IsEqual(Window(Home).Property('
        'LibraryRatings.Screensaver.ClearLogoResolverReady),true)'
    )
    mode_title = (
        'String.IsEqual(Window(Home).Property('
        'LibraryRatings.Screensaver.ClearLogoFinalMode),title)'
    )
    mode_cropv2 = (
        'String.IsEqual(Window(Home).Property('
        'LibraryRatings.Screensaver.ClearLogoFinalMode),cropv2)'
    )
    final_path = (
        'Window(Home).Property('
        'LibraryRatings.Screensaver.ClearLogoFinal)'
    )

    return '\n'.join([
        i0 + '<control type="group">',
        i1 + '<width>680</width>',
        i1 + '<height>280</height>',
        i1 + KPM_SCREENSAVER_CLEARLOGO_START_0207,
        i1 + '<control type="grouplist">',
        i2 + '<left>0</left>',
        i2 + '<bottom>0</bottom>',
        i2 + '<width>680</width>',
        i2 + '<height>280</height>',
        i2 + '<orientation>vertical</orientation>',
        i2 + '<align>bottom</align>',
        i2 + '<control type="textbox">',
        i3 + '<font>font_title_midi</font>',
        i3 + '<textcolor>main_fg_100</textcolor>',
        i3 + '<label>$INFO[Container(1297).ListItem.Title]</label>',
        i3 + '<width>680</width>',
        i3 + '<height max="270">auto</height>',
        i3 + '<aligny>center</aligny>',
        i3 + '<align>center</align>',
        i3 + '<visible>{item_match} + {resolver_ready} + {mode_title}</visible>'.format(
            item_match=item_match,
            resolver_ready=resolver_ready,
            mode_title=mode_title,
        ),
        i2 + '</control>',
        i1 + '</control>',
        i1 + '<control type="image">',
        i2 + '<left>0</left>',
        i2 + '<bottom>0</bottom>',
        i2 + '<width>680</width>',
        i2 + '<height>280</height>',
        i2 + '<texture background="true">'
             '$INFO[Window(Home).Property('
             'LibraryRatings.Screensaver.ClearLogoFinal)]</texture>',
        i2 + '<aspectratio align="center" aligny="bottom">keep</aspectratio>',
        i2 + '<visible>{item_match} + {resolver_ready} + {mode_cropv2} + '
             '!String.IsEmpty({final_path})</visible>'.format(
                 item_match=item_match,
                 resolver_ready=resolver_ready,
                 mode_cropv2=mode_cropv2,
                 final_path=final_path,
             ),
        i1 + '</control>',
        i1 + KPM_SCREENSAVER_CLEARLOGO_END_0207,
        i0 + '</control>',
    ])


def _patch_screensaver_clearlogo_final_0207(text: str):
    """Replace both AF3 left/right logo groups without changing coordinates."""
    owned_re = re.compile(
        r'(?P<indent>^[ \t]*)<control type="group">\s*'
        r'(?:<width>680</width>\s*)?'
        r'<height>280</height>\s*'
        r'<!--\s*KPM-AF3-SCREENSAVER-CLEARLOGO-FINAL-START-0207\s*-->'
        r'.*?'
        r'<!--\s*KPM-AF3-SCREENSAVER-CLEARLOGO-FINAL-END-0207\s*-->\s*'
        r'</control>',
        re.I | re.S | re.M,
    )
    native_re = re.compile(
        r'(?P<indent>^[ \t]*)<control type="group">\s*\n'
        r'(?P=indent)    <height>280</height>\s*\n'
        r'(?P=indent)    <control type="grouplist">.*?'
        r'(?P=indent)    </control>\s*\n'
        r'(?P=indent)    <control type="image">.*?'
        r'Container\(1297\)\.ListItem\.Art\(clearlogo\).*?'
        r'(?P=indent)    </control>\s*\n'
        r'(?P=indent)</control>',
        re.I | re.S | re.M,
    )

    owned_matches = list(owned_re.finditer(text))
    if owned_matches:
        if len(owned_matches) != 2:
            raise ValueError(
                'Expected two KPM screensaver clearlogo groups; found {0}.'.format(
                    len(owned_matches)
                )
            )
        patched = owned_re.sub(
            lambda match: _screensaver_clearlogo_group_0207(
                match.group('indent')
            ),
            text,
        )
        return patched, patched != text

    native_matches = list(native_re.finditer(text))
    if len(native_matches) != 2:
        raise ValueError(
            'Expected two native AF3 screensaver clearlogo groups; found {0}.'.format(
                len(native_matches)
            )
        )

    patched = native_re.sub(
        lambda match: _screensaver_clearlogo_group_0207(
            match.group('indent')
        ),
        text,
    )
    return patched, patched != text



def _upgrade_current_screensaver_fadeout_0235(text: str) -> str:
    """Update only the six current KPM metadata panels from any old Hidden fade to 1 ms."""
    replacements = []
    panels = _metadata_panels_current_0233(text)
    if len(panels) != 6:
        raise ValueError('Expected six current metadata panels before fade-out update; found {0}'.format(len(panels)))
    for start, end, block in panels:
        updated, count = re.subn(
            r'(<animation\s+effect="fade"\s+start="100"\s+end="0"\s+time=")\d+("\s*>Hidden</animation>)',
            r'\g<1>1\g<2>',
            block,
            count=1,
            flags=re.I,
        )
        if count != 1:
            raise ValueError('Current metadata panel Hidden fade-out is missing or duplicated')
        replacements.append((start, end, updated))
    for start, end, block in sorted(replacements, key=lambda item: item[0], reverse=True):
        text = text[:start] + block + text[end:]
    _validate_current_screensaver_0233(text)
    return text


def _patch_screensaver_mirage_xml() -> bool:
    """Add a marker-scoped rating row to AF3 Arctic Mirage screensaver if it exists."""
    path = af3_path('1080i', 'screensaver-arctic-mirage.xml')
    if not os.path.exists(path):
        return False
    text = read_text(path)
    original = text
    text = re.sub(r'\s*<!--\s*KPM-AF3-SCREENSAVER-RATING-ROW-START-[^>]*-->.*?<!--\s*KPM-AF3-SCREENSAVER-RATING-ROW-END-[^>]*-->\s*', '\n', text, flags=re.I | re.S)
    pos = text.lower().rfind('</controls>')
    if pos < 0:
        return False
    text = text[:pos] + _screensaver_rating_row_block() + text[pos:]
    if text != original:
        backup = path + '.kpm0186-screensaver-rating.bak'
        if not os.path.exists(backup):
            write_text(backup, original)
        write_text(path, text)
        return True
    return False


def _patch_af3_info_xml_kpm_owned(text: str):
    t, c1 = _patch_kpm_rating_row_info_xml(text)
    t, c2 = _patch_kpm_steam_info_plot(t)
    return t, c1 or c2

def _patch_file_text(path: str, patcher, backup_suffix: str) -> bool:
    original = read_text(path)
    backup = path + backup_suffix
    if not os.path.exists(backup): write_text(backup, original)
    patched, changed = patcher(original)
    if changed: write_text(path, patched)
    return changed


def _patch_af3_info_xml_safely(path: str) -> bool:
    original_current = read_text(path)
    backup = path + '.kpm0186-unified.bak'
    if not os.path.exists(backup):
        write_text(backup, original_current)
    patched, changed = _patch_af3_info_xml_kpm_owned(original_current)
    if patched != original_current:
        write_text(path, patched)
        return True
    return bool(changed)

def status_af3_unified_integration() -> str:
    info = af3_path('1080i', 'Includes_Info.xml')
    if os.path.exists(info):
        try:
            text = read_text(info)
            if KPM_AF3_ROW_CALL_START in text and KPM_AF3_ROW_DEF_START in text:
                return 'Patched (KPM-owned)'
        except Exception:
            pass
    return 'Not patched'

def apply_af3_unified_integration() -> Result:
    info_xml = af3_path('1080i', 'Includes_Info.xml')
    if not os.path.exists(info_xml):
        return Result('AF3 Unified Integration', 'Skipped', 'Includes_Info.xml not found:\n{0}'.format(info_xml))
    changed = _patch_af3_info_xml_safely(info_xml)
    ss_changed = False
    try:
        ss_changed = _patch_screensaver_mirage_xml()
    except Exception as exc:  # pylint: disable=broad-except
        log('Screensaver rating row patch skipped: {0}'.format(exc))
    save_state('af3_unified_integration', {'enabled': True, 'version': VERSION, 'owner': 'KPM', 'visual_properties': 'KPM.RatingRow.* + LibraryRatings.Screensaver.*', 'changed': bool(changed or ss_changed)})
    return Result('AF3 Unified Integration', 'Patched' if (changed or ss_changed) else 'Skipped', 'KPM-owned AF3 integration is active.' + ('' if (changed or ss_changed) else ' Already current.'))

def remove_af3_unified_integration() -> Result:
    info_xml = af3_path('1080i', 'Includes_Info.xml')
    changed = False
    if os.path.exists(info_xml):
        backup = info_xml + '.kpm0186-unified.bak'
        if os.path.exists(backup):
            shutil.copy2(backup, info_xml)
            changed = True
        else:
            original = read_text(info_xml)
            # Fallback only removes KPM-owned blocks. It does not touch native
            # AF3 sections when the original backup is unavailable.
            text = CURRENT_KPM_ROW_CALL_RE.sub('', original)
            text = CURRENT_KPM_ROW_DEF_RE.sub('', text)
            text = re.sub(r'\s*<!--\s*KPM-AF3-STEAM-INFO-LINE-START-[^>]*-->.*?<!--\s*KPM-AF3-STEAM-INFO-LINE-END-[^>]*-->\s*', '\n', text, flags=re.I|re.S)
            text = re.sub(r'\s*<!--\s*KPM-AF3-STEAM-PLOT-START-[^>]*-->.*?<!--\s*KPM-AF3-STEAM-PLOT-END-[^>]*-->\s*', '\n', text, flags=re.I|re.S)
            text = NATIVE_DISABLED_MARKER_RE.sub('\n', text)
            if text != original:
                write_text(info_xml, text)
                changed = True
    ss_xml = af3_path('1080i', 'screensaver-arctic-mirage.xml')
    if os.path.exists(ss_xml):
        ss_backup = ss_xml + '.kpm0186-screensaver-rating.bak'
        if os.path.exists(ss_backup):
            shutil.copy2(ss_backup, ss_xml)
            changed = True
        else:
            ss_text = read_text(ss_xml)
            ss_new = re.sub(r'\s*<!--\s*KPM-AF3-SCREENSAVER-RATING-ROW-START-[^>]*-->.*?<!--\s*KPM-AF3-SCREENSAVER-RATING-ROW-END-[^>]*-->\s*', '\n', ss_text, flags=re.I | re.S)
            if ss_new != ss_text:
                write_text(ss_xml, ss_new)
                changed = True
    delete_state('af3_unified_integration')
    return Result('AF3 Unified Integration', 'Removed' if changed else 'Skipped', 'KPM-owned AF3 integration removed.' if changed else 'Not installed; no file was touched.')

# -----------------------------------------------------------------------------
# v0.1.87 - old-behavior parity (golden LRS/Steam implementations)
# -----------------------------------------------------------------------------
KPM_AF3_ROW_CALL_START = '<!-- KPM-AF3-RATING-ROW-CALL-START-0188 -->'
KPM_AF3_ROW_CALL_END = '<!-- KPM-AF3-RATING-ROW-CALL-END-0188 -->'
KPM_AF3_ROW_DEF_START = '<!-- KPM-AF3-RATING-ROW-DEF-START-0188 -->'
KPM_AF3_ROW_DEF_END = '<!-- KPM-AF3-RATING-ROW-DEF-END-0188 -->'
KPM_STEAM_INFO_START = '<!-- KPM-AF3-STEAM-INFO-LINE-START-0188 -->'
KPM_STEAM_INFO_END = '<!-- KPM-AF3-STEAM-INFO-LINE-END-0188 -->'
KPM_STEAM_PLOT_START = '<!-- KPM-AF3-STEAM-PLOT-START-0188 -->'
KPM_STEAM_PLOT_END = '<!-- KPM-AF3-STEAM-PLOT-END-0188 -->'
KPM_SCREENSAVER_RATING_START = '<!-- KPM-AF3-SCREENSAVER-RATING-ROW-START-0188 -->'
KPM_SCREENSAVER_RATING_END = '<!-- KPM-AF3-SCREENSAVER-RATING-ROW-END-0188 -->'
KPM_LAYOUT_MARKER_BEGIN = '<!-- KPM Compact Steam Landscape BEGIN 0188 -->'
KPM_LAYOUT_MARKER_END = '<!-- KPM Compact Steam Landscape END 0188 -->'
KPM_LAYOUT_ORIGINAL_BEGIN = '<!-- KPM Original Landscape BEGIN 0188 -->'
KPM_LAYOUT_ORIGINAL_END = '<!-- KPM Original Landscape END 0188 -->'
KPM_COMPACT_LANDSCAPE_H = '192'
# Do not consume indentation of the XML node following a marker block.


def _kpm_row_call_block() -> str:
    return '''                    {start}
                    <include content="KPM_Info_Meta_RatingRow">
                        <param name="visible">$PARAM[visible]</param>
                        <param name="container">$PARAM[container]</param>
                        <param name="listitem">$PARAM[listitem]</param>
                        <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    </include>
                    {end}
'''.format(start=KPM_AF3_ROW_CALL_START, end=KPM_AF3_ROW_CALL_END)


def _kpm_row_def_block() -> str:
    # Exact mature LRS rule: IMDb icon width 52; all other icons keep AF3 native width.
    no_collection = '!String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) + !String.IsEqual($PARAM[container]$PARAM[listitem].DBType,collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(is_collection),true)'
    not_loading = '!Window.IsVisible(busydialog) + !Window.IsVisible(busydialognocancel)'
    parts = [KPM_AF3_ROW_DEF_START, '    <include name="KPM_Info_Meta_RatingRow">', '        <definition>']
    for idx in range(1, 11):
        icon = 'special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(KPM.RatingRow.Slot{0}_IconFile)]'.format(idx)
        label = '$INFO[Window(Home).Property(KPM.RatingRow.Slot{0}_Label)]'.format(idx)
        src = 'Window(Home).Property(KPM.RatingRow.Slot{0}_Source)'.format(idx)
        visible = '[$PARAM[visible]] + String.IsEqual(Window(Home).Property(KPM.RatingRow.Visible),true) + {no_collection} + {not_loading} + !String.IsEmpty(Window(Home).Property(KPM.RatingRow.Slot{idx}_Label)) + !String.IsEmpty(Window(Home).Property(KPM.RatingRow.Slot{idx}_IconFile))'.format(no_collection=no_collection, not_loading=not_loading, idx=idx)
        parts.append('''            <include content="Info_Meta_Object">
                <param name="icon">{icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + String.IsEqual({src},imdb)</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
                <param name="icon_w">52</param>
            </include>
            <include content="Info_Meta_Object">
                <param name="icon">{icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + !String.IsEqual({src},imdb)</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
            </include>'''.format(icon=icon, label=label, visible=visible, src=src))
    parts += ['        </definition>', '    </include>', KPM_AF3_ROW_DEF_END]
    return '\n'.join(parts) + '\n'

_KPM_0187_SCREENSAVER_ROW = '                <!-- KPM-AF3-SCREENSAVER-RATING-ROW-START-0188 -->\n                <control type="grouplist">\n                    <orientation>horizontal</orientation>\n                    <align>center</align>\n                    <height>54</height>\n                    <centertop>332</centertop>\n                    <itemgap>12</itemgap>\n                    <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.HasData),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.ClearLogoFinalTitle),Container(1297).ListItem.Title)</visible>\n                    <!-- LRS RatingSlot1 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot1_IconFile))</visible>\n                    </control>\n                    <!-- LRS RatingSlot2 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot2_IconFile))</visible>\n                    </control>\n                    <!-- LRS RatingSlot3 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot3_IconFile))</visible>\n                    </control>\n                    <!-- LRS RatingSlot4 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot4_IconFile))</visible>\n                    </control>\n                    <!-- LRS RatingSlot5 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot5_IconFile))</visible>\n                    </control>\n                    <!-- LRS RatingSlot6 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot6_IconFile))</visible>\n                    </control>\n                    <!-- LRS RatingSlot7 -->\n                    <control type="image">\n                        <width>52</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_IconFile)) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_Source),imdb)</visible>\n                    </control>\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_IconFile)]</texture>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_IconFile)) + !String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_Source),imdb)</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_Label)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_IconFile))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_Label)) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.RatingSlot7_IconFile))</visible>\n                    </control>\n                    <!-- LRS Oscar -->\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/oscars.png</texture>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins),x,]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible>\n                    </control>\n                    <!-- LRS Emmy -->\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/emmys.png</texture>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins),x,]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible>\n                    </control>\n                    <!-- LRS TV status -->\n                    <control type="image">\n                        <width>32</width>\n                        <height>32</height>\n                        <aspectratio>keep</aspectratio>\n                        <centertop>50%</centertop>\n                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/ends.png</texture>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible>\n                    </control>\n                    <control type="label">\n                        <aligny>center</aligny>\n                        <label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel)]</label>\n                        <textcolor>main_fg_70</textcolor>\n                        <font>font_main</font>\n                        <width max="680">auto</width>\n                        <textoffsetx>0</textoffsetx>\n                        <texturefocus />\n                        <texturenofocus />\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible>\n                    </control>\n                    <control type="group">\n                        <width>-4</width>\n                        <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible>\n                    </control>\n                </control>\n                <!-- KPM-AF3-SCREENSAVER-RATING-ROW-END-0188 -->\n'


def _screensaver_rating_row_block() -> str:
    return _KPM_0187_SCREENSAVER_ROW



KPM_SCREENSAVER_TRANSITION_START_0211 = (
    '<!-- KPM-AF3-SCREENSAVER-METADATA-TRANSITION-START-0211 -->'
)
KPM_SCREENSAVER_TRANSITION_END_0211 = (
    '<!-- KPM-AF3-SCREENSAVER-METADATA-TRANSITION-END-0211 -->'
)


def _patch_screensaver_metadata_transition_0211(
    text: str,
) -> Tuple[str, bool]:
    """Stop the outgoing Arctic Mirage metadata panel from lingering."""
    original = text

    marker_count = text.count(KPM_SCREENSAVER_TRANSITION_START_0211)
    hidden_count = text.count(
        '<animation effect="fade" start="100" end="0" '
        'time="1">Hidden</animation>'
    )
    if marker_count == 2 and hidden_count == 2:
        ET.fromstring(text)
        return text, False
    if marker_count or hidden_count:
        raise ValueError(
            'Partial KPM screensaver transition patch detected; refusing to stack'
        )

    pattern = re.compile(
        r'(?P<prefix>'
        r'(?P<indent>^[ \t]*)<control type="group">\s*\n'
        r'(?P=indent)    <(?P<side>left|right)>view_pad</(?P=side)>\s*\n'
        r'(?P=indent)    <width>680</width>\s*\n'
        r'(?P=indent)    <visible>'
        r'(?P<condition>!?Integer\.IsOdd\(ListItem\.CurrentItem\))'
        r'</visible>\s*\n'
        r')'
        r'(?P=indent)    <animation effect="fade" start="0" end="100" '
        r'time="400">Visible</animation>',
        re.I | re.M,
    )

    matches = list(pattern.finditer(text))
    if len(matches) != 2:
        raise ValueError(
            'Expected two Arctic Mirage metadata panels; found {0}.'.format(
                len(matches)
            )
        )

    def replace(match: re.Match) -> str:
        indent = match.group('indent') + '    '
        return (
            match.group('prefix')
            + indent + KPM_SCREENSAVER_TRANSITION_START_0211 + '\n'
            + indent
            + '<animation effect="fade" start="0" end="100" '
              'time="400">Visible</animation>\n'
            + indent
            + '<animation effect="fade" start="100" end="0" '
              'time="1">Hidden</animation>\n'
            + indent + KPM_SCREENSAVER_TRANSITION_END_0211
        )

    text = pattern.sub(replace, text)

    if text.count(KPM_SCREENSAVER_TRANSITION_START_0211) != 2:
        raise ValueError('Both metadata panels were not patched')
    if text.count(
        '<animation effect="fade" start="100" end="0" '
        'time="1">Hidden</animation>'
    ) != 2:
        raise ValueError('Outgoing metadata animation is incomplete')

    ET.fromstring(text)
    return text, text != original



def _patch_screensaver_mirage_xml() -> bool:
    """Restore the exact known-good row placement; never append at a guessed top."""
    path = af3_path('1080i', 'screensaver-arctic-mirage.xml')
    if not os.path.exists(path):
        return False
    original = read_text(path)
    text = original
    # Keep an already-correct KPM row in place or replace the exact native star row.
    kpm_re = re.compile(r'\s*<!--\s*KPM-AF3-SCREENSAVER-RATING-ROW-START-[^>]*-->.*?<!--\s*KPM-AF3-SCREENSAVER-RATING-ROW-END-[^>]*-->\s*', re.I | re.S)
    had_exact_kpm = False
    def replace_kpm(match):
        nonlocal_hack = match.group(0)
        if '<centertop>332</centertop>' in nonlocal_hack and '<top>900</top>' not in nonlocal_hack:
            return '\n' + _screensaver_rating_row_block().rstrip('\n') + '\n'
        return '\n'
    current_blocks = kpm_re.findall(text)
    had_exact_kpm = any('<centertop>332</centertop>' in block and '<top>900</top>' not in block for block in current_blocks)
    text = kpm_re.sub(replace_kpm, text)
    if had_exact_kpm:
        pass
    else:
        # Replace the exact native AF3 star-rating block.
        native_re = re.compile(
            r'(?P<indent>^[ \t]*)<include\s+content=["\']Info_StarRating["\']>\s*'
            r'.*?<param\s+name=["\']rating["\']>Container\(1297\)\.ListItem\.Rating</param>\s*'
            r'.*?<centertop>320</centertop>\s*.*?</include>', re.I | re.S | re.M)
        if native_re.search(text):
            def repl(match):
                indent = match.group('indent')
                lines = _screensaver_rating_row_block().rstrip('\n').splitlines()
                min_indent = min((len(x) - len(x.lstrip(' ')) for x in lines if x.strip()), default=0)
                return '\n'.join(indent + x[min_indent:] for x in lines)
            text = native_re.sub(repl, text)
        else:
            log('Screensaver row not changed: exact native target not found; refusing guessed placement.')
            return False
    text, clearlogo_changed_0207 = _patch_screensaver_clearlogo_final_0207(text)
    text, runtime_changed_0209 = _patch_screensaver_runtime_settings_0209(text)
    text, transition_changed_0211 = (
        _patch_screensaver_metadata_transition_0211(text)
    )
    if text.count(KPM_SCREENSAVER_RATING_START) < 1:
        raise ValueError('Screensaver row marker missing after patch')
    if '<centertop>332</centertop>' not in text or '<height>54</height>' not in text or '<itemgap>12</itemgap>' not in text:
        raise ValueError('Screensaver geometry validation failed')
    if text.count(KPM_SCREENSAVER_CLEARLOGO_START_0207) != 2:
        raise ValueError('Both screensaver clearlogo groups were not patched')
    if text.count('<width>680</width>') < 6:
        raise ValueError('Screensaver clearlogo width geometry was not applied')
    if text.count('<height>280</height>') < 6:
        raise ValueError('Screensaver clearlogo height geometry was not applied')
    if text.count('<bottom>0</bottom>') < 4:
        raise ValueError('Screensaver clearlogo bottom anchor was not applied')
    if text.count(
        '<aspectratio align="center" aligny="bottom">keep</aspectratio>'
    ) < 2:
        raise ValueError('Screensaver clearlogo alignment was not applied')
    if text.count(KPM_SCREENSAVER_TRANSITION_START_0211) != 2:
        raise ValueError('Screensaver metadata transition fix is incomplete')
    if text.count(
        '<animation effect="fade" start="100" end="0" '
        'time="1">Hidden</animation>'
    ) != 2:
        raise ValueError('Screensaver outgoing metadata is not instant-hidden')
    ET.fromstring(text)
    if text != original:
        backup = path + '.kpm0188-screensaver-rating.bak'
        if not os.path.exists(backup):
            write_text(backup, original)
        write_text(path, text)
        return True
    return False


def _find_xml_include_block_0187(text: str, include_name: str):
    start_marker = '    <include name="{}">'.format(include_name)
    start = text.find(start_marker)
    if start < 0:
        return -1, -1, ''
    next_start = text.find('\n    <include name="', start + len(start_marker))
    close_root = text.find('\n</includes>', start)
    if next_start >= 0 and (close_root < 0 or next_start < close_root):
        end = next_start + 1
    elif close_root >= 0:
        end = close_root
    else:
        end = len(text)
    return start, end, text[start:end]


def _extract_definition_root_inner_0187(block: str) -> str:
    def_start = block.find('        <definition>')
    def_end = block.rfind('        </definition>')
    if def_start < 0 or def_end < 0 or def_end <= def_start:
        return ''
    root_start = block.find('            <control type="group">', def_start, def_end)
    if root_start < 0:
        return ''
    first_line_end = block.find('\n', root_start)
    root_close = block.rfind('            </control>', root_start, def_end)
    if first_line_end < 0 or root_close < 0:
        return ''
    return block[first_line_end + 1:root_close]


def _compact_landscape_group_0187(original_inner: str) -> str:
    # Exact dimensions and layout copied from Steam Library 0.3.67.
    return '''                {begin}
                <control type="group">
                    <visible>!String.IsEmpty($PARAM[listitem].Property(platform))</visible>
                    <width>$PARAM[item_w]</width>
                    <height>{height}</height>

                    <include content="Object_ItemBack">
                        <param name="selected">$PARAM[selected]</param>
                        <param name="shadow_colordiffuse">$PARAM[shadow_colordiffuse]</param>
                    </include>

                    <include content="Object_Control" condition="$PARAM[selected]">
                        <param name="control">image</param>
                        <include>Texture_Box_Highlight_V</include>
                    </include>

                    <include content="Object_Layout_Image_Rectangle" condition="![$PARAM[detailed]]">
                        <param name="diffuse">$PARAM[diffuse]</param>
                        <param name="icon">$PARAM[icon]</param>
                        <param name="listitem">$PARAM[listitem]</param>
                        <param name="selected">$PARAM[selected]</param>
                        <param name="aspectratio">keep</param>
                    </include>

                    <include content="Object_Layout_Image_Rectangle" condition="$PARAM[detailed]">
                        <param name="diffuse">$PARAM[diffuse]</param>
                        <param name="icon">$PARAM[icon]</param>
                        <param name="listitem">$PARAM[listitem]</param>
                        <param name="selected">$PARAM[selected]</param>
                        <param name="aspectratio">scale</param>
                    </include>

                    <include content="Object_ProgressLine">
                        <param name="progress">$PARAM[listitem].$PARAM[progress]</param>
                    </include>

                    <include content="Object_Indicator" condition="!$PARAM[selected]">
                        <param name="affix">$PARAM[affix]</param>
                        <param name="listitem">$PARAM[listitem]</param>
                    </include>

                    <include content="Object_ContentBanner" condition="$PARAM[indicator]">
                        <param name="listitem">$PARAM[listitem]</param>
                    </include>

                    <include content="Object_TraktOverlays" condition="$PARAM[indicator] + [Skin.HasSetting(Indicator.TraktWatchlist) | Skin.HasSetting(Indicator.TraktFavourites)]">
                        <param name="listitem">$PARAM[listitem]</param>
                    </include>

                    <include content="Layout_Labels" condition="![$PARAM[detailed]]">
                        <param name="top">10</param>
                        <param name="item_h">{height}</param>
                        <param name="affix">$PARAM[affix]</param>
                        <param name="listitem">$PARAM[listitem]</param>
                        <param name="textcolor">$PARAM[textcolor]</param>
                        <param name="use_label2">$PARAM[use_label2]</param>
                    </include>

                    <include content="Object_SelectBox" condition="$PARAM[selected]">
                        <param name="affix">$PARAM[affix]</param>
                        <param name="indicator">true</param>
                        <param name="focusbounce">true</param>
                        <param name="listitem">$PARAM[listitem]</param>
                    </include>
                </control>
                {end}

                {orig_begin}
                <control type="group">
                    <visible>String.IsEmpty($PARAM[listitem].Property(platform))</visible>
{original_inner}
                </control>
                {orig_end}
'''.format(begin=KPM_LAYOUT_MARKER_BEGIN, end=KPM_LAYOUT_MARKER_END,
           orig_begin=KPM_LAYOUT_ORIGINAL_BEGIN, orig_end=KPM_LAYOUT_ORIGINAL_END,
           height=KPM_COMPACT_LANDSCAPE_H, original_inner=original_inner.rstrip('\n'))


def _restore_compact_landscape_0187(text: str):
    marker_sets = [
        (KPM_LAYOUT_ORIGINAL_BEGIN, KPM_LAYOUT_ORIGINAL_END),
    ]
    start, end, block = _find_xml_include_block_0187(text, 'Layout_Landscape')
    if start < 0:
        return text, False
    for original_begin, original_end in marker_sets:
        if original_begin not in block or original_end not in block:
            continue
        pos1 = block.find(original_begin)
        pos2 = block.find(original_end, pos1)
        chunk = block[pos1 + len(original_begin):pos2]
        lines = chunk.splitlines()
        while lines and not lines[0].strip(): lines.pop(0)
        while lines and not lines[-1].strip(): lines.pop()
        if not lines or '<control type="group"' not in lines[0]:
            continue
        lines = lines[1:]
        if lines and 'String.IsEmpty($PARAM[listitem].Property(platform))' in lines[0]:
            lines = lines[1:]
        while lines and not lines[-1].strip(): lines.pop()
        if lines and lines[-1].strip() == '</control>': lines = lines[:-1]
        original_inner = '\n'.join(lines).rstrip('\n')
        def_start = block.find('        <definition>')
        def_end = block.rfind('        </definition>')
        if def_start < 0 or def_end < 0:
            continue
        restored = '''        <definition>
            <control type="group">
{original_inner}
            </control>
        </definition>'''.format(original_inner=original_inner)
        new_block = block[:def_start] + restored + block[def_end + len('        </definition>'):]
        out = text[:start] + new_block + text[end:]
        ET.fromstring(out)
        return out, True
    return text, False


def _patch_af3_layouts_0187(text: str):
    original = text
    text, _ = _restore_compact_landscape_0187(text)
    start, end, block = _find_xml_include_block_0187(text, 'Layout_Landscape')
    if start < 0:
        return original, False
    original_inner = _extract_definition_root_inner_0187(block)
    if not original_inner:
        return original, False
    def_start = block.find('        <definition>')
    def_end = block.rfind('        </definition>')
    new_definition = '''        <definition>
            <control type="group">
                <width>$PARAM[item_w]</width>
                <height>$PARAM[item_h]</height>

{steam_group}            </control>
        </definition>'''.format(steam_group=_compact_landscape_group_0187(original_inner))
    block = block[:def_start] + new_definition + block[def_end + len('        </definition>'):]
    text = text[:start] + block + text[end:]
    ET.fromstring(text)
    return text, text != original


def _patch_af3_layouts_file_0187() -> bool:
    path = af3_path('1080i', 'Includes_Layouts.xml')
    if not os.path.exists(path):
        return False
    original = read_text(path)
    patched, changed = _patch_af3_layouts_0187(original)
    if changed:
        backup = path + '.kpm0188-layouts.bak'
        if not os.path.exists(backup):
            write_text(backup, original)
        write_text(path, patched)
    return changed


def status_af3_unified_integration() -> str:
    info = af3_path('1080i', 'Includes_Info.xml')
    layouts = af3_path('1080i', 'Includes_Layouts.xml')
    row_ok = False
    layout_ok = False
    if os.path.exists(info):
        try:
            text = read_text(info)
            row_ok = KPM_AF3_ROW_CALL_START in text and KPM_AF3_ROW_DEF_START in text and '<param name="icon_w">52</param>' in text
        except Exception:
            pass
    if os.path.exists(layouts):
        try:
            layout_ok = KPM_LAYOUT_MARKER_BEGIN in read_text(layouts)
        except Exception:
            pass
    if row_ok and layout_ok:
        return 'Patched (KPM-owned)'
    if row_ok:
        return 'Patched (row active; landscape layout unavailable)'
    return 'Not patched'


def apply_af3_unified_integration() -> Result:
    info_xml = af3_path('1080i', 'Includes_Info.xml')
    if not os.path.exists(info_xml):
        return Result('AF3 Unified Integration', 'Skipped', 'Includes_Info.xml not found:\n{0}'.format(info_xml))
    changed = _patch_af3_info_xml_safely(info_xml)
    ss_changed = False
    layout_changed = False
    try:
        ss_changed = _patch_screensaver_mirage_xml()
    except Exception as exc:
        log('Screensaver exact-row patch skipped: {0}'.format(exc))
    try:
        layout_changed = _patch_af3_layouts_file_0187()
    except Exception as exc:
        log('Exact 192px game landscape patch skipped: {0}'.format(exc))
    any_changed = bool(changed or ss_changed or layout_changed)
    save_state('af3_unified_integration', {
        'enabled': True,
        'version': VERSION,
        'owner': 'KPM',
        'visual_properties': 'KPM.RatingRow.* bridged from LibraryRatings.HomeHub.DisplaySlot* + LibraryRatings.Screensaver.*',
        'game_landscape_height': KPM_COMPACT_LANDSCAPE_H,
        'changed': any_changed,
    })
    detail = 'KPM row, exact 192px Steam landscape, and notification-safe screensaver placement are active.'
    return Result('AF3 Unified Integration', 'Patched' if any_changed else 'Skipped', detail + ('' if any_changed else ' Already current.'))

# Current idempotent row injector: marker removal must not accumulate blanks.
def _patch_kpm_rating_row_info_xml(text: str):
    original = text
    text = _normalize_current_rating_xml(text)
    text = re.sub(r'\n{3,}(?=</includes>)', '\n\n', text)
    def add_row_call(match):
        return match.group(0).rstrip() + '\n' + _kpm_row_call_block().rstrip('\n')
    text2, count = re.subn(r'(?m)^[ \t]*<!--\s*Ratings\s*-->\s*$', add_row_call, text, count=1)
    if count:
        text = text2
    elif '<include name="Info_Meta">' in text:
        text = text.replace('<include name="Info_Meta">', '<include name="Info_Meta">\n' + _kpm_row_call_block().rstrip('\n'), 1)
    text = re.sub(r'\n{3,}(?=</includes>)', '\n\n', text)
    if '</includes>' in text:
        text = text.replace('</includes>', _kpm_row_def_block() + '</includes>', 1)
    return text, text != original


def remove_af3_unified_integration() -> Result:
    changed = False
    info_xml = af3_path('1080i', 'Includes_Info.xml')
    if os.path.exists(info_xml):
        backup = info_xml + '.kpm0186-unified.bak'
        if os.path.exists(backup):
            shutil.copy2(backup, info_xml)
            changed = True
    ss_xml = af3_path('1080i', 'screensaver-arctic-mirage.xml')
    if os.path.exists(ss_xml):
        backup = ss_xml + '.kpm0188-screensaver-rating.bak'
        if not os.path.exists(backup):
            backup = ss_xml + '.kpm0186-screensaver-rating.bak'
        if os.path.exists(backup):
            shutil.copy2(backup, ss_xml)
            changed = True
    layouts_xml = af3_path('1080i', 'Includes_Layouts.xml')
    if os.path.exists(layouts_xml):
        backup = layouts_xml + '.kpm0188-layouts.bak'
        if os.path.exists(backup):
            shutil.copy2(backup, layouts_xml)
            changed = True
    delete_state('af3_unified_integration')
    return Result('AF3 Unified Integration', 'Removed' if changed else 'Skipped', 'KPM-owned AF3 integration removed.' if changed else 'No KPM backup was available.')


# -----------------------------------------------------------------------------
# v0.1.88 - final visible parity fixes + context-wide live diagnostics
# -----------------------------------------------------------------------------

def _kpm_status_source_expr_0188(idx: int) -> str:
    src = 'Window(Home).Property(KPM.RatingRow.Slot{0}_Source)'.format(idx)
    return '[String.IsEqual({0},tvstatus) | String.IsEqual({0},tv_status) | String.IsEqual({0},series_status) | String.IsEqual({0},status)]'.format(src)


def _kpm_row_def_block() -> str:
    # Render IMDb at native AF3 width 52 and TV status with AF3's own icon.
    no_collection = '!String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) + !String.IsEqual($PARAM[container]$PARAM[listitem].DBType,collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(is_collection),true)'
    not_loading = '!Window.IsVisible(busydialog) + !Window.IsVisible(busydialognocancel)'
    parts = [KPM_AF3_ROW_DEF_START, '    <include name="KPM_Info_Meta_RatingRow">', '        <definition>']
    for idx in range(1, 11):
        shared_icon = 'special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(KPM.RatingRow.Slot{0}_IconFile)]'.format(idx)
        af3_status_icon = 'flags/$VAR[Color_Directory]/ratings/ends.png'
        label = '$INFO[Window(Home).Property(KPM.RatingRow.Slot{0}_Label)]'.format(idx)
        src = 'Window(Home).Property(KPM.RatingRow.Slot{0}_Source)'.format(idx)
        status_expr = _kpm_status_source_expr_0188(idx)
        visible = '[$PARAM[visible]] + String.IsEqual(Window(Home).Property(KPM.RatingRow.Visible),true) + {no_collection} + {not_loading} + !String.IsEmpty(Window(Home).Property(KPM.RatingRow.Slot{idx}_Label)) + !String.IsEmpty(Window(Home).Property(KPM.RatingRow.Slot{idx}_IconFile))'.format(no_collection=no_collection, not_loading=not_loading, idx=idx)
        parts.append('''            <include content="Info_Meta_Object">
                <param name="icon">{shared_icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + String.IsEqual({src},imdb)</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
                <param name="icon_w">52</param>
            </include>
            <include content="Info_Meta_Object">
                <param name="icon">{af3_status_icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + {status_expr}</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
            </include>
            <include content="Info_Meta_Object">
                <param name="icon">{shared_icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + !String.IsEqual({src},imdb) + !{status_expr}</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
            </include>'''.format(shared_icon=shared_icon, af3_status_icon=af3_status_icon, label=label, visible=visible, src=src, status_expr=status_expr))
    parts += ['        </definition>', '    </include>', KPM_AF3_ROW_DEF_END]
    return '\n'.join(parts) + '\n'


def _screensaver_identity_guard_0188() -> str:
    # Compare the active MWH ListItem directly with the LRS rating snapshot.
    # No title or LRS-to-LRS fallback is allowed because both can be stale.
    current_key = 'Container(1297).ListItem.Property(mediahub_item_key)'
    lrs_key = 'Window(Home).Property(LibraryRatings.Screensaver.ItemKey)'
    return '!String.IsEmpty({0}) + String.IsEqual({0},{1})'.format(
        current_key, lrs_key
    )


def _screensaver_slot_controls_0188(idx: int) -> str:
    base = 'Window(Home).Property(LibraryRatings.Screensaver.RatingSlot{0}_'.format(idx)
    label_prop = base + 'Label)'
    icon_prop = base + 'IconFile)'
    source_prop = base + 'Source)'
    visible = '!String.IsEmpty({0}) + !String.IsEmpty({1})'.format(label_prop, icon_prop)
    return '''                    <!-- LRS RatingSlot{idx} -->
                    <control type="image">
                        <width>52</width><height>32</height><aspectratio>keep</aspectratio><centertop>50%</centertop>
                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[{icon_prop}]</texture>
                        <visible>{visible} + String.IsEqual({source_prop},imdb)</visible>
                    </control>
                    <control type="image">
                        <width>32</width><height>32</height><aspectratio>keep</aspectratio><centertop>50%</centertop>
                        <texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[{icon_prop}]</texture>
                        <visible>{visible} + !String.IsEqual({source_prop},imdb)</visible>
                    </control>
                    <control type="label">
                        <aligny>center</aligny><label>$INFO[{label_prop}]</label><textcolor>main_fg_70</textcolor><font>font_main</font>
                        <width max="680">auto</width><textoffsetx>0</textoffsetx><texturefocus /><texturenofocus />
                        <visible>{visible}</visible>
                    </control>
                    <control type="group"><width>-4</width><visible>{visible}</visible></control>'''.format(idx=idx, icon_prop=icon_prop, source_prop=source_prop, label_prop=label_prop, visible=visible)


def _screensaver_rating_row_block() -> str:
    parts = [
        '                ' + KPM_SCREENSAVER_RATING_START,
        '                <control type="grouplist">',
        '                    <orientation>horizontal</orientation>',
        '                    <align>center</align>',
        '                    <height>54</height>',
        '                    <centertop>332</centertop>',
        '                    <itemgap>12</itemgap>',
        '                    <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.HasData),true) + {0}</visible>'.format(_screensaver_identity_guard_0188()),
    ]
    for idx in range(1, 8):
        parts.append(_screensaver_slot_controls_0188(idx))
    parts.extend([
        '                    <!-- LRS Oscar -->',
        '                    <control type="image"><width>32</width><height>32</height><aspectratio>keep</aspectratio><centertop>50%</centertop><texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/oscars.png</texture><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible></control>',
        '                    <control type="label"><aligny>center</aligny><label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins),x,]</label><textcolor>main_fg_70</textcolor><font>font_main</font><width max="680">auto</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible></control>',
        '                    <control type="group"><width>-4</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible></control>',
        '                    <!-- LRS Emmy -->',
        '                    <control type="image"><width>32</width><height>32</height><aspectratio>keep</aspectratio><centertop>50%</centertop><texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/emmys.png</texture><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible></control>',
        '                    <control type="label"><aligny>center</aligny><label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins),x,]</label><textcolor>main_fg_70</textcolor><font>font_main</font><width max="680">auto</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible></control>',
        '                    <control type="group"><width>-4</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible></control>',
        '                    <!-- LRS TV status: use AF3 default icon, not KPM shared icon -->',
        '                    <control type="image"><width>32</width><height>32</height><aspectratio>keep</aspectratio><centertop>50%</centertop><texture colordiffuse="main_fg_90">flags/$VAR[Color_Directory]/ratings/ends.png</texture><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible></control>',
        '                    <control type="label"><aligny>center</aligny><label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel)]</label><textcolor>main_fg_70</textcolor><font>font_main</font><width max="680">auto</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible></control>',
        '                    <control type="group"><width>-4</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible></control>',
        '                </control>',
        '                ' + KPM_SCREENSAVER_RATING_END,
    ])
    return '\n'.join(parts) + '\n'


# Include every visual file needed to diagnose invisible parity regressions.
AF3_FULL_CONTEXT_XMLS = tuple(dict.fromkeys(AF3_FULL_CONTEXT_XMLS + (
    'Custom_1104_Hub.xml', 'Includes_Layouts.xml', 'screensaver-arctic-mirage.xml',
    'FileBrowser.xml',
)))


def _home_prop_snapshot_0188(prefix: str, names) -> Dict[str, str]:
    return {name: _window_prop(10000, prefix + name) for name in names}


def _rating_row_runtime_0188() -> Dict[str, object]:
    base_names = ('Visible', 'ItemKey', 'ItemType', 'Window', 'Reason', 'UpdatedAt', 'ResolverTitle', 'ResolverDBID', 'Generation', 'Signature')
    report: Dict[str, object] = _home_prop_snapshot_0188('KPM.RatingRow.', base_names)
    slots = {}
    for idx in range(1, 11):
        slots[str(idx)] = _home_prop_snapshot_0188('KPM.RatingRow.Slot{0}_'.format(idx), ('Source', 'IconFile', 'Label', 'Value'))
    report['slots'] = slots
    return report


def _screensaver_runtime_0188() -> Dict[str, object]:
    names = (
        'HasData', 'DBType', 'Title', 'Year', 'ItemKey', 'SourceContext',
        'ClearLogoFinal', 'ClearLogoFinalMode', 'ClearLogoFinalSource', 'ClearLogoFinalTitle', 'ClearLogoFinalItemKey',
        'ClearLogoResolverReady', 'ClearLogoResolverStatus', 'ClearLogoResolverSourceHash',
        'Oscar_Wins', 'Oscar_BestPicture', 'Emmy_Wins', 'Series_StatusLabel',
    )
    report: Dict[str, object] = _home_prop_snapshot_0188('LibraryRatings.Screensaver.', names)
    slots = {}
    for idx in range(1, 8):
        slots[str(idx)] = _home_prop_snapshot_0188('LibraryRatings.Screensaver.RatingSlot{0}_'.format(idx), ('Source', 'Icon', 'IconFile', 'Label', 'Value'))
    report['slots'] = slots
    report['container_1297'] = _game_bridge_for_prefix('Container(1297).ListItem')
    return report


def _candidate_item_snapshot_0188() -> Dict[str, object]:
    prefixes = ['ListItem', 'Container.ListItem']
    prefixes += ['Container({0}).ListItem'.format(cid) for cid in (50, 51, 52, 300, 301, 302, 303, 304, 305, 306, 307, 308, 309, 310, 311, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 1297, 9000)]
    out = {}
    for prefix in prefixes:
        title = info_label(prefix + '.Title') or info_label(prefix + '.Label')
        dbtype = info_label(prefix + '.DBType') or info_label(prefix + '.Property(DBTYPE)') or info_label(prefix + '.Property(MediaType)')
        dbid = info_label(prefix + '.DBID') or info_label(prefix + '.Property(DBID)')
        if not (title or dbtype or dbid):
            continue
        out[prefix] = {
            'title': title, 'label': info_label(prefix + '.Label'), 'dbtype': dbtype, 'dbid': dbid,
            'year': info_label(prefix + '.Year'), 'path': info_label(prefix + '.FileNameAndPath') or info_label(prefix + '.FolderPath'),
            'platform': info_label(prefix + '.Property(platform)'), 'steam_appid': info_label(prefix + '.Property(steam_appid)'),
            'lrs_item_type': info_label(prefix + '.Property(lrs_item_type)'),
        }
    return out


def _visual_conditions_0188() -> Dict[str, object]:
    expressions = (
        'System.ScreenSaverActive', 'Container.IsUpdating', 'Player.HasVideo', 'Player.Playing', 'Player.Paused', 'Player.Seeking',
        'Window.IsVisible(busydialog)', 'Window.IsVisible(busydialognocancel)', 'Window.IsVisible(extendedprogressdialog)',
        'Window.IsVisible(progressdialog)', 'Window.IsActive(home)', 'Window.IsActive(programs)', 'Window.IsActive(videos)',
        'Window.IsActive(Custom_1101_Hub.xml)', 'Window.IsActive(Custom_1102_Hub.xml)', 'Window.IsActive(Custom_1103_Hub.xml)',
        'Window.IsActive(Custom_1104_Hub.xml)', 'Window.IsActive(screensaver-arctic-mirage.xml)',
    )
    return {expr: bool(cond_visible(expr)) for expr in expressions}


def _live_consistency_issues_0188(sample: Dict[str, object]) -> list:
    issues = []
    row = sample.get('kpm_rating_row', {}) or {}
    row_slots = row.get('slots', {}) or {}
    nonempty_row = [slot for slot in row_slots.values() if (slot or {}).get('Label')]
    if str(row.get('Visible') or '').lower() == 'true' and not nonempty_row:
        issues.append('kpm_row_visible_without_slots')
    for slot in nonempty_row:
        src = str(slot.get('Source') or '').lower()
        label = str(slot.get('Label') or '')
        if src in ('tvstatus', 'tv_status', 'series_status', 'status') and label.lower().startswith('ends at'):
            issues.append('tv_status_misclassified_as_endsat')
    ss = sample.get('screensaver', {}) or {}
    ss_slots = ss.get('slots', {}) or {}
    nonempty_ss = [slot for slot in ss_slots.values() if (slot or {}).get('Label')]
    if str(ss.get('HasData') or '').lower() == 'true' and not nonempty_ss:
        issues.append('screensaver_hasdata_without_slots')
    c1297 = ss.get('container_1297', {}) or {}
    current_title = str(c1297.get('Title') or c1297.get('Label') or '')
    cprops = c1297.get('properties', {}) or {}
    current_key = str(cprops.get('mediahub_item_key') or '')
    item_key = str(ss.get('ItemKey') or '')
    logo_key = str(ss.get('ClearLogoFinalItemKey') or '')
    if sample.get('conditions', {}).get('System.ScreenSaverActive') and current_title:
        rating_identity_ok = bool(current_key and item_key and current_key == item_key)
        logo_identity_ok = bool(current_key and logo_key and current_key == logo_key)
        if str(ss.get('HasData') or '').lower() == 'true' and not rating_identity_ok:
            issues.append('screensaver_identity_guard_mismatch')
        if str(ss.get('ClearLogoFinal') or '') and not logo_identity_ok:
            issues.append('screensaver_clearlogo_key_mismatch')
        if str(ss.get('HasData') or '').lower() != 'true':
            issues.append('screensaver_active_without_rating_data')
    return sorted(set(issues))


def _full_visual_sample_0188(sample_no: int) -> Dict[str, object]:
    sample = {
        'schema': 'kpm-live-visual-0188',
        'sample': sample_no,
        'epoch': time.time(),
        'wall_time': time.strftime('%Y-%m-%d %H:%M:%S'),
        'window_ids': _current_window_ids(),
        'window_xml': info_label('Window.Property(xmlfile)'),
        'focused_control_id': info_label('System.CurrentControlId'),
        'focused_control': info_label('System.CurrentControl'),
        'conditions': _visual_conditions_0188(),
        'kpm_rating_row': _rating_row_runtime_0188(),
        'lrs_homehub': _lrs_homehub_display_props(),
        'screensaver': _screensaver_runtime_0188(),
        'candidate_items': _candidate_item_snapshot_0188(),
        'studio': {
            'visible': _window_prop(10000, 'KPM.StudioLogo.Visible'),
            'path': _window_prop(10000, 'KPM.StudioLogo.Path'),
            'label': _window_prop(10000, 'KPM.StudioLogo.Label'),
            'resolved': _window_prop(10000, 'KPM.StudioLogo.Resolved'),
            'item_key': _window_prop(10000, 'KPM.StudioLogo.ItemKey'),
        },
    }
    sample['issues'] = _live_consistency_issues_0188(sample)
    return sample


def _full_system_runtime_report() -> Dict[str, object]:
    return {
        'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'versions': _full_system_versions_report(),
        'player_runtime': _player_runtime_state(),
        'current_item_snapshot': _current_item_snapshot(),
        'kpm_rating_row': _rating_row_runtime_0188(),
        'lrs_homehub': _lrs_homehub_display_props(),
        'screensaver': _screensaver_runtime_0188(),
        'candidate_items': _candidate_item_snapshot_0188(),
        'conditions': _visual_conditions_0188(),
        'cropv2': _cropv2_diagnostics_report(),
        'shared_icons': _shared_icons_report(),
    }


def run_diag_live(duration_seconds: int = 120) -> None:
    stamp = time.strftime('%Y%m%d-%H%M%S')
    live_dir = addon_data_dir('runtime', 'logs', DIAG_LIVE_DIRNAME)
    out_path = os.path.join(live_dir, '{0}-{1}.jsonl'.format(DIAG_LIVE_PREFIX, stamp))
    summary_path = os.path.join(live_dir, '{0}-{1}-summary.json'.format(DIAG_LIVE_PREFIX, stamp))
    end_time = time.time() + max(10, int(duration_seconds))
    notify('Full visual live diagnostic started for {0}s'.format(duration_seconds))
    log('[KPM_DIAG] Full visual live diagnostic started for {0}s -> {1}'.format(duration_seconds, out_path))
    issue_counts = {}
    transitions = []
    previous_signature = ''
    samples = 0
    started = time.time()
    with open(out_path, 'w', encoding='utf-8') as handle:
        while time.time() < end_time:
            if xbmc and xbmc.Monitor().abortRequested():
                break
            samples += 1
            data = _full_visual_sample_0188(samples)
            signature_payload = {
                'window': data.get('window_ids'), 'xml': data.get('window_xml'),
                'focus': data.get('focused_control_id'),
                'row': data.get('kpm_rating_row'), 'screensaver': data.get('screensaver'),
                'issues': data.get('issues'),
            }
            signature = hashlib.sha1(json.dumps(signature_payload, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()
            changed = signature != previous_signature
            data['changed'] = changed
            if changed:
                transitions.append({'sample': samples, 'epoch': data['epoch'], 'window_xml': data.get('window_xml'), 'focus': data.get('focused_control_id'), 'issues': data.get('issues', [])})
                previous_signature = signature
            for issue in data.get('issues', []):
                issue_counts[issue] = issue_counts.get(issue, 0) + 1
            handle.write(json.dumps(data, ensure_ascii=False) + '\n')
            handle.flush()
            if xbmc:
                xbmc.sleep(250)
            else:
                time.sleep(0.25)
    summary = {
        'schema': 'kpm-live-visual-summary-0188',
        'started_at_epoch': started,
        'finished_at_epoch': time.time(),
        'duration_seconds': round(time.time() - started, 3),
        'samples': samples,
        'sample_interval_ms': 250,
        'issue_counts': issue_counts,
        'transitions': transitions[-500:],
        'instructions': 'Export Full Diagnostics ZIP; the live JSONL and this summary are included automatically.',
    }
    with open(summary_path, 'w', encoding='utf-8') as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
    log('[KPM_DIAG] Full visual live diagnostic finished: {0}; samples={1}; issues={2}'.format(out_path, samples, issue_counts))
    notify('Live diagnostic finished. Export Full Diagnostics ZIP now.')


def start_live_diagnostics_menu() -> None:
    message = (
        'Start a 120 second full visual diagnostic?\n\n'
        'During recording, move through Home, Movies Hub, TV Hub, Games Hub/library, one collection/set, and Arctic Mirage screensaver. '
        'It samples every 250 ms and records focus/container identities, KPM row generations, all LRS DisplaySlots, Screensaver slots/title/item keys, studio logo state, loading dialogs and consistency warnings.\n\n'
        'After it finishes, run Export Full Diagnostics ZIP.'
    )
    if not yesno(ADDON_NAME, message):
        return
    if xbmc:
        xbmc.executebuiltin('RunScript({0},diag_live,120)'.format(ADDON_ID))
        ok(ADDON_NAME, 'Full visual diagnostic started for 120 seconds.\n\nBrowse every context, then export the Full Diagnostics ZIP.')
    else:
        run_diag_live(10)


# -----------------------------------------------------------------------------
# v0.1.89 - panel-wide transition parity + native AF3 status semantics
# -----------------------------------------------------------------------------
KPM_AF3_ROW_CALL_START = '<!-- KPM-AF3-RATING-ROW-CALL-START-0189 -->'
KPM_AF3_ROW_CALL_END = '<!-- KPM-AF3-RATING-ROW-CALL-END-0189 -->'
KPM_AF3_ROW_DEF_START = '<!-- KPM-AF3-RATING-ROW-DEF-START-0189 -->'
KPM_AF3_ROW_DEF_END = '<!-- KPM-AF3-RATING-ROW-DEF-END-0189 -->'
KPM_STEAM_INFO_START = '<!-- KPM-AF3-STEAM-INFO-LINE-START-0189 -->'
KPM_STEAM_INFO_END = '<!-- KPM-AF3-STEAM-INFO-LINE-END-0189 -->'
KPM_STEAM_PLOT_START = '<!-- KPM-AF3-STEAM-PLOT-START-0189 -->'
KPM_STEAM_PLOT_END = '<!-- KPM-AF3-STEAM-PLOT-END-0189 -->'
KPM_SCREENSAVER_RATING_START = '<!-- KPM-AF3-SCREENSAVER-RATING-ROW-START-0189 -->'
KPM_SCREENSAVER_RATING_END = '<!-- KPM-AF3-SCREENSAVER-RATING-ROW-END-0189 -->'
KPM_PANEL_GATE_START = '<!-- KPM-AF3-PANEL-TRANSITION-GATE-START-0190 -->'
KPM_PANEL_GATE_END = '<!-- KPM-AF3-PANEL-TRANSITION-GATE-END-0190 -->'
KPM_LAYOUT_MARKER_BEGIN = '<!-- KPM Compact Steam Landscape BEGIN 0189 -->'
KPM_LAYOUT_MARKER_END = '<!-- KPM Compact Steam Landscape END 0189 -->'
KPM_LAYOUT_ORIGINAL_BEGIN = '<!-- KPM Original Landscape BEGIN 0189 -->'
KPM_LAYOUT_ORIGINAL_END = '<!-- KPM Original Landscape END 0189 -->'


def _kpm_row_call_block() -> str:
    # service is required for AF3's native Image_<service>_Status variable.
    return '''                    {start}
                    <include content="KPM_Info_Meta_RatingRow">
                        <param name="visible">$PARAM[visible]</param>
                        <param name="container">$PARAM[container]</param>
                        <param name="listitem">$PARAM[listitem]</param>
                        <param name="service">$PARAM[service]</param>
                        <param name="colordiffuse">$PARAM[colordiffuse]</param>
                    </include>
                    {end}
'''.format(start=KPM_AF3_ROW_CALL_START, end=KPM_AF3_ROW_CALL_END)


def _kpm_status_source_expr_0189(idx: int) -> str:
    src = 'Window(Home).Property(KPM.RatingRow.Slot{0}_Source)'.format(idx)
    return '[String.IsEqual({0},tvstatus) | String.IsEqual({0},tv_status) | String.IsEqual({0},series_status) | String.IsEqual({0},status)]'.format(src)


def _kpm_row_def_block() -> str:
    # AF3 native behavior from the installed skin:
    # - IMDb has icon_w=52.
    # - series status uses $VAR[Image_<service>_Status], not ratings/ends.png.
    no_collection = '!String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) + !String.IsEqual($PARAM[container]$PARAM[listitem].DBType,collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(is_collection),true)'
    not_loading = '!Window.IsVisible(busydialog) + !Window.IsVisible(busydialognocancel)'
    panel_ready = '[!String.IsEqual(Window(Home).Property(KPM.Visual.GateActive),true) | String.IsEqual(Window(Home).Property(KPM.Visual.Ready),true)]'
    parts = [KPM_AF3_ROW_DEF_START, '    <include name="KPM_Info_Meta_RatingRow">', '        <param name="service">ListItem</param>', '        <definition>']
    for idx in range(1, 11):
        shared_icon = 'special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property(KPM.RatingRow.Slot{0}_IconFile)]'.format(idx)
        native_status_icon = '$VAR[Image_$PARAM[service]_Status]'
        label = '$INFO[Window(Home).Property(KPM.RatingRow.Slot{0}_Label)]'.format(idx)
        src = 'Window(Home).Property(KPM.RatingRow.Slot{0}_Source)'.format(idx)
        status_expr = _kpm_status_source_expr_0189(idx)
        visible = '[$PARAM[visible]] + String.IsEqual(Window(Home).Property(KPM.RatingRow.Visible),true) + {panel_ready} + {no_collection} + {not_loading} + !String.IsEmpty(Window(Home).Property(KPM.RatingRow.Slot{idx}_Label))'.format(panel_ready=panel_ready, no_collection=no_collection, not_loading=not_loading, idx=idx)
        parts.append('''            <include content="Info_Meta_Object">
                <param name="icon">{shared_icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + String.IsEqual({src},imdb) + !String.IsEmpty(Window(Home).Property(KPM.RatingRow.Slot{idx}_IconFile))</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
                <param name="icon_w">52</param>
            </include>
            <include content="Info_Meta_Object">
                <param name="icon">{native_status_icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + {status_expr}</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
            </include>
            <include content="Info_Meta_Object">
                <param name="icon">{shared_icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + !String.IsEqual({src},imdb) + !{status_expr} + !String.IsEmpty(Window(Home).Property(KPM.RatingRow.Slot{idx}_IconFile))</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
            </include>'''.format(shared_icon=shared_icon, native_status_icon=native_status_icon, label=label, visible=visible, src=src, status_expr=status_expr, idx=idx))
    parts += ['        </definition>', '    </include>', KPM_AF3_ROW_DEF_END]
    return '\n'.join(parts) + '\n'


def _screensaver_rating_row_block() -> str:
    # Geometry is copied from the previously working LRS screensaver row.
    parts = [
        '                ' + KPM_SCREENSAVER_RATING_START,
        '                <control type="grouplist">',
        '                    <orientation>horizontal</orientation>',
        '                    <align>center</align>',
        '                    <height>54</height>',
        '                    <centertop>332</centertop>',
        '                    <itemgap>12</itemgap>',
        '                    <visible>String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.HasData),true) + {0}</visible>'.format(_screensaver_identity_guard_0188()),
    ]
    for idx in range(1, 8):
        parts.append(_screensaver_slot_controls_0188(idx))
    parts.extend([
        '                    <!-- LRS Oscar -->',
        '                    <control type="image"><width>32</width><height>32</height><aspectratio>keep</aspectratio><centertop>50%</centertop><texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/oscars.png</texture><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible></control>',
        '                    <control type="label"><aligny>center</aligny><label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins),x,]</label><textcolor>main_fg_70</textcolor><font>font_main</font><width max="680">auto</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible></control>',
        '                    <control type="group"><width>-4</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + String.IsEqual(Window(Home).Property(LibraryRatings.Screensaver.DBType),movie) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Oscar_Wins))</visible></control>',
        '                    <!-- LRS Emmy -->',
        '                    <control type="image"><width>32</width><height>32</height><aspectratio>keep</aspectratio><centertop>50%</centertop><texture colordiffuse="main_fg_90">special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/emmys.png</texture><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible></control>',
        '                    <control type="label"><aligny>center</aligny><label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins),x,]</label><textcolor>main_fg_70</textcolor><font>font_main</font><width max="680">auto</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible></control>',
        '                    <control type="group"><width>-4</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.Awards),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Emmy_Wins))</visible></control>',
        '                    <!-- Native AF3 series status icon -->',
        '                    <control type="image"><width>32</width><height>32</height><aspectratio>keep</aspectratio><centertop>50%</centertop><texture colordiffuse="main_fg_90">$VAR[Image_ListItem_Status]</texture><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible></control>',
        '                    <control type="label"><aligny>center</aligny><label>$INFO[Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel)]</label><textcolor>main_fg_70</textcolor><font>font_main</font><width max="680">auto</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible></control>',
        '                    <control type="group"><width>-4</width><visible>String.IsEqual(Window(Home).Property(LibraryRatings.Display.TVStatus),true) + !String.IsEmpty(Window(Home).Property(LibraryRatings.Screensaver.Series_StatusLabel))</visible></control>',
        '                </control>',
        '                ' + KPM_SCREENSAVER_RATING_END,
    ])
    return '\n'.join(parts) + '\n'


def _remove_panel_gate_0189(text: str) -> str:
    # Canonicalise the current KPM gate before reinserting the current block.
    pattern = r'<!--\s*KPM-AF3-PANEL-TRANSITION-GATE-START-[^>]*-->\s*<visible>.*?</visible>\s*<!--\s*KPM-AF3-PANEL-TRANSITION-GATE-END-[^>]*-->'
    return re.sub(pattern, '<visible>$PARAM[visible]</visible>', text, flags=re.I | re.S)


def _patch_info_panel_gate_0189(text: str):
    original = text
    start, end, block = _find_xml_include_block_0187(text, 'Info_Panel')
    if start < 0:
        return original, False

    gate = ('{start_marker}\n'
            '                <visible>[$PARAM[visible]] + !String.IsEqual(Window(Home).Property(KPM.Visual.Suppress),true)</visible>\n'
            '                {end_marker}').format(start_marker=KPM_PANEL_GATE_START, end_marker=KPM_PANEL_GATE_END)
    old_gate_pattern = r'<!--\s*KPM-AF3-PANEL-TRANSITION-GATE-START-[^>]*-->\s*<visible>.*?</visible>\s*<!--\s*KPM-AF3-PANEL-TRANSITION-GATE-END-[^>]*-->'
    if re.search(old_gate_pattern, block, flags=re.I | re.S):
        new_block = re.sub(old_gate_pattern, gate, block, count=1, flags=re.I | re.S)
    else:
        anchor = '            <control type="grouplist">\n                <visible>$PARAM[visible]</visible>'
        replacement = '            <control type="grouplist">\n                {0}'.format(gate)
        if anchor not in block:
            return original, False
        new_block = block.replace(anchor, replacement, 1)
    out = text[:start] + new_block + text[end:]
    ET.fromstring(out)
    return out, out != original


def _patch_af3_info_xml_kpm_owned(text: str):
    t, c1 = _patch_kpm_rating_row_info_xml(text)
    t, c2 = _patch_kpm_steam_info_plot(t)
    t, c3 = _patch_info_panel_gate_0189(t)
    return t, bool(c1 or c2 or c3)


def status_af3_unified_integration() -> str:
    info = af3_path('1080i', 'Includes_Info.xml')
    layouts = af3_path('1080i', 'Includes_Layouts.xml')
    row_ok = gate_ok = layout_ok = False
    if os.path.exists(info):
        try:
            text = read_text(info)
            row_ok = KPM_AF3_ROW_CALL_START in text and KPM_AF3_ROW_DEF_START in text and '$VAR[Image_$PARAM[service]_Status]' in text
            gate_ok = KPM_PANEL_GATE_START in text and KPM_PANEL_GATE_END in text
        except Exception:
            pass
    if os.path.exists(layouts):
        try:
            txt = read_text(layouts)
            layout_ok = KPM_LAYOUT_MARKER_BEGIN in txt or 'KPM Compact Steam Landscape BEGIN 0188' in txt
        except Exception:
            pass
    if row_ok and gate_ok and layout_ok:
        return 'Patched (keep-last transition, native status, 192px game landscape)'
    if row_ok and gate_ok:
        return 'Patched (keep-last transition; landscape layout unavailable)'
    if row_ok:
        return 'Partial (rating row active; keep-last marker missing)'
    return 'Not patched'


def _visual_transition_runtime_0189() -> Dict[str, str]:
    names = ('GateActive', 'Ready', 'HasCommitted', 'Transitioning', 'Suppress', 'HoldReason', 'ItemKey', 'PendingItemKey', 'ItemType', 'CanonicalPrefix', 'CanonicalTitle', 'CanonicalDBID', 'CanonicalAppID', 'StableCount', 'StableMs', 'Generation', 'ChangedAt', 'CandidatesJSON')
    return _home_prop_snapshot_0188('KPM.Visual.', names)


def _native_panel_snapshot_0189() -> Dict[str, object]:
    prefixes = ['ListItem', 'Container.ListItem'] + ['Container({0}).ListItem'.format(x) for x in (50, 51, 52, 301, 500, 501, 502, 503, 504, 505, 506, 507, 508, 509, 510, 9000)]
    out = {}
    for prefix in prefixes:
        title = info_label(prefix + '.Title') or info_label(prefix + '.Label')
        if not title:
            continue
        out[prefix] = {
            'title': title,
            'dbtype': info_label(prefix + '.DBType') or info_label(prefix + '.Property(DBTYPE)') or info_label(prefix + '.Property(MediaType)'),
            'dbid': info_label(prefix + '.DBID') or info_label(prefix + '.Property(DBID)'),
            'appid': info_label(prefix + '.Property(steam_appid)') or info_label(prefix + '.Property(appid)'),
            'tagline': info_label(prefix + '.Tagline') or info_label(prefix + '.Property(tagline)'),
            'plot': info_label(prefix + '.Plot') or info_label(prefix + '.Property(plot)'),
            'clearlogo': info_label(prefix + '.Art(clearlogo)') or info_label(prefix + '.Property(clearlogo)'),
            'fanart': info_label(prefix + '.Art(fanart)') or info_label(prefix + '.Property(fanart)'),
            'steam': info_label(prefix + '.Property(steam_rating_display)'),
            'metacritic': info_label(prefix + '.Property(metacritic_score)'),
            'achievement': info_label(prefix + '.Property(achievement_display)'),
            'playtime_forever': info_label(prefix + '.Property(playtime_forever)'),
            'playtime_display': info_label(prefix + '.Property(playtime_display)'),
        }
    out['service'] = {
        'title': info_label('Window(Home).Property(TMDbHelper.ListItem.Title)') or info_label('Window.Property(TMDbHelper.ListItem.Title)'),
        'dbid': info_label('Window(Home).Property(TMDbHelper.ListItem.DBID)') or info_label('Window.Property(TMDbHelper.ListItem.DBID)'),
        'dbtype': info_label('Window(Home).Property(TMDbHelper.ListItem.DBTYPE)') or info_label('Window.Property(TMDbHelper.ListItem.DBTYPE)'),
        'clearlogo': info_label('Window(Home).Property(TMDbHelper.ListItem.ClearLogo)') or info_label('Window.Property(TMDbHelper.ListItem.ClearLogo)'),
    }
    return out


def _live_consistency_issues_0189(sample: Dict[str, object]) -> list:
    issues = list(_live_consistency_issues_0188(sample))
    visual = sample.get('visual_transition', {}) or {}
    row = sample.get('kpm_rating_row', {}) or {}
    ready = str(visual.get('Ready') or '').lower() == 'true'
    gate = str(visual.get('GateActive') or '').lower() == 'true'
    row_visible = str(row.get('Visible') or '').lower() == 'true'
    if gate and not ready and row_visible:
        issues.append('rating_row_visible_while_panel_gate_closed')
    if ready and row_visible and visual.get('ItemKey') and row.get('ItemKey') and visual.get('ItemKey') != row.get('ItemKey'):
        issues.append('panel_row_itemkey_mismatch')
    nonempty = [slot for slot in (row.get('slots', {}) or {}).values() if (slot or {}).get('Label')]
    if str(row.get('ItemType') or '').lower() == 'game':
        order = [str(slot.get('Source') or '').lower() for slot in nonempty]
        expected = [x for x in ('steam', 'metacritic', 'achievement', 'steam_playtime') if x in order]
        if [x for x in order if x in ('steam', 'metacritic', 'achievement', 'steam_playtime')] != expected:
            issues.append('game_slot_order_invalid')
        if 'steam_playtime' in order and order[-1] != 'steam_playtime':
            issues.append('steam_playtime_not_last')
        if any(x not in ('steam', 'metacritic', 'achievement', 'steam_playtime') for x in order):
            issues.append('movie_slot_leaked_into_game_row')
    return sorted(set(issues))


def _full_visual_sample_0189(sample_no: int) -> Dict[str, object]:
    sample = _full_visual_sample_0188(sample_no)
    sample['schema'] = 'kpm-live-visual-0189'
    sample['visual_transition'] = _visual_transition_runtime_0189()
    sample['native_panel'] = _native_panel_snapshot_0189()
    sample['issues'] = _live_consistency_issues_0189(sample)
    return sample


def _full_system_runtime_report() -> Dict[str, object]:
    report = {
        'generated_at': time.strftime('%Y-%m-%d %H:%M:%S'),
        'versions': _full_system_versions_report(),
        'player_runtime': _player_runtime_state(),
        'current_item_snapshot': _current_item_snapshot(),
        'visual_transition': _visual_transition_runtime_0189(),
        'native_panel': _native_panel_snapshot_0189(),
        'kpm_rating_row': _rating_row_runtime_0188(),
        'lrs_homehub': _lrs_homehub_display_props(),
        'screensaver': _screensaver_runtime_0188(),
        'candidate_items': _candidate_item_snapshot_0188(),
        'conditions': _visual_conditions_0188(),
        'cropv2': _cropv2_diagnostics_report(),
        'shared_icons': _shared_icons_report(),
    }
    return report


def run_diag_live(duration_seconds: int = 120) -> None:
    # 60 ms captures the short game->movie torn frames that 250 ms missed.
    stamp = time.strftime('%Y%m%d-%H%M%S')
    live_dir = addon_data_dir('runtime', 'logs', DIAG_LIVE_DIRNAME)
    out_path = os.path.join(live_dir, '{0}-{1}.jsonl'.format(DIAG_LIVE_PREFIX, stamp))
    summary_path = os.path.join(live_dir, '{0}-{1}-summary.json'.format(DIAG_LIVE_PREFIX, stamp))
    end_time = time.time() + max(10, int(duration_seconds))
    notify('Full visual live diagnostic started for {0}s'.format(duration_seconds))
    log('[KPM_DIAG] 60ms resilient transition diagnostic started -> {0}'.format(out_path))
    issue_counts, transitions = {}, []
    previous_signature = ''
    samples = written = 0
    last_heartbeat = 0.0
    started = time.time()
    os.makedirs(live_dir, exist_ok=True)
    with open(out_path, 'w', encoding='utf-8') as handle:
        while time.time() < end_time:
            if xbmc and xbmc.Monitor().abortRequested():
                break
            samples += 1
            try:
                data = _full_visual_sample_0189(samples)
            except Exception as exc:  # diagnostic must never die on one bad sample
                data = {
                    'schema': 'kpm-live-visual-sample-error-0190',
                    'sample': samples, 'epoch': time.time(),
                    'error': str(exc), 'traceback': traceback.format_exc(),
                    'issues': ['diagnostic_sample_exception'],
                }
            signature_payload = {
                'window': data.get('window_ids'), 'xml': data.get('window_xml'), 'focus': data.get('focused_control_id'),
                'visual': data.get('visual_transition'), 'row': data.get('kpm_rating_row'),
                'native': data.get('native_panel'), 'screensaver': data.get('screensaver'), 'issues': data.get('issues'),
            }
            signature = hashlib.sha1(json.dumps(signature_payload, sort_keys=True, ensure_ascii=False).encode('utf-8')).hexdigest()
            now = time.time()
            changed = signature != previous_signature
            heartbeat = now - last_heartbeat >= 1.0
            data['changed'] = changed
            data['heartbeat'] = heartbeat
            if changed:
                transitions.append({'sample': samples, 'epoch': data['epoch'], 'window_xml': data.get('window_xml'), 'focus': data.get('focused_control_id'), 'visual': data.get('visual_transition'), 'issues': data.get('issues', [])})
                previous_signature = signature
            for issue in data.get('issues', []):
                issue_counts[issue] = issue_counts.get(issue, 0) + 1
            if changed or heartbeat:
                handle.write(json.dumps(data, ensure_ascii=False) + '\n')
                handle.flush()
                written += 1
                if heartbeat:
                    last_heartbeat = now
            if xbmc:
                xbmc.sleep(60)
            else:
                time.sleep(0.06)
    summary = {
        'schema': 'kpm-live-visual-summary-0190',
        'started_at_epoch': started, 'finished_at_epoch': time.time(),
        'duration_seconds': round(time.time() - started, 3),
        'samples': samples, 'written_changed_or_heartbeat_samples': written,
        'sample_interval_ms': 60, 'issue_counts': issue_counts,
        'transitions': transitions[-1000:],
        'instructions': 'Export Full Diagnostics ZIP; the 60 ms transition log and summary are included automatically.',
    }
    with open(summary_path, 'w', encoding='utf-8') as handle:
        json.dump(summary, handle, indent=2, ensure_ascii=False)
    notify('Live diagnostic finished. Export Full Diagnostics ZIP now.')


def start_live_diagnostics_menu() -> None:
    message = (
        'Start a 120 second full visual transition diagnostic?\n\n'
        'Move repeatedly between a Steam game and a movie/TV item, then test Home, all Hubs, game library and Arctic Mirage screensaver. '
        'Sampling is 60 ms and records the canonical source, panel gate, clearlogo/title/plot identities, KPM row generation, game slot order/playtime, LRS slots, screensaver and studio state.\n\n'
        'After it finishes, run Export Full Diagnostics ZIP.'
    )
    if not yesno(ADDON_NAME, message):
        return
    if xbmc:
        xbmc.executebuiltin('RunScript({0},diag_live,120)'.format(ADDON_ID))
        ok(ADDON_NAME, 'Transition diagnostic started for 120 seconds.\n\nReproduce the game↔movie transition, then export Full Diagnostics ZIP.')
    else:
        run_diag_live(10)

# Current-only compact landscape canonicaliser. It understands only the
# marker written by the current layout patch; older patch markers are rejected
# by _assert_current_layout_source_0233 before this helper can run.
def _restore_compact_landscape_0187(text: str):
    start, end, block = _find_xml_include_block_0187(text, 'Layout_Landscape')
    if start < 0:
        return text, False
    original_begin, original_end = KPM_LAYOUT_ORIGINAL_BEGIN, KPM_LAYOUT_ORIGINAL_END
    if original_begin not in block or original_end not in block:
        return text, False
    pos1 = block.find(original_begin)
    pos2 = block.find(original_end, pos1)
    chunk = block[pos1 + len(original_begin):pos2]
    lines = chunk.splitlines()
    while lines and not lines[0].strip():
        lines.pop(0)
    while lines and not lines[-1].strip():
        lines.pop()
    if not lines or '<control type="group"' not in lines[0]:
        return text, False
    lines = lines[1:]
    if lines and 'String.IsEmpty($PARAM[listitem].Property(platform))' in lines[0]:
        lines = lines[1:]
    while lines and not lines[-1].strip():
        lines.pop()
    if lines and lines[-1].strip() == '</control>':
        lines = lines[:-1]
    original_inner = '\n'.join(lines).rstrip('\n')
    def_start = block.find('        <definition>')
    def_end = block.rfind('        </definition>')
    if def_start < 0 or def_end < 0:
        return text, False
    restored = '''        <definition>
            <control type="group">
{original_inner}
            </control>
        </definition>'''.format(original_inner=original_inner)
    new_block = block[:def_start] + restored + block[def_end + len('        </definition>'):]
    out = text[:start] + new_block + text[end:]
    ET.fromstring(out)
    return out, True

# v0.1.94 - render one of two complete lower-row slot snapshots.
def _kpm_row_def_block() -> str:
    no_collection = '!String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) + !String.IsEqual($PARAM[container]$PARAM[listitem].DBType,collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(is_collection),true)'
    not_loading = '!Window.IsVisible(busydialog) + !Window.IsVisible(busydialognocancel)'
    panel_ready = '[!String.IsEqual(Window(Home).Property(KPM.Visual.GateActive),true) | String.IsEqual(Window(Home).Property(KPM.Visual.Ready),true)]'
    parts = [KPM_AF3_ROW_DEF_START, '    <include name="KPM_Info_Meta_RatingRow">', '        <param name="service">ListItem</param>', '        <definition>']
    for set_name in ('A', 'B'):
        active_expr = 'String.IsEqual(Window(Home).Property(KPM.RatingRow.ActiveSet),{0})'.format(set_name)
        for idx in range(1, 11):
            base = 'KPM.RatingRow.{0}.Slot{1}_'.format(set_name, idx)
            shared_icon = 'special://home/addons/script.kodi.patch.manager/resources/media/shared-icons/$INFO[Window(Home).Property({0}IconFile)]'.format(base)
            native_status_icon = '$VAR[Image_$PARAM[service]_Status]'
            label = '$INFO[Window(Home).Property({0}Label)]'.format(base)
            src = 'Window(Home).Property({0}Source)'.format(base)
            status_expr = '[String.IsEqual({0},tvstatus) | String.IsEqual({0},tv_status) | String.IsEqual({0},series_status) | String.IsEqual({0},status)]'.format(src)
            visible = '[$PARAM[visible]] + String.IsEqual(Window(Home).Property(KPM.RatingRow.Visible),true) + {active} + {panel_ready} + {no_collection} + {not_loading} + !String.IsEmpty(Window(Home).Property({base}Label))'.format(active=active_expr, panel_ready=panel_ready, no_collection=no_collection, not_loading=not_loading, base=base)
            parts.append('''            <include content="Info_Meta_Object">
                <param name="icon">{shared_icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + String.IsEqual({src},imdb) + !String.IsEmpty(Window(Home).Property({base}IconFile))</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
                <param name="icon_w">52</param>
            </include>
            <include content="Info_Meta_Object">
                <param name="icon">{native_status_icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + {status_expr}</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
            </include>
            <include content="Info_Meta_Object">
                <param name="icon">{shared_icon}</param>
                <param name="label">{label}</param>
                <param name="visible">{visible} + !String.IsEqual({src},imdb) + !{status_expr} + !String.IsEmpty(Window(Home).Property({base}IconFile))</param>
                <param name="colordiffuse">$PARAM[colordiffuse]</param>
            </include>'''.format(shared_icon=shared_icon, native_status_icon=native_status_icon, label=label, visible=visible, src=src, status_expr=status_expr, base=base))
    parts += ['        </definition>', '    </include>', KPM_AF3_ROW_DEF_END]
    return '\n'.join(parts) + '\n'

# v0.1.94 idempotent injector for the atomic lower-row snapshot renderer.
def _patch_kpm_rating_row_info_xml(text: str):
    original = text
    text = _normalize_current_rating_xml(text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    def add_row_call(match):
        return match.group(0).rstrip() + '\n' + _kpm_row_call_block().rstrip('\n')
    text2, count = re.subn(r'(?m)^[ \t]*<!--\s*Ratings\s*-->\s*$', add_row_call, text, count=1)
    if count:
        text = text2
    elif '<include name="Info_Meta">' in text:
        text = text.replace('<include name="Info_Meta">', '<include name="Info_Meta">\n' + _kpm_row_call_block().rstrip('\n'), 1)
    text = re.sub(r'\n{3,}', '\n\n', text)
    if '</includes>' in text:
        text = text.replace('</includes>', _kpm_row_def_block().rstrip('\n') + '\n</includes>', 1)
    text = re.sub(r'\n{3,}', '\n\n', text)
    ET.fromstring(text)
    return text, text != original

# v0.1.94 final full-info patch normalizer.
def _patch_af3_info_xml_kpm_owned(text: str):
    t, c1 = _patch_kpm_rating_row_info_xml(text)
    t, c2 = _patch_kpm_steam_info_plot(t)
    t, c3 = _patch_info_panel_gate_0189(t)
    t = re.sub(r'\n{3,}', '\n\n', t)
    ET.fromstring(t)
    return t, t != text

# v0.1.94 whitespace-stable full-info patch.
def _patch_af3_info_xml_kpm_owned(text: str):
    t, _ = _patch_kpm_rating_row_info_xml(text)
    t, _ = _patch_kpm_steam_info_plot(t)
    t, _ = _patch_info_panel_gate_0189(t)
    t = re.sub(r'(?:[ \t]*\n){3,}', '\n\n', t)
    ET.fromstring(t)
    return t, t != text

# v0.1.94 canonical newline normalization for repeatable patch output.
def _patch_af3_info_xml_kpm_owned(text: str):
    original = text.replace('\r\n', '\n').replace('\r', '\n')
    t, _ = _patch_kpm_rating_row_info_xml(original)
    t, _ = _patch_kpm_steam_info_plot(t)
    t, _ = _patch_info_panel_gate_0189(t)
    t = t.replace('\r\n', '\n').replace('\r', '\n')
    t = re.sub(r'(?:[ \t]*\n){3,}', '\n\n', t)
    ET.fromstring(t)
    return t, t != original

# v0.1.94 diagnostic snapshot for the committed lower-row slot set.
def _rating_row_runtime_0188() -> Dict[str, object]:
    base_names = ('Visible', 'ActiveSet', 'SchemaVersion', 'ItemKey', 'ItemType', 'Window', 'Reason', 'UpdatedAt', 'ResolverTitle', 'ResolverDBID', 'Generation', 'Signature')
    report: Dict[str, object] = _home_prop_snapshot_0188('KPM.RatingRow.', base_names)
    slots = {}
    for idx in range(1, 11):
        slots[str(idx)] = _home_prop_snapshot_0188('KPM.RatingRow.Slot{0}_'.format(idx), ('Source', 'IconFile', 'Label', 'Value'))
    report['slots'] = slots
    sets = {}
    for set_name in ('A', 'B'):
        set_report = _home_prop_snapshot_0188('KPM.RatingRow.{0}.'.format(set_name), ('ItemKey', 'ItemType', 'Generation', 'Signature'))
        set_slots = {}
        for idx in range(1, 11):
            set_slots[str(idx)] = _home_prop_snapshot_0188('KPM.RatingRow.{0}.Slot{1}_'.format(set_name, idx), ('Source', 'IconFile', 'Label', 'Value'))
        set_report['slots'] = set_slots
        sets[set_name] = set_report
    report['sets'] = sets
    active = str(report.get('ActiveSet') or '')
    report['active_slots'] = (sets.get(active) or {}).get('slots', {})
    return report


# v0.2.18 - LRS RatingSlot7 bridge/display support.
KPM_LRS_RATING_SLOT_COUNT = 7


# -----------------------------------------------------------------------------
# v0.2.19 - notification-safe Arctic Mirage metadata placement
# -----------------------------------------------------------------------------
# Arctic Mirage alternates its metadata panel between left and right. Kodi toast
# and background-progress windows occupy the lower-right area, so an odd/right
# panel can overlap them. Keep the native alternation normally, but while a
# standard notification/progress window is visible render the odd panel from an
# identical left-anchored snapshot instead.
KPM_SCREENSAVER_NOTIFY_LEFT_START_0219 = '<!-- KPM-AF3-SCREENSAVER-NOTIFY-LEFT-START-0219 -->'
KPM_SCREENSAVER_NOTIFY_LEFT_END_0219 = '<!-- KPM-AF3-SCREENSAVER-NOTIFY-LEFT-END-0219 -->'
KPM_SCREENSAVER_NOTIFY_RIGHT_START_0219 = '<!-- KPM-AF3-SCREENSAVER-NOTIFY-RIGHT-VISIBLE-START-0219 -->'
KPM_SCREENSAVER_NOTIFY_RIGHT_END_0219 = '<!-- KPM-AF3-SCREENSAVER-NOTIFY-RIGHT-VISIBLE-END-0219 -->'
KPM_SCREENSAVER_NOTIFY_CONDITION_0219 = (
    '[Window.IsVisible(notification) | Window.IsVisible(10107) | '
    'Window.IsVisible(extendedprogressdialog) | Window.IsVisible(10151) | '
    'Window.IsVisible(progressdialog) | Window.IsVisible(10101)]'
)
KPM_SCREENSAVER_NO_NOTIFY_CONDITION_0219 = (
    '!Window.IsVisible(notification) + !Window.IsVisible(10107) + '
    '!Window.IsVisible(extendedprogressdialog) + !Window.IsVisible(10151) + '
    '!Window.IsVisible(progressdialog) + !Window.IsVisible(10101)'
)


def _strip_screensaver_notification_safe_left_0219(text: str) -> str:
    """Return the canonical two-panel XML before reapplying the 0.2.19 patch."""
    duplicate_re = re.compile(
        r'\s*<!--\s*KPM-AF3-SCREENSAVER-NOTIFY-LEFT-START-0219\s*-->.*?'
        r'<!--\s*KPM-AF3-SCREENSAVER-NOTIFY-LEFT-END-0219\s*-->\s*',
        re.I | re.S,
    )
    text = duplicate_re.sub('\n', text)

    right_re = re.compile(
        r'<!--\s*KPM-AF3-SCREENSAVER-NOTIFY-RIGHT-VISIBLE-START-0219\s*-->.*?'
        r'<!--\s*KPM-AF3-SCREENSAVER-NOTIFY-RIGHT-VISIBLE-END-0219\s*-->',
        re.I | re.S,
    )
    text = right_re.sub(
        '<visible>Integer.IsOdd(ListItem.CurrentItem)</visible>',
        text,
    )
    return re.sub(r'\n{3,}', '\n\n', text)


def _control_block_for_anchor_0219(text: str, anchor: str):
    anchor_pos = text.find(anchor)
    if anchor_pos < 0:
        return -1, -1, ''
    starts = list(re.finditer(r'<control\s+type=["\']group["\'][^>]*>', text[:anchor_pos], re.I))
    if not starts:
        return -1, -1, ''
    start = starts[-1].start()
    depth = 0
    token_re = re.compile(r'<control\b[^>]*>|</control\s*>', re.I)
    for match in token_re.finditer(text, start):
        token = match.group(0)
        if token.lower().startswith('</control'):
            depth -= 1
            if depth == 0:
                return start, match.end(), text[start:match.end()]
        elif not token.rstrip().endswith('/>'):
            depth += 1
    return -1, -1, ''


def _patch_screensaver_notification_safe_left_0219(text: str):
    original = text
    text = _strip_screensaver_notification_safe_left_0219(text)
    anchor = '<right>view_pad</right>'
    start, end, block = _control_block_for_anchor_0219(text, anchor)
    if start < 0:
        return original, False

    native_visible = '<visible>Integer.IsOdd(ListItem.CurrentItem)</visible>'
    if native_visible not in block:
        return original, False

    line_start = text.rfind('\n', 0, start) + 1
    indent = text[line_start:start]
    condition = KPM_SCREENSAVER_NOTIFY_CONDITION_0219
    no_condition = KPM_SCREENSAVER_NO_NOTIFY_CONDITION_0219

    right_visible = (
        KPM_SCREENSAVER_NOTIFY_RIGHT_START_0219 + '\n'
        + indent + '    <visible>Integer.IsOdd(ListItem.CurrentItem) + '
        + no_condition + '</visible>\n'
        + indent + '    ' + KPM_SCREENSAVER_NOTIFY_RIGHT_END_0219
    )
    right_block = block.replace(native_visible, right_visible, 1)

    left_block = block.replace(anchor, '<left>view_pad</left>', 1)
    left_block = left_block.replace(
        native_visible,
        '<visible>Integer.IsOdd(ListItem.CurrentItem) + {0}</visible>'.format(condition),
        1,
    )
    duplicate = (
        indent + KPM_SCREENSAVER_NOTIFY_LEFT_START_0219 + '\n'
        + left_block + '\n'
        + indent + KPM_SCREENSAVER_NOTIFY_LEFT_END_0219
    )

    patched = text[:start] + right_block + '\n' + duplicate + text[end:]
    ET.fromstring(patched)
    return patched, patched != original


_patch_screensaver_mirage_xml_0219_base = _patch_screensaver_mirage_xml


def _patch_screensaver_mirage_xml() -> bool:
    path = af3_path('1080i', 'screensaver-arctic-mirage.xml')
    if not os.path.exists(path):
        return False

    # Strip our duplicate first so the mature 0.2.18 normalizer still sees the
    # exact two native metadata panels and exactly two KPM rating/clearlogo rows.
    before = read_text(path)
    canonical = _strip_screensaver_notification_safe_left_0219(before)
    if canonical != before:
        write_text(path, canonical)

    _patch_screensaver_mirage_xml_0219_base()
    current = read_text(path)
    patched, notify_changed = _patch_screensaver_notification_safe_left_0219(current)
    if notify_changed:
        write_text(path, patched)
    # Compare the final XML with the caller-visible starting state. Reapplying
    # the same 0.2.19 patch therefore reports Skipped instead of Patched.
    return patched != before


_remove_af3_unified_integration_0219_base = remove_af3_unified_integration


def remove_af3_unified_integration() -> Result:
    path = af3_path('1080i', 'screensaver-arctic-mirage.xml')
    if os.path.exists(path):
        current = read_text(path)
        canonical = _strip_screensaver_notification_safe_left_0219(current)
        if canonical != current:
            write_text(path, canonical)
    return _remove_af3_unified_integration_0219_base()


_status_af3_unified_integration_0219_base = status_af3_unified_integration


def status_af3_unified_integration() -> str:
    base = _status_af3_unified_integration_0219_base()
    path = af3_path('1080i', 'screensaver-arctic-mirage.xml')
    notify_ok = False
    if os.path.exists(path):
        try:
            current = read_text(path)
            notify_ok = (
                KPM_SCREENSAVER_NOTIFY_LEFT_START_0219 in current
                and KPM_SCREENSAVER_NOTIFY_RIGHT_START_0219 in current
                and 'Window.IsVisible(notification)' in current
                and 'Window.IsVisible(extendedprogressdialog)' in current
                and 'Window.IsVisible(progressdialog)' in current
            )
        except Exception:
            notify_ok = False
    if notify_ok:
        return base + '; notification-safe left panel'
    if str(base).startswith('Patched'):
        return 'Partial (base integration active; notification-safe left panel missing)'
    return base


# -----------------------------------------------------------------------------
# v0.2.20 - KPM Unified owns AF3 progress separator spacing
# -----------------------------------------------------------------------------
_AF3_PROGRESS_OLD_0220 = '$INFO[Control.GetLabel(32), - ,%]'
_AF3_PROGRESS_NEW_0220 = '$INFO[Control.GetLabel(32),- ,%]'

def _af3_progress_file_0220():
    return translate('special://home/addons/skin.arctic.fuse.3/1080i/DialogExtendedProgressBar.xml')

def _patch_af3_progress_spacing_0220():
    path = _af3_progress_file_0220()
    text = read_text(path)
    if _AF3_PROGRESS_NEW_0220 in text:
        return {'path': path, 'changed': False, 'status': 'already_patched'}
    if _AF3_PROGRESS_OLD_0220 not in text:
        raise RuntimeError('AF3 progress separator expression not found')
    backup = path + '.kpm0220-unified-progress.bak'
    if not os.path.exists(backup):
        shutil.copy2(path, backup)
    write_text(path, text.replace(_AF3_PROGRESS_OLD_0220, _AF3_PROGRESS_NEW_0220))
    return {'path': path, 'backup': backup, 'changed': True, 'status': 'patched'}

def _remove_af3_progress_spacing_0220():
    path = _af3_progress_file_0220()
    if not os.path.exists(path):
        return {'path': path, 'changed': False, 'status': 'missing'}
    text = read_text(path)
    if _AF3_PROGRESS_NEW_0220 in text:
        write_text(path, text.replace(_AF3_PROGRESS_NEW_0220, _AF3_PROGRESS_OLD_0220))
        return {'path': path, 'changed': True, 'status': 'restored'}
    return {'path': path, 'changed': False, 'status': 'not_patched'}

def _status_af3_progress_spacing_0220():
    try:
        text = read_text(_af3_progress_file_0220())
        return 'Patched' if _AF3_PROGRESS_NEW_0220 in text else 'Not patched'
    except Exception as exc:
        return 'Error ({0})'.format(exc)

# Wrap the final Unified functions, whatever earlier compatibility layer defined.
_apply_af3_unified_0220_base = globals().get('apply_af3_unified_integration')
_remove_af3_unified_0220_base = globals().get('remove_af3_unified_integration')
_status_af3_unified_0220_base = globals().get('status_af3_unified_integration')

def apply_af3_unified_integration():
    result = _apply_af3_unified_0220_base() if callable(_apply_af3_unified_0220_base) else None
    spacing = _patch_af3_progress_spacing_0220()
    try:
        state = load_state('af3_unified_integration')
    except Exception:
        state = {}
    state['progress_separator_spacing'] = spacing
    save_state('af3_unified_integration', state)
    return result

def remove_af3_unified_integration():
    spacing = _remove_af3_progress_spacing_0220()
    result = _remove_af3_unified_0220_base() if callable(_remove_af3_unified_0220_base) else None
    return result or spacing

def status_af3_unified_integration():
    base = _status_af3_unified_0220_base() if callable(_status_af3_unified_0220_base) else 'Unknown'
    return '{0}; Progress spacing: {1}'.format(base, _status_af3_progress_spacing_0220())


# -----------------------------------------------------------------------------
# v0.2.24 - AF3 Cinema Pre-roll fonts
# -----------------------------------------------------------------------------
KPM_CINEMA_FONT_NAMES_0223 = (
    'CinemaTitleSingle', 'CinemaTitleDouble', 'CinemaTitleLong',
    'CinemaTitleTriple', 'CinemaCertNumber', 'CinemaAgeText',
)
KPM_CINEMA_FONT_SPECS_0223 = (
    ('CinemaTitleSingle', 'resource://resource.font.robotocjksc/Inter-Unicode-Bold.ttf', 62),
    ('CinemaTitleDouble', 'resource://resource.font.robotocjksc/Inter-Unicode-Bold.ttf', 52),
    ('CinemaTitleLong', 'resource://resource.font.robotocjksc/Inter-Unicode-Bold.ttf', 44),
    ('CinemaTitleTriple', 'resource://resource.font.robotocjksc/Inter-Unicode-Bold.ttf', 34),
    ('CinemaCertNumber', 'resource://resource.font.robotocjksc/Inter-Unicode-Regular.ttf', 16),
    ('CinemaAgeText', 'resource://resource.font.robotocjksc/Inter-Unicode-Bold.ttf', 21),
)


def _af3_font_xml_0223() -> str:
    return af3_path('1080i', 'Font.xml')


def _cinema_font_block_0223(indent: str) -> str:
    rows = []
    for name, filename, size in KPM_CINEMA_FONT_SPECS_0223:
        rows.extend([
            indent + '<font>',
            indent + '    <name>{0}</name>'.format(name),
            indent + '    <filename>{0}</filename>'.format(filename),
            indent + '    <size>{0}</size>'.format(size),
            indent + '</font>',
        ])
    return '\n'.join(rows)


def _fontset_bounds_0223(text: str, fontset_id: str):
    pattern = re.compile(r'<fontset\b[^>]*\bid=["\']' + re.escape(fontset_id) + r'["\'][^>]*>', re.I)
    match = pattern.search(text)
    if not match:
        return -1, -1, ''
    end = text.find('</fontset>', match.end())
    if end < 0:
        return -1, -1, ''
    end += len('</fontset>')
    return match.start(), end, text[match.start():end]


def _strip_cinema_fonts_from_fontset_0223(block: str) -> str:
    for name in KPM_CINEMA_FONT_NAMES_0223:
        pattern = re.compile(
            r'(?m)^[ \t]*<font>\s*<name>\s*' + re.escape(name) + r'\s*</name>.*?</font>[ \t]*(?:\n|$)',
            re.I | re.S,
        )
        block = pattern.sub('', block)
    return re.sub(r'\n{3,}', '\n\n', block)


def _patch_af3_cinema_fonts_0223():
    path = _af3_font_xml_0223()
    if not os.path.exists(path):
        return {'path': path, 'changed': False, 'status': 'missing'}
    original = read_text(path)
    current = original
    for fontset_id in ('Default', 'Default (Unicode)'):
        start, end, block = _fontset_bounds_0223(current, fontset_id)
        if start < 0:
            raise RuntimeError('AF3 Font.xml fontset not found: {0}'.format(fontset_id))
        block = _strip_cinema_fonts_from_fontset_0223(block)
        close_pos = block.rfind('</fontset>')
        line_start = block.rfind('\n', 0, close_pos) + 1
        close_indent = block[line_start:close_pos]
        font_indent = close_indent + '    '
        clean_head = block[:close_pos].rstrip()
        patched_block = clean_head + '\n' + _cinema_font_block_0223(font_indent) + '\n' + close_indent + '</fontset>'
        current = current[:start] + patched_block + current[end:]
    ET.fromstring(current)
    if current != original:
        write_text(path, current)
        return {'path': path, 'changed': True, 'status': 'patched'}
    return {'path': path, 'changed': False, 'status': 'already_patched'}


def _remove_af3_cinema_fonts_0223():
    path = _af3_font_xml_0223()
    if not os.path.exists(path):
        return {'path': path, 'changed': False, 'status': 'missing'}
    original = read_text(path)
    current = original
    for fontset_id in ('Default', 'Default (Unicode)'):
        start, end, block = _fontset_bounds_0223(current, fontset_id)
        if start < 0:
            continue
        patched_block = _strip_cinema_fonts_from_fontset_0223(block).rstrip()
        current = current[:start] + patched_block + current[end:]
    ET.fromstring(current)
    if current != original:
        write_text(path, current)
        return {'path': path, 'changed': True, 'status': 'removed'}
    return {'path': path, 'changed': False, 'status': 'not_patched'}


def _cinema_font_status_0223() -> str:
    path = _af3_font_xml_0223()
    if not os.path.exists(path):
        return 'Missing target'
    try:
        root = ET.fromstring(read_text(path))
        results = []
        for fontset_id in ('Default', 'Default (Unicode)'):
            fontset = next((node for node in root.findall('fontset') if node.get('id') == fontset_id), None)
            found = {}
            if fontset is not None:
                for node in fontset.findall('font'):
                    name = (node.findtext('name') or '').strip()
                    if name in KPM_CINEMA_FONT_NAMES_0223:
                        found[name] = ((node.findtext('filename') or '').strip(), (node.findtext('size') or '').strip())
            valid = 0
            for name, filename, size in KPM_CINEMA_FONT_SPECS_0223:
                if found.get(name) == (filename, str(size)):
                    valid += 1
            results.append('{0} {1}/6'.format(fontset_id.upper(), valid))
        return 'Patched ({0})'.format(', '.join(results)) if all(value.endswith('6/6') for value in results) else 'Partial ({0})'.format(', '.join(results))
    except Exception as exc:
        return 'Error ({0})'.format(exc)


_apply_af3_unified_0223_base = apply_af3_unified_integration
_remove_af3_unified_0223_base = remove_af3_unified_integration
_status_af3_unified_0223_base = status_af3_unified_integration


def apply_af3_unified_integration():
    result = _apply_af3_unified_0223_base()
    font_result = _patch_af3_cinema_fonts_0223()
    if font_result.get('changed') and not (isinstance(result, Result) and result.status == 'Patched'):
        _reload_skin_after_patch()
    if isinstance(result, Result):
        detail = result.detail + ' Cinema fonts: {0}.'.format(font_result.get('status'))
        status = 'Patched' if result.status == 'Patched' or font_result.get('changed') else result.status
        return Result(result.name, status, detail)
    return Result('AF3 Unified Integration', 'Patched' if font_result.get('changed') else 'Skipped', 'Cinema fonts: {0}.'.format(font_result.get('status')))


def remove_af3_unified_integration():
    font_result = _remove_af3_cinema_fonts_0223()
    result = _remove_af3_unified_0223_base()
    if font_result.get('changed') and not (isinstance(result, Result) and result.status == 'Removed'):
        _reload_skin_after_patch()
    if isinstance(result, Result):
        return Result(result.name, result.status, result.detail + ' Cinema fonts: {0}.'.format(font_result.get('status')))
    return Result('AF3 Unified Integration', 'Removed' if font_result.get('changed') else 'Skipped', 'Cinema fonts: {0}.'.format(font_result.get('status')))


def status_af3_unified_integration() -> str:
    base = _status_af3_unified_0223_base()
    return '{0}; Cinema Pre-roll fonts: {1}'.format(base, _cinema_font_status_0223())


# -----------------------------------------------------------------------------


# -----------------------------------------------------------------------------

# -----------------------------------------------------------------------------
# v0.2.33 - current-only AF3 integration, fresh-install baseline
# -----------------------------------------------------------------------------
# This release patches only a clean AF3 file or its own complete current output.
# Older KPM/SteamLib patch markers are rejected without modifying the file.
# There is no conversion path from an earlier patch layout.
KPM_CURRENT_SCREEN_NORMAL_START_0233 = '<!-- KPM-AF3-SCREENSAVER-CURRENT-NORMAL-START-0233 -->'
KPM_CURRENT_SCREEN_NORMAL_END_0233 = '<!-- KPM-AF3-SCREENSAVER-CURRENT-NORMAL-END-0233 -->'
KPM_CURRENT_SCREEN_NOTIFY_START_0233 = '<!-- KPM-AF3-SCREENSAVER-CURRENT-NOTIFY-LEFT-START-0233 -->'
KPM_CURRENT_SCREEN_NOTIFY_END_0233 = '<!-- KPM-AF3-SCREENSAVER-CURRENT-NOTIFY-LEFT-END-0233 -->'
KPM_CURRENT_VIGNETTE_LEFT_START_0233 = '<!-- KPM-AF3-SCREENSAVER-CURRENT-VIGNETTE-LEFT-START-0233 -->'
KPM_CURRENT_VIGNETTE_LEFT_END_0233 = '<!-- KPM-AF3-SCREENSAVER-CURRENT-VIGNETTE-LEFT-END-0233 -->'
KPM_CURRENT_VIGNETTE_RIGHT_START_0233 = '<!-- KPM-AF3-SCREENSAVER-CURRENT-VIGNETTE-RIGHT-START-0233 -->'
KPM_CURRENT_VIGNETTE_RIGHT_END_0233 = '<!-- KPM-AF3-SCREENSAVER-CURRENT-VIGNETTE-RIGHT-END-0233 -->'
KPM_CURRENT_BACKUP_SCREEN_0233 = '.kpm-current-screensaver.bak'
KPM_CURRENT_BACKUP_INFO_0233 = '.kpm-current-info.bak'
KPM_CURRENT_BACKUP_LAYOUTS_0233 = '.kpm-current-layouts.bak'

_KPM_SCREEN_BASE_CURRENT_0233 = _patch_screensaver_mirage_xml
_KPM_INFO_PATCH_CURRENT_0233 = _patch_af3_info_xml_kpm_owned
_KPM_LAYOUT_PATCH_CURRENT_0233 = _patch_af3_layouts_0187

KPM_CURRENT_NOTIFY_CONDITION_0233 = KPM_SCREENSAVER_NOTIFY_CONDITION_0219
KPM_CURRENT_NO_NOTIFY_CONDITION_0233 = KPM_SCREENSAVER_NO_NOTIFY_CONDITION_0219


def _kpm_marker_suffixes_0233(text: str, prefix: str = 'KPM-AF3-') -> set:
    suffixes = set()
    for marker in re.findall(r'<!--\s*(' + re.escape(prefix) + r'[^>]*?)\s*-->', text or '', re.I):
        match = re.search(r'-(\d{4})(?:\s|$)', marker)
        if match:
            suffixes.add(match.group(1))
    return suffixes


def _assert_current_info_source_0233(text: str) -> None:
    # This exact 0186 marker is still emitted by the current native-meta conflict guard.
    marker_clean = (text or '').replace('<!-- KPM-AF3-NATIVE-META-DISABLED-0186 -->', '')
    suffixes = _kpm_marker_suffixes_0233(marker_clean)
    allowed = {'0189', '0190'}
    unsupported = suffixes - allowed
    if unsupported:
        raise ValueError(
            'Unsupported older AF3 info patch markers: {0}. Restore a clean AF3 file before applying.'.format(
                ', '.join(sorted(unsupported))
            )
        )


def _assert_current_layout_source_0233(text: str) -> None:
    old_tokens = (
        'KPM Compact Steam Landscape BEGIN 0187',
        'KPM Compact Steam Landscape BEGIN 0188',
        'KPM Original Landscape BEGIN 0187',
        'KPM Original Landscape BEGIN 0188',
        'SteamLib Compact Landscape BEGIN',
        'SteamLib Original Landscape BEGIN',
    )
    if any(token in text for token in old_tokens):
        raise ValueError('Unsupported older AF3 landscape patch. Restore a clean AF3 file before applying.')


def _assert_current_screensaver_source_0233(text: str) -> None:
    if _is_current_screensaver_0233(text):
        return
    old_tokens = (
        'KPM-AF3-SCREENSAVER-NOTIFY-LEFT-START-0219',
        'KPM-AF3-SCREENSAVER-NOTIFY-RIGHT-VISIBLE-START-0219',
        'KPM-AF3-SCREENSAVER-ATOMIC-BUNDLE-START-0227',
        'KPM-AF3-SCREENSAVER-DUAL-BUNDLE-START-0229',
        'KPM-AF3-SCREENSAVER-PARITY-SLOT-START-0231',
        'KPM-AF3-SCREENSAVER-NOTIFY-LEFT-SLOT-START-0232',
        'KPM-AF3-SCREENSAVER-VIGNETTE-LEFT-NOTIFY-START-0232',
        'KPM-AF3-SCREENSAVER-VIGNETTE-RIGHT-NOTIFY-START-0232',
    )
    found = [token for token in old_tokens if token in text]
    if found:
        raise ValueError('Unsupported older screensaver patch. Restore a clean AF3 file before applying.')
    current_partial = any(
        token in text for token in (
            KPM_CURRENT_SCREEN_NORMAL_START_0233,
            KPM_CURRENT_SCREEN_NOTIFY_START_0233,
            KPM_CURRENT_VIGNETTE_LEFT_START_0233,
            KPM_CURRENT_VIGNETTE_RIGHT_START_0233,
        )
    )
    if current_partial:
        raise ValueError('Partial current screensaver patch detected; source was not modified.')


def _matching_control_end_current_0233(text: str, start: int) -> int:
    depth = 0
    token_re = re.compile(r'<control\b[^>]*>|</control\s*>', re.I)
    for match in token_re.finditer(text, start):
        token = match.group(0)
        if token.lower().startswith('</control'):
            depth -= 1
            if depth == 0:
                return match.end()
        elif not token.rstrip().endswith('/>'):
            depth += 1
    return -1


def _metadata_panels_current_0233(text: str):
    pattern = re.compile(
        r'^[ \t]*<control type="group">\s*\n'
        r'^[ \t]*<(?:left|right)>view_pad</(?:left|right)>\s*\n'
        r'^[ \t]*<width>680</width>',
        re.I | re.M,
    )
    output = []
    for match in pattern.finditer(text):
        end = _matching_control_end_current_0233(text, match.start())
        if end < 0:
            raise ValueError('Unbalanced Arctic Mirage metadata panel')
        output.append((match.start(), end, text[match.start():end]))
    return output


def _visible_current_0233(block: str):
    return re.search(r'(?P<indent>^[ \t]*)<visible>(?P<condition>[^<]+)</visible>', block, re.I | re.M)


def _replace_visible_current_0233(block: str, condition: str, start_marker: str, end_marker: str) -> str:
    visible = _visible_current_0233(block)
    if not visible:
        raise ValueError('Metadata panel visible condition is missing')
    indent = visible.group('indent')
    replacement = (
        indent + start_marker + '\n'
        + indent + '<visible>' + condition + '</visible>\n'
        + indent + end_marker
    )
    return block[:visible.start()] + replacement + block[visible.end():]


def _slot_gate_current_0233(slot: str) -> str:
    prefix = 'LibraryRatings.Screensaver.Bundle{0}.'.format(slot)
    return (
        'String.IsEqual(Container(1297).ListItem.Property(mediahub_bundle_slot),{0}) + '.format(slot)
        + 'String.IsEqual(Window(Home).Property(' + prefix + 'Ready),true) + '
        + '!String.IsEmpty(Container(1297).ListItem.Property(mediahub_item_key)) + '
        + 'String.IsEqual(Container(1297).ListItem.Property(mediahub_item_key),'
        + 'Window(Home).Property(' + prefix + 'ItemKey))'
    )


def _strip_intermediate_markers_current_0233(block: str) -> str:
    patterns = (
        r'^[ \t]*<!-- KPM-AF3-SCREENSAVER-NOTIFY-LEFT-(?:START|END)-0219 -->[ \t]*\n?',
        r'^[ \t]*<!-- KPM-AF3-SCREENSAVER-NOTIFY-RIGHT-VISIBLE-(?:START|END)-0219 -->[ \t]*\n?',
    )
    for pattern in patterns:
        block = re.sub(pattern, '', block, flags=re.I | re.M)
    return block


def _slot_panel_current_0233(template: str, slot: str, side: str, notification: bool = False) -> str:
    block = _strip_intermediate_markers_current_0233(template)
    block = re.sub(
        r'LibraryRatings\.Screensaver\.(?!Bundle[AB]\.)',
        'LibraryRatings.Screensaver.Bundle{0}.'.format(slot),
        block,
    )
    block = block.replace(
        '$INFO[Container(1297).ListItem.Title]',
        '$INFO[Window(Home).Property(LibraryRatings.Screensaver.Bundle{0}.Title)]'.format(slot),
    )
    block = block.replace(
        '$INFO[Container(1297).ListItem.Plot]',
        '$INFO[Window(Home).Property(LibraryRatings.Screensaver.Bundle{0}.Plot)]'.format(slot),
    )
    if side == 'left':
        block = block.replace('<right>view_pad</right>', '<left>view_pad</left>', 1)
    else:
        block = block.replace('<left>view_pad</left>', '<right>view_pad</right>', 1)
    if 'time="1">Hidden</animation>' not in block:
        visible_animation = re.search(
            r'(?P<indent>^[ \t]*)<animation effect="fade" start="0" end="100" time="400">Visible</animation>',
            block,
            re.I | re.M,
        )
        if not visible_animation:
            raise ValueError('Metadata panel fade-in animation is missing')
        hidden_animation = (
            visible_animation.group(0) + '\n' + visible_animation.group('indent')
            + '<animation effect="fade" start="100" end="0" time="1">Hidden</animation>'
        )
        block = block[:visible_animation.start()] + hidden_animation + block[visible_animation.end():]
    gate = _slot_gate_current_0233(slot)
    if notification:
        condition = KPM_CURRENT_NOTIFY_CONDITION_0233 + ' + ' + gate
        return _replace_visible_current_0233(
            block, condition, KPM_CURRENT_SCREEN_NOTIFY_START_0233, KPM_CURRENT_SCREEN_NOTIFY_END_0233
        )
    parity = '!Integer.IsOdd(ListItem.CurrentItem)' if side == 'left' else 'Integer.IsOdd(ListItem.CurrentItem)'
    condition = parity + ' + ' + KPM_CURRENT_NO_NOTIFY_CONDITION_0233 + ' + ' + gate
    return _replace_visible_current_0233(
        block, condition, KPM_CURRENT_SCREEN_NORMAL_START_0233, KPM_CURRENT_SCREEN_NORMAL_END_0233
    )


def _vignette_ranges_current_0233(text: str):
    output = []
    for match in re.finditer(r'<control type="image">', text, re.I):
        end = _matching_control_end_current_0233(text, match.start())
        if end < 0:
            continue
        block = text[match.start():end]
        if 'vignette.png' in block:
            output.append((match.start(), end, block))
    return output


def _patch_vignettes_current_0233(text: str) -> str:
    ranges = _vignette_ranges_current_0233(text)
    if len(ranges) != 2:
        raise ValueError('Expected two Arctic Mirage vignette controls; found {0}'.format(len(ranges)))
    replacements = []
    for start, end, block in ranges:
        left = 'flipx="false"' in block
        condition = (
            '[!Integer.IsOdd(ListItem.CurrentItem) + ' + KPM_CURRENT_NO_NOTIFY_CONDITION_0233 + '] | '
            + KPM_CURRENT_NOTIFY_CONDITION_0233
            if left else
            'Integer.IsOdd(ListItem.CurrentItem) + ' + KPM_CURRENT_NO_NOTIFY_CONDITION_0233
        )
        replacements.append((
            start,
            end,
            _replace_visible_current_0233(
                block,
                condition,
                KPM_CURRENT_VIGNETTE_LEFT_START_0233 if left else KPM_CURRENT_VIGNETTE_RIGHT_START_0233,
                KPM_CURRENT_VIGNETTE_LEFT_END_0233 if left else KPM_CURRENT_VIGNETTE_RIGHT_END_0233,
            ),
        ))
    for start, end, block in sorted(replacements, key=lambda item: item[0], reverse=True):
        text = text[:start] + block + text[end:]
    return text


def _validate_current_screensaver_0233(text: str) -> None:
    if text.count(KPM_CURRENT_SCREEN_NORMAL_START_0233) != 4:
        raise ValueError('Current normal metadata panel count is invalid')
    if text.count(KPM_CURRENT_SCREEN_NOTIFY_START_0233) != 2:
        raise ValueError('Current notification-left panel count is invalid')
    if text.count(KPM_CURRENT_VIGNETTE_LEFT_START_0233) != 1:
        raise ValueError('Current left vignette marker is missing')
    if text.count(KPM_CURRENT_VIGNETTE_RIGHT_START_0233) != 1:
        raise ValueError('Current right vignette marker is missing')
    panels = _metadata_panels_current_0233(text)
    if len(panels) != 6:
        raise ValueError('Expected six current metadata panels; found {0}'.format(len(panels)))
    normal_left = normal_right = notify_left = 0
    slots = {'A': 0, 'B': 0}
    for _start, _end, block in panels:
        visible = _visible_current_0233(block)
        if not visible:
            raise ValueError('Current metadata panel visible condition is missing')
        condition = visible.group('condition')
        slot = 'A' if 'mediahub_bundle_slot),A)' in condition else ('B' if 'mediahub_bundle_slot),B)' in condition else '')
        if not slot:
            raise ValueError('Current metadata panel lost its bundle slot')
        slots[slot] += 1
        if KPM_CURRENT_NOTIFY_CONDITION_0233 in condition:
            notify_left += 1
            if '<left>view_pad</left>' not in block or 'Integer.IsOdd(ListItem.CurrentItem)' in condition:
                raise ValueError('Notification panel must stay left and ignore parity')
        elif '!Integer.IsOdd(ListItem.CurrentItem)' in condition:
            normal_left += 1
            if '<left>view_pad</left>' not in block or KPM_CURRENT_NO_NOTIFY_CONDITION_0233 not in condition:
                raise ValueError('Even current panel is invalid')
        elif 'Integer.IsOdd(ListItem.CurrentItem)' in condition:
            normal_right += 1
            if '<right>view_pad</right>' not in block or KPM_CURRENT_NO_NOTIFY_CONDITION_0233 not in condition:
                raise ValueError('Odd current panel is invalid')
        else:
            raise ValueError('Current normal panel lost AF3 parity')
        if block.count('time="1">Hidden</animation>') < 1:
            raise ValueError('Current metadata panel lost its 1 ms fade-out')
    if (normal_left, normal_right, notify_left) != (2, 2, 2):
        raise ValueError('Current metadata distribution is invalid')
    if slots != {'A': 3, 'B': 3}:
        raise ValueError('Current bundle distribution is invalid: {0}'.format(slots))
    if text.count('KPM-AF3-SCREENSAVER-DUAL-BUNDLE') or text.count('KPM-AF3-SCREENSAVER-PARITY-SLOT'):
        raise ValueError('Older screensaver patch markers remain')
    if text.count('KPM-AF3-SCREENSAVER-NOTIFY-LEFT-SLOT'):
        raise ValueError('Older notification-slot markers remain')
    ET.fromstring(text)


def _is_current_screensaver_0233(text: str) -> bool:
    return (
        text.count(KPM_CURRENT_SCREEN_NORMAL_START_0233) == 4
        and text.count(KPM_CURRENT_SCREEN_NOTIFY_START_0233) == 2
        and text.count(KPM_CURRENT_VIGNETTE_LEFT_START_0233) == 1
        and text.count(KPM_CURRENT_VIGNETTE_RIGHT_START_0233) == 1
    )


def _build_current_screensaver_0233(intermediate: str) -> str:
    panels = _metadata_panels_current_0233(intermediate)
    if len(panels) != 3:
        raise ValueError('Clean AF3 intermediate must contain three metadata panels; found {0}'.format(len(panels)))
    left_normal = right_normal = left_notify = None
    for start, end, block in panels:
        visible = _visible_current_0233(block)
        condition = visible.group('condition') if visible else ''
        if '<right>view_pad</right>' in block:
            right_normal = (start, end, block)
        elif KPM_CURRENT_NOTIFY_CONDITION_0233 in condition:
            left_notify = (start, end, block)
        else:
            left_normal = (start, end, block)
    if not left_normal or not right_normal or not left_notify:
        raise ValueError('Could not identify clean AF3 left, right, and notification templates')
    replacement_map = (
        (left_normal[0], left_normal[1],
         _slot_panel_current_0233(left_normal[2], 'A', 'left') + '\n' +
         _slot_panel_current_0233(left_normal[2], 'B', 'left')),
        (right_normal[0], right_normal[1],
         _slot_panel_current_0233(right_normal[2], 'A', 'right') + '\n' +
         _slot_panel_current_0233(right_normal[2], 'B', 'right')),
        (left_notify[0], left_notify[1],
         _slot_panel_current_0233(left_notify[2], 'A', 'left', notification=True) + '\n' +
         _slot_panel_current_0233(left_notify[2], 'B', 'left', notification=True)),
    )
    text = intermediate
    for start, end, replacement in sorted(replacement_map, key=lambda item: item[0], reverse=True):
        text = text[:start] + replacement + text[end:]
    text = re.sub(r'^[ \t]*<!-- KPM-AF3-SCREENSAVER-NOTIFY-(?:LEFT|RIGHT-VISIBLE)-(?:START|END)-0219 -->[ \t]*\n?', '', text, flags=re.I | re.M)
    text = _patch_vignettes_current_0233(text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    _validate_current_screensaver_0233(text)
    return text


def _patch_screensaver_mirage_xml() -> bool:
    path = af3_path('1080i', 'screensaver-arctic-mirage.xml')
    if not os.path.exists(path):
        return False
    original = read_text(path)
    _assert_current_screensaver_source_0233(original)
    if _is_current_screensaver_0233(original):
        updated = _upgrade_current_screensaver_fadeout_0235(original)
        if updated != original:
            write_text(path, updated)
            return True
        _validate_current_screensaver_0233(original)
        return False
    backup = path + KPM_CURRENT_BACKUP_SCREEN_0233
    if not os.path.exists(backup):
        write_text(backup, original)
    try:
        _KPM_SCREEN_BASE_CURRENT_0233()
        intermediate = read_text(path)
        final = _build_current_screensaver_0233(intermediate)
        if final != original:
            write_text(path, final)
        return final != original
    except Exception:
        write_text(path, original)
        raise


def _patch_af3_info_xml_safely(path: str) -> bool:
    original = read_text(path)
    _assert_current_info_source_0233(original)
    backup = path + KPM_CURRENT_BACKUP_INFO_0233
    if not os.path.exists(backup):
        write_text(backup, original)
    patched, changed = _KPM_INFO_PATCH_CURRENT_0233(original)
    # Canonicalise to a fixed point in the same update so the next startup is a no-op.
    canonical, canonical_changed = _KPM_INFO_PATCH_CURRENT_0233(patched)
    if canonical_changed:
        patched = canonical
    ET.fromstring(patched)
    if patched != original:
        write_text(path, patched)
        return True
    return bool(changed or canonical_changed)


def _patch_af3_layouts_file_0187() -> bool:
    path = af3_path('1080i', 'Includes_Layouts.xml')
    if not os.path.exists(path):
        return False
    original = read_text(path)
    _assert_current_layout_source_0233(original)
    backup = path + KPM_CURRENT_BACKUP_LAYOUTS_0233
    if not os.path.exists(backup):
        write_text(backup, original)
    patched, changed = _KPM_LAYOUT_PATCH_CURRENT_0233(original)
    ET.fromstring(patched)
    if patched != original:
        write_text(path, patched)
        return True
    return bool(changed)


def apply_af3_unified_integration() -> Result:
    info_xml = af3_path('1080i', 'Includes_Info.xml')
    if not os.path.exists(info_xml):
        return Result('AF3 Unified Integration', 'Skipped', 'Includes_Info.xml not found:\n{0}'.format(info_xml))
    changed = []
    try:
        changed.append(_patch_af3_info_xml_safely(info_xml))
        changed.append(_patch_af3_layouts_file_0187())
        changed.append(_patch_screensaver_mirage_xml())
        changed.append(bool(_patch_af3_progress_spacing_0220().get('changed')))
        changed.append(bool(_patch_af3_cinema_fonts_0223().get('changed')))
    except Exception as exc:
        log('Current-only AF3 integration refused: {0}'.format(exc))
        return Result('AF3 Unified Integration', 'Skipped', str(exc))
    any_changed = any(changed)
    save_state('af3_unified_integration', {
        'enabled': True,
        'version': VERSION,
        'owner': 'KPM',
        'baseline': 'current-only-fresh-install',
        'changed': any_changed,
    })
    if any_changed:
        _reload_skin_after_patch()
    return Result(
        'AF3 Unified Integration',
        'Patched' if any_changed else 'Skipped',
        'Current AF3 integration is active. No old patch conversion was executed.' + ('' if any_changed else ' Already current.'),
    )


def _restore_current_backup_0233(path: str, suffix: str) -> bool:
    backup = path + suffix
    if not os.path.exists(path) or not os.path.exists(backup):
        return False
    shutil.copy2(backup, path)
    return True


def remove_af3_unified_integration() -> Result:
    changed = False
    changed = _restore_current_backup_0233(af3_path('1080i', 'Includes_Info.xml'), KPM_CURRENT_BACKUP_INFO_0233) or changed
    changed = _restore_current_backup_0233(af3_path('1080i', 'Includes_Layouts.xml'), KPM_CURRENT_BACKUP_LAYOUTS_0233) or changed
    changed = _restore_current_backup_0233(af3_path('1080i', 'screensaver-arctic-mirage.xml'), KPM_CURRENT_BACKUP_SCREEN_0233) or changed
    changed = bool(_remove_af3_progress_spacing_0220().get('changed')) or changed
    changed = bool(_remove_af3_cinema_fonts_0223().get('changed')) or changed
    delete_state('af3_unified_integration')
    if changed:
        _reload_skin_after_patch()
    return Result(
        'AF3 Unified Integration',
        'Removed' if changed else 'Skipped',
        'Current KPM backups were restored.' if changed else 'No current KPM backup was available; no heuristic removal was attempted.',
    )


def status_af3_unified_integration() -> str:
    try:
        screen = read_text(af3_path('1080i', 'screensaver-arctic-mirage.xml'))
        _validate_current_screensaver_0233(screen)
        screen_status = 'current 6-panel parity/notification-left'
    except Exception:
        screen_status = 'not current'
    try:
        info = read_text(af3_path('1080i', 'Includes_Info.xml'))
        info_ok = KPM_AF3_ROW_CALL_START in info and KPM_AF3_ROW_DEF_START in info and KPM_PANEL_GATE_START in info
    except Exception:
        info_ok = False
    try:
        layouts = read_text(af3_path('1080i', 'Includes_Layouts.xml'))
        layout_ok = KPM_LAYOUT_MARKER_BEGIN in layouts and KPM_LAYOUT_MARKER_END in layouts
    except Exception:
        layout_ok = False
    return 'Patched' if info_ok and layout_ok and screen_status.startswith('current') else 'Not patched ({0})'.format(screen_status)


# -----------------------------------------------------------------------------
# v0.2.36 - repair rating-row call placement after 0.2.35 current-file refresh
# -----------------------------------------------------------------------------
def _validate_kpm_rating_row_placement_0236(text: str) -> None:
    """Require the single KPM row call to live inside Info_Meta's grouplist.

    XML well-formedness alone did not catch the 0.2.35 regression because an
    <include content=...> child placed beside <param>/<definition> is valid XML
    but invalid for Kodi's include schema. Validate the semantic ancestry too.
    """
    root = ET.fromstring(text)
    parent = {child: node for node in root.iter() for child in node}
    info_nodes = [node for node in root.findall('include') if node.get('name') == 'Info_Meta']
    if len(info_nodes) != 1:
        raise ValueError('Expected exactly one Info_Meta include; found {0}'.format(len(info_nodes)))
    info_node = info_nodes[0]
    definitions = [node for node in info_node.findall('definition')]
    if len(definitions) != 1:
        raise ValueError('Info_Meta must contain exactly one definition')
    definition = definitions[0]
    all_calls = [node for node in root.iter('include') if node.get('content') == 'KPM_Info_Meta_RatingRow']
    if len(all_calls) != 1:
        raise ValueError('Expected exactly one KPM rating-row call; found {0}'.format(len(all_calls)))
    call = all_calls[0]
    node = call
    inside_definition = False
    inside_grouplist = False
    while node in parent:
        node = parent[node]
        if node is definition:
            inside_definition = True
        if node.tag == 'control' and node.get('type') == 'grouplist':
            inside_grouplist = True
    if not inside_definition or not inside_grouplist:
        raise ValueError('KPM rating-row call is outside Info_Meta definition/grouplist')
    stray_direct = [node for node in info_node.findall('include') if node.get('content') == 'KPM_Info_Meta_RatingRow']
    if stray_direct:
        raise ValueError('KPM rating-row call is a direct child of Info_Meta')
    row_defs = [node for node in root.findall('include') if node.get('name') == 'KPM_Info_Meta_RatingRow']
    if len(row_defs) != 1:
        raise ValueError('Expected exactly one KPM rating-row definition; found {0}'.format(len(row_defs)))


def _insert_kpm_rating_row_call_0236(text: str) -> str:
    """Insert the row call at the native Ratings location inside the grouplist."""
    marker_re = re.compile(
        r'(?m)^(?P<indent>[ \t]*)<!--\s*KPM-AF3-NATIVE-META-DISABLED-[^>]*-->'
        r'[ \t\r\n]*(?:<!--\s*Ratings\s*-->[ \t\r\n]*)?'
    )
    match = marker_re.search(text)
    if not match:
        raise ValueError('Native AF3 rating marker not found; refusing unsafe row placement')
    indent = match.group('indent')
    replacement = (
        indent + '<!-- KPM-AF3-NATIVE-META-DISABLED-0186 -->\n' +
        indent + '<!-- Ratings -->\n' +
        _kpm_row_call_block().rstrip('\n') + '\n' + indent
    )
    return text[:match.start()] + replacement + text[match.end():]


def _patch_af3_info_xml_kpm_owned_0236(text: str):
    original = text
    text = CURRENT_KPM_ROW_CALL_RE.sub('\n', text)
    text = CURRENT_KPM_ROW_DEF_RE.sub('\n', text)
    text = _disable_native_af3_meta_conflicts(text)
    text = _insert_kpm_rating_row_call_0236(text)
    if '</includes>' not in text:
        raise ValueError('Includes_Info.xml root closing tag not found')
    text = text.replace('</includes>', _kpm_row_def_block() + '</includes>', 1)
    text, _ = _patch_kpm_steam_info_plot(text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    _validate_kpm_rating_row_placement_0236(text)
    return text, text != original


# The current-only 0.2.33+ wrapper calls this captured patcher at runtime.
# Repoint it after all legacy definitions have loaded.
_KPM_INFO_PATCH_CURRENT_0233 = _patch_af3_info_xml_kpm_owned_0236


_status_af3_unified_integration_0236_base = status_af3_unified_integration

def status_af3_unified_integration() -> str:
    try:
        info = read_text(af3_path('1080i', 'Includes_Info.xml'))
        _validate_kpm_rating_row_placement_0236(info)
    except Exception as exc:
        return 'Not patched (rating-row placement invalid: {0})'.format(exc)
    return _status_af3_unified_integration_0236_base()


# -----------------------------------------------------------------------------
# v0.2.37 - runtime-only AF3 repair, Combined Expanded rating, startup fallback
# -----------------------------------------------------------------------------
KPM_STEAM_PLOT_REPAIR_START_0237 = '<!-- KPM-AF3-STEAM-PLOT-START-0189 -->'
KPM_STEAM_PLOT_REPAIR_END_0237 = '<!-- KPM-AF3-STEAM-PLOT-END-0189 -->'
KPM_COMBINED_EPISODE_START_0237 = '<!-- KPM-AF3-COMBINED-EPISODE-RATING-START-0237 -->'
KPM_COMBINED_EPISODE_END_0237 = '<!-- KPM-AF3-COMBINED-EPISODE-RATING-END-0237 -->'
KPM_STARTUP_WEATHER_START_0237 = '<!-- KPM-AF3-STARTUP-WEATHER-FALLBACK-START-0237 -->'
KPM_STARTUP_WEATHER_END_0237 = '<!-- KPM-AF3-STARTUP-WEATHER-FALLBACK-END-0237 -->'
KPM_CURRENT_BACKUP_IMAGES_0237 = '.kpm-current-startup-weather.bak'


def _steam_plot_block_0237(indent: str = '        ') -> str:
    i0 = indent
    i1 = indent + '    '
    i2 = indent + '        '
    return '\n'.join([
        i0 + KPM_STEAM_PLOT_REPAIR_START_0237,
        i0 + '<control type="group">',
        i1 + '<visible>$PARAM[visible]</visible>',
        i1 + '<visible>![$PARAM[override]]</visible>',
        i1 + '<visible>!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</visible>',
        i1 + '<height>120</height>',
        i1 + '<control type="label">',
        i2 + '<top>0</top>',
        i2 + '<left>40</left>',
        i2 + '<height>40</height>',
        i2 + '<width>$PARAM[width]</width>',
        i2 + '<font>font_main_bold</font>',
        i2 + '<textcolor>$PARAM[colordiffuse]_90</textcolor>',
        i2 + '<label>$INFO[$PARAM[container]$PARAM[listitem].Property(tagline_display)]</label>',
        i2 + '<visible>!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(tagline_display))</visible>',
        i1 + '</control>',
        i1 + '<include content="Info_Plot_TextBox">',
        i2 + '<param name="label">$INFO[$PARAM[container]$PARAM[listitem].Plot]</param>',
        i2 + '<param name="colordiffuse">$PARAM[colordiffuse]</param>',
        i2 + '<param name="use_textbox">$PARAM[use_textbox]</param>',
        i2 + '<param name="height">80</param>',
        i2 + '<param name="width">$PARAM[width]</param>',
        i2 + '<param name="top">40</param>',
        i1 + '</include>',
        i0 + '</control>',
        i0 + KPM_STEAM_PLOT_REPAIR_END_0237,
    ]) + '\n'


def _steam_info_block_0237(indent: str = '                ') -> str:
    i0 = indent
    i1 = indent + '    '
    return '\n'.join([
        i0 + KPM_STEAM_INFO_START,
        i0 + '<include content="Info_Line_Pill_Text">',
        i1 + '<param name="colordiffuse">$PARAM[colordiffuse]</param>',
        i1 + '<param name="label">STEAM</param>',
        i1 + '<param name="width">auto</param>',
        i1 + '<param name="min_width">86</param>',
        i1 + '<param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))</param>',
        i0 + '</include>',
        i0 + '<include content="Info_Line_StarRating" condition="!Skin.HasSetting(InfoTags.DisableStarRating)">',
        i1 + '<param name="colordiffuse">$PARAM[colordiffuse]</param>',
        i1 + '<param name="rating">$PARAM[container]$PARAM[listitem].Rating</param>',
        i1 + '<param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].Rating)</param>',
        i0 + '</include>',
        i0 + '<include content="Info_Line_Label">',
        i1 + '<param name="colordiffuse">$PARAM[colordiffuse]</param>',
        i1 + '<param name="label">$INFO[$PARAM[container]$PARAM[listitem].Property(steam_review_desc)]</param>',
        i1 + '<param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(steam_review_desc)) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(steam_review_desc),N/A)</param>',
        i0 + '</include>',
        i0 + '<include content="Info_Line_Label">',
        i1 + '<param name="colordiffuse">$PARAM[colordiffuse]</param>',
        i1 + '<param name="label">$INFO[$PARAM[container]$PARAM[listitem].Year]</param>',
        i1 + '<param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].Year)</param>',
        i0 + '</include>',
        i0 + '<include content="Info_Line_Label">',
        i1 + '<param name="colordiffuse">$PARAM[colordiffuse]</param>',
        i1 + '<param name="label">$INFO[$PARAM[container]$PARAM[listitem].Property(age_rating_display)]</param>',
        i1 + '<param name="visible">!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(age_rating_display)) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(age_rating_display),N/A)</param>',
        i0 + '</include>',
        i0 + KPM_STEAM_INFO_END,
    ]) + '\n'


def _validate_steam_game_plot_0237(text: str) -> None:
    if text.count(KPM_STEAM_PLOT_REPAIR_START_0237) != 1 or text.count(KPM_STEAM_PLOT_REPAIR_END_0237) != 1:
        raise ValueError('Expected exactly one KPM Steam plot block')
    start, end, block = _find_xml_include_block_0187(text, 'Info_Plot_Main')
    if start < 0:
        raise ValueError('Info_Plot_Main include not found')
    if KPM_STEAM_PLOT_REPAIR_START_0237 not in block:
        raise ValueError('KPM Steam plot is outside Info_Plot_Main')
    required = (
        '!String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))',
        '$INFO[$PARAM[container]$PARAM[listitem].Plot]',
    )
    if not all(token in block for token in required):
        raise ValueError('KPM Steam plot lost platform visibility or plot label')


def _patch_kpm_steam_info_plot_0237(text: str):
    original = text
    text = re.sub(
        r'\s*<!--\s*KPM-AF3-STEAM-INFO-LINE-START-[^>]*-->.*?<!--\s*KPM-AF3-STEAM-INFO-LINE-END-[^>]*-->\s*',
        '\n', text, flags=re.I | re.S,
    )
    text = re.sub(
        r'\s*<!--\s*KPM-AF3-STEAM-PLOT-START-[^>]*-->.*?<!--\s*KPM-AF3-STEAM-PLOT-END-[^>]*-->\s*',
        '\n', text, flags=re.I | re.S,
    )
    text = re.sub(
        r'\s*<!--\s*Steam Game Info Line\s*-->.*?(?=\s*<!--\s*Info Pill\s*-->)',
        '\n', text, flags=re.I | re.S,
    )
    text = re.sub(
        r'\s*<!--\s*Steam Game Plot\s*-->\s*<control type="group">.*?</control>\s*',
        '\n', text, flags=re.I | re.S,
    )
    text = _apply_steam_game_visibility_guards(text)

    info_pill = re.search(r'(?m)^(?P<indent>[ \t]*)<!--\s*Info Pill\s*-->', text)
    if not info_pill:
        raise ValueError('Info Pill anchor not found; Steam info line was not changed')
    text = text[:info_pill.start()] + _steam_info_block_0237(info_pill.group('indent')) + text[info_pill.start():]

    start, end, block = _find_xml_include_block_0187(text, 'Info_Plot_Main')
    if start < 0:
        raise ValueError('Info_Plot_Main anchor not found; Steam plot was not changed')
    movie = re.search(r'(?m)^(?P<indent>[ \t]*)<!--\s*Movie\s*-->', block)
    if not movie:
        raise ValueError('Movie anchor inside Info_Plot_Main not found')
    new_block = block[:movie.start()] + _steam_plot_block_0237(movie.group('indent')) + block[movie.start():]
    text = text[:start] + new_block + text[end:]
    text = re.sub(r'\n{3,}', '\n\n', text)
    ET.fromstring(text)
    _validate_steam_game_plot_0237(text)
    return text, text != original


def _combined_episode_rating_block_0237(indent: str) -> str:
    i0 = indent
    i1 = indent + '    '
    return '\n'.join([
        i0 + KPM_COMBINED_EPISODE_START_0237,
        i0 + '<control type="grouplist">',
        i1 + '<right>150</right>',
        i1 + '<width>360</width>',
        i1 + '<height>40</height>',
        i1 + '<orientation>horizontal</orientation>',
        i1 + '<align>right</align>',
        i1 + '<itemgap>7</itemgap>',
        i1 + '<visible>Control.IsVisible(528) + String.IsEqual(ListItem.DBType,episode)</visible>',
        i1 + '<control type="image">',
        i1 + '    <width>22</width><height>22</height><centertop>50%</centertop><aspectratio>keep</aspectratio>',
        i1 + '    <texture colordiffuse="white">flags/star10.png</texture>',
        i1 + '    <visible>!String.IsEmpty(ListItem.Rating(imdb)) | !String.IsEmpty(ListItem.Rating(tmdb))</visible>',
        i1 + '</control>',
        i1 + '<control type="label">',
        i1 + '    <width>48</width><font>font_mini</font><align>left</align>',
        i1 + '    <include condition="$PARAM[selected]">Color_SelectedText</include><textcolor>main_fg_70</textcolor>',
        i1 + '    <label>$INFO[ListItem.Rating(imdb)]</label><visible>!String.IsEmpty(ListItem.Rating(imdb))</visible>',
        i1 + '</control>',
        i1 + '<control type="label">',
        i1 + '    <width>48</width><font>font_mini</font><align>left</align>',
        i1 + '    <include condition="$PARAM[selected]">Color_SelectedText</include><textcolor>main_fg_70</textcolor>',
        i1 + '    <label>$INFO[ListItem.Rating(tmdb)]</label><visible>String.IsEmpty(ListItem.Rating(imdb)) + !String.IsEmpty(ListItem.Rating(tmdb))</visible>',
        i1 + '</control>',
        i1 + '<control type="label">',
        i1 + '    <width>12</width><font>font_mini</font><align>center</align>',
        i1 + '    <include condition="$PARAM[selected]">Color_SelectedText</include><textcolor>main_fg_70</textcolor>',
        i1 + '    <label>•</label><visible>!String.IsEmpty(ListItem.Rating(imdb)) | !String.IsEmpty(ListItem.Rating(tmdb))</visible>',
        i1 + '</control>',
        i1 + '<control type="label">',
        i1 + '    <width>105</width><font>font_mini</font><align>right</align>',
        i1 + '    <include condition="$PARAM[selected]">Color_SelectedText</include><textcolor>main_fg_70</textcolor>',
        i1 + '    <label>$VAR[Label_MediaList_Details_LeftLabel]</label>',
        i1 + '</control>',
        i0 + '</control>',
        i0 + KPM_COMBINED_EPISODE_END_0237,
    ]) + '\n'


def _patch_combined_expanded_episode_rating_0237(text: str):
    original = text
    start_count = text.count(KPM_COMBINED_EPISODE_START_0237)
    end_count = text.count(KPM_COMBINED_EPISODE_END_0237)
    if start_count or end_count:
        if start_count != 1 or end_count != 1:
            raise ValueError('Partial Combined Expanded episode rating patch detected')
        required = (
            '<texture colordiffuse="white">flags/star10.png</texture>',
            '$INFO[ListItem.Rating(imdb)]',
            '$INFO[ListItem.Rating(tmdb)]',
            '<scroll>$PARAM[selected]</scroll>',
            'Control.IsVisible(528) + String.IsEqual(ListItem.DBType,episode)',
        )
        if not all(token in text for token in required):
            raise ValueError('Combined Expanded episode rating patch is incomplete')
        return text, False
    text = re.sub(
        r'\s*<!--\s*KPM-AF3-COMBINED-EPISODE-RATING-START-0237\s*-->.*?<!--\s*KPM-AF3-COMBINED-EPISODE-RATING-END-0237\s*-->\s*',
        '\n', text, flags=re.I | re.S,
    )
    start, end, block = _find_xml_include_block_0187(text, 'Layout_MediaList_Detailed')
    if start < 0:
        raise ValueError('Layout_MediaList_Detailed include not found')

    # Focused Combined Expanded episode titles scroll; unfocused titles remain truncated.
    title_re = re.compile(
        r'(?P<indent>[ \t]*)<control type="label">\s*'
        r'<label>\$INFO\[ListItem\.Label\]</label>\s*'
        r'<font>font_main_bold</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_90</textcolor>\s*'
        r'<right>320</right>\s*'
        r'</control>', re.S,
    )
    match = title_re.search(block)
    if not match:
        raise ValueError('Combined Expanded title label anchor not found')
    indent = match.group('indent')
    title = '\n'.join([
        indent + '<control type="label">',
        indent + '    <label>$INFO[ListItem.Label]</label>',
        indent + '    <font>font_main_bold</font>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_90</textcolor>',
        indent + '    <right>320</right>',
        indent + '    <visible>![Control.IsVisible(528) + String.IsEqual(ListItem.DBType,episode)]</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <label>$INFO[ListItem.Label]</label>',
        indent + '    <font>font_main_bold</font>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_90</textcolor>',
        indent + '    <right>520</right>',
        indent + '    <scroll>$PARAM[selected]</scroll>',
        indent + '    <scrollsuffix>  •  </scrollsuffix>',
        indent + '    <visible>Control.IsVisible(528) + String.IsEqual(ListItem.DBType,episode)</visible>',
        indent + '</control>',
    ])
    block = block[:match.start()] + title + block[match.end():]

    date_re = re.compile(
        r'(?P<indent>[ \t]*)<control type="label">\s*'
        r'<right>150</right>\s*'
        r'<font>font_mini</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_70</textcolor>\s*'
        r'<label>\$VAR\[Label_MediaList_Details_LeftLabel\]</label>\s*'
        r'<align>right</align>\s*'
        r'</control>', re.S,
    )
    match = date_re.search(block)
    if not match:
        raise ValueError('Combined Expanded date label anchor not found')
    indent = match.group('indent')
    date_native = match.group(0).replace(
        '</control>',
        '    <visible>![Control.IsVisible(528) + String.IsEqual(ListItem.DBType,episode)]</visible>\n' + indent + '</control>',
        1,
    )
    replacement = _combined_episode_rating_block_0237(indent) + date_native
    block = block[:match.start()] + replacement + block[match.end():]
    text = text[:start] + block + text[end:]
    text = re.sub(r'\n{3,}', '\n\n', text)
    ET.fromstring(text)
    if text.count(KPM_COMBINED_EPISODE_START_0237) != 1:
        raise ValueError('Combined Expanded rating block count is not one')
    return text, text != original


def _patch_af3_layouts_0237(text: str):
    text, changed_base = _KPM_LAYOUT_PATCH_CURRENT_0233_BASE_0237(text)
    text, changed_rating = _patch_combined_expanded_episode_rating_0237(text)
    return text, bool(changed_base or changed_rating)


def _patch_startup_weather_fallback_text_0237(text: str):
    original = text
    start_count = text.count(KPM_STARTUP_WEATHER_START_0237)
    end_count = text.count(KPM_STARTUP_WEATHER_END_0237)
    if start_count or end_count:
        if start_count != 1 or end_count != 1:
            raise ValueError('Partial startup weather fallback patch detected')
        required = (
            'Window(Home).Property(KPM.AF3StartupFallbackPath)',
            '<variable name="Image_StartUp">',
        )
        if not all(token in text for token in required):
            raise ValueError('Startup weather fallback patch is incomplete')
        if ('/' + 'all' + '/') in text.lower():
            raise ValueError('Forbidden all weather path detected')
        return text, False
    text = re.sub(
        r'\s*<!--\s*KPM-AF3-STARTUP-WEATHER-FALLBACK-START-0237\s*-->.*?<!--\s*KPM-AF3-STARTUP-WEATHER-FALLBACK-END-0237\s*-->\s*',
        '\n', text, flags=re.I | re.S,
    )
    block = extract_variable_block(text, 'Image_StartUp')
    if not block:
        raise ValueError('Image_StartUp variable not found')
    first_value = re.search(r'(?m)^(?P<indent>[ \t]*)<value\b', block)
    if not first_value:
        raise ValueError('Image_StartUp has no value anchor')
    indent = first_value.group('indent')
    fallback = '\n'.join([
        indent + KPM_STARTUP_WEATHER_START_0237,
        indent + '<value condition="!String.IsEmpty(Window(Home).Property(KPM.AF3StartupFallbackPath)) + [String.IsEmpty(Skin.String(Startup.ImageFolder)) | Skin.String(Startup.ImageFolder,special://skin/extras/backgrounds/launch/)]">$INFO[Window(Home).Property(KPM.AF3StartupFallbackPath)]</value>',
        indent + KPM_STARTUP_WEATHER_END_0237,
        '',
    ])
    new_block = block[:first_value.start()] + fallback + block[first_value.start():]
    text = text.replace(block, new_block, 1)
    ET.fromstring(text)
    if text.count(KPM_STARTUP_WEATHER_START_0237) != 1:
        raise ValueError('Startup weather fallback value count is not one')
    if ('/' + 'all' + '/') in text.lower():
        raise ValueError('Forbidden all weather path detected')
    return text, text != original


def _patch_af3_startup_weather_xml_0237() -> bool:
    path = af3_path('1080i', 'Includes_Images.xml')
    if not os.path.exists(path):
        return False
    original = read_text(path)
    backup = path + KPM_CURRENT_BACKUP_IMAGES_0237
    if not os.path.exists(backup):
        write_text(backup, original)
    updated, changed = _patch_startup_weather_fallback_text_0237(original)
    if updated != original:
        write_text(path, updated)
        return True
    return bool(changed)


def _remove_af3_startup_weather_xml_0237() -> bool:
    path = af3_path('1080i', 'Includes_Images.xml')
    if not os.path.exists(path):
        return False
    original = read_text(path)
    updated = re.sub(
        r'\s*<!--\s*KPM-AF3-STARTUP-WEATHER-FALLBACK-START-0237\s*-->.*?<!--\s*KPM-AF3-STARTUP-WEATHER-FALLBACK-END-0237\s*-->\s*',
        '\n', original, flags=re.I | re.S,
    )
    if updated != original:
        ET.fromstring(updated)
        write_text(path, updated)
        return True
    return False


def _patch_af3_info_xml_kpm_owned_0237(text: str):
    original = text
    text = CURRENT_KPM_ROW_CALL_RE.sub('\n', text)
    text = CURRENT_KPM_ROW_DEF_RE.sub('\n', text)
    text = _disable_native_af3_meta_conflicts(text)
    text = _insert_kpm_rating_row_call_0236(text)
    if '</includes>' not in text:
        raise ValueError('Includes_Info.xml root closing tag not found')
    text = text.replace('</includes>', _kpm_row_def_block() + '</includes>', 1)
    text, _ = _patch_kpm_steam_info_plot_0237(text)
    text = re.sub(r'\n{3,}', '\n\n', text)
    ET.fromstring(text)
    _validate_kpm_rating_row_placement_0236(text)
    _validate_steam_game_plot_0237(text)
    return text, text != original


# Capture the prior current-layout patcher once, then add only the episode overlay.
_KPM_LAYOUT_PATCH_CURRENT_0233_BASE_0237 = _KPM_LAYOUT_PATCH_CURRENT_0233
_KPM_LAYOUT_PATCH_CURRENT_0233 = _patch_af3_layouts_0237
_KPM_INFO_PATCH_CURRENT_0233 = _patch_af3_info_xml_kpm_owned_0237


_apply_af3_unified_integration_0237_base = apply_af3_unified_integration

def apply_af3_unified_integration() -> Result:
    result = _apply_af3_unified_integration_0237_base()
    if result.status not in ('Patched', 'Skipped') or result.detail.startswith('Includes_Info.xml not found'):
        return result
    try:
        weather_changed = _patch_af3_startup_weather_xml_0237()
    except Exception as exc:
        log('Startup weather fallback patch refused: {0}'.format(exc))
        return Result('AF3 Unified Integration', 'Skipped', 'Core patch result: {0}\nStartup fallback refused: {1}'.format(result.detail, exc))
    if weather_changed:
        if result.status != 'Patched':
            _reload_skin_after_patch()
        return Result('AF3 Unified Integration', 'Patched', result.detail + ' Startup weather fallback value added by partial XML patch.')
    return result


_remove_af3_unified_integration_0237_base = remove_af3_unified_integration

def remove_af3_unified_integration() -> Result:
    weather_changed = _remove_af3_startup_weather_xml_0237()
    result = _remove_af3_unified_integration_0237_base()
    if weather_changed and result.status != 'Removed':
        _reload_skin_after_patch()
        return Result('AF3 Unified Integration', 'Removed', 'Startup weather fallback value removed.')
    return result


# -----------------------------------------------------------------------------
# v0.2.38 - silent full-integration startup refresh and flat episode metadata
# -----------------------------------------------------------------------------
FULL_INTEGRATION_STATE_ID_0238 = 'full_kpm_integration'
FULL_INTEGRATION_COMPONENTS_0238 = (
    'af3_unified_integration',
    'af3_poster_ratio_2_3',
    'upnext_episode_thumb',
    'shw_random_movies_tvshows',
    'vfs_pause_ratings',
    'reliable_studio_logos',
)
KPM_COMBINED_EPISODE_TITLE_START_0238 = '<!-- KPM-AF3-COMBINED-EPISODE-TITLE-START-0238 -->'
KPM_COMBINED_EPISODE_TITLE_END_0238 = '<!-- KPM-AF3-COMBINED-EPISODE-TITLE-END-0238 -->'
KPM_COMBINED_EPISODE_START_0238 = '<!-- KPM-AF3-COMBINED-EPISODE-RATING-START-0238 -->'
KPM_COMBINED_EPISODE_END_0238 = '<!-- KPM-AF3-COMBINED-EPISODE-RATING-END-0238 -->'
KPM_COMBINED_EPISODE_CONDITION_0238 = 'Control.IsVisible(528) + String.IsEqual(ListItem.DBType,episode)'


def _combined_episode_native_title_0238(indent: str) -> str:
    return '\n'.join([
        indent + '<control type="label">',
        indent + '    <label>$INFO[ListItem.Label]</label>',
        indent + '    <font>font_main_bold</font>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_90</textcolor>',
        indent + '    <right>320</right>',
        indent + '</control>',
    ])


def _combined_episode_title_block_0238(indent: str) -> str:
    condition = KPM_COMBINED_EPISODE_CONDITION_0238
    return '\n'.join([
        indent + KPM_COMBINED_EPISODE_TITLE_START_0238,
        indent + '<control type="label">',
        indent + '    <label>$INFO[ListItem.Label]</label>',
        indent + '    <font>font_main_bold</font>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_90</textcolor>',
        indent + '    <right>320</right>',
        indent + '    <visible>![' + condition + ']</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <label>$INFO[ListItem.Label]</label>',
        indent + '    <font>font_main_bold</font>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_90</textcolor>',
        indent + '    <right>520</right>',
        indent + '    <scroll>$PARAM[selected]</scroll>',
        indent + '    <scrollsuffix>  •  </scrollsuffix>',
        indent + '    <visible>' + condition + '</visible>',
        indent + '</control>',
        indent + KPM_COMBINED_EPISODE_TITLE_END_0238,
    ])


def _combined_episode_flat_rating_block_0238(indent: str) -> str:
    condition = KPM_COMBINED_EPISODE_CONDITION_0238
    has_rating = '!String.IsEmpty(ListItem.Rating(imdb)) | !String.IsEmpty(ListItem.Rating(tmdb))'
    return '\n'.join([
        indent + KPM_COMBINED_EPISODE_START_0238,
        indent + '<control type="image">',
        indent + '    <right>333</right>',
        indent + '    <width>22</width>',
        indent + '    <height>22</height>',
        indent + '    <centertop>50%</centertop>',
        indent + '    <aspectratio>keep</aspectratio>',
        indent + '    <texture colordiffuse="white">flags/star10.png</texture>',
        indent + '    <visible>' + condition + ' + [' + has_rating + ']</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <right>278</right>',
        indent + '    <width>48</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>right</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>$INFO[ListItem.Rating(imdb)]</label>',
        indent + '    <visible>' + condition + ' + !String.IsEmpty(ListItem.Rating(imdb))</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <right>278</right>',
        indent + '    <width>48</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>right</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>$INFO[ListItem.Rating(tmdb)]</label>',
        indent + '    <visible>' + condition + ' + String.IsEmpty(ListItem.Rating(imdb)) + !String.IsEmpty(ListItem.Rating(tmdb))</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <right>258</right>',
        indent + '    <width>12</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>center</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>•</label>',
        indent + '    <visible>' + condition + ' + [' + has_rating + ']</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <right>150</right>',
        indent + '    <width>105</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>right</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>$VAR[Label_MediaList_Details_LeftLabel]</label>',
        indent + '    <visible>' + condition + '</visible>',
        indent + '</control>',
        indent + KPM_COMBINED_EPISODE_END_0238,
    ]) + '\n'


def _strip_combined_episode_patch_0238(block: str) -> str:
    # Remove current and broken 0.2.37 marked blocks only.
    title_0238 = re.compile(
        r'(?ms)^(?P<indent>[ \t]*)<!--\s*KPM-AF3-COMBINED-EPISODE-TITLE-START-0238\s*-->.*?'
        r'^[ \t]*<!--\s*KPM-AF3-COMBINED-EPISODE-TITLE-END-0238\s*-->[ \t]*(?:\r?\n)?'
    )
    block = title_0238.sub(
        lambda match: _combined_episode_native_title_0238(match.group('indent')) + '\n',
        block,
        count=1,
    )
    block = re.sub(
        r'(?ms)^[ \t]*<!--\s*KPM-AF3-COMBINED-EPISODE-RATING-START-0238\s*-->.*?^[ \t]*<!--\s*KPM-AF3-COMBINED-EPISODE-RATING-END-0238\s*-->[ \t]*(?:\r?\n)?',
        '', block,
    )
    block = re.sub(
        r'(?ms)^[ \t]*<!--\s*KPM-AF3-COMBINED-EPISODE-RATING-START-0237\s*-->.*?^[ \t]*<!--\s*KPM-AF3-COMBINED-EPISODE-RATING-END-0237\s*-->[ \t]*(?:\r?\n)?',
        '', block,
    )

    # Restore the original single title label from the 0.2.37 two-label form.
    old_title_pair = re.compile(
        r'(?P<indent>[ \t]*)<control type="label">\s*'
        r'<label>\$INFO\[ListItem\.Label\]</label>\s*'
        r'<font>font_main_bold</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_90</textcolor>\s*'
        r'<right>320</right>\s*'
        r'<visible>!\[Control\.IsVisible\(528\) \+ String\.IsEqual\(ListItem\.DBType,episode\)\]</visible>\s*'
        r'</control>\s*'
        r'<control type="label">\s*'
        r'<label>\$INFO\[ListItem\.Label\]</label>\s*'
        r'<font>font_main_bold</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_90</textcolor>\s*'
        r'<right>520</right>\s*'
        r'<scroll>\$PARAM\[selected\]</scroll>\s*'
        r'<scrollsuffix>\s*•\s*</scrollsuffix>\s*'
        r'<visible>Control\.IsVisible\(528\) \+ String\.IsEqual\(ListItem\.DBType,episode\)</visible>\s*'
        r'</control>',
        re.S,
    )
    block = old_title_pair.sub(
        lambda match: _combined_episode_native_title_0238(match.group('indent')),
        block,
        count=1,
    )

    # Restore the native date label if 0.2.37 left its Combined-episode guard.
    date_label = re.compile(
        r'(?P<label>(?P<indent>[ \t]*)<control type="label">\s*'
        r'<right>150</right>\s*'
        r'<font>font_mini</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_70</textcolor>\s*'
        r'<label>\$VAR\[Label_MediaList_Details_LeftLabel\]</label>\s*'
        r'<align>right</align>\s*'
        r'(?:<visible>!\[Control\.IsVisible\(528\) \+ String\.IsEqual\(ListItem\.DBType,episode\)\]</visible>\s*)?'
        r'</control>)',
        re.S,
    )
    match = date_label.search(block)
    if match:
        cleaned = re.sub(
            r'\s*<visible>!\[Control\.IsVisible\(528\) \+ String\.IsEqual\(ListItem\.DBType,episode\)\]</visible>',
            '', match.group('label'), count=1,
        )
        block = block[:match.start()] + cleaned + block[match.end():]
    return block


def _validate_combined_episode_rating_0238(text: str) -> None:
    if text.count(KPM_COMBINED_EPISODE_TITLE_START_0238) != 1 or text.count(KPM_COMBINED_EPISODE_TITLE_END_0238) != 1:
        raise ValueError('Combined Expanded title patch 0238 is missing or duplicated')
    if text.count(KPM_COMBINED_EPISODE_START_0238) != 1 or text.count(KPM_COMBINED_EPISODE_END_0238) != 1:
        raise ValueError('Combined Expanded rating patch 0238 is missing or duplicated')
    if 'KPM-AF3-COMBINED-EPISODE-RATING-START-0237' in text:
        raise ValueError('Broken 0.2.37 Combined Expanded block remains')
    start, end, layout = _find_xml_include_block_0187(text, 'Layout_MediaList_Detailed')
    if start < 0:
        raise ValueError('Layout_MediaList_Detailed include not found')
    marker_start = layout.find(KPM_COMBINED_EPISODE_START_0238)
    marker_end = layout.find(KPM_COMBINED_EPISODE_END_0238)
    if marker_start < 0 or marker_end < marker_start:
        raise ValueError('Combined Expanded rating controls are outside Layout_MediaList_Detailed')
    marked = layout[marker_start:marker_end]
    if '<control type="grouplist">' in marked:
        raise ValueError('Combined Expanded rating still uses unsupported grouplist')
    required = (
        '<control type="image">',
        '<texture colordiffuse="white">flags/star10.png</texture>',
        '$INFO[ListItem.Rating(imdb)]',
        '$INFO[ListItem.Rating(tmdb)]',
        '$VAR[Label_MediaList_Details_LeftLabel]',
        '<scroll>$PARAM[selected]</scroll>',
        KPM_COMBINED_EPISODE_CONDITION_0238,
    )
    if not all(token in layout for token in required):
        raise ValueError('Combined Expanded flat controls are incomplete')
    ET.fromstring(text)


def _patch_combined_expanded_episode_rating_0238(text: str):
    original = text
    start, end, block = _find_xml_include_block_0187(text, 'Layout_MediaList_Detailed')
    if start < 0:
        raise ValueError('Layout_MediaList_Detailed include not found')
    block = _strip_combined_episode_patch_0238(block)

    title_re = re.compile(
        r'(?P<indent>[ \t]*)<control type="label">\s*'
        r'<label>\$INFO\[ListItem\.Label\]</label>\s*'
        r'<font>font_main_bold</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_90</textcolor>\s*'
        r'<right>320</right>\s*'
        r'</control>', re.S,
    )
    title_match = title_re.search(block)
    if not title_match:
        raise ValueError('Combined Expanded native title label anchor not found')
    block = block[:title_match.start()] + _combined_episode_title_block_0238(title_match.group('indent')) + block[title_match.end():]

    date_re = re.compile(
        r'(?P<indent>[ \t]*)<control type="label">\s*'
        r'<right>150</right>\s*'
        r'<font>font_mini</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_70</textcolor>\s*'
        r'<label>\$VAR\[Label_MediaList_Details_LeftLabel\]</label>\s*'
        r'<align>right</align>\s*'
        r'</control>', re.S,
    )
    date_match = date_re.search(block)
    if not date_match:
        raise ValueError('Combined Expanded native date label anchor not found')
    indent = date_match.group('indent')
    native_date = date_match.group(0).replace(
        '</control>',
        '    <visible>![' + KPM_COMBINED_EPISODE_CONDITION_0238 + ']</visible>\n' + indent + '</control>',
        1,
    )
    replacement = _combined_episode_flat_rating_block_0238(indent) + native_date
    block = block[:date_match.start()] + replacement + block[date_match.end():]
    text = text[:start] + block + text[end:]
    text = re.sub(r'\n{3,}', '\n\n', text)
    _validate_combined_episode_rating_0238(text)
    return text, text != original


def _patch_af3_layouts_0238(text: str):
    # Use the pre-0.2.37 current-layout patcher so the broken grouplist is never rebuilt.
    text, changed_base = _KPM_LAYOUT_PATCH_CURRENT_0233_BASE_0237(text)
    text, changed_rating = _patch_combined_expanded_episode_rating_0238(text)
    return text, bool(changed_base or changed_rating)


_KPM_LAYOUT_PATCH_CURRENT_0233 = _patch_af3_layouts_0238

_status_af3_unified_integration_0238_base = status_af3_unified_integration

def status_af3_unified_integration() -> str:
    try:
        layouts = read_text(af3_path('1080i', 'Includes_Layouts.xml'))
        _validate_combined_episode_rating_0238(layouts)
    except Exception as exc:
        return 'Not patched (Combined Expanded 0238 invalid: {0})'.format(exc)
    return _status_af3_unified_integration_0238_base()


def full_integration_startup_enabled_0238() -> bool:
    if os.path.exists(state_file(FULL_INTEGRATION_STATE_ID_0238)):
        return True
    # Migration path for installations that used Apply Full Integration before
    # the dedicated master-state file existed. Resetting XML does not remove
    # these component state files.
    return all(os.path.exists(state_file(patch_id)) for patch_id in FULL_INTEGRATION_COMPONENTS_0238)


def apply_full_integration_core_0238(mark_enabled: bool = False) -> List[Result]:
    global _KPM_BATCH_PATCH_MODE, _KPM_BATCH_RELOAD_NEEDED
    entries = [
        ('af3_unified_integration', status_af3_unified_integration, apply_af3_unified_integration),
        ('af3_poster_ratio_2_3', status_af3_poster_ratio_2_3, patch_af3_poster_ratio_2_3),
        ('upnext_episode_thumb', status_upnext, patch_upnext),
        ('shw_random_movies_tvshows', status_shw, lambda: patch_shw(100)),
        ('vfs_pause_ratings', status_vfs_pause_ratings, patch_vfs_pause_ratings),
        ('reliable_studio_logos', status_reliable_studio_logos, patch_reliable_studio_logos),
    ]
    results: List[Result] = []
    _KPM_BATCH_PATCH_MODE = True
    _KPM_BATCH_RELOAD_NEEDED = False
    try:
        for patch_id, status_func, patch_func in entries:
            try:
                results.append(_apply_patch_smart(patch_id, status_func, patch_func))
            except Exception as exc:
                log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
                results.append(Result(patch_title(patch_id, patch_id), 'Error', str(exc)))
    finally:
        _KPM_BATCH_PATCH_MODE = False
        _finish_deferred_reload()
    if mark_enabled:
        save_state(FULL_INTEGRATION_STATE_ID_0238, {
            'enabled': True,
            'components': list(FULL_INTEGRATION_COMPONENTS_0238),
            'owner': 'KPM',
        })
    return results


def apply_all() -> None:
    if not yesno(ADDON_NAME, 'Apply Full KPM Integration now?\n\nThis runs all KPM visual/XML patches in the correct order:\n- AF3 Unified Integration\n- AF3 Poster Ratio 2:3\n- Episode Thumb Up Next\n- Movies + Shows Screensaver\n- Pause Shows Full OSD\n- Reliable Studio Logos\n- Cinema Pre-roll Fonts\n\nRule: status is checked first. Current patches are skipped. Partial current patches are normalized only inside their own marked or anchored blocks.'):
        return
    results = apply_full_integration_core_0238(mark_enabled=True)
    notify('Apply Full KPM Integration finished')
    textviewer(ADDON_NAME + ' - Results', format_results(results))


def remove_all() -> None:
    global _KPM_BATCH_PATCH_MODE, _KPM_BATCH_RELOAD_NEEDED
    if not yesno(ADDON_NAME, 'Remove Full KPM Integration now?\n\nThis removes KPM visual/XML patches where possible:\n- AF3 Unified Integration\n- AF3 Poster Ratio 2:3\n- Episode Thumb Up Next\n- Movies + Shows Screensaver\n- Pause Shows Full OSD\n- Reliable Studio Logos\n- Cinema Pre-roll Fonts\n\nRule: status is checked first. Missing/not-installed patches are skipped. Installed patches are removed by marker/block restore only.'):
        return
    entries = [
        ('af3_unified_integration', status_af3_unified_integration, remove_af3_unified_integration),
        ('af3_poster_ratio_2_3', status_af3_poster_ratio_2_3, remove_af3_poster_ratio_2_3),
        ('upnext_episode_thumb', status_upnext, remove_upnext),
        ('shw_random_movies_tvshows', status_shw, remove_shw),
        ('vfs_pause_ratings', status_vfs_pause_ratings, remove_vfs_pause_ratings),
        ('reliable_studio_logos', status_reliable_studio_logos, remove_reliable_studio_logos),
    ]
    results: List[Result] = []
    _KPM_BATCH_PATCH_MODE = True
    _KPM_BATCH_RELOAD_NEEDED = False
    try:
        for patch_id, status_func, remove_func in entries:
            try:
                results.append(_remove_patch_smart(patch_id, status_func, remove_func))
            except Exception as exc:
                log(traceback.format_exc(), xbmc.LOGERROR if xbmc else None)
                results.append(Result(patch_title(patch_id, patch_id), 'Error', str(exc)))
    finally:
        _KPM_BATCH_PATCH_MODE = False
        _finish_deferred_reload()
    delete_state(FULL_INTEGRATION_STATE_ID_0238)
    # Removal is also the explicit opt-out from startup restoration. Clear all
    # legacy component-state files even when their XML markers were already
    # reset and the smart remover therefore skipped them.
    for patch_id in FULL_INTEGRATION_COMPONENTS_0238:
        delete_state(patch_id)
    notify('Remove Full KPM Integration finished')
    textviewer(ADDON_NAME + ' - Results', format_results(results))


# v0.2.39 - native AF3 episode star, year-only date, AF3-style title behavior
KPM_COMBINED_EPISODE_TITLE_START_0239 = '<!-- KPM-AF3-COMBINED-EPISODE-TITLE-START-0239 -->'
KPM_COMBINED_EPISODE_TITLE_END_0239 = '<!-- KPM-AF3-COMBINED-EPISODE-TITLE-END-0239 -->'
KPM_COMBINED_EPISODE_START_0239 = '<!-- KPM-AF3-COMBINED-EPISODE-RATING-START-0239 -->'
KPM_COMBINED_EPISODE_END_0239 = '<!-- KPM-AF3-COMBINED-EPISODE-RATING-END-0239 -->'
KPM_COMBINED_EPISODE_CONDITION_0239 = 'Control.IsVisible(528) + String.IsEqual(ListItem.DBType,episode)'


def _combined_episode_title_block_0239(indent: str) -> str:
    """Keep the native AF3 label style; reserve only the agreed right-side metadata width."""
    condition = KPM_COMBINED_EPISODE_CONDITION_0239
    return '\n'.join([
        indent + KPM_COMBINED_EPISODE_TITLE_START_0239,
        indent + '<control type="label">',
        indent + '    <label>$INFO[ListItem.Label]</label>',
        indent + '    <font>font_main_bold</font>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_90</textcolor>',
        indent + '    <right>320</right>',
        indent + '    <visible>![' + condition + ']</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <label>$INFO[ListItem.Label]</label>',
        indent + '    <font>font_main_bold</font>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_90</textcolor>',
        indent + '    <right>400</right>',
        indent + '    <visible>' + condition + '</visible>',
        indent + '</control>',
        indent + KPM_COMBINED_EPISODE_TITLE_END_0239,
    ])


def _combined_episode_native_rating_block_0239(indent: str) -> str:
    condition = KPM_COMBINED_EPISODE_CONDITION_0239
    has_rating = '!String.IsEmpty(ListItem.Rating(imdb)) | !String.IsEmpty(ListItem.Rating(tmdb))'
    has_year = '!String.IsEmpty(ListItem.Year)'
    return '\n'.join([
        indent + KPM_COMBINED_EPISODE_START_0239,
        indent + '<include content="Object_StarRating">',
        indent + '    <param name="selected">$PARAM[selected]</param>',
        indent + '    <centertop>50%</centertop>',
        indent + '    <centerright>324</centerright>',
        indent + '    <visible>' + condition + ' + [' + has_rating + ']</visible>',
        indent + '</include>',
        indent + '<control type="label">',
        indent + '    <right>244</right>',
        indent + '    <width>48</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>right</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>$INFO[ListItem.Rating(imdb)]</label>',
        indent + '    <visible>' + condition + ' + !String.IsEmpty(ListItem.Rating(imdb))</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <right>244</right>',
        indent + '    <width>48</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>right</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>$INFO[ListItem.Rating(tmdb)]</label>',
        indent + '    <visible>' + condition + ' + String.IsEmpty(ListItem.Rating(imdb)) + !String.IsEmpty(ListItem.Rating(tmdb))</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <right>224</right>',
        indent + '    <width>12</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>center</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>•</label>',
        indent + '    <visible>' + condition + ' + [' + has_rating + '] + ' + has_year + '</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <right>164</right>',
        indent + '    <width>52</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>right</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>$INFO[ListItem.Year]</label>',
        indent + '    <visible>' + condition + '</visible>',
        indent + '</control>',
        indent + KPM_COMBINED_EPISODE_END_0239,
    ]) + '\n'


def _strip_combined_episode_patch_0239(block: str) -> str:
    # Normalize a current 0.2.39 block back to the native AF3 anchors first.
    title_0239 = re.compile(
        r'(?ms)^(?P<indent>[ \t]*)<!--\s*KPM-AF3-COMBINED-EPISODE-TITLE-START-0239\s*-->.*?'
        r'^[ \t]*<!--\s*KPM-AF3-COMBINED-EPISODE-TITLE-END-0239\s*-->[ \t]*(?:\r?\n)?'
    )
    block = title_0239.sub(
        lambda match: _combined_episode_native_title_0238(match.group('indent')) + '\n',
        block,
        count=1,
    )
    block = re.sub(
        r'(?ms)^[ \t]*<!--\s*KPM-AF3-COMBINED-EPISODE-RATING-START-0239\s*-->.*?'
        r'^[ \t]*<!--\s*KPM-AF3-COMBINED-EPISODE-RATING-END-0239\s*-->[ \t]*(?:\r?\n)?',
        '', block,
    )
    # Then remove/repair the 0.2.38 and 0.2.37 forms using the proven normalizer.
    return _strip_combined_episode_patch_0238(block)


def _validate_combined_episode_rating_0239(text: str) -> None:
    if text.count(KPM_COMBINED_EPISODE_TITLE_START_0239) != 1 or text.count(KPM_COMBINED_EPISODE_TITLE_END_0239) != 1:
        raise ValueError('Combined Expanded title patch 0239 is missing or duplicated')
    if text.count(KPM_COMBINED_EPISODE_START_0239) != 1 or text.count(KPM_COMBINED_EPISODE_END_0239) != 1:
        raise ValueError('Combined Expanded rating patch 0239 is missing or duplicated')
    for old in (
        'KPM-AF3-COMBINED-EPISODE-RATING-START-0237',
        'KPM-AF3-COMBINED-EPISODE-RATING-START-0238',
        'KPM-AF3-COMBINED-EPISODE-TITLE-START-0238',
    ):
        if old in text:
            raise ValueError('Older Combined Expanded block remains: ' + old)
    start, end, layout = _find_xml_include_block_0187(text, 'Layout_MediaList_Detailed')
    if start < 0:
        raise ValueError('Layout_MediaList_Detailed include not found')
    marker_start = layout.find(KPM_COMBINED_EPISODE_START_0239)
    marker_end = layout.find(KPM_COMBINED_EPISODE_END_0239)
    if marker_start < 0 or marker_end < marker_start:
        raise ValueError('Combined Expanded rating controls are outside Layout_MediaList_Detailed')
    marked = layout[marker_start:marker_end]
    if '<control type="grouplist">' in marked:
        raise ValueError('Combined Expanded rating still uses unsupported grouplist')
    if '<texture colordiffuse="white">flags/star10.png</texture>' in marked:
        raise ValueError('Manual KPM star remains; native Object_StarRating was not used')
    required = (
        '<include content="Object_StarRating">',
        '<param name="selected">$PARAM[selected]</param>',
        '<centerright>324</centerright>',
        '$INFO[ListItem.Rating(imdb)]',
        '$INFO[ListItem.Rating(tmdb)]',
        '$INFO[ListItem.Year]',
        '<right>400</right>',
        KPM_COMBINED_EPISODE_CONDITION_0239,
    )
    if not all(token in layout for token in required):
        raise ValueError('Combined Expanded native-star/year controls are incomplete')
    title_start = layout.find(KPM_COMBINED_EPISODE_TITLE_START_0239)
    title_end = layout.find(KPM_COMBINED_EPISODE_TITLE_END_0239)
    title_marked = layout[title_start:title_end]
    if '<scroll>' in title_marked or '<autoscroll' in title_marked:
        raise ValueError('Combined Expanded episode title must keep AF3-style non-scrolling behavior')
    ET.fromstring(text)


def _patch_combined_expanded_episode_rating_0239(text: str):
    original = text
    start, end, block = _find_xml_include_block_0187(text, 'Layout_MediaList_Detailed')
    if start < 0:
        raise ValueError('Layout_MediaList_Detailed include not found')
    block = _strip_combined_episode_patch_0239(block)

    title_re = re.compile(
        r'(?P<indent>[ \t]*)<control type="label">\s*'
        r'<label>\$INFO\[ListItem\.Label\]</label>\s*'
        r'<font>font_main_bold</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_90</textcolor>\s*'
        r'<right>320</right>\s*'
        r'</control>', re.S,
    )
    title_match = title_re.search(block)
    if not title_match:
        raise ValueError('Combined Expanded native title label anchor not found')
    block = block[:title_match.start()] + _combined_episode_title_block_0239(title_match.group('indent')) + block[title_match.end():]

    date_re = re.compile(
        r'(?P<indent>[ \t]*)<control type="label">\s*'
        r'<right>150</right>\s*'
        r'<font>font_mini</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_70</textcolor>\s*'
        r'<label>\$VAR\[Label_MediaList_Details_LeftLabel\]</label>\s*'
        r'<align>right</align>\s*'
        r'</control>', re.S,
    )
    date_match = date_re.search(block)
    if not date_match:
        raise ValueError('Combined Expanded native date label anchor not found')
    indent = date_match.group('indent')
    native_date = date_match.group(0).replace(
        '</control>',
        '    <visible>![' + KPM_COMBINED_EPISODE_CONDITION_0239 + ']</visible>\n' + indent + '</control>',
        1,
    )
    replacement = _combined_episode_native_rating_block_0239(indent) + native_date
    block = block[:date_match.start()] + replacement + block[date_match.end():]
    text = text[:start] + block + text[end:]
    text = re.sub(r'\n{3,}', '\n\n', text)
    _validate_combined_episode_rating_0239(text)
    return text, text != original


def _patch_af3_layouts_0239(text: str):
    # Preserve every pre-existing KPM layout patch; replace only the Combined Expanded episode block.
    text, changed_base = _KPM_LAYOUT_PATCH_CURRENT_0233_BASE_0237(text)
    text, changed_rating = _patch_combined_expanded_episode_rating_0239(text)
    return text, bool(changed_base or changed_rating)


_KPM_LAYOUT_PATCH_CURRENT_0233 = _patch_af3_layouts_0239


def status_af3_unified_integration() -> str:
    try:
        layouts = read_text(af3_path('1080i', 'Includes_Layouts.xml'))
        _validate_combined_episode_rating_0239(layouts)
    except Exception as exc:
        return 'Not patched (Combined Expanded 0239 invalid: {0})'.format(exc)
    # Call the status function captured before the 0.2.38 Combined validator wrapper.
    return _status_af3_unified_integration_0238_base()

# v0.2.42 - equal rendered gaps across Combined Expanded episode metadata
KPM_COMBINED_EPISODE_TITLE_START_0240 = '<!-- KPM-AF3-COMBINED-EPISODE-TITLE-START-0240 -->'
KPM_COMBINED_EPISODE_TITLE_END_0240 = '<!-- KPM-AF3-COMBINED-EPISODE-TITLE-END-0240 -->'
KPM_COMBINED_EPISODE_START_0240 = '<!-- KPM-AF3-COMBINED-EPISODE-RATING-START-0240 -->'
KPM_COMBINED_EPISODE_END_0240 = '<!-- KPM-AF3-COMBINED-EPISODE-RATING-END-0240 -->'
KPM_COMBINED_EPISODE_CONDITION_0240 = 'Control.IsVisible(528) + String.IsEqual(ListItem.DBType,episode)'


def _combined_episode_title_block_0240(indent: str) -> str:
    """Keep the approved AF3-style title with right=400 and no scrolling."""
    condition = KPM_COMBINED_EPISODE_CONDITION_0240
    return '\n'.join([
        indent + KPM_COMBINED_EPISODE_TITLE_START_0240,
        indent + '<control type="label">',
        indent + '    <label>$INFO[ListItem.Label]</label>',
        indent + '    <font>font_main_bold</font>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_90</textcolor>',
        indent + '    <right>320</right>',
        indent + '    <visible>![' + condition + ']</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <label>$INFO[ListItem.Label]</label>',
        indent + '    <font>font_main_bold</font>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_90</textcolor>',
        indent + '    <right>400</right>',
        indent + '    <visible>' + condition + '</visible>',
        indent + '</control>',
        indent + KPM_COMBINED_EPISODE_TITLE_END_0240,
    ])


def _combined_episode_native_rating_block_0240(indent: str) -> str:
    condition = KPM_COMBINED_EPISODE_CONDITION_0240
    has_rating = '!String.IsEmpty(ListItem.Rating(imdb)) | !String.IsEmpty(ListItem.Rating(tmdb))'
    has_year = '!String.IsEmpty(ListItem.Year)'
    return '\n'.join([
        indent + KPM_COMBINED_EPISODE_START_0240,
        indent + '<include content="Object_StarRating">',
        indent + '    <param name="selected">$PARAM[selected]</param>',
        indent + '    <centertop>50%</centertop>',
        indent + '    <centerright>319</centerright>',
        indent + '    <visible>' + condition + ' + [' + has_rating + ']</visible>',
        indent + '</include>',
        indent + '<control type="label">',
        indent + '    <right>241</right>',
        indent + '    <width>48</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>left</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>$INFO[ListItem.Rating(imdb)]</label>',
        indent + '    <visible>' + condition + ' + !String.IsEmpty(ListItem.Rating(imdb))</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <right>241</right>',
        indent + '    <width>48</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>left</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>$INFO[ListItem.Rating(tmdb)]</label>',
        indent + '    <visible>' + condition + ' + String.IsEmpty(ListItem.Rating(imdb)) + !String.IsEmpty(ListItem.Rating(tmdb))</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <right>220</right>',
        indent + '    <width>24</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>center</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>•</label>',
        indent + '    <visible>' + condition + ' + [' + has_rating + '] + ' + has_year + '</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <right>149</right>',
        indent + '    <width>68</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>right</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>$INFO[ListItem.Year]</label>',
        indent + '    <visible>' + condition + '</visible>',
        indent + '</control>',
        indent + KPM_COMBINED_EPISODE_END_0240,
    ]) + '\n'


def _strip_combined_episode_patch_0240(block: str) -> str:
    # Normalize an existing 0.2.40 block back to AF3 anchors, then reuse the
    # proven 0.2.39 normalizer for 0.2.39/0.2.38/0.2.37 installations.
    title_0240 = re.compile(
        r'(?ms)^(?P<indent>[ \t]*)<!--\s*KPM-AF3-COMBINED-EPISODE-TITLE-START-0240\s*-->.*?'
        r'^[ \t]*<!--\s*KPM-AF3-COMBINED-EPISODE-TITLE-END-0240\s*-->[ \t]*(?:\r?\n)?'
    )
    block = title_0240.sub(
        lambda match: _combined_episode_native_title_0238(match.group('indent')) + '\n',
        block,
        count=1,
    )
    block = re.sub(
        r'(?ms)^[ \t]*<!--\s*KPM-AF3-COMBINED-EPISODE-RATING-START-0240\s*-->.*?'
        r'^[ \t]*<!--\s*KPM-AF3-COMBINED-EPISODE-RATING-END-0240\s*-->[ \t]*(?:\r?\n)?',
        '', block,
    )
    return _strip_combined_episode_patch_0239(block)


def _validate_combined_episode_rating_0240(text: str) -> None:
    if text.count(KPM_COMBINED_EPISODE_TITLE_START_0240) != 1 or text.count(KPM_COMBINED_EPISODE_TITLE_END_0240) != 1:
        raise ValueError('Combined Expanded title patch 0240 is missing or duplicated')
    if text.count(KPM_COMBINED_EPISODE_START_0240) != 1 or text.count(KPM_COMBINED_EPISODE_END_0240) != 1:
        raise ValueError('Combined Expanded rating patch 0240 is missing or duplicated')
    for old in (
        'KPM-AF3-COMBINED-EPISODE-RATING-START-0237',
        'KPM-AF3-COMBINED-EPISODE-RATING-START-0238',
        'KPM-AF3-COMBINED-EPISODE-TITLE-START-0238',
        'KPM-AF3-COMBINED-EPISODE-RATING-START-0239',
        'KPM-AF3-COMBINED-EPISODE-TITLE-START-0239',
    ):
        if old in text:
            raise ValueError('Older Combined Expanded block remains: ' + old)
    start, end, layout = _find_xml_include_block_0187(text, 'Layout_MediaList_Detailed')
    if start < 0:
        raise ValueError('Layout_MediaList_Detailed include not found')
    marker_start = layout.find(KPM_COMBINED_EPISODE_START_0240)
    marker_end = layout.find(KPM_COMBINED_EPISODE_END_0240)
    if marker_start < 0 or marker_end < marker_start:
        raise ValueError('Combined Expanded rating controls are outside Layout_MediaList_Detailed')
    marked = layout[marker_start:marker_end]
    if '<control type="grouplist">' in marked:
        raise ValueError('Combined Expanded rating still uses unsupported grouplist')
    if '<texture colordiffuse="white">flags/star10.png</texture>' in marked:
        raise ValueError('Manual KPM star remains; native Object_StarRating was not used')
    required = (
        '<include content="Object_StarRating">',
        '<param name="selected">$PARAM[selected]</param>',
        '<centerright>319</centerright>',
        '<right>241</right>',
        '<width>48</width>',
        '<align>left</align>',
        '<right>220</right>',
        '<width>24</width>',
        '<right>149</right>',
        '<width>68</width>',
        '$INFO[ListItem.Rating(imdb)]',
        '$INFO[ListItem.Rating(tmdb)]',
        '$INFO[ListItem.Year]',
        '<right>400</right>',
        KPM_COMBINED_EPISODE_CONDITION_0240,
    )
    if not all(token in layout for token in required):
        raise ValueError('Combined Expanded exact-spacing controls are incomplete')
    title_start = layout.find(KPM_COMBINED_EPISODE_TITLE_START_0240)
    title_end = layout.find(KPM_COMBINED_EPISODE_TITLE_END_0240)
    title_marked = layout[title_start:title_end]
    if '<scroll>' in title_marked or '<autoscroll' in title_marked:
        raise ValueError('Combined Expanded episode title must remain non-scrolling')
    # R33 runtime screenshot at native 1920 width measured the rendered gaps as:
    # star-rating 29 px, rating-bullet 26 px, bullet-year 20 px,
    # year-indicator 36 px, and native indicator-duration 21 px.
    # Keep the native indicator and duration fixed and shift the four KPM
    # controls so every rendered gap targets the same native 21 px rhythm.
    expected_geometry = {
        'star_centerright': 319,
        'rating_right': 241,
        'rating_width': 48,
        'bullet_right': 220,
        'bullet_width': 24,
        'year_right': 149,
        'year_width': 68,
    }
    if expected_geometry != {
        'star_centerright': 319,
        'rating_right': 241,
        'rating_width': 48,
        'bullet_right': 220,
        'bullet_width': 24,
        'year_right': 149,
        'year_width': 68,
    }:
        raise ValueError('Combined Expanded equal-gap geometry changed')
    ET.fromstring(text)


def _patch_combined_expanded_episode_rating_0240(text: str):
    original = text
    start, end, block = _find_xml_include_block_0187(text, 'Layout_MediaList_Detailed')
    if start < 0:
        raise ValueError('Layout_MediaList_Detailed include not found')
    block = _strip_combined_episode_patch_0240(block)

    title_re = re.compile(
        r'(?P<indent>[ \t]*)<control type="label">\s*'
        r'<label>\$INFO\[ListItem\.Label\]</label>\s*'
        r'<font>font_main_bold</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_90</textcolor>\s*'
        r'<right>320</right>\s*'
        r'</control>', re.S,
    )
    title_match = title_re.search(block)
    if not title_match:
        raise ValueError('Combined Expanded native title label anchor not found')
    block = block[:title_match.start()] + _combined_episode_title_block_0240(title_match.group('indent')) + block[title_match.end():]

    date_re = re.compile(
        r'(?P<indent>[ \t]*)<control type="label">\s*'
        r'<right>150</right>\s*'
        r'<font>font_mini</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_70</textcolor>\s*'
        r'<label>\$VAR\[Label_MediaList_Details_LeftLabel\]</label>\s*'
        r'<align>right</align>\s*'
        r'</control>', re.S,
    )
    date_match = date_re.search(block)
    if not date_match:
        raise ValueError('Combined Expanded native date label anchor not found')
    indent = date_match.group('indent')
    native_date = date_match.group(0).replace(
        '</control>',
        '    <visible>![' + KPM_COMBINED_EPISODE_CONDITION_0240 + ']</visible>\n' + indent + '</control>',
        1,
    )
    replacement = _combined_episode_native_rating_block_0240(indent) + native_date
    block = block[:date_match.start()] + replacement + block[date_match.end():]
    text = text[:start] + block + text[end:]
    text = re.sub(r'\n{3,}', '\n\n', text)
    _validate_combined_episode_rating_0240(text)
    return text, text != original


def _patch_af3_layouts_0240(text: str):
    # Preserve every other KPM/AF3 layout patch and replace only the marked
    # Combined Expanded episode title/rating block.
    text, changed_base = _KPM_LAYOUT_PATCH_CURRENT_0233_BASE_0237(text)
    text, changed_rating = _patch_combined_expanded_episode_rating_0240(text)
    return text, bool(changed_base or changed_rating)


_KPM_LAYOUT_PATCH_CURRENT_0233 = _patch_af3_layouts_0240


def status_af3_unified_integration() -> str:
    try:
        layouts = read_text(af3_path('1080i', 'Includes_Layouts.xml'))
        _validate_combined_episode_rating_0240(layouts)
    except Exception as exc:
        return 'Not patched (Combined Expanded 0240 invalid: {0})'.format(exc)
    return _status_af3_unified_integration_0238_base()

# -----------------------------------------------------------------------------
# v0.2.43 - current-only AF3 status audit (reporting fix, no migration)
# -----------------------------------------------------------------------------
def _validate_af3_unified_current_0243(info_text: str, layouts_text: str,
                                       images_text: str, screen_text: str) -> None:
    """Validate only the current KPM-owned AF3 contract.

    This does not convert, restore, or rewrite any XML/state. It exists solely
    so Settings and diagnostics report the current 0189/0233/0237/0240 blocks
    instead of looking for retired landscape/panel-gate markers.
    """
    ET.fromstring(info_text)
    ET.fromstring(layouts_text)
    ET.fromstring(images_text)
    ET.fromstring(screen_text)

    _validate_kpm_rating_row_placement_0236(info_text)
    _validate_steam_game_plot_0237(info_text)
    if info_text.count(KPM_AF3_ROW_CALL_START) != 1 or info_text.count(KPM_AF3_ROW_CALL_END) != 1:
        raise ValueError('Current rating-row call marker is missing or duplicated')
    if info_text.count(KPM_AF3_ROW_DEF_START) != 1 or info_text.count(KPM_AF3_ROW_DEF_END) != 1:
        raise ValueError('Current rating-row definition marker is missing or duplicated')
    if info_text.count(KPM_STEAM_INFO_START) != 1 or info_text.count(KPM_STEAM_INFO_END) != 1:
        raise ValueError('Current Steam info marker is missing or duplicated')
    for token in (
        'Window(Home).Property(KPM.RatingRow.ActiveSet)',
        'Window(Home).Property(KPM.Visual.GateActive)',
        'Window(Home).Property(KPM.Visual.Ready)',
        '$PARAM[container]$PARAM[listitem].Property(platform)',
    ):
        if token not in info_text:
            raise ValueError('Current Includes_Info contract lost token: {0}'.format(token))

    _validate_combined_episode_rating_0240(layouts_text)
    _validate_current_screensaver_0233(screen_text)
    checked_images, images_changed = _patch_startup_weather_fallback_text_0237(images_text)
    if images_changed or checked_images != images_text:
        raise ValueError('Startup weather fallback is not current')


def status_af3_unified_integration() -> str:
    paths = {
        'Includes_Info.xml': af3_path('1080i', 'Includes_Info.xml'),
        'Includes_Layouts.xml': af3_path('1080i', 'Includes_Layouts.xml'),
        'Includes_Images.xml': af3_path('1080i', 'Includes_Images.xml'),
        'screensaver-arctic-mirage.xml': af3_path('1080i', 'screensaver-arctic-mirage.xml'),
    }
    try:
        missing = [name for name, path in paths.items() if not os.path.isfile(path)]
        if missing:
            return 'Not patched (missing: {0})'.format(', '.join(missing))
        _validate_af3_unified_current_0243(
            read_text(paths['Includes_Info.xml']),
            read_text(paths['Includes_Layouts.xml']),
            read_text(paths['Includes_Images.xml']),
            read_text(paths['screensaver-arctic-mirage.xml']),
        )
        return 'Patched (current 0189/0233/0237/0240)'
    except Exception as exc:
        return 'Not patched (current validation: {0})'.format(exc)


# -----------------------------------------------------------------------------
# v0.2.44 - Expanded episode parity, exact-ten labels, and loading-row guards
# -----------------------------------------------------------------------------
KPM_EXPANDED_EPISODE_TITLE_START_0244 = '<!-- KPM-AF3-EXPANDED-EPISODE-TITLE-START-0244 -->'
KPM_EXPANDED_EPISODE_TITLE_END_0244 = '<!-- KPM-AF3-EXPANDED-EPISODE-TITLE-END-0244 -->'
KPM_EXPANDED_EPISODE_START_0244 = '<!-- KPM-AF3-EXPANDED-EPISODE-RATING-START-0244 -->'
KPM_EXPANDED_EPISODE_END_0244 = '<!-- KPM-AF3-EXPANDED-EPISODE-RATING-END-0244 -->'
KPM_EXPANDED_EPISODE_CONDITION_0244 = 'String.IsEqual(ListItem.DBType,episode)'


# Keep the established A/B row renderer and alter only its transient-window gate:
# DialogBusy may show the committed row; a container that is still updating may not.
_KPM_ROW_DEF_BLOCK_0243 = _kpm_row_def_block

def _kpm_row_def_block() -> str:
    block = _KPM_ROW_DEF_BLOCK_0243()
    old = '!Window.IsVisible(busydialog) + !Window.IsVisible(busydialognocancel)'
    if old not in block:
        raise ValueError('Current KPM lower-row busy guard was not found')
    return block.replace(old, '!Container.IsUpdating')


def _expanded_episode_title_block_0244(indent: str) -> str:
    condition = KPM_EXPANDED_EPISODE_CONDITION_0244
    return '\n'.join([
        indent + KPM_EXPANDED_EPISODE_TITLE_START_0244,
        indent + '<control type="label">',
        indent + '    <label>$INFO[ListItem.Label]</label>',
        indent + '    <font>font_main_bold</font>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_90</textcolor>',
        indent + '    <right>320</right>',
        indent + '    <visible>![' + condition + ']</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <label>$INFO[ListItem.Label]</label>',
        indent + '    <font>font_main_bold</font>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_90</textcolor>',
        indent + '    <right>400</right>',
        indent + '    <visible>' + condition + '</visible>',
        indent + '</control>',
        indent + KPM_EXPANDED_EPISODE_TITLE_END_0244,
    ])


def _expanded_episode_rating_block_0244(indent: str) -> str:
    condition = KPM_EXPANDED_EPISODE_CONDITION_0244
    has_rating = '!String.IsEmpty(ListItem.Rating(imdb)) | !String.IsEmpty(ListItem.Rating(tmdb))'
    has_year = '!String.IsEmpty(ListItem.Year)'
    imdb_ten = '[String.IsEqual(ListItem.Rating(imdb),10) | String.IsEqual(ListItem.Rating(imdb),10.0)]'
    tmdb_ten = '[String.IsEqual(ListItem.Rating(tmdb),10) | String.IsEqual(ListItem.Rating(tmdb),10.0)]'

    def rating_label(label: str, visible: str) -> list:
        return [
            indent + '<control type="label">',
            indent + '    <right>241</right>',
            indent + '    <width>48</width>',
            indent + '    <font>font_mini</font>',
            indent + '    <align>left</align>',
            indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
            indent + '    <textcolor>main_fg_70</textcolor>',
            indent + '    <label>' + label + '</label>',
            indent + '    <visible>' + condition + ' + ' + visible + '</visible>',
            indent + '</control>',
        ]

    lines = [
        indent + KPM_EXPANDED_EPISODE_START_0244,
        indent + '<include content="Object_StarRating">',
        indent + '    <param name="selected">$PARAM[selected]</param>',
        indent + '    <centertop>50%</centertop>',
        indent + '    <centerright>319</centerright>',
        indent + '    <visible>' + condition + ' + [' + has_rating + ']</visible>',
        indent + '</include>',
    ]
    lines += rating_label('10', imdb_ten)
    lines += rating_label('$INFO[ListItem.Rating(imdb)]', '!String.IsEmpty(ListItem.Rating(imdb)) + !' + imdb_ten)
    lines += rating_label('10', 'String.IsEmpty(ListItem.Rating(imdb)) + ' + tmdb_ten)
    lines += rating_label('$INFO[ListItem.Rating(tmdb)]', 'String.IsEmpty(ListItem.Rating(imdb)) + !String.IsEmpty(ListItem.Rating(tmdb)) + !' + tmdb_ten)
    lines += [
        indent + '<control type="label">',
        indent + '    <right>220</right>',
        indent + '    <width>24</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>center</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>•</label>',
        indent + '    <visible>' + condition + ' + [' + has_rating + '] + ' + has_year + '</visible>',
        indent + '</control>',
        indent + '<control type="label">',
        indent + '    <right>149</right>',
        indent + '    <width>68</width>',
        indent + '    <font>font_mini</font>',
        indent + '    <align>right</align>',
        indent + '    <include condition="$PARAM[selected]">Color_SelectedText</include>',
        indent + '    <textcolor>main_fg_70</textcolor>',
        indent + '    <label>$INFO[ListItem.Year]</label>',
        indent + '    <visible>' + condition + '</visible>',
        indent + '</control>',
        indent + KPM_EXPANDED_EPISODE_END_0244,
    ]
    return '\n'.join(lines) + '\n'


def _strip_expanded_episode_patch_0244(block: str) -> str:
    title_re = re.compile(
        r'(?ms)^(?P<indent>[ \t]*)<!--\s*KPM-AF3-EXPANDED-EPISODE-TITLE-START-0244\s*-->.*?'
        r'^[ \t]*<!--\s*KPM-AF3-EXPANDED-EPISODE-TITLE-END-0244\s*-->[ \t]*(?:\r?\n)?'
    )
    block = title_re.sub(
        lambda match: _combined_episode_native_title_0238(match.group('indent')) + '\n',
        block,
        count=1,
    )
    block = re.sub(
        r'(?ms)^[ \t]*<!--\s*KPM-AF3-EXPANDED-EPISODE-RATING-START-0244\s*-->.*?'
        r'^[ \t]*<!--\s*KPM-AF3-EXPANDED-EPISODE-RATING-END-0244\s*-->[ \t]*(?:\r?\n)?',
        '', block,
    )
    block = re.sub(
        r'\n[ \t]*<visible>!\[' + re.escape(KPM_EXPANDED_EPISODE_CONDITION_0244) + r'\]</visible>',
        '', block, count=1,
    )
    return _strip_combined_episode_patch_0240(block)


def _validate_expanded_episode_rating_0244(text: str) -> None:
    if text.count(KPM_EXPANDED_EPISODE_TITLE_START_0244) != 1 or text.count(KPM_EXPANDED_EPISODE_TITLE_END_0244) != 1:
        raise ValueError('Expanded episode title patch 0244 is missing or duplicated')
    if text.count(KPM_EXPANDED_EPISODE_START_0244) != 1 or text.count(KPM_EXPANDED_EPISODE_END_0244) != 1:
        raise ValueError('Expanded episode rating patch 0244 is missing or duplicated')
    for old in (
        'KPM-AF3-COMBINED-EPISODE-RATING-START-0237',
        'KPM-AF3-COMBINED-EPISODE-RATING-START-0238',
        'KPM-AF3-COMBINED-EPISODE-TITLE-START-0238',
        'KPM-AF3-COMBINED-EPISODE-RATING-START-0239',
        'KPM-AF3-COMBINED-EPISODE-TITLE-START-0239',
        'KPM-AF3-COMBINED-EPISODE-RATING-START-0240',
        'KPM-AF3-COMBINED-EPISODE-TITLE-START-0240',
    ):
        if old in text:
            raise ValueError('Older expanded episode block remains: ' + old)
    start, end, layout = _find_xml_include_block_0187(text, 'Layout_MediaList_Detailed')
    if start < 0:
        raise ValueError('Layout_MediaList_Detailed include not found')
    marker_start = layout.find(KPM_EXPANDED_EPISODE_START_0244)
    marker_end = layout.find(KPM_EXPANDED_EPISODE_END_0244)
    if marker_start < 0 or marker_end < marker_start:
        raise ValueError('Expanded episode controls are outside Layout_MediaList_Detailed')
    marked = layout[marker_start:marker_end]
    required = (
        '<include content="Object_StarRating">',
        '<centerright>319</centerright>',
        '<right>241</right>',
        '<width>48</width>',
        '<right>220</right>',
        '<width>24</width>',
        '<right>149</right>',
        '<width>68</width>',
        '<label>10</label>',
        '$INFO[ListItem.Rating(imdb)]',
        '$INFO[ListItem.Rating(tmdb)]',
        '$INFO[ListItem.Year]',
        '<right>400</right>',
        KPM_EXPANDED_EPISODE_CONDITION_0244,
    )
    if not all(token in layout for token in required):
        raise ValueError('Expanded episode 0244 controls are incomplete')
    if marked.count('<label>10</label>') != 2:
        raise ValueError('Exact-ten formatter must have one IMDb and one TMDb literal label')
    title_start = layout.find(KPM_EXPANDED_EPISODE_TITLE_START_0244)
    title_end = layout.find(KPM_EXPANDED_EPISODE_TITLE_END_0244)
    title_marked = layout[title_start:title_end]
    if '<scroll>' in title_marked or '<autoscroll' in title_marked:
        raise ValueError('Expanded episode title must remain non-scrolling')
    ET.fromstring(text)


def _patch_expanded_episode_rating_0244(text: str):
    original = text
    start, end, block = _find_xml_include_block_0187(text, 'Layout_MediaList_Detailed')
    if start < 0:
        raise ValueError('Layout_MediaList_Detailed include not found')
    block = _strip_expanded_episode_patch_0244(block)

    title_re = re.compile(
        r'(?P<indent>[ \t]*)<control type="label">\s*'
        r'<label>\$INFO\[ListItem\.Label\]</label>\s*'
        r'<font>font_main_bold</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_90</textcolor>\s*'
        r'<right>320</right>\s*'
        r'</control>', re.S,
    )
    title_match = title_re.search(block)
    if not title_match:
        raise ValueError('Expanded episode native title label anchor not found')
    block = block[:title_match.start()] + _expanded_episode_title_block_0244(title_match.group('indent')) + block[title_match.end():]

    date_re = re.compile(
        r'(?P<indent>[ \t]*)<control type="label">\s*'
        r'<right>150</right>\s*'
        r'<font>font_mini</font>\s*'
        r'<include condition="\$PARAM\[selected\]">Color_SelectedText</include>\s*'
        r'<textcolor>main_fg_70</textcolor>\s*'
        r'<label>\$VAR\[Label_MediaList_Details_LeftLabel\]</label>\s*'
        r'<align>right</align>\s*'
        r'</control>', re.S,
    )
    date_match = date_re.search(block)
    if not date_match:
        raise ValueError('Expanded episode native date label anchor not found')
    indent = date_match.group('indent')
    native_date = date_match.group(0).replace(
        '</control>',
        '    <visible>![' + KPM_EXPANDED_EPISODE_CONDITION_0244 + ']</visible>\n' + indent + '</control>',
        1,
    )
    replacement = _expanded_episode_rating_block_0244(indent) + native_date
    block = block[:date_match.start()] + replacement + block[date_match.end():]
    text = text[:start] + block + text[end:]
    text = re.sub(r'\n{3,}', '\n\n', text)
    _validate_expanded_episode_rating_0244(text)
    return text, text != original


def _patch_af3_layouts_0244(text: str):
    text, changed_base = _KPM_LAYOUT_PATCH_CURRENT_0233_BASE_0237(text)
    text, changed_rating = _patch_expanded_episode_rating_0244(text)
    return text, bool(changed_base or changed_rating)


_KPM_LAYOUT_PATCH_CURRENT_0233 = _patch_af3_layouts_0244


# Export the exact startup and busy windows, plus the active definitions that own
# Hub_Widget_Splash and Hub_Window, so timing/geometry can be diagnosed without guessing.
AF3_FULL_CONTEXT_XMLS = tuple(dict.fromkeys(AF3_FULL_CONTEXT_XMLS + (
    'Custom_1198_Dialog_Startup.xml', 'DialogBusy.xml',
)))
_ADD_FULL_SYSTEM_DIAGNOSTIC_FILES_0243 = _add_full_system_diagnostic_files

def _add_full_system_diagnostic_files(files_to_write: Dict[str, str], stamp: str) -> None:
    _ADD_FULL_SYSTEM_DIAGNOSTIC_FILES_0243(files_to_write, stamp)
    definitions = {}
    root = af3_path('1080i')
    try:
        for fname in sorted(os.listdir(root)):
            if not fname.lower().endswith('.xml'):
                continue
            path = os.path.join(root, fname)
            try:
                text = read_text(path)
            except Exception:
                continue
            names = []
            for name in ('Hub_Widget_Splash', 'Hub_Window'):
                if re.search(r'<include\s+name=["\']' + re.escape(name) + r'["\']', text, re.I):
                    names.append(name)
            if names:
                definitions[fname] = names
                _copy_text_file_to_diag(files_to_write, 'xml/1080i/' + fname, path, 6000000)
    except Exception as exc:
        definitions['_scan_error'] = str(exc)
    files_to_write['xml/startup-hub-definition-files.json'] = json.dumps(definitions, indent=2, ensure_ascii=False)


def _validate_af3_unified_current_0244(info_text: str, layouts_text: str,
                                       images_text: str, screen_text: str) -> None:
    ET.fromstring(info_text)
    ET.fromstring(layouts_text)
    ET.fromstring(images_text)
    ET.fromstring(screen_text)
    _validate_kpm_rating_row_placement_0236(info_text)
    _validate_steam_game_plot_0237(info_text)
    if info_text.count(KPM_AF3_ROW_CALL_START) != 1 or info_text.count(KPM_AF3_ROW_CALL_END) != 1:
        raise ValueError('Current rating-row call marker is missing or duplicated')
    if info_text.count(KPM_AF3_ROW_DEF_START) != 1 or info_text.count(KPM_AF3_ROW_DEF_END) != 1:
        raise ValueError('Current rating-row definition marker is missing or duplicated')
    row_start = info_text.find(KPM_AF3_ROW_DEF_START)
    row_end = info_text.find(KPM_AF3_ROW_DEF_END)
    row = info_text[row_start:row_end]
    if '!Window.IsVisible(busydialog)' in row or '!Window.IsVisible(busydialognocancel)' in row:
        raise ValueError('DialogBusy is still hiding the committed rating row')
    if '!Container.IsUpdating' not in row:
        raise ValueError('Updating-container guard is missing from the rating row')
    _validate_expanded_episode_rating_0244(layouts_text)
    _validate_current_screensaver_0233(screen_text)
    checked_images, images_changed = _patch_startup_weather_fallback_text_0237(images_text)
    if images_changed or checked_images != images_text:
        raise ValueError('Startup weather fallback is not current')


def status_af3_unified_integration() -> str:
    paths = {
        'Includes_Info.xml': af3_path('1080i', 'Includes_Info.xml'),
        'Includes_Layouts.xml': af3_path('1080i', 'Includes_Layouts.xml'),
        'Includes_Images.xml': af3_path('1080i', 'Includes_Images.xml'),
        'screensaver-arctic-mirage.xml': af3_path('1080i', 'screensaver-arctic-mirage.xml'),
    }
    try:
        missing = [name for name, path in paths.items() if not os.path.isfile(path)]
        if missing:
            return 'Not patched (missing: {0})'.format(', '.join(missing))
        _validate_af3_unified_current_0244(
            read_text(paths['Includes_Info.xml']),
            read_text(paths['Includes_Layouts.xml']),
            read_text(paths['Includes_Images.xml']),
            read_text(paths['screensaver-arctic-mirage.xml']),
        )
        return 'Patched (current 0189/0233/0237/0244)'
    except Exception as exc:
        return 'Not patched (current validation: {0})'.format(exc)


# -----------------------------------------------------------------------------
# v0.2.45 - custom-only startup artwork and 2500/1000 startup slideshow
# -----------------------------------------------------------------------------
KPM_STARTUP_CUSTOM_ROOT_0245 = 'special://masterprofile/media/af3-launch-weather'
KPM_STARTUP_TIMING_START_0245 = '<!-- KPM-AF3-STARTUP-SLIDESHOW-START-0245 -->'
KPM_STARTUP_TIMING_END_0245 = '<!-- KPM-AF3-STARTUP-SLIDESHOW-END-0245 -->'


def _patch_startup_weather_fallback_text_0237(text: str):
    """Replace only Image_StartUp with custom KPM paths.

    The active weather code remains an input to the KPM service. Image files are
    never read from native weather-fanart or the stock AF3 launch directory.
    System.Time provides a first-frame clock fallback before the service writes
    KPM.AF3StartupFallbackPath.
    """
    original = text
    block = extract_variable_block(text, 'Image_StartUp')
    if not block:
        raise ValueError('Image_StartUp variable not found')
    indent_match = re.match(r'(?P<indent>[ \t]*)<variable', block)
    indent = indent_match.group('indent') if indent_match else '    '
    inner = indent + '    '
    replacement = '\n'.join([
        indent + '<variable name="Image_StartUp">',
        inner + '<!-- KPM-AF3-STARTUP-WEATHER-FALLBACK-START-0237 -->',
        inner + '<value condition="!String.IsEmpty(Window(Home).Property(KPM.AF3StartupFallbackPath))">$INFO[Window(Home).Property(KPM.AF3StartupFallbackPath)]</value>',
        inner + '<value condition="System.Time(05:00,07:00) | System.Time(17:00,19:00)">' + KPM_STARTUP_CUSTOM_ROOT_0245 + '/dawn-dusk/</value>',
        inner + '<value condition="System.Time(07:00,17:00)">' + KPM_STARTUP_CUSTOM_ROOT_0245 + '/clear/day/</value>',
        inner + '<value condition="!System.Time(05:00,19:00)">' + KPM_STARTUP_CUSTOM_ROOT_0245 + '/clear/night/</value>',
        inner + '<value>' + KPM_STARTUP_CUSTOM_ROOT_0245 + '/clear/day/</value>',
        inner + '<!-- KPM-AF3-STARTUP-WEATHER-FALLBACK-END-0237 -->',
        indent + '</variable>',
    ])
    text = text.replace(block, replacement, 1)
    ET.fromstring(text)
    new_block = extract_variable_block(text, 'Image_StartUp') or ''
    required = (
        'Window(Home).Property(KPM.AF3StartupFallbackPath)',
        'System.Time(05:00,07:00)',
        '/dawn-dusk/', '/clear/day/', '/clear/night/',
    )
    if not all(token in new_block for token in required):
        raise ValueError('Custom startup Image_StartUp block is incomplete')
    forbidden = ('special://skin/extras/backgrounds/launch/', 'resource.images.weatherfanart.multi', '/all/')
    if any(token in new_block for token in forbidden):
        raise ValueError('Forbidden native/all startup path remains in Image_StartUp')
    return text, text != original


def _patch_startup_slideshow_0245(text: str):
    original = text
    marker_start = text.count(KPM_STARTUP_TIMING_START_0245)
    marker_end = text.count(KPM_STARTUP_TIMING_END_0245)
    if marker_start or marker_end:
        if marker_start != 1 or marker_end != 1:
            raise ValueError('Partial startup slideshow marker detected')
        match_current = re.search(r'(?ms)<include name="Background_StartUp">.*?</include>', text)
        if not match_current:
            raise ValueError('Background_StartUp include not found')
        current = match_current.group(0)
        if '<timeperimage>2500</timeperimage>' not in current or '<fadetime>1000</fadetime>' not in current:
            raise ValueError('Marked startup slideshow timing is incomplete')
        return text, False
    match = re.search(r'(?ms)(?P<indent>[ \t]*)<include name="Background_StartUp">(?P<body>.*?)^[ \t]*</include>', text)
    if not match:
        raise ValueError('Background_StartUp include not found')
    full = match.group(0)
    if '<control type="multiimage">' not in full:
        raise ValueError('Background_StartUp multiimage not found')
    updated = re.sub(r'<timeperimage>\d+</timeperimage>', '<timeperimage>2500</timeperimage>', full, count=1)
    updated = re.sub(r'<fadetime>\d+</fadetime>', '<fadetime>1000</fadetime>', updated, count=1)
    if updated == full and '<timeperimage>2500</timeperimage>' not in full:
        raise ValueError('Background_StartUp timing anchors not found')
    indent = match.group('indent') + '    '
    updated = updated.replace('<control type="multiimage">', KPM_STARTUP_TIMING_START_0245 + '\n' + indent + '<control type="multiimage">', 1)
    # place closing marker immediately after multiimage control inside this include
    close_pos = updated.find('</control>', updated.find('<control type="multiimage">'))
    if close_pos < 0:
        raise ValueError('Background_StartUp multiimage closing control not found')
    close_pos += len('</control>')
    updated = updated[:close_pos] + '\n' + indent + KPM_STARTUP_TIMING_END_0245 + updated[close_pos:]
    text = text[:match.start()] + updated + text[match.end():]
    ET.fromstring(text)
    block = re.search(r'(?ms)<include name="Background_StartUp">.*?</include>', text).group(0)
    if block.count('<timeperimage>2500</timeperimage>') != 1 or block.count('<fadetime>1000</fadetime>') != 1:
        raise ValueError('Startup slideshow timing validation failed')
    return text, text != original


def _patch_af3_startup_slideshow_xml_0245() -> bool:
    target = af3_path('1080i', 'Includes_Background.xml')
    if not os.path.isfile(target):
        raise FileNotFoundError('Includes_Background.xml not found')
    original = read_text(target)
    updated, changed = _patch_startup_slideshow_0245(original)
    if changed:
        snapshot('af3_unified_integration', [target])
        write_text(target, updated)
    return changed


def _remove_af3_startup_slideshow_xml_0245() -> bool:
    target = af3_path('1080i', 'Includes_Background.xml')
    if not os.path.isfile(target):
        return False
    text = read_text(target)
    original = text
    text = text.replace(KPM_STARTUP_TIMING_START_0245 + '\n', '').replace(KPM_STARTUP_TIMING_END_0245, '')
    match = re.search(r'(?ms)<include name="Background_StartUp">.*?</include>', text)
    if match:
        block = match.group(0)
        block = re.sub(r'<timeperimage>2500</timeperimage>', '<timeperimage>5000</timeperimage>', block, count=1)
        block = re.sub(r'<fadetime>1000</fadetime>', '<fadetime>2000</fadetime>', block, count=1)
        text = text[:match.start()] + block + text[match.end():]
    text = re.sub(r'\n{3,}', '\n\n', text)
    if text != original:
        ET.fromstring(text)
        write_text(target, text)
        return True
    return False


_apply_af3_unified_integration_0245_base = apply_af3_unified_integration

def apply_af3_unified_integration() -> Result:
    result = _apply_af3_unified_integration_0245_base()
    if result.status not in ('Patched', 'Skipped'):
        return result
    try:
        timing_changed = _patch_af3_startup_slideshow_xml_0245()
    except Exception as exc:
        log('Startup slideshow patch refused: {0}'.format(exc))
        return Result('AF3 Unified Integration', 'Skipped', result.detail + '\nStartup slideshow refused: ' + str(exc))
    if timing_changed:
        _reload_skin_after_patch()
        return Result('AF3 Unified Integration', 'Patched', result.detail + ' Startup slideshow set to 2500/1000 ms.')
    return result


_remove_af3_unified_integration_0245_base = remove_af3_unified_integration

def remove_af3_unified_integration() -> Result:
    timing_changed = _remove_af3_startup_slideshow_xml_0245()
    result = _remove_af3_unified_integration_0245_base()
    if timing_changed and result.status != 'Removed':
        _reload_skin_after_patch()
        return Result('AF3 Unified Integration', 'Removed', 'Startup slideshow timing restored.')
    return result


_status_af3_unified_integration_0245_base = status_af3_unified_integration

def status_af3_unified_integration() -> str:
    result = _status_af3_unified_integration_0245_base()
    if not result.startswith('Patched'):
        return result
    try:
        path = af3_path('1080i', 'Includes_Background.xml')
        text = read_text(path)
        block = re.search(r'(?ms)<include name="Background_StartUp">.*?</include>', text)
        if not block:
            raise ValueError('Background_StartUp missing')
        value = block.group(0)
        if '<timeperimage>2500</timeperimage>' not in value or '<fadetime>1000</fadetime>' not in value:
            raise ValueError('startup timing is not 2500/1000')
        return 'Patched (current 0189/0233/0237/0244/0245)'
    except Exception as exc:
        return 'Not patched (startup slideshow: {0})'.format(exc)

# Restore only the original Image_StartUp variable captured before the first
# custom-only patch. Never replace the complete Includes_Images.xml file.
def _remove_af3_startup_weather_xml_0237() -> bool:
    path = af3_path('1080i', 'Includes_Images.xml')
    backup = path + KPM_CURRENT_BACKUP_IMAGES_0237
    if not os.path.isfile(path):
        return False
    current = read_text(path)
    current_block = extract_variable_block(current, 'Image_StartUp')
    if not current_block:
        return False
    if os.path.isfile(backup):
        original_text = read_text(backup)
        original_block = extract_variable_block(original_text, 'Image_StartUp')
        if not original_block:
            raise ValueError('Image_StartUp variable missing from KPM backup')
    else:
        indent_match = re.match(r'(?P<indent>[ \t]*)<variable', current_block)
        indent = indent_match.group('indent') if indent_match else '    '
        inner = indent + '    '
        original_block = '\n'.join([
            indent + '<variable name="Image_StartUp">',
            inner + '<value condition="Weather.IsFetched + !String.IsEmpty(Weather.FanartCode) + System.HasAddon(resource.images.weatherfanart.multi) + [String.IsEmpty(Skin.String(Startup.ImageFolder)) | Skin.String(Startup.ImageFolder,special://skin/extras/backgrounds/launch/)]">resource://resource.images.weatherfanart.multi/$INFO[Weather.FanartCode]/</value>',
            inner + '<value condition="!String.IsEmpty(Skin.String(Startup.ImageFolder))">$INFO[Skin.String(Startup.ImageFolder)]</value>',
            inner + '<value>special://skin/extras/backgrounds/launch/</value>',
            indent + '</variable>',
        ])
    updated = current.replace(current_block, original_block, 1)
    if updated == current:
        return False
    ET.fromstring(updated)
    write_text(path, updated)
    return True

# Fresh-install contract: startup refresh is controlled only by the dedicated
# Full Integration state. Legacy component-state inference is intentionally not
# used as a migration path.
def full_integration_startup_enabled_0238() -> bool:
    return os.path.exists(state_file(FULL_INTEGRATION_STATE_ID_0238))


# -----------------------------------------------------------------------------
# v0.2.46 - owner-container loading guard for KPM rating rows
# -----------------------------------------------------------------------------
# R38 used the unqualified Container.IsUpdating boolean inside the reusable
# KPM_Info_Meta_RatingRow include. In Home/Hub/Media windows that include can be
# evaluated outside the list container which owns the visible loading spinner.
# The row now receives an explicit visibility condition from each Info_Panel
# owner and no longer relies on the unqualified container boolean.
KPM_TRANSIENT_INFO_META_PARAM_START_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-INFO-META-PARAM-START-0246 -->'
KPM_TRANSIENT_INFO_META_PARAM_END_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-INFO-META-PARAM-END-0246 -->'
KPM_TRANSIENT_INFO_PANEL_PARAM_START_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-INFO-PANEL-PARAM-START-0246 -->'
KPM_TRANSIENT_INFO_PANEL_PARAM_END_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-INFO-PANEL-PARAM-END-0246 -->'
KPM_TRANSIENT_INFO_PASS_START_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-PASS-START-0246 -->'
KPM_TRANSIENT_INFO_PASS_END_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-PASS-END-0246 -->'
KPM_TRANSIENT_VIEWS_START_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-VIEWS-START-0246 -->'
KPM_TRANSIENT_VIEWS_END_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-VIEWS-END-0246 -->'
KPM_TRANSIENT_COMBINED_START_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-COMBINED-START-0246 -->'
KPM_TRANSIENT_COMBINED_END_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-COMBINED-END-0246 -->'
KPM_TRANSIENT_HUB_WALL_START_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-HUB-WALL-START-0246 -->'
KPM_TRANSIENT_HUB_WALL_END_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-HUB-WALL-END-0246 -->'
KPM_TRANSIENT_HUB_COMBINED_A_START_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-HUB-COMBINED-A-START-0246 -->'
KPM_TRANSIENT_HUB_COMBINED_A_END_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-HUB-COMBINED-A-END-0246 -->'
KPM_TRANSIENT_HUB_COMBINED_B_START_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-HUB-COMBINED-B-START-0246 -->'
KPM_TRANSIENT_HUB_COMBINED_B_END_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-HUB-COMBINED-B-END-0246 -->'
KPM_TRANSIENT_HUB_SPOTLIGHT_START_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-HUB-SPOTLIGHT-START-0246 -->'
KPM_TRANSIENT_HUB_SPOTLIGHT_END_0246 = '<!-- KPM-AF3-RATING-TRANSIENT-HUB-SPOTLIGHT-END-0246 -->'

# Regenerate the KPM row without the old generic guard. The exact owner guard is
# passed through the KPM-only kpm_rating_visible parameter below.
_KPM_ROW_DEF_BLOCK_0245 = _kpm_row_def_block

def _kpm_row_def_block() -> str:
    block = _KPM_ROW_DEF_BLOCK_0245()
    block = block.replace(' + !Container.IsUpdating', '')
    return block


def _insert_after_once_0246(text: str, anchor: str, insertion: str, label: str) -> str:
    if text.count(anchor) != 1:
        raise ValueError('{0} anchor count is {1}, expected 1'.format(label, text.count(anchor)))
    return text.replace(anchor, anchor + insertion, 1)


def _patch_info_transient_guard_0246(text: str):
    original = text
    # Normalize the R38 definition even when this function is tested or called
    # directly, without relying on an earlier row regeneration step.
    row_start = text.find(KPM_AF3_ROW_DEF_START)
    row_end = text.find(KPM_AF3_ROW_DEF_END)
    if row_start < 0 or row_end < row_start:
        raise ValueError('KPM rating-row definition markers are missing')
    row_end += len(KPM_AF3_ROW_DEF_END)
    row = text[row_start:row_end].replace(' + !Container.IsUpdating', '')
    text = text[:row_start] + row + text[row_end:]
    markers = (
        KPM_TRANSIENT_INFO_META_PARAM_START_0246, KPM_TRANSIENT_INFO_META_PARAM_END_0246,
        KPM_TRANSIENT_INFO_PANEL_PARAM_START_0246, KPM_TRANSIENT_INFO_PANEL_PARAM_END_0246,
        KPM_TRANSIENT_INFO_PASS_START_0246, KPM_TRANSIENT_INFO_PASS_END_0246,
    )
    present = [m in text for m in markers]
    if any(present):
        if not all(present):
            raise ValueError('Partial 0246 Includes_Info transient marker set')
        _validate_info_transient_guard_0246(text)
        return text, False

    start, end, info_meta = _find_xml_include_block_0187(text, 'Info_Meta')
    if start < 0:
        raise ValueError('Info_Meta include not found')
    info_meta = _insert_after_once_0246(
        info_meta,
        '        <param name="visible">true</param>',
        '\n        ' + KPM_TRANSIENT_INFO_META_PARAM_START_0246 +
        '\n        <param name="kpm_rating_visible">true</param>' +
        '\n        ' + KPM_TRANSIENT_INFO_META_PARAM_END_0246,
        'Info_Meta visible parameter',
    )
    call_start = info_meta.find(KPM_AF3_ROW_CALL_START)
    call_end = info_meta.find(KPM_AF3_ROW_CALL_END)
    if call_start < 0 or call_end < call_start:
        raise ValueError('KPM rating-row call markers missing inside Info_Meta')
    call_end += len(KPM_AF3_ROW_CALL_END)
    call = info_meta[call_start:call_end]
    old_visible = '<param name="visible">$PARAM[visible]</param>'
    new_visible = '<param name="visible">[$PARAM[visible]] + [$PARAM[kpm_rating_visible]]</param>'
    if call.count(old_visible) != 1:
        raise ValueError('KPM rating-row call visible parameter is not current')
    call = call.replace(old_visible, new_visible, 1)
    info_meta = info_meta[:call_start] + call + info_meta[call_end:]
    text = text[:start] + info_meta + text[end:]

    start, end, panel = _find_xml_include_block_0187(text, 'Info_Panel')
    if start < 0:
        raise ValueError('Info_Panel include not found')
    panel = _insert_after_once_0246(
        panel,
        '        <param name="visible_meta">true</param>',
        '\n        ' + KPM_TRANSIENT_INFO_PANEL_PARAM_START_0246 +
        '\n        <param name="kpm_rating_visible">true</param>' +
        '\n        ' + KPM_TRANSIENT_INFO_PANEL_PARAM_END_0246,
        'Info_Panel visible_meta parameter',
    )
    meta_call = re.search(r'(?ms)(?P<indent>\s*)<include content="Info_Meta" condition="\$PARAM\[include_details\]">.*?</include>', panel)
    if not meta_call:
        raise ValueError('Info_Panel Info_Meta call not found')
    call = meta_call.group(0)
    anchor = '                    <param name="visible">$PARAM[visible_meta]</param>'
    insertion = (
        '\n                    ' + KPM_TRANSIENT_INFO_PASS_START_0246 +
        '\n                    <param name="kpm_rating_visible">$PARAM[kpm_rating_visible]</param>' +
        '\n                    ' + KPM_TRANSIENT_INFO_PASS_END_0246
    )
    if call.count(anchor) != 1:
        raise ValueError('Info_Panel Info_Meta visible parameter is not current')
    call = call.replace(anchor, anchor + insertion, 1)
    panel = panel[:meta_call.start()] + call + panel[meta_call.end():]
    text = text[:start] + panel + text[end:]
    text = re.sub(r'\n{3,}', '\n\n', text)
    ET.fromstring(text)
    _validate_info_transient_guard_0246(text)
    return text, text != original


def _validate_info_transient_guard_0246(text: str) -> None:
    ET.fromstring(text)
    for marker in (
        KPM_TRANSIENT_INFO_META_PARAM_START_0246, KPM_TRANSIENT_INFO_META_PARAM_END_0246,
        KPM_TRANSIENT_INFO_PANEL_PARAM_START_0246, KPM_TRANSIENT_INFO_PANEL_PARAM_END_0246,
        KPM_TRANSIENT_INFO_PASS_START_0246, KPM_TRANSIENT_INFO_PASS_END_0246,
    ):
        if text.count(marker) != 1:
            raise ValueError('Includes_Info marker missing or duplicated: ' + marker)
    if text.count('<param name="kpm_rating_visible">true</param>') != 2:
        raise ValueError('Includes_Info kpm_rating_visible defaults are incomplete')
    if text.count('<param name="kpm_rating_visible">$PARAM[kpm_rating_visible]</param>') != 1:
        raise ValueError('Info_Panel does not pass kpm_rating_visible to Info_Meta')
    if text.count('<param name="visible">[$PARAM[visible]] + [$PARAM[kpm_rating_visible]]</param>') != 1:
        raise ValueError('KPM rating-row call does not consume kpm_rating_visible')
    row_start = text.find(KPM_AF3_ROW_DEF_START)
    row_end = text.find(KPM_AF3_ROW_DEF_END)
    if row_start < 0 or row_end < row_start:
        raise ValueError('KPM rating-row definition missing')
    row = text[row_start:row_end]
    if '!Container.IsUpdating' in row:
        raise ValueError('Old unqualified Container.IsUpdating guard remains in KPM row definition')


def _insert_kpm_param_in_info_panel_call_0246(block: str, marker_start: str,
                                               marker_end: str, condition: str,
                                               occurrence: int = 1) -> str:
    calls = list(re.finditer(r'(?ms)<include content="Info_Panel"[^>]*>.*?</include>', block))
    if len(calls) < occurrence:
        raise ValueError('Info_Panel call occurrence {0} not found'.format(occurrence))
    match = calls[occurrence - 1]
    call = match.group(0)
    if marker_start in call or marker_end in call:
        if marker_start not in call or marker_end not in call:
            raise ValueError('Partial transient marker in Info_Panel call')
        return block
    # Place the guard after visible_meta when present; otherwise after visible.
    anchors = re.findall(r'(?m)^(?P<indent>[ \t]*)<param name="visible_meta">.*?</param>[ \t]*$', call)
    anchor_match = re.search(r'(?m)^(?P<indent>[ \t]*)<param name="visible_meta">.*?</param>[ \t]*$', call)
    if not anchor_match:
        anchor_match = re.search(r'(?m)^(?P<indent>[ \t]*)<param name="visible">.*?</param>[ \t]*$', call)
    if not anchor_match:
        raise ValueError('Info_Panel call visibility anchor not found')
    indent = anchor_match.group('indent')
    insertion = (
        '\n' + indent + marker_start +
        '\n' + indent + '<param name="kpm_rating_visible">' + condition + '</param>' +
        '\n' + indent + marker_end
    )
    call = call[:anchor_match.end()] + insertion + call[anchor_match.end():]
    return block[:match.start()] + call + block[match.end():]


def _patch_views_transient_guard_0246(text: str):
    original = text
    start, end, block = _find_xml_include_block_0187(text, 'View_Row_Info')
    if start < 0:
        raise ValueError('View_Row_Info include not found in Includes_Views.xml')
    block = _insert_kpm_param_in_info_panel_call_0246(
        block, KPM_TRANSIENT_VIEWS_START_0246, KPM_TRANSIENT_VIEWS_END_0246,
        '!Container.IsUpdating', 1,
    )
    text = text[:start] + block + text[end:]
    ET.fromstring(text)
    if text.count(KPM_TRANSIENT_VIEWS_START_0246) != 1 or text.count(KPM_TRANSIENT_VIEWS_END_0246) != 1:
        raise ValueError('Includes_Views transient marker missing or duplicated')
    if '<param name="kpm_rating_visible">!Container.IsUpdating</param>' not in block:
        raise ValueError('Includes_Views current-container guard missing')
    return text, text != original


def _patch_combined_views_transient_guard_0246(text: str):
    original = text
    start, end, block = _find_xml_include_block_0187(text, 'View_Combined_Info')
    if start < 0:
        raise ValueError('View_Combined_Info include not found')
    block = _insert_kpm_param_in_info_panel_call_0246(
        block, KPM_TRANSIENT_COMBINED_START_0246, KPM_TRANSIENT_COMBINED_END_0246,
        '!Container(53$PARAM[id]).IsUpdating', 1,
    )
    text = text[:start] + block + text[end:]
    ET.fromstring(text)
    if text.count(KPM_TRANSIENT_COMBINED_START_0246) != 1 or text.count(KPM_TRANSIENT_COMBINED_END_0246) != 1:
        raise ValueError('Includes_Views_Combined transient marker missing or duplicated')
    if '<param name="kpm_rating_visible">!Container(53$PARAM[id]).IsUpdating</param>' not in block:
        raise ValueError('Combined owner-container guard missing')
    return text, text != original


def _patch_hubs_transient_guard_0246(text: str):
    original = text
    specs = (
        ('Hub_Wall_Info', KPM_TRANSIENT_HUB_WALL_START_0246, KPM_TRANSIENT_HUB_WALL_END_0246,
         '!Container($PARAM[id]).IsUpdating', (1,)),
        ('Hub_Combined_Info', KPM_TRANSIENT_HUB_COMBINED_A_START_0246, KPM_TRANSIENT_HUB_COMBINED_A_END_0246,
         '!Container($PARAM[id]).IsUpdating', (1,)),
        ('Hub_Combined_Info', KPM_TRANSIENT_HUB_COMBINED_B_START_0246, KPM_TRANSIENT_HUB_COMBINED_B_END_0246,
         '!Container($PARAM[id]).IsUpdating', (2,)),
        ('Hub_Spotlight_Info', KPM_TRANSIENT_HUB_SPOTLIGHT_START_0246, KPM_TRANSIENT_HUB_SPOTLIGHT_END_0246,
         '!Container(301).IsUpdating', (1,)),
    )
    # Re-open each parent block after every replacement because offsets change.
    for include_name, marker_start, marker_end, condition, occurrences in specs:
        start, end, block = _find_xml_include_block_0187(text, include_name)
        if start < 0:
            raise ValueError(include_name + ' include not found')
        block = _insert_kpm_param_in_info_panel_call_0246(
            block, marker_start, marker_end, condition, occurrences[0],
        )
        text = text[:start] + block + text[end:]
    ET.fromstring(text)
    required = (
        (KPM_TRANSIENT_HUB_WALL_START_0246, KPM_TRANSIENT_HUB_WALL_END_0246),
        (KPM_TRANSIENT_HUB_COMBINED_A_START_0246, KPM_TRANSIENT_HUB_COMBINED_A_END_0246),
        (KPM_TRANSIENT_HUB_COMBINED_B_START_0246, KPM_TRANSIENT_HUB_COMBINED_B_END_0246),
        (KPM_TRANSIENT_HUB_SPOTLIGHT_START_0246, KPM_TRANSIENT_HUB_SPOTLIGHT_END_0246),
    )
    for start_marker, end_marker in required:
        if text.count(start_marker) != 1 or text.count(end_marker) != 1:
            raise ValueError('Includes_Hubs transient marker missing or duplicated: ' + start_marker)
    if text.count('<param name="kpm_rating_visible">!Container($PARAM[id]).IsUpdating</param>') != 3:
        raise ValueError('Hub owner-container guards are incomplete')
    if text.count('<param name="kpm_rating_visible">!Container(301).IsUpdating</param>') != 1:
        raise ValueError('Hub spotlight guard is missing')
    return text, text != original


def _rating_transient_targets_0246():
    return (
        ('Includes_Info.xml', _patch_info_transient_guard_0246),
        ('Includes_Views.xml', _patch_views_transient_guard_0246),
        ('Includes_Hubs.xml', _patch_hubs_transient_guard_0246),
        ('Includes_Views_Combined.xml', _patch_combined_views_transient_guard_0246),
    )


def _patch_rating_transient_xmls_0246() -> bool:
    staged = []
    paths = []
    for filename, patcher in _rating_transient_targets_0246():
        path = af3_path('1080i', filename)
        if not os.path.isfile(path):
            raise FileNotFoundError(filename + ' not found')
        original = read_text(path)
        updated, changed = patcher(original)
        staged.append((path, original, updated, changed))
        paths.append(path)
    if not any(item[3] for item in staged):
        return False
    snapshot('af3_unified_integration', paths)
    for path, original, updated, changed in staged:
        if changed:
            write_text(path, updated)
    return True


def _remove_marker_param_blocks_0246(text: str) -> str:
    pairs = (
        (KPM_TRANSIENT_INFO_META_PARAM_START_0246, KPM_TRANSIENT_INFO_META_PARAM_END_0246),
        (KPM_TRANSIENT_INFO_PANEL_PARAM_START_0246, KPM_TRANSIENT_INFO_PANEL_PARAM_END_0246),
        (KPM_TRANSIENT_INFO_PASS_START_0246, KPM_TRANSIENT_INFO_PASS_END_0246),
        (KPM_TRANSIENT_VIEWS_START_0246, KPM_TRANSIENT_VIEWS_END_0246),
        (KPM_TRANSIENT_COMBINED_START_0246, KPM_TRANSIENT_COMBINED_END_0246),
        (KPM_TRANSIENT_HUB_WALL_START_0246, KPM_TRANSIENT_HUB_WALL_END_0246),
        (KPM_TRANSIENT_HUB_COMBINED_A_START_0246, KPM_TRANSIENT_HUB_COMBINED_A_END_0246),
        (KPM_TRANSIENT_HUB_COMBINED_B_START_0246, KPM_TRANSIENT_HUB_COMBINED_B_END_0246),
        (KPM_TRANSIENT_HUB_SPOTLIGHT_START_0246, KPM_TRANSIENT_HUB_SPOTLIGHT_END_0246),
    )
    for marker_start, marker_end in pairs:
        text = re.sub(
            r'(?ms)^[ \t]*' + re.escape(marker_start) + r'.*?^[ \t]*' + re.escape(marker_end) + r'[ \t]*(?:\n|$)',
            '', text,
        )
    text = text.replace(
        '<param name="visible">[$PARAM[visible]] + [$PARAM[kpm_rating_visible]]</param>',
        '<param name="visible">$PARAM[visible]</param>',
    )
    return re.sub(r'\n{3,}', '\n\n', text)


def _remove_rating_transient_xmls_0246() -> bool:
    changed_any = False
    for filename, _patcher in _rating_transient_targets_0246():
        path = af3_path('1080i', filename)
        if not os.path.isfile(path):
            continue
        original = read_text(path)
        updated = _remove_marker_param_blocks_0246(original)
        if updated != original:
            ET.fromstring(updated)
            write_text(path, updated)
            changed_any = True
    return changed_any


def _validate_rating_transient_files_0246(info: str, views: str, hubs: str, combined: str) -> None:
    _validate_info_transient_guard_0246(info)
    _patch_views_transient_guard_0246(views)
    _patch_hubs_transient_guard_0246(hubs)
    _patch_combined_views_transient_guard_0246(combined)


# New files are exported by future diagnostics so this guard can be verified
# from the actual installed XML instead of inferred from screenshots.
AF3_FULL_CONTEXT_XMLS = tuple(dict.fromkeys(AF3_FULL_CONTEXT_XMLS + (
    'Includes_Views.xml', 'Includes_Hubs.xml', 'Includes_Views_Combined.xml',
    'Includes_Background.xml', 'Includes_Constants.xml', 'Font.xml',
    'DialogExtendedProgressBar.xml',
)))


_apply_af3_unified_integration_0246_base = apply_af3_unified_integration

def apply_af3_unified_integration() -> Result:
    result = _apply_af3_unified_integration_0246_base()
    if result.status not in ('Patched', 'Skipped'):
        return result
    try:
        transient_changed = _patch_rating_transient_xmls_0246()
    except Exception as exc:
        log('Owner-container rating guard refused: {0}'.format(exc))
        return Result('AF3 Unified Integration', 'Skipped', result.detail + '\nOwner-container guard refused: ' + str(exc))
    if transient_changed:
        _reload_skin_after_patch()
        return Result('AF3 Unified Integration', 'Patched', result.detail + ' Rating rows now use exact owner-container loading guards.')
    return result


_remove_af3_unified_integration_0246_base = remove_af3_unified_integration

def remove_af3_unified_integration() -> Result:
    transient_changed = _remove_rating_transient_xmls_0246()
    result = _remove_af3_unified_integration_0246_base()
    if transient_changed and result.status != 'Removed':
        _reload_skin_after_patch()
        return Result('AF3 Unified Integration', 'Removed', 'Owner-container rating guards removed.')
    return result


def _validate_af3_unified_current_0246(info_text: str, layouts_text: str,
                                       images_text: str, screen_text: str,
                                       background_text: str, views_text: str,
                                       hubs_text: str, combined_text: str) -> None:
    for value in (info_text, layouts_text, images_text, screen_text, background_text, views_text, hubs_text, combined_text):
        ET.fromstring(value)
    _validate_kpm_rating_row_placement_0236(info_text)
    _validate_steam_game_plot_0237(info_text)
    _validate_info_transient_guard_0246(info_text)
    _validate_expanded_episode_rating_0244(layouts_text)
    _validate_current_screensaver_0233(screen_text)
    checked_images, images_changed = _patch_startup_weather_fallback_text_0237(images_text)
    if images_changed or checked_images != images_text:
        raise ValueError('Startup weather fallback is not current')
    background_check, background_changed = _patch_startup_slideshow_0245(background_text)
    if background_changed or background_check != background_text:
        raise ValueError('Startup slideshow is not current')
    checked_views, changed_views = _patch_views_transient_guard_0246(views_text)
    checked_hubs, changed_hubs = _patch_hubs_transient_guard_0246(hubs_text)
    checked_combined, changed_combined = _patch_combined_views_transient_guard_0246(combined_text)
    if changed_views or checked_views != views_text:
        raise ValueError('Includes_Views owner-container guard is not current')
    if changed_hubs or checked_hubs != hubs_text:
        raise ValueError('Includes_Hubs owner-container guards are not current')
    if changed_combined or checked_combined != combined_text:
        raise ValueError('Includes_Views_Combined owner-container guard is not current')


def status_af3_unified_integration() -> str:
    names = (
        'Includes_Info.xml', 'Includes_Layouts.xml', 'Includes_Images.xml',
        'screensaver-arctic-mirage.xml', 'Includes_Background.xml',
        'Includes_Views.xml', 'Includes_Hubs.xml', 'Includes_Views_Combined.xml',
    )
    try:
        values = []
        missing = []
        for name in names:
            path = af3_path('1080i', name)
            if not os.path.isfile(path):
                missing.append(name)
            else:
                values.append(read_text(path))
        if missing:
            return 'Not patched (missing: {0})'.format(', '.join(missing))
        _validate_af3_unified_current_0246(*values)
        return 'Patched (current 0189/0233/0237/0244/0245/0246)'
    except Exception as exc:
        return 'Not patched (current validation: {0})'.format(exc)

# -----------------------------------------------------------------------------
# v0.2.47 - strict MyVideoNav loading guard and movie-collection aggregates
# -----------------------------------------------------------------------------
KPM_COLLECTION_INFO_LINE_START_0247 = '<!-- KPM-AF3-COLLECTION-INFO-LINE-START-0247 -->'
KPM_COLLECTION_INFO_LINE_END_0247 = '<!-- KPM-AF3-COLLECTION-INFO-LINE-END-0247 -->'
KPM_COLLECTION_PLOT_START_0247 = '<!-- KPM-AF3-COLLECTION-PLOT-START-0247 -->'
KPM_COLLECTION_PLOT_END_0247 = '<!-- KPM-AF3-COLLECTION-PLOT-END-0247 -->'
KPM_COLLECTION_INFO_VISIBLE_TOKEN_0247 = 'String.IsEqual(Window(Home).Property(LibraryRatings.Collection.Visible),true)'
KPM_MEDIA_LOADING_CONDITION_0247 = '![Container(500).IsUpdating | Container(501).IsUpdating | Container(502).IsUpdating | Container(503).IsUpdating | Container(504).IsUpdating | Container(505).IsUpdating | Container(506).IsUpdating | Container(507).IsUpdating | Container(508).IsUpdating | Container(509).IsUpdating | Container(510).IsUpdating | Container(511).IsUpdating | Container(512).IsUpdating | Container(513).IsUpdating | Container(514).IsUpdating | Container(520).IsUpdating | Container(521).IsUpdating | Container(522).IsUpdating | Container(523).IsUpdating | Container(524).IsUpdating | Container(526).IsUpdating | Container(528).IsUpdating | Container(549).IsUpdating]'

_KPM_COLLECTION_EXCLUSION_0247 = '!String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) + !String.IsEqual($PARAM[container]$PARAM[listitem].DBType,collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(DBTYPE),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(dbtype),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),set) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(MediaType),collection) + !String.IsEqual($PARAM[container]$PARAM[listitem].Property(is_collection),true)'

_KPM_ROW_DEF_BLOCK_0246 = _kpm_row_def_block

def _kpm_row_def_block() -> str:
    block = _KPM_ROW_DEF_BLOCK_0246()
    if _KPM_COLLECTION_EXCLUSION_0247 not in block:
        raise ValueError('Collection exclusion contract missing from KPM rating row')
    allow_collection = '[[' + _KPM_COLLECTION_EXCLUSION_0247 + '] | ' + KPM_COLLECTION_INFO_VISIBLE_TOKEN_0247 + ']'
    return block.replace(_KPM_COLLECTION_EXCLUSION_0247, allow_collection)


def _strip_marker_block_0247(text: str, start: str, end: str) -> str:
    return re.sub(
        r'(?ms)^[ \t]*' + re.escape(start) + r'.*?^[ \t]*' + re.escape(end) + r'[ \t]*(?:\n|$)',
        '', text,
    )


def _patch_views_transient_guard_0246(text: str):
    original = text
    start, end, block = _find_xml_include_block_0187(text, 'View_Row_Info')
    if start < 0:
        raise ValueError('View_Row_Info include not found in Includes_Views.xml')
    block = _strip_marker_block_0247(block, KPM_TRANSIENT_VIEWS_START_0246, KPM_TRANSIENT_VIEWS_END_0246)
    block = _insert_kpm_param_in_info_panel_call_0246(
        block, KPM_TRANSIENT_VIEWS_START_0246, KPM_TRANSIENT_VIEWS_END_0246,
        KPM_MEDIA_LOADING_CONDITION_0247, 1,
    )
    text = text[:start] + block + text[end:]
    ET.fromstring(text)
    if text.count(KPM_TRANSIENT_VIEWS_START_0246) != 1 or text.count(KPM_TRANSIENT_VIEWS_END_0246) != 1:
        raise ValueError('Includes_Views transient marker missing or duplicated')
    expected = '<param name="kpm_rating_visible">' + KPM_MEDIA_LOADING_CONDITION_0247 + '</param>'
    if expected not in block:
        raise ValueError('Includes_Views explicit media-container guard missing')
    return text, text != original


def _collection_info_line_block_0247(indent: str = '                    ') -> str:
    visible = '[String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,collection)] + ' + KPM_COLLECTION_INFO_VISIBLE_TOKEN_0247
    return '\n'.join([
        indent + KPM_COLLECTION_INFO_LINE_START_0247,
        indent + '<include content="Info_Line_Pill_Icon">',
        indent + '    <param name="colordiffuse">$PARAM[colordiffuse]</param>',
        indent + '    <param name="icon">flags/info-inverted.png</param>',
        indent + '    <param name="visible">' + visible + '</param>',
        indent + '</include>',
        indent + '<include content="Info_Line_StarRating" condition="!Skin.HasSetting(InfoTags.DisableStarRating)">',
        indent + '    <param name="colordiffuse">$PARAM[colordiffuse]</param>',
        indent + '    <param name="rating">Window(Home).Property(LibraryRatings.Collection.StarRating)</param>',
        indent + '    <param name="visible">' + visible + ' + !String.IsEmpty(Window(Home).Property(LibraryRatings.Collection.StarRating))</param>',
        indent + '</include>',
        indent + '<include content="Info_Line_Label">',
        indent + '    <param name="colordiffuse">$PARAM[colordiffuse]</param>',
        indent + '    <param name="label">$INFO[Window(Home).Property(LibraryRatings.Collection.YearRange)]</param>',
        indent + '    <param name="visible">' + visible + ' + !String.IsEmpty(Window(Home).Property(LibraryRatings.Collection.YearRange))</param>',
        indent + '</include>',
        indent + '<include content="Info_Line_Label">',
        indent + '    <param name="colordiffuse">$PARAM[colordiffuse]</param>',
        indent + '    <param name="label">$INFO[Window(Home).Property(LibraryRatings.Collection.RuntimeDisplay)]</param>',
        indent + '    <param name="visible">' + visible + ' + !String.IsEmpty(Window(Home).Property(LibraryRatings.Collection.RuntimeDisplay))</param>',
        indent + '</include>',
        indent + KPM_COLLECTION_INFO_LINE_END_0247,
    ])


def _collection_plot_block_0247(indent: str = '        ') -> str:
    visible = '$PARAM[visible] + ![$PARAM[override]] + [String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,collection)] + ' + KPM_COLLECTION_INFO_VISIBLE_TOKEN_0247
    return '\n'.join([
        indent + KPM_COLLECTION_PLOT_START_0247,
        indent + '<control type="group">',
        indent + '    <visible>' + visible + '</visible>',
        indent + '    <height>120</height>',
        indent + '    <control type="label">',
        indent + '        <top>0</top>',
        indent + '        <left>40</left>',
        indent + '        <height>40</height>',
        indent + '        <width>$PARAM[width]</width>',
        indent + '        <font>font_main_bold</font>',
        indent + '        <textcolor>$PARAM[colordiffuse]_90</textcolor>',
        indent + '        <label>$INFO[Window(Home).Property(LibraryRatings.Collection.DisplayTagline)]</label>',
        indent + '        <visible>!String.IsEmpty(Window(Home).Property(LibraryRatings.Collection.DisplayTagline))</visible>',
        indent + '    </control>',
        indent + '    <include content="Info_Plot_TextBox">',
        indent + '        <param name="label">$INFO[Window(Home).Property(LibraryRatings.Collection.Plot)]</param>',
        indent + '        <param name="colordiffuse">$PARAM[colordiffuse]</param>',
        indent + '        <param name="use_textbox">$PARAM[use_textbox]</param>',
        indent + '        <param name="height">80</param>',
        indent + '        <param name="width">$PARAM[width]</param>',
        indent + '        <param name="top">40</param>',
        indent + '    </include>',
        indent + '</control>',
        indent + KPM_COLLECTION_PLOT_END_0247,
    ])



_KPM_COLLECTION_NATIVE_EXCLUSION_0248 = ' + !String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) + !String.IsEqual($PARAM[container]$PARAM[listitem].DBType,collection)'


def _suppress_native_collection_info_0248(info_line: str) -> str:
    """Hide AF3's native set info pill and native ListItem star pair.

    The aggregate KPM/LRS line remains the only collection line. This function
    changes only the three native visibility parameters and is idempotent.
    """
    bases = (
        'String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform))',
        'String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].Rating) + String.IsEmpty($PARAM[container]$PARAM[listitem].UserRating)',
        'String.IsEmpty($PARAM[container]$PARAM[listitem].Property(platform)) + !String.IsEmpty($PARAM[container]$PARAM[listitem].UserRating)',
    )
    for base in bases:
        old = '<param name="visible">' + base + '</param>'
        new = '<param name="visible">' + base + _KPM_COLLECTION_NATIVE_EXCLUSION_0248 + '</param>'
        if new in info_line:
            continue
        if old not in info_line:
            raise ValueError('Native collection visibility anchor missing: ' + base)
        info_line = info_line.replace(old, new, 1)
    return info_line

def _patch_collection_info_text_0247(text: str):
    original = text
    # Upgrade an installed 0.2.47 skin from the removed KPM mirror to the
    # direct LRS property namespace before normalizing the marker blocks.
    text = text.replace(
        'Window(Home).Property(KPM.Collection.',
        'Window(Home).Property(LibraryRatings.Collection.',
    )
    # Upgrade an already-current 0.2.46 row as well. The 0.2.46 transient
    # patch normalizes visibility parameters but does not regenerate a row that
    # was already present, so the collection allowance must be applied here.
    row_start_0247 = text.find(KPM_AF3_ROW_DEF_START)
    row_end_0247 = text.find(KPM_AF3_ROW_DEF_END)
    current_row_0247 = text[row_start_0247:row_end_0247] if row_start_0247 >= 0 and row_end_0247 > row_start_0247 else ''
    if KPM_COLLECTION_INFO_VISIBLE_TOKEN_0247 not in current_row_0247:
        text, _row_changed_0247 = _patch_kpm_rating_row_info_xml(text)
    text = _strip_marker_block_0247(text, KPM_COLLECTION_INFO_LINE_START_0247, KPM_COLLECTION_INFO_LINE_END_0247)
    text = _strip_marker_block_0247(text, KPM_COLLECTION_PLOT_START_0247, KPM_COLLECTION_PLOT_END_0247)

    start, end, info_line = _find_xml_include_block_0187(text, 'Info_Line')
    if start < 0:
        raise ValueError('Info_Line include not found')
    visible_match = re.search(r'(?m)^\s*<visible>.*DBType,movie\).*\$PARAM\[override\].*</visible>\s*$', info_line)
    if not visible_match:
        raise ValueError('Info_Line media visibility contract not found')
    visible_line = visible_match.group(0)
    if KPM_COLLECTION_INFO_VISIBLE_TOKEN_0247 not in visible_line:
        replacement = visible_line.replace('$PARAM[override]]</visible>', '$PARAM[override] | [[String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,collection)] + ' + KPM_COLLECTION_INFO_VISIBLE_TOKEN_0247 + ']]</visible>')
        if replacement == visible_line:
            raise ValueError('Info_Line collection visibility insertion point missing')
        info_line = info_line[:visible_match.start()] + replacement + info_line[visible_match.end():]
    anchor = '<!-- KPM-AF3-STEAM-INFO-LINE-START-0189 -->'
    if anchor not in info_line:
        raise ValueError('Steam info-line anchor missing')
    info_line = info_line.replace(anchor, _collection_info_line_block_0247() + '\n' + anchor, 1)
    info_line = _suppress_native_collection_info_0248(info_line)
    text = text[:start] + info_line + text[end:]

    start, end, plot_main = _find_xml_include_block_0187(text, 'Info_Plot_Main')
    if start < 0:
        raise ValueError('Info_Plot_Main include not found')
    movie_anchor = '<!-- Movie -->'
    if movie_anchor not in plot_main:
        raise ValueError('Info_Plot_Main movie anchor missing')
    plot_main = plot_main.replace(movie_anchor, _collection_plot_block_0247() + '\n' + movie_anchor, 1)
    text = text[:start] + plot_main + text[end:]

    start, end, plot_other = _find_xml_include_block_0187(text, 'Info_Plot_Other')
    if start < 0:
        raise ValueError('Info_Plot_Other include not found')
    other_visible = re.search(r'(?m)^\s*<visible>!\[String\.IsEqual\(\$PARAM\[container\].*?</visible>\s*$', plot_other)
    if not other_visible:
        raise ValueError('Info_Plot_Other exclusion contract not found')
    line = other_visible.group(0)
    set_clause = ' | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,set) | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,collection)'
    if 'DBType,set)' not in line:
        line = line.replace(' | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,song)', ' | String.IsEqual($PARAM[container]$PARAM[listitem].DBType,song)' + set_clause)
        plot_other = plot_other[:other_visible.start()] + line + plot_other[other_visible.end():]
    text = text[:start] + plot_other + text[end:]
    text = re.sub(r'\n{3,}', '\n\n', text)
    ET.fromstring(text)
    _validate_collection_info_0247(text)
    return text, text != original


def _validate_collection_info_0247(text: str) -> None:
    ET.fromstring(text)
    for marker in (
        KPM_COLLECTION_INFO_LINE_START_0247, KPM_COLLECTION_INFO_LINE_END_0247,
        KPM_COLLECTION_PLOT_START_0247, KPM_COLLECTION_PLOT_END_0247,
    ):
        if text.count(marker) != 1:
            raise ValueError('Collection marker missing or duplicated: ' + marker)
    for token in (
        'Window(Home).Property(LibraryRatings.Collection.StarRating)',
        'Window(Home).Property(LibraryRatings.Collection.YearRange)',
        'Window(Home).Property(LibraryRatings.Collection.RuntimeDisplay)',
        'Window(Home).Property(LibraryRatings.Collection.DisplayTagline)',
        'Window(Home).Property(LibraryRatings.Collection.Plot)',
    ):
        if token not in text:
            raise ValueError('Collection info token missing: ' + token)
    row_start = text.find(KPM_AF3_ROW_DEF_START)
    row_end = text.find(KPM_AF3_ROW_DEF_END)
    if row_start < 0 or row_end < row_start:
        raise ValueError('KPM rating-row definition missing')
    row = text[row_start:row_end]
    if KPM_COLLECTION_INFO_VISIBLE_TOKEN_0247 not in row:
        raise ValueError('Collection rating-row allowance missing')
    if 'Window(Home).Property(KPM.Collection.' in text:
        raise ValueError('Legacy KPM collection mirror token remains')
    if text.count(_KPM_COLLECTION_NATIVE_EXCLUSION_0248) < 3:
        raise ValueError('Native collection info/star suppression is incomplete')
    plot_start = text.find(KPM_COLLECTION_PLOT_START_0247)
    plot_end = text.find(KPM_COLLECTION_PLOT_END_0247)
    plot_block = text[plot_start:plot_end] if plot_start >= 0 and plot_end > plot_start else ''
    if '$PARAM[container]$PARAM[listitem].Plot' in plot_block:
        raise ValueError('Collection plot still reads native ListItem.Plot')


def _patch_collection_info_file_0247() -> bool:
    path = af3_path('1080i', 'Includes_Info.xml')
    if not os.path.isfile(path):
        raise FileNotFoundError('Includes_Info.xml not found')
    original = read_text(path)
    updated, changed = _patch_collection_info_text_0247(original)
    if changed:
        snapshot('af3_unified_integration', [path])
        write_text(path, updated)
    return changed


def _remove_collection_info_0247() -> bool:
    path = af3_path('1080i', 'Includes_Info.xml')
    if not os.path.isfile(path):
        return False
    original = read_text(path)
    text = _strip_marker_block_0247(original, KPM_COLLECTION_INFO_LINE_START_0247, KPM_COLLECTION_INFO_LINE_END_0247)
    text = _strip_marker_block_0247(text, KPM_COLLECTION_PLOT_START_0247, KPM_COLLECTION_PLOT_END_0247)
    # Base removal later restores the complete native KPM row and panel files.
    if text != original:
        ET.fromstring(text)
        write_text(path, text)
        return True
    return False


_apply_af3_unified_integration_0247_base = apply_af3_unified_integration

def apply_af3_unified_integration() -> Result:
    result = _apply_af3_unified_integration_0247_base()
    if result.status not in ('Patched', 'Skipped'):
        return result
    try:
        collection_changed = _patch_collection_info_file_0247()
    except Exception as exc:
        log('Collection aggregate visual patch refused: {0}'.format(exc))
        return Result('AF3 Unified Integration', 'Skipped', result.detail + '\nCollection visual refused: ' + str(exc))
    if collection_changed:
        _reload_skin_after_patch()
        return Result('AF3 Unified Integration', 'Patched', result.detail + ' Collection aggregates and strict media loading guard applied.')
    return result


_remove_af3_unified_integration_0247_base = remove_af3_unified_integration

def remove_af3_unified_integration() -> Result:
    collection_changed = _remove_collection_info_0247()
    result = _remove_af3_unified_integration_0247_base()
    if collection_changed and result.status != 'Removed':
        _reload_skin_after_patch()
        return Result('AF3 Unified Integration', 'Removed', 'Collection aggregate visuals removed.')
    return result


_status_af3_unified_integration_0247_base = status_af3_unified_integration

def status_af3_unified_integration() -> str:
    result = _status_af3_unified_integration_0247_base()
    if not result.startswith('Patched'):
        return result
    try:
        info_text = read_text(af3_path('1080i', 'Includes_Info.xml'))
        views_text = read_text(af3_path('1080i', 'Includes_Views.xml'))
        _validate_collection_info_0247(info_text)
        checked, changed = _patch_views_transient_guard_0246(views_text)
        if changed or checked != views_text:
            raise ValueError('MyVideoNav explicit media-container guard is not current')
        return 'Patched (current 0189/0233/0237/0244/0245/0246/0247/0248/0250)'
    except Exception as exc:
        return 'Not patched (0248 validation: {0})'.format(exc)


# -----------------------------------------------------------------------------
# v0.2.49 - collection-count diagnostics and slot-order validation
# -----------------------------------------------------------------------------
_KPM_RATING_ROW_RUNTIME_0249_BASE = _rating_row_runtime_0188

def _rating_row_runtime_0188() -> Dict[str, object]:
    report = _KPM_RATING_ROW_RUNTIME_0249_BASE()
    report['collection_source'] = _home_prop_snapshot_0188(
        'LibraryRatings.Collection.',
        ('Visible', 'ItemKey', 'IDSet', 'Title', 'Plot', 'DisplayTagline', 'MemberCount', 'StarRating', 'UpdatedAt'),
    )
    return report


_KPM_LIVE_ISSUES_0249_BASE = _live_consistency_issues_0189

def _live_consistency_issues_0189(sample: Dict[str, object]) -> list:
    issues = list(_KPM_LIVE_ISSUES_0249_BASE(sample))
    row = sample.get('kpm_rating_row', {}) or {}
    item_type = str(row.get('ItemType') or '').strip().lower()
    active_slots = row.get('active_slots', {}) or row.get('slots', {}) or {}
    nonempty = [slot for slot in active_slots.values() if (slot or {}).get('Label')]
    count_slots = [slot for slot in nonempty if str((slot or {}).get('Source') or '').strip().lower() == 'collection_count']
    collection = row.get('collection_source', {}) or {}
    source_visible = str(collection.get('Visible') or '').strip().lower() == 'true'
    source_key = str(collection.get('ItemKey') or '').strip()
    row_key = str(row.get('ItemKey') or '').strip()
    try:
        member_count = int(float(str(collection.get('MemberCount') or '0').strip()))
    except Exception:
        member_count = 0
    expected = item_type in ('set', 'collection') and source_visible and source_key and source_key == row_key and member_count > 0
    if expected:
        expected_label = '{0} Film{1}'.format(member_count, '' if member_count == 1 else 's')
        if len(count_slots) != 1:
            issues.append('collection_count_slot_missing_or_duplicated')
        else:
            slot = count_slots[0]
            if nonempty[-1] is not slot:
                issues.append('collection_count_slot_not_last')
            if str(slot.get('IconFile') or '') != 'sets.png':
                issues.append('collection_count_icon_invalid')
            if str(slot.get('Label') or '') != expected_label:
                issues.append('collection_count_label_invalid')
    elif count_slots:
        issues.append('stale_collection_count_slot')
    return sorted(set(issues))

Kodi Patch Manager v0.1.39

New in v0.1.39:
- Independent Fanart Engine now uses AF3 source-bridge mode.
- KPM still selects random fanart from Artwork Curator artwork-cache.db.
- AF3/TMDbHelper still renders native blur, flixart placement, vignette, dim and overlay effects.
- Old direct KPM fanart values in Includes_Images.xml are removed to prevent ghost/double fanart layers.
- KPM does not patch TMDbHelper imgmon.py/images.py for random fanart. It only supplies the selected URL into AF3's existing blur source/fallback pipeline.

Main menu:
- Apply Recommended Patch
- Remove Recommended Patch
- Patch Status
- Diagnostics
- Clear Add-on Icon Cache
- Advanced Patches
- Settings
- Exit

Recommended workflow:
1. Install this zip.
2. Run Kodi Patch Manager > Apply Recommended Patch.
3. Restart Kodi once so service.py v0.1.39 replaces any older running service.

Notes:
- Independent fanart uses Artwork Curator / LAC artwork-cache.db read-only.
- Episode and season fanart fall back to parent TV show fanart through MyVideos DB mapping.
- Launch fallback can use random movie/TV fanart URL from artwork-cache.db; Kodi handles texture cache normally.
- Reliable Studio Logos remains single-logo only through KPM.StudioLogo.1.

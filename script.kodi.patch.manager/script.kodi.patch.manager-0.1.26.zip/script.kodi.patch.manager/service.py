# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import re
import time
import traceback
from urllib.parse import unquote

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # pragma: no cover outside Kodi
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

ADDON_ID = 'script.kodi.patch.manager'
ADDON_NAME = 'Kodi Patch Manager'
ACTIVE_PROP = 'KPM.Service.Active.v0126'
ARMED_PROP = 'KPM.ResumeCloseService.Armed'
ARMED_DIALOG_PROP = 'KPM.ResumeCloseService.ArmedDialogId'
PAUSE_SINCE_PROP = 'KPM.ResumeCloseService.PauseSince'
LAST_FOREIGN_DIALOG_PROP = 'KPM.ResumeCloseService.LastForeignDialogId'
LOG_PREFIX = '[Kodi Patch Manager Service v0.1.26] '

NO_DIALOG_ID = 9999
KNOWN_OSD_DIALOG_IDS = {9999, 12901, 10142}
AUTO_OPEN_GRACE_SECONDS = 0.0
STARTUP_AUTO_DIALOG_GUARD_SECONDS = 0.85
STARTUP_GUARD_WINDOW_SECONDS = 3.0
STUDIO_RESOURCE_ID = 'resource.images.studios.coloured'
STUDIO_PROP_PREFIX = 'KPM.StudioLogo.'
STUDIO_NAME_PROP_PREFIX = 'KPM.StudioLogoName.'
STUDIO_COUNT_PROP = 'KPM.StudioLogos.Count'
STUDIO_AVAILABLE_PROP = 'KPM.StudioLogos.Available'
STUDIO_STATUS_PROP = 'KPM.StudioLogos.Status'
STUDIO_CANDIDATES_PROP = 'KPM.StudioLogos.Candidates'
STUDIO_RESOLVED_PROP = 'KPM.StudioLogos.Resolved'
STUDIO_MISSING_PROP = 'KPM.StudioLogos.Missing'
STUDIO_UPDATED_AT_PROP = 'KPM.StudioLogos.UpdatedAt'
STUDIO_CACHE_PROP = 'KPM.StudioLogos.Cache'
STUDIO_INDEX_BUILD_MS_PROP = 'KPM.StudioLogos.IndexBuildMs'
STUDIO_RESOLVE_LAST_MS_PROP = 'KPM.StudioLogos.ResolveLastMs'
STUDIO_RESOLVE_MAX_MS_PROP = 'KPM.StudioLogos.ResolveMaxMs'
STUDIO_RESOLVE_COUNT_PROP = 'KPM.StudioLogos.ResolveCount'
STUDIO_BROKEN_SKIPPED_PROP = 'KPM.StudioLogos.BrokenSkipped'
STUDIO_DEBUG_PROP = 'KPM.StudioLogos.Debug'
STUDIO_RESOLVE_INTERVAL_SECONDS = 0.65
STUDIO_EMPTY_CLEAR_SECONDS = 1.25
BROKEN_STUDIO_TEXTURE_NAMES = {
    'centropolis entertainment.png',
    'dune entertainment.png',
    'gk films.png',
    'thunder road.png',
}


def translate(path: str) -> str:
    if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if xbmc and hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return path


def log(message: str, level=None) -> None:
    if xbmc:
        xbmc.log(LOG_PREFIX + message, level or xbmc.LOGINFO)
    else:
        print(LOG_PREFIX + message)


def cond(expression: str) -> bool:
    try:
        return bool(xbmc.getCondVisibility(expression)) if xbmc else False
    except Exception:
        return False


def info(label: str) -> str:
    try:
        return xbmc.getInfoLabel(label).strip() if xbmc else ''
    except Exception:
        return ''


def home_prop(name: str) -> str:
    try:
        return xbmcgui.Window(10000).getProperty(name) if xbmcgui else ''
    except Exception:
        return ''


def set_home_prop(name: str, value: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).setProperty(name, value)
    except Exception:
        pass


def clear_home_prop(name: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).clearProperty(name)
    except Exception:
        pass


def current_window_id() -> int:
    try:
        return int(xbmcgui.getCurrentWindowId()) if xbmcgui else -1
    except Exception:
        return -1


def current_dialog_id() -> int:
    try:
        return int(xbmcgui.getCurrentWindowDialogId()) if xbmcgui else NO_DIALOG_ID
    except Exception:
        return NO_DIALOG_ID


def addon_data_path(*parts: str) -> str:
    base = translate(f'special://profile/addon_data/{ADDON_ID}')
    return os.path.join(base, *parts)


def state_file(patch_id: str) -> str:
    return addon_data_path('state', f'{patch_id}.json')


def load_json_file(path: str) -> dict:
    with open(path, 'r', encoding='utf-8', errors='replace') as handle:
        return json.load(handle)


def patch_state_enabled(patch_id: str) -> bool:
    return os.path.exists(state_file(patch_id))


def pause_patch_enabled() -> bool:
    path = state_file('vfs_pause_ratings')
    if not os.path.exists(path):
        return False
    try:
        data = load_json_file(path)
        return bool(data.get('auto_videoosd') and data.get('pause_stay_until_resume'))
    except Exception:
        return True


def studio_patch_enabled() -> bool:
    return patch_state_enabled('reliable_studio_logos')


def load_kpm_settings() -> dict:
    data = {'studio_logo_count': 1, 'studio_debug': False}
    path = addon_data_path('settings.json')
    if os.path.exists(path):
        try:
            loaded = load_json_file(path)
            if isinstance(loaded, dict):
                data.update(loaded)
        except Exception:
            pass
    try:
        count = int(data.get('studio_logo_count', 1))
    except Exception:
        count = 1
    data['studio_logo_count'] = max(1, min(3, count))
    return data


def is_foreign_dialog(active_dialog_id: int) -> bool:
    return active_dialog_id not in KNOWN_OSD_DIALOG_IDS


def close_video_osd_safely() -> None:
    try:
        xbmc.executebuiltin('CancelAlarm(osd_timeout,true)')
        xbmc.executebuiltin('Dialog.Close(videoosd,true)')
        xbmc.executebuiltin('ActivateWindow(fullscreenvideo)')
    except Exception:
        log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def _read_xbt_filenames(path: str) -> list[str]:
    try:
        with open(path, 'rb') as handle:
            data = handle.read()
    except Exception:
        return []
    names = []
    # Kodi XBTF2 texture packs used by the studio resources have a 5-byte magic,
    # a 4-byte little-endian file count, then 304-byte file records with a
    # null-terminated 256-byte filename at the start of each record.
    if data.startswith(b'XBTF2') and len(data) >= 9:
        try:
            count = int.from_bytes(data[5:9], 'little')
            step = 304
            start = 9
            for idx in range(count):
                off = start + idx * step
                raw = data[off:off + 256]
                if not raw:
                    break
                name = raw.split(b'\x00', 1)[0].decode('utf-8', 'ignore').strip()
                if name.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                    names.append(name.replace('\\', '/'))
            if names:
                return names
        except Exception:
            pass
    # Conservative fallback: scan the header/table for image-looking strings.
    for match in re.finditer(rb'([A-Za-z0-9][A-Za-z0-9 _.,&+!\'()\-]{1,180}\.(?:png|jpg|jpeg|webp))\x00', data[:4_000_000], re.I):
        try:
            names.append(match.group(1).decode('utf-8', 'ignore').strip().replace('\\', '/'))
        except Exception:
            pass
    return list(dict.fromkeys(names))


def _walk_resource_images(resource_dir: str) -> list[str]:
    found = []
    for root, _dirs, files in os.walk(resource_dir):
        for filename in files:
            if filename.lower().endswith(('.png', '.jpg', '.jpeg', '.webp')):
                rel = os.path.relpath(os.path.join(root, filename), resource_dir).replace('\\', '/')
                found.append(rel)
    return found


def _strip_ext(name: str) -> str:
    base = os.path.basename(name.replace('\\', '/'))
    return re.sub(r'\.(png|jpg|jpeg|webp)$', '', base, flags=re.I).strip()


def _simple_key(value: str) -> str:
    value = unquote(value or '').lower().strip()
    value = value.replace('&', ' and ').replace('+', ' plus ')
    value = re.sub(r'\([^)]*\)', ' ', value)
    value = re.sub(r'[^a-z0-9]+', ' ', value)
    value = re.sub(r'\s+', ' ', value).strip()
    return value


def _drop_company_suffixes(key: str) -> str:
    suffixes = {
        'ltd', 'limited', 'inc', 'llc', 'gmbh', 'ag', 's a', 'sa', 's r l', 'srl',
        'co', 'company', 'corp', 'corporation', 'productions', 'production',
        'pictures', 'picture', 'films', 'film', 'studios', 'studio', 'entertainment'
    }
    parts = key.split()
    while parts and ' '.join(parts[-3:]) in suffixes:
        parts = parts[:-3]
    while parts and ' '.join(parts[-2:]) in suffixes:
        parts = parts[:-2]
    while parts and parts[-1] in suffixes:
        parts = parts[:-1]
    return ' '.join(parts).strip()


def _logo_keys(name: str) -> list[str]:
    raw = _strip_ext(name)
    raw = unquote(raw).strip()
    variants = [raw]
    variants.append(re.sub(r'\s*\([^)]*\)\s*$', '', raw).strip())
    variants.append(raw.replace(' Ltd.', '').replace(' Ltd', '').replace(' Inc.', '').replace(' Inc', '').replace(' LLC', '').strip())
    keys = []
    for variant in variants:
        key = _simple_key(variant)
        if key:
            keys.append(key)
            short = _drop_company_suffixes(key)
            if short and short != key:
                keys.append(short)
    alias_map = {
        'prime video': 'amazon prime video',
        'amazon video': 'amazon prime video',
        'fox searchlight': 'fox searchlight pictures',
        'searchlight': 'searchlight pictures',
        'lucasfilm ltd': 'lucasfilm',
    }
    for key in list(keys):
        alias = alias_map.get(key)
        if alias:
            keys.append(alias)
    return list(dict.fromkeys(keys))



def _studio_index_cache_path() -> str:
    return addon_data_path('cache', 'studio-logo-index-coloured-v2.json')


def _file_signature(path: str) -> dict:
    try:
        return {
            'path': path,
            'size': int(os.path.getsize(path)),
            'mtime': float(os.path.getmtime(path)),
        }
    except Exception:
        return {'path': path, 'size': -1, 'mtime': -1.0}


def _load_cached_studio_index(texture_path: str) -> dict[str, str]:
    cache_path = _studio_index_cache_path()
    if not os.path.exists(cache_path):
        return {}
    try:
        data = load_json_file(cache_path)
        if not isinstance(data, dict):
            return {}
        if data.get('resource_id') != STUDIO_RESOURCE_ID:
            return {}
        if data.get('texture_signature') != _file_signature(texture_path):
            return {}
        index = data.get('index')
        if not isinstance(index, dict):
            return {}
        set_home_prop(STUDIO_AVAILABLE_PROP, str(int(data.get('file_count', 0))))
        set_home_prop(STUDIO_STATUS_PROP, 'ready')
        set_home_prop(STUDIO_CACHE_PROP, 'hit')
        set_home_prop(STUDIO_INDEX_BUILD_MS_PROP, '0')
        set_home_prop(STUDIO_BROKEN_SKIPPED_PROP, str(int(data.get('broken_skipped', 0))))
        log(f'studio logo index cache hit; files={data.get("file_count", 0)}, keys={len(index)}')
        return {str(k): str(v) for k, v in index.items()}
    except Exception:
        return {}


def _save_cached_studio_index(texture_path: str, filenames_count: int, index: dict[str, str], broken_skipped: int) -> None:
    cache_path = _studio_index_cache_path()
    try:
        os.makedirs(os.path.dirname(cache_path), exist_ok=True)
        payload = {
            'resource_id': STUDIO_RESOURCE_ID,
            'generated': time.strftime('%Y-%m-%d %H:%M:%S'),
            'texture_signature': _file_signature(texture_path),
            'file_count': filenames_count,
            'key_count': len(index),
            'broken_skipped': broken_skipped,
            'index': index,
        }
        with open(cache_path, 'w', encoding='utf-8') as handle:
            json.dump(payload, handle, ensure_ascii=False, separators=(',', ':'))
    except Exception:
        pass


def _is_broken_studio_texture(filename_or_uri: str) -> bool:
    base = os.path.basename(unquote(str(filename_or_uri or '')).replace('\\', '/')).lower().strip()
    return base in BROKEN_STUDIO_TEXTURE_NAMES


def build_studio_logo_index() -> dict[str, str]:
    started = time.time()
    addon_dir = translate(f'special://home/addons/{STUDIO_RESOURCE_ID}')
    resource_dir = os.path.join(addon_dir, 'resources')
    texture_path = os.path.join(resource_dir, 'Textures.xbt')
    cached = _load_cached_studio_index(texture_path)
    if cached:
        return cached

    filenames = []
    if os.path.exists(texture_path):
        filenames.extend(_read_xbt_filenames(texture_path))
    if os.path.isdir(resource_dir):
        filenames.extend(_walk_resource_images(resource_dir))
    filenames = list(dict.fromkeys(filenames))
    ranked: dict[str, tuple[int, str]] = {}
    broken_skipped = 0
    for filename in filenames:
        clean = filename.replace('\\', '/')
        if _is_broken_studio_texture(clean):
            broken_skipped += 1
            continue
        uri = f'resource://{STUDIO_RESOURCE_ID}/{clean}'
        stem = _strip_ext(clean)
        # Prefer exact flat names over regional/parenthetical variants when two
        # filenames normalize to the same studio key, e.g. prefer
        # "universal pictures.png" over "universal pictures (spain).png".
        base_score = 0
        if '(' in stem or ')' in stem:
            base_score += 20
        if '/' in clean:
            base_score += 10
        base_score += min(9, len(stem) // 30)
        for pos, key in enumerate(_logo_keys(clean)):
            score = base_score + pos
            old = ranked.get(key)
            if old is None or score < old[0]:
                ranked[key] = (score, uri)
    index = {key: uri for key, (_score, uri) in ranked.items()}
    elapsed_ms = int((time.time() - started) * 1000)
    set_home_prop(STUDIO_AVAILABLE_PROP, str(len(filenames)))
    set_home_prop(STUDIO_STATUS_PROP, 'ready' if index else 'no-resource')
    set_home_prop(STUDIO_CACHE_PROP, 'rebuilt')
    set_home_prop(STUDIO_INDEX_BUILD_MS_PROP, str(elapsed_ms))
    set_home_prop(STUDIO_BROKEN_SKIPPED_PROP, str(broken_skipped))
    _save_cached_studio_index(texture_path, len(filenames), index, broken_skipped)
    log(f'studio logo index ready; files={len(filenames)}, keys={len(index)}, skipped_broken={broken_skipped}, build_ms={elapsed_ms}')
    return index


def _split_studio_label(value: str) -> list[str]:
    value = (value or '').strip()
    if not value:
        return []
    # Kodi multi-studio label commonly uses " / ". Also handle pipes and semicolons.
    parts = re.split(r'\s+/\s+|\s*\|\s*|\s*;\s*', value)
    return [p.strip() for p in parts if p and p.strip()]


def collect_studio_candidates() -> list[str]:
    candidates: list[str] = []
    for label in ('Container.ListItem.Studio', 'ListItem.Studio', 'VideoPlayer.Studio'):
        candidates.extend(_split_studio_label(info(label)))
    for idx in range(1, 11):
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.ListItem.Studio.{idx}.Name')))
    for idx in range(1, 6):
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.ListItem.Network.{idx}.Name')))
    for idx in range(1, 6):
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.Player.Studio.{idx}.Name')))
        candidates.extend(_split_studio_label(home_prop(f'TMDbHelper.Player.Network.{idx}.Name')))
    deduped = []
    seen = set()
    for item in candidates:
        key = _simple_key(item)
        if key and key not in seen:
            seen.add(key)
            deduped.append(item)
    return deduped


def resolve_studio_logos(index: dict[str, str], count: int) -> list[tuple[str, str]]:
    resolved: list[tuple[str, str]] = []
    seen_uris = set()
    for name in collect_studio_candidates():
        uri = ''
        for key in _logo_keys(name):
            uri = index.get(key, '')
            if uri:
                break
        if uri and uri not in seen_uris:
            resolved.append((name, uri))
            seen_uris.add(uri)
        if len(resolved) >= count:
            break
    return resolved


def clear_studio_props() -> None:
    for idx in range(1, 4):
        clear_home_prop(f'{STUDIO_PROP_PREFIX}{idx}')
        clear_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}')
    clear_home_prop(STUDIO_COUNT_PROP)
    clear_home_prop(STUDIO_CANDIDATES_PROP)
    clear_home_prop(STUDIO_RESOLVED_PROP)
    clear_home_prop(STUDIO_MISSING_PROP)
    clear_home_prop(STUDIO_UPDATED_AT_PROP)
    clear_home_prop(STUDIO_RESOLVE_LAST_MS_PROP)
    clear_home_prop(STUDIO_RESOLVE_MAX_MS_PROP)
    clear_home_prop(STUDIO_RESOLVE_COUNT_PROP)


def update_studio_logo_props(
    index: dict[str, str],
    count: int,
    force: bool = False,
    last_key: str = '',
    empty_since: float = 0.0,
    debug: bool = False,
    stats: dict | None = None,
) -> tuple[str, float]:
    started = time.time()
    studios = collect_studio_candidates()
    now = time.time()

    if not studios:
        set_home_prop(STUDIO_CANDIDATES_PROP, '')
        set_home_prop(STUDIO_RESOLVED_PROP, '')
        set_home_prop(STUDIO_MISSING_PROP, '')
        set_home_prop(STUDIO_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))
        if empty_since <= 0.0:
            empty_since = now
        # Do not clear instantly when focus briefly passes through a non-media
        # context. This prevents footer flicker and avoids repeated texture reloads
        # while the user moves around hubs/home rows.
        if now - empty_since < STUDIO_EMPTY_CLEAR_SECONDS and home_prop(f'{STUDIO_PROP_PREFIX}1'):
            return last_key, empty_since
        for idx in range(1, 4):
            clear_home_prop(f'{STUDIO_PROP_PREFIX}{idx}')
            clear_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}')
        set_home_prop(STUDIO_COUNT_PROP, str(count))
        return '', empty_since

    empty_since = 0.0
    key = '|'.join(studios) + f'|count={count}'
    if not force and key == last_key:
        return last_key, empty_since

    resolved: list[tuple[str, str]] = []
    missing: list[str] = []
    broken: list[str] = []
    seen_uris = set()
    for name in studios:
        uri = ''
        for logo_key in _logo_keys(name):
            uri = index.get(logo_key, '')
            if uri:
                break
        if uri and _is_broken_studio_texture(uri):
            broken.append(name)
            uri = ''
        if uri:
            if uri not in seen_uris and len(resolved) < count:
                resolved.append((name, uri))
            seen_uris.add(uri)
        else:
            missing.append(name)

    for idx in range(1, 4):
        if idx <= len(resolved):
            name, uri = resolved[idx - 1]
            set_home_prop(f'{STUDIO_PROP_PREFIX}{idx}', uri)
            set_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}', name)
        else:
            clear_home_prop(f'{STUDIO_PROP_PREFIX}{idx}')
            clear_home_prop(f'{STUDIO_NAME_PROP_PREFIX}{idx}')
    elapsed_ms = int((time.time() - started) * 1000)
    if stats is not None:
        stats['resolve_count'] = int(stats.get('resolve_count', 0)) + 1
        stats['resolve_max_ms'] = max(int(stats.get('resolve_max_ms', 0)), elapsed_ms)
        set_home_prop(STUDIO_RESOLVE_COUNT_PROP, str(stats['resolve_count']))
        set_home_prop(STUDIO_RESOLVE_MAX_MS_PROP, str(stats['resolve_max_ms']))
    set_home_prop(STUDIO_RESOLVE_LAST_MS_PROP, str(elapsed_ms))
    set_home_prop(STUDIO_COUNT_PROP, str(count))
    set_home_prop(STUDIO_CANDIDATES_PROP, ' | '.join(studios[:20]))
    set_home_prop(STUDIO_RESOLVED_PROP, ' | '.join([f'{name} => {uri}' for name, uri in resolved[:3]]))
    missing_all = missing[:20]
    if broken:
        missing_all = (missing_all + [f'BROKEN_TEXTURE:{x}' for x in broken])[:20]
    set_home_prop(STUDIO_MISSING_PROP, ' | '.join(missing_all))
    set_home_prop(STUDIO_UPDATED_AT_PROP, time.strftime('%Y-%m-%d %H:%M:%S'))
    if debug:
        if resolved:
            log('studio logos: ' + ' | '.join([f'{name} -> {uri}' for name, uri in resolved]) + f' ({elapsed_ms}ms)')
        elif studios:
            log('studio logos: no valid match; candidates=' + ' | '.join(studios[:6]) + f' ({elapsed_ms}ms)')
    return key, empty_since


def main() -> None:
    if not xbmc:
        return

    if home_prop(ACTIVE_PROP) == 'true':
        log('already running; exiting duplicate instance')
        return

    set_home_prop(ACTIVE_PROP, 'true')
    monitor = xbmc.Monitor()
    armed = home_prop(ARMED_PROP) == 'true'
    try:
        armed_dialog_id = int(home_prop(ARMED_DIALOG_PROP) or '0')
    except Exception:
        armed_dialog_id = 0

    log('started')
    pause_since = 0.0
    last_foreign_dialog = 0
    playback_started_at = 0.0
    last_has_video = False
    studio_index: dict[str, str] = {}
    studio_last_key = ''
    studio_empty_since = 0.0
    studio_stats = {'resolve_count': 0, 'resolve_max_ms': 0}
    studio_enabled_cached = False
    studio_count_cached = 1
    studio_debug_cached = False
    last_config_check = 0.0
    last_studio_update = 0.0
    try:
        while not monitor.abortRequested():
            now = time.time()
            if now - last_config_check >= 1.0:
                last_config_check = now
                studio_enabled_cached = studio_patch_enabled()
                settings_cached = load_kpm_settings()
                studio_count_cached = int(settings_cached.get('studio_logo_count', 1))
                studio_debug_cached = bool(settings_cached.get('studio_debug')) or home_prop(STUDIO_DEBUG_PROP).lower() == 'true'
                if studio_enabled_cached and not studio_index:
                    studio_index = build_studio_logo_index()
                if not studio_enabled_cached:
                    studio_last_key = ''
                    studio_empty_since = 0.0
                    clear_studio_props()

            if studio_enabled_cached and studio_index and now - last_studio_update >= STUDIO_RESOLVE_INTERVAL_SECONDS:
                last_studio_update = now
                try:
                    studio_last_key, studio_empty_since = update_studio_logo_props(studio_index, studio_count_cached, False, studio_last_key, studio_empty_since, studio_debug_cached, studio_stats)
                except Exception:
                    log('studio resolver error:\n' + traceback.format_exc(), xbmc.LOGWARNING)

            if not pause_patch_enabled():
                armed = False
                armed_dialog_id = 0
                pause_since = 0.0
                last_foreign_dialog = 0
                playback_started_at = 0.0
                last_has_video = False
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                clear_home_prop(PAUSE_SINCE_PROP)
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)
                monitor.waitForAbort(0.25)
                continue

            paused = cond('Player.Paused')
            playing = cond('Player.Playing')
            seeking = cond('Player.Seeking')
            has_video = cond('Player.HasVideo') or cond('Player.HasMedia')
            fullscreen_video = cond('Window.IsActive(VideoFullScreen.xml)') or cond('Window.IsActive(fullscreenvideo)')
            videoosd = cond('Window.IsActive(videoosd)') or cond('Window.IsVisible(videoosd)')
            dialog_id = current_dialog_id()
            foreign_dialog = is_foreign_dialog(dialog_id)

            if has_video and not last_has_video:
                playback_started_at = now
                log(f'video session detected; startup guard active for {STARTUP_GUARD_WINDOW_SECONDS:.1f}s')
            elif not has_video:
                playback_started_at = 0.0
            last_has_video = has_video

            if foreign_dialog:
                if dialog_id != last_foreign_dialog:
                    last_foreign_dialog = dialog_id
                    set_home_prop(LAST_FOREIGN_DIALOG_PROP, str(dialog_id))
                    log(f'foreign dialog active; KPM will not auto-open/close/focus VideoOSD; dialog_id={dialog_id}, window_id={current_window_id()}')
            else:
                last_foreign_dialog = 0
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)

            if has_video and paused and not seeking:
                if pause_since <= 0:
                    pause_since = time.time()
                    set_home_prop(PAUSE_SINCE_PROP, str(pause_since))
                if fullscreen_video and not videoosd and not foreign_dialog:
                    startup_age = (time.time() - playback_started_at) if playback_started_at > 0 else 999.0
                    grace = AUTO_OPEN_GRACE_SECONDS
                    grace_reason = 'normal-pause-no-delay'
                    if startup_age < STARTUP_GUARD_WINDOW_SECONDS:
                        grace = STARTUP_AUTO_DIALOG_GUARD_SECONDS
                        grace_reason = 'startup-dialog-guard'
                    if time.time() - pause_since >= grace:
                        log(f'paused with no foreign dialog; opening VideoOSD; grace={grace:.2f}s/{grace_reason}; dialog_id={dialog_id}, window_id={current_window_id()}')
                        try:
                            xbmc.executebuiltin('CancelAlarm(osd_timeout,true)')
                            xbmc.executebuiltin('ActivateWindow(videoosd)')
                        except Exception:
                            log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)
                        monitor.waitForAbort(0.15)
                        continue
            else:
                pause_since = 0.0
                clear_home_prop(PAUSE_SINCE_PROP)

            if has_video and paused and videoosd:
                if not armed:
                    armed_dialog_id = dialog_id
                    set_home_prop(ARMED_DIALOG_PROP, str(armed_dialog_id))
                    log(f'armed while paused; dialog_id={armed_dialog_id}, window_id={current_window_id()}')
                armed = True
                set_home_prop(ARMED_PROP, 'true')

            if armed and has_video and playing and videoosd:
                if foreign_dialog:
                    monitor.waitForAbort(0.25)
                    continue
                log(f'pause->play detected; closing VideoOSD safely; dialog_id={dialog_id}, armed_dialog_id={armed_dialog_id}')
                close_video_osd_safely()
                armed = False
                armed_dialog_id = 0
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                monitor.waitForAbort(0.4)
                continue

            if not has_video or (not paused and not playing):
                armed = False
                armed_dialog_id = 0
                pause_since = 0.0
                last_foreign_dialog = 0
                playback_started_at = 0.0
                last_has_video = False
                clear_home_prop(ARMED_PROP)
                clear_home_prop(ARMED_DIALOG_PROP)
                clear_home_prop(PAUSE_SINCE_PROP)
                clear_home_prop(LAST_FOREIGN_DIALOG_PROP)

            monitor.waitForAbort(0.08)
    finally:
        clear_home_prop(ACTIVE_PROP)
        clear_home_prop(ARMED_PROP)
        clear_home_prop(ARMED_DIALOG_PROP)
        clear_home_prop(PAUSE_SINCE_PROP)
        clear_home_prop(LAST_FOREIGN_DIALOG_PROP)
        log('stopped')


if __name__ == '__main__':
    main()

# -*- coding: utf-8 -*-
from __future__ import annotations

import json
import os
import time
import traceback

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except Exception:  # pragma: no cover outside Kodi
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

ADDON_ID = 'script.kodi.patch.manager'
ADDON_NAME = 'Kodi Patch Manager'
ACTIVE_PROP = 'KPM.ResumeCloseService.Active'
ARMED_PROP = 'KPM.ResumeCloseService.Armed'
LOG_PREFIX = '[Kodi Patch Manager ResumeClose] '


def translate(path: str) -> str:
    if xbmcvfs and hasattr(xbmcvfs, 'translatePath'):
        return xbmcvfs.translatePath(path)
    if xbmc and hasattr(xbmc, 'translatePath'):
        return xbmc.translatePath(path)
    return path


def log(message: str, level=None) -> None:
    if xbmc:
        xbmc.log(LOG_PREFIX + message, level or xbmc.LOGINFO)
    else:
        print(LOG_PREFIX + message)


def cond(expression: str) -> bool:
    try:
        return bool(xbmc.getCondVisibility(expression)) if xbmc else False
    except Exception:
        return False


def home_prop(name: str) -> str:
    try:
        return xbmcgui.Window(10000).getProperty(name) if xbmcgui else ''
    except Exception:
        return ''


def set_home_prop(name: str, value: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).setProperty(name, value)
    except Exception:
        pass


def clear_home_prop(name: str) -> None:
    try:
        if xbmcgui:
            xbmcgui.Window(10000).clearProperty(name)
    except Exception:
        pass


def state_file() -> str:
    return os.path.join(translate(f'special://profile/addon_data/{ADDON_ID}'), 'state', 'vfs_pause_ratings.json')


def patch_enabled() -> bool:
    path = state_file()
    if not os.path.exists(path):
        return False
    try:
        with open(path, 'r', encoding='utf-8', errors='replace') as handle:
            data = json.load(handle)
        return bool(data.get('auto_videoosd') and data.get('pause_stay_until_resume'))
    except Exception:
        return True


def close_video_osd() -> None:
    # Dialog.Close is harmless if the skin treats videoosd as a dialog; Action(Back)
    # is the reliable fallback for the focused VideoOSD window.
    try:
        xbmc.executebuiltin('CancelAlarm(osd_timeout,true)')
        xbmc.executebuiltin('Dialog.Close(videoosd,true)')
        xbmc.executebuiltin('Action(Back)')
    except Exception:
        log(traceback.format_exc(), xbmc.LOGWARNING if xbmc else None)


def main() -> None:
    if not xbmc:
        return

    # Prevent duplicate loops when Patch starts the service manually while Kodi
    # already started the xbmc.service instance.
    if home_prop(ACTIVE_PROP) == 'true':
        log('already running; exiting duplicate instance')
        return

    set_home_prop(ACTIVE_PROP, 'true')
    monitor = xbmc.Monitor()
    armed = home_prop(ARMED_PROP) == 'true'
    log('started')
    try:
        while not monitor.abortRequested():
            if not patch_enabled():
                armed = False
                clear_home_prop(ARMED_PROP)
                monitor.waitForAbort(1.0)
                continue

            paused = cond('Player.Paused')
            playing = cond('Player.Playing')
            has_video = cond('Player.HasVideo') or cond('Player.HasMedia')
            videoosd = cond('Window.IsActive(videoosd)') or cond('Window.IsVisible(videoosd)')

            if has_video and paused and videoosd:
                armed = True
                set_home_prop(ARMED_PROP, 'true')

            if armed and has_video and playing and videoosd:
                log('pause->play detected while videoosd is active; closing OSD')
                close_video_osd()
                armed = False
                clear_home_prop(ARMED_PROP)
                monitor.waitForAbort(0.4)
                continue

            if not has_video or (not paused and not playing):
                armed = False
                clear_home_prop(ARMED_PROP)

            monitor.waitForAbort(0.2)
    finally:
        clear_home_prop(ACTIVE_PROP)
        clear_home_prop(ARMED_PROP)
        log('stopped')


if __name__ == '__main__':
    main()

Kodi Patch Manager v0.1.18

New in v0.1.18:
- Pause Shows Full OSD now stays open while playback is paused; AF3 osd_timeout is disabled only during pause.
- VideoOSD closes fast when playback resumes from pause.
- Clearart is moved from VideoOSD into DialogSeekBar behind the progress layer, so the progress line/time render over it.
- Clearart is slightly smaller while keeping the same bottom-right anchor.
- Chapter/cutlist tick markers on the progress line are hidden.
- OSD plot width remains shortened so text stops before the clearart area.

Safe patch style:
- Does not ship full replacement XML/PY target files.
- Uses anchor-based injection/replacement only.
- Adds clear markers to every injected block.
- Normal Remove/Restore is block-level: it removes injected blocks or restores only the saved original XML variable block, not the whole file.
- A safety snapshot is also stored before patching, but normal restore does not overwrite the whole target file.

Included patches:
1. Episode Thumb Up Next
   Target: skin.arctic.fuse.3/1080i/Includes_Images.xml
   Change: Image_UpNext becomes thumb -> landscape -> fanart.

2. Stable Random Fanart
   Target: plugin.video.themoviedb.helper/resources/tmdbhelper/lib/monitor/imgmon.py
   Target: plugin.video.themoviedb.helper/resources/tmdbhelper/lib/monitor/images.py
   Change: random extra-fanart stays stable while focus stays on the same item.

3. Movies + Shows Screensaver
   Target: script.skin.helper.widgets/resources/lib/media.py
   Target: skin.arctic.fuse.3/1080i/Includes_Defaults.xml
   Change: adds randommoviestvshows path and points AF3 screensaver widget to movies + TV shows only.

4. AF3 x LRS Ratings UI
   Target: skin.arctic.fuse.3/1080i/Includes_Info.xml, Includes_Hubs.xml, screensaver-arctic-mirage.xml
   Change: injects LRS rating/status/award display blocks into AF3.

5. Pause Shows Full OSD
   Target: DialogSeekBar.xml, VideoOSD.xml, Includes_OSD.xml, Includes_Actions.xml
   Change: pause opens full VideoOSD, stays open until playback resumes, shows clearart behind progress, hides chapter ticks, shortens plot, and closes fast on resume.

Backups/state:
- special://profile/addon_data/script.kodi.patch.manager/state
- special://profile/addon_data/script.kodi.patch.manager/snapshots

After patch/remove:
- Reload Skin is requested automatically for XML patches.
- Full Kodi restart is safest if Kodi keeps an old XML window in memory.

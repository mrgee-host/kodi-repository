MrGee Kodi Repository 1.0.3 - R7

Passive repository descriptor with no runtime database or migration code.
The add-on icon is replaced with the supplied Mr.Gee Repository artwork.
The configured remote repository URLs are unchanged.

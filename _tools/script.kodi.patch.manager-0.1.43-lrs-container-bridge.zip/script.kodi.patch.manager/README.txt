Kodi Patch Manager v0.1.43

New in v0.1.43:
- Independent Fanart Engine now uses an LRS-style AF3 hub bridge. XML publishes only the active container ID.
- KPM service resolves Container(ID).ListItem.DBID/DBTYPE/Label itself, so Play/More/tab/selector focus does not blank the item.
- Priority is LRS.Active.ContainerID, then KPM.Active.ContainerID, then KPM.Focus.Container, then TMDbHelper.WidgetContainer, then normal ListItem fallback.
- KPM still only feeds AF3/TMDbHelper Blur.SourceImage/Fallback and never writes raw artwork URLs into TMDbHelper.ListItem.BlurImage outputs.

Main menu:
- Apply Recommended Patch
- Remove Recommended Patch
- Patch Status
- Diagnostics
- Clear Add-on Icon Cache
- Advanced Patches
- Settings
- Exit

Recommended workflow:
1. Install this zip.
2. Run Kodi Patch Manager > Apply Recommended Patch.
3. Restart Kodi once so service.py v0.1.43 replaces any older running service.

Notes:
- Independent fanart uses Artwork Curator / LAC artwork-cache.db read-only.
- Episode and season fanart fall back to parent TV show fanart through MyVideos DB mapping.
- Launch fallback can use random movie/TV fanart URL from artwork-cache.db; Kodi handles texture cache normally.
- Reliable Studio Logos remains single-logo only through KPM.StudioLogo.1.


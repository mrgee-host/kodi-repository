import os
import hashlib
import json
import re
import sqlite3
import time
import traceback

import xbmcvfs

from lib.libs import pykodi
from lib import runtrace

ADDON_ID = 'script.artwork.curator'
DB_NAME = 'artwork-cache.db'
SCHEMA_VERSION = '8-dbid-identity-guard'
FINAL_SKIP_STATUSES = ('N/A', 'PROTECTED', 'MANUAL')
APPLY_STATUSES = ('OK', 'MANUAL', 'PROTECTED')
RETRY_STATUSES = ('MISSING', 'ERROR', 'RETRY', '')


def _translate(path):
    value = xbmcvfs.translatePath(path)
    if isinstance(value, bytes):
        value = value.decode('utf-8', 'replace')
    return value


def profile_dir():
    path = _translate('special://profile/addon_data/%s/' % ADDON_ID)
    if not os.path.isdir(path):
        try:
            os.makedirs(path)
        except Exception:
            pass
    return path


def db_path():
    return os.path.join(profile_dir(), DB_NAME)


def _now():
    return int(time.time())


def elapsed_text(ms):
    try:
        ms = int(ms or 0)
    except Exception:
        ms = 0
    if ms < 1000:
        return '%d ms' % ms
    seconds = int(round(ms / 1000.0))
    if seconds < 60:
        return '%ds' % seconds
    minutes, seconds = divmod(seconds, 60)
    if minutes < 60:
        return '%dm %02ds' % (minutes, seconds)
    hours, minutes = divmod(minutes, 60)
    return '%dh %02dm %02ds' % (hours, minutes, seconds)


def _item_key(mediatype, dbid):
    return '%s:%s' % (mediatype, dbid)


def parse_item_key(item_key):
    try:
        mediatype, raw_dbid = (item_key or '').split(':', 1)
        return mediatype, int(raw_dbid)
    except Exception:
        return '', None


def is_default_icon_url(url):
    lower = (url or '').lower()
    return 'defaultvideo.png' in lower or 'defaultplaylist.png' in lower or 'defaultfolder.png' in lower


def infer_source(url):
    lower = (url or '').lower()
    if not lower:
        return ''
    if 'image.tmdb.org' in lower or 'themoviedb.org' in lower:
        return 'TMDb'
    if 'fanart.tv' in lower or 'assets.fanart.tv' in lower:
        return 'fanart.tv'
    if 'thetvdb.com' in lower or 'artworks.thetvdb.com' in lower or 'tvdb' in lower:
        return 'TheTVDB'
    if 'theposterdb.com' in lower or 'images.theposterdb.com' in lower:
        return 'TPDb'
    if lower.startswith('image://'):
        return 'Kodi'
    if lower.startswith('http://') or lower.startswith('https://'):
        return 'Remote'
    return 'Existing'


def _log_error(message, ex=None, **kwargs):
    try:
        if ex is not None:
            runtrace.error(message, ex, **kwargs)
        else:
            runtrace.event('artworkdb', message, **kwargs)
    except Exception:
        pass


def _addon_version():
    try:
        return pykodi.get_main_addon().version
    except Exception:
        return '<unknown>'


def connect():
    conn = sqlite3.connect(db_path())
    conn.execute('PRAGMA journal_mode=WAL')
    conn.execute('PRAGMA synchronous=NORMAL')
    init(conn)
    return conn


def init(conn=None):
    own = conn is None
    conn = conn or sqlite3.connect(db_path())
    try:
        conn.executescript('''
        CREATE TABLE IF NOT EXISTS metadata (
            key TEXT PRIMARY KEY,
            value TEXT
        );
        CREATE TABLE IF NOT EXISTS library_items (
            item_key TEXT PRIMARY KEY,
            title TEXT,
            status TEXT,
            file TEXT,
            uniqueids TEXT,
            last_seen_at INTEGER,
            last_processed_at INTEGER,
            updated_at INTEGER
        );
        CREATE TABLE IF NOT EXISTS artwork (
            item_key TEXT,
            title TEXT,
            art_type TEXT,
            url TEXT,
            source TEXT,
            status TEXT,
            reason TEXT,
            updated_at INTEGER,
            PRIMARY KEY (item_key, art_type)
        );
        CREATE TABLE IF NOT EXISTS runs (
            run_id TEXT PRIMARY KEY,
            action TEXT,
            status TEXT,
            started_at INTEGER,
            finished_at INTEGER,
            elapsed_text TEXT,
            elapsed_ms INTEGER DEFAULT 0,
            total_items INTEGER DEFAULT 0,
            processed_items INTEGER DEFAULT 0,
            updated_items INTEGER DEFAULT 0,
            updated_artwork INTEGER DEFAULT 0,
            errors INTEGER DEFAULT 0,
            notes TEXT
        );
        CREATE TABLE IF NOT EXISTS run_items (
            run_id TEXT,
            item_key TEXT,
            title TEXT,
            status TEXT,
            updated_arttypes TEXT,
            elapsed_ms INTEGER DEFAULT 0,
            error TEXT,
            updated_at INTEGER,
            PRIMARY KEY (run_id, item_key)
        );
        CREATE INDEX IF NOT EXISTS idx_artwork_status ON artwork(status);
        CREATE INDEX IF NOT EXISTS idx_artwork_source ON artwork(source);
        CREATE INDEX IF NOT EXISTS idx_artwork_art_type ON artwork(art_type);
        CREATE INDEX IF NOT EXISTS idx_run_items_run ON run_items(run_id);
        ''')
        conn.execute('INSERT OR REPLACE INTO metadata(key, value) VALUES(?, ?)', ('schema_version', str(SCHEMA_VERSION)))
        conn.execute('INSERT OR REPLACE INTO metadata(key, value) VALUES(?, ?)', ('addon_version', _addon_version()))
        conn.commit()
    finally:
        if own:
            conn.close()


def ensure():
    try:
        init()
        return True
    except Exception as ex:
        _log_error('artwork-cache.db ensure failed', ex)
        return False


def get_metadata(key, default=''):
    try:
        conn = connect()
        try:
            row = conn.execute('SELECT value FROM metadata WHERE key=?', (key,)).fetchone()
            return row[0] if row else default
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db get_metadata failed', ex, key=key)
        return default


def set_metadata(key, value):
    try:
        conn = connect()
        try:
            with conn:
                conn.execute('INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)', (key, str(value)))
            return True
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db set_metadata failed', ex, key=key)
        return False


def checkpoint():
    """Flush WAL into artwork-cache.db before diagnostics copies the DB."""
    try:
        conn = connect()
        try:
            conn.execute('PRAGMA wal_checkpoint(TRUNCATE)')
            conn.commit()
            return True
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db checkpoint failed', ex)
        return False


def title_for_item(mediaitem):
    if getattr(mediaitem, 'mediatype', '') == 'episode':
        try:
            sxex = 'S%02dE%02d' % (int(getattr(mediaitem, 'season', 0) or 0), int(getattr(mediaitem, 'episode', 0) or 0))
        except Exception:
            sxex = ''
        show = getattr(mediaitem, 'showtitle', '') or getattr(mediaitem, 'tvshowtitle', '') or ''
        if show:
            return (show + ' - ' + sxex).strip(' -')
        label = getattr(mediaitem, 'label', '') or ''
        return (label + ' - ' + sxex).strip(' -') if label else sxex
    if getattr(mediaitem, 'mediatype', '') == 'season':
        show = getattr(mediaitem, 'showtitle', '') or getattr(mediaitem, 'tvshowtitle', '') or ''
        label = getattr(mediaitem, 'label', '') or ''
        return (show + ' - ' + label).strip(' -') if show and label and show.lower() not in label.lower() else (label or show)
    return getattr(mediaitem, 'label', '') or ''


def _jsonish(value):
    try:
        import json
        return json.dumps(value or {}, sort_keys=True)
    except Exception:
        return repr(value)


def begin_run(action, total_items=0, notes=''):
    try:
        run_id = time.strftime('%Y%m%d-%H%M%S') + '-' + action.replace(' ', '_').replace('.', '_')[:40]
        conn = connect()
        try:
            conn.execute('INSERT OR REPLACE INTO runs(run_id, action, status, started_at, total_items, notes) VALUES(?, ?, ?, ?, ?, ?)',
                         (run_id, action, 'running', _now(), int(total_items or 0), notes or ''))
            conn.commit()
        finally:
            conn.close()
        return run_id
    except Exception as ex:
        _log_error('artwork-cache.db begin_run failed', ex, action=action)
        return None


def finish_run(run_id, status='finished', updated_items=0, updated_artwork=0, errors=0, elapsed_ms=0, notes=''):
    if not run_id:
        return
    try:
        conn = connect()
        try:
            total = 0
            try:
                row = conn.execute('SELECT total_items FROM runs WHERE run_id=?', (run_id,)).fetchone()
                total = int(row[0] or 0) if row else 0
            except Exception:
                pass
            processed = total if status == 'finished' else 0
            conn.execute('''UPDATE runs SET finished_at=?, status=?, processed_items=?, updated_items=?, updated_artwork=?, errors=?, elapsed_ms=?, elapsed_text=?, notes=COALESCE(NULLIF(?, ''), notes) WHERE run_id=?''',
                         (_now(), status, processed, int(updated_items or 0), int(updated_artwork or 0), int(errors or 0), int(elapsed_ms or 0), elapsed_text(elapsed_ms), notes or '', run_id))
            conn.commit()
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db finish_run failed', ex, run_id=run_id)


def record_item(mediaitem, run_id=None, status='processed', updatedart=None, elapsed_ms=0, error=None):
    try:
        conn = connect()
        item_key = _item_key(mediaitem.mediatype, mediaitem.dbid)
        now = _now()
        updatedart = list(updatedart or getattr(mediaitem, 'updatedart', []) or [])
        readable_title = title_for_item(mediaitem)
        with conn:
            conn.execute('''INSERT OR REPLACE INTO library_items(item_key,title,status,file,uniqueids,last_seen_at,last_processed_at,updated_at)
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                         (item_key, readable_title, status, getattr(mediaitem, 'file', '') or '', _jsonish(getattr(mediaitem, 'uniqueids', {})), now, now, now))
            for art_type in sorted(set(updatedart)):
                url = (getattr(mediaitem, 'art', {}) or {}).get(art_type) or ''
                if art_type == 'icon' or is_default_icon_url(url):
                    continue
                if url:
                    set_artwork(conn, item_key, readable_title, art_type, url, infer_source(url), 'OK', '', now)
            if run_id:
                # New DBs do not use the redundant phase column. Existing DBs with
                # an old phase column remain compatible because explicit columns are used.
                conn.execute('''INSERT OR REPLACE INTO run_items(run_id,item_key,title,status,updated_arttypes,elapsed_ms,error,updated_at)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                             (run_id, item_key, readable_title, status, ','.join(updatedart), int(elapsed_ms or 0), error or '', now))
    except Exception as ex:
        _log_error('artwork-cache.db record_item failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''))


def set_artwork(conn, item_key, title, art_type, url='', source='', status='OK', reason='', updated_at=None):
    updated_at = updated_at or _now()
    if art_type == 'icon' or is_default_icon_url(url):
        return
    if url and not source:
        source = infer_source(url)
    if url and (not status or status in ('MISSING', 'ERROR', 'RETRY')):
        status = 'OK'
    if not url and status == 'OK':
        status = 'MISSING'
    conn.execute('''INSERT OR REPLACE INTO artwork(item_key,title,art_type,url,source,status,reason,updated_at)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)''',
                 (item_key, title or '', art_type, url or '', source or '', status or 'MISSING', reason or '', int(updated_at)))


def set_artwork_item(mediaitem, art_type, url='', source='', status='OK', reason=''):
    try:
        conn = connect()
        try:
            with conn:
                set_artwork(conn, _item_key(mediaitem.mediatype, mediaitem.dbid), title_for_item(mediaitem), art_type, url, source, status, reason, _now())
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db set_artwork_item failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''), art_type=art_type)


def set_artwork_for_key(mediatype, dbid, title, art_type, url='', source='', status='OK', reason=''):
    try:
        if not mediatype or dbid is None:
            return
        conn = connect()
        try:
            with conn:
                item_key = _item_key(mediatype, dbid)
                now = _now()
                conn.execute("""INSERT OR IGNORE INTO library_items(item_key,title,status,file,uniqueids,last_seen_at,last_processed_at,updated_at)
                                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                             (item_key, title or '', 'mirrored', '', '{}', now, now, now))
                set_artwork(conn, item_key, title or '', art_type, url, source, status, reason, now)
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db set_artwork_for_key failed', ex, mediatype=mediatype, dbid=dbid, art_type=art_type)


def get_artwork_rows_for_key(item_key):
    try:
        conn = connect()
        try:
            rows = conn.execute('SELECT art_type,url,source,status,reason,updated_at,title FROM artwork WHERE item_key=?', (item_key,)).fetchall()
            return dict((r[0], {'url': r[1] or '', 'source': r[2] or '', 'status': r[3] or '', 'reason': r[4] or '', 'updated_at': r[5] or 0, 'title': r[6] or ''}) for r in rows)
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db get_artwork_rows failed', ex, item_key=item_key)
        return {}


def get_artwork_rows(mediaitem):
    return get_artwork_rows_for_key(_item_key(mediaitem.mediatype, mediaitem.dbid))


def artwork_to_apply(mediaitem):
    rows = get_artwork_rows(mediaitem)
    result = {}
    for art_type, row in rows.items():
        status = (row.get('status') or '').upper()
        url = row.get('url') or ''
        if url and status in APPLY_STATUSES:
            result[art_type] = url
    return result


def should_search_row(row):
    if row is None:
        return True
    status = (row.get('status') or '').upper()
    url = row.get('url') or ''
    if status in FINAL_SKIP_STATUSES:
        return False
    if status == 'OK' and url:
        return False
    if status == 'OK' and not url:
        return True
    if status in RETRY_STATUSES:
        return True
    return not bool(url)


def mark_art_status_item(mediaitem, art_type, status, reason=''):
    row_url = ''
    try:
        if status == 'OK':
            row_url = (getattr(mediaitem, 'art', {}) or {}).get(art_type) or ''
        set_artwork_item(mediaitem, art_type, row_url, infer_source(row_url), status, reason or '')
    except Exception as ex:
        _log_error('artwork-cache.db mark_art_status_item failed', ex, mediatype=getattr(mediaitem, 'mediatype', ''), dbid=getattr(mediaitem, 'dbid', ''), art_type=art_type)


def mark_art_status(mediatype, dbid, art_type, status, reason=''):
    try:
        conn = connect()
        item_key = _item_key(mediatype, dbid)
        title = ''
        try:
            row = conn.execute('SELECT title FROM library_items WHERE item_key=?', (item_key,)).fetchone()
            title = row[0] if row else ''
        except Exception:
            pass
        with conn:
            set_artwork(conn, item_key, title, art_type, '', '', status, reason or '', _now())
        conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db mark_art_status failed', ex, mediatype=mediatype, dbid=dbid, art_type=art_type)


def is_na(mediatype, dbid, art_type):
    try:
        rows = get_artwork_rows_for_key(_item_key(mediatype, dbid))
        row = rows.get(art_type)
        return bool(row and (row.get('status') or '').upper() in FINAL_SKIP_STATUSES)
    except Exception as ex:
        _log_error('artwork-cache.db is_na failed', ex, mediatype=mediatype, dbid=dbid, art_type=art_type)
        return False


def reset_na():
    try:
        conn = connect()
        try:
            with conn:
                cur = conn.execute("UPDATE artwork SET status='MISSING', reason='Reset N/A status', url='', source='', updated_at=? WHERE status='N/A'", (_now(),))
                return cur.rowcount
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db reset_na failed', ex)
        return 0


def known_artwork_urls(media_types=None):
    try:
        conn = connect()
        try:
            where = "WHERE url IS NOT NULL AND url != ''"
            params = []
            if media_types:
                likes = []
                for mt in media_types:
                    likes.append('item_key LIKE ?')
                    params.append(str(mt) + ':%')
                where += ' AND (' + ' OR '.join(likes) + ')'
            return set(row[0] for row in conn.execute('SELECT DISTINCT url FROM artwork ' + where, params) if row[0])
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db known_artwork_urls failed', ex)
        return set()



# -----------------------------------------------------------------------------
# v0.32.48 - DBID identity guard and cross-series episode-art collision repair
# -----------------------------------------------------------------------------
_EPISODE_COORD_RE = re.compile(r"^(.*?)\s+-\s+S(\d+)E(\d+)$", re.I)
_REMOTE_EPISODE_ART_TYPES = ("thumb", "landscape")
_REMOTE_PROVIDER_MARKERS = (
    "image.tmdb.org", "themoviedb.org", "artworks.thetvdb.com", "thetvdb.com",
    "fanart.tv", "assets.fanart.tv",
)


def _normal_text(value):
    return " ".join(str(value or "").strip().lower().split())


def _normal_file(value):
    return str(value or "").replace("/", "\\").strip().lower()


def _load_ids(value):
    if isinstance(value, dict):
        source = value
    else:
        try:
            source = json.loads(value or "{}")
        except Exception:
            source = {}
    result = {}
    for key, raw in (source or {}).items():
        raw = str(raw or "").strip().lower()
        if raw:
            result[str(key).strip().lower()] = raw
    return result


def _mediaitem_ids(mediaitem):
    return _load_ids(getattr(mediaitem, "uniqueids", {}) or {})


def _episode_coord_from_title(title):
    match = _EPISODE_COORD_RE.match(str(title or "").strip())
    if not match:
        return "", None, None
    try:
        return _normal_text(match.group(1)), int(match.group(2)), int(match.group(3))
    except Exception:
        return _normal_text(match.group(1)), None, None


def _mediaitem_identity(mediaitem):
    mediatype = str(getattr(mediaitem, "mediatype", "") or "")
    identity = {
        "mediatype": mediatype,
        "title": _normal_text(title_for_item(mediaitem)),
        "file": _normal_file(getattr(mediaitem, "file", "")),
        "ids": _mediaitem_ids(mediaitem),
    }
    if mediatype == "episode":
        identity.update({
            "show": _normal_text(getattr(mediaitem, "showtitle", "") or getattr(mediaitem, "tvshowtitle", "")),
            "season": int(getattr(mediaitem, "season", 0) or 0),
            "episode": int(getattr(mediaitem, "episode", 0) or 0),
        })
    elif mediatype == "season":
        identity.update({
            "show": _normal_text(getattr(mediaitem, "showtitle", "") or getattr(mediaitem, "tvshowtitle", "")),
            "season": int(getattr(mediaitem, "season", 0) or 0),
        })
    return identity


def _stored_identity(row, mediatype):
    title = row[0] or ""
    show, season, episode = _episode_coord_from_title(title)
    return {
        "mediatype": mediatype,
        "title": _normal_text(title),
        "file": _normal_file(row[1] or ""),
        "ids": _load_ids(row[2] or "{}"),
        "show": show,
        "season": season,
        "episode": episode,
    }


def _identity_matches(current, stored):
    if current.get("mediatype") != stored.get("mediatype"):
        return False
    common = set(current.get("ids") or {}).intersection(stored.get("ids") or {})
    strong = False
    for provider in common:
        left = (current.get("ids") or {}).get(provider)
        right = (stored.get("ids") or {}).get(provider)
        if left and right:
            if left != right:
                return False
            strong = True
    mediatype = current.get("mediatype")
    if mediatype == "episode":
        if stored.get("show") and current.get("show") and stored.get("show") != current.get("show"):
            return False
        if stored.get("season") is not None and stored.get("season") != current.get("season"):
            return False
        if stored.get("episode") is not None and stored.get("episode") != current.get("episode"):
            return False
        if strong:
            return True
        return bool(
            stored.get("show") and current.get("show") and stored.get("show") == current.get("show")
            and stored.get("season") == current.get("season")
            and stored.get("episode") == current.get("episode")
        )
    if mediatype == "season":
        if stored.get("show") and current.get("show") and stored.get("show") != current.get("show"):
            return False
        if stored.get("season") is not None and stored.get("season") != current.get("season"):
            return False
        return strong or bool(stored.get("show") and stored.get("show") == current.get("show"))
    if strong:
        return True
    # Movies, shows, and sets can be renamed/localized. A file match is stronger
    # than a label match when provider IDs are unavailable.
    if current.get("file") and stored.get("file"):
        return current.get("file") == stored.get("file")
    return bool(current.get("title") and current.get("title") == stored.get("title"))


def _delete_item_key_conn(conn, item_key, include_history=True):
    removed_art = conn.execute("DELETE FROM artwork WHERE item_key=?", (item_key,)).rowcount
    removed_item = conn.execute("DELETE FROM library_items WHERE item_key=?", (item_key,)).rowcount
    removed_runs = 0
    if include_history:
        removed_runs = conn.execute("DELETE FROM run_items WHERE item_key=?", (item_key,)).rowcount
    return {"items": removed_item, "artwork": removed_art, "run_items": removed_runs}


def ensure_item_identity(mediaitem):
    """Invalidate stale DB-first rows when Kodi reused a DBID for another item."""
    item_key = _item_key(mediaitem.mediatype, mediaitem.dbid)
    try:
        conn = connect()
        try:
            row = conn.execute("SELECT title,file,uniqueids FROM library_items WHERE item_key=?", (item_key,)).fetchone()
            if not row:
                return {"item_key": item_key, "status": "new", "invalidated": False}
            current = _mediaitem_identity(mediaitem)
            stored = _stored_identity(row, mediaitem.mediatype)
            if _identity_matches(current, stored):
                return {"item_key": item_key, "status": "match", "invalidated": False}
            with conn:
                removed = _delete_item_key_conn(conn, item_key, include_history=True)
                conn.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)", ("last_dbid_identity_repair", "%s|%s" % (_now(), item_key)))
            runtrace.event("artworkdb", "DBID identity changed; stale artwork cache removed",
                           item_key=item_key, old_title=row[0] or "", new_title=title_for_item(mediaitem), removed=removed)
            return {"item_key": item_key, "status": "mismatch", "invalidated": True, "removed": removed}
        finally:
            conn.close()
    except Exception as ex:
        _log_error("artwork-cache.db identity guard failed", ex, item_key=item_key)
        return {"item_key": item_key, "status": "error", "invalidated": False, "error": str(ex)}


def _collision_marker_key(item_key, art_type, url):
    digest = hashlib.sha1(str(url or "").encode("utf-8", "replace")).hexdigest()[:20]
    return "episode_collision_retry:%s:%s:%s" % (item_key, art_type, digest)


def _remote_provider_url(url):
    lower = str(url or "").lower()
    return lower.startswith(("http://", "https://")) and any(marker in lower for marker in _REMOTE_PROVIDER_MARKERS)


def repair_episode_cross_series_collisions(mediaitem):
    """Remove newer copied episode stills that are also owned by another show.

    This repairs rows already poisoned before the identity guard existed. The
    older cross-series owner is treated as the likely original; only the newer
    current row is reopened. Each exact URL is retried once to avoid loops when
    two shows legitimately share an image.
    """
    if str(getattr(mediaitem, "mediatype", "")) != "episode":
        return []
    item_key = _item_key(mediaitem.mediatype, mediaitem.dbid)
    current_show = _normal_text(getattr(mediaitem, "showtitle", "") or getattr(mediaitem, "tvshowtitle", ""))
    if not current_show:
        return []
    repaired = []
    try:
        conn = connect()
        try:
            current_rows = conn.execute(
                "SELECT art_type,url,updated_at FROM artwork WHERE item_key=? AND art_type IN ('thumb','landscape') AND status='OK'",
                (item_key,)
            ).fetchall()
            for art_type, url, current_updated in current_rows:
                if not _remote_provider_url(url):
                    continue
                marker = _collision_marker_key(item_key, art_type, url)
                if conn.execute("SELECT 1 FROM metadata WHERE key=?", (marker,)).fetchone():
                    continue
                others = conn.execute(
                    """SELECT a.item_key,l.title,a.updated_at
                       FROM artwork a JOIN library_items l ON l.item_key=a.item_key
                       WHERE a.url=? AND a.art_type=? AND a.item_key<>? AND a.item_key LIKE 'episode:%' AND a.status='OK'""",
                    (url, art_type, item_key)
                ).fetchall()
                offender = None
                for other_key, other_title, other_updated in others:
                    other_show, _season, _episode = _episode_coord_from_title(other_title)
                    if not other_show or other_show == current_show:
                        continue
                    # The corruption pattern is a newly rewritten row borrowing
                    # an older provider URL from another show's cached episode.
                    if int(current_updated or 0) > int(other_updated or 0):
                        offender = (other_key, other_title, int(other_updated or 0))
                        break
                if not offender:
                    continue
                with conn:
                    conn.execute("DELETE FROM artwork WHERE item_key=? AND art_type=?", (item_key, art_type))
                    conn.execute("INSERT OR REPLACE INTO metadata(key,value) VALUES(?,?)", (
                        marker, "%s|owner=%s|title=%s" % (_now(), offender[0], offender[1])
                    ))
                repaired.append({"art_type": art_type, "url": url, "other_item_key": offender[0], "other_title": offender[1]})
                runtrace.event("artworkdb", "cross-series episode artwork collision reopened",
                               item_key=item_key, title=title_for_item(mediaitem), art_type=art_type,
                               other_item_key=offender[0], other_title=offender[1])
            return repaired
        finally:
            conn.close()
    except Exception as ex:
        _log_error("artwork-cache.db episode collision repair failed", ex, item_key=item_key)
        return repaired


def prepare_db_first_identity(mediaitem):
    identity = ensure_item_identity(mediaitem)
    collisions = repair_episode_cross_series_collisions(mediaitem)
    return {"identity": identity, "collisions": collisions, "changed": bool(identity.get("invalidated") or collisions)}


def cached_identity_mismatches(mediaitems):
    """Return current Kodi items whose type:DBID row belongs to another identity."""
    result = []
    items = list(mediaitems or [])
    if not items:
        return result
    try:
        conn = connect()
        try:
            for mediaitem in items:
                key = _item_key(mediaitem.mediatype, mediaitem.dbid)
                row = conn.execute("SELECT title,file,uniqueids FROM library_items WHERE item_key=?", (key,)).fetchone()
                if row and not _identity_matches(_mediaitem_identity(mediaitem), _stored_identity(row, mediaitem.mediatype)):
                    result.append(mediaitem)
        finally:
            conn.close()
    except Exception as ex:
        _log_error("artwork-cache.db batch identity scan failed", ex, count=len(items))
    return result

class ProcessedItemsAdapter(object):
    # In-memory compatibility adapter for legacy add_additional_iteminfo().
    # 0.32.5 intentionally has no processed_cache table and no processeditems.db.
    def __init__(self):
        self._data = {}
        self._seen = set()

    def _key(self, mediaid, mediatype):
        return _item_key(mediatype, mediaid)

    def exists(self, mediaid, mediatype, medialabel):
        return self._key(mediaid, mediatype) in self._seen

    def does_not_exist(self, mediaid, mediatype, medialabel):
        return not self.exists(mediaid, mediatype, medialabel)

    def is_stale(self, mediaid, mediatype, medialabel):
        return True

    def get_data(self, mediaid, mediatype, medialabel):
        return self._data.get(self._key(mediaid, mediatype))

    def set_data(self, mediaid, mediatype, medialabel, data):
        key = self._key(mediaid, mediatype)
        self._data[key] = data
        self._seen.add(key)

    def set_nextdate(self, mediaid, mediatype, medialabel, nextdate):
        self._seen.add(self._key(mediaid, mediatype))


def _ignored_legacy_artwork_where():
    # Legacy/internal rows kept for compatibility should not make status/source
    # summaries look duplicated or missing. Direct season rows are canonical;
    # tvshow season.N.* rows are only compatibility mirrors. Season/episode
    # fanart is no longer a managed target.
    ignored = "((item_key LIKE 'season:%' AND art_type='fanart') OR (item_key LIKE 'episode:%' AND art_type='fanart') OR (item_key LIKE 'tvshow:%' AND art_type LIKE 'season.%'))"
    return "NOT " + ignored

def summary_text():
    rows = ['Library Artwork Curator cache DB summary', '=' * 72, 'path: %s' % db_path(), 'schema: %s' % SCHEMA_VERSION]
    try:
        ensure()
        conn = connect()
        try:
            for table in ('metadata', 'library_items', 'artwork', 'runs', 'run_items'):
                try:
                    count = conn.execute('SELECT COUNT(*) FROM %s' % table).fetchone()[0]
                    if table == 'artwork':
                        active = conn.execute('SELECT COUNT(*) FROM artwork WHERE ' + _ignored_legacy_artwork_where()).fetchone()[0]
                        ignored = count - active
                        rows.append('%s: %s active / %s raw%s' % (table, active, count, ' (%s ignored legacy rows)' % ignored if ignored else ''))
                    else:
                        rows.append('%s: %s' % (table, count))
                except Exception as table_ex:
                    rows.append('%s: ERROR %r' % (table, table_ex))
            rows.append('')
            rows.append('Artwork status counts:')
            try:
                for row in conn.execute("SELECT COALESCE(NULLIF(status,''), '<empty>'), COUNT(*) FROM artwork WHERE " + _ignored_legacy_artwork_where() + " GROUP BY COALESCE(NULLIF(status,''), '<empty>') ORDER BY COUNT(*) DESC"):
                    rows.append('%s: %s' % row)
            except Exception:
                rows.append(traceback.format_exc())
            rows.append('')
            rows.append('Artwork source counts:')
            try:
                for row in conn.execute("SELECT COALESCE(NULLIF(source,''), '<empty>'), COUNT(*) FROM artwork WHERE " + _ignored_legacy_artwork_where() + " GROUP BY COALESCE(NULLIF(source,''), '<empty>') ORDER BY COUNT(*) DESC"):
                    rows.append('%s: %s' % row)
            except Exception:
                rows.append(traceback.format_exc())
            rows.append('')
            rows.append('Recent runs:')
            try:
                for row in conn.execute("SELECT run_id, action, status, total_items, processed_items, updated_items, updated_artwork, errors, COALESCE(elapsed_text, elapsed_ms || ' ms') FROM runs ORDER BY started_at DESC LIMIT 20"):
                    rows.append('%s | %s | %s | total=%s processed=%s updated_items=%s artwork=%s errors=%s elapsed=%s' % row)
            except Exception:
                rows.append('Recent runs query failed:')
                rows.append(traceback.format_exc())
        finally:
            conn.close()
    except Exception:
        rows.append('DB SUMMARY ERROR:')
        rows.append(traceback.format_exc())
    return '\n'.join(rows) + '\n'


def cleanup_retention(keep_runs=30):
    try:
        conn = connect()
        try:
            rows = conn.execute('SELECT run_id FROM runs ORDER BY started_at DESC LIMIT -1 OFFSET ?', (int(keep_runs),)).fetchall()
            old_ids = [row[0] for row in rows]
            if not old_ids:
                return 0
            with conn:
                for run_id in old_ids:
                    conn.execute('DELETE FROM run_items WHERE run_id=?', (run_id,))
                    conn.execute('DELETE FROM runs WHERE run_id=?', (run_id,))
            return len(old_ids)
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db cleanup_retention failed', ex)
        return 0



def delete_item_keys(item_keys):
    """Remove Library Artwork Curator cache rows for items that Kodi Clean Library removed."""
    keys = sorted(set(k for k in (item_keys or []) if k))
    if not keys:
        return {'items': 0, 'artwork': 0, 'run_items': 0}
    try:
        conn = connect()
        try:
            removed_items = removed_artwork = removed_run_items = 0
            with conn:
                for key in keys:
                    removed_artwork += conn.execute('DELETE FROM artwork WHERE item_key=?', (key,)).rowcount
                    removed_items += conn.execute('DELETE FROM library_items WHERE item_key=?', (key,)).rowcount
                    removed_run_items += conn.execute('DELETE FROM run_items WHERE item_key=?', (key,)).rowcount
            runtrace.event('artworkdb', 'clean library removed cached rows', keys=len(keys), library_items=removed_items, artwork=removed_artwork, run_items=removed_run_items)
            return {'items': removed_items, 'artwork': removed_artwork, 'run_items': removed_run_items}
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db delete_item_keys failed', ex, keys=len(keys))
        return {'items': 0, 'artwork': 0, 'run_items': 0}

def clear_run_history():
    try:
        conn = connect()
        try:
            with conn:
                run_items = conn.execute('DELETE FROM run_items').rowcount
                runs = conn.execute('DELETE FROM runs').rowcount
            return runs, run_items
        finally:
            conn.close()
    except Exception as ex:
        _log_error('artwork-cache.db clear_run_history failed', ex)
        return 0, 0


# Removed persistent queue DB in 0.32.5. These no-op wrappers keep old service calls harmless.
def queue_item(mediatype, dbid, source='kodi'):
    return True


def get_queued_items(media_types=None):
    return []


def clear_queued_items(rows):
    return 0


def pop_queued_items(media_types=None):
    return []


def queued_count():
    return 0


def record_maintenance(*args, **kwargs):
    return None
